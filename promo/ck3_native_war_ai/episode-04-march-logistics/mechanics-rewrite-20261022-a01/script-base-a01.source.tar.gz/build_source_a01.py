"""Compile the source-only episode rewrite; never synthesize or render media."""
from __future__ import annotations

import hashlib
import json
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
MACHINE = "desktop-3fevhd2-1c74096080"
TITLE = "大军为什么越走越少？——补给、损耗与行军费用"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def pin(path):
    body = path.read_bytes()
    if len(body) > 1048576:
        raise ValueError("Source-only compiler refuses large-body reads: " + str(path))
    return {"path": str(path), "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}


def width(text):
    return sum(2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in text)


def wrap(text, ceiling):
    lines = []
    line = ""
    for char in text:
        if line and width(line + char) > ceiling:
            lines.append(line)
            line = ""
        line += char
    if line:
        lines.append(line)
    return lines


def svg_card(card, target):
    ET.register_namespace("", "http://www.w3.org/2000/svg")
    ns = "{http://www.w3.org/2000/svg}"
    svg = ET.Element(ns + "svg", {"viewBox": "0 0 1920 1080", "width": "1920", "height": "1080"})
    ET.SubElement(svg, ns + "title").text = card["title"]
    ET.SubElement(svg, ns + "desc").text = "CK3 1.20.0.4. " + card["note"]
    ET.SubElement(svg, ns + "rect", {"width": "1920", "height": "1080", "fill": "#111b29"})
    ET.SubElement(svg, ns + "rect", {"x": "88", "y": "82", "width": "8", "height": "76", "fill": "#dfbd73"})

    def text(value, x, y, size, fill="#edf1f5"):
        item = ET.SubElement(svg, ns + "text", {
            "x": str(x), "y": str(y), "font-size": str(size), "fill": fill,
            "font-family": "Microsoft YaHei, Noto Sans CJK SC, sans-serif"})
        item.text = value

    text(card["title"], 120, 134, 48)
    ET.SubElement(svg, ns + "rect", {"x": "112", "y": "205", "width": "1696", "height": "225", "rx": "18", "fill": "#1d3046"})
    hero_lines = wrap(card["hero"], 76)
    if len(hero_lines) > 3:
        raise ValueError("Hero overflow: " + card["id"])
    for i, line in enumerate(hero_lines):
        text(line, 152, 273 + i * 62, 40, "#f1d58e")
    y = 493
    if card["id"] == "F07":
        # Three schematic rule panels. These are diagrams, not game captures.
        labels = [("同领内换男爵领", "不触发这一跨领项", "#528b90"),
                  ("跨领但接壤控制区", "不触发这一深入项", "#528b90"),
                  ("跨领且不接壤控制区", "跨入时结算", "#c37760")]
        for i, (heading, result, color) in enumerate(labels):
            x = 120 + i * 570
            ET.SubElement(svg, ns + "rect", {"x": str(x), "y": "480", "width": "540", "height": "354", "rx": "14", "fill": "#1a2737", "stroke": color, "stroke-width": "3"})
            text(heading, x + 24, 536, 30)
            if i == 0:
                ET.SubElement(svg, ns + "rect", {"x": str(x + 28), "y": "568", "width": "484", "height": "151", "fill": "#724a44"})
                text("同一敌对伯爵领", x + 144, 602, 24)
                for j in range(2):
                    ET.SubElement(svg, ns + "rect", {"x": str(x + 56 + j * 260), "y": "621", "width": "162", "height": "72", "fill": "#91645a"})
                    text("男爵领", x + 91 + j * 260, 667, 25)
                text("→", x + 238, 668, 39, "#f1d58e")
            elif i == 1:
                ET.SubElement(svg, ns + "rect", {"x": str(x + 28), "y": "568", "width": "484", "height": "66", "fill": "#31585c"})
                text("我方控制区", x + 190, 610, 25)
                ET.SubElement(svg, ns + "rect", {"x": str(x + 28), "y": "634", "width": "242", "height": "85", "fill": "#724a44"})
                ET.SubElement(svg, ns + "rect", {"x": str(x + 270), "y": "634", "width": "242", "height": "85", "fill": "#91645a"})
                text("敌伯爵领甲", x + 45, 685, 23)
                text("→", x + 242, 688, 34, "#f1d58e")
                text("敌伯爵领乙", x + 300, 685, 23)
            else:
                for j in range(3):
                    ET.SubElement(svg, ns + "rect", {"x": str(x + 28 + j * 161), "y": "585", "width": "161", "height": "134", "fill": "#31585c" if j == 0 else "#724a44"})
                    text("控制区" if j == 0 else "敌伯爵领" + ("甲" if j == 1 else "乙"), x + 37 + j * 161, 644, 22)
                text("→", x + 335, 698, 36, "#f1d58e")
            text(result, x + 28, 758, 30, "#f1d58e")
        y = 884
        text("同领内换男爵领，不表示其他损耗为零", 132, y, 31)
    else:
        rows = [line for row in card["rows"] for line in wrap(row, 90)]
        if len(rows) > 8:
            raise ValueError("Rows overflow: " + card["id"])
        for line in rows:
            text(line, 132, y, 33)
            y += 54
    note_lines = wrap(card["note"], 130)
    if len(note_lines) > 2 or y > 980:
        raise ValueError("Footer overflow: " + card["id"])
    for i, line in enumerate(note_lines):
        text(line, 120, 1000 + i * 30, 23, "#a7b6c7")
    text("CK3 1.20.0.4", 1570, 1060, 21, "#a7b6c7")
    ET.indent(svg, space="  ")
    target.write_bytes(ET.tostring(svg, encoding="utf-8", xml_declaration=True) + b"\n")


def main():
    observed = datetime.now(timezone.utc).isoformat()
    chapters = [read(p) for p in sorted((ROOT / "chapters").glob("*.json"))]
    cues = [c for chapter in chapters for c in chapter["cues"]]
    baseline = read(ROOT / "CURRENT67-SOURCE-INDEX.actual-a01.json")
    project = read(ROOT / "promo-project.mechanics.source-a01.json")
    project["project"]["title"] = TITLE
    project["chapters"] = [{"id": c["chapter_id"], "type": "documentary", "state": "planned",
        "title": {"zh-CN": c["title_zh"], "en": c["title_en"]},
        "cues": [{"id": x["id"], "narration": {"zh-CN": x["narration_zh"]},
                  "subtitles": {"zh-CN": x["subtitle_zh"], "en": x["subtitle_en"]}}
                 for x in c["cues"]]} for c in chapters]
    write(ROOT / "promo-project.mechanics.source-a01.json", project)
    write(ROOT / "NARRATION-SUBTITLES.source-a01.json", {
        "schema": "xar.e04.mechanics.bilingual-source.v1", "machine_id": MACHINE,
        "observed_at_utc": observed, "source_only": True, "narration_generated": False,
        "timing": "Set from actual newly generated narration, then lay out meaningful formula/footage beats. No old timebase is imposed.",
        "target_duration_seconds": [1200, 2400], "chapters": chapters})
    md = ["# " + TITLE, "", "源稿：中文旁白及中文字幕、英文字幕。尚未合成或计量新音频。", ""]
    for chapter in chapters:
        md += ["## " + chapter["title_zh"], ""]
        for cue in chapter["cues"]:
            md += ["### " + cue["id"], "", cue["narration_zh"], "", cue["subtitle_en"], ""]
    (ROOT / "SCRIPT.zh-en.source-a01.md").write_text("\n".join(md), encoding="utf-8")
    official = read(BASE / "research-a01/terminology_audit/AUDIT-CURRENT67.actual-a01.json")
    cue_hits = official["cue_hits"]
    mechanism = read(BASE / "research-a01/mechanism_audit/MECHANISM-AUDIT-AND-R04-RULES.actual-a01.json")
    mapped = {row["cue_id"]: [c["id"] for c in cues if row["cue_id"] in c["old_cues"]]
              for row in baseline["rows"]}
    meta_ids = {"C01-03", "C05-02", "C05-15", "C05-16", "C06-01"}
    audit_rows = []
    for row in baseline["rows"]:
        ids = mapped[row["cue_id"]]
        terms = [term for term, old_ids in cue_hits.items() if row["cue_id"] in old_ids]
        findings = [item for item in mechanism["audit"] if row["cue_id"] in item["cues"]]
        audit_rows.append({**row, "new_cues": ids,
            "current_core_sentence": row["current_narration_zh"].partition("。")[0] + "。",
            "official_term_issues": terms,
            "mechanism_gaps_in_old_cue": [item["finding"] for item in findings],
            "replacement_mechanisms": [{"cue_id": c["id"], "narration_zh": c["narration_zh"], "evidence": c["evidence"]} for c in cues if c["id"] in ids],
            "action": "replace_and_merge" if ids else "delete_from_main_narration",
            "production_or_repeated_method_priority_delete": row["cue_id"] in meta_ids,
            "reason": "Mechanism and worked example replace production explanation; actual footage is separately retained by evidence scope." if ids else "No unique player mechanism is retained from this old narration; valid source evidence stays in the source register."})
    write(ROOT / "CURRENT67-TO-REWRITE-MAP.source-a01.json", {
        "schema": "xar.e04.complete67-rewrite-map.v1", "machine_id": MACHINE,
        "observed_at_utc": observed, "baseline": pin(ROOT / "CURRENT67-SOURCE-INDEX.actual-a01.json"),
        "terminology_audit": pin(BASE / "research-a01/terminology_audit/AUDIT-CURRENT67.actual-a01.json"),
        "old_count": 67, "new_count": len(cues), "rows": audit_rows,
        "rule": "Old timecodes identify the viewed a03 only. New timings require actual new narration; no old voice CAS is falsely reused under rewritten text."})
    cards = read(ROOT / "FORMULA-CARDS.source-a01.json")["cards"]
    target = ROOT / "formula-svg"
    target.mkdir(exist_ok=True)
    for card in cards:
        svg_card(card, target / (card["id"] + ".svg"))
    keys = sorted({k for c in cues for k in c["evidence"]})
    packets = {
        "terminology": "terminology_audit/TERMINOLOGY.v1.json",
        "monthly": "monthly_rules/MECHANICS-CLOSED.actual-a01.json",
        "loss_fleet": "monthly_rules/LOSS-FLEET-SUPPLEMENT.actual-a01.json",
        "named_modifiers": "monthly_rules/NAMED-MODIFIERS-CLOSED.actual-a01.json",
        "levy_context": "monthly_rules/LEVY-CONTEXT-CLOSED.actual-a01.json",
        "land_scope": "monthly_rules/LAND-SCOPE-AND-GRACE-CLOSED.actual-a01.json",
        "raw_retreat_state": "monthly_rules/UNIT-RAW-STATE-CLOSED.actual-a01.json",
        "attrition": "mechanism_audit/MECHANISM-AUDIT-AND-R04-RULES.actual-a01.json",
        "merge": "mechanism_audit/R09-DESTINATION-WEIGHT-CLOSED.actual-a01.json",
        "march_upkeep": "march_payroll_rules/rules-a01.json",
        "march_upkeep_primary": "march_payroll_rules/prior-rules-a01.source.json",
        "financial_cadence": "march_payroll_rules/financial-cadence-a03.json",
        "embark": "research_next/DELIVERY.actual-a01.json",
        "embark_rules": "research_next/R07-EMBARK-FEE-SOURCE.candidate-a01.md",
        "embark_registry": "research_next/MODIFIER-REGISTRATION-CLOSED.actual-a02.json"}
    packet_pins = {k: pin(BASE / "research-a01" / v) for k, v in packets.items()}
    eight_path = Path(baseline["eight_example_sources"]["path"])
    eight = read(eight_path)
    themes = {item["theme"]: item for item in eight["examples"]}
    actual_theme = {"actual.reinforcement.R0221": "R06", "actual.split.R0194": "R09",
        "actual.siege.R0191": "R03", "actual.county.R0217": "R04",
        "actual.embark.R0196": "R07", "actual.stop.R0174": "R11",
        "actual.stop.R0175": "R12", "actual.reroute.R0176": "R13"}
    actual_receipts = {key: themes[theme]["source_root_adjudication"] for key, theme in actual_theme.items()}
    actual_receipts["actual.B.first_station"] = pin(Path("C:/ck3-e04-resume-20261020-a01/r18-publication-source-a01/successor-r0232-a01/ROOT-R0232-R10-FIRSTSITE-SHOT-ACCEPTANCE.actual-a02.json"))
    actual_receipts["actual.B.second_station"] = pin(Path("C:/ck3-e04-resume-20261020-a01/r20-b-secondclip-qa-a01/ROOT-R0234-SECOND-SITE-LIMITED-ADOPTION.actual-a01.json"))
    links = []
    for key in keys:
        if key.startswith("official."):
            groups = ["terminology"]
        elif key.startswith("rules.embark.") or key.startswith("actual.embark."):
            groups = ["embark", "embark_rules", "embark_registry"]
        elif key.startswith("rules.merge.") or key == "rules.character_regiment":
            groups = ["merge", "named_modifiers"]
        elif key.startswith("rules.split."):
            groups = ["merge", "attrition"]
        elif key.startswith("rules.attrition.hostile"):
            groups = ["attrition"]
        elif key.startswith("rules.supply.") or key.startswith("rules.reinforcement.") or key.startswith("rules.attrition."):
            groups = ["monthly", "loss_fleet", "named_modifiers"]
            if key.startswith("rules.supply."):
                groups.append("land_scope")
            if key.startswith("rules.reinforcement."):
                groups.append("levy_context")
        elif key.startswith("rules.maintenance.") or key.startswith("rules.movement."):
            groups = ["march_upkeep", "march_upkeep_primary"]
            if key in ("rules.maintenance.financial_cadence", "rules.maintenance.accounting"):
                groups.append("financial_cadence")
        else:
            groups = []
        links.append({"key": key, "closed_research_packets": groups,
                      "actual_scope_receipt": actual_receipts.get(key),
                      "used_by": [c["id"] for c in cues if key in c["evidence"]]})
    write(ROOT / "EVIDENCE-REGISTER.source-a01.json", {
        "schema": "xar.e04.mechanics.source-register.v1", "machine_id": MACHINE,
        "observed_at_utc": observed, "retained_build": "1.20.0.4/25734779",
        "packets": packet_pins, "claim_keys": links,
        "actual_scope_receipts": actual_receipts,
        "actual_footage_source_index": baseline["eight_example_sources"],
        "baseline_movie": baseline["actual_movie_retained_pin"],
        "current_big_media_body_read": False,
        "supersession": "rules-a01's historical null payment cadence is superseded only by financial-cadence-a03. Its closed upkeep and speed rules remain valid source. Path-weight initialization remains a separate active research question; this script uses path weight without inventing kilometres or a terrain producer.",
        "remaining_research": "A new recorded actual military payment and complete common-start A/B/C results are not supplied by static formulas."})
    write(ROOT / "ASSET-REUSE-PLAN.source-a01.json", {
        "schema": "xar.e04.mechanics.visual-and-voice-source-plan.v1", "machine_id": MACHINE,
        "observed_at_utc": observed, "source_only": True,
        "new_voice_cues": [c["id"] for c in cues], "old_voice_reused_under_changed_text": False,
        "onscreen_version_scope": {"opening_corner_label": "CK3 1.20.0.4", "formula_footer": "All18 formula SVG sources explicitly show CK3 1.20.0.4", "all_versions_claimed": False},
        "future_run_toolchain_check": "Before each newly admitted media run, verify the then-current official xar_promo_toolchain Release and the exact installed version/wheel/CLI source; reuse a fresh same-run qualification when applicable. Historical0.3.0 is not assumed permanently latest.",
        "formula_cards": [pin(p) for p in sorted(target.glob("*.svg"))],
        "accepted_original_shots": [{"theme": theme, "raw_retained_ref": item["raw"],
            "start_seconds": item["start_seconds"], "source_seconds": item["source_seconds"],
            "scope_receipt": item["source_root_adjudication"]} for theme, item in themes.items()],
        "new_B_shots": [{"key": "actual.B.first_station", "frame_window": [420, 1137], "fps": 30,
                         "scope_receipt": actual_receipts["actual.B.first_station"], "native_illustration_redraw_raw_frames": [648, 680]},
                        {"key": "actual.B.second_station", "frame_window": [420, 1120], "fps": 30,
                         "scope_receipt": actual_receipts["actual.B.second_station"], "native_illustration_redraw_raw_frames": [631, 664]}],
        "old_burned_subtitle_segments": "Do not reuse old complete segments when old terminology or narration is burned in. Reuse their accepted raw source windows and qualified compositor, not incorrect visible text.",
        "music": eight["music"],
        "pending_topics": ["R05", "full R08", "full R10 strategy", "common-start A/B/C comparison"],
        "formal_credit_not_increased_by_rewrite": True,
        "actual_old_viewed_movie_kept": True, "media_copy_or_decode_during_source_build": False})
    assert len(baseline["rows"]) == 67
    assert len({c["id"] for c in cues}) == len(cues)
    assert all(c["subtitle_zh"] == c["narration_zh"] and c["subtitle_en"] for c in cues)
    assert 69 * 4020 // 100000 == 2 and min(69 * 4020 // 100000, 1) == 1
    assert 199 * 5 // 100 + 199 // 100 == 10
    assert (1162 * 1000 * 25000 // 100000 + 50000) // 100000 == 3
    assert min(30000000, 29894738 + 2000000) - 29894738 == 105262
    for path in target.glob("*.svg"):
        ET.parse(path)
    size = sum(p.stat().st_size for p in ROOT.rglob("*") if p.is_file())
    if size > 4194304:
        raise ValueError("Source root exceeded 4MiB")
    write(ROOT / "SOURCE-CHECKS.draft-a01.json", {"machine_id": MACHINE,
        "observed_at_utc": observed, "all_json_xml_parse": True, "old_cues_indexed": 67,
        "new_cues": len(cues), "formula_svg_count": len(cards),
        "chinese_narration_characters": sum(len(c["narration_zh"]) for c in cues),
        "arithmetic_examples": "PASS", "actual_TTS_or_render": False,
        "aggregate_bytes_before_this_receipt": size,
        "not_checked": ["actual new narration length", "rendered SVG appearance", "human continuous AV review"]})
    print(json.dumps({"cues": len(cues), "cards": len(cards), "source_bytes": size}, ensure_ascii=False))


if __name__ == "__main__":
    main()
