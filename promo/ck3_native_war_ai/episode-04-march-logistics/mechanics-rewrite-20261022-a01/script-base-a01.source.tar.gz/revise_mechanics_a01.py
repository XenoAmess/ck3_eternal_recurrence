"""Apply the mechanism corrections received during the source-only rewrite.

This authoring helper writes only the sibling script source directory. It does
not run TTS, render, read large media, or modify any baseline evidence.
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def replace(cues: list[dict[str, object]], cue_id: str, zh: str, en: str) -> None:
    item = next(c for c in cues if c["id"] == cue_id)
    item.update(narration_zh=zh, subtitle_zh=zh, subtitle_en=en)


def add(cues: list[dict[str, object]], after: str, cue_id: str, old: list[str],
        zh: str, en: str, visual: str, evidence: list[str]) -> None:
    if any(c["id"] == cue_id for c in cues):
        return
    index = next(i for i, c in enumerate(cues) if c["id"] == after) + 1
    cues.insert(index, {"id": cue_id, "old_cues": old, "narration_zh": zh,
                        "subtitle_zh": zh, "subtitle_en": en,
                        "visual": visual, "evidence": evidence})


def main() -> None:
    for path in sorted((ROOT / "chapters").glob("*.json")):
        obj = json.loads(path.read_text(encoding="utf-8"))
        cues = obj["cues"]
        chapter = obj["chapter_id"]
        if chapter == "E4-01":
            replace(cues, "N01-02",
                    "补给变化不是每天把月变化除以三十。游戏把军队分组，每天处理轮到的那组；轮到这支军队、并且允许更新时，才把当前变化量整笔加上。战斗和集结会阻止这次更新。原版集结后的补给宽限是三十天，必须已经超过三十天，才通过这一项检查。因此停下几天而补给条没有变化，可能还没有轮到可以恢复的那次结算。",
                    "Supply change is not divided by 30 and applied daily. Armies are processed in rotating groups. When an army's group is processed and its update conditions pass, the current change is applied in full. Combat and gathering block the update. The vanilla post-gathering supply grace requires more than 30 days to have elapsed. Several stationary days with no bar movement can therefore mean the eligible recovery update has not yet arrived.")
            replace(cues, "N01-04",
                    "看第一处实际驻点。结算前，面板显示二百七十八；结算后，显示二百九十八。精确值约从二百七十八点九五，升到二百九十八点九五，实际增加二十。军队仍是一千一百九十五人。恢复的是补给，士兵人数没有因此增加。",
                    "At the first recorded station, the panel changes from 278 to 298. The precise values are approximately 278.95 and 298.95: an actual increase of 20. The army remains at 1,195 soldiers. Supply recovers; troop strength does not increase.")
            replace(cues, "N01-03",
                    "陆地恢复补给，要同时通过地点关系和当地人数两道判断。自己控制、或同一场当前战争同侧参战者控制的土地，是直接允许的情况；属下和宗主关系也会进入后续判断。看的是实际控制者，不能只看法理归属或一纸盟约。地点允许、当地计算兵力又不超过补给上限时，基础恢复二十；恰好等于上限也可以恢复。占领者改变以后，同一块地的补给许可也可能改变。",
                    "Land resupply requires both an eligible location relationship and a troop-count check. Land actually controlled by the army owner, or by a participant on the same side of a current war, is directly admitted. Subordinate and suzerain relationships also enter later checks. Actual control matters, rather than de jure ownership or an alliance alone. With permission and counted strength no greater than the local limit, base recovery is 20; equality can recover. A change of occupation can change resupply permission at the same location.")
            add(cues, "N01-03", "N01-11", ["C02-03", "C05-07"],
                "当地人数合计哪些军队？同一地点自己的军队，以及某场当前战争里同侧参战者的军队，会一起计算。普通征召兵和兵士看当前人数；明确不消耗补给的生成部队，则从用量里排除。行军和撤退不会自动把本应计入的军队删掉。两队还在同一地点时，只选中较小的那支，另一支仍然占用当地补给。",
                "Which armies count toward local usage? Your own armies at that location and armies on the same side of a current war are counted together. Ordinary levies and men-at-arms use current troop strength; spawned troops explicitly set not to consume supply are excluded. Moving and retreating do not automatically remove an otherwise included army. Selecting the smaller of two armies at the same location leaves the other in local usage.",
                "Local usage participants: own / same-war-side; show an explicit non-consuming special troop exception separately.",
                ["rules.supply.local_usage"])
            replace(cues, "N01-05",
                    "第二处驻点为什么只增加约一点零五？因为补给最多只能到三百。原来的约二百九十八点九五，加二十，已经超过上限；游戏把结果压回三百。实际只补上距离上限的约一点零五。这个小增量来自封顶，不是这里的恢复速度突然变慢。",
                    "Why does the second station add only about 1.05 supply? The army's limit is 300. Adding 20 to approximately 298.95 exceeds that limit, so the result is capped at 300. It only fills the remaining gap of about 1.05. The smaller gain is caused by the cap, not by a slower local recovery rate.")
            replace(cues, "N01-07",
                    "补给状态看绝对数值，不看补给条填了百分之多少。六十及以上是补给充分；十到不足六十是补给不足；低于十才是挨饿。所以上限三百时，补给十仍在上面一档，九点九九已经进入挨饿。将领和当地修正还会改变最后的消耗，判断时要看军队实际显示的变化值。",
                    "Supply states use absolute values, not the percentage of the bar filled. At least 60 is Well Supplied; 10 to below 60 is Low on Supplies; below 10 is Starving. Even with a limit of 300, exactly 10 is on the upper side, while 9.99 is Starving. Commander and local modifiers affect final consumption, so use the army's actual displayed change.")
            replace(cues, "N01-08",
                    "一次更新里，先改变补给，再按改变后的补给计算损耗。原来十二，减去五，变成七，这一次就可以进入挨饿损耗，不必再等下一轮。补给条不动，可能是加值碰到上限，负变化被下限压回零，还没轮到允许更新，或者更新已经发生、但当地当前变化量恰好为零。",
                    "Supply changes before attrition is calculated from the new value. Starting at 12 and losing five gives seven, which can trigger starvation attrition in that same update. An unchanged bar can mean a capped gain, a loss floored at zero, an eligible update that has not yet occurred, or an update that did occur with a current local change of exactly zero.")
            add(cues, "N01-06", "N01-10", ["C02-04", "C06-04"],
                "后勤专家改变的是补给持续时间。假设总有效加成只有百分之四十，原本每轮消耗五点，会除以一点四，变成约三点五七，而不是直接少扣百分之四十、变成三点。它改变负数补给变化的大小，不改变军队轮到更新的日程，也不把友方的基础恢复二十变成二十八。有进阶特质或其他加成时，要代入合计后的有效数值。",
                "Logistician changes supply duration. If the total effective bonus is exactly 40%, a loss of five is divided by 1.4, giving about 3.57, rather than reduced by 40% to three. This changes negative supply change, not the army's update schedule, and it does not turn the base friendly recovery of 20 into 28. Trait progression and other bonuses must be included in the total effective modifier.",
                "F15: named supply-duration division and separate positive recovery.",
                ["rules.supply.duration_named"])
        elif chapter == "E4-02":
            replace(cues, "N02-01",
                    "补员按日历月初处理，和补给按军队分组轮转，是两套不同的节奏。补给够用，不会直接把缺额变成士兵。要看军团当前人数、满员人数、补员率和当次条件。军队总人数把不同军团放在一起；展开军团，才能知道缺员的是哪一部分，以及它由谁提供。",
                    "Reinforcement is processed at the start of the calendar month, unlike supply's rotating army groups. Having enough supply does not directly turn vacancies into soldiers. Reinforcement depends on current strength, maximum strength, rate and eligibility. The army total combines different regiments; expanding them shows where the vacancies are and who provides those troops.")
            replace(cues, "N02-02",
                    "兵士补员开关要看军团的提供者。来源是封臣时，相关分支读取的是提供者是否允许补员，不是只看玩家自己的开关。普通征召兵不读取这项兵士补员开关；它仍要通过各自的来源、位置和战斗状态检查。先认清这部分兵属于哪种来源，才能判断调整哪个开关会影响它。",
                    "The men-at-arms reinforcement toggle is checked against the regiment's provider. For vassal-provided troops, the relevant path uses that provider's setting, not simply the player's. Ordinary levies bypass this men-at-arms toggle but still have their own origin, position and combat checks. Identify the troop source before deciding which toggle can affect it.")
            add(cues, "N02-02", "N02-04", ["C02-09", "C06-07"],
                "普通征召兵的补员速率，是基础速率乘上一加适用修正的合计。来源地产、持有者、信仰关系，以及符合位置条件时的将领友好领土补员修正，进入对应的分支。用一个规则算例：基础百分之三，适用修正合计提高百分之三十四，结果就是百分之四点零二。这里把修正先相加，再乘基础；不是把每个百分比轮流相乘。",
                "For ordinary levies, the reinforcement rate is the selected base rate multiplied by one plus the sum of applicable modifiers. The origin holding, holder, faith relationship and eligible commander friendly-territory modifier contribute through their respective branches. In a rule example, a 3% base rate with applicable modifiers totalling +34% gives 4.02%. Add those rate modifiers before multiplying the base; do not multiply their percentages one after another.",
                "F16 rule example, kept separate from the historical 4.02% input whose individual components were not sampled.",
                ["rules.reinforcement.rate_named"])
            add(cues, "N02-03", "N02-05", ["C02-01", "C02-09"],
                "这也解释了两种常见现象。第一，接近满员的军团，实际增加人数会小于补员率乘满员人数，因为剩余缺额先限制了结果。第二，很多小军团各自取整，和把它们当成一个大军团再算，可能得到不同总数。要补的是各军团的缺额，不能只把军队总人数乘一个补员百分比，就当成下一轮一定会增加的人数。",
                "Two common results follow. Near-full regiments gain fewer soldiers than maximum strength times the reinforcement rate because their remaining vacancies limit the result. Separately rounding many small regiments can also differ from treating them as one large regiment. Reinforcement fills each regiment's vacancies; multiplying the army total by one percentage is not a guaranteed next-update gain.",
                "Per-regiment vacancies and rounding diagram; no unobserved actual gain is assigned.",
                ["rules.reinforcement.quantity"])
            replace(cues, "N02-05",
                    "补员还按军团中实际分开的兵力部分分别计算、分别取整。假设两部分满员都是二十人，都允许补员，而且缺额充足；补员率都是百分之三。每部分算出零点六人，各自舍去小数，结果都是零。不能先合成满员四十人，再把一点二取成一人。接近满员时还要先限制缺额，所以也不能把军队总人数乘一个百分比，就当成下一轮一定增加的人数。",
                    "Reinforcement is calculated and rounded separately for the regiment's individual troop portions. Suppose two eligible portions each have a maximum of 20, ample vacancies and a 3% rate. Each produces 0.6, which separately truncates to zero. Combining their maxima into 40 and truncating 1.2 to one gives the wrong result. Vacancies also limit near-full portions, so the army total times one percentage is not a guaranteed next-update gain.")
            replace(cues, "N02-04",
                    "普通征召兵的补员速率，是基础速率乘上一加适用修正的合计。兵源地、持有者、信仰关系，以及符合位置条件时的将领友好领土补员修正，进入对应分支。这里比较兵源伯爵领和原地产持有者的信仰；同一信仰内，即使礼仪不同，也走相同信仰这一支。用假设算例：基础百分之三，适用修正合计提高百分之三十四，结果是百分之四点零二。修正先相加，再乘基础。",
                    "For ordinary levies, the reinforcement rate is the selected base multiplied by one plus the sum of applicable modifiers. Origin, holder, faith and an eligible commander friendly-territory modifier contribute through their respective branches. The faith comparison uses the troop-source county and the original holding's holder; different rites within one faith still use the same-faith branch. In a hypothetical example, a 3% base with applicable modifiers totalling +34% gives 4.02%. Add those modifiers before multiplying the base.")
            add(cues, "N02-02", "N02-06", ["C02-09"],
                "补员还要看兵源地。普通来源地产正在被围攻，会阻止相关补员；占领状态也进入常规检查。军队在外面时，还要看当前地点持有者与它的关系，战斗和撤退另有资格限制。单纯处在行军状态，并不自动禁止补员。因此缺员迟迟补不上，要分别看兵源地和军队所在位置，而不是只看补给条。",
                "Reinforcement also depends on the troop origin. An origin holding under siege blocks the relevant reinforcement, and occupation is checked on the ordinary path. A field army's eligibility also depends on its relation to the current location's holder, with additional combat and retreat restrictions. Movement alone does not automatically forbid reinforcement. Persistent vacancies therefore require checking both the troop origin and the army's location, not just its supply bar.",
                "Origin holding and army-location two-panel eligibility diagram; no literal source-memory labels.",
                ["rules.reinforcement.eligibility"])
        elif chapter == "E4-03":
            replace(cues, "N03-03",
                    "不同分量先各自取整，再合并。假设这次补给损耗和围攻损耗，各自的计算人数都恰好是一百九十九人。补给分量百分之五，算出九人；围攻分量百分之一，算出一人，合计十人。如果先把比例加成百分之六，再乘一百九十九，就会算成十一人。实际两项的计数范围还要分别判断，不能先混成一个共同人数。",
                    "Components are truncated separately before being combined. Suppose the supply and siege components each happen to use a count of 199. The 5% supply component gives nine, while the 1% siege component gives one: ten in total. Adding the rates first and multiplying 199 by 6% would instead give eleven. In an actual army, the two components' counting scopes must be evaluated separately rather than assumed to share one denominator.")
        elif chapter == "E4-04":
            replace(cues, "N04-01",
                    "平分军队，并不是把每个军团的人数逐一砍成两半。普通路径以整队军团为单位分配，再按权重分组，所以两支军队不保证人数正好相等。这次实拍，原来二百五十人，拆出七十五人，另一支一百七十五人，合计仍是二百五十。拆分改变的是编组。",
                    "Splitting an army in half does not halve every regiment internally. The normal path assigns whole regiments by weight, so the two army totals need not be identical. In this example, 250 becomes 75 and 175, still totaling 250. The split changes organization.")
            replace(cues, "N04-05",
                    "保留哪支军队，偶尔也会影响权重。两边使用不同的计数：本例这种将领关联的非兵士一人记录，保留军不计，并入军计入。用假设算例：甲有一百名普通兵和这个角色记录，补给二十；乙有一百名普通兵，补给八十。保留甲，算出五十；保留乙，在不碰合后上限的条件下，按两步取整算出约四十九点八五。",
                    "The retained army can affect the weights because the two sides use different counts. The commander-associated non-men-at-arms one-person record in this example is excluded on the retained side and included on the absorbed side. Suppose A has 100 ordinary soldiers plus that record and 20 supply; B has 100 ordinary soldiers and 80 supply. Keeping A gives 50. Keeping B gives about 49.85 after the two truncations, without hitting the final limit.")
        elif chapter == "E4-05":
            replace(cues, "N05-01",
                    "行军时间要逐段算。每段路段权重，除以军队在这一段的有效速度，再把各段时间相加。已经走了一部分的首段，要先减去累计完成的进度，再算剩余时间。地图预览的终点日期、首段剩余时间和移动速度，描述的是不同的量。路段权重也不是地图上的公里数。",
                    "Travel time is calculated leg by leg. Divide each leg's path weight by its effective army speed, then add the leg times. For a partly completed first leg, subtract accumulated progress before calculating the remaining time. A destination estimate, remaining first-leg time and movement speed are different quantities. Path weight is not a distance in kilometres on the map.")
            replace(cues, "N05-06",
                    "登船还有一次性费用。先用这支军队参与计费的人数除以一百，乘原版每百人一金币，再乘登船费用倍率。倍率是一加角色的合计登船修正，但最低保留零点一。算出非负金额后，最后加零点五并截成整金币，也就是普通正数下的四舍五入。人数不先凑整百，倍率最低一成也不等于至少收一金币。",
                    "Embarkation has a one-off fee. Divide the army's counted troop strength by 100, multiply by the vanilla rate of one gold per hundred, then by the embarkation-cost multiplier. That multiplier is one plus the character's combined embarkation modifier, with a minimum of 0.1. The nonnegative amount is finally increased by 0.5 and truncated to whole gold: ordinary round-half-up. Troop strength is not rounded to full hundreds first, and the 10% multiplier floor is not a minimum fee of one gold.")
            replace(cues, "N05-07",
                    "这次为什么恰好收三金币？军队是一千一百六十二人，罗贝尔的诺曼文化已经掌握长船革新，登船费用减少百分之七十五。用长船折扣代入：十一点六二乘零点二五，得到二点九零五，最终取成三金币，和这次实付一致。画面的钱包从二百六十降到二百五十七，精确账户扣去的也是三金币。同样人数如果没有折扣，十一点六二就会取成十二金币。",
                    "Why is this example three gold? The army has 1,162 soldiers, and Robert's Norman culture has discovered Longboats, reducing embarkation cost by 75%. With that discount, 11.62 × 0.25 = 2.905, rounding to three gold and matching the actual payment. The visible wallet falls from 260 to 257, and the precise account also records a three-gold debit. Without a discount, the same 11.62 would round to 12 gold.")
            add(cues, "N05-07", "N05-09", ["C04-10"],
                "这个取整也会让小军队的金币显示出现台阶。假设只有长船的七成五折扣，一百人算出零点二五金币，最终是零；二百人算出零点五，最终是一金币。即使登船修正把一加修正压到零以下，最低倍率仍然是一成，而不是负数或倒贴金币。规划海路时，应该代入当前军队和角色的有效修正，最后再做整金币取整。",
                "Whole-gold rounding creates steps for small armies. With only the 75% Longboats discount, 100 counted troops produce 0.25 gold and round to zero; 200 produce 0.5 and round to one. Even if one plus the embarkation modifier falls below zero, the multiplier floor remains 0.1 rather than becoming negative or paying the army. Use the current army and character's effective modifiers, then round the final fee.",
                "F17 hypothetical troop-count staircase at the final whole-gold rounding boundary.",
                ["rules.embark.formula"])
        elif chapter == "E4-06":
            replace(cues, "N06-04",
                    "最大军事维护费，是以全军集结并补到满员为前提，不是当前残余人数原封不动乘个系数。当前军事维护费和最大军事维护费，是两种情景，不能相加。远征时，还要按军队实际的海上状态核算额外维护。把集结、补员和海上状态分开，才知道哪一项会使接下来的费用上升。",
                    "Maximum military upkeep assumes the army is raised and fully reinforced; it is not simply a multiplier on its current depleted strength. Current and maximum upkeep are different scenarios and are not added together. An expedition also requires naval upkeep to be evaluated for the army's actual embarked state. Separate raising, reinforcement and naval status to see what increases the next bill.")
            add(cues, "N06-04", "N06-08", ["C05-11", "C05-13", "C06-08"],
                "符合常规经济结算条件的领主，按角色编号分成三十组，每天轮到一组，同一领主每三十日结算一次，不是所有人都在每月一号结账。届时整笔结算本轮月度净收支，不再把月费除以三十逐日扣。金币计算保留小数；这和登船费用最后取成整金币，是两套不同的取整规则。",
                "Lords eligible for ordinary economic settlement are divided into 30 groups by character ID. One group is processed each day, so the same lord settles once every 30 days, rather than everyone settling on the first of each calendar month. The monthly net amount is settled in full, not divided by 30 into daily charges. Gold calculations retain fractional precision, unlike the final whole-gold rounding of embarkation fees.",
                "F18: distinct reinforcement calendar month / rotating army supply / rotating lord finances. Static scheduling source is not presented as a newly recorded payment.",
                ["rules.maintenance.financial_cadence"])
            replace(cues, "N06-05",
                    "把收入和开支放到同一轮里算。假设这一轮收入十金币，包含军费在内的完整支出三金币，正常净入账就是七金币；军费已经抵扣过，不再重复减一次。一次性登船费用则另外预留。钱包同时受税收、其他支出和一次性费用影响，判断远征能撑多久，要看集结后的净亏损，而不只盯着军费这一项。",
                    "Compare income and expenses within the same settlement. If income is ten gold and total expenses, including military upkeep, are three, the ordinary net credit is seven. Upkeep has already been included. Reserve the one-off embarkation cost separately. Taxes, other expenses and one-off payments also affect the wallet; an expedition's runway depends on net losses after raising the army, not on the military-expense line alone.")
            replace(cues, "N06-06",
                    "整军、分兵还是改道，就算四件事：哪里补给，哪里损耗，锁定后先到哪，以及这段海陆行程要花多少钱。",
                    "For a direct march, split or detour, calculate four things: where supply recovers, where attrition applies, the next locked destination, and the cost of the land-and-sea journey.")
        for cue in cues:
            cue["narration_zh"] = cue["narration_zh"].replace("省份修正", "当地修正")
            cue["narration_zh"] = cue["narration_zh"].replace("地形加权路程", "路径权重")
            cue["narration_zh"] = cue["narration_zh"].replace("准备好的补员率", "有效补员率")
            cue["narration_zh"] = cue["narration_zh"].replace("只有长船的七成五折扣", "登船费用减少百分之七十五、支付原价四分之一")
            cue["narration_zh"] = cue["narration_zh"].replace("宽限过去以后", "宽限到期以后")
            cue["narration_zh"] = cue["narration_zh"].replace("维持费", "维护费").replace("钱包", "金钱余额")
            cue["subtitle_en"] = cue["subtitle_en"].replace("Low on Supplies", "Undersupplied").replace("province and commander modifiers", "local and commander modifiers").replace("province or commander modifiers", "local or commander modifiers").replace("Province and commander modifiers", "Local and commander modifiers").replace("wallet", "gold balance")
            cue["subtitle_en"] = cue["subtitle_en"].replace("army's supply limit", "army's supply capacity").replace("army supply limit", "army supply capacity").replace("army’s supply limit", "army’s supply capacity").replace("final supply limit", "final supply capacity").replace("army's actual supply limit", "army's actual supply capacity").replace("relevant supply limit after merging", "relevant supply capacity after merging")
            cue["subtitle_zh"] = cue["narration_zh"]
        path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    path = ROOT / "FORMULA-CARDS.source-a01.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    cards = {item["id"]: item for item in data["cards"]}
    cards["F09"]["note"] = "假设数据演算，合后上限至少80；正权重普通数值域"
    cards["F09"]["rows"][0] = "保留军：本例100普通兵，不计非兵士角色1"
    cards["F09"]["rows"][1] = "并入军：本例军团当前人数，把该角色1计入"
    cards["F06"]["note"] = "规则演算：两项计算人数恰好均为199，有效比例为5%与1%"
    cards["F11"]["rows"][1] = "倍率 max(1 − 75%, 0.1) = 0.25；基础每百人1金币"
    cards["F13"]["note"] = "军费只计一次；一次性费用与持续维护分别预算"
    if "F18" in cards:
        cards["F18"]["note"] = "适用常规经济结算；登船费用另按整金币取整"
    for item in data["cards"]:
        for key in ("title", "hero", "note"):
            item[key] = item[key].replace("省份", "当地").replace("地形权重", "路径权重").replace("地形加权路程", "路径权重").replace("维持费", "维护费").replace("钱包", "金钱余额")
        item["rows"] = [row.replace("地形加权路程", "路径权重").replace("地形权重", "路径权重").replace("维持费", "维护费").replace("钱包", "金钱余额") for row in item["rows"]]
    additions = [
        {"id": "F15", "title": "后勤专家：除以1.4，不是乘0.6", "hero": "−5 ÷ (1 + 40%) = −3.57142", "rows": ["假设总有效补给持续时间加成为+40%", "只调整负补给变化；正数基础恢复仍为+20", "更新日程与军队补给上限分别计算"], "note": "定点精度下的规则演算；进阶和其他加成须计入总有效值", "evidence": ["rules.supply.duration_named"]},
        {"id": "F16", "title": "征召兵补员速率：基础乘适用修正", "hero": "3% × (1 + 34%) = 4.02%", "rows": ["基础速率 × (1 + 适用修正之和)", "按军团满员人数计算，再受缺额限制", "最后舍去不足一名士兵的小数"], "note": "3%与+34%是假设算例；实际69/68军团当次有效速率为4.02%", "evidence": ["rules.reinforcement.rate_named", "actual.reinforcement.R0221"]},
        {"id": "F17", "title": "登船费：最终整金币取整", "hero": "100人：0.25 → 0金币；200人：0.5 → 1金币", "rows": ["假设只有长船−75%登船费用", "费率1 × 人数/100 × max(1 + 修正, 0.1)", "非负结果加0.5，再舍去小数"], "note": "规则演算；0.1是倍率下限，不是最低1金币收费", "evidence": ["rules.embark.formula"]},
        {"id": "F18", "title": "三种更新，各有自己的节奏", "hero": "补员：日历月初；补给：军队轮转；收支：领主轮转", "rows": ["常规领主收支按角色编号分30组，每天一组", "同一领主每30日结算一次本轮月度净额", "算例：收入10 − 含军费的完整支出3 = 净入账7", "月度金额不再除以30；金币保留小数精度"], "note": "适用常规经济结算；不把静态日程冒充新的实际付款镜头", "evidence": ["rules.maintenance.financial_cadence", "rules.maintenance.accounting"]},
    ]
    data["cards"].extend(item for item in additions if item["id"] not in cards)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
