"""ROOT-only single-stream immutable copy and formal INPUT/argv creation. No parser, SDK or game."""
from pathlib import Path
import argparse,hashlib,json,re,sys
sys.dont_write_bytecode=True
PY='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
RUN=Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-019').resolve()
HEAD='465595b67efa8f72dfc97bc0de218302c75e3bfd'
SCHEMA='lyd.r19.root-formal-capture-specification.attempt.v2'
WINDOWS={'B1-phase1':'B1','B2-representatives':'B2','B3-signed-precommit':'B3','B4-factory-result':'B4','B5-final-protection':'B5'}
KEYS={'schema','source_head','window','attempt_label','prepared','client_session','attached_binding','attach','checkpoint','G2','G3','metadata_result','compiled_result','native_clean_qualification','sdk_metadata_artifact','checkpoint_source_index','formal_author','materializer','original0240_control','native_title_reference_query','native_event_numeric_query','formal_callback_registry','future_preserved_checkpoint','input_output','materialize_argv_output','materializer_output','author_output'}
def need(ok,message):
 if not ok:raise ValueError(message)
def unique(raw):
 def pairs(rows):
  out={}
  for key,value in rows:need(key not in out,'duplicate JSON key '+key);out[key]=value
  return out
 return json.loads(raw.decode('utf-8-sig'),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def ref(path):
 p=Path(path).resolve();need(p.suffix.lower() in ('.json','.py'),'compact JSON/source reference only');need(0<p.stat().st_size<=8*1024*1024,'bounded8MiB JSON/source');raw=p.read_bytes()
 return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(row):
 need(type(row)is dict and set(row)=={'path','bytes','sha256'} and type(row['bytes'])is int and 0<row['bytes']<=8*1024*1024 and type(row['sha256'])is str and re.fullmatch('[0-9a-f]{64}',row['sha256']),'exact positive actual ref3')
 need(ref(row['path'])==row,'frozen JSON/source changed');return unique(Path(row['path']).read_bytes())
def put(path,obj):
 with Path(path).open('x',encoding='utf-8',newline='\n')as f:json.dump(obj,f,indent=2,ensure_ascii=False);f.write('\n')
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--inputs',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--root-create',action='store_true',required=True);a=p.parse_args()
 specification=ref(a.inputs);need(specification['sha256']==a.sha256,'explicit frozen capture specification SHA');d=read(specification)
 need(type(d)is dict and set(d)==KEYS and d['schema']==SCHEMA and d['source_head']==HEAD,'closed actual R19 formal capture specification')
 need(type(d['window'])is str and d['window'] in WINDOWS,'actual B1/B2/B3/B4/B5 window');need(type(d['attempt_label'])is str and re.fullmatch(r'r[1-9][0-9]*-(pending|signed)',d['attempt_label']),'strict positive-round pending/signed ROOT attempt label required');slug=WINDOWS[d['window']]+'-'+d['attempt_label']
 prepared,session,binding=[read(d[key]) for key in ('prepared','client_session','attached_binding')]
 need(prepared['source_revision']==session['source_revision']==HEAD,'current source binding')
 need(session['client_session_id']==binding['client_session_id'] and session['profile_sha256']==binding['profile_sha256']==prepared['profile']['sha256'],'actual Client/profile binding')
 need(session['target']['pid']==prepared['root_actual_live_binding']['process_id'] and session['target']['process_create_time']==prepared['root_actual_live_binding']['process_create_time'],'current ROOT identity tuple from JSON')
 need(session['automatic_attach'] is False and session['automatic_retry'] is False,'existing non-retrying Client required')
 receipts={}
 for key in ('attach','checkpoint','G2','G3'):
  pair=d[key];need(type(pair)is dict and set(pair)=={'native_receipt','sdk_result'},'original SDK/native pair '+key)
  native=read(pair['native_receipt']);read(pair['sdk_result']);receipts[key]=native
  need(native['session_id']==binding['native_session_id'] and native['profile_sha256']==prepared['profile']['sha256'],'same native session/profile '+key)
  need(Path(native['receipt_path']).resolve()==Path(pair['native_receipt']['path']).resolve(),'original native receipt_path '+key)
 metadata=read(d['metadata_result']);need(metadata['head']==HEAD and metadata['native_clean_qualification']==d['native_clean_qualification'] and metadata['metadata']==d['sdk_metadata_artifact'] and metadata['compiled_verification']==d['compiled_result'],'actual ROOT metadata tuple')
 index=read(d['checkpoint_source_index']);need(d['checkpoint_source_index']['sha256']=='8b0fd3e326edf8696100e1605ee2f8ba1e5523fb2c2ad76db8cdfee1755eced8' and index['formal_author']==d['formal_author'] and index['formal_materializer']==d['materializer'],'sealed R19 checkpoint source002')
 need(ref(d['formal_author']['path'])==d['formal_author'] and d['formal_author']['sha256']=='de3df42e58918489a4c72fb795600ffb1e041225cae3c6c1b542d2221f5ad17e','exact current formal author')
 need(ref(d['materializer']['path'])==d['materializer'] and d['materializer']['sha256']=='3e9bd5bc47166d4106612d36c0c7372d7d8040b592e0b89d56b732552ee042b1','exact current formal materializer')
 control=read(d['original0240_control']);need(control['schema']=='lyd.r19.original0240-baseline-control.v1','actual completed baseline control required')
 for key in ('native_title_reference_query','native_event_numeric_query','formal_callback_registry'):
  if d[key] is not None:read(d[key])
 need(d['formal_callback_registry'] is None or d['window'] in ('B3-signed-precommit','B4-factory-result','B5-final-protection'),'formal registry only supported explicit windows')
 native=receipts['checkpoint'];saved=native['result']['checkpoint'];expected=d['future_preserved_checkpoint']
 need(type(expected)is dict and set(expected)=={'path','bytes','sha256'} and type(expected['bytes'])is int and expected['bytes']>0 and type(expected['sha256'])is str and re.fullmatch('[0-9a-f]{64}',expected['sha256']),'actual saved descriptor and future immutable path required')
 source=Path(saved['path']).resolve();target=Path(expected['path']).resolve()
 need(source==RUN/'userdir/save games/xar_checkpoint.ck3' and target==RUN/'checkpoints'/(d['window']+'-'+d['attempt_label'])/'checkpoint.ck3','exact current saved source/window immutable destination')
 need(native['status']=='native_gameplay_postcondition_verified' and saved['status']=='saved' and saved['date_raw']==native['snapshot_after']['date_raw'] and saved['size']==expected['bytes'] and saved['sha256']==expected['sha256'],'original actual saved descriptor')
 output=Path(d['input_output']).resolve();argv_output=Path(d['materialize_argv_output']).resolve();mat_output=Path(d['materializer_output']).resolve();author_output=Path(d['author_output']).resolve()
 need(output==RUN/('ROOT-'+slug+'-MATERIALIZER-INPUTS.actual.json') and argv_output==RUN/('ROOT-'+slug+'-MATERIALIZE-ARGV.actual.json') and mat_output==RUN/(slug+'-author-input-001') and author_output==RUN/(slug+'-author-001'),'fixed distinct per-window ROOT output paths')
 locations=[target.parent,output,argv_output,mat_output,author_output];need(all(path.is_relative_to(RUN) and not path.exists() for path in locations),'all new copy/input/materializer/author targets must be fresh inside R19 run')
 need(source.stat().st_size==saved['size'],'actual saved source size before copy')
 target.parent.mkdir(parents=True,exist_ok=False);digest=hashlib.sha256();copied=0
 with source.open('rb')as reader,target.open('xb')as writer:
  for chunk in iter(lambda:reader.read(1024*1024),b''):
   writer.write(chunk);digest.update(chunk);copied+=len(chunk)
 preserved={'path':target.as_posix(),'bytes':copied,'sha256':digest.hexdigest()}
 need(preserved==expected and target.stat().st_size==saved['size'] and source.stat().st_size==saved['size'],'actual one-stream immutable copy must equal original SDK bytes/SHA')
 fields={'schema':'lyd.r19.actual-checkpoint-materializer-input.v1','prepared':d['prepared'],'client_session':d['client_session'],'attach':d['attach'],'metadata_result':d['metadata_result'],'compiled_result':d['compiled_result'],'native_clean_qualification':d['native_clean_qualification'],'sdk_metadata_artifact':d['sdk_metadata_artifact'],'checkpoint':d['checkpoint'],'G2':d['G2'],'G3':d['G3'],'preserved_checkpoint':preserved,'window':d['window'],'author_output':author_output.as_posix(),'original0240_control':d['original0240_control'],'native_title_reference_query':d['native_title_reference_query'],'native_event_numeric_query':d['native_event_numeric_query'],'formal_callback_registry':d['formal_callback_registry']}
 put(output,fields)
 argv=[PY,'-B','-X','utf8',d['materializer']['path'],'--inputs',output.as_posix(),'--inputs-sha256',ref(output)['sha256'],'--output',mat_output.as_posix()]
 put(argv_output,{'argv':argv,'executed':False,'future_author_body_scans_requested':1,'formal_author':d['formal_author'],'window':d['window']})
 put(target.parent/'CAPTURE.actual.json',{'schema':'lyd.r19.root-preserved-formal-capture.v1','window':d['window'],'attempt_label':d['attempt_label'],'specification':specification,'source_saved_descriptor':saved,'actual_immutable_copy':preserved,'inputs':ref(output),'materializer_argv':ref(argv_output),'original0240_control':d['original0240_control'],'exact_copy_stream_passes':1,'save_parser_scans':0,'materializer_executed':False,'author_executed':False,'SDK_game_calls':0,'future_formal_acceptance':None,'future_new_T':None,'wholemod_PASS':None})
 print(json.dumps({'inputs':ref(output),'preserved_checkpoint':preserved,'argv_file':ref(argv_output),'materializer_executed':False,'author_executed':False},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
