"""ROOT file-only reusable B1-B5 capture specification/argv author. Never copies or parses a save."""
from pathlib import Path
import argparse,hashlib,json,re,sys
sys.dont_write_bytecode=True
PY='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004');RUN=BASE/'live-attempt-019';HERE=Path(__file__).parent
CP=BASE/'r19-checkpoint-author-sourceonly-20261007-002'
WINDOWS={'B1-phase1':'B1','B2-representatives':'B2','B3-signed-precommit':'B3','B4-factory-result':'B4','B5-final-protection':'B5'}
def need(ok,msg):
 if not ok:raise ValueError(msg)
def ref(path):
 path=Path(path).resolve();need(path.suffix.lower() in ('.json','.py') and 0<path.stat().st_size<=8*1024*1024,'compact actual JSON/source only');raw=path.read_bytes();return {'path':path.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(path):return json.loads(Path(path).read_bytes())
def put(path,obj):
 with Path(path).open('x',encoding='utf-8',newline='\n')as f:json.dump(obj,f,indent=2,ensure_ascii=False);f.write('\n')
def pair(stem):
 need(type(stem)is str and re.fullmatch(r'[0-9]{4}-r19-[0-9]{3}-[A-Za-z0-9_-]+',stem),'actual R19 Client stem without path')
 response=read(RUN/'mcp-client-001'/(stem+'.response.json'));need(response['status']=='MCP_RESULT_RECORDED' and len(response['native_receipts'])==1,'one completed actual native receipt')
 row=response['native_receipts'][0];original=Path(row['path']).resolve();copy=(RUN/'mcp-client-001'/row['copy']).resolve()
 need(original.is_relative_to(RUN/'native-evidence') and copy.is_relative_to(RUN/'mcp-client-001'),'actual same-run original native receipt and Client copy')
 need(ref(original)['sha256']==ref(copy)['sha256']==row['sha256'],'original native and Client copy exact SHA')
 native=read(original);need(Path(native['receipt_path']).resolve()==original,'original native receipt path')
 sdk=(RUN/'mcp-client-001'/response['sdk_result']).resolve();need(sdk.is_relative_to(RUN/'mcp-client-001') and ref(sdk)['sha256']==response['sdk_result_sha256'],'original SDK response binding')
 return {'native_receipt':ref(original),'sdk_result':ref(sdk)}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--window',choices=list(WINDOWS),required=True)
 for key in ('checkpoint-stem','g2-stem','g3-stem'):p.add_argument('--'+key,required=True)
 p.add_argument('--baseline-capture-specification',type=Path,required=True);p.add_argument('--baseline-capture-specification-sha256',required=True);p.add_argument('--output-prefix',type=Path,required=True);p.add_argument('--attempt-label',required=True)
 for key in ('native-title-reference-query','native-event-numeric-query','formal-callback-registry'):
  p.add_argument('--'+key,type=Path);p.add_argument('--'+key+'-sha256')
 a=p.parse_args();need(re.fullmatch(r'r[1-9][0-9]*-(pending|signed)',a.attempt_label),'strict positive-round pending/signed ROOT attempt label required');slug=WINDOWS[a.window]+'-'+a.attempt_label
 prefix=a.output_prefix.resolve();need(prefix.is_relative_to(RUN) and prefix.parent.is_dir() and not prefix.exists(),'fresh ROOT prefix inside actual run')
 specification_path=Path(str(prefix)+'.SPEC.actual.json');argv_path=Path(str(prefix)+'.ARGV.unexecuted.json');need(not specification_path.exists() and not argv_path.exists(),'fresh specification and argv')
 base_ref=ref(a.baseline_capture_specification);need(base_ref['sha256']==a.baseline_capture_specification_sha256 and Path(base_ref['path']).is_relative_to(RUN),'explicit actual same-run R19 baseline capture specification');base=read(a.baseline_capture_specification);need(base['schema']=='lyd.r19.root-baseline-capture-specification.v1' and base['source_head']=='465595b67efa8f72dfc97bc0de218302c75e3bfd','actual R19 baseline runtime tuple');index=read(CP/'INDEX.json')
 checkpoint,g2,g3=[pair(stem) for stem in (a.checkpoint_stem,a.g2_stem,a.g3_stem)]
 native=read(checkpoint['native_receipt']['path']);saved=native['result']['checkpoint'];need(saved['status']=='saved' and native['status']=='native_gameplay_postcondition_verified','actual successful checkpoint required')
 optional={}
 for key in ('native_title_reference_query','native_event_numeric_query','formal_callback_registry'):
  path=getattr(a,key);sha=getattr(a,key+'_sha256');need((path is None)==(sha is None),'optional artifact requires path and exact SHA together: '+key)
  if path is None:optional[key]=None
  else:
   stamp=ref(path);need(stamp['sha256']==sha and Path(stamp['path']).is_relative_to(RUN),'actual same-run optional artifact SHA '+key);read(path);optional[key]=stamp
 need(optional['formal_callback_registry'] is None or a.window in ('B3-signed-precommit','B4-factory-result','B5-final-protection'),'callback registry limited to supported windows')
 specification={'schema':'lyd.r19.root-formal-capture-specification.attempt.v2','source_head':base['source_head'],'window':a.window,'attempt_label':a.attempt_label,**{key:base[key] for key in ('prepared','client_session','attached_binding','attach','metadata_result','compiled_result','native_clean_qualification','sdk_metadata_artifact')},'checkpoint':checkpoint,'G2':g2,'G3':g3,'checkpoint_source_index':ref(CP/'INDEX.json'),'formal_author':index['formal_author'],'materializer':index['formal_materializer'],'original0240_control':ref(RUN/'ORIGINAL0240-CONTROL.actual.json'),**optional,'future_preserved_checkpoint':{'path':(RUN/'checkpoints'/(a.window+'-'+a.attempt_label)/'checkpoint.ck3').as_posix(),'bytes':saved['size'],'sha256':saved['sha256']},'input_output':(RUN/('ROOT-'+slug+'-MATERIALIZER-INPUTS.actual.json')).as_posix(),'materialize_argv_output':(RUN/('ROOT-'+slug+'-MATERIALIZE-ARGV.actual.json')).as_posix(),'materializer_output':(RUN/(slug+'-author-input-001')).as_posix(),'author_output':(RUN/(slug+'-author-001')).as_posix()}
 helper=HERE/'capture_formal_materializer_inputs_root_only.py';need(ref(helper)['sha256']=='22f113872b1983eac1ec0e5a8deeebe09ec3bcc5d8c7292d012714e1b2a424a4','sealed generic capture helper')
 put(specification_path,specification);put(argv_path,{'argv':[PY,'-B','-X','utf8',helper.as_posix(),'--inputs',specification_path.as_posix(),'--sha256',ref(specification_path)['sha256'],'--root-create'],'executed':False,'future_immutable_copy':None,'future_author_result':None,'future_formal_PASS':None})
 print(json.dumps({'specification':ref(specification_path),'ROOT_capture_argv':ref(argv_path),'body_reads':0,'actual_copy':False,'materializer_executed':False,'author_executed':False},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
