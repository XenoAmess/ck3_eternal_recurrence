from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,os
B=Path('C:/workspace/ck3_lyd_runtime_20261004');D=B/'r13-root-actual-native-build-20261006-001'
O=B/'post-r12-readonly-native-build001-addendum-20261006-002'
cache={};objects={};orig=[]
def sha(v):return hashlib.sha256(v).hexdigest()
def read(p):
    p=Path(p);assert p.suffix.lower() not in {'.dll','.exe','.ck3','.tar'}
    key=os.path.normcase(os.path.abspath(str(p)))
    if key not in cache:
        a=p.stat();cache[key]=p.read_bytes();z=p.stat();assert (a.st_size,a.st_mtime_ns)==(z.st_size,z.st_mtime_ns)
    return cache[key]
def new(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(v)
def dump(name,v):new(O/name,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
def keep(p,role,expected=None,n=None):
    p=Path(p);v=read(p);h=sha(v);assert expected is None or h==expected;assert n is None or len(v)==n
    rel='archive/'+h+(p.suffix.lower() or '.bin')+'.gz'
    if rel not in objects:
        z=gzip.compress(v,compresslevel=9,mtime=0);assert gzip.decompress(z)==v
        new(O/rel,z);objects[rel]={'path':rel,'bytes':len(z),'sha256':sha(z)}
    r={'path':p.as_posix(),'bytes':len(v),'sha256':h}
    orig.append({'role':role,'original':r,'stored_mode':'gzip-lossless','stored':objects[rel],
        'decoded_bytes':len(v),'decoded_sha256':h});return r
assert not O.exists();O.mkdir();(O/'archive').mkdir()
prev=keep(B/'post-r12-readonly-source-integration-draft-20261006-001/INDEX.json','immutable predecessor INDEX only',
    '508d1c09a16ee319005b40423911ed536366d9d2983c5761ecf2c21ce0a9988f')
ir=keep(D/'INDEX.json','actual nativebuild001 frozen INDEX');idx=json.loads(read(D/'INDEX.json'))
for row in idx['files']:keep(row['path'],'nativebuild001 exact raw output/source-state/command original',row['sha256'],row['bytes'])
r=json.loads(read(D/'RESULT.json'));assert sha(read(D/'RESULT.json'))=='75819cf34f9dd2fc350e90266f66623ca7f7f4c2c2f345685235ab324cc15e02'
cf=json.loads(read(D/'COMPILE-LINK-FACTS.json'));refs={}
for name,ref in [('canonical_producer',cf['canonical_producer']),('actual_cmake_cache',cf['actual_cmake_cache'])]+list(cf['actual_Defender_refs'].items()):
    refs[name]=keep(ref['path'],'actual original producer/cache/Defender '+name,ref['sha256'],ref['bytes'])
producer=json.loads(read(cf['canonical_producer']['path']))
assert producer['configured'] is True and producer['built'] is True and producer['build_succeeded'] is True
assert producer['status']=='built_defender_registration_failed' and cf['actual_flags']=={}
assert r['actual_focused_tests']==[] and r['actual_focused_tests_pass'] is False
assert r['whole_native_raw_before_after_unchanged'] is True and len(r['targets'])==4
cache_raw=read(cf['actual_cmake_cache']['path'])
report={'schema':'lyd.post-r12.nativebuild001-facts-addendum.v1','created_at_utc':datetime.now(timezone.utc).isoformat(),
    'status':'PRODUCER_BUILD_SUCCEEDED_ENVIRONMENT_RED_WRAPPER_CACHE_VERIFIER_ERROR_QUALIFICATION_PENDING',
    'predecessor_INDEX':prev,'original_nativebuild001_INDEX':ir,'original_RESULT_sha256':sha(read(D/'RESULT.json')),
    'actual_dirty_source_HEAD_anchor':r['actual_HEAD'],'actual_source_kind':r['source_kind'],
    'native_source_before_after_identical':True,'canonical_producer_configured':True,'canonical_producer_built':True,
    'canonical_producer_build_succeeded':True,'producer_refs':refs,
    'four_product_descriptors_external_not_read':r['targets'],
    'outer_original_exit_code':1,'Defender_settings_status':'settings_failed','Defender_WMI_error':cf['actual_Defender_registration']['error'],
    'original_wrapper_actual_compilation_pass':r['actual_compilation_pass'],
    'original_wrapper_flags':cf['actual_flags'],'original_wrapper_exact_flags_verified':False,
    'wrapper_failure_classification':'ROOT-observed cache regex omitted CRLF normalization; author verifier error, not compiler failure',
    'actual_cache_CRLF_line_count':cache_raw.count(b'\r\n'),'actual_cache_LF_count':cache_raw.count(b'\n'),
    'corrected_flag_qualification_result':None,'native_first_two_test_results':None,
    'original_two_tests_execution_count':0,'actual_rebuild_by_author':False,'AV_retry_or_configuration_change_by_author':False,
    'clean_HEAD_artifact_credit':False,'new_native_private23_runtime':False,'formal_I3b_C3_I4_credit':None,
    'wholephase_GREEN':False,'author_main_Git_game_pipe_collector_calls':0}
dump('REPORT.json',report)
new(O/'REPORT.zh.md',('''# nativebuild001 实际结果勘误准备（新资格验证待补）

原producer配置、构建与build_succeeded均true，四份DLL/EXE产品有生产者bytes/SHA描述；native源前后精确一致。这是dirty worktree构建，不是clean HEAD632产物。本作者没有读取或复制二进制产品。

原外层exit1保留，Defender WMI settings_failed为独立环境RED。包装器原actual_compilation_pass=false、actual_flags={}和exact flags=false保留；ROOT已定位其cache行regex未处理CRLF，属于作者验证器错误，不能据此称编译失败。新flag资格验证尚未收到实际回执。

原两项native测试因为包装器资格门失败而未执行，原actual_focused_tests=[]/pass=false不改。ROOT安排现有产品的两项首次实际测试与窄cache补充，不重建、不做AV重试；新结果暂NULL/PENDING。旧SOURCE草稿、原001失败及全部原件保留。Python17项既有通过不外推为新native实机/wholephase GREEN，I3b/C3/I4正式仍未执行。
''').encode('utf-8'))
keep(Path(__file__),'external-only raw evidence append author')
dump('ORIGIN-MAP.json',{'schema':'lyd.lossless-origin-map.v1','origins':orig,'original_count':len(orig),'unique_stored_count':len(objects)})
dump('ROOT-IMPORT-PLAN.SKELETON.json',{'ROOT_only':True,'apply_allowed':False,'old_reports_overwrite':False,
    'target_relative':'docs/li-yu-dao/acceptance/2026-10-06-post-r12-readonly-source-l0/nativebuild001',
    'native_qualification_and_two_first_test_receipts':None})
rows=[]
for p in sorted(O.rglob('*')):
    if p.is_file():v=read(p);rows.append({'path':p.relative_to(O).as_posix(),'bytes':len(v),'sha256':sha(v)})
dump('INDEX.json',{'self_excluded':True,'status':report['status'],'files':rows})
v=read(O/'INDEX.json');print(json.dumps({'OUT':O.as_posix(),'INDEX_bytes':len(v),'INDEX_sha256':sha(v),
    'payload_files':len(rows),'producer_build_succeeded':True,'qualification_pending':True,'test_count_executed_in_original':0,
    'main_writes':0,'build_or_tests_or_AV_actions_by_author':0},ensure_ascii=True))
