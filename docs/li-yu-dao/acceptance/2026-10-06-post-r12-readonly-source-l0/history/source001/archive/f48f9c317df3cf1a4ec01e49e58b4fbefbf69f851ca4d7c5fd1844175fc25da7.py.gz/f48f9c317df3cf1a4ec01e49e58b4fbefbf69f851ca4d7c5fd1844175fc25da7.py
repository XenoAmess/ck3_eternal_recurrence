"""External-only integration receipts/source SHA+shared diff; do not rerun tests/build or write main."""
from pathlib import Path
from datetime import datetime,timezone
import difflib,gzip,hashlib,json,os
B=Path('C:/workspace/ck3_lyd_runtime_20261004');REPO=Path('C:/workspace/ck3_eternal_recurrence')
O=B/'post-r12-readonly-source-integration-draft-20261006-001'
N=B/'root-readers-native-exact-application-after-r12-20261006-001'
P=B/'root-python-readonly-exact-application-after-r12-20261006-001'
T=B/'r13-root-python-focused-tests-20261006-001'
cache={};orig=[];objects={}
def ext(p):
    s=os.path.abspath(str(p));return '\\\\?\\'+s if os.name=='nt' and not s.startswith('\\\\?\\') else s
def sha(v):return hashlib.sha256(v).hexdigest()
def read(p):
    k=os.path.normcase(os.path.abspath(str(p)))
    if k not in cache:
        before=os.stat(ext(p))
        with open(ext(p),'rb') as f:cache[k]=f.read()
        after=os.stat(ext(p));assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
    return cache[k]
def load(p):return json.loads(read(p))
def new(p,v):
    Path(ext(p.parent)).mkdir(parents=True,exist_ok=True)
    with open(ext(p),'xb') as f:f.write(v)
def dump(name,v):new(O/name,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
def keep(p,role,expected=None):
    p=Path(p);v=read(p);h=sha(v);assert expected is None or h==expected,(str(p),h)
    rel='archive/'+h+(p.suffix.lower() or '.bin')+'.gz'
    if rel not in objects:
        z=gzip.compress(v,compresslevel=9,mtime=0);assert gzip.decompress(z)==v
        new(O/rel,z);objects[rel]={'path':rel,'bytes':len(z),'sha256':sha(z)}
    rr={'path':p.as_posix(),'bytes':len(v),'sha256':h}
    orig.append({'role':role,'original':rr,'stored_mode':'gzip-lossless','stored':objects[rel],'decoded_bytes':len(v),'decoded_sha256':h})
    return rr
assert not O.exists();Path(ext(O)).mkdir();Path(ext(O/'archive')).mkdir()
nr=keep(N/'APPLIED.json','actual ROOT43 source application receipt');na=load(N/'APPLIED.json');assert len(na['files'])==43
pr=keep(P/'APPLIED.json','actual ROOT5 Python readonly application receipt','75a7bff32bf0c690d5a59ccd462d47e63bcd23fe862a77a25ef1281dfa7d533a')
pa=load(P/'APPLIED.json');assert len(pa['files'])==5
ni=keep(N/'INPUTS.json','ROOT actual before/after target descriptors and frozen source manifests');nm=load(N/'INPUTS.json')
pi=keep(P/'INPUTS.json','ROOT actual Python source manifest and boundary descriptor');pm=load(P/'INPUTS.json')
manifestrefs=[]
for ir in [nm['native_manifest'],nm['readers_manifest'],pm['manifest'],pm['index']]:
    r=keep(ir['path'],'immutable source application target manifest/index',ir['sha256']);assert r['bytes']==ir['bytes'];manifestrefs.append(r)
for d in [N,P]:
    for p in sorted(d.iterdir()):
        if p.is_file() and p.name not in {'APPLIED.json','INPUTS.json'}:keep(p,'actual ROOT source application command/bus-before receipt '+d.name)
tr=keep(T/'RESULT.json','actual ROOT 17 focused test invocation result; inherited r10 schema retained');tv=load(T/'RESULT.json');assert tv['exit_code']==0
for p in sorted(T.iterdir()):
    if p.is_file() and p.name!='RESULT.json':keep(p,'actual ROOT 17 tests argv/stdout/stderr')
argv=keep(Path(tv['argv_source']),'actual structured test argv source',tv['argv_source_sha256'])
assert sha(read(T/'stdout.txt'))==tv['stdout_sha256'] and sha(read(T/'stderr.txt'))==tv['stderr_sha256']
assert b'Ran 17 tests' in read(T/'stderr.txt') and read(T/'stderr.txt').rstrip().endswith(b'OK')
imports=[]
for d in ['r11-root-global-import-receipt-after-r12-20261006-001','r12-root-global-import-receipt-20261006-001']:
    r=keep(B/d/'RECEIPT.json','actual permanent report import receipt');v=load(B/d/'RECEIPT.json')
    assert v['status']=='ACTUAL_ROOT_APPEND_IMPORT_COMPLETE_NOT_GREEN' and v['objects_lossless_decode_verified'] is True
    imports.append({'receipt':r,'actual_main_report_INDEX':v['INDEX'],'candidate_INDEX':v['candidate_INDEX']})
sources=[];diffs=[];apply_mismatch=[]
for kind,d,receipt in [('native20_readers23',N,na),('python5',P,pa)]:
    for row in receipt['files']:
        q=Path(row['path']);target=q if q.is_absolute() else REPO/q
        assert os.path.commonpath([os.path.normcase(os.path.abspath(target)),os.path.normcase(os.path.abspath(REPO))])==os.path.normcase(os.path.abspath(REPO))
        rel=target.relative_to(REPO).as_posix();after=read(target)
        actual={'path':target.as_posix(),'bytes':len(after),'sha256':sha(after)}
        same=(len(after),sha(after))==(row['bytes'],row['sha256'])
        if not same:apply_mismatch.append({'path':rel,'application_receipt':row,'current_source':actual,'classification':'ROOT post-application source delta; not runtime credit'})
        before=d/'before'/rel;bf=None;diffref=None
        if before.is_file():
            bv=read(before);bf={'path':before.as_posix(),'bytes':len(bv),'sha256':sha(bv)}
            diff=b''.join(difflib.diff_bytes(difflib.unified_diff,bv.splitlines(keepends=True),after.splitlines(keepends=True),
                fromfile=('receipt-before/'+rel).encode('utf-8'),tofile=('ROOT-current/'+rel).encode('utf-8'),n=3))
            dp=O/'source-diffs'/((sha(rel.encode('utf-8'))[:16])+'.diff');new(dp,diff)
            diffref=keep(dp,'exact byte-line unified diff for shared repository source; no full baseline copy')
            # Plain diff contains only new generated artifact; permanent copy uses its lossless archive representation.
            diffs.append({'repository_path':rel,'diff_original':diffref,'before':bf,'after':actual})
        sources.append({'source_group':kind,'repository_path':rel,'ROOT_applied_descriptor':row,'current_source_ref':actual,
            'matches_application_receipt_as_of_author_read':same,'before_backup':bf,'shared_source_diff':diffref,
            'large_before_after_bodies_copied':False,'new_file_or_before_backup_missing':bf is None})
assert len(sources)==48
dump('SOURCE-48-SHA-PROOF.json',{'actual_repository_source_count':48,'source_body_copy_count':0,'Git_calls':0,
    'rows':sources,'shared_diff_count':len(diffs),'ROOT_post_application_deltas':apply_mismatch})
report={'schema':'lyd.post-r12.readonly-source-integration-draft.v1','status':'SOURCE_APPLIED_PYTHON17_PASS_NATIVE_BUILD_AND_TEST_PENDING',
    'created_at_utc':datetime.now(timezone.utc).isoformat(),'base_applied_source_head':nm['head'],
    'actual_R12_closed_boundary':nm['closed_boundary'],'permanent_R11_R12_report_imports':imports,
    'ROOT_actual_native20_reader23_application':nr,'ROOT_actual_Python5_application':pr,'source_manifest_refs':manifestrefs,
    'actual48_source_SHA_count':48,'source_shared_diff_count':len(diffs),'source_CURRENT_vs_APPLIED_delta_count':len(apply_mismatch),
    'default_SDK_tools':21,'explicit_private_tools_source_contract':23,'actual_private23_runtime_credit':False,
    'Python_focused_tests':{'count':17,'actual_exit_code':0,'RESULT':tr,'argv_source':argv,'actual_runner_schema':tv['schema']},
    'native_build_result':None,'native_compile_result':None,'native_two_test_results':None,'native_environment_RED':None,
    'new_I3b_C3_I4_formal_runtime':None,'whole_phase1_GREEN':False,'actual_new_game_run':False,
    'old_R11_R12_runtime_source_632_rewritten_as_current_source':False,
    'existing_reports_archive_recompression_or_tests_repeated':False,'author_Git_main_codegen_game_collector_calls':0}
dump('REPORT.json',report)
new(O/'REPORT.zh.md',('''# R12闭合后只读接口与checkpoint reader源码整合（native验证待补）

ROOT已实际永久导入R11/R12验收报告；这些历史实机仍绑定632冻结源码，不能给本轮新增代码授实机信用。R11正式JOIN与循环、R12最终冷载58项的既有事实保持。

ROOT在R12真实闭合后应用43份目标（20 native、23 reader）及5份Python。48个仓库源路径有实际APPLIED descriptor、当前字节SHA与已有before backup证明；共享文件导出最小字节diff，新增文件仅保留仓库路径/hash引用，不复制完整巨型before/after树。当前源若与应用时回执不同，明确列为ROOT后续source delta，不改写原应用事实。

正式默认工具清单仍21；显式private23为源码合同与17项Python测试所验证的接口，不等于已经在新DLL实机使用。ROOT focused tests实际exit0、Ran17 OK；argv/stdout/stderr/result原字节完整保留，真实runner沿用r10 schema不更名。

native build/compile以及ROOT两项新native测试尚未收到实际结果，保持NULL/PENDING；环境失败与源码失败后续按原回执分列。I3b/C3/I4正式业务、新private runtime与整个第一阶段仍未通过。此草稿不重跑测试/构建、codegen、旧compression或实机，不写main/Git。收到新native实际收据后仅新增revision，旧草稿不覆盖。
''').encode('utf-8'))
keep(Path(__file__),'external-only report source and shared diff author')
dump('ORIGIN-MAP.json',{'schema':'lyd.lossless-origin-map.v1','origins':orig,'original_count':len(orig),'unique_stored_count':len(objects)})
rows=[]
for p in sorted(Path(ext(O)).rglob('*')):
    if p.is_file() and 'source-diffs' not in p.parts:
        v=read(p);rows.append({'path':p.relative_to(Path(ext(O))).as_posix(),'bytes':len(v),'sha256':sha(v)})
dump('ROOT-IMPORT-PLAN.SKELETON.json',{'ROOT_only':True,'apply_allowed':False,
    'target_relative':'docs/li-yu-dao/acceptance/2026-10-06-post-r12-readonly-source-l0',
    'source_package':O.as_posix(),'old_report_overwrite':False,'native_results_and_final_addendum_required':None,
    'copy_files':rows,'shared_source_diffs_stored_lossless_only':True})
v=read(O/'ROOT-IMPORT-PLAN.SKELETON.json');rows.append({'path':'ROOT-IMPORT-PLAN.SKELETON.json','bytes':len(v),'sha256':sha(v)})
dump('INDEX.json',{'self_excluded':True,'status':report['status'],'files':rows,'source48_ref_body_copies':0})
v=read(O/'INDEX.json')
print(json.dumps({'OUT':O.as_posix(),'INDEX_bytes':len(v),'INDEX_sha256':sha(v),'source48_proof_count':48,
    'shared_diff_count':len(diffs),'source_current_delta_count':len(apply_mismatch),'payload_files':len(rows),
    'native_build_credit':None,'checks_rerun':0,'main_writes':0},ensure_ascii=True))
