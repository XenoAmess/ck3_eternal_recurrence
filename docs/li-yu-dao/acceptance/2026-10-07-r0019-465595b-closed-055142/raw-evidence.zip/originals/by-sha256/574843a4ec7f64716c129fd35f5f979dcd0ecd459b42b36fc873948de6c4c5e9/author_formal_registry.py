"""Author existing formal registry JSON from ROOT's actual immutable receipts.

No SDK/game/proc calls, save reads, receipt copies, qualification credit, or
source predicate changes. The checkpoint author retains the final proof gates.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re
import sys
sys.dont_write_bytecode=True
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve()

def need(ok,message):
 if not ok:raise ValueError(message)
def ref(path):
 p=Path(path).resolve();raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def checked(path,sha):
 item=ref(path);need(type(sha)is str and item['sha256']==sha.lower(),'Explicit actual input SHA differs: '+str(path));return json.loads(Path(path).read_bytes()),item
def read_ref(item):
 need(type(item)is dict and set(item)=={'path','bytes','sha256'} and ref(item['path'])==item,'Actual ref3 bytes differ');return json.loads(Path(item['path']).read_bytes())
def write(path,value):
 with path.open('x',encoding='utf-8',newline='\n')as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def leaf_module(path,sha):
 need(ref(path)['sha256']==sha.lower(),'Frozen qualification leaf SHA differs')
 sys.path.insert(0,str(path.resolve().parent))
 spec=importlib.util.spec_from_file_location('bound_formal_registry_leaf',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 return module

def sdk_pair(sdk_path,leaf,provenance,official_ref=None):
 sdk=json.loads(Path(sdk_path).read_bytes());native=sdk['structuredContent']
 need(type(native)is dict and type(native.get('receipt_path'))is str,'Existing original receipt_path required')
 original=Path(native['receipt_path']).resolve()
 pair={'native_receipt':ref(original),'sdk_result':ref(sdk_path)}
 actual=json.loads(original.read_bytes())
 if official_ref is not None:
  read_ref(official_ref)
  need(pair['native_receipt']['bytes']==official_ref['bytes'] and pair['native_receipt']['sha256']==official_ref['sha256'],'Official Client copy differs from original receipt bytes')
 authenticated,_=leaf.query_pair(pair,provenance)
 need(authenticated==actual==native,'Actual original/SDK native differs')
 return pair,actual

def callback_output(path,sha,expected_event,leaf,provenance):
 result,result_ref=checked(path,sha)
 need(result['status']=='EXPLICIT_STEP_ACTUALLY_COMPLETED' and type(result['calls'])is list and len(result['calls'])==2,'Actual completed guarded event query/select output required')
 pairs=[];natives=[]
 for row in result['calls']:
  need(row['exit_code']==0 and row['dispatch']['status']=='MCP_RESULT_RECORDED' and not row['dispatch'].get('is_error'),'Actual guarded callback SDK success required')
  sdk_ref=row['SDK_wrapper'];read_ref(sdk_ref)
  pair,native=sdk_pair(sdk_ref['path'],leaf,provenance,row['original_native_receipt'])
  pairs.append(pair);natives.append(native)
 query,selection=natives
 need(query['status']=='native_event_query_verified' and query['result']['current_event_window_context']['event_definition_key']==expected_event,'Explicit callback query event differs')
 need(selection['status']=='native_gameplay_postcondition_verified' and selection['result']['step']=='select-event-option-1','Existing formal affirmative source option0 selection required')
 return {'query':pairs[0],'select':pairs[1]},result_ref

def certificate(path,sha,leaf,expected_window):
 data,item=checked(path,sha)
 need(data['schema']==leaf.OUTPUT_SCHEMA and data['window']==expected_window and data['qualification_pass']is True,'Actual independently PASS prior certificate required')
 return data,item

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--bindings',type=Path,required=True);p.add_argument('--bindings-sha256',required=True)
 p.add_argument('--leaf',type=Path,required=True);p.add_argument('--leaf-sha256',required=True)
 p.add_argument('--expected-head',required=True);p.add_argument('--output',type=Path,required=True)
 sub=p.add_subparsers(dest='mode',required=True)
 b3=sub.add_parser('b3',help='Build existing signed-precommit registry from four actual guarded callback outputs')
 for event in ('410','412','411','413'):
  b3.add_argument('--callback-'+event+'-output',type=Path,required=True);b3.add_argument('--callback-'+event+'-sha256',required=True)
 b3.add_argument('--review-query-sdk',type=Path,required=True);b3.add_argument('--review-query-sdk-sha256',required=True)
 b3.add_argument('--reference-query-sdk',type=Path,required=True);b3.add_argument('--reference-query-sdk-sha256',required=True)
 post=sub.add_parser('postcommit',help='Build existing B4/B5 registry; independently PASS prior certificates required')
 post.add_argument('--window',choices=['B4-factory-result','B5-final-protection'],required=True)
 post.add_argument('--action-output',type=Path,required=True);post.add_argument('--action-output-sha256',required=True)
 post.add_argument('--signed-precommit',type=Path,required=True);post.add_argument('--signed-precommit-sha256',required=True)
 post.add_argument('--previous-postcommit',type=Path);post.add_argument('--previous-postcommit-sha256')
 a=p.parse_args();runtime,runtime_ref=checked(a.bindings,a.bindings_sha256)
 need(re.fullmatch('[0-9a-f]{40}',a.expected_head) and runtime['source_head']==a.expected_head,'Actual full source HEAD differs')
 need(runtime['run_id'].endswith('--li-yu-dao--R0019'),'Actual current R19 runtime required')
 attach=read_ref(runtime['game_original_handle_owner']['original_attach_receipt'])
 provenance={'session_id':runtime['session_id'],'profile_sha256':runtime['profile_sha256'],'pipe_name':attach['pipe_name']}
 leaf=leaf_module(a.leaf,a.leaf_sha256);sources=[runtime_ref,ref(a.leaf)]
 if a.mode=='b3':
  callbacks={}
  for event in ('410','412','411','413'):
   pair,item=callback_output(getattr(a,'callback_'+event+'_output'),getattr(a,'callback_'+event+'_sha256'),'lyd.'+event,leaf,provenance)
   callbacks['lyd.'+event]=[pair];sources.append(item)
  queries=[]
  for name in ('review_query_sdk','reference_query_sdk'):
   path=getattr(a,name);sha=getattr(a,name+'_sha256');_,sdk_ref=checked(path,sha)
   pair,native=sdk_pair(path,leaf,provenance)
   need(native['status']=='native_event_query_verified' and native['result']['current_event_window_context']['event_definition_key']=='lyd.430','Explicit actual current/first430 query required')
   queries.append(pair);sources.append(sdk_ref)
  registry={'schema':leaf.REGISTRY_SCHEMA,'source_head':a.expected_head,'window':'B3-signed-precommit','callback_pairs':callbacks,'review_query':queries[0],'reference_query':queries[1]}
 else:
  signed,signed_ref=certificate(a.signed_precommit,a.signed_precommit_sha256,leaf,'B3-signed-precommit')
  need(signed['source_head']==a.expected_head,'Actual prior B3 certificate source differs');sources.append(signed_ref)
  previous_ref=None
  if a.window=='B5-final-protection':
   need(a.previous_postcommit is not None and a.previous_postcommit_sha256 is not None,'Actual independent B4 certificate required before B5')
   previous,previous_ref=certificate(a.previous_postcommit,a.previous_postcommit_sha256,leaf,'B4-factory-result')
   need(previous['source_head']==a.expected_head and previous['signed_precommit']==signed_ref,'B4 must carry same actual qualified B3 reference');sources.append(previous_ref)
  else:need(a.previous_postcommit is None and a.previous_postcommit_sha256 is None,'B4 previous_postcommit remains NULL')
  pair,item=callback_output(a.action_output,a.action_output_sha256,'lyd.430' if a.window=='B4-factory-result' else 'lyd.431',leaf,provenance);sources.append(item)
  registry={'schema':leaf.POST_SCHEMA,'source_head':a.expected_head,'window':a.window,'signed_precommit':signed_ref,'previous_postcommit':previous_ref,'action':pair}
 out=a.output.resolve();need(out.is_relative_to(BASE) and not out.exists(),'Fresh external registry output required');out.mkdir(parents=True)
 target=out/'REGISTRY.actual.json';write(target,registry)
 write(out/'RESULT.actual.json',{'status':'EXISTING_FORMAL_REGISTRY_ACTUAL_RECEIPT_REFERENCES_AUTHORED','registry':ref(target),'source_inputs':sources,
      'source':ref(__file__),'source_head':a.expected_head,'window':registry['window'],'qualification_executed':False,
      'formal_qualification_pass':None,'whole_product_pass':None,'SDK_calls':0,'game_calls':0,'process_queries':0,'save_body_reads':0,'receipt_copies':0,'main_writes':0})
 print(json.dumps({'registry':ref(target),'result':ref(out/'RESULT.actual.json'),'qualification_pass':None}));return 0

if __name__=='__main__':raise SystemExit(main())
