from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
MAIN = Path('C:/workspace/ck3_eternal_recurrence')
FROZEN = Path('C:/lr29s1/ck3_autonomous_player/native_bridge')
OUT = Path('C:/mq29f1')
TEST = MAIN / 'ck3_autonomous_player/native_bridge/src/main_thread_query_mailbox_v1_test.cpp'
BRIDGE = MAIN / 'ck3_autonomous_player/native_bridge/src/bridge.cpp'
MAILBOX = FROZEN / 'src/main_thread_query_mailbox_v1.cpp'

def ref(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def write(path, obj):
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(obj, handle, ensure_ascii=False, indent=2)
        handle.write('\n')

if OUT.exists():
    raise FileExistsError('fresh isolated output required: ' + str(OUT))
OUT.mkdir()
for relative in ('src/bridge.cpp', 'src/main_thread_query_mailbox_v1.cpp', 'include/xar_bridge/main_thread_query_mailbox_v1.hpp'):
    if (MAIN / 'ck3_autonomous_player/native_bridge' / relative).read_bytes() != (FROZEN / relative).read_bytes():
        raise ValueError('MAIN production input differs from actual frozen R29: ' + relative)
before = (HERE / 'main_thread_query_mailbox_v1_test.original.cpp').read_bytes()
after = TEST.read_bytes()
patch = ''.join(difflib.unified_diff(before.decode('utf-8').splitlines(keepends=True),
                                   after.decode('utf-8').splitlines(keepends=True),
                                   fromfile='a/ck3_autonomous_player/native_bridge/src/main_thread_query_mailbox_v1_test.cpp',
                                   tofile='b/ck3_autonomous_player/native_bridge/src/main_thread_query_mailbox_v1_test.cpp'))
with (HERE / 'PATCH.diff').open('x', encoding='utf-8', newline='') as handle:
    handle.write(patch)
bridge = BRIDGE.read_bytes()
start = bridge.index(b'  void InstallCoreFrame12004() noexcept {')
end = bridge.index(b'  void MaybeConfigureCouncilPrivateRoute()', start)
eol = b'\r\n' if b'\r\n' in bridge else b'\n'
assignment = eol.join((
    b'    environment.permitted_executor_actor_cached_succession12004 =',
    b'        &xar::ck3_12004::ExecuteActorCachedSuccessionMailboxV1;',
)) + eol
scope = bridge[start:end]
if scope.count(assignment) != 1:
    raise ValueError('actual4 cache registration negative fixture anchor differs')
at = start + scope.index(assignment)
negative_bridge = OUT / 'bridge.actual4-cache-registration-removed.fixture.cpp'
with negative_bridge.open('xb') as handle:
    handle.write(bridge[:at] + bridge[at + len(assignment):])
sys.path.insert(0, str(MAIN / 'tools'))
helper_path = MAIN / 'tools/run_native_msvc.py'
spec = importlib.util.spec_from_file_location('r29_focused_msvc_environment', helper_path)
if spec is None or spec.loader is None:
    raise RuntimeError('MSVC environment loader unavailable')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
environment = helper.child_environment(OUT)
installation = helper.visual_studio_installation(None, environment)
environment, tools = helper.initialize_msvc(installation, OUT, environment)
exe = OUT / 'xar_ck3_main_thread_query_mailbox_v1_test.exe'
compile_argv = [tools['cl'], '/nologo', '/std:c++20', '/EHsc', '/W4', '/permissive-',
                '/O2', '/MD', '/DNDEBUG', '/DNOMINMAX', '/DWIN32_LEAN_AND_MEAN',
                '/DUNICODE', '/D_UNICODE', '/I' + str(FROZEN / 'include'),
                '/Fo' + str(OUT) + '\\', '/Fe' + str(exe), str(MAILBOX), str(TEST),
                '/link', 'bcrypt.lib', 'user32.lib', '/OPT:REF', '/OPT:ICF']
positive_argv = [str(exe), '--confucian-registration-only', str(BRIDGE)]
negative_argv = [str(exe), '--confucian-registration-only', str(negative_bridge)]
request = {
    'schema': 'lyd.r29.actor-cache-registration-focused-request.v1',
    'compile_argv': compile_argv, 'positive_argv': positive_argv,
    'negative_argv': negative_argv, 'output_directory': str(OUT),
    'inputs': {'production_mailbox': ref(MAILBOX), 'patched_test': ref(TEST),
               'actual_production_bridge': ref(BRIDGE), 'negative_bridge': ref(negative_bridge),
               'MSVC_environment_helper': ref(helper_path), 'patch': ref(HERE / 'PATCH.diff')},
    'isolated_test_only': True, 'historical_R29_source_build_unchanged': True,
    'full_suite_or_runtime_DLL_build': False,
}
write(OUT / 'REQUEST.actual.json', request)
print(json.dumps({'request': ref(OUT / 'REQUEST.actual.json'), 'compile_argv': compile_argv}), flush=True)

def run(label, argv):
    started = time.time()
    result = subprocess.run(argv, cwd=OUT, env=environment, capture_output=True, check=False)
    stdout = OUT / (label + '.stdout.bin')
    stderr = OUT / (label + '.stderr.bin')
    with stdout.open('xb') as handle:
        handle.write(result.stdout)
    with stderr.open('xb') as handle:
        handle.write(result.stderr)
    row = {'argv': argv, 'returncode': result.returncode, 'elapsed_seconds': time.time() - started,
           'stdout': ref(stdout), 'stderr': ref(stderr)}
    write(OUT / (label + '.RESULT.actual.json'), row)
    print(label, json.dumps(row), flush=True)
    if result.stdout:
        print(result.stdout.decode('utf-8', errors='replace'), flush=True)
    if result.stderr:
        print(result.stderr.decode('utf-8', errors='replace'), flush=True)
    return row

compiled = run('compile', compile_argv)
if compiled['returncode'] != 0:
    raise RuntimeError('focused production mailbox fixture compilation failed; raw evidence retained')
positive = run('positive', positive_argv)
negative = run('negative_missing_actual4_cache', negative_argv)
summary = {
    'schema': 'lyd.r29.actor-cache-registration-focused-result.v1',
    'request': ref(OUT / 'REQUEST.actual.json'), 'compile': compiled,
    'positive': positive, 'negative_missing_actual4_cache': negative,
    'exe': ref(exe), 'pass': positive['returncode'] == 0 and negative['returncode'] == 1,
    'runtime_DLL_qualification': None, 'business_pass': None,
    'SDK_or_CK3_calls': 0, 'whole_mod': 'NOT_GREEN',
}
write(OUT / 'RESULT.actual.json', summary)
print(json.dumps(ref(OUT / 'RESULT.actual.json')), flush=True)
if not summary['pass']:
    raise RuntimeError('focused positive/source-negative regression did not have expected results')
