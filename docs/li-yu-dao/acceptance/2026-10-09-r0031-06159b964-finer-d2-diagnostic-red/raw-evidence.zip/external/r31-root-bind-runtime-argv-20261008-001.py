from pathlib import Path
import hashlib
import json

B = Path('C:/workspace/ck3_lyd_runtime_20261004')
source = B / 'r31-root-bootstrap-sourceonly-20261008-003/ROOT-AUTHOR-RUNTIME-ARGV.late-pending.json'
raw = source.read_bytes()
assert hashlib.sha256(raw).hexdigest().startswith('2c607315')
obj = json.loads(raw)
argv = obj['argv']
canonical = B / 'r31-root-allocation-bound-canonical-20261008-001/INDEX.json'
overlay = B / 'r31-root-diagnostic-overlay-20261008-001/BINDING.actual.json'
assert hashlib.sha256(canonical.read_bytes()).hexdigest() == '80da36e050e707caf35f7da3f7612311babb57446cad7a786f92641bc787cae0'
assert hashlib.sha256(overlay.read_bytes()).hexdigest() == 'febe31ef3c82bba653871a4c8f3a88272df5d37c4362564637c978185a7619b5'
for flag, value in (
    ('--canonical-index-sha256', '80da36e050e707caf35f7da3f7612311babb57446cad7a786f92641bc787cae0'),
    ('--diagnostic-overlay', overlay.as_posix()),
    ('--diagnostic-overlay-sha256', 'febe31ef3c82bba653871a4c8f3a88272df5d37c4362564637c978185a7619b5'),
):
    index = argv.index(flag) + 1
    assert argv[index] is None
    argv[index] = value
assert all(isinstance(x, str) for x in argv)
obj['root_binding'] = {'source': source.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'filled_fields': ['--canonical-index-sha256', '--diagnostic-overlay', '--diagnostic-overlay-sha256']}
target = B / 'r31-root-author-runtime-argv-20261008-001.json'
with target.open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'path': target.as_posix(), 'bytes': target.stat().st_size, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))
