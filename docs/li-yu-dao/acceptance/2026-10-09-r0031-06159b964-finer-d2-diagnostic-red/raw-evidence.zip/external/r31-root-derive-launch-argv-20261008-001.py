from pathlib import Path
import hashlib
import json
B = Path('C:/workspace/ck3_lyd_runtime_20261004')
source = B / 'r31-root-preflight-argv-20261008-001.json'
obj = json.loads(source.read_bytes())
argv = obj['argv']
assert argv[5].replace('\\', '/').endswith('/core/root_next_formal_launch_profile.py')
assert argv[6] == 'preflight'
argv[6] = 'launch'
i = argv.index('--output') + 1
assert argv[i] == 'C:/workspace/ck3_lyd_runtime_20261004/live-attempt-031/root-preflight-001'
argv[i] = 'C:/workspace/ck3_lyd_runtime_20261004/live-attempt-031/root-launch-001'
obj['source_argv'] = {'path': source.as_posix(), 'bytes': source.stat().st_size, 'sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'changed_fields': ['mode', '--output']}
target = B / 'r31-root-launch-argv-20261008-001.json'
with target.open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'path': target.as_posix(), 'bytes': target.stat().st_size, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))
