from __future__ import annotations
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

PACK = Path(__file__).resolve().parent
EXPORT = Path('C:/lr31s1')
MAIN = Path('C:/workspace/ck3_eternal_recurrence')
PROJECTION = PACK / 'portable-projection'
PYTHON = 'C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
HEAD = '06159b964d859d30f2f07f4b183284df7d6dac47'
PRIOR = PACK.parent / 'r31-06159b964-official-step31-portable-reproduction-20261008-001'

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat().replace('+00:00', 'Z')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def ref(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)

def write_json(path, value):
    write(path, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))

def main():
    PROJECTION.mkdir()
    tools = [
        'test_ck3_mod_acceptance.py', 'test_ck3_mod_acceptance_adapters.py',
        'test_ck3_mod_acceptance_completion.py', 'ck3_mod_acceptance.py',
        'ck3_mod_acceptance_allocate.py', 'ck3_mod_acceptance_client.py',
        'ck3_mod_acceptance_prepare.py', 'fixture_engine_prepare.py',
        'ck3_mod_acceptance_products.json',
    ]
    sources = [EXPORT / 'tools' / name for name in tools]
    # Only this bounded package is enumerated; no repository-wide source scan.
    sources += sorted((EXPORT / 'tools/ck3_mod_acceptance_cases').glob('*.py'))
    sources.append(EXPORT / 'tools/ck3_mod_acceptance_cases/xqol_original_plans.json')
    sources.append(EXPORT / 'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py')
    sources.append(EXPORT / 'ck3_autonomous_player/src/xar_autoplayer/bridge/version_identity.py')
    sources.append(EXPORT / 'ck3_autonomous_player/src/xar_autoplayer/steam_workshop_status.py')
    rows = []
    for source in sources:
        rel = source.relative_to(EXPORT)
        data = source.read_bytes()
        target = PROJECTION / rel
        write(target, data)
        rows.append({'relative_path': rel.as_posix(), 'source_root_kind': 'actual_clean_export',
                     'source': ref(source), 'projection': ref(target)})
    # ROOT explicitly authorized this single tracked file read at clean MAIN HEAD06159.
    source = MAIN / 'workshop/products.json'
    target = PROJECTION / 'workshop/products.json'
    write(target, source.read_bytes())
    rows.append({'relative_path': 'workshop/products.json', 'source_root_kind': 'ROOT_verified_clean_main_at_exact_head',
                 'source': ref(source), 'projection': ref(target)})
    manifest = {
        'schema': 'bounded-portable-step-projection-v1', 'created_at_utc': now(),
        'expected_head': HEAD,
        'head_provenance': 'ROOT verified actual clean export and MAIN at06159; no Git operation by this author',
        'projection': str(PROJECTION), 'original_export': str(EXPORT),
        'files': rows, 'main_writes': 0, 'export_writes': 0,
        'binary_or_saved_body_copies': 0,
        'prior_missing_export_dependency': ref(PRIOR / 'INDEX-MISSING-EXPORT-DEPENDENCY.json'),
        'workflow_source': ref(PRIOR / 'exact-workflow-001.source.yml'),
        'workflow_commands_source': ref(PRIOR / 'WORKFLOW-COMMANDS.actual-source.json'),
    }
    write_json(PACK / 'PROJECTION.actual.json', manifest)
    temporary = PACK / 'portable-test-temp'
    temporary.mkdir()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1',
               TMP=str(temporary), TEMP=str(temporary), TMPDIR=str(temporary))
    commands = [
        [PYTHON, '-B', '-X', 'utf8', 'tools/test_ck3_mod_acceptance.py'],
        [PYTHON, '-B', '-X', 'utf8', 'tools/test_ck3_mod_acceptance_adapters.py'],
        [PYTHON, '-B', '-X', 'utf8', 'tools/test_ck3_mod_acceptance_completion.py'],
    ]
    results = []
    failed = None
    begun = now()
    for index, argv in enumerate(commands, 1):
        output = PACK / f'command-{index:03}'
        output.mkdir()
        write_json(output / 'ARGV.actual.json', {'argv': argv, 'cwd': str(PROJECTION), 'shell': False,
                   'environment_overrides': {k: env[k] for k in ('PYTHONDONTWRITEBYTECODE','PYTHONUTF8','TMP','TEMP','TMPDIR')},
                   'timeout_seconds': 60, 'expected_head': HEAD})
        started = now()
        start = time.perf_counter()
        timed_out = False
        try:
            result = subprocess.run(argv, cwd=PROJECTION, env=env, stdin=subprocess.DEVNULL,
                                    capture_output=True, timeout=60, shell=False)
            stdout, stderr, exit_code = result.stdout, result.stderr, result.returncode
        except subprocess.TimeoutExpired as error:
            timed_out = True
            stdout, stderr, exit_code = error.stdout or b'', error.stderr or b'', None
        wall = time.perf_counter() - start
        write(output / 'stdout.actual.log', stdout)
        write(output / 'stderr.actual.log', stderr)
        receipt = {'schema': 'original-portable-command-completion-v1',
                   'argv': argv, 'cwd': str(PROJECTION), 'started_at_utc': started, 'finished_at_utc': now(),
                   'wall_time_seconds': wall, 'exit_code': exit_code, 'timed_out': timed_out,
                   'stdout': ref(output / 'stdout.actual.log'), 'stderr': ref(output / 'stderr.actual.log')}
        write_json(output / 'RESULT.actual.json', receipt)
        results.append({'command_number': index, 'receipt': ref(output / 'RESULT.actual.json'), **receipt})
        print(json.dumps({'command_number': index, 'exit_code': exit_code, 'timed_out': timed_out,
                          'wall_time_seconds': wall}, ensure_ascii=False), flush=True)
        print(stderr.decode('utf-8', errors='replace'), flush=True)
        if exit_code != 0 or timed_out:
            failed = index
            break
    unchanged = all(ref(PROJECTION / row['relative_path'])['sha256'] == row['projection']['sha256'] for row in rows)
    actual = {
        'schema': 'bounded-official-step-local-projection-reproduction-v1',
        'exact_head': HEAD, 'started_at_utc': begun, 'finished_at_utc': now(),
        'status': 'ACTUAL_LOCAL_COMPLETE_PORTABLE_STEP_PASS' if failed is None else 'ACTUAL_LOCAL_COMPLETE_PROJECTION_RED',
        'projection_manifest': ref(PACK / 'PROJECTION.actual.json'),
        'source_files_unchanged': unchanged,
        'commands': results, 'first_failed_command': failed,
        'unexecuted_commands': [{'command_number': n, 'argv': commands[n-1], 'status': 'NOT_RUN_STOPPED_AT_FIRST_RED'}
                                for n in range(len(results)+1, 4)],
        'official_run_id': 37772862210, 'official_job_id': 113296449487,
        'official_conclusion': 'failure', 'official_failure_case': None, 'official_failure_cause': None,
        'official_cause_claim': 'No downloaded original producer stacktrace; local failure only establishes the stated local case.',
        'source_patch_candidate': None, 'main_writes': 0, 'export_writes': 0, 'git_calls': 0,
        'game_calls': 0, 'sdk_calls': 0, 'steam_calls': 0,
    }
    write_json(PACK / 'REPRODUCTION.actual.json', actual)
    print(json.dumps(ref(PACK / 'REPRODUCTION.actual.json'), ensure_ascii=False), flush=True)
    raise SystemExit(0 if failed is None and unchanged else 1)

if __name__ == '__main__':
    main()
