from __future__ import annotations
import datetime as dt
import hashlib
import json
from pathlib import Path
import zipfile

PACK = Path(__file__).resolve().parent
PRIOR = PACK.parent / 'r31-06159b964-official-step31-portable-reproduction-20261008-001'
CI = PACK.parent / 'r30-06159b964-exact-official-ci-20261008-001'
HEAD = '06159b964d859d30f2f07f4b183284df7d6dac47'
DEST = 'docs/li-yu-dao/acceptance/2026-10-08-r0030-06159b964-exact-official-ci'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def ref(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)

def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

def main():
    created = dt.datetime.now(dt.timezone.utc).isoformat().replace('+00:00', 'Z')
    actual = json.loads((PACK / 'REPRODUCTION.actual.json').read_text(encoding='utf-8-sig'))
    projection = json.loads((PACK / 'PROJECTION.actual.json').read_text(encoding='utf-8-sig'))
    if actual['status'] != 'ACTUAL_LOCAL_COMPLETE_PORTABLE_STEP_PASS' or not actual['source_files_unchanged']:
        raise ValueError('This sealing source is for the actual three-command local PASS only')
    if len(actual['commands']) != 3 or any(row['exit_code'] != 0 for row in actual['commands']):
        raise ValueError('Actual command completion differs')
    report = f'''# 06159 官方 step31 的完整本地 portable 验证补充

精确 HEAD：`{HEAD}`。本地补齐导出依赖后的单次完整验证为 PASS；Official Runner 的原 step31 FAILURE 保持不变，官方具体 case / cause 仍 NULL。

ROOT 确认 MAIN 和 clean export `C:/lr31s1` 同为该 HEAD，并明确授权只读 MAIN 的 `workshop/products.json`。作者仅将所需 tools / src 源文件、registry 和这一产品清单按原字节复制到新的外置隔离目录，再执行该 HEAD 官方 workflow 的三个命令。未改变 MAIN 或原 clean export；未复制 EXE、DLL、游戏内容或真实存档。

| 实际命令 | 本地结果 |
| --- | --- |
| `python -B -X utf8 tools/test_ck3_mod_acceptance.py` | exit0，10 tests |
| `python -B -X utf8 tools/test_ck3_mod_acceptance_adapters.py` | exit0，9 tests |
| `python -B -X utf8 tools/test_ck3_mod_acceptance_completion.py` | exit0，3 tests |

三个脚本共 22 tests，按顺序各运行一次。实际解释器为 PY313，官方 workflow 同样声明 Python 3.13；每条命令的 argv、cwd、时间、exit 和完整 stdio 均在 raw ZIP。隔离源文件全部与准备时 SHA 一致。执行时间：{actual['started_at_utc']} 至 {actual['finished_at_utc']}。

此前在不完整 clean export 的首轮执行遇到 `workshop/products.json` 缺失，已独立永久保留在 `local-reproduction-001`；这次补充不覆盖首轮 RED，也不把它认作官方 case。官方 run `37772862210` / job `113296449487` 的 step31 原 FAILURE，以及两次 joblog 超时和未取得的具体原因，继续由父目录原 CI INDEX 记录。Li Yu / Linear 的原 SUCCESS 与 Official FAILURE 分列，不由本地 PASS 改写。

本地未复现功能性失败，源码修复 candidate 为 NULL。无第三次 joblog 下载、workflow 重跑、Git、native 编译、游戏、SDK、Steam、屏幕、进程、总线或系统设置操作；无业务验收、native / live GREEN。需要官方 producer 原文才能进一步认定远端原因，当前没有猜测补丁。
'''
    report_path = PACK / 'REPORT.md'
    write(report_path, report.encode('utf-8'))
    objects = [
        ('PROJECTION.actual.json', PACK / 'PROJECTION.actual.json'),
        ('REPRODUCTION.actual.json', PACK / 'REPRODUCTION.actual.json'),
        ('prepare_and_run.py', PACK / 'prepare_and_run.py'),
        ('REPORT.md', report_path),
        ('workflow/exact-workflow-001.actual.json', PRIOR / 'exact-workflow-001.actual.json'),
        ('workflow/exact-workflow-001.source.yml', PRIOR / 'exact-workflow-001.source.yml'),
        ('workflow/WORKFLOW-COMMANDS.actual-source.json', PRIOR / 'WORKFLOW-COMMANDS.actual-source.json'),
    ]
    for n in range(1, 4):
        for name in ('ARGV.actual.json','RESULT.actual.json','stdout.actual.log','stderr.actual.log'):
            rel = f'command-{n:03}/{name}'
            objects.append((rel, PACK / rel))
    for row in projection['files']:
        rel = 'portable-projection/' + row['relative_path']
        objects.append((rel, PACK / rel))
    records = [{'archive_member': name, 'source': ref(path)} for name, path in objects]
    archive = PACK / 'raw-portable-complete-step.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, path in objects:
            z.write(path, name)
    with zipfile.ZipFile(archive) as z:
        checks = []
        for row in records:
            data = z.read(row['archive_member'])
            checks.append({'archive_member': row['archive_member'],
                           'bytes_match': len(data) == row['source']['bytes'],
                           'sha256_match': sha(data) == row['source']['sha256']})
    all_match = all(row['bytes_match'] and row['sha256_match'] for row in checks)
    check_path = PACK / 'ARCHIVE-CHECK.actual.json'
    write(check_path, json_bytes({'schema': 'archive-original-byte-check-v1',
                                 'checked_at_utc': created, 'archive': ref(archive),
                                 'member_count': len(checks), 'all_match': all_match, 'members': checks}))
    if not all_match:
        raise ValueError('Archive byte check failed')
    index = {
        'schema': 'exact-ci-portable-complete-step-index-v1', 'created_at_utc': created,
        'exact_head': HEAD, 'official_workflow': 'Official Runner CI',
        'official_run_id': 37772862210, 'official_job_id': 113296449487,
        'official_job_url': 'https://github.com/XenoAmess/ck3_eternal_recurrence/actions/runs/37772862210/job/113296449487',
        'official_conclusion': 'failure', 'official_failed_step_number': 31,
        'official_failure_case': None, 'official_failure_cause': None,
        'official_final_index': ref(CI / 'INDEX.json'),
        'local_status': actual['status'], 'local_tests': [10, 9, 3], 'local_test_total': 22,
        'local_exit_codes': [row['exit_code'] for row in actual['commands']],
        'source_files_unchanged_in_projection': actual['source_files_unchanged'],
        'root_head_verification_provenance': projection['head_provenance'],
        'source_patch_candidate': None,
        'prior_incomplete_export_red_index': ref(PRIOR / 'INDEX-MISSING-EXPORT-DEPENDENCY.json'),
        'report': ref(report_path), 'projection_manifest': ref(PACK / 'PROJECTION.actual.json'),
        'reproduction_receipt': ref(PACK / 'REPRODUCTION.actual.json'),
        'archive': ref(archive), 'archive_check': ref(check_path), 'raw_objects': records,
        'suggested_delivery_subdirectory': DEST + '/local-reproduction-002',
        'claims': {'official_green': False, 'local_portable_step_pass': True,
                   'official_failure_cause_known': False, 'native_green': None, 'live_green': None, 'business_green': None},
        'scope': {'main_writes': 0, 'canonical_export_writes': 0, 'git_calls': 0,
                  'game_calls': 0, 'sdk_calls': 0, 'new_joblog_downloads': 0, 'workflow_dispatches': 0},
    }
    index_path = PACK / 'INDEX.json'
    write(index_path, json_bytes(index))
    deliveries = [
        (PRIOR, 'local-reproduction-001', 'INDEX-MISSING-EXPORT-DEPENDENCY.json', 'INDEX.json'),
        (PRIOR, 'local-reproduction-001', 'REPORT-MISSING-EXPORT-DEPENDENCY.md', 'REPORT.md'),
        (PRIOR, 'local-reproduction-001', 'SOURCE-DEPENDENCY.actual.json', 'SOURCE-DEPENDENCY.actual.json'),
        (PRIOR, 'local-reproduction-001', 'REPRODUCTION.actual.json', 'REPRODUCTION.actual.json'),
        (PRIOR, 'local-reproduction-001', 'raw-portable-first-failure.zip', 'raw-portable-first-failure.zip'),
        (PRIOR, 'local-reproduction-001', 'ARCHIVE-FIRST-FAILURE-CHECK.actual.json', 'ARCHIVE-CHECK.actual.json'),
    ]
    deliveries += [(PACK, 'local-reproduction-002', name, name) for name in (
        'INDEX.json','REPORT.md','PROJECTION.actual.json','REPRODUCTION.actual.json',
        'raw-portable-complete-step.zip','ARCHIVE-CHECK.actual.json')]
    copies = []
    for source_root, stage, source_name, target_name in deliveries:
        source = source_root / source_name
        target = PACK / 'candidate' / DEST / stage / target_name
        data = source.read_bytes()
        write(target, data)
        copies.append({'source': ref(source), 'candidate': ref(target),
                       'target_relative_path': DEST + '/' + stage + '/' + target_name,
                       'bytes_match': target.read_bytes() == data})
    copy_path = PACK / 'COPY-MANIFEST.actual.json'
    write(copy_path, json_bytes({'schema': 'create-only-exact-byte-copy-manifest-v1',
                               'created_at_utc': created, 'exact_head': HEAD,
                               'candidate_root': str(PACK / 'candidate'),
                               'copies': copies, 'all_match': all(row['bytes_match'] for row in copies),
                               'main_imported': False, 'committed': False, 'pushed': False}))
    print(json.dumps({'index': ref(index_path), 'report': ref(report_path), 'archive': ref(archive),
                      'archive_check': ref(check_path), 'copy_manifest': ref(copy_path),
                      'candidate_root': str(PACK / 'candidate'), 'copy_count': len(copies)}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
