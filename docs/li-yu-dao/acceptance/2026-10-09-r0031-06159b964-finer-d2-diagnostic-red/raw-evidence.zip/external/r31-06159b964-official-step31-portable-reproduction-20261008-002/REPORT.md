# 06159 官方 step31 的完整本地 portable 验证补充

精确 HEAD：`06159b964d859d30f2f07f4b183284df7d6dac47`。本地补齐导出依赖后的单次完整验证为 PASS；Official Runner 的原 step31 FAILURE 保持不变，官方具体 case / cause 仍 NULL。

ROOT 确认 MAIN 和 clean export `C:/lr31s1` 同为该 HEAD，并明确授权只读 MAIN 的 `workshop/products.json`。作者仅将所需 tools / src 源文件、registry 和这一产品清单按原字节复制到新的外置隔离目录，再执行该 HEAD 官方 workflow 的三个命令。未改变 MAIN 或原 clean export；未复制 EXE、DLL、游戏内容或真实存档。

| 实际命令 | 本地结果 |
| --- | --- |
| `python -B -X utf8 tools/test_ck3_mod_acceptance.py` | exit0，10 tests |
| `python -B -X utf8 tools/test_ck3_mod_acceptance_adapters.py` | exit0，9 tests |
| `python -B -X utf8 tools/test_ck3_mod_acceptance_completion.py` | exit0，3 tests |

三个脚本共 22 tests，按顺序各运行一次。实际解释器为 PY313，官方 workflow 同样声明 Python 3.13；每条命令的 argv、cwd、时间、exit 和完整 stdio 均在 raw ZIP。隔离源文件全部与准备时 SHA 一致。执行时间：2026-10-08T12:32:38.961789Z 至 2026-10-08T12:32:41.754731Z。

此前在不完整 clean export 的首轮执行遇到 `workshop/products.json` 缺失，已独立永久保留在 `local-reproduction-001`；这次补充不覆盖首轮 RED，也不把它认作官方 case。官方 run `37772862210` / job `113296449487` 的 step31 原 FAILURE，以及两次 joblog 超时和未取得的具体原因，继续由父目录原 CI INDEX 记录。Li Yu / Linear 的原 SUCCESS 与 Official FAILURE 分列，不由本地 PASS 改写。

本地未复现功能性失败，源码修复 candidate 为 NULL。无第三次 joblog 下载、workflow 重跑、Git、native 编译、游戏、SDK、Steam、屏幕、进程、总线或系统设置操作；无业务验收、native / live GREEN。需要官方 producer 原文才能进一步认定远端原因，当前没有猜测补丁。
