"""Pure retained JSON binding for R31 diagnostic stages; never invokes a provider."""
from pathlib import Path
import hashlib, importlib.util, importlib, json, sys
sys.dont_write_bytecode = True
B = Path('C:/workspace/ck3_lyd_runtime_20261004')
RUN = Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-031')
HEAD = '06159b964d859d30f2f07f4b183284df7d6dac47'
CACHE = Path('C:/workspace/ck3_lyd_runtime_20261004/r31-root-cache-comparator-bound-source-20261008-001/compare_actor_cached_succession.py')
CACHE_SHA = '3e9d1ea61d9e922db41656a576923c3f821e16d679e0e2b9812ef3b22ddd0aa5'
CONTEXT = Path('C:/lr31s1/ck3_autonomous_player/src/xar_autoplayer/bridge/ingame_decision_outcome_contract.py')
SIGNED_INPUT = {'path': 'C:/workspace/ck3_lyd_runtime_20261004/r30-root-signed-B3-input.actual.json', 'bytes': 3015, 'sha256': '5e5860c2d940da5701b954c1cbe568c5df8831ce5277e48562def029113f56af'}
from finer_d2_observations import STAGES, STAGE_VALUES

def need(ok, msg):
    if not ok:
        raise ValueError(msg)

def load_module(name, p):
    spec = importlib.util.spec_from_file_location(name, p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m
need(hashlib.sha256(CACHE.read_bytes()).hexdigest() == CACHE_SHA, 'Frozen cache authenticator changed')
cache = load_module('r31_stage_frozen_cache_json', CACHE)

def ref(p):
    p = Path(p).resolve()
    raw = p.read_bytes()
    return {'path': p.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def read(desc, *, sdk=False):
    return cache.artifact(desc, sdk=sdk)

def pair_native(pair, cp, tool, revision, arguments=None):
    cache.exact(pair, {'query_request', 'query_dispatch', 'query_sdk_result', 'query_native_receipt'}, 'actual retained ROOT query pair')
    request = read(pair['query_request'])
    dispatch = read(pair['query_dispatch'])
    sdk = read(pair['query_sdk_result'], sdk=True)
    native = read(pair['query_native_receipt'])
    cache.exact(request, {'schema', 'request_id', 'operation', 'name', 'arguments'}, 'actual ROOT request')
    need(request['schema'] == 'ck3.lyd.mcp-request.v1' and request['operation'] == 'call_tool' and (request['name'] == tool), 'actual readonly query tool required')
    need(request['arguments'] == ({'expected_revision': revision} if arguments is None else arguments), 'query must use its actual SAVE before/after public revision')
    need(dispatch['schema'] == 'ck3.lyd.mcp-dispatch.v1' and dispatch['status'] == 'MCP_RESULT_RECORDED' and (dispatch['request_id'] == request['request_id']) and (dispatch['request_sha256'] == pair['query_request']['sha256']), 'actual request/dispatch binding')
    need(dispatch['sdk_result_sha256'] == pair['query_sdk_result']['sha256'] and (Path(pair['query_dispatch']['path']).parent / dispatch['sdk_result']).resolve() == Path(pair['query_sdk_result']['path']).resolve(), 'original SDK dispatch binding')
    rows = dispatch['native_receipts']
    need(type(rows) is list and len(rows) == 1 and (rows[0]['sha256'] == pair['query_native_receipt']['sha256']) and (Path(rows[0]['path']).resolve() == Path(pair['query_native_receipt']['path']).resolve()), 'original native receipt dispatch binding')
    cache.sdk_native(sdk, native)
    need(native['schema'] == 'ck3.native-profile-receipt.v1' and Path(native['receipt_path']).resolve() == Path(pair['query_native_receipt']['path']).resolve(), 'actual original native path/schema')
    for key in ('session_id', 'profile_sha256', 'pipe_name'):
        need(native[key] == cp[key], 'query/SAVE original provenance differs ' + key)
    return native

def bind(evidence, cp, converter):
    cache.exact(evidence, {'stage', 'stage_context', 'cache_before', 'cache_after'}, 'R31 diagnostic stage evidence')
    stage = evidence['stage']
    need(stage in STAGES, 'actual finer-D2 diagnostic stage required')
    before = converter.frame_binding(cp['snapshot_before'])
    after = converter.frame_binding(cp['snapshot_after'])
    native = pair_native(evidence['stage_context'], cp, 'ck3_query_profile_event_window_v1', before['revision'], {'expected_revision': before['revision'], 'event_instance_id': cp['snapshot_before']['active_event']['instance_id']})
    source_pins = json.loads((Path(__file__).parent / 'STAGE-SOURCE-REFS.json').read_bytes())
    for item in source_pins['event_normalizer_sources']:
        need(ref(item['path']) == item, 'Exact exported event normalization source changed')
    provider, _ = cache.provider()
    context = importlib.import_module('xar_autoplayer.bridge.ingame_decision_outcome_contract')
    need(Path(context.__file__).resolve() == CONTEXT.resolve(), 'actual exported event normalizer path')
    need(context.actual_expected_event(native['result'], cp['snapshot_before'], before, 'lyd_factory_diag.' + str(STAGE_VALUES[stage])), 'stage label must be proven by actual event definition/root/instance at SAVE-before frame')
    observations = {}
    for name, binding in (('cache_before', before), ('cache_after', after)):
        n = pair_native(evidence[name], cp, cache.TOOL, binding['revision'])
        need(n['status'] == 'native_actor_cached_succession_observed' and n['business_effects_verified'] is False and (n['full_product_acceptance_credit'] is False), 'actual available readonly cache receipt without business credit')
        public = provider.normalize_public_query(n['result'], binding)
        payload = public['native_result']['actor_cached_succession']
        need(payload['available'] is True and payload['roster_complete'] is True and (payload['unavailable_reason'] is None), 'complete actual cache observation required')
        observations[name] = {'binding': binding, 'complete_cached_successor_ids': payload['complete_cached_successor_ids'], 'native_count': payload['native_count'], 'capture_epoch': payload['capture_epoch'], 'original_receipts': evidence[name]}
    return {'stage': stage, 'before': before, 'after': after, 'actual_stage_context': native['result']['current_event_window_context'], **observations, 'inputs': evidence, 'formal_mandate_credit': None, 'actual_pass': None}
