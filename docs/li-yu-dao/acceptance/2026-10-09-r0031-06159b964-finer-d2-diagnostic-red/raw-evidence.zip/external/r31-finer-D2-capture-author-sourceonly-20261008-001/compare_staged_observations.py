"""Compare existing D0/D1-D6 JSON observations; preserve every false protection check."""
from pathlib import Path
import argparse, json, sys
sys.dont_write_bytecode = True
from stage_json_binding import need, read, ref, cache
from finer_d2_observations import STAGES, ORDER, title_delta

def rowdiff(a, b, path=''):
    if type(a) is not type(b):
        return [{'path': path, 'before': a, 'after': b}]
    if isinstance(a, dict):
        out = []
        for k in sorted(set(a) | set(b)):
            p = path + '/' + str(k).replace('~', '~0').replace('/', '~1')
            if k not in a or k not in b:
                out.append({'path': p, 'before_present': k in a, 'after_present': k in b, 'before': a.get(k), 'after': b.get(k)})
            else:
                out.extend(rowdiff(a[k], b[k], p))
        return out
    if isinstance(a, list):
        out = []
        for i in range(max(len(a), len(b))):
            p = path + '/' + str(i)
            if i >= len(a) or i >= len(b):
                out.append({'path': p, 'before_present': i < len(a), 'after_present': i < len(b), 'before': a[i] if i < len(a) else None, 'after': b[i] if i < len(b) else None})
            else:
                out.extend(rowdiff(a[i], b[i], p))
        return out
    return [] if a == b else [{'path': path, 'before': a, 'after': b}]

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--inputs', type=Path, required=True)
    p.add_argument('--sha256', required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    desc = ref(a.inputs)
    need(desc['sha256'] == a.sha256, 'Actual JSON comparison input SHA required')
    d = read(desc)
    keys = {'prior_author_result', 'prior_state', 'prior_typed_protection', 'prior_cache_result', 'prior_stage_observations', 'current_author_result', 'current_stage_observations'}
    need(set(d) == keys, 'Closed actual comparison inputs; future required NULL rejected')
    prior = read(d['prior_author_result'])
    ps = read(d['prior_state'])
    pt = read(d['prior_typed_protection'])
    current = read(d['current_author_result'])
    observed = read(d['current_stage_observations'])
    for k in ('prior_state', 'prior_typed_protection'):
        need(d[k] in prior['outputs'], 'Prior author must inventory exact ' + k)
    need(prior['save_body_reads'] == current['save_body_reads'] == 1, 'Prior/current independent single-body receipts required')
    need(observed['source_author_result'] == d['current_author_result'] and all((observed[k] in current['outputs'] for k in ('state', 'typed_protection', 'qualified_native'))), 'Current stage author original output binding')
    state = read(observed['state'])
    typed = read(observed['typed_protection'])
    q = read(observed['qualified_native'])
    need(q['G2_status'] == 'BOUND_COMPLETE_NATIVE_OBSERVATION' and q['runtime_binding']['source_head'] == observed['source_head'], 'Actual current complete qualified native join')
    need(ps['identity']['pid'] == state['identity']['pid'] and ps['identity']['session_id'] == state['identity']['session_id'] and (ps['checkpoint_sha256'] != state['checkpoint_sha256']), 'Same diagnostic cold process/session; separate actual SAVE')
    stage = observed['stage']
    need(stage in STAGES, 'Actual finer-D2 observed stage')
    if d['prior_stage_observations'] is None:
        need(stage == 'D1' and ps['stage'] == 'signed_precommit', 'D1 compares actual D0 signed-precommit state')
        pc = read(d['prior_cache_result'])
        need(pc['native_to_saved_equality'] is True and pc['input_artifacts']['state'] == d['prior_state'], 'Actual D0 cache-to-saved baseline match')
        previous_stage = 'D0'
        prior_title = None
        old_titles = {str(r['title_id']): r for r in ps['protected_titles']}
    else:
        po = read(d['prior_stage_observations'])
        need(po['source_author_result'] == d['prior_author_result'] and po['state'] == d['prior_state'] and (po['typed_protection'] == d['prior_typed_protection']), 'Exact previous staged output tuple')
        previous_stage = po['stage']
        need(previous_stage in ORDER and ORDER[previous_stage] + 1 == ORDER[stage], 'Consecutive actual D1/D2a/D2b/staged pair only')
        prior_title = po['scoped_title_observation']
        old_titles = po['political7']
    need(set(old_titles) == set(observed['political7']) == {'2230', '2231', '2232', '2235', '2262', '2263', '2264'}, 'Complete immutable seven-title comparison universe')
    political = []
    for tid in sorted(old_titles, key=int):
        before = old_titles[tid]
        after = observed['political7'][tid]
        delta = rowdiff(before['entries'], after['entries'])
        if delta:
            political.append({'title_id': int(tid), 'before_AST_sha256': before['AST_sha256'], 'after_AST_sha256': after['AST_sha256'], 'full_AST_deltas': delta, 'holder_before': before['holder'], 'holder_after': after['holder']})
    cache_before = cache.saved_ids(ps)
    cache_after = cache.saved_ids(state)
    landed = rowdiff(ps['actor']['landed_data'], state['actor']['landed_data'])
    protected_before = {r['name']: r for r in pt['checks']}
    protected_after = {r['name']: r for r in typed['checks']}
    need(len(pt['checks']) == len(typed['checks']) == 87 and set(protected_before) == set(protected_after), 'Unmodified original87 protected check names')
    report = {'schema': 'lyd.r31.staged-factory-first-delta-observations.v1', 'status': 'ACTUAL_STAGE_COMPARISON_RECORDED', 'previous_stage': previous_stage, 'stage': stage, 'inputs': d, 'political_full_AST_deltas': political, 'actor_landed_full_AST_deltas': landed, 'scoped_title_full_AST_delta': title_delta(prior_title, observed['scoped_title_observation'], rowdiff), 'all_saved_factory_marker_Title_ASTs': observed['all_saved_factory_marker_Title_ASTs'], 'cache_before_stage_saved_ids': cache_before, 'cache_after_stage_saved_ids': cache_after, 'cached_successor_stage_delta': rowdiff(cache_before, cache_after), 'cache_before_SAVE_ids': observed['actual_native_stage']['cache_before']['complete_cached_successor_ids'], 'cache_after_SAVE_ids': observed['actual_native_stage']['cache_after']['complete_cached_successor_ids'], 'cache_after_SAVE_equals_saved_actor': observed['cache_after_SAVE_equals_saved_actor'], 'cache_drift_during_SAVE': not observed['cache_before_SAVE_equals_cache_after_SAVE'], 'original87_prior_match': pt['protection_checks_match'], 'original87_current_match': typed['protection_checks_match'], 'original87_false_checks': [r for r in typed['checks'] if r['matches'] is not True], 'newly_false_checks': [protected_after[k] for k in protected_after if protected_before[k]['matches'] is True and protected_after[k]['matches'] is not True], 'first_changed_component': 'political_full_AST' if political else 'actor_landed_AST' if landed else None, 'terminal_formal_observations': observed['terminal_formal_observations'], 'formal_mandate_credit': None, 'formal_B4_B5_pass': None, 'wholemod_GREEN': False, 'factory_cause_inferred': False, 'body_reads': 0, 'SDK_calls': 0}
    a.output.mkdir(parents=True, exist_ok=False)
    with (a.output / 'RESULT.actual.json').open('x', encoding='utf-8', newline='\n') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
        f.write('\n')
    print(json.dumps({'result': ref(a.output / 'RESULT.actual.json'), 'stage': stage, 'changed_political_titles': [x['title_id'] for x in political], 'original87_current_match': typed['protection_checks_match'], 'formal_mandate_credit': None}))
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
