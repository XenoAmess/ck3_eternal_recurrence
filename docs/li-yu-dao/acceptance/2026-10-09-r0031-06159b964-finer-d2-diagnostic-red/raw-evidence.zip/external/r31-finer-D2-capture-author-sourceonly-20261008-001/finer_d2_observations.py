"""Pure observations from the already parsed staged save; no body or native calls."""
from copy import deepcopy

STAGES=('D1','D2a','D2b','D3','D4','D5','D6')
STAGE_VALUES={'D1':1,'D2a':20,'D2b':2,'D3':3,'D4':4,'D5':5,'D6':6}
WINDOWS={stage+'-staged-observation':stage for stage in STAGES}
ORDER={stage:i for i,stage in enumerate(('D0',)+STAGES)}
PROPS=('destroy_if_invalid_heir','no_automatic_claims','definite_form','always_follows_primary_heir')

def marked_title_rows(scan):
    # Both correct and malformed marker rows remain available for an honest
    # missing/mismatched scoped-T diagnosis. No candidate is silently chosen.
    return {str(tid):deepcopy(row) for tid,row in sorted(scan['titles'].items())
            if any(k in row['variables'] for k in ('lyd_c2_owned_head_title','lyd_c2_owner_faith'))}

def title_observation(scan,bound,reader):
    stage=bound['stage'];rows=marked_title_rows(scan)
    context=bound['actual_stage_context'];scopes=context['saved_scopes']
    stage_rows=[r for r in scopes if r['name']=='lyd_factory_diag_stage']
    actual_stage=None
    if len(stage_rows)==1:
        scope=stage_rows[0]['scope'];numeric=scope.get('numeric_value')
        if (scope.get('raw_type_index')==1 and scope.get('type_key')=='value'
                and scope.get('subtype')==0 and type(numeric)is dict):
            actual_stage=numeric.get('integer_value')
    stage_match=actual_stage==str(STAGE_VALUES[stage])
    result={'stage':stage,'native_saved_stage_value':deepcopy(stage_rows),
            'native_saved_stage_value_matches':stage_match,
            'all_saved_factory_marker_Title_ASTs':rows,
            'actual_native_new_title_scope':None,'actual_native_title_id':None,
            'actual_saved_title':None,'checks':{},'binding_match':None,
            'status':'UNKNOWN','diagnostic_advance_allowed':False,
            'formal_mandate_credit':None,'formal_B4_B5_pass':None}
    if stage=='D1':
        result.update(status='D1_PRECREATION_OBSERVED' if stage_match else 'RED_STAGE_SCOPE_VALUE',
                      diagnostic_advance_allowed=stage_match)
        return result
    named=[r for r in scopes if r['name']=='new_title']
    if len(named)!=1:
        result.update(status='UNKNOWN_NEW_TITLE_SCOPE_MISSING_OR_NOT_UNIQUE')
        return result
    scope=named[0]['scope'];result['actual_native_new_title_scope']=deepcopy(named[0])
    identity=scope.get('typed_identity',{})
    if not (scope.get('status')=='available' and scope.get('raw_type_index')==5
            and scope.get('type_key')=='landed_title' and scope.get('subtype')==0
            and identity.get('status')=='available' and identity.get('kind')=='landed_title'
            and type(identity.get('title_id'))is int and -(2**31)<=identity['title_id']<2**31
            and identity['title_id'] not in (-1,0)):
        result.update(status='UNKNOWN_NEW_TITLE_TYPED_REFERENCE_UNAVAILABLE')
        return result
    tid=identity['title_id'] & 0xffffffff
    result['actual_native_raw_title_id']=identity['title_id'];result['actual_native_title_id']=tid
    row=scan['titles'].get(tid)
    if row is None:
        result.update(status='UNKNOWN_NATIVE_SCOPED_TITLE_NOT_PRESENT_IN_SAVE')
        return result
    result['actual_saved_title']=deepcopy(row)
    owned=row['variables'].get('lyd_c2_owned_head_title')
    owner=row['variables'].get('lyd_c2_owner_faith')
    checks={'saved_stage_matches_actual_event':stage_match,
            'saved_id_equals_actual_native_scope':row['title_id']==tid,
            'owned_marker_exact_one':type(owned)is dict and owned.get('type')=='value'
                 and owned.get('present')is True and owned.get('identity')=='100000'
                 and owned.get('number')=='1' and owned.get('scale')==100000,
            'typed_owner_Faith_matches':type(owner)is dict and owner.get('type')=='faith'
                 and owner.get('present')is True and owner.get('identity')==str(scan['faith_id']),
            'holder_matches_stage':row['holder'] is None if stage=='D2a'
                 else row['holder']==scan['actor']['character_id']}
    checks.update({key:reader.one(row['entries'],key)=='yes' for key in PROPS})
    result.update(checks=checks,binding_match=all(checks.values()),
                  status='BOUND_D2A_UNHELD_TITLE_OBSERVED' if stage=='D2a' and all(checks.values())
                      else 'BOUND_HELD_TITLE_STAGE_OBSERVED' if all(checks.values())
                      else 'RED_ACTUAL_SCOPED_TITLE_STAGE_MISMATCH',
                  diagnostic_advance_allowed=all(checks.values()))
    return result

def title_delta(previous,current,rowdiff):
    old=previous.get('actual_saved_title') if previous is not None else None
    new=current.get('actual_saved_title')
    old_id=previous.get('actual_native_title_id') if previous is not None else None
    new_id=current.get('actual_native_title_id')
    continuity=(old_id==new_id if old_id is not None and new_id is not None else None)
    prior_ready=previous is None or previous['diagnostic_advance_allowed']
    continuous=(previous is None or previous['stage']=='D1' or continuity is True)
    return {'before_native_title_id':old_id,'after_native_title_id':new_id,
            'same_native_title_id':continuity,
            'before_saved_title_present':old is not None,'after_saved_title_present':new is not None,
            'before_holder':old['holder'] if old is not None else None,
            'after_holder':new['holder'] if new is not None else None,
            'complete_saved_Title_AST_deltas':rowdiff(old['entries'] if old else None,new['entries'] if new else None),
            'prior_binding_status':previous['status'] if previous is not None else None,
            'current_binding_status':current['status'],
            'current_binding_match':current['binding_match'],
            'continuity_status':'SAME_ACTUAL_NATIVE_TITLE' if continuity is True
                else 'CREATION_BOUNDARY' if previous is None or previous['stage']=='D1'
                else 'RED_OR_UNKNOWN_ACTUAL_TITLE_CONTINUITY',
            'diagnostic_advance_allowed':bool(prior_ready and continuous and current['diagnostic_advance_allowed'])}
