import argparse
import hashlib
import json
import subprocess
from pathlib import Path
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
M=Path('C:/workspace/ck3_eternal_recurrence')
PY='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
HEAD='06159b964d859d30f2f07f4b183284df7d6dac47'
O=B/'r31-root-production-input-author-20261008-001'
PROD=B/'r31-root-reviewed-production-20261008-001/mod_li_yu_dao'
MAN=PROD.with_name(PROD.name+'.manifest.json')
def ref(p):
    p=Path(p); b=p.read_bytes()
    return {'path':p.as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,obj):
    with p.open('x',encoding='utf-8',newline='\n') as f: json.dump(obj,f,ensure_ascii=False,indent=2); f.write('\n')
def git(*a):
    return subprocess.check_output(['git','-C',str(M),*a],text=True).strip()
def main():
    p=argparse.ArgumentParser(); p.add_argument('mode',choices=['prepare','canonical']); a=p.parse_args()
    assert git('rev-parse','HEAD')==HEAD and git('rev-parse','origin/master')==HEAD
    assert not git('status','--porcelain')
    if a.mode=='prepare':
        O.mkdir()
        put(O/'PRODUCTION-ARGV.actual.json',{'argv':[PY,'-B','-X','utf8',str(M/'mod_li_yu_dao/tools/build_release.py'),'--output',PROD.as_posix()], 'source_head':HEAD})
        print(json.dumps({'argv':ref(O/'PRODUCTION-ARGV.actual.json')})); return
    actual=json.loads((B/'r31-root-production-build-original-exec-20261008-001/RESULT.actual.json').read_bytes())
    assert actual['exit_code']==0
    index=json.loads((B/'r30-root-canonical-source-20261008-002/INDEX.json').read_bytes())
    oldref=index['actual_reviewed_production_manifest']; assert ref(oldref['path'])==oldref
    old=json.loads(Path(oldref['path']).read_bytes()); new=json.loads(MAN.read_bytes())
    assert new['git_sha']==HEAD and len(new['files'])==71 and new['files']==old['files']
    review={'status':'ACTUAL_NEW_HEAD_RENDERED_PRODUCTION71_EXACT_ORDERED_BYTES_EQUAL',
            'source_head':HEAD,'current':ref(MAN),'previous':oldref,'business_files_changed':0,
            'diagnostic_overlay_in_production':False,'business_credit':False}
    reviewpath=O/'PRODUCTION-CONTINUITY-REVIEW.actual.json'; put(reviewpath,review)
    pending=B/'r31-canonical-latebinder-sourceonly-20261008-001/ROOT-CONSTRUCTOR-ARGV.pending.json'
    request=json.loads(pending.read_bytes()); argv=request['argv']
    values={'--head':HEAD,'--reviewed-prod-manifest':MAN.as_posix(),'--reviewed-prod-manifest-sha256':ref(MAN)['sha256'],
            '--production-review':reviewpath.as_posix(),'--production-review-sha256':ref(reviewpath)['sha256']}
    for flag,value in values.items():
        pos=argv.index(flag)+1; assert argv[pos] is None; argv[pos]=value
    assert all(type(item)is str for item in argv)
    put(O/'CANONICAL-ARGV.actual.json',{'argv':argv,'source_head':HEAD,'production_review':ref(reviewpath),'business_credit':False})
    print(json.dumps({'argv':ref(O/'CANONICAL-ARGV.actual.json'),'review':ref(reviewpath),'production':ref(MAN)}))
if __name__=='__main__': main()
