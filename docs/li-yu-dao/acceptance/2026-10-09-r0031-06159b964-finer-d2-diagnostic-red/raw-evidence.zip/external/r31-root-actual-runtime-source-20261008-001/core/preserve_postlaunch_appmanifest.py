"""Preserve the actual prelaunch/current manifest pair and exact LastPlayed-only delta."""
from pathlib import Path
import argparse,hashlib,json,sys
sys.dont_write_bytecode=True
import prepare_next_formal_cold as cold_helper
from prepare_next_formal_cold import ref,read,put,checked_ref,need,BASE
import postlaunch_appmanifest
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--request',type=Path,required=True);parser.add_argument('--sha256',required=True);parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();request_ref=ref(args.request);need(request_ref['sha256']==args.sha256,'Actual cold request explicit SHA changed')
request=read(args.request);cold_helper.configure_run(request['output'],request['cold_context']['attempt_id'],request['expected_head'])
need(request['schema']==cold_helper.SCHEMA,'Actual newly assigned cold request required')
out=args.output.resolve();need(BASE in out.parents and not out.exists(),'New external delta attempt required');out.mkdir()
try:
    frozen=request['game']['app_manifest'];before=checked_ref(request['prelaunch_app_manifest']).read_bytes()
    need(len(before)==frozen['bytes'] and hashlib.sha256(before).hexdigest()==frozen['sha256'],'Actual preserved prelaunch manifest differs')
    p=Path(frozen['path']);need(p.is_absolute(),'Absolute actual current manifest required')
    for q in (p,*p.parents):need(not q.is_symlink() and not q.is_junction(),'Linked actual manifest refused')
    current=p.read_bytes()
    import re
    pattern=rb'("LastPlayed"\s*")([0-9]+)(")';old=list(re.finditer(pattern,before));new=list(re.finditer(pattern,current))
    need(len(old)==len(new)==1,'One exact LastPlayed scalar required');o,n=old[0],new[0]
    need(before[:o.start(2)]==current[:n.start(2)] and before[o.end(2):]==current[n.end(2):],'Non-LastPlayed appmanifest bytes changed')
    with (out/'APP-MANIFEST.before-preserved.acf').open('xb') as f:f.write(before)
    with (out/'APP-MANIFEST.current-preserved.acf').open('xb') as f:f.write(current)
    proof={'schema':'lyd.r14.exact-appmanifest-lastplayed-only-proof.v1','method':'ACTUAL_PRELAUNCH_PRESERVED_AND_CURRENT_CAPTURE','before_original_capture_available':True,
           'frozen_prelaunch_ref':frozen,'cold_request':request_ref,'actual_prelaunch_preservation':request['prelaunch_app_manifest'],
           'before_preserved':ref(out/'APP-MANIFEST.before-preserved.acf'),'current_preserved':ref(out/'APP-MANIFEST.current-preserved.acf'),
           'changed_vdf_keys':['AppState/LastPlayed'],'before_LastPlayed':int(o.group(2)),'after_LastPlayed':int(n.group(2)),
           'all_other_raw_bytes_equal':True,'game_started_by_this_helper':False,'original_cold_files_modified':False}
    put(out/'APP-MANIFEST-DYNAMIC-DELTA.actual.json',proof)
    postlaunch_appmanifest.prove(frozen,ref(out/'APP-MANIFEST-DYNAMIC-DELTA.actual.json'))
    put(out/'RESULT.json',{'status':'ACTUAL_PRELAUNCH_CURRENT_LASTPLAYED_ONLY_DELTA_PRESERVED','delta':ref(out/'APP-MANIFEST-DYNAMIC-DELTA.actual.json'),'game_started':False,'native_attached':False})
    print(json.dumps(read(out/'RESULT.json'),indent=2))
except Exception as error:
    import traceback
    put(out/'FAILURE.json',{'error':str(error),'traceback':traceback.format_exc(),'attempt_preserved':True,'game_started':False});raise
