"""R12's exact LastPlayed-only allowance for an already launched R14 game."""
from pathlib import Path
import hashlib,json,re
HERE=Path(__file__).resolve().parent
def need(ok,message):
    if not ok:raise ValueError(message)
def checked(row):
    need(type(row) is dict and set(row)=={'path','bytes','sha256'},'Exact appmanifest ref3 required')
    p=Path(row['path']);need(p.is_absolute(),'Absolute appmanifest ref required')
    for q in (p,*p.parents):need(not q.is_symlink() and not q.is_junction(),'Linked appmanifest refused')
    raw=p.read_bytes();need(len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],'Appmanifest evidence bytes/SHA changed')
    return raw
def prove(frozen,receipt):
    proof=json.loads(checked(receipt).decode('utf-8'))
    need(proof['schema']=='lyd.r14.exact-appmanifest-lastplayed-only-proof.v1' and proof['method']=='ACTUAL_PRELAUNCH_PRESERVED_AND_CURRENT_CAPTURE' and proof['before_original_capture_available'] is True,'Actual before/current preservation provenance required')
    need(proof['frozen_prelaunch_ref']==frozen and proof['changed_vdf_keys']==['AppState/LastPlayed'],'Exact frozen prelaunch appmanifest binding required')
    before=checked(proof['before_preserved']);preserved=checked(proof['current_preserved'])
    current=Path(frozen['path']).read_bytes()
    need(current==preserved,'Current Steam manifest changed since exact delta preservation')
    need(len(before)==frozen['bytes'] and hashlib.sha256(before).hexdigest()==frozen['sha256'],'Preserved actual before does not match frozen prelaunch hash')
    pattern=rb'("LastPlayed"\s*")([0-9]+)(")'
    old=list(re.finditer(pattern,before));new=list(re.finditer(pattern,current))
    need(len(old)==len(new)==1,'One exact LastPlayed value required')
    o,n=old[0],new[0]
    # VDF prefix braces place the unique scalar directly inside AppState.
    prefix=current[:n.start()]
    tokens=re.findall(rb'"[^"\r\n]*"|[{}]',prefix)
    stack=[];pending=None
    for token in tokens:
        if token==b'{':stack.append(pending);pending=None
        elif token==b'}':need(bool(stack),'Invalid appmanifest VDF');stack.pop();pending=None
        else:pending=None if pending is not None else token[1:-1]
    need(stack==[b'AppState'],'LastPlayed must be AppState/LastPlayed')
    need(int(o.group(2))==proof['before_LastPlayed'] and int(n.group(2))==proof['after_LastPlayed'],'LastPlayed evidence differs')
    need(before[:o.start(2)]==current[:n.start(2)] and before[o.end(2):]==current[n.end(2):],'Non-LastPlayed appmanifest bytes changed')
    need(re.findall(rb'"buildid"\s*"([0-9]+)"',current)==[b'25734779'] and re.findall(rb'"appid"\s*"([0-9]+)"',current)==[b'1158310'],'Installed app/build changed')
    need(proof['all_other_raw_bytes_equal'] is True,'Exact raw delta proof required')
    return proof
