"""Freeze one explicit formal or normal-exit queue request; never enqueue or call SDK."""
from pathlib import Path
import argparse,hashlib,json,sys,uuid
sys.dont_write_bytecode=True

def need(ok,message):
 if not ok:raise ValueError(message)

def ref(path):
 path=Path(path).resolve();raw=path.read_bytes();return {'path':path.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--consumer-source',type=Path,required=True);p.add_argument('--consumer-index-sha256',required=True)
 p.add_argument('--tool');p.add_argument('--arguments',type=Path);p.add_argument('--operation',choices=['call_tool','list_tools','close'],default='call_tool')
 p.add_argument('--request-id');p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 source=a.consumer_source.resolve();index=source/'INDEX.json';need(ref(index)['sha256']==a.consumer_index_sha256,'Actual frozen formal consumer index changed')
 data=json.loads(index.read_bytes());metadata_ref=data['actual_metadata'];need(ref(metadata_ref['path'])==metadata_ref,'Actual immutable metadata changed')
 metadata=json.loads(Path(metadata_ref['path']).read_bytes());tools_ref=metadata['metadata'];need(ref(tools_ref['path'])==tools_ref,'Actual complete tool inventory changed')
 tools={row['name']:row for row in json.loads(Path(tools_ref['path']).read_bytes())}
 payload={'schema':'ck3.lyd.mcp-request.v1','request_id':a.request_id or ('r18-explicit-'+uuid.uuid4().hex),'operation':a.operation}
 if a.operation=='call_tool':
  need(a.tool in tools and a.arguments is not None,'Actual existing tool and explicit closed argument JSON required')
  args=json.loads(a.arguments.read_bytes());schema=tools[a.tool]['inputSchema'];need(type(args) is dict and schema.get('additionalProperties') is False and set(schema.get('required',[]))<=set(args)<=set(schema.get('properties',{})),'Arguments must contain all actual required SDK keys and only declared properties')
  if 'expected_revision' in args:need(type(args['expected_revision']) is int and 0<args['expected_revision']<2**64,'Actual strict positive uint64 revision required')
  payload.update(name=a.tool,arguments=args)
 else:need(a.tool is None and a.arguments is None,'List/close has no tool arguments')
 sys.path.insert(0,str(source));from persistent_native_mcp_queue_29 import validate_request
 validate_request(payload)
 output=a.output.resolve();need(output.is_relative_to(Path(data['run_root'])) and not output.exists(),'Fresh request file in actual run required')
 output.parent.mkdir(parents=True,exist_ok=True)
 with output.open('x',encoding='utf-8',newline='\n') as f:json.dump(payload,f,ensure_ascii=False,indent=2);f.write('\n')
 print(json.dumps({'request':ref(output),'enqueued':False,'SDK_calls':0,'game_calls':0,'root_next_enqueue_argv':[sys.executable,'-B','-X','utf8',str(source/'persistent_native_mcp_queue_29.py'),'enqueue','--queue','ACTUAL_ROOT_QUEUE_DIRECTORY','--request',str(output)]}));return 0

if __name__=='__main__':raise SystemExit(main())
