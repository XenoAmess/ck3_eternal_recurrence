"""Bind a six-file diagnostic overlay to its real builder manifest and export."""
from pathlib import Path
import json,hashlib,re
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve()
KEY='diagnostic_stage'
OVERRIDE='common/scripted_effects/lyd_i3b_commit_effects.txt'
def need(ok,message):
    if not ok:raise ValueError(message)
def ref(path):
    p=Path(path).resolve();raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(row):
    need(type(row)is dict and set(row)=={'path','bytes','sha256'} and Path(row['path']).suffix.lower()=='.json' and ref(row['path'])==row,'Exact diagnostic JSON ref required')
    return json.loads(Path(row['path']).read_bytes())
def load_binding(row,head):
    d=read(row)
    need(set(d)=={'source_head','source_root','files','package_index','allowed_override_paths','purpose','build_manifest'} and d['purpose']=='SIGNED_B3_STAGED_FACTORY_DIAGNOSTIC_ONLY' and d['source_head']==head,'Explicit actual diagnostic overlay HEAD/role required')
    manifest=read(d['build_manifest']);export=read(manifest['actual_export_report'])
    need(manifest['schema']=='lyd.factory-operation-diagnostic-overlay.v1' and manifest['actual_source_head']==head==export['source']['head'],'Actual overlay builder/export HEAD must match')
    need(manifest['production71_modified']is False and manifest['runtime_acceptance']is None and manifest['diagnostic_business_credit']is None,'Dedicated development overlay only')
    root=Path(d['source_root']).resolve();need(root.is_relative_to(BASE),'External diagnostic mount required')
    need(d['allowed_override_paths']==[OVERRIDE] and type(d['files'])is list and len(d['files'])==6,'Exactly the reviewed six-file diagnostic overlay required')
    need(len({x['path']for x in d['files']})==6 and {OVERRIDE,'descriptor.mod'}<={x['path']for x in d['files']},'Unique diagnostic files and descriptor required')
    package=d['package_index'];need(type(package)is dict and set(package)=={'root','path','bytes','sha256'},'Existing package INDEX shape required')
    package_root=Path(package['root']).resolve();index=read({k:package[k]for k in ('path','bytes','sha256')})
    need(package_root in root.parents and package_root in Path(package['path']).resolve().parents,'Original package_rows containment required')
    by_name={x['path']:x for x in index['files']}
    expected={x['relative_path']:{'path':x['relative_path'],'bytes':x['bytes'],'sha256':x['sha256']}for x in manifest['files']}
    need(expected=={x['path']:x for x in d['files']},'Actual builder manifest must inventory all mounted bytes')
    for item in d['files']:
        need(set(item)=={'path','bytes','sha256'} and type(item['path'])is str and not item['path'].startswith('/') and '..'not in Path(item['path']).parts,'Existing normalized runtime row required')
        file=root/item['path'];actual=ref(file);need(actual['bytes']==item['bytes'] and actual['sha256']==item['sha256'],'Diagnostic mounted bytes changed')
        declared=next(x for x in manifest['files']if x['relative_path']==item['path'])
        need(Path(declared['path']).resolve()==file.resolve(),'Actual builder file path changed')
        relative=file.relative_to(package_root).as_posix();need(by_name.get(relative)=={**item,'path':relative},'Actual package INDEX must inventory diagnostic row')
    return {'source_root':root.as_posix(),'files':d['files'],'package_index':package}
