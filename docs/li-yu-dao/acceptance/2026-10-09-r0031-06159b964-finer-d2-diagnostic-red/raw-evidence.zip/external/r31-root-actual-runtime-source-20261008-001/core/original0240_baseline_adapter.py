"""Original immutable 0240 proof adapter; no save-body reads in check/author."""
from pathlib import Path
import hashlib,json
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve()
SAVE_SHA='1d98f0d2482c02477f460127044690b1df128e806b2ffbfab399e945e3551a1d'
SAVE_BYTES=91669783
ORIGINAL_REQUEST={'path': 'C:/workspace/ck3_lyd_runtime_20261004/r13-root-cold-inputs-20261006-002/REQUEST.actual.json', 'bytes': 62237, 'sha256': 'a7d30b8b72429ee129b6298700781c8443826e06e88b5a30a664822cf02a4419'}
def need(ok,message):
 if not ok:raise ValueError(message)
def checked(row):
 need(type(row) is dict and set(row)=={'path','bytes','sha256'},'Exact actual parsed ref3 required')
 p=Path(row['path']).resolve();need(p.is_relative_to(BASE) and p.suffix.lower()!='.ck3','Only external parsed/source references may be read')
 raw=p.read_bytes();need(len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],'Actual parsed reference changed: '+str(p));return p,raw
def load_packet(row):
 packet=json.loads(checked(row)[1])
 need(set(packet)=={'purpose','checkpoint','legacy_baseline','original_request','original0240_state','formal_acceptance'},'Exact original0240 input fields required')
 need(packet['purpose']=='ORIGINAL_0240_FORMAL_BASELINE' and packet['formal_acceptance'] is None,'Original0240 is a baseline, no formal acceptance')
 need(packet['original_request']==ORIGINAL_REQUEST,'Original sealed request binding differs')
 baseline=json.loads(checked(packet['original_request'])[1])['baseline'];need(packet['legacy_baseline']==baseline,'Original240 proof rows changed')
 checkpoint=packet['checkpoint'];need(set(checkpoint)=={'path','bytes','sha256'} and checkpoint['bytes']==SAVE_BYTES and checkpoint['sha256']==SAVE_SHA and checkpoint=={k:baseline[k] for k in ['path','bytes','sha256']},'Only exact original0240 descriptor admitted')
 p=Path(checkpoint['path']).resolve();need(p.is_relative_to(BASE) and p.stat().st_size==SAVE_BYTES and p.stat().st_file_attributes & 1,'Original0240 must remain immutable/exact size')
 checked(packet['original0240_state']);return packet
def verify_baseline(item,helper):
 need(type(item) is dict and set(item)=={'path','bytes','sha256','original0240_source'},'Exact original0240 baseline required')
 packet=load_packet(item['original0240_source']);need({k:item[k] for k in ['path','bytes','sha256']}==packet['checkpoint'],'Cold baseline descriptor differs')
 old_image=helper.legacy.EXE_SHA
 try:
  helper.legacy.EXE_SHA='94b55397abb687a3dcd436805a5d885e6be90fa6c693feb44a9e3bbeeade02a6'
  baseline,proofs=helper.verify_checkpoint240(packet['legacy_baseline'])
 finally:helper.legacy.EXE_SHA=old_image
 return baseline,{**proofs,'original0240_source':item['original0240_source']}
