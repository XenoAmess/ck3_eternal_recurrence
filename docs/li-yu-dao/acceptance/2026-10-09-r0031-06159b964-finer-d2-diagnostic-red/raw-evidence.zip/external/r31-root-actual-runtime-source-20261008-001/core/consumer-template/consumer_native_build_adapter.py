"""Actual eleven-flag compiled qualifier; no game access."""
from pathlib import Path
import json
import sys
sys.dont_write_bytecode = True
from r14_metadata_common import read_ref, jread
EXPECTED_QUALIFICATION = {'path': 'C:/workspace/ck3_lyd_runtime_20261004/r29-official-metadata-actual-20261008-002/NATIVE-CLEAN-QUALIFICATION.actual.json', 'bytes': 1035641, 'sha256': '874cdab77ae2726a2df8d567429b15422665295077002a7d04116fbdcd452b8d'}
REQUIRED_TARGETS = ('xar_ck3_bridge', 'xar_ck3_bridge_injector', 'xar_confucian_assembly_predicates_v1_test', 'xar_confucian_religious_title_readback_v1_test', 'xar_confucian_challenger_graph_v1_test', 'xar_ck3_main_thread_query_mailbox_v1_test', 'xar_ck3_12002_event_window_context_test', 'xar_ck3_12004_army_route_binding_test')

def validate_actual_r14_build(report, binding, profile):
    actual = jread(read_ref(EXPECTED_QUALIFICATION))
    if report != actual or report.get('source_revision') != binding['source_revision'] or report.get('schema')!='lyd.next-cold.clean-export-native-byte-qualification.grant-numeric.v1' or report.get('grant_title_picker_opt_in') is not True or len(report.get('actual_private_flags_ON',[]))!=12 or set(report.get('actual_products',{}))!=set(REQUIRED_TARGETS) or len(report.get('actual_focused_tests',[]))!=6 or {row['target'] for row in report.get('actual_focused_tests',[])}!=set(REQUIRED_TARGETS[2:]):
        raise ValueError('Actual new native qualifier differs')
    # Actual qualification is an immutable already-verified build-time fact.
    # A later LastPlayed appmanifest change must not reinterpret that build.
    # Current source/guard/postlaunch binding is checked by the consumer/cold path.
    for stamp in actual['actual_products'].values():
        read_ref(stamp)
    read_ref(actual['new_runtime_library'])
    for name in ('dll', 'injector'):
        product = report['native_artifacts'][name]
        row = profile[name]
        if set(row) != {'path', 'sha256'} or Path(row['path']).resolve() != Path(product['path']).resolve() or row['sha256'] != product['sha256']:
            raise ValueError('Native product differs from managed profile: ' + name)
    return actual
