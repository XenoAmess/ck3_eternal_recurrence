'Freeze R29 source/profile writer only after actual new grant28 metadata exists.'
from pathlib import Path
import argparse, ast, hashlib, json, re, sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve()

def need(ok,message):
 if not ok:raise ValueError(message)

def ref(path):
 path=Path(path).resolve();raw=path.read_bytes()
 return {'path':path.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def checked(row):
 need(type(row) is dict and set(row)=={'path','bytes','sha256'},'Exact actual input ref3 required')
 actual=ref(row['path']);need(actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],'Actual input descriptor changed')
 return Path(row['path']).resolve()

def put(path,value):
 raw=value.encode() if type(value) is str else (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
 with path.open('xb') as f:f.write(raw)

def assign(source,name,value):
 pattern=r'^'+name+r' = .+$'
 need(len(re.findall(pattern,source,flags=re.M))==1,'Expected one frozen source pin: '+name)
 literal='Path('+repr(value)+').resolve()' if name=='REPO' else repr(value)
 return re.sub(pattern,name+' = '+literal,source,flags=re.M)

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--metadata-result',type=Path,required=True);p.add_argument('--sha256',required=True)
 p.add_argument('--expected-head',required=True);p.add_argument('--run-directory',type=Path,required=True)
 p.add_argument('--attempt-id',required=True);p.add_argument('--screen-task',required=True)
 p.add_argument('--native-gate',type=Path,required=True);p.add_argument('--native-gate-sha256',required=True)
 for key in ['previous-boundary','previous-boundary-verifier']:
  p.add_argument('--'+key,type=Path,required=True);p.add_argument('--'+key+'-sha256',required=True)
 p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 from prepare_next_formal_cold import configure_run,configure_previous_boundary,configure_adapters,metadata
 metadata_ref=ref(a.metadata_result);need(metadata_ref['sha256']==a.sha256,'Explicit actual metadata SHA differs')
 gate=ref(a.native_gate);need(gate['sha256']==a.native_gate_sha256,'Explicit actual native gate SHA differs')
 closure=ref(a.previous_boundary);need(closure['sha256']==a.previous_boundary_sha256,'Explicit actual previous boundary SHA differs')
 verifier=ref(a.previous_boundary_verifier);need(verifier['sha256']==a.previous_boundary_verifier_sha256,'Explicit actual previous intake SHA differs')
 configure_run(a.run_directory,a.attempt_id,a.expected_head);configure_previous_boundary(closure)
 configure_adapters({'native_gate':gate,'previous_boundary_verifier':verifier})
 m,q=metadata(metadata_ref);export=json.loads(checked(m['actual_export_report']).read_bytes())
 root=Path(export['source_root']).resolve();inventory=json.loads(checked(m['source_inventory']).read_bytes())
 rows={r['path']:r for r in inventory};need(len(rows)==len(inventory),'Distinct complete actual source inventory required')
 for relative in ['tools/ck3_native_profile_mcp.py','ck3_autonomous_player/native_bridge/src/normal_exit_map_source_v1.cpp','ck3_autonomous_player/src/xar_autoplayer/bridge/confucian_readonly_private_v1.py','ck3_autonomous_player/src/xar_autoplayer/bridge/confucian_challenger_graph_v1.py','ck3_autonomous_player/src/xar_autoplayer/bridge/ordinary_interaction_contract.py','ck3_autonomous_player/src/xar_autoplayer/bridge/actor_cached_succession_private_v1.py']:
  row=rows[relative];actual=ref(root/relative);need(actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],'Actual frozen source differs: '+relative)
 need(type(a.screen_task) is str and re.fullmatch('[A-Za-z0-9_.:-]{6,160}',a.screen_task),'Explicit screen task name required; no lease credit')
 output=a.output.resolve();need(output.is_relative_to(BASE) and not output.exists(),'New external consumer source output required')
 output.mkdir(parents=True,exist_ok=False);written=[]
 pins={'REPO':root.as_posix(),'EXPECTED_SOURCE_REVISION':m['head'],
  'EXPECTED_NORMAL_EXIT_CPP_SHA256':rows['ck3_autonomous_player/native_bridge/src/normal_exit_map_source_v1.cpp']['sha256'],
  'EXPECTED_SERVER_SHA256':rows['tools/ck3_native_profile_mcp.py']['sha256'],
  'CONFUCIAN_READONLY_SHA256':rows['ck3_autonomous_player/src/xar_autoplayer/bridge/confucian_readonly_private_v1.py']['sha256'],
  'CONFUCIAN_CHALLENGER_SHA256':rows['ck3_autonomous_player/src/xar_autoplayer/bridge/confucian_challenger_graph_v1.py']['sha256'],
   'ORDINARY_CONTRACT_SHA256':rows['ck3_autonomous_player/src/xar_autoplayer/bridge/ordinary_interaction_contract.py']['sha256'],
  'ACTOR_CACHE_SOURCE_SHA256':rows['ck3_autonomous_player/src/xar_autoplayer/bridge/actor_cached_succession_private_v1.py']['sha256'],
  'EXPECTED_METADATA_RESULT':metadata_ref}
 for path in sorted((HERE/'consumer-template').glob('*.py')):
  code=path.read_text(encoding='utf-8')
  if path.name=='consumer_binding.py':
   for name,value in pins.items():code=assign(code,name,value)
   code=assign(code,'REQUIRED_BUILD_FLAGS',set(q['actual_private_flags_ON']))
  elif path.name=='consumer_native_build_adapter.py':code=assign(code,'EXPECTED_QUALIFICATION',m['native_clean_qualification'])
  elif path.name=='prepare_fresh_native_profile.py':code=assign(code,'REPO',root.as_posix())
  ast.parse(code);target=output/path.name;put(target,code);written.append(ref(target))
 receipt={'status':'ACTUAL_CACHE29_METADATA_BOUND_R29_FORMAL_CONSUMER_SOURCE_ONLY',
  'source_revision':m['head'],'source_export':root.as_posix(),'actual_metadata':metadata_ref,
  'actual_native_qualification':m['native_clean_qualification'],'native_gate':gate,
  'run_root':a.run_directory.resolve().as_posix(),'attempt_id':a.attempt_id,'root_screen_task':a.screen_task,
  'files':written,'queue_helper':ref(output/'persistent_native_mcp_queue_29.py'),
  'profile_freezer':ref(output/'prepare_fresh_native_profile.py'),
  'actual_complete_tool_inventory_count':29,'diagnostic_dispatch_only':False,
  'actual_process_identity':None,'Client_started':False,'native_attached':False,'main_writes':0,
  'SDK_calls':0,'game_calls':0,'bus_calls':0,'process_lookups':0,'formal_acceptance':None}
 put(output/'INDEX.json',receipt);print(json.dumps({'INDEX':ref(output/'INDEX.json'),'queue_helper':receipt['queue_helper'],'profile_freezer':receipt['profile_freezer'],'Client_started':False}));return 0

if __name__=='__main__':raise SystemExit(main())
