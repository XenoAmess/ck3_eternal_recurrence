'R29 formal original0240 cold preparation; no launch or SDK calls.'
from pathlib import Path
from datetime import datetime, timezone
import argparse, ast, hashlib, importlib.util, json, re, sys, traceback, zipfile
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BASE = Path('C:/workspace/ck3_lyd_runtime_20261004').resolve()
ROOT = Path('C:/workspace/ck3_eternal_recurrence').resolve()
RUN = None
EXPECTED_HEAD = None
RUN_NUMBER = None
NAMESPACE = None
CURRENT_BOUNDARY = None
HEAD = None
TASK = None
SCHEMA = None
CONTEXT = {}
LEGACY = BASE / 'r11-continuation-cold-helper-20261006-001/candidate/prepare_r0011_continuation.py'
OLD_REQUEST = BASE / 'r13-root-cold-inputs-20261006-002/REQUEST.actual.json'
ADAPTER_BINDINGS = None
BASELINE_PACKET = None
from signed_B3_diagnostic_baseline_adapter import load_packet, verify_baseline
from diagnostic_overlay_binding import load_binding as load_overlay_binding, KEY as DIAGNOSTIC_KEY, OVERRIDE as DIAGNOSTIC_OVERRIDE
DIAGNOSTIC_OVERLAY = None

def configure_overlay(row, head):
    global DIAGNOSTIC_OVERLAY
    DIAGNOSTIC_OVERLAY = {'input': row, 'fixture': load_overlay_binding(row, head)}

ACTUAL_PREVIOUS_BOUNDARY = None
ACTUAL_PREVIOUS_IDENTITY = None
EXPECTED_PREVIOUS_BOUNDARY = {'path': 'C:/workspace/ck3_lyd_runtime_20261004/r30-root-actual-typed-closed-boundary-20261008-001/PREVIOUS-BOUNDARY.actual.json', 'bytes': 3103, 'sha256': '2944ee5104746377a738ae5c1d625846cdb9bb9691ac5e4ca6504e4162b938da'}
EXPECTED_PREVIOUS_BOUNDARY_VERIFIER = {'path': 'C:/workspace/ck3_lyd_runtime_20261004/r30-root-typed-close-actual-source-20261008-001/verify_previous_boundary.py', 'bytes': 24731, 'sha256': '6239df5be60613f9b39e88ef905880b4652ecd19e5a58c53497d5289af16c510'}

def need(ok, message):
    if not ok: raise ValueError(message)

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def ref(path):
    p=Path(path).resolve();return {'path':p.as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)}

def checked_ref(row):
    need(type(row) is dict and set(row)=={'path','bytes','sha256'},'Exact ref3 required')
    p=Path(row['path']);need(p.is_absolute(),'Absolute ref required')
    for q in (p,*p.parents):need(not q.is_symlink() and not q.is_junction(),'Linked input refused')
    need(type(row['bytes']) is int and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'Input bytes/SHA changed: '+str(p))
    return p.resolve()

def put(path, value):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')

def pinned_module(name,path,expected):
    need(sha(path)==expected,'Successor dependency changed: '+str(path))
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module

def configure_run(run_directory, attempt_id, expected_head):
    global RUN, RUN_NUMBER, EXPECTED_HEAD, HEAD, NAMESPACE, SCHEMA
    need(type(attempt_id) is str and re.fullmatch('R[0-9]{4}',attempt_id),'Actual root allocated attempt ID required')
    number=int(attempt_id[1:]);need(number==31,'Only ROOT allocated R0031 formal original0240 is supported')
    need(type(expected_head) is str and re.fullmatch('[0-9a-f]{40}',expected_head)
         and expected_head not in ('19e660105e05395caa6cc95e76c299312ee89d51','632f0a57a07aa6299052004589ed6f7632e7d8f7','768fd56e6f078c8fc6b1cc669cad71fb2594e3a2'),'Actual new clean main-line HEAD required')
    run=Path(run_directory).resolve()
    need(run.parent==BASE and run.name=='live-attempt-'+str(number).zfill(3),'Run path must exactly match root allocated attempt ID')
    for path in (run,*run.parents):need(not path.is_symlink() and not path.is_junction(),'Linked run path refused')
    RUN=run;RUN_NUMBER=number;EXPECTED_HEAD=expected_head;HEAD=expected_head
    NAMESPACE='lyd.r'+str(number)+'.';SCHEMA=NAMESPACE+'formal-institution-cold-request.v1'
    CONTEXT.clear();CONTEXT.update(attempt_id=attempt_id,output=run.as_posix(),save_basename='lyd_r'+str(number)+'_i3b_signed_B3_diagnostic',root_screen_task=TASK)

def configure_previous_boundary(row):
    global CURRENT_BOUNDARY
    checked_ref(row)
    need(row == EXPECTED_PREVIOUS_BOUNDARY,'Explicit source-pinned actual previous operational boundary required')
    CURRENT_BOUNDARY=row

def production_delta(rows, production):
    old=read(OLD_REQUEST);old_manifest=old['production']['manifest'];old_rows=read(checked_ref(old_manifest))['files']
    before={r['path']:r for r in old_rows};after={r['path']:r for r in rows}
    return {'manifest':old_manifest,'actual_production_manifest':production['manifest'],
            'source_revision':EXPECTED_HEAD,'business_runtime_rows_unchanged':rows==old_rows,
            'complete_changed_paths':[k for k in sorted(set(before)|set(after)) if before.get(k)!=after.get(k)],
            'source_of_new_business_bytes':'ACTUAL_CLEAN_NEW_EXPORT_FORMAL_STAGING'}

def configure_adapters(bindings):
    global ADAPTER_BINDINGS
    need(type(bindings) is dict and set(bindings)=={'native_gate','previous_boundary_verifier'},'Explicit actual native/previous-boundary adapters required')
    for row in bindings.values():checked_ref(row)
    need(bindings['previous_boundary_verifier'] == EXPECTED_PREVIOUS_BOUNDARY_VERIFIER,'Explicit source-pinned previous operational intake required')
    ADAPTER_BINDINGS=bindings

def metadata(row):
    global HEAD,ACTUAL_PREVIOUS_BOUNDARY
    need(ADAPTER_BINDINGS is not None,'Actual adapter bindings must be explicit')
    result=read(checked_ref(row));HEAD=result.get('head')
    need(EXPECTED_HEAD is not None and HEAD==EXPECTED_HEAD,'Actual grant28 metadata must match explicit clean HEAD')
    need(result.get('status')=='ACTUAL_OFFICIAL_CLIENT_METADATA_AND_FRESH_CODE_INVENTORY','Actual official metadata/source required')
    need(result.get('tool_count')==29 and result.get('default_tool_count')==21 and result.get('readonly_tool_count')==23 and result.get('challenger_tool_count')==24 and result.get('private_bundle')=='CONFUCIAN_CHALLENGER_GRANT_ACTOR_CACHE_29' and result.get('actor_cached_succession_opt_in') is True and result.get('grant_tool_count')==28 and result.get('grant_title_picker_opt_in') is True and result.get('factory_opt_in')=={'confucian_readonly_tools':False,'confucian_challenger_tools':True,'player_control_tools':False,'grant_title_picker_tools':True,'actor_cached_succession_tools':True},'Actual grant28/default21/private23/challenger24 metadata factory required')
    for key in ('metadata','default_metadata','readonly_metadata','challenger_metadata','actual_export_report','native_clean_qualification','compiled_verification','previous_boundary'):checked_ref(result[key])
    for key,count in (('metadata',29),('default_metadata',21),('readonly_metadata',23),('challenger_metadata',24),('grant_metadata',28)):
        rows=read(result[key]['path']);need(type(rows) is list and len(rows)==count and len({x['name'] for x in rows})==count,'Actual complete SDK tool inventory changed')
        need(all(x.get('inputSchema',{}).get('additionalProperties') is False for x in rows),'Actual SDK input schemas must remain closed')
    from actor_cache_metadata_semantics import ACTOR_CACHE_TOOL,check_actor_cache_tool
    cache_rows={r['name']:r for r in read(result['metadata']['path'])};grant_rows={r['name']:r for r in read(checked_ref(result['grant_metadata']))}
    need(set(cache_rows)==set(grant_rows)|{ACTOR_CACHE_TOOL} and all(cache_rows[k]==v for k,v in grant_rows.items()),'Exact grant28 plus sole cache alias metadata required')
    check_actor_cache_tool(cache_rows[ACTOR_CACHE_TOOL])
    qualification=read(result['native_clean_qualification']['path'])
    need(qualification.get('schema')=='lyd.next-cold.clean-export-native-byte-qualification.grant-numeric.v1' and qualification.get('status')=='ACTUAL_COMPILED_NATIVE_BYTES_MATCH_ACTUAL_CLEAN_EXPORT' and qualification.get('source_revision')==HEAD and qualification.get('compiled_route')=='CLEAN_HEAD_BUILD' and qualification.get('actual_export_report')==result['actual_export_report'] and qualification.get('grant_title_picker_opt_in') is True,'Actual new grant-numeric clean build qualification required')
    gate_ref=ADAPTER_BINDINGS['native_gate'];gate_path=checked_ref(gate_ref);sys.path.insert(0,str(gate_path.parent))
    gate=pinned_module('r21_actual_native_gate',gate_path,gate_ref['sha256'])
    compiled=read(checked_ref(qualification['compiled_verification']))
    census=compiled['private_option_census'];flags=gate.parsed_flags(checked_ref(qualification['raw_CMakeCache']).read_bytes(),census,True)
    expected=set(gate.enabled_flags(True))
    need(len(expected)==12 and expected==set(qualification['actual_private_flags_ON']) and flags==qualification['actual_flags'] and flags.get('BUILD_TESTING')=='ON' and flags.get('XAR_CK3_ENABLE_PLAYER_CONTROL_PRIVATE_V1')=='OFF','Actual twelve enabled private flags/playerOFF/testingON differ')
    need(set(flags)==set(census['names'])|{'BUILD_TESTING'} and all(flags[name]==('ON' if name in expected else 'OFF') for name in census['names']),'Every actual remaining private option must remain explicitly OFF')
    required_targets=('xar_ck3_bridge', 'xar_ck3_bridge_injector', 'xar_confucian_assembly_predicates_v1_test', 'xar_confucian_religious_title_readback_v1_test', 'xar_confucian_challenger_graph_v1_test', 'xar_ck3_main_thread_query_mailbox_v1_test', 'xar_ck3_12002_event_window_context_test', 'xar_ck3_12004_army_route_binding_test')
    need(compiled.get('schema')=='lyd.next-cold.actual-clean-source-native-build-grant-numeric-army-route.v1','Actual R29 army-route compiled schema required')
    need(set(qualification['actual_products'])==set(required_targets) and len(qualification['actual_focused_tests'])==6 and {row['target'] for row in qualification['actual_focused_tests']}==set(required_targets[2:]),'Actual eight declared products/six declared focused tests required')
    for product in qualification['actual_products'].values():checked_ref(product)
    checked_ref(qualification['new_runtime_library'])
    for product in qualification['native_artifacts'].values():checked_ref(product)
    need(CURRENT_BOUNDARY is not None and result['previous_boundary']==CURRENT_BOUNDARY,'New actual metadata must bind explicit source-pinned previous operational boundary')
    ACTUAL_PREVIOUS_BOUNDARY=CURRENT_BOUNDARY
    return result,qualification

def load_legacy():
    pins=read(HERE/'DEPENDENCIES.json')
    helper=pinned_module('r14_r11_preserved_helper',LEGACY,pins['legacy']['sha256'])
    legacy=helper.legacy
    legacy.RUN=RUN;legacy.REPO=ROOT;legacy.SCHEMA=SCHEMA;legacy.CONTEXT=dict(CONTEXT)
    legacy.EXE_SHA='98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518'
    # The historical0240 checker still validates its original .3 SDK/EXE.
    # Only the live nine-field-profile validator is projected to actual .4.
    guard_source=checked_ref(pins['original_guard_validator_source'])
    guard_tree=ast.parse(guard_source.read_text(encoding='utf-8-sig'))
    guard_defs=[node for node in guard_tree.body if isinstance(node,ast.FunctionDef) and node.name=='validate_guard_review']
    need(len(guard_defs)==1,'Exactly one preserved original eleven-field guard validator required')
    class GuardVersion(ast.NodeTransformer):
        count=0
        def visit_Constant(self,node):
            if node.value=='1.20.0.3':
                self.count+=1;return ast.copy_location(ast.Constant('1.20.0.4'),node)
            return node
    guard_projection=GuardVersion();guard_def=guard_projection.visit(guard_defs[0])
    need(guard_projection.count==1,'Only original live-profile version literal may be projected')
    exec(compile(ast.fix_missing_locations(ast.Module(body=[guard_def],type_ignores=[])),str(guard_source)+'::R29-live-profile-version','exec'),legacy.__dict__)
    current_guard_validator=legacy.validate_guard_review
    need(BASELINE_PACKET is not None,'Explicit actual original0240 formal baseline required')
    legacy.BASELINE=Path(BASELINE_PACKET['checkpoint']['path']);legacy.BASELINE_BYTES=BASELINE_PACKET['checkpoint']['bytes'];legacy.BASELINE_SHA=BASELINE_PACKET['checkpoint']['sha256']
    legacy.SAVE_BASENAME=CONTEXT['save_basename'];legacy.SAVE_RELATIVE='save games/'+legacy.SAVE_BASENAME+'.ck3'
    need(DIAGNOSTIC_OVERLAY is not None, 'Explicit reviewed diagnostic overlay required')
    legacy.FIXTURE_COUNTS={'entry':7,'observer':8,'i4_single_event':31,'charter':6,DIAGNOSTIC_KEY:6}
    def native_meta(item,source):
        result,qualification=metadata(item['metadata_capture_result'])
        need(item['source_revision']==source['head']==result['head'] and item['tool_count']==29 and item['receipt']==result['metadata'],'Cold/challenger24 source differs')
        return item
    def boundary(item):
        global ACTUAL_PREVIOUS_IDENTITY
        need(type(item) is dict and set(item)=={'review'},'Exact actual previous-boundary ref required')
        actual=checked_ref(item['review']);expected=checked_ref(ACTUAL_PREVIOUS_BOUNDARY)
        need(actual==expected and item['review']['bytes']==ACTUAL_PREVIOUS_BOUNDARY['bytes'] and item['review']['sha256']==ACTUAL_PREVIOUS_BOUNDARY['sha256'],'Actual previous R14 boundary required')
        verifier=ADAPTER_BINDINGS['previous_boundary_verifier'];path=checked_ref(verifier);sys.path.insert(0,str(path.parent))
        module=pinned_module('r14_actual_previous_boundary',path,verifier['sha256'])
        checked=module.verify_previous_boundary_v3(item,legacy_context=None)
        module.validate_previous_boundary_limits(checked)
        ACTUAL_PREVIOUS_IDENTITY=checked['actual_prior_identity']
        return checked
    def review_validator(review,inputs,profile,guard):
        need(review.get('schema')==NAMESPACE+'root-live-guard-review.v1','Actual R14 live guard review required')
        checked=current_guard_validator({**review,'schema':'lyd.r10.root-live-guard-review.v1'},inputs,profile,guard)
        helper.semantic.verify_live_semantics(checked,inputs,profile,guard,legacy)
        need(ACTUAL_PREVIOUS_IDENTITY is not None and (review['process_id'],review['process_create_time'])!=(ACTUAL_PREVIOUS_IDENTITY['pid'],ACTUAL_PREVIOUS_IDENTITY['process_create_time']),'Original prior process cannot stand for R14')
        return {**checked,'schema':review['schema']}
    legacy.validate_metadata=native_meta;legacy.verify_next_boundary=boundary;legacy.validate_guard_review=review_validator
    raw=checked_ref(pins['generated']).read_bytes();tree=ast.parse(raw.decode('utf-8-sig'))
    mappings={'1.20.0.3':'1.20.0.4','25652598':'25734779'}
    mappings.update({key:key.replace('lyd.r11.',NAMESPACE,1) for key in ('lyd.r11.root-profile-bound-preparation.v1','lyd.r11.isolated-userdir.v1','lyd.r11.cold-materialized-only.v1')})
    class Projection(ast.NodeTransformer):
        count=0
        def visit_Constant(self,node):
            if type(node.value) is str and node.value in mappings:
                self.count+=1;return ast.copy_location(ast.Constant(mappings[node.value]),node)
            return node
    projection=Projection();tree=projection.visit(tree);need(projection.count==6,'Original generated three schemas/two game versions/buildid seam changed')
    exec(compile(ast.fix_missing_locations(tree),'r14-three-output-schema-projection','exec'),legacy.__dict__)
    return helper,legacy

def postlaunch_appmanifest_proof(frozen,receipt):
    pins=read(HERE/'DEPENDENCIES.json')
    module=pinned_module('r14_postlaunch_appmanifest',pins['postlaunch_appmanifest']['path'],pins['postlaunch_appmanifest']['sha256'])
    module.prove(frozen,receipt)
    return receipt


def configure_task(task):
    global TASK
    need(type(task) is str and re.fullmatch('[A-Za-z0-9_.:-]{6,160}',task),'Explicit actual screen task required')
    TASK=task;CONTEXT['root_screen_task']=task


def make_request(metadata_ref, output, screen_task, adapter_bindings, previous_boundary, baseline_input, diagnostic_overlay):
    global BASELINE_PACKET
    BASELINE_PACKET=load_packet(baseline_input)
    configure_task(screen_task);configure_previous_boundary(previous_boundary);configure_adapters(adapter_bindings)
    result,qualification=metadata(metadata_ref);export=read(result['actual_export_report']['path']);old=read(OLD_REQUEST)
    need(export['source']['head']==HEAD and export['source_clean_before_and_after'] is True,'Actual clean export changed')
    source={k:export['source'][k] for k in ('head','tree','product_tree','native_tree','inventory')}
    production={k:export['build'][k] for k in ('staging','manifest','archive')}
    rows=read(production['manifest']['path'])['files'];old_rows=read(old['production']['manifest']['path'])['files']
    need(len(rows)==71 and len([r for r in rows if r['path']!='descriptor.mod'])==70 and {r['path'] for r in rows}==set(['common/character_interactions/lyd_c2_consent_interactions.txt', 'common/character_interactions/lyd_c3_teacher_interactions.txt', 'common/character_interactions/lyd_i3b_nomination_interactions.txt', 'common/character_interactions/lyd_interactions.txt', 'common/decisions/lyd_c2_consent_decisions.txt', 'common/decisions/lyd_c3_leadership_decisions.txt', 'common/decisions/lyd_decisions.txt', 'common/decisions/lyd_i3b_institution_decisions.txt', 'common/on_action/lyd_c3_lifecycle_on_actions.txt', 'common/religion/faith_types/lyd_faiths.txt', 'common/religion/rite_types/lyd_rites.txt', 'common/religion/tenet_types/lyd_tenets.txt', 'common/script_values/lyd_c2_consent_values.txt', 'common/script_values/lyd_i3b_institution_values.txt', 'common/scripted_effects/lyd_c2_close_effects.txt', 'common/scripted_effects/lyd_c2_commit_effects.txt', 'common/scripted_effects/lyd_c2_head_effects.txt', 'common/scripted_effects/lyd_c2_response_effects.txt', 'common/scripted_effects/lyd_c2_setup_effects.txt', 'common/scripted_effects/lyd_c2_snapshot_effects.txt', 'common/scripted_effects/lyd_c2_vote_effects.txt', 'common/scripted_effects/lyd_c3_challenger_effects.txt', 'common/scripted_effects/lyd_c3_council_effects.txt', 'common/scripted_effects/lyd_c3_head_factory.txt', 'common/scripted_effects/lyd_c3_lifecycle_effects.txt', 'common/scripted_effects/lyd_c3_migration_hooks.txt', 'common/scripted_effects/lyd_entry_effects.txt', 'common/scripted_effects/lyd_i3b_commit_effects.txt', 'common/scripted_effects/lyd_i3b_response_effects.txt', 'common/scripted_effects/lyd_i3b_setup_effects.txt', 'common/scripted_effects/lyd_i3b_terms_effects.txt', 'common/scripted_effects/lyd_practice_10_effects.txt', 'common/scripted_effects/lyd_practice_11_effects.txt', 'common/scripted_effects/lyd_practice_12_effects.txt', 'common/scripted_effects/lyd_practice_13_effects.txt', 'common/scripted_effects/lyd_practice_14_effects.txt', 'common/scripted_effects/lyd_practice_1_effects.txt', 'common/scripted_effects/lyd_practice_2_effects.txt', 'common/scripted_effects/lyd_practice_3_effects.txt', 'common/scripted_effects/lyd_practice_4_effects.txt', 'common/scripted_effects/lyd_practice_5_effects.txt', 'common/scripted_effects/lyd_practice_6_effects.txt', 'common/scripted_effects/lyd_practice_7_effects.txt', 'common/scripted_effects/lyd_practice_8_effects.txt', 'common/scripted_effects/lyd_practice_9_effects.txt', 'common/scripted_effects/lyd_school_2_effects.txt', 'common/scripted_effects/lyd_school_3_effects.txt', 'common/scripted_effects/lyd_school_4_effects.txt', 'common/scripted_effects/lyd_school_5_effects.txt', 'common/scripted_effects/lyd_school_effects.txt', 'common/scripted_triggers/lyd_c2_consent_triggers.txt', 'common/scripted_triggers/lyd_c3_leadership_triggers.txt', 'common/scripted_triggers/lyd_i3b_institution_triggers.txt', 'common/scripted_triggers/lyd_m3_faith_asset_triggers.txt', 'common/scripted_triggers/lyd_player_triggers.txt', 'descriptor.mod', 'events/lyd_c2_consent_events.txt', 'events/lyd_c3_leadership_events.txt', 'events/lyd_events.txt', 'events/lyd_i3b_institution_events.txt', 'history/faiths/lyd_faith_history.txt', 'localization/english/lyd_c2_consent_l_english.yml', 'localization/english/lyd_c3_leadership_l_english.yml', 'localization/english/lyd_content_l_english.yml', 'localization/english/lyd_i3b_institution_l_english.yml', 'localization/english/lyd_runtime_l_english.yml', 'localization/simp_chinese/lyd_c2_consent_l_simp_chinese.yml', 'localization/simp_chinese/lyd_c3_leadership_l_simp_chinese.yml', 'localization/simp_chinese/lyd_content_l_simp_chinese.yml', 'localization/simp_chinese/lyd_i3b_institution_l_simp_chinese.yml', 'localization/simp_chinese/lyd_runtime_l_simp_chinese.yml']),'Actual formal production must retain complete70/runtime69 inventory')
    configure_overlay(diagnostic_overlay, HEAD)
    fixtures={**old['fixtures'], DIAGNOSTIC_KEY:DIAGNOSTIC_OVERLAY['fixture']}
    mount=read(old['combined_preflight']['path'])
    mount['fixtures'][DIAGNOSTIC_KEY]=DIAGNOSTIC_OVERLAY['fixture']
    mount['production_binding'].update(source_revision=HEAD,manifest_sha256=production['manifest']['sha256'],file_count=len(rows))
    put(output.parent/'MOUNT-MANIFEST.actual.json',mount)
    enabled=[]
    for key,item in [('production',production),*fixtures.items()]:
        root=Path(item['staging'] if key=='production' else item['source_root'])
        files=rows if key=='production' else item['files']
        enabled.append({'key':key,'registration':'mod/lyd_'+key+'.mod','source_root':root.as_posix(),'inner_descriptor':ref(root/'descriptor.mod'),'files':files})
    put(output.parent/'ENABLED-SOURCE-INVENTORY.actual.json',{'schema':'lyd.r14.enabled-source-inventory.v1','source_revision':HEAD,'enabled_mods':enabled})
    helper,legacy=load_legacy()
    baseline={**BASELINE_PACKET['checkpoint'],'original0240_source':baseline_input}
    verify_baseline(baseline,helper)
    game=json.loads(json.dumps(old['game']))
    for key in ('executable','launcher_settings','app_manifest'):game[key]=ref(game[key]['path'])
    game['stock_gui']=[ref(row['path']) for row in game['stock_gui']]
    app_raw=checked_ref(game['app_manifest']).read_bytes()
    app_copy=output.parent/'APP-MANIFEST.prelaunch-preserved.acf'
    with app_copy.open('xb') as f:f.write(app_raw)
    need(ref(app_copy)['sha256']==game['app_manifest']['sha256'],'Actual prelaunch manifest changed while preserving')
    request={**old,'schema':SCHEMA,'output':RUN.as_posix(),'source':source,'production':production,'cold_context':CONTEXT,
             'fixtures':fixtures,'diagnostic_overlay':diagnostic_overlay,'diagnostic_mode':True,'root_screen_task':TASK,'expected_head':EXPECTED_HEAD,'previous_boundary':{'review':CURRENT_BOUNDARY},'baseline':baseline,
             'combined_preflight':ref(output.parent/'MOUNT-MANIFEST.actual.json'),
             'enabled_source_inventory':ref(output.parent/'ENABLED-SOURCE-INVENTORY.actual.json'),
             'native_build':{'source_revision':HEAD,'native_tree':source['native_tree'],'receipt':result['native_clean_qualification'],
                             **qualification['native_artifacts'],'compilation_binding':qualification},
             'sdk_metadata':{'source_revision':HEAD,'tool_count':29,'receipt':result['metadata'],'metadata_capture_result':metadata_ref},
             'game':game,'production_comparison':production_delta(rows,production),
             'actual_export_report':result['actual_export_report'],'metadata_capture_result':metadata_ref,'adapter_bindings':adapter_bindings,'prelaunch_app_manifest':ref(app_copy)}
    put(output,request);return {'status':'ACTUAL_NEW_FORMAL_COLD_REQUEST_READY','request':ref(output),'game_launched':False,'prepared':False}

def validate(request, *, fresh=True, postlaunch_delta=None):
    global BASELINE_PACKET
    BASELINE_PACKET=load_packet(request['baseline']['original0240_source'])
    need(request.get('diagnostic_mode') is True, 'Dedicated signed-B3 diagnostic cold request required')
    configure_overlay(request['diagnostic_overlay'], request['expected_head'])
    need(request['fixtures'][DIAGNOSTIC_KEY]==DIAGNOSTIC_OVERLAY['fixture'], 'Actual overlay mount binding changed')
    context=request.get('cold_context',{})
    configure_run(request.get('output'),context.get('attempt_id'),request.get('expected_head'))
    configure_task(request.get('root_screen_task'));configure_previous_boundary(request['previous_boundary']['review']);configure_adapters(request['adapter_bindings'])
    need(request.get('schema')==SCHEMA and request.get('status')=='ROOT_REVIEWED_ACTUAL_COLD_INPUTS','Actual R14 cold request required')
    need(request['cold_context']==CONTEXT and request['output']==RUN.as_posix() and request['root_screen_task']==TASK,'Actual new formal run context changed')
    if fresh:need(not RUN.exists(),'R14 output exists; overwrite refused')
    result,qualification=metadata(request['metadata_capture_result'])
    export=read(result['actual_export_report']['path']);source=request['source'];helper,legacy=load_legacy()
    need(source=={k:export['source'][k] for k in ('head','tree','product_tree','native_tree','inventory')},'Cold source differs from actual new export')
    need(request['actual_export_report']==result['actual_export_report'],'Cold export reference changed')
    inventory=read(checked_ref(source['inventory']));source_rows=legacy.normalized_inventory(inventory['files'])
    inventory_root=legacy.absolute_path(inventory.get('root',str(Path(export['source_root'])/'mod_li_yu_dao')),under=None)
    legacy.verify_inventory(inventory_root,source_rows,exact=True)
    production=request['production'];need(production=={k:export['build'][k] for k in ('staging','manifest','archive')},'Production did not come from actual new export')
    stage=Path(production['staging']);manifest=read(checked_ref(production['manifest']));checked_ref(production['archive'])
    need(manifest['git_sha']==HEAD and manifest['product_id']=='mod_li_yu_dao','Formal production source changed')
    rows=legacy.normalized_inventory(manifest['files']);legacy.verify_inventory(stage,rows,exact=True,runtime=True);legacy.no_gui(rows,'production');legacy.descriptor_text(stage)
    with zipfile.ZipFile(production['archive']['path']) as zipped:
        need(set(zipped.namelist())=={'mod_li_yu_dao/'+r['path'] for r in rows},'Formal archive inventory changed')
        for row in rows:
            raw=zipped.read('mod_li_yu_dao/'+row['path']);need(len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],'Formal archive bytes changed')
    fixtures={};collisions={r['path'].casefold() for r in rows if r['path']!='descriptor.mod'}
    need(list(request['fixtures'])==list(legacy.FIXTURE_COUNTS),'Exact ordered original four fixture mounts required; no handoff mount')
    for key,count in legacy.FIXTURE_COUNTS.items():
        item=request['fixtures'][key];root=legacy.absolute_path(item['source_root'],under=BASE);files=legacy.normalized_inventory(item['files'],count)
        legacy.verify_inventory(root,files,exact=True,runtime=True);legacy.no_gui(files,key);legacy.descriptor_text(root)
        package=legacy.package_rows(item['package_index'],root,files)
        for row in files:
            if row['path']=='descriptor.mod':continue
            name=row['path'].casefold()
            if name in collisions:
                need(key==DIAGNOSTIC_KEY and row['path']==DIAGNOSTIC_OVERRIDE, 'Only the explicit diagnostic commit-effect override is authorized: '+name)
            collisions.add(name)
        fixtures[key]={'source_root':root.as_posix(),'files':files,'package_index':package}
    native=request['native_build'];need(native['source_revision']==HEAD and native['native_tree']==source['native_tree'] and native['receipt']==result['native_clean_qualification']
                                       and native['compilation_binding']==qualification,'Cold native qualifier/source changed')
    for key in ('dll','injector'):need(native[key]==qualification['native_artifacts'][key],'Cold native artifact differs');checked_ref(native[key])
    legacy.validate_metadata(request['sdk_metadata'],source)
    baseline,proofs=verify_baseline(request['baseline'],helper)
    settings=legacy.file_ref(request['settings_reference']);legacy.verify_settings(Path(settings['path']))
    game=request['game'];need(Path(game['root']).resolve()==legacy.GAME,'Installed game root changed')
    for key in ('executable','launcher_settings'):checked_ref(game[key])
    app_copy=checked_ref(request['prelaunch_app_manifest'])
    need(app_copy.stat().st_size==game['app_manifest']['bytes'] and sha(app_copy)==game['app_manifest']['sha256'],'Actual preserved prelaunch manifest differs')
    if postlaunch_delta:postlaunch_appmanifest_proof(game['app_manifest'],postlaunch_delta)
    else:checked_ref(game['app_manifest'])
    need(game['executable']['sha256']==legacy.EXE_SHA and read(game['launcher_settings']['path'])['rawVersion']=='1.20.0.4'
         and re.findall(r'"buildid"\s*"([0-9]+)"',Path(game['app_manifest']['path']).read_text(encoding='utf-8'))==['25734779'],'Installed exact game build changed')
    need(len(game['stock_gui'])==6,'Original ordered six stock GUI files required')
    for name,row in zip(legacy.exit_source.STOCK_GUI_PATHS,game['stock_gui']):
        need(checked_ref(row)==legacy.GAME/'game'/name,'Stock GUI path/order changed')
    previous=legacy.verify_next_boundary(request['previous_boundary'])
    checked_ref(request['normal_exit_protocol'])
    need(request['normal_exit_protocol']['sha256']==legacy.digest(legacy.HERE/'normal_exit_source_inventory_v1.py'),'Original normal exit protocol changed')
    comparison=request['production_comparison'];need(comparison==production_delta(manifest['files'],production),'Actual new production delta binding changed')
    need(len(rows)==71 and len([r for r in rows if r['path']!='descriptor.mod'])==70 and {r['path'] for r in rows}==set(['common/character_interactions/lyd_c2_consent_interactions.txt', 'common/character_interactions/lyd_c3_teacher_interactions.txt', 'common/character_interactions/lyd_i3b_nomination_interactions.txt', 'common/character_interactions/lyd_interactions.txt', 'common/decisions/lyd_c2_consent_decisions.txt', 'common/decisions/lyd_c3_leadership_decisions.txt', 'common/decisions/lyd_decisions.txt', 'common/decisions/lyd_i3b_institution_decisions.txt', 'common/on_action/lyd_c3_lifecycle_on_actions.txt', 'common/religion/faith_types/lyd_faiths.txt', 'common/religion/rite_types/lyd_rites.txt', 'common/religion/tenet_types/lyd_tenets.txt', 'common/script_values/lyd_c2_consent_values.txt', 'common/script_values/lyd_i3b_institution_values.txt', 'common/scripted_effects/lyd_c2_close_effects.txt', 'common/scripted_effects/lyd_c2_commit_effects.txt', 'common/scripted_effects/lyd_c2_head_effects.txt', 'common/scripted_effects/lyd_c2_response_effects.txt', 'common/scripted_effects/lyd_c2_setup_effects.txt', 'common/scripted_effects/lyd_c2_snapshot_effects.txt', 'common/scripted_effects/lyd_c2_vote_effects.txt', 'common/scripted_effects/lyd_c3_challenger_effects.txt', 'common/scripted_effects/lyd_c3_council_effects.txt', 'common/scripted_effects/lyd_c3_head_factory.txt', 'common/scripted_effects/lyd_c3_lifecycle_effects.txt', 'common/scripted_effects/lyd_c3_migration_hooks.txt', 'common/scripted_effects/lyd_entry_effects.txt', 'common/scripted_effects/lyd_i3b_commit_effects.txt', 'common/scripted_effects/lyd_i3b_response_effects.txt', 'common/scripted_effects/lyd_i3b_setup_effects.txt', 'common/scripted_effects/lyd_i3b_terms_effects.txt', 'common/scripted_effects/lyd_practice_10_effects.txt', 'common/scripted_effects/lyd_practice_11_effects.txt', 'common/scripted_effects/lyd_practice_12_effects.txt', 'common/scripted_effects/lyd_practice_13_effects.txt', 'common/scripted_effects/lyd_practice_14_effects.txt', 'common/scripted_effects/lyd_practice_1_effects.txt', 'common/scripted_effects/lyd_practice_2_effects.txt', 'common/scripted_effects/lyd_practice_3_effects.txt', 'common/scripted_effects/lyd_practice_4_effects.txt', 'common/scripted_effects/lyd_practice_5_effects.txt', 'common/scripted_effects/lyd_practice_6_effects.txt', 'common/scripted_effects/lyd_practice_7_effects.txt', 'common/scripted_effects/lyd_practice_8_effects.txt', 'common/scripted_effects/lyd_practice_9_effects.txt', 'common/scripted_effects/lyd_school_2_effects.txt', 'common/scripted_effects/lyd_school_3_effects.txt', 'common/scripted_effects/lyd_school_4_effects.txt', 'common/scripted_effects/lyd_school_5_effects.txt', 'common/scripted_effects/lyd_school_effects.txt', 'common/scripted_triggers/lyd_c2_consent_triggers.txt', 'common/scripted_triggers/lyd_c3_leadership_triggers.txt', 'common/scripted_triggers/lyd_i3b_institution_triggers.txt', 'common/scripted_triggers/lyd_m3_faith_asset_triggers.txt', 'common/scripted_triggers/lyd_player_triggers.txt', 'descriptor.mod', 'events/lyd_c2_consent_events.txt', 'events/lyd_c3_leadership_events.txt', 'events/lyd_events.txt', 'events/lyd_i3b_institution_events.txt', 'history/faiths/lyd_faith_history.txt', 'localization/english/lyd_c2_consent_l_english.yml', 'localization/english/lyd_c3_leadership_l_english.yml', 'localization/english/lyd_content_l_english.yml', 'localization/english/lyd_i3b_institution_l_english.yml', 'localization/english/lyd_runtime_l_english.yml', 'localization/simp_chinese/lyd_c2_consent_l_simp_chinese.yml', 'localization/simp_chinese/lyd_c3_leadership_l_simp_chinese.yml', 'localization/simp_chinese/lyd_content_l_simp_chinese.yml', 'localization/simp_chinese/lyd_i3b_institution_l_simp_chinese.yml', 'localization/simp_chinese/lyd_runtime_l_simp_chinese.yml']),'Actual declared production71/runtime70 inventory changed')
    enabled=read(checked_ref(request['enabled_source_inventory']));need(enabled['source_revision']==HEAD,'Enabled inventory source changed')
    expected=[('production',stage,rows)]+[(k,Path(v['source_root']),v['files']) for k,v in fixtures.items()]
    need(len(enabled['enabled_mods'])==len(expected),'Complete five mount inventory required')
    for item,(key,root,files) in zip(enabled['enabled_mods'],expected):
        need(item['key']==key and Path(item['source_root']).resolve()==root.resolve() and legacy.normalized_inventory(item['files'])==files,'Enabled mount changed');checked_ref(item['inner_descriptor'])
    mount=read(checked_ref(request['combined_preflight']));need(mount['production_binding']['source_revision']==HEAD and mount['production_binding']['manifest_sha256']==production['manifest']['sha256'],'Fixture production binding changed')
    validated={**request,'source':{**source,'files':source_rows,'inventory_root':inventory_root.as_posix()},
               'production':{**production,'files':rows},'fixtures':fixtures,'baseline':{**baseline,**proofs},'previous_boundary':previous}
    return helper,legacy,validated

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    command=parser.add_mutually_exclusive_group(required=True);command.add_argument('--metadata-result',type=Path);command.add_argument('--request',type=Path);command.add_argument('--bind-live-review',type=Path)
    parser.add_argument('--sha256',required=True);parser.add_argument('--output',type=Path);parser.add_argument('--screen-task')
    parser.add_argument('--run-directory',type=Path);parser.add_argument('--attempt-id');parser.add_argument('--expected-head')
    parser.add_argument('--baseline-input',type=Path);parser.add_argument('--baseline-input-sha256')
    parser.add_argument('--diagnostic-overlay',type=Path);parser.add_argument('--diagnostic-overlay-sha256')
    parser.add_argument('--previous-boundary',type=Path);parser.add_argument('--previous-boundary-sha256')
    parser.add_argument('--native-gate',type=Path);parser.add_argument('--native-gate-sha256')
    parser.add_argument('--previous-boundary-verifier',type=Path);parser.add_argument('--previous-boundary-verifier-sha256')
    parser.add_argument('--postlaunch-appmanifest-delta',type=Path);parser.add_argument('--postlaunch-appmanifest-delta-sha256')
    execution=parser.add_mutually_exclusive_group(required=True);execution.add_argument('--check',action='store_true');execution.add_argument('--create',action='store_true')
    args=parser.parse_args();audit=[]
    try:
        path=args.metadata_result or args.request or args.bind_live_review
        reference=ref(path);need(reference['sha256']==args.sha256,'Explicit input SHA changed')
        if args.metadata_result:
            need(args.create and args.output is not None,'Metadata request authoring needs explicit --create --output')
            bindings={}
            for key,path,expected in [('native_gate',args.native_gate,args.native_gate_sha256),('previous_boundary_verifier',args.previous_boundary_verifier,args.previous_boundary_verifier_sha256)]:
                need(path is not None and expected is not None,'Actual adapter path and explicit SHA required');row=ref(path);need(row['sha256']==expected,'Actual adapter explicit SHA changed');bindings[key]=row
            need(args.run_directory is not None and args.attempt_id is not None and args.expected_head is not None,'Actual root run/attempt/new HEAD required')
            configure_run(args.run_directory,args.attempt_id,args.expected_head)
            need(args.previous_boundary is not None and args.previous_boundary_sha256 is not None,'Actual R14 closed boundary path/SHA required')
            previous=ref(args.previous_boundary);need(previous['sha256']==args.previous_boundary_sha256,'Explicit previous boundary SHA changed')
            need(args.baseline_input is not None and args.baseline_input_sha256 is not None,'Explicit actual original0240 baseline input path/SHA required')
            baseline_input=ref(args.baseline_input);need(baseline_input['sha256']==args.baseline_input_sha256,'Actual explicit original0240 baseline changed')
            need(args.diagnostic_overlay is not None and args.diagnostic_overlay_sha256 is not None,'Explicit actual diagnostic overlay input required')
            overlay=ref(args.diagnostic_overlay);need(overlay['sha256']==args.diagnostic_overlay_sha256,'Actual diagnostic overlay input SHA differs')
            result=make_request(reference,args.output.resolve(),args.screen_task,bindings,previous,baseline_input,overlay)
        elif args.request:
            need(args.output is None,'Cold output is fixed by actual request')
            helper,legacy,validated=validate(read(path));before=legacy.git_snapshot(validated['source'],audit)
            if args.create:
                result=legacy.materialize_next_files(validated,path.resolve(),before,audit)
                legacy.verify_next_cold_inventory(read(RUN/'COLD-SOURCE-INVENTORY.json'),validated)
            else:result={'status':'ACTUAL_NEW_FORMAL_COLD_INPUTS_CHECKED_ONLY','prepared':False,'game_launched':False,'source_snapshot':before,'save_body_rehashed':False}
        else:
            need(args.output is not None,'Actual live bind run output required')
            run=args.output.resolve();cold=read(run/'COLD-MATERIALIZED.json');request=read(checked_ref(cold['input_request']))
            configure_run(run,request['cold_context']['attempt_id'],request['expected_head'])
            need(args.postlaunch_appmanifest_delta is not None and args.postlaunch_appmanifest_delta_sha256 is not None,'Actual postlaunch manifest delta path and explicit SHA required')
            delta=ref(args.postlaunch_appmanifest_delta);need(delta['sha256']==args.postlaunch_appmanifest_delta_sha256,'Explicit postlaunch manifest delta SHA changed')
            helper,legacy,validated=validate(request,fresh=False,postlaunch_delta=delta)
            result=legacy.bind_next_profile(path.resolve(),args.sha256,check_only=args.check)
        print(json.dumps(result,ensure_ascii=False,indent=2));return 0
    except Exception as error:
        print(json.dumps({'status':'NEW_FORMAL_COLD_RED','error':str(error),'error_type':type(error).__name__,'traceback':traceback.format_exc(),
                          'partial_attempt_preserved':RUN is not None and RUN.exists(),'game_launched':False,'prepared_credit':False,'git_read_only_commands':audit},ensure_ascii=False,indent=2));return 1

if __name__=='__main__':raise SystemExit(main())
