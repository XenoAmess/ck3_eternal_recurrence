"""Write a reviewed ROOT registration argv only; no bus registration or acquire."""
from pathlib import Path
import argparse,hashlib,json,re,sys

def ref(path):
 path=Path(path).resolve();raw=path.read_bytes();return {'path':path.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def need(ok,message):
 if not ok:raise ValueError(message)

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--expected-head',required=True);p.add_argument('--task-id',required=True)
 p.add_argument('--metadata-result',type=Path,required=True);p.add_argument('--metadata-sha256',required=True)
 p.add_argument('--bus-cli',type=Path,required=True);p.add_argument('--bus-cli-sha256',required=True)
 p.add_argument('--keeper-output',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 need(re.fullmatch('[0-9a-f]{40}',a.expected_head) and re.fullmatch('[A-Za-z0-9_.:-]{6,160}',a.task_id),'Actual clean HEAD and new task name required')
 mref=ref(a.metadata_result);need(mref['sha256']==a.metadata_sha256,'Actual metadata SHA differs');m=json.loads(a.metadata_result.read_bytes())
 need(m['head']==a.expected_head and m['status']=='ACTUAL_OFFICIAL_CLIENT_METADATA_AND_FRESH_CODE_INVENTORY' and m['tool_count']==29 and m['grant_title_picker_opt_in'] is True,'Actual new native qualified official grant28 metadata required before task registration')
 qref=m['native_clean_qualification'];need(ref(qref['path'])==qref,'Actual qualified native bytes changed');q=json.loads(Path(qref['path']).read_bytes())
 need(q['source_revision']==a.expected_head and q['schema']=='lyd.next-cold.clean-export-native-byte-qualification.grant-numeric.v1' and q['status']=='ACTUAL_COMPILED_NATIVE_BYTES_MATCH_ACTUAL_CLEAN_EXPORT' and q['grant_title_picker_opt_in'] is True,'Actual fresh compile qualification required')
 cli=ref(a.bus_cli);need(cli['sha256']==a.bus_cli_sha256.lower(),'Actual source bus CLI SHA differs')
 installed=ref(Path('C:/workspace/.codex-task-bus/bin/codex_task_bus.py'));need(installed['sha256']==cli['sha256'],'Actual installed/source bus CLI must match')
 base=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve();out=a.output.resolve();keeper=a.keeper_output.resolve()
 need(out.is_relative_to(base) and keeper.is_relative_to(base) and not out.exists() and not keeper.exists(),'Fresh external registration argv and keeper output required')
 prefix=[sys.executable,'-B','-X','utf8',str(a.bus_cli.resolve()),'--bus-dir','C:/workspace/.codex-task-bus','--expected-cli-sha256',cli['sha256'].upper()]
 payload={'root_register_argv':prefix+['register','--task',a.task_id,'--repo','C:/workspace/ck3_eternal_recurrence','--summary','R29 formal I3b from immutable signed B3 diagnostic','--next-step','Fresh offline review and signed B3 diagnostic cold full-political control before formal I3b actions','--resource','ck3-screen:acquired'],
  'root_before_register_list_argv':prefix+['list','--stale-after','600'],
  'keeper_argv_prefix':[sys.executable,'-B','-X','utf8',str(Path(__file__).with_name('screen_lease_entry_r0031.py')),'--expected-head',a.expected_head,'--task-id',a.task_id,'--bus-cli-sha256',cli['sha256'],'--output',keeper.as_posix()],
  'keeper_expected_sequence':None,'keeper_sequence_instruction':'Append --expected-sequence only from actual successful registration receipt; never guess or use an old sequence.',
  'source_bus_cli':cli,'installed_bus_cli':installed,'actual_metadata':mref,'actual_native_qualification':qref,
  'executed':False,'registration_credit':None,'lease_credit':None,'SDK_calls':0,'game_calls':0,'bus_calls':0,'process_lookups':0}
 out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('x',encoding='utf-8',newline='\n') as f:json.dump(payload,f,ensure_ascii=False,indent=2);f.write('\n')
 print(json.dumps({'ROOT_argv':ref(out),'registered':False,'keeper_started':False}));return 0

if __name__=='__main__':raise SystemExit(main())
