"""Author original closed consumer binding from actual PREPARED; no Client start."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, subprocess, sys
sys.dont_write_bytecode=True
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve()

def need(ok,message):
 if not ok:raise ValueError(message)

def ref(path):
 path=Path(path).resolve();raw=path.read_bytes();return {'path':path.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def put(path,value):
 with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')

def short(row):return {key:row[key] for key in ['path','sha256']}

def jref(row):
 need(type(row) is dict and set(row)=={'path','bytes','sha256'},'Exact ref3 required')
 actual=ref(row['path']);need(actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],'Actual immutable reference differs')
 return json.loads(Path(row['path']).read_bytes())

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--consumer-source',type=Path,required=True);p.add_argument('--consumer-index-sha256',required=True)
 p.add_argument('--prepared',type=Path,required=True);p.add_argument('--prepared-sha256',required=True)
 p.add_argument('--epoch-id',required=True)
 for name in ['queue-directory','client-output','binding-output','author-output']:p.add_argument('--'+name,type=Path,required=True)
 p.add_argument('--execute-binder',action='store_true');a=p.parse_args()
 source=a.consumer_source.resolve();index_path=source/'INDEX.json'
 need(ref(index_path)['sha256']==a.consumer_index_sha256,'Actual frozen consumer source index changed')
 index=json.loads(index_path.read_bytes());need(index['status']=='ACTUAL_CACHE29_METADATA_BOUND_R29_FORMAL_CONSUMER_SOURCE_ONLY','Actual consumer source freezing required')
 for row in index['files']:
  current=ref(row['path']);need(current['bytes']==row['bytes'] and current['sha256']==row['sha256'],'Frozen consumer source changed')
 m=jref(index['actual_metadata']);q=jref(index['actual_native_qualification'])
 prepared_ref=ref(a.prepared);need(prepared_ref['sha256']==a.prepared_sha256,'Actual PREPARED SHA differs')
 prepared=json.loads(a.prepared.read_bytes());run=Path(index['run_root']).resolve()
 need(a.prepared.resolve()==run/'PREPARED.json' and prepared.get('source_revision')==index['source_revision'],'Actual current run PREPARED required')
 profile_ref=prepared['profile'];profile=jref(profile_ref);guard_ref=prepared['guard'];guard=jref(guard_ref)
 review=prepared['root_actual_live_binding'];need(review['root_screen_task']==index['root_screen_task'],'Actual source screen task differs')
 target={key:guard['target'][key] for key in ['pid','process_create_time']}
 need(target['pid']==review['process_id'] and target['process_create_time']==review['process_create_time'],'Actual profile/review process differs')
 locations=[a.queue_directory.resolve(),a.client_output.resolve(),a.binding_output.resolve(),a.author_output.resolve()]
 need(len(set(locations))==4 and all(x.is_relative_to(run) and not x.exists() for x in locations),'All four new queue/client/binder/author paths must be fresh inside actual run')
 server=Path(index['source_export'])/'tools/ck3_native_profile_mcp.py';cpp=Path(index['source_export'])/'ck3_autonomous_player/native_bridge/src/normal_exit_map_source_v1.cpp'
 binding={'schema':'ck3-root-official-mcp-consumer-binding-v1','epoch_id':a.epoch_id,
  'source_revision':index['source_revision'],'run_root':run.as_posix(),'profile':short(profile_ref),
  'guard':short(guard_ref),'dll':short(q['native_artifacts']['dll']),'metadata':short(m['metadata']),
  'source_inventory':short(m['source_inventory']),'normal_exit_source_inventory':profile['normal_exit_source_inventory'],
  'server':short(ref(server)),'native_build':short(m['native_clean_qualification']),'normal_exit_cpp_sha256':ref(cpp)['sha256'],
  'target':target,'queue_directory':a.queue_directory.resolve().as_posix(),'client_output_directory':a.client_output.resolve().as_posix(),
  'root_prepared':short(prepared_ref),'source_ready':{'metadata_capture_result':index['actual_metadata']},
  'attempt_id':index['attempt_id'],'source_export':index['source_export'],'root_screen_task':index['root_screen_task']}
 sys.path.insert(0,str(source));spec=importlib.util.spec_from_file_location('r21_bound_consumer',source/'consumer_binding.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 need(set(binding)==module.FIELDS,'Original exact closed ROOT binding fields required')
 out=a.author_output.resolve();out.mkdir(parents=True,exist_ok=False);path=out/'ROOT-INPUTS.actual.json';put(path,binding)
 module.load_binding(path,ref(path)['sha256'],profile=profile_ref['path'],queue=a.queue_directory,output=a.client_output,tools=__import__('persistent_native_mcp_queue_29').TOOLS)
 argv=[sys.executable,'-B','-X','utf8',str(source/'prepare_mcp_binding.py'),'--request',str(path),'--request-sha256',ref(path)['sha256'],'--output',str(a.binding_output.resolve())]
 put(out/'BINDER-ARGV.json',{'argv':argv,'executed':a.execute_binder})
 receipt={'status':'ACTUAL_R29_FORMAL_ROOT_INPUTS_READY_NO_CLIENT','prepared':prepared_ref,'request':ref(path),'binder_argv':ref(out/'BINDER-ARGV.json'),'consumer_source_index':ref(index_path),'Client_started':False,'native_attached':False,'SDK_calls':0,'game_calls':0,'bus_calls':0,'main_writes':0,'future_session':None,'formal_acceptance':None}
 if a.execute_binder:
  with (out/'binder.stdout').open('xb') as stdout,(out/'binder.stderr').open('xb') as stderr:result=subprocess.run(argv,stdout=stdout,stderr=stderr)
  receipt.update(binder_actual_exit_code=result.returncode,binder_stdout=ref(out/'binder.stdout'),binder_stderr=ref(out/'binder.stderr'))
  if result.returncode==0:receipt.update(actual_binding=ref(a.binding_output/'ROOT-BINDING.json'),serve_cli=ref(a.binding_output/'serve-cli.json'))
  else:receipt['status']='BINDER_RED_PRESERVED_NO_CLIENT'
 put(out/'RESULT.json',receipt);print(json.dumps(receipt));return 0 if receipt.get('binder_actual_exit_code',0)==0 else 1

if __name__=='__main__':raise SystemExit(main())
