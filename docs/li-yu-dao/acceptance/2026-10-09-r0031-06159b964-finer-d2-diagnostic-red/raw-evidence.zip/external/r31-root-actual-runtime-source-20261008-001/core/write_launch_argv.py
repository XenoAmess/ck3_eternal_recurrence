"""Write structured launch/profile argv from actual cold receipts; never execute."""
from pathlib import Path
import argparse, hashlib, json, sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve();RUN=None
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ref(p):
    p=Path(p).resolve();return {'path':p.as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)}
def check(p,expected):
    p=Path(p).resolve();_require_input(sha(p)==expected, 'Actual explicit SHA changed: '+str(p));return p
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--mode',choices=('preflight','launch','profile-request'),default='launch')
for name in ('offline-review','offline-review-sha256','live-run-id','live-run-id-sha256','keeper-directory','screen-task','profile-freezer','profile-freezer-sha256','helper-output','output'):
    parser.add_argument('--'+name,required=True)
for name in ('pid','hwnd','steam-ui-pid','steam-client-pid'):parser.add_argument('--'+name,type=int)
parser.add_argument('--launch-sha256')
parser.add_argument('--postlaunch-appmanifest-delta');parser.add_argument('--postlaunch-appmanifest-delta-sha256')
parser.add_argument('--run-directory',type=Path,required=True);parser.add_argument('--attempt-id',required=True)
args=parser.parse_args();RUN=args.run_directory.resolve()
import prepare_next_formal_cold as cold_helper

def _require_input(ok, message):
    if not ok:
        raise ValueError(message)

cold_ref=ref(RUN/'COLD-MATERIALIZED.json');cold=read(cold_ref['path']);inputs=read(check(cold['inputs']['path'],cold['inputs']['sha256']))
request=read(check(cold['input_request']['path'],cold['input_request']['sha256']))
cold_helper.configure_run(RUN,args.attempt_id,request['expected_head'])
_require_input(args.attempt_id==request['cold_context']['attempt_id'] and RUN.as_posix()==request['output'], 'Actual assigned run context differs')
_require_input(args.screen_task==inputs['root_screen_task']==request['cold_context']['root_screen_task'], 'Actual screen task differs from prepared cold context')
export=request['actual_export_report'];native=inputs['native_build']['receipt']
for row in (export,native,cold['cold_inventory']):check(row['path'],row['sha256'])
offline=check(args.offline_review,args.offline_review_sha256);identity=check(args.live_run_id,args.live_run_id_sha256)
freezer=check(args.profile_freezer,args.profile_freezer_sha256)
argv=[sys.executable,'-B','-X','utf8',str(HERE/'root_next_formal_launch_profile.py'),args.mode]
values={'run-directory':RUN.as_posix(),'attempt-id':args.attempt_id,'head':inputs['source']['head'],'export-report':export['path'],'export-sha256':export['sha256'],
        'native-build':native['path'],'native-build-sha256':native['sha256'],'cold-sha256':cold_ref['sha256'],
        'cold-inputs-sha256':cold['inputs']['sha256'],'cold-inventory-sha256':cold['cold_inventory']['sha256'],
        'input-request-sha256':cold['input_request']['sha256'],'offline-review':str(offline),'offline-review-sha256':args.offline_review_sha256,
        'keeper-directory':str(Path(args.keeper_directory).resolve()),'live-run-id':str(identity),'live-run-id-sha256':args.live_run_id_sha256,
        'task-bus-sha256':sha(Path('C:/workspace/ck3_eternal_recurrence/tools/codex_task_bus.py')),
        'profile-freezer':str(freezer),'profile-freezer-sha256':args.profile_freezer_sha256,'screen-task':args.screen_task,'output':args.helper_output}
if args.mode=='profile-request':
    for name in ('pid','hwnd','steam_ui_pid','steam_client_pid'):
        value=getattr(args,name);_require_input(type(value) is int and value>0, 'Actual positive process/window identity required')
        values[name.replace('_','-')]=str(value)
    _require_input(args.launch_sha256 and sha(RUN/'launch.json')==args.launch_sha256, 'Actual explicit same-launch SHA required')
    values['launch-sha256']=args.launch_sha256
    _require_input(args.postlaunch_appmanifest_delta and args.postlaunch_appmanifest_delta_sha256, 'Actual postlaunch manifest delta required')
    values['postlaunch-appmanifest-delta']=str(check(args.postlaunch_appmanifest_delta,args.postlaunch_appmanifest_delta_sha256))
    values['postlaunch-appmanifest-delta-sha256']=args.postlaunch_appmanifest_delta_sha256
for name,value in values.items():argv.extend(['--'+name,value])
out=Path(args.output).resolve();_require_input(BASE in out.parents and not out.exists(), 'Fresh external argv file required')
out.parent.mkdir(parents=True,exist_ok=True)
with out.open('x',encoding='utf-8',newline='\n') as f:json.dump({'argv':argv,'cwd':'C:/workspace/ck3_eternal_recurrence','executed':False},f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':'STRUCTURED_ARGV_WRITTEN_NOT_EXECUTED','argv':ref(out),'cold':cold_ref,'profile_freezer':ref(freezer),'game_started':False},indent=2))
