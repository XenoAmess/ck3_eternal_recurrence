"""A sealed withdrawn-state continuation; original0240 intake stays unchanged.

This module reads existing bounded JSON, and only stats the CK3 file. The cold
producer retains its exact source/destination SHA check during the new copy.
"""
from pathlib import Path
import hashlib,json,re
import original0240_baseline_adapter as original

BASE=original.BASE
SCHEMA='lyd.withdrawal-cold-resume-input.v1'
PURPOSE='WITHDRAWN_ROUND_COLD_RESUME'
SAVE_SHA='5501caf084a7cc6058c63d5b540e54dd2770596a51184f340a36aa0e593205fe'
SAVE_BYTES=91670781
FIELDS={'schema','purpose','checkpoint','capture','materializer_input','author_input',
        'author_result','state','typed_protection','qualified_native','provenance',
        'original0240_control','readback_source_head','formal_acceptance'}

def need(ok,message):
    if not ok:raise ValueError(message)

def read_ref(row):
    need(type(row)is dict and set(row)=={'path','bytes','sha256'},'Exact existing JSON ref3 required')
    need(type(row['bytes'])is int and 0<row['bytes']<=8*1024*1024,'Bounded positive JSON bytes required')
    need(type(row['sha256'])is str and re.fullmatch('[0-9a-f]{64}',row['sha256']),'Exact JSON SHA required')
    path=Path(row['path']).resolve()
    need(path.is_relative_to(BASE) and path.suffix.lower()=='.json','Only external small JSON may be read')
    data=path.read_bytes()
    need(len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],'Frozen withdrawal JSON changed: '+str(path))
    return json.loads(data)

def validate_clean_withdrawn_state(state):
    need(state.get('schema')=='lyd.i3b.checkpoint-observations.v1','Existing actual saved-state schema required')
    need(state.get('checkpoint_sha256')==SAVE_SHA,'Actual withdrawn checkpoint STATE binding differs')
    need(state.get('actual_pass')is None and state.get('formal_mandate_credit')is None,'Withdrawal cannot imply formal credit')
    need(state.get('round')=={'serial':1,'nonce':2,'phase':None,'result_code':None},'Only actual withdrawn R1 S1/N2 state is admitted')
    identity=state['identity']
    need(identity['actor_id']==31254 and identity['faith_id']==107 and identity['main_rite_id']==169,'Original0240 actor/Faith/main Rite differs')
    retained={'lyd_i3b_serial','lyd_i3b_nonce','lyd_i3b_faith','lyd_i3b_main'}
    variables=state['actor']['variables']
    need({name for name in variables if name.startswith('lyd_i3b_')}==retained,'Actual actor withdrawal cleanup differs')
    for key,kind,value in [('lyd_i3b_serial','value','1'),('lyd_i3b_nonce','value','2')]:
        row=variables[key]
        need(row.get('present')is True and row.get('tick')is None and row.get('type')==kind and row.get('number')==value,'Actual persistent serial/nonce differs')
    for key,kind,value in [('lyd_i3b_faith','faith','107'),('lyd_i3b_main','rite','169')]:
        row=variables[key]
        need(row.get('present')is True and row.get('tick')is None and row.get('type')==kind and row.get('identity')==value,'Actual retained Faith/Rite differs')
    need(all(not any(name.startswith('lyd_i3b_') for name in rite['variables']) for rite in state['rites']),'Actual Rite owner/delegate/ballot stamps remain')
    roster=state['roster']
    need(roster['whole_world_living_records_scanned']is True and roster['faith_classification_complete']is True and not roster['unclassified_living_ids'],'Complete original living Faith roster required')
    for member in roster['members']:
        stamps={name for name in member['variables'] if name.startswith('lyd_i3b_')}
        need(stamps in (set(),retained),'Actual member owner/vote/consent stamps remain')
        if stamps:
            need(member['variables']==variables,'Only the existing actor persistent state may remain in roster')
    return state

def validate_resume_packet(packet):
    need(type(packet)is dict and set(packet)==FIELDS and packet['schema']==SCHEMA and packet['purpose']==PURPOSE,'Closed withdrawal resume packet required')
    need(packet['formal_acceptance']is None,'Withdrawn state is not formal acceptance')
    checkpoint=packet['checkpoint']
    need(type(checkpoint)is dict and set(checkpoint)=={'path','bytes','sha256'} and checkpoint['bytes']==SAVE_BYTES and checkpoint['sha256']==SAVE_SHA,'Only the actual preserved withdrawal descriptor is admitted')
    source=Path(checkpoint['path']).resolve()
    need(source.is_relative_to(BASE) and source.suffix.lower()=='.ck3' and source.stat().st_size==SAVE_BYTES,'Existing exact-size withdrawal copy required; save is not read here')
    capture=read_ref(packet['capture']);inputs=read_ref(packet['materializer_input'])
    request=read_ref(packet['author_input']);result=read_ref(packet['author_result'])
    state=read_ref(packet['state']);typed=read_ref(packet['typed_protection'])
    qualified=read_ref(packet['qualified_native']);provenance=read_ref(packet['provenance'])
    control=read_ref(packet['original0240_control'])
    need(re.fullmatch(r'lyd\.r[1-9][0-9]*\.root-preserved-withdrawal-capture\.v1',capture.get('schema','')),'Actual independently labeled withdrawal capture required')
    need(capture['actual_immutable_copy']==checkpoint and capture['inputs']==packet['materializer_input'] and capture['exact_copy_stream_passes']==1 and capture['save_parser_scans']==0,'Actual one-stream immutable capture/input binding differs')
    need(inputs['preserved_checkpoint']==checkpoint and inputs['window']=='baseline' and inputs['author_output']==str(Path(packet['author_result']['path']).parent).replace('\\','/'),'Existing withdrawal compact readback request differs')
    need(request['window']=='baseline' and request['preserved_checkpoint']==checkpoint,'Existing author INPUT withdrawal copy differs')
    need(result['status']=='ACTUAL_COMPACT_NATIVE_SAVED_OBSERVATIONS_JOINED' and result['save_body_reads']==1 and result['strict_formal_reader_executed']is False and result['actual_pass']is None,'One completed compact readback with no formal credit required')
    for key in ('author_input','state','typed_protection','qualified_native','provenance'):
        need(packet[key]in result['outputs'],'Actual readback output lies outside RESULT inventory: '+key)
    head=packet['readback_source_head']
    need(type(head)is str and re.fullmatch('[0-9a-f]{40}',head) and head==request['expected_source_head']==provenance['source_head'],'Actual completed readback source HEAD differs')
    need(result['source_refs']['profile']['path']==request['profile'] and result['source_refs']['checkpoint_receipt']==inputs['checkpoint']['native_receipt'],'Actual profile/checkpoint readback provenance differs')
    for key in ('G2','G3'):
        need(result['source_refs'][key+'_receipt']==inputs[key]['native_receipt'],'Actual same-checkpoint '+key+' binding differs')
    need(typed['protection_checks_match']is True and len(typed['checks'])==87 and all(row['matches']is True for row in typed['checks']),'All original0240 87 protections must match')
    need(qualified['G2_status']=='BOUND_COMPLETE_NATIVE_OBSERVATION','Existing complete native observation required')
    need(control['schema'].endswith('.original0240-baseline-control.v1'),'Original comparison CONTROL required')
    original_input=read_ref(control['author_input'])
    original_result=read_ref(control['author_result'])
    original_typed=read_ref(control['typed_protection'])
    need(original_input['original_baseline']==request['original_baseline'] and original_result['save_body_reads']==1,'Original comparison baseline must remain exact')
    need(original_typed['protection_checks_match']is True and len(original_typed['checks'])==87 and all(row['matches']is True for row in original_typed['checks']),'Original CONTROL 87 protections must remain exact')
    validate_clean_withdrawn_state(state)
    need(state['identity']['session_id']==provenance['session_id'] and state['identity']['pid']==provenance['game_pid'],'Actual withdrawal saved/runtime provenance differs')
    return packet

def load_packet(row):
    packet=read_ref(row)
    if packet.get('purpose')!=PURPOSE:
        return original.load_packet(row)
    return validate_resume_packet(packet)

def verify_baseline(item,helper):
    need(type(item)is dict and set(item)=={'path','bytes','sha256','original0240_source'},'Existing cold baseline reference shape required')
    packet=load_packet(item['original0240_source'])
    if packet.get('purpose')!=PURPOSE:
        return original.verify_baseline(item,helper)
    need({key:item[key] for key in ('path','bytes','sha256')}==packet['checkpoint'],'Cold copy descriptor differs from sealed withdrawal packet')
    baseline={**packet['checkpoint'],'check_only_save_hash':'ACTUAL_CAPTURE_SDK_READER_PROOF_ONLY_EXACT_COPY_SHA_REQUIRED_AT_CREATE'}
    proofs={key:packet[key] for key in ('capture','author_result','state','typed_protection','qualified_native','original0240_control')}
    proofs.update(withdrawal_resume_source=item['original0240_source'],baseline_purpose=PURPOSE,
        withdrawn_round={'serial':1,'nonce':2,'phase':None},formal_acceptance=None)
    return baseline,proofs
