"""Pure allocated-run same-launch evidence binding. Future facts come from actual receipts."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,math,re
HEAD=None
TASK=None
NAMESPACE=None
def run_namespace(run):
    match=re.fullmatch(r"live-attempt-([0-9]{3,})",Path(run).name)
    need(match is not None and int(match[1])>14,"Actual allocated next formal run directory required")
    number=int(match[1]);namespace="lyd.r"+str(number)+"."
    need(Path(run).name=="live-attempt-"+str(number).zfill(3) and NAMESPACE==namespace,"Bound cold/run namespace differs")
    return namespace
KEYS={'prelaunch_check','process_readback','offline_review','offline_frame','offline_image','launch_attempt'}
def need(value,message):
    if not value:raise ValueError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def ref_read(row):
    need(type(row) is dict and set(row)=={'path','bytes','sha256'},'Exact actual lifecycle file ref3 required')
    path=Path(row['path']).resolve();raw=path.read_bytes()
    need(type(row['bytes']) is int and len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'].lower(),'Actual lifecycle bytes/SHA changed: '+str(path))
    return path,raw
def interval(captured,created):
    need(type(created) in (int,float) and math.isfinite(created),'Actual game creation time required')
    stamp=datetime.fromisoformat(captured.replace('Z','+00:00'));need(stamp.tzinfo is not None,'Actual timezone capture required')
    lag=created-stamp.timestamp();need(0<=lag<=600,'Capture not within 600 seconds before actual creation');return lag
def bind_prelaunch_offline(run,launch_sha,review_path,review,frame_path,frame,pid,steam_ui_pid,steam_client_pid):
    run=Path(run).resolve();namespace=run_namespace(run);launch_path=run/'launch.json';raw=launch_path.read_bytes()
    need(type(launch_sha) is str and hashlib.sha256(raw).hexdigest()==launch_sha.lower(),'Explicit actual R12 launch SHA changed')
    launch=json.loads(raw)
    need(launch.get('schema')==namespace+'root-launch-profile-helper.v1' and launch.get('source_revision')==HEAD
         and launch.get('mode')=='launch' and launch.get('status')=='GAME_CREATED_REQUIRES_NATIVE_LOAD_READBACK'
         and launch.get('game_create_attempted') is True and launch.get('game_started') is True and launch.get('pid')==pid,'Actual same allocated-run successful launch required')
    evidence=launch.get('prelaunch_evidence');need(type(evidence) is dict and set(evidence)==KEYS,'Actual launch must preserve closed prelaunch evidence refs')
    resolved={key:ref_read(row) for key,row in evidence.items()}
    attempt=json.loads(resolved['launch_attempt'][1]);pre=json.loads(resolved['prelaunch_check'][1]);probe=json.loads(resolved['process_readback'][1])
    output=Path(attempt['helper_output']).resolve();need(run in output.parents and resolved['launch_attempt'][0]==(run/'launch-attempt.json').resolve(),'Actual R12 output/attempt escaped run')
    need(resolved['prelaunch_check'][0]==output/'prelaunch-check.json' and resolved['process_readback'][0]==output/'process-readback.json','Actual prelaunch evidence paths differ')
    need(json.loads((output/'RESULT.json').read_bytes())==launch and launch['argv']==attempt['argv']==pre['launch']['argv'],'Actual successful result/argv binding differs')
    need(pre['source']['head']==HEAD and pre['cold']['schema']==namespace+'cold-materialized-only.v1'
         and pre['fresh_owner']['task']['task_id']==TASK,'Actual prelaunch source/cold/task binding differs')
    need(attempt['live_run_identity']==pre['live_run_identity'] and launch['execution_id']==pre['live_run_identity']['execution_id']
         and launch['live_run_id']==pre['live_run_identity']['run_id'],'Actual fresh R12 identity differs')
    need(resolved['offline_review'][0]==Path(review_path).resolve() and json.loads(resolved['offline_review'][1])==review==pre['offline_review']
         and resolved['offline_frame'][0]==Path(frame_path).resolve() and json.loads(resolved['offline_frame'][1])==frame==pre['offline'],'Only original exact prelaunch review/frame admitted after launch')
    need(review.get('steam_offline_confirmed') is True and frame.get('moving_edge_changed') is True and frame.get('steam_pid')==steam_ui_pid,'Actual reviewed moving offline frame required')
    image=resolved['offline_image'][0]
    need(image==(Path(review_path).parent/review['image']).resolve()==Path(frame['moved_path']).resolve()
         and sha(image)==review['image_sha256'].lower()==frame['moved_sha256'].lower(),'Original reviewed image SHA differs')
    lag=interval(frame['captured_at_utc'],launch['process_create_time']);captured=datetime.fromisoformat(frame['captured_at_utc'].replace('Z','+00:00')).timestamp()
    rows={}
    for role,expected,names in (('steam_ui',steam_ui_pid,{'steam.exe','steamwebhelper.exe'}),('steam_client',steam_client_pid,{'steam.exe'})):
        matches=[row for row in probe['processes'] if row.get('pid')==expected]
        need(len(matches)==1 and Path(matches[0]['exe']).name.lower() in names and matches[0]['create_time']<=captured,'Actual prelaunch '+role+' identity differs')
        rows[role]=matches[0]
    return {'schema':namespace+'original-prelaunch-offline-lifecycle-binding.v1','actual_launch_pid':launch['pid'],
            'actual_launch_create_time':launch['process_create_time'],'actual_launch_argv':launch['argv'],
            'original_capture_utc':frame['captured_at_utc'],'capture_to_actual_creation_seconds':lag,
            'current_capture_age_seconds':datetime.now(timezone.utc).timestamp()-captured,'capture_timestamp_restamped':False,
            'steam_ui':rows['steam_ui'],'steam_client':rows['steam_client'],'actual_evidence_refs':evidence,
            'live_process_observed_by_this_pure_binding':False}
