"""ROOT-only new formal I3b preflight/one cold launch and fresh original nine-field profile request.

Authoring this helper does not execute it. No GUI input/OCR/Steam/Defender
policy operations or task-bus mutations exist. ROOT invokes launch explicitly.
"""
from __future__ import annotations
import prepare_next_formal_cold as cold_helper
from prepare_next_formal_cold import validate, metadata, CONTEXT, postlaunch_appmanifest_proof
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, os, subprocess, sys, traceback
sys.dont_write_bytecode = True
ROOT = Path('C:/workspace/ck3_eternal_recurrence')
BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
RUN = None
RUN_NUMBER = None
HEAD = None
TASK = None
BUS = ROOT / 'tools/codex_task_bus.py'
BUS_SHA = None
EXPORT = None
BUILD = None
EXE = Path('C:/Program Files (x86)/Steam/steamapps/common/Crusader Kings III/binaries/ck3.exe')
EXE_SHA = '98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518'
SAVE_SHA = '1d98f0d2482c02477f460127044690b1df128e806b2ffbfab399e945e3551a1d'
FIELDS = {'schema_version', 'guard_profile', 'guard_profile_sha256', 'userdir', 'state_directory', 'evidence_directory', 'game_version', 'dll', 'injector'}
FREEZER = Path(__file__).parent / 'prepare_fresh_native_profile_r12.py'
LIFECYCLE_SHA = 'd1f7d14b6aae9aee3d6320197a0b12c0d65481c81faf87635e2a56007962e87f'
COLD_SOURCE_PACKAGE = BASE / 'r12-final-join-reload-source-route-20261006-003'
COLD_SOURCE_PINS = {'ACTUAL-CLOSURE-BINDING.json': '24695124f0f02b48d595e59a8a46ad8bcb32296eae40e4eb7ea51c53c32032a7', 'APP-MANIFEST-DYNAMIC-DELTA.json': 'b609ef7130ebbac6506f627d6b27468272cb165f78b871b92d2a7fa41d83b931', 'APP-MANIFEST.before-hashbound-reconstructed.acf': '1fc933e0c664eb6a3f9a013bcf04783e3c36fc2c68f543bc48227dd03f023fca', 'APP-MANIFEST.current-preserved.acf': '45af46898a4776875428122bbbb351a7b78526d09959e060d7ce7adea8682dac', 'BASELINE103-PINS.json': '8bd9c8d7d0e7519782a7feb23ba176ac3c1ef801f567b2e80dbcde8c0714cb84', 'DEPENDENCIES.json': 'a3e6ddc5b905dbbadf25a11dfa6e761f96d3ba9382e6fa01e17cfc4e6b97aad0', 'prepare_r12_cold_reload.py': '4665c27c75124a8cd2365897b804143f7437dfcd0e0fa08f1751a4877c9198c1', 'r12_baseline103.py': '7e2e80b9aca88bd26a3080dc9668349431945fd57bd4c4e8b8e73ca76e2ea532', 'README.md': '86ce659eaea8f6fea76e9fdb4d141a576fcf01bbf3fad0b6c9e30156253f8455', 'RELOAD-EXPECTED.actual.json': '3d647478e01cea60d29f56baf8356e3c7a76a5c992a42b5197c8afbaa332c6f9', 'REQUEST.actual.json': '4b0984ceff400edc3d0681626d530b24a8736416c88e6dcd5b68d06d553e9d17', 'REQUEST.pending.json': 'f4384af53b6152e9a45d0f677b4460b00877cba01ed1d36e6f43d99068388828', 'REVISION-ONLY-DELTA.json': '79fdaaf372dc8a84760e5ad84cf7826860e4ebb601ae24d2351fccaa32fb74e2', 'ROOT-COLD-CHECK-ARGV.actual.json': '69d5466767ec7b5364ef46a9decc440094f21c731448a5230bae76c5a7e92d22', 'ROOT-COLD-CREATE-ARGV.actual.json': '0fa8af7ba9bd62c312d19aa015a2fde261b29693d8511e72b707153b1f92c4dd', 'ROOT-LAUNCH-INPUTS.pending.json': '7ab03647217bd0ec693266c0b47e510e889afae74817fbed8f7ee4073984b055', 'ROOT-LIVE-BIND-CHECK-ARGV.pending.json': 'ac2a8d66459f4215d59fa4859f1498e895289e0967744e8f84f2e7ca9a9f769c', 'ROOT-LIVE-BIND-CREATE-ARGV.pending.json': 'bd9c1657f08ff1320cb775c4ed366df07df1d384d617995a01462fda9a4cef1e', 'SOURCE-REVISION.json': '81567016b18a54835373218a9b2df8b0ba8214c08dd6c251a09da93ba496529b', 'write_r12_actual_request.py': 'a4b068baed6826af7a1b995325d9f797a7343ced0d1d143cb1cb05393605d246'}
REFERENCE = BASE / 'live-attempt-007/reviewed-actions-reference-only.json'
REFERENCE_IMAGE_SHA = '835bad86ce18931e7fe6245146ee63a9e6643e637b961d1b177758473da6f601'

def require(ok, reason):
    if not ok:
        raise RuntimeError(reason)

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def write(path, obj):
    with Path(path).open('x', encoding='utf-8', newline='\n') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.write('\n')

def pin(path, expected):
    path = Path(path).resolve()
    require(len(expected) == 64 and digest(path) == expected, 'Input SHA changed: ' + str(path))
    return path

def file_ref(row, role='absolute_file_reference'):
    require(type(row) is dict and {'path', 'bytes', 'sha256'} <= set(row), 'Invalid actual file reference at ' + role + '; expected path/bytes/sha256')
    try:
        p = pin(row['path'], row['sha256'])
    except Exception as error:
        raise RuntimeError('Invalid actual file reference at ' + role + ': ' + str(error)) from error
    require(type(row['bytes']) is int and p.stat().st_size == row['bytes'], 'File size changed at ' + role + ': ' + str(p))
    return p

def mounted_file_ref(row, root, role):
    require(type(row) is dict and set(row) == {'relative_path', 'bytes', 'sha256'}, 'Invalid mounted row at ' + role + '; expected exact relative_path/bytes/sha256')
    relative = row['relative_path']
    require(type(relative) is str and relative and ('\\' not in relative) and (':' not in relative), 'Invalid relative path at ' + role)
    parsed = PurePosixPath(relative)
    require(not parsed.is_absolute() and parsed.as_posix() == relative and all((part not in ('.', '..') for part in parsed.parts)), 'Unsafe relative path at ' + role)
    root = Path(root).resolve()
    path = (root / relative).resolve()
    require((RUN / 'content').resolve() in root.parents and root in path.parents, 'Mounted row escapes actual isolated content at ' + role)
    require(type(row['bytes']) is int and row['bytes'] >= 0, 'Declared bytes missing/invalid at ' + role)
    try:
        path = pin(path, row['sha256'])
    except Exception as error:
        raise RuntimeError('Mounted bytes/SHA differ at ' + role + ': ' + str(error)) from error
    require(path.stat().st_size == row['bytes'], 'Mounted size changed at ' + role + ': ' + str(path))
    return path

def command(argv):
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=45)
    require(result.returncode == 0, 'Read-only command failed: ' + result.stderr.decode('utf-8', 'replace'))
    return result.stdout

def source_snapshot():
    head = command(['git', 'rev-parse', 'HEAD']).decode().strip()
    status = command(['git', 'status', '--porcelain=v1', '--untracked-files=all']).decode()
    require(head == HEAD and (not status), 'Assigned exact clean HEAD changed')
    return {'head': head, 'status': status}

def runtime_reference(path):
    path = Path(path).resolve()
    return {'path': path.as_posix(), 'bytes': path.stat().st_size, 'sha256': digest(path)}

def process_probe():
    import psutil, win32gui, win32process
    rows = []
    windows = []
    for p in psutil.process_iter(['pid', 'name', 'exe', 'create_time', 'cmdline']):
        if (p.info['name'] or '').lower() in ('ck3.exe', 'steam.exe', 'steamwebhelper.exe', 'crashreporter.exe'):
            rows.append(p.info)

    def collect(hwnd, _):
        if win32gui.IsWindowVisible(hwnd):
            thread, pid = win32process.GetWindowThreadProcessId(hwnd)
            if any((row['pid'] == pid for row in rows)):
                windows.append({'hwnd': hwnd, 'pid': pid, 'thread': thread, 'title': win32gui.GetWindowText(hwnd), 'class': win32gui.GetClassName(hwnd), 'rect': list(win32gui.GetWindowRect(hwnd))})
    win32gui.EnumWindows(collect, None)
    return {'utc': datetime.now(timezone.utc).isoformat(), 'processes': rows, 'windows': windows, 'foreground_hwnd': win32gui.GetForegroundWindow()}

def offline_inputs(args):
    import psutil
    review_path = pin(args.offline_review, args.offline_review_sha256)
    review = read(review_path)
    require(review.get('steam_offline_confirmed') is True, 'Fresh actual visual Steam offline review required')
    image = (review_path.parent / review['image']).resolve()
    require(type(review.get('image_sha256')) is str and digest(image) == review['image_sha256'].lower(), 'Reviewed fresh image bytes changed')
    receipt_path = (review_path.parent / review['fresh_frame_receipt']).resolve()
    receipt = read(receipt_path)
    require(receipt.get('schema') == 'ck3.steam_fresh_desktop_frame.v1' and receipt.get('moving_edge_changed') is True, 'Fresh Steam window movement evidence absent')
    require(Path(receipt['moved_path']).resolve() == image and type(receipt.get('moved_sha256')) is str and (receipt['moved_sha256'].lower() == digest(image)), 'Reviewed image does not bind the moved fresh frame')
    captured = datetime.fromisoformat(receipt['captured_at_utc'].replace('Z', '+00:00'))
    require(captured.tzinfo is not None, 'Steam capture requires timezone')
    age = (datetime.now(timezone.utc) - captured).total_seconds()
    if args.mode in ('preflight','launch'):
        require(-10 <= age <= 600, 'Steam fresh frame older than ten minutes before launch')
    else:
        pin(Path(__file__).parent / 'offline_launch_lifecycle.py', LIFECYCLE_SHA)
        sys.path.insert(0, str(Path(__file__).parent))
        import offline_launch_lifecycle
        offline_launch_lifecycle.HEAD = HEAD
        offline_launch_lifecycle.TASK = TASK
        offline_launch_lifecycle.NAMESPACE = cold_helper.NAMESPACE
        from offline_launch_lifecycle import bind_prelaunch_offline
        require(type(args.launch_sha256) is str, 'Explicit actual R12 launch SHA required after launch')
        lifecycle = bind_prelaunch_offline(RUN, args.launch_sha256, review_path, review, receipt_path, receipt, args.pid, args.steam_ui_pid, args.steam_client_pid)
        game = psutil.Process(args.pid)
        require(game.create_time() == lifecycle['actual_launch_create_time'] and Path(game.exe()).resolve() == EXE.resolve(), 'Original launched game PID/create/exe changed')
        require([str(x).replace('\\', '/') for x in game.cmdline()] == [str(x).replace('\\', '/') for x in lifecycle['actual_launch_argv']], 'Original launched game argv changed')
        for role in ('steam_ui', 'steam_client'):
            row = lifecycle[role]
            current = psutil.Process(row['pid'])
            require(current.create_time() == row['create_time'] and Path(current.exe()).resolve() == Path(row['exe']).resolve(), 'Original prelaunch ' + role + ' process identity changed')
    require('requires a new fresh review' not in str(review.get('evidence_scope', '')).lower(), 'Offline review excludes actual launch')
    ui = psutil.Process(receipt['steam_pid'])
    require(ui.create_time() <= captured.timestamp(), 'Steam UI process replaced after capture')
    require(Path(ui.exe()).name.lower() in ('steam.exe', 'steamwebhelper.exe'), 'Fresh frame PID is not Steam UI')
    return (review_path, review, receipt_path, receipt)

def keeper_and_owner(args, out):
    keeper = Path(args.keeper_directory).resolve()
    require(BASE.resolve() in keeper.parents and not keeper.is_symlink() and not keeper.is_junction(), 'Explicit external keeper directory required')
    require(not any(((keeper / n).exists() for n in ('STOP.request', 'ROOT_STOP_REQUIRED.json', 'FINAL.json'))), 'Keeper stopped or requests root stop')
    admitted = read(keeper / 'ADMITTED.json')
    ready = read(keeper / 'READY.json')
    require(ready.get('lease', {}).get('task_id') == TASK and ready['lease'].get('checkout_head') == HEAD, 'R11 keeper ready proof differs')
    require(admitted.get('task_id', admitted.get('lease', {}).get('task_id')) in (None, TASK), 'Keeper admission belongs to another task')
    require(digest(BUS) == BUS_SHA, 'Current source bus SHA differs')
    installed = Path('C:/workspace/.codex-task-bus/bin/codex_task_bus.py')
    require(digest(installed) == BUS_SHA, 'Installed task bus SHA differs')
    argv = [sys.executable, str(BUS), '--bus-dir', 'C:/workspace/.codex-task-bus', '--expected-cli-sha256', BUS_SHA.upper(), 'list', '--stale-after', '600']
    raw = command(argv)
    packet = json.loads(raw)
    require(packet.get('schema') == 'codex.task_bus.v1' and packet.get('ok') is True, 'Actual read-only task list failed')
    rows = [row for row in packet.get('tasks', []) if row.get('task_id') == TASK]
    require(len(rows) == 1, 'Assigned screen task missing')
    sys.path.insert(0, str(ROOT / 'promo/ck3_native_war_ai/integration'))
    from screen_bus_lease import checked_owner
    owner = checked_owner(packet['tasks'], TASK, rows[0]['last_sequence'], ROOT, HEAD)
    packet['task'] = owner
    packet['root_readback_projection'] = 'exact sole-owner row from actual list; no mutation or registration claim'
    path = out / 'fresh-screen-owner-list.json'
    write(path, packet)
    return (path, packet)

def common(args, out):
    g = globals()
    require = g['require']
    read = g['read']
    pin = g['pin']
    file_ref = g['file_ref']
    ACTUAL_HEAD = g['HEAD']
    export = read(pin(g['EXPORT'], args.export_sha256))
    build = read(pin(g['BUILD'], args.native_build_sha256))
    require(g['HEAD'] == ACTUAL_HEAD and export['source']['head'] == ACTUAL_HEAD and (export['source_clean_before_and_after'] is True), 'Actual R14 clean export required')
    cold = read(pin(RUN / 'COLD-MATERIALIZED.json', args.cold_sha256))
    require(cold.get('schema') == cold_helper.NAMESPACE+'cold-materialized-only.v1' and cold.get('status') == 'COLD_MATERIALIZED_NOT_ATTACHABLE' and (cold.get('source_revision') == ACTUAL_HEAD) and (cold.get('prepared') is False) and (cold.get('game_launched') is False), 'Actual R14 cold materialization required')
    require(not (RUN / 'PREPARED.json').exists(), 'Fresh cold flow must not have been bound previously')
    for key, expected in (('inputs', args.cold_inputs_sha256), ('cold_inventory', args.cold_inventory_sha256), ('input_request', args.input_request_sha256)):
        require(cold[key]['sha256'] == expected, 'Cold ' + key + ' SHA changed')
        file_ref(cold[key])
    inputs = read(cold['inputs']['path'])
    request = read(cold['input_request']['path'])
    manifest_delta = None
    if args.mode == 'profile-request':
        require(args.postlaunch_appmanifest_delta is not None and args.postlaunch_appmanifest_delta_sha256 is not None, 'Actual postlaunch manifest delta path/SHA required')
        delta_path = Path(args.postlaunch_appmanifest_delta).resolve()
        manifest_delta = {'path': delta_path.as_posix(), 'bytes': delta_path.stat().st_size, 'sha256': args.postlaunch_appmanifest_delta_sha256}
        file_ref(manifest_delta)
    helper, legacy, validated = validate(request, fresh=False, postlaunch_delta=manifest_delta)
    require(inputs == validated, 'Cold INPUTS differ from actual R14 source/native request')
    require(request['cold_context'] == CONTEXT and request['root_screen_task'] == g['TASK'], 'Actual R14 context changed')
    metadata_result, qualified = metadata(request['metadata_capture_result'])
    require(build == qualified and inputs['native_build']['receipt']['sha256'] == args.native_build_sha256 and (Path(inputs['native_build']['receipt']['path']).resolve() == g['BUILD']), 'Cold did not consume actual new clean qualifier')
    require(request['actual_export_report']['sha256'] == args.export_sha256 and Path(request['actual_export_report']['path']).resolve() == g['EXPORT'], 'Cold/export binding changed')
    require(cold['baseline']['bytes']==cold_helper.BASELINE_PACKET['checkpoint']['bytes'] and cold['baseline']['sha256']==cold_helper.BASELINE_PACKET['checkpoint']['sha256'],'Wrong actual original0240 formal source')
    require(file_ref(cold['baseline']) == (RUN / ('userdir/save games/'+CONTEXT['save_basename']+'.ck3')).resolve(), 'Cold save target changed')
    inventory = read(cold['cold_inventory']['path'])
    legacy.verify_next_cold_inventory(inventory, inputs, allow_settings_update=args.mode == 'profile-request')
    launch = read(RUN / 'launch-argv.json')
    expected = [str(g['EXE']), '-debug_mode', '-gdpr-compliant', '-userdir=' + (RUN / 'userdir').as_posix(), '-loadsave=' + CONTEXT['save_basename']]
    require([x.replace('\\', '/') for x in launch['argv']] == [x.replace('\\', '/') for x in expected] and cold['launch_argv'] == launch['argv'], 'Cold actual launch argv changed')
    require(Path(launch['cwd']).resolve() == g['EXE'].parent.resolve() and g['digest'](g['EXE']) == g['EXE_SHA'], 'Installed game EXE/cwd changed')
    identity = read(pin(args.live_run_id, args.live_run_id_sha256))
    require(identity.get('schema') == 'xar.ck3-live-run-identity.v1' and identity.get('mod_key') == 'li-yu-dao' and (type(identity.get('sequence')) is int) and (identity['sequence'] == RUN_NUMBER) and identity.get('execution_id'), 'Fresh actual R14 identity required')
    require(Path(args.live_run_id).resolve() == (RUN / 'live-run-id.json').resolve(), 'R14 identity path changed')
    review_path, review, offline_path, offline = g['offline_inputs'](args)
    lease_path, lease = g['keeper_and_owner'](args, out)
    snap = g['source_snapshot']()
    return {'postlaunch_appmanifest_delta': manifest_delta, 'source': snap, 'native_compilation_binding': qualified, 'native_original_wrapper_exit_code': qualified['original_outer_exit_code'], 'native_compile_exit_code': None, 'native_defender_original': qualified['Defender'], 'cold': cold, 'launch': launch, 'live_run_identity': identity, 'offline_review_path': str(review_path), 'offline_review': review, 'fresh_frame_receipt': str(offline_path), 'offline': offline, 'fresh_owner_receipt': str(lease_path), 'fresh_owner': lease}

def startup_readback():
    rows = []
    userdir = RUN / 'userdir'
    for relative in ('logs/system.log', 'logs/error.log', 'logs/game.log', 'logs/debug.log', 'crashes'):
        path = userdir / relative
        if path.is_file():
            rows.append({'relative_path': relative, 'exists': True, 'bytes': path.stat().st_size, 'sha256': digest(path)})
        elif path.is_dir():
            rows.append({'relative_path': relative, 'exists': True, 'entries': [str(p.relative_to(userdir)) for p in sorted(path.rglob('*')) if p.is_file()]})
        else:
            rows.append({'relative_path': relative, 'exists': False, 'bytes': None, 'sha256': None})
    return {'schema': cold_helper.NAMESPACE+'independent-startup-files-readback.v1', 'utc': datetime.now(timezone.utc).isoformat(), 'actual_files': rows, 'loaded_baseline_business_verified': False, 'expected_future_native_actor': 31254, 'expected_future_native_faith': 107, 'expected_future_native_main_rite': 169, 'startup_or_error_log_is_not_native_load_credit': True}

def validate_native_template(template, targets):
    require(type(template) is dict and set(template) == FIELDS, 'Preserve original exact nine-field managed profile projection')
    for key in ('dll', 'injector'):
        reference = template[key]
        require(type(reference) is dict and set(reference) == {'path', 'sha256'}, 'Template artifact requires exact path/SHA fields')
        expected = targets[key]
        require(type(reference['path']) is str and type(reference['sha256']) is str and (Path(reference['path']).resolve() == Path(expected['path']).resolve()) and (reference['sha256'].lower() == expected['sha256'].lower()), 'Template artifact identity differs from actual Release build')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('preflight', 'launch', 'profile-request'))
    for name in ('head', 'export-report', 'native-build', 'task-bus-sha256'):
        parser.add_argument('--' + name, required=True)
    for name in ('export-sha256', 'native-build-sha256', 'cold-sha256', 'cold-inputs-sha256', 'cold-inventory-sha256', 'input-request-sha256', 'offline-review', 'offline-review-sha256', 'keeper-directory', 'live-run-id', 'live-run-id-sha256', 'output'):
        parser.add_argument('--' + name, required=True)
    for name in ('pid', 'hwnd', 'steam-ui-pid', 'steam-client-pid'):
        parser.add_argument('--' + name, type=int)
    parser.add_argument('--launch-sha256')
    parser.add_argument('--profile-freezer', required=True)
    parser.add_argument('--profile-freezer-sha256', required=True)
    parser.add_argument('--screen-task', required=True)
    parser.add_argument('--run-directory',type=Path,required=True)
    parser.add_argument('--attempt-id',required=True)
    parser.add_argument('--postlaunch-appmanifest-delta')
    parser.add_argument('--postlaunch-appmanifest-delta-sha256')
    args = parser.parse_args()
    global HEAD, EXPORT, BUILD, BUS_SHA, FREEZER, FREEZER_SHA, TASK, RUN, RUN_NUMBER
    import re
    require(re.fullmatch('[0-9a-f]{40}', args.head) is not None and args.head != '632f0a57a07aa6299052004589ed6f7632e7d8f7', 'Actual new clean R14 HEAD required')
    require(re.fullmatch('[0-9a-f]{64}', args.task_bus_sha256) is not None, 'Actual final source bus SHA required')
    TASK = args.screen_task
    require(re.fullmatch('[A-Za-z0-9_.:-]{6,160}', TASK) is not None, 'Explicit actual screen task required')
    FREEZER = Path(args.profile_freezer).resolve()
    FREEZER_SHA = args.profile_freezer_sha256
    cold_helper.configure_run(args.run_directory,args.attempt_id,args.head)
    RUN=cold_helper.RUN;RUN_NUMBER=cold_helper.RUN_NUMBER
    HEAD = args.head
    EXPORT = Path(args.export_report).resolve()
    BUILD = Path(args.native_build).resolve()
    BUS_SHA = args.task_bus_sha256
    pin(FREEZER,FREEZER_SHA)
    require(BASE.resolve() in EXPORT.parents and BASE.resolve() in BUILD.parents, 'Actual new export/build receipt paths must be external BASE')
    out = Path(args.output).resolve()
    require(RUN.resolve() in out.parents and (not out.exists()), 'Choose a fresh R11 output directory')
    out.mkdir(parents=True)
    result = {'schema': cold_helper.NAMESPACE+'root-launch-profile-helper.v1', 'utc': datetime.now(timezone.utc).isoformat(), 'mode': args.mode, 'source_revision': HEAD, 'game_create_attempted': False, 'game_started': False, 'native_injected': False, 'bus_mutation': False, 'input_sent': False}
    try:
        actual = common(args, out)
        before = process_probe()
        write(out / 'process-readback.json', before)
        if args.mode == 'preflight':
            require(not any(((row['name'] or '').lower() in ('ck3.exe','crashreporter.exe') for row in before['processes'])), 'Existing game prevents new formal preflight')
            require(not (RUN/'launch.json').exists() and not (RUN/'launch-attempt.json').exists(),'Existing launch attempt prevents preflight')
            write(out/'prelaunch-check.json',actual)
            result.update(status='ACTUAL_NEW_FORMAL_PREFLIGHT_ONLY_NO_GAME',run_directory=RUN.as_posix(),attempt_id=CONTEXT['attempt_id'],original_HANDLE_retention='ROOT creates and retains new keeper/Client HANDLEs at their actual starts; no future receipt inferred',loaded_baseline_business_verified=False)
        elif args.mode == 'launch':
            require(not any(((row['name'] or '').lower() in ('ck3.exe', 'crashreporter.exe') for row in before['processes'])), 'Existing CK3/crash reporter prevents new managed launch')
            require(not (RUN / 'launch.json').exists() and (not (RUN / 'launch-attempt.json').exists()), 'Launch already attempted; do not replay')
            write(out / 'prelaunch-check.json', actual)
            captured = datetime.fromisoformat(actual['offline']['captured_at_utc'].replace('Z', '+00:00'))
            require(captured.tzinfo is not None and -10 <= (datetime.now(timezone.utc) - captured).total_seconds() <= 600, 'Original reviewed proof expired immediately before R12 creation')
            proof = {'prelaunch_check': runtime_reference(out / 'prelaunch-check.json'), 'process_readback': runtime_reference(out / 'process-readback.json'), 'offline_review': runtime_reference(actual['offline_review_path']), 'offline_frame': runtime_reference(actual['fresh_frame_receipt']), 'offline_image': runtime_reference(Path(actual['offline_review_path']).parent / actual['offline_review']['image'])}
            write(RUN / 'launch-attempt.json', {'utc': datetime.now(timezone.utc).isoformat(), 'helper_output': str(out), 'argv': actual['launch']['argv'], 'live_run_identity': actual['live_run_identity'], 'status': 'CREATE_PENDING', 'prelaunch_evidence': proof})
            result['prelaunch_evidence'] = {**proof, 'launch_attempt': runtime_reference(RUN / 'launch-attempt.json')}
            result['game_create_attempted'] = True
            with (RUN / 'ck3-stdout.txt').open('xb') as stdout, (RUN / 'ck3-stderr.txt').open('xb') as stderr:
                proc = subprocess.Popen(actual['launch']['argv'], cwd=actual['launch']['cwd'], env={**os.environ, 'PYTHONIOENCODING': 'utf-8'}, stdout=stdout, stderr=stderr)
            result.update(game_started=True, pid=proc.pid)
            import psutil
            observed = psutil.Process(proc.pid)
            require(Path(observed.exe()).resolve() == EXE.resolve(), 'Created PID is not exact current CK3 EXE')
            result.update(status='GAME_CREATED_REQUIRES_NATIVE_LOAD_READBACK', game_started=True, pid=proc.pid, process_create_time=observed.create_time(), argv=actual['launch']['argv'], live_run_id=actual['live_run_identity']['run_id'], execution_id=actual['live_run_identity']['execution_id'])
            write(RUN / 'launch.json', result)
        else:
            require(all((type(getattr(args, n)) is int and getattr(args, n) > 0 for n in ('pid', 'hwnd', 'steam_ui_pid', 'steam_client_pid'))), 'profile-request requires actual positive PID/HWND/Steam PIDs')
            launch = read(RUN / 'launch.json')
            require(launch.get('source_revision') == HEAD and launch.get('pid') == args.pid and (launch.get('game_started') is True), 'Actual newly launched R11 PID receipt absent')
            import psutil, win32gui, win32process
            process = psutil.Process(args.pid)
            require(process.create_time() == launch['process_create_time'] and Path(process.exe()).resolve() == EXE.resolve(), 'R11 PID/create-time changed')
            require(win32process.GetWindowThreadProcessId(args.hwnd)[1] == args.pid and win32gui.IsWindowVisible(args.hwnd), 'HWND is not actual R12 visible game window')
            require(win32gui.GetForegroundWindow() == args.hwnd, 'ROOT must already have actual game HWND foreground before freezing')
            require(args.steam_ui_pid == actual['offline']['steam_pid'], 'Steam UI PID differs from freshly reviewed frame')
            require(Path(psutil.Process(args.steam_client_pid).exe()).name.lower() == 'steam.exe', 'Actual Steam client PID required')
            template = read(RUN / 'native-profile.UNBOUND.template.json')
            validate_native_template(template, read(BUILD)['native_artifacts'])
            write(out / 'independent-startup-readback.json', startup_readback())
            pin(FREEZER, args_freezer_sha())
            actions = read(REFERENCE)
            require(set(actions) == {'reviewed_new_game_reference'}, 'Actual immutable reference-only action dictionary changed')
            action = actions['reviewed_new_game_reference']
            require(action['source_sha256'] == REFERENCE_IMAGE_SHA and digest(action['source_image']) == REFERENCE_IMAGE_SHA, 'Old reviewed reference bytes changed')
            actions_path = out / 'reviewed-actions-reference-only.json'
            write(actions_path, actions)
            request = {'schema': 'ck3.lyd.fresh-profile-request.v1', 'pid': args.pid, 'hwnd': args.hwnd, 'steam_ui_pid': args.steam_ui_pid, 'steam_client_pid': args.steam_client_pid, 'offline_review': actual['offline_review_path'], 'offline_image_sha256': actual['offline_review']['image_sha256'], 'lease_receipt': actual['fresh_owner_receipt'], 'screen_task_id': TASK, 'task_bus_script': str(BUS), 'task_bus_sha256': BUS_SHA, 'native_template': str(RUN / 'native-profile.UNBOUND.template.json'), 'actions_file': str(actions_path), 'output': str(out / 'native-profile-fresh-001')}
            request_path = out / 'native-profile-request.json'
            write(request_path, request)
            result.update(status='FRESH_NINE_FIELD_PROFILE_REQUEST_READY_FREEZER_NOT_RUN', request=str(request_path), request_sha256=digest(request_path), next_argv=[sys.executable, '-B', '-X', 'utf8', str(FREEZER), '--request', str(request_path)], guard_action_scope='immutable actually reviewed reference-only data; desktop action server must not be run', guard_review_offline_field='For later cold helper bind-live-review, fresh_steam_offline_review must reference guard.steam.offline_evidence (the fresh frame receipt), not this wrapper offline-review JSON')
        write(out / 'RESULT.json', result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except Exception as error:
        result.update(status='RED', error_type=type(error).__name__, error=str(error), error_traceback=traceback.format_exc(), retry_authorization=False)
        write(out / 'RESULT.json', result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 1

def args_freezer_sha():
    return FREEZER_SHA
if __name__ == '__main__':
    raise SystemExit(main())
