"""R24 R2 actual SDK capture intake. No prior save parse or 87-check credit.

The existing original0240 and compact-readback branches remain exact imports.
This source only reads bounded historical JSON; cold create owns the hash copy.
"""
from pathlib import Path
from hashlib import sha256
import json,re
import withdrawal_resume_baseline_adapter as previous
BASE=previous.BASE
RUN=BASE/'live-attempt-024'
CLIENT=RUN/'mcp-client-002'
SCHEMA='lyd.withdrawal-sdk-capture-cold-resume-input.v1'
PURPOSE='WITHDRAWN_ROUND_COLD_RESUME'
SAVE_SHA='3b1f6e9326780f7c95a3ddf85f5d2346c7d7ac6c194524081ce6e5363da21bdb'
SAVE_BYTES=91671419
KEYS={'schema','purpose','checkpoint','preservation','responses','prepared','client_session','attached_binding','comparison_control','prior_source_head','saved_body_parse_reads','saved_state_and_87_validation','formal_acceptance'}
STEMS={'round_query':'0037-r24-044-cancel-event-query','withdraw':'0038-r24-045-withdraw-r2','checkpoint':'0039-r24-046-withdraw-save','G2':'0040-r24-047-withdraw-g2','G3':'0041-r24-048-withdraw-g3'}
def need(ok,message):
    if not ok:raise ValueError(message)
def ref(path):
    p=Path(path).resolve();need(p.is_relative_to(BASE) and p.suffix=='.json','Only existing external JSON; never save body')
    need(0<p.stat().st_size<=8*1024*1024,'Bounded JSON required');raw=p.read_bytes()
    return {'path':p.as_posix(),'bytes':len(raw),'sha256':sha256(raw).hexdigest()}
def read(row):
    need(type(row)is dict and set(row)=={'path','bytes','sha256'} and ref(row['path'])==row,'Exact immutable JSON ref3 required')
    return json.loads(Path(row['path']).read_bytes())
def pair(response_row,stem):
    need(Path(response_row['path']).resolve()==CLIENT/(stem+'.response.json'),'Only actual R2 preserved response admitted')
    response=read(response_row)
    need(response['status']=='MCP_RESULT_RECORDED' and response.get('is_error')is not True and len(response['native_receipts'])==1,'One completed official SDK/native response required')
    request=read(ref(response['request_path']));need(ref(response['request_path'])['sha256']==response['request_sha256'] and request['request_id']==response['request_id'] and request['operation']=='call_tool','Exact actual request/response binding')
    row=response['native_receipts'][0];original=Path(row['path']).resolve();copy=(CLIENT/row['copy']).resolve();sdkpath=(CLIENT/response['sdk_result']).resolve()
    need(original.is_relative_to(RUN/'native-evidence') and copy.is_relative_to(CLIENT) and sdkpath.is_relative_to(CLIENT),'Actual original native and Client preserved paths')
    native_ref=ref(original);need(native_ref['sha256']==ref(copy)['sha256']==row['sha256'] and ref(sdkpath)['sha256']==response['sdk_result_sha256'],'Actual original/copy/SDK SHA equality')
    native=read(native_ref);sdk=read(ref(sdkpath));texts=[json.loads(item['text'])for item in sdk['content']if item.get('type')=='text']
    need(sdk['isError']is False and sdk['structuredContent']==native and texts==[native],'Exact SDK structured/text/native equality')
    need(native['schema']=='ck3.native-profile-receipt.v1' and Path(native['receipt_path']).resolve()==original,'Exact native receipt schema/path')
    return request,native,native_ref
def validate_packet(packet):
    need(type(packet)is dict and set(packet)==KEYS and packet['schema']==SCHEMA and packet['purpose']==PURPOSE,'Closed R2 SDK capture-only packet required')
    need(packet['saved_body_parse_reads']==0 and packet['saved_state_and_87_validation']is None and packet['formal_acceptance']is None,'No saved parser/87/formal credit before new cold author')
    checkpoint=packet['checkpoint'];need(type(checkpoint)is dict and set(checkpoint)=={'path','bytes','sha256'} and checkpoint['path']==(RUN/'checkpoints/R2-withdrawn/checkpoint.ck3').as_posix() and checkpoint['bytes']==SAVE_BYTES and checkpoint['sha256']==SAVE_SHA,'Only actual preserved R2 withdrawal descriptor')
    need(Path(checkpoint['path']).stat().st_size==SAVE_BYTES,'Existing preserved checkpoint size; hash copy deferred to ROOT create')
    preservation=read(packet['preservation']);need(preservation['preserved']==checkpoint and preservation['saved_body_parse_reads']==0 and preservation['formal_acceptance']is None,'Original capture-only preservation boundary')
    prepared=read(packet['prepared']);session=read(packet['client_session']);binding=read(packet['attached_binding']);control=read(packet['comparison_control'])
    need(packet['prior_source_head']==session['source_revision']==prepared['source_revision'] and re.fullmatch('[0-9a-f]{40}',packet['prior_source_head']),'Actual prior source HEAD only; no future relabel')
    need(session['client_session_id']==binding['client_session_id'] and session['profile_sha256']==binding['profile_sha256']==prepared['profile']['sha256'],'Actual historical Client/profile/attach binding')
    need(control['schema']=='lyd.r24.original0240-baseline-control.v1','Original0240 comparison CONTROL retained, not R2 parse credit')
    need(type(packet['responses'])is dict and set(packet['responses'])==set(STEMS),'Exactly the five existing withdrawal/query/save/G2/G3 responses')
    pairs={key:pair(packet['responses'][key],stem)for key,stem in STEMS.items()};natives={key:row[1]for key,row in pairs.items()}
    for native in natives.values():need(native['session_id']==binding['native_session_id'] and native['profile_sha256']==session['profile_sha256'],'Same actual prior native session/profile')
    context=natives['round_query']['result']['current_event_window_context'];need(context['status']=='available' and context['event_definition_key']=='lyd.430','Actual R2 query context')
    scopes={row['name']:row['scope']for row in context['saved_scopes']}
    for name,number in [('lyd_i3b_event_serial',2),('lyd_i3b_event_nonce',4),('lyd_i3b_event_phase',2)]:
        value=scopes[name]['numeric_value'];need(value['integer_value']==str(number) and value['scale']==100000 and value['raw_fixed_point']==str(number*100000),'Actual R2 scope numeric value')
    withdrawal=natives['withdraw'];selection=withdrawal['result']['event_selection']
    need(withdrawal['status']=='native_gameplay_postcondition_verified' and selection['postcondition_verified']is True and selection['old_event_instance_id']==context['current_event_instance_id'] and selection['new_event_instance_id']is None and selection['selected_native_option_index']==3,'Actual historical withdrawal selection, not future option assumption')
    need(withdrawal['snapshot_after']['active_event']is None and withdrawal['snapshot_after']['paused']is True,'Observed withdrawal event closed/paused; saved stamps not inferred')
    saved=natives['checkpoint']['result']['checkpoint'];after=natives['checkpoint']['snapshot_after']
    need(natives['checkpoint']['status']=='native_gameplay_postcondition_verified' and saved['status']=='saved' and saved==preservation['original_checkpoint'] and pairs['checkpoint'][2]['sha256']==preservation['source_native']['sha256'] and saved['size']==SAVE_BYTES and saved['sha256']==SAVE_SHA,'Actual original native SAVE and immutable descriptor')
    need(after['active_event']is None and after['paused']is True and after['revision']==16 and after['native_revision']==15 and after['date_raw']==53144712,'Exact captured withdrawal SAVE frame')
    for key,operation in [('G2','assembly_predicates'),('G3','religious_title')]:
        native=natives[key];result=native['result'];need(native['status']=='native_confucian_readonly_observed' and result['schema']=='ck3-confucian-readonly-public-v1' and result['operation']==operation,'Exact observed existing G2/G3 operation')
        need(result['queried_snapshot_id']==after['snapshot_id'] and result['queried_revision']==after['revision'] and result['queried_native_revision']==after['native_revision'] and result['date_raw']==after['date_raw'] and result['game_pid']==session['target']['pid'] and result['connection_generation']==1,'Same exact SAVE-after G2/G3 frame and prior native identity')
    g2=natives['G2']['result']['native_result']['confucian_assembly_predicates'];g3=natives['G3']['result']['native_result']['confucian_religious_title']
    need(g2['available']is True and g2['predicates_complete']is True and g2['played_character_id']==31254 and g2['faith_id']==107 and g2['played_rite_id']==169 and g2['complete_native_faith_rite_ids']==[169],'Actual complete R2 native Faith/Rite observations')
    need(g3['available']is True and g3['graph_available']is True and g3['faith_full_id']==107 and g3['legal_head_title_absent']is True and g3['head_title_full_id']is None and g3['native_title_holder_full_id']is None,'Actual R2 noHoF; failed factory save not admitted')
    return packet
def load_packet(row):
    packet=read(row)
    return validate_packet(packet)if packet.get('schema')==SCHEMA else previous.load_packet(row)
def verify_baseline(item,helper):
    need(type(item)is dict and set(item)=={'path','bytes','sha256','original0240_source'},'Existing cold baseline reference shape')
    packet=load_packet(item['original0240_source'])
    if packet.get('schema')!=SCHEMA:return previous.verify_baseline(item,helper)
    need({key:item[key]for key in ('path','bytes','sha256')}==packet['checkpoint'],'Cold copy must use exact R2 capture descriptor')
    baseline={**packet['checkpoint'],'check_only_save_hash':'ACTUAL_SDK_CAPTURE_ONLY_BODY0_EXACT_COPY_SHA_REQUIRED_AT_CREATE'}
    proofs={'withdrawal_resume_source':item['original0240_source'],'baseline_purpose':PURPOSE,'prior_SDK_capture':packet['preservation'],'original0240_comparison_control':packet['comparison_control'],'prior_saved_body_parse_reads':0,'prior_saved_state_and_87_validation':None,'observed_prewithdraw_round':{'serial':2,'nonce':4,'phase':2},'saved_variable_cleanup_validation':None,'formal_acceptance':None}
    return baseline,proofs
