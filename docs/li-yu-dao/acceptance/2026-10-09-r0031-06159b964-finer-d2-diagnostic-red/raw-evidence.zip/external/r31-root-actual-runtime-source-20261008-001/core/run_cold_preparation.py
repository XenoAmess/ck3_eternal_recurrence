"""Invoke the explicit cold author/check/create sequence and preserve each result."""
from pathlib import Path
import argparse, hashlib, json, subprocess, sys

def _require_input(ok, message):
    if not ok:
        raise ValueError(message)

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve()
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def ref(path):
    path=Path(path).resolve();return {'path':path.as_posix(),'bytes':path.stat().st_size,'sha256':digest(path)}
def put(path,value):
    with Path(path).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--metadata-result',type=Path,required=True);parser.add_argument('--sha256',required=True)
parser.add_argument('--screen-task',required=True);parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--run-directory',type=Path,required=True);parser.add_argument('--attempt-id',required=True);parser.add_argument('--expected-head',required=True)
parser.add_argument('--previous-boundary',required=True);parser.add_argument('--previous-boundary-sha256',required=True)
parser.add_argument('--baseline-input',required=True);parser.add_argument('--baseline-input-sha256',required=True)
parser.add_argument('--diagnostic-overlay',required=True);parser.add_argument('--diagnostic-overlay-sha256',required=True)
for name in ('native-gate','native-gate-sha256','previous-boundary-verifier','previous-boundary-verifier-sha256'):parser.add_argument('--'+name,required=True)
args=parser.parse_args()
_require_input(digest(args.metadata_result)==args.sha256, 'Actual metadata SHA changed')
out=args.output.resolve();_require_input(BASE in out.parents and not out.exists(), 'Fresh external input directory required')
out.mkdir();request=out/'REQUEST.actual.json';calls=[]
helper=[sys.executable,'-B','-X','utf8',str(HERE/'prepare_next_formal_cold.py')]
steps=[('request',helper+['--metadata-result',str(args.metadata_result.resolve()),'--sha256',args.sha256,'--screen-task',args.screen_task,'--run-directory',str(args.run_directory.resolve()),'--attempt-id',args.attempt_id,'--expected-head',args.expected_head,'--previous-boundary',args.previous_boundary,'--previous-boundary-sha256',args.previous_boundary_sha256,'--output',str(request),'--native-gate',args.native_gate,'--native-gate-sha256',args.native_gate_sha256,'--previous-boundary-verifier',args.previous_boundary_verifier,'--previous-boundary-verifier-sha256',args.previous_boundary_verifier_sha256,'--baseline-input',args.baseline_input,'--baseline-input-sha256',args.baseline_input_sha256,'--diagnostic-overlay',args.diagnostic_overlay,'--diagnostic-overlay-sha256',args.diagnostic_overlay_sha256,'--create'])]
for name in ('request','check','create'):
    if name!='request':
        command=helper+['--request',str(request),'--sha256',digest(request),'--'+name]
    else:command=steps[0][1]
    step=out/(name+'-invocation');step.mkdir();put(step/'ARGV.json',{'argv':command,'cwd':'C:/workspace/ck3_eternal_recurrence'})
    with (step/'stdout.bin').open('xb') as stdout,(step/'stderr.bin').open('xb') as stderr:
        completed=subprocess.run(command,cwd='C:/workspace/ck3_eternal_recurrence',stdout=stdout,stderr=stderr)
    row={'step':name,'exit_code':completed.returncode,'stdout':ref(step/'stdout.bin'),'stderr':ref(step/'stderr.bin')}
    put(step/'RESULT.json',row);calls.append(row)
    if completed.returncode!=0:break
run=args.run_directory.resolve()
result={'status':'ACTUAL_COLD_FILES_CREATED_NO_GAME' if len(calls)==3 and all(r['exit_code']==0 for r in calls) else 'COLD_PREPARATION_RED_PRESERVED',
        'metadata_result':ref(args.metadata_result),'screen_task':args.screen_task,'calls':calls,'game_started':False,'consumer_started':False,'native_injected':False}
if result['status']=='ACTUAL_COLD_FILES_CREATED_NO_GAME':
    result.update(request=ref(request),inputs=ref(run/'INPUTS.json'),cold_receipt=ref(run/'COLD-MATERIALIZED.json'),
                  cold_inventory=ref(run/'COLD-SOURCE-INVENTORY.json'),launch_argv=ref(run/'launch-argv.json'),native_template=ref(run/'native-profile.UNBOUND.template.json'))
put(out/'RESULT.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
raise SystemExit(0 if result['status']=='ACTUAL_COLD_FILES_CREATED_NO_GAME' else 1)
