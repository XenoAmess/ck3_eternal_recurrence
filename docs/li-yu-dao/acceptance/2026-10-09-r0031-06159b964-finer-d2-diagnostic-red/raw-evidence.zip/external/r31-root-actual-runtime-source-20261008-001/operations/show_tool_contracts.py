"""Read only the exact actual SDK metadata already captured by ROOT."""
import argparse,json
from pathlib import Path
from operations_common import pinned,pinned_ref,read,need,ref
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--metadata-result',type=Path,required=True);p.add_argument('--metadata-result-sha256',required=True);p.add_argument('names',nargs='*');a=p.parse_args()
 result_path=pinned(a.metadata_result,a.metadata_result_sha256);result=read(result_path);tools_path=pinned_ref(result['metadata']);tools=read(tools_path);need(type(tools)is list,'Actual SDK tools list required')
 names=set(a.names);found={row['name'] for row in tools};need(not names-found,'Requested tools absent from this actual metadata: '+str(sorted(names-found)))
 for row in tools:
  if not names or row['name'] in names:print(json.dumps(row,ensure_ascii=False))
if __name__=='__main__':main()
