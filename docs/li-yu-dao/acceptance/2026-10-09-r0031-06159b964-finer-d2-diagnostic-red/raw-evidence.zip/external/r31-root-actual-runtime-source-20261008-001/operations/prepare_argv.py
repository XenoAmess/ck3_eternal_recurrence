"""ROOT-only file projection for phase/profile/binding argv; never executes them."""
from pathlib import Path
import argparse,json
from operations_common import PY,need,pinned,read,run_path,actual_text,ref,put,argument,set_argument
def main():
 p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='mode',required=True)
 phase=sub.add_parser('phase');phase.add_argument('--phase',choices=['preflight','launch','profile-request'],required=True)
 for key in ['input-argv']:phase.add_argument('--'+key,type=Path,required=True);phase.add_argument('--'+key+'-sha256',required=True)
 for key in ['identity','launch','postlaunch-appmanifest-delta']:phase.add_argument('--'+key,type=Path);phase.add_argument('--'+key+'-sha256')
 binding=sub.add_parser('binding')
 for key in ['author','prepared']:binding.add_argument('--'+key,type=Path,required=True);binding.add_argument('--'+key+'-sha256',required=True)
 binding.add_argument('--consumer-source',type=Path,required=True);binding.add_argument('--consumer-index-sha256',required=True);binding.add_argument('--epoch-id',required=True)
 for key in ['queue-directory','client-output','binding-output','author-output']:binding.add_argument('--'+key,type=Path,required=True)
 binding.add_argument('--execute-binder',action='store_true',help='Include existing binder flag in the argv; this helper still does not run it')
 for command in [phase,binding]:
  command.add_argument('--run-directory',type=Path,required=True);command.add_argument('--output',type=Path,required=True)
 phase.add_argument('--phase-output',type=Path,required=True)
 a=p.parse_args();run=run_path(a.run_directory)
 if a.mode=='phase':
  original=pinned(a.input_argv,a.input_argv_sha256);value=read(original);argv=list(value['argv'] if type(value)is dict else value)
  need(all(type(x)is str and x and x.lower() not in {'null','none','pending'} for x in argv),'Actual complete argv required; future NULL rejected')
  need(len(argv)>5 and argv[5]=='preflight' and Path(argument(argv,'run-directory')).resolve()==run and argument(argv,'attempt-id')=='R0031','Original R29 preflight argv required')
  need(Path(argv[4]).name=='root_next_formal_launch_profile.py','Use existing actual core launch/profile helper')
  argv[5]=a.phase;need(a.phase_output.resolve().is_relative_to(run) and not a.phase_output.exists(),'Fresh same-run phase output required');set_argument(argv,'output',a.phase_output.resolve())
  if a.phase=='profile-request':
   for key in ['identity','launch','postlaunch_appmanifest_delta']:need(getattr(a,key)is not None and getattr(a,key+'_sha256')is not None,'Actual '+key+' file/hash required after launch')
   identity=read(pinned(a.identity,a.identity_sha256));launch_path=pinned(a.launch,a.launch_sha256);launch=read(launch_path);delta=pinned(a.postlaunch_appmanifest_delta,a.postlaunch_appmanifest_delta_sha256)
   need(launch.get('schema')=='lyd.r30.root-launch-profile-helper.v1' and launch['pid']==identity['game']['pid'],'Actual same R29 launch identity required')
   values={'pid':identity['game']['pid'],'hwnd':identity['windows'][0]['hwnd'],'steam-ui-pid':identity['steam_ui']['pid'],'steam-client-pid':identity['steam_client']['pid']}
   need(all(type(v)is int and v>0 for v in values.values()),'Actual positive process/window identities required')
   values.update({'launch-sha256':ref(launch_path)['sha256'],'postlaunch-appmanifest-delta':str(delta),'postlaunch-appmanifest-delta-sha256':ref(delta)['sha256']})
   for key,v in values.items():need('--'+key not in argv,'Original preflight argv cannot already contain runtime identities');argv+=['--'+key,str(v)]
  else:need(all(getattr(a,key)is None and getattr(a,key+'_sha256')is None for key in ['identity','launch','postlaunch_appmanifest_delta']),'Do not prefill future runtime identities before launch')
  provenance={'original_preflight_argv':ref(original)}
 else:
  author=pinned(a.author,a.author_sha256);prepared=pinned(a.prepared,a.prepared_sha256);need(prepared==run/'PREPARED.json','Actual same-run PREPARED required')
  source=a.consumer_source.resolve();index_path=pinned(source/'INDEX.json',a.consumer_index_sha256);index=read(index_path);need(index['attempt_id']=='R0031' and Path(index['run_root']).resolve()==run,'Actual R29 consumer source required')
  actual_text(a.epoch_id,'ROOT epoch');locations=[getattr(a,k).resolve() for k in ['queue_directory','client_output','binding_output','author_output']]
  need(len(set(locations))==4 and all(x.is_relative_to(run) and not x.exists() for x in locations),'Existing binder requires four distinct fresh same-run paths')
  argv=[PY,'-B','-X','utf8',str(author),'--consumer-source',str(source),'--consumer-index-sha256',a.consumer_index_sha256,'--prepared',str(prepared),'--prepared-sha256',a.prepared_sha256,'--epoch-id',a.epoch_id]
  for key in ['queue-directory','client-output','binding-output','author-output']:argv+=['--'+key,str(getattr(a,key.replace('-','_')).resolve())]
  if a.execute_binder:argv+=['--execute-binder']
  provenance={'actual_PREPARED':ref(prepared),'actual_consumer_index':ref(index_path),'existing_binding_author':ref(author)}
 print(json.dumps({'output':put(a.output,{'argv':argv,'cwd':'C:/workspace/ck3_eternal_recurrence','executed':False,'provenance':provenance}),'executed':False},ensure_ascii=False))
if __name__=='__main__':main()
