from pathlib import Path
import argparse,hashlib,json,sys
parser=argparse.ArgumentParser(description='Bounded display of an already preserved actual native receipt; no native/SDK call');parser.add_argument('--receipt',type=Path,required=True);parser.add_argument('--sha256',required=True);parser.add_argument('--pointer',default='');args=parser.parse_args()
p=args.receipt.resolve();raw=p.read_bytes()
if hashlib.sha256(raw).hexdigest()!=args.sha256.lower():raise ValueError('Actual native receipt bytes differ')
d=json.loads(raw)
def compact(v,key=''):
 if key in ('native_ack','before_actual_model','later_decisions_tree','observation_after'):return '<retained in original receipt>'
 if key in ('snapshot_before','snapshot_after','snapshot') and isinstance(v,dict):
  return {k:compact(v[k],k) for k in ('snapshot_id','revision','native_revision','date_raw','paused','speed','played_character','played_character_gold','played_character_prestige','played_character_piety','active_event','pending_character_interaction','last_checkpoint_submission') if k in v}
 if key in ('diagnostics','hello'):return '<omitted>'
 if isinstance(v,dict):return {k:compact(x,k) for k,x in v.items()}
 if isinstance(v,list):
  if key=='characters':return [compact(x) for x in v if x.get('id',x.get('character_id')) in (31254,65865,65866)]
  if key=='native_command_history':return {'count':len(v),'last_two':[compact(x) for x in v[-2:]]}
  if len(v)>24:return {'count':len(v),'first_three':[compact(x) for x in v[:3]]}
  return [compact(x) for x in v]
 return v
selected=d
if args.pointer:
 for part in args.pointer.strip('/').split('/'):selected=selected[part]
print(json.dumps({'path':p.as_posix(),'sha256':hashlib.sha256(raw).hexdigest(),'data':compact(selected)},ensure_ascii=False,indent=2))
