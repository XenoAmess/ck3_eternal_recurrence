"""ROOT file-only request argv author; --execute invokes the existing once-only executor."""
from pathlib import Path
import argparse,json,subprocess
from operations_common import PY,need,ref,pinned,read,run_path,actual_text,put
def main():
 p=argparse.ArgumentParser(description=__doc__)
 for key in ['run-directory','consumer-source','request-author','executor','spec','argv-output','execution-output']:p.add_argument('--'+key,type=Path,required=True)
 for key in ['consumer-index-sha256','request-author-sha256','executor-sha256','spec-sha256']:p.add_argument('--'+key,required=True)
 p.add_argument('--phase',choices=['pre-attach','attached'],required=True)
 p.add_argument('--attached-binding',type=Path);p.add_argument('--attached-binding-sha256')
 p.add_argument('--execute',action='store_true',help='ROOT explicitly invokes the unchanged once-enqueue path; default only writes argv')
 a=p.parse_args();run=run_path(a.run_directory);spec=pinned(a.spec,a.spec_sha256);need(spec.is_relative_to(run),'Actual spec must be inside this run')
 source=a.consumer_source.resolve();index=read(pinned(source/'INDEX.json',a.consumer_index_sha256));need(index['attempt_id']=='R0031' and Path(index['run_root']).resolve()==run,'Actual R29 consumer source required')
 author=pinned(a.request_author,a.request_author_sha256);executor=pinned(a.executor,a.executor_sha256)
 session=read(run/'persistent-client-001/session.json');binding=Path(session['binding_file']).resolve();profile=Path(session['profile']).resolve()
 need(session['source_revision']==index['source_revision'],'Actual source/session HEAD differs')
 for key in ['source_revision','epoch_id','client_session_id']:actual_text(session[key],key)
 need(binding.is_relative_to(run) and profile.is_relative_to(run),'Actual same-run profile and binding required')
 output=a.execution_output.resolve();need(output.is_relative_to(run) and not output.exists(),'Fresh ROOT execution output inside actual run required')
 argv=[PY,'-B','-X','utf8',str(executor),'--spec',str(spec),'--spec-sha256',a.spec_sha256,
 '--request-author',str(author),'--request-author-sha256',a.request_author_sha256,
 '--binding',str(binding),'--binding-sha256',ref(binding)['sha256'],'--profile',str(profile),'--profile-sha256',ref(profile)['sha256'],
 '--consumer-source',str(source),'--consumer-index-sha256',a.consumer_index_sha256,'--run-directory',str(run),
 '--queue-directory',str(Path(session['queue']).resolve()),'--client-output',str(run/'persistent-client-001'),
 '--expected-head',session['source_revision'],'--epoch-id',session['epoch_id'],'--client-session-id',session['client_session_id'],
 '--output',str(output),'--phase',a.phase]
 if a.phase=='attached':
  need(a.attached_binding is not None and a.attached_binding_sha256 is not None,'Actual retained attach binding required for attached phase')
  facts=read(pinned(a.attached_binding,a.attached_binding_sha256));native=pinned(facts['attach_native']['path'],facts['attach_native']['sha256'])
  need(facts['client_session_id']==session['client_session_id'] and facts['profile_sha256']==ref(profile)['sha256'],'Actual retained attach binding differs')
  actual_text(facts['native_session_id'],'native session');argv+=['--native-session-id',facts['native_session_id'],'--attach-native',str(native),'--attach-native-sha256',facts['attach_native']['sha256']]
 else:need(a.attached_binding is None and a.attached_binding_sha256 is None,'No future native facts before actual attach')
 stamp=put(a.argv_output,{'argv':argv,'cwd':'C:/workspace/ck3_eternal_recurrence','executed_by_author':False,'phase':a.phase,'actual_consumer_index':ref(source/'INDEX.json')})
 print(json.dumps({'argv_file':stamp,'executing_existing_once_executor':a.execute},ensure_ascii=False))
 return subprocess.run(argv,cwd='C:/workspace/ck3_eternal_recurrence').returncode if a.execute else 0
if __name__=='__main__':raise SystemExit(main())
