from pathlib import Path
import hashlib,json,re
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve()
PY='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
def need(value,message):
 if not value:raise ValueError(message)
def ref(path):
 p=Path(path).resolve();raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def pinned(path,sha):
 need(type(sha)is str and re.fullmatch('[0-9a-fA-F]{64}',sha) is not None,'Explicit actual SHA256 required; future NULL rejected')
 p=Path(path).resolve();need(ref(p)['sha256']==sha.lower(),'Actual input bytes changed: '+str(p));return p
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def pinned_ref(row):
 need(type(row)is dict and set(row)=={'path','bytes','sha256'},'Original actual ref3 required')
 p=pinned(row['path'],row['sha256']);need(ref(p)['bytes']==row['bytes'],'Actual input byte count changed');return p
def run_path(path):
 p=Path(path).resolve();need(p==BASE/'live-attempt-031' and p.is_dir(),'ROOT actual allocated R0031 directory required; helper does not allocate');return p
def actual_text(value,label):
 need(type(value)is str and bool(value) and value.lower() not in {'null','none','pending'},'Actual '+label+' required; future NULL rejected');return value
def put(path,value):
 p=Path(path).resolve();need(p.parent.is_dir() and not p.exists(),'Fresh output file in an existing ROOT directory required')
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
 return ref(p)
def argument(argv,key):
 need(argv.count('--'+key)==1,'One existing --'+key+' required');return argv[argv.index('--'+key)+1]
def set_argument(argv,key,value):
 need(argv.count('--'+key)==1,'One existing --'+key+' required');argv[argv.index('--'+key)+1]=str(value)
