"""Preserve actual official attach facts; no attach, process query, or SDK action."""
import argparse,json
from pathlib import Path
from operations_common import pinned,read,need,ref,run_path,actual_text,put
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run-directory',type=Path,required=True)
 for key in ['attach-native','attach-sdk']:p.add_argument('--'+key,type=Path,required=True);p.add_argument('--'+key+'-sha256',required=True)
 p.add_argument('--output',type=Path,required=True);a=p.parse_args();run=run_path(a.run_directory)
 native=pinned(a.attach_native,a.attach_native_sha256);sdk=pinned(a.attach_sdk,a.attach_sdk_sha256)
 need(native.is_relative_to(run/'persistent-client-001') and sdk.is_relative_to(run/'persistent-client-001'),'Use actual official Client-preserved attach files')
 value=read(native);session=read(run/'persistent-client-001/session.json')
 need(value.get('status')=='attached_snapshot_verified' and value.get('profile_sha256')==session['profile_sha256'],'Original actual verified attach required')
 snapshot=value['snapshot'];need(snapshot['date_raw']==53144712 and snapshot['paused'] is True and snapshot['played_character']['character_id']==31254,'Original0240 actor/date/pause changed')
 host=value['observation_after'];need(all(host[k]==session['target'][k] for k in ['pid','process_create_time']),'Actual original game host identity differs')
 actual_text(value['session_id'],'native session');actual_text(session['client_session_id'],'Client session')
 facts={'native_session_id':value['session_id'],'client_session_id':session['client_session_id'],'profile_sha256':session['profile_sha256'],'attach_native':ref(native),'attach_sdk':ref(sdk),'date_raw':snapshot['date_raw'],'revision':snapshot['revision'],'native_revision':snapshot['native_revision']}
 need(a.output.resolve()==run/'ROOT-ATTACHED-BINDING.actual.json','Original same-run attach binding output required');print(json.dumps({'output':put(a.output,facts),'facts':facts},ensure_ascii=False))
if __name__=='__main__':main()
