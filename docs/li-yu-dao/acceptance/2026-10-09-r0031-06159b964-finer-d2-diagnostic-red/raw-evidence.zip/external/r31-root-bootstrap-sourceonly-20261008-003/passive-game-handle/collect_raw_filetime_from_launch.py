"""ROOT-only one-shot native FILETIME observation; never convert FILETIME to float ctime."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, importlib.util, json, math, sys
sys.dont_write_bytecode=True
HEAD='06159b964d859d30f2f07f4b183284df7d6dac47'
RUN=Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-031').resolve()
OBSERVER_SHA='ed6e041ed0555807cd7956cb73c0d978a5b39945a9b69beb6a9724796bd8dd70'
def need(ok,message):
    if not ok:raise ValueError(message)
def ref(path,suffix):
    path=Path(path).resolve();need(path.suffix.lower()==suffix and 0<path.stat().st_size<=8*1024*1024,'bounded exact JSON/source input required')
    raw=path.read_bytes();return {'path':path.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n')as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--launch',required=True,type=Path);parser.add_argument('--launch-sha256',required=True)
    parser.add_argument('--observer',required=True,type=Path);parser.add_argument('--observer-sha256',required=True)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args();launch_ref=ref(args.launch,'.json');observer_ref=ref(args.observer,'.py')
    need(launch_ref['sha256']==args.launch_sha256 and args.launch.resolve().is_relative_to(RUN),'exact actual R29 launch ref required')
    need(observer_ref['sha256']==args.observer_sha256==OBSERVER_SHA,'unchanged production observer bytes required')
    need(args.observer.resolve()==Path('C:/lr31s1/ck3_autonomous_player/src/xar_autoplayer/bridge/normal_exit_process_observer_v1.py').resolve(),'actual R29 clean exported observer required')
    launch=json.loads(args.launch.read_bytes());pid=launch['pid'];ctime=launch['process_create_time']
    need(launch['schema']=='lyd.r31.root-launch-profile-helper.v1'and launch['source_revision']==HEAD and launch['mode']=='launch'and launch['game_started']is True and launch['native_injected']is False and launch['live_run_id'].endswith('--li-yu-dao--R0031'),'actual R29 preattach launch required')
    need(type(pid)is int and 0<pid<2**32 and type(ctime)is float and math.isfinite(ctime)and ctime>0,'actual launch PID/ctime; future NULL refused')
    need(type(launch['argv'])is list and launch['argv']and Path(launch['argv'][0]).name.lower()=='ck3.exe','actual launch executable path required')
    output=args.output.resolve();need(output.suffix.lower()=='.json'and output.is_relative_to(RUN)and not output.exists()and output.parent.is_dir(),'fresh current-run JSON output required')
    need(not(RUN/'ROOT-ATTACHED-BINDING.actual.json').exists()and not any(RUN.glob('*client-*/*-attach*.request.json')),'collect before first native attach request')
    spec=importlib.util.spec_from_file_location('r29_existing_observer_for_raw_filetime',args.observer)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    import psutil
    api=module.Win32ProcessApi();handle=api.open_process(module.SYNCHRONIZE|module.PROCESS_QUERY_LIMITED_INFORMATION,pid)
    try:
        actual_pid=api.process_id(handle);raw_ft=api.creation_filetime(handle)
        process=psutil.Process(pid);actual_ctime=process.create_time();actual_exe=process.exe()
        record={'schema':'lyd.r31.original-native-FILETIME-and-independent-launch-observation.v1','source_head':HEAD,'source':ref(__file__,'.py'),'launch':launch_ref,'production_observer':observer_ref,'pid':actual_pid,'raw_creation_filetime':raw_ft,'launch_create_time':ctime,'actual_psutil_create_time':actual_ctime,'actual_executable':actual_exe,'launch_executable':launch['argv'][0],'ctime_exact_matches':type(actual_ctime)is type(ctime)and actual_ctime==ctime,'executable_exact_normalized_path_matches':Path(actual_exe).resolve()==Path(launch['argv'][0]).resolve(),'raw_FILETIME_to_float_conversion_performed':False,'OpenProcess_count':1,'retained_for_later_exit_observation':False,'SDK_calls':0,'game_input_calls':0,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'actual_pass':None}
        valid=actual_pid==pid and type(raw_ft)is int and 0<raw_ft<2**64 and record['ctime_exact_matches']is True and record['executable_exact_normalized_path_matches']is True
        record['status']='ACTUAL_RAW_FILETIME_AND_INDEPENDENT_LAUNCH_IDENTITY_OBSERVED'if valid else'REJECTED_ACTUAL_PROCESS_IDENTITY_DIFFERENCE'
        write(output,record);print(json.dumps({'status':record['status'],'output':ref(output,'.json')}));return 0 if valid else 2
    finally:api.close(handle)
if __name__=='__main__':raise SystemExit(main())
