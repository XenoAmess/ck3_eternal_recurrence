import psutil
'ROOT-only passive original game HANDLE, pinned from actual launch before attach.\n\nUses the existing production Win32ProcessApi/RetainedProcessObserver. No input,\nSDK, injection, termination or task-bus action. External OS observation grants no\ntyped normal-exit or autosave credit.\n'
import argparse
import hashlib
import importlib.util
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
sys.dont_write_bytecode = True
BASE = Path('C:/workspace/ck3_lyd_runtime_20261004').resolve()
RUN = BASE / 'live-attempt-031'
HEAD = '06159b964d859d30f2f07f4b183284df7d6dac47'
OBSERVER_SHA256 = 'ed6e041ed0555807cd7956cb73c0d978a5b39945a9b69beb6a9724796bd8dd70'

def need(value, message):
    if not value:
        raise ValueError(message)

def ref(path):
    path = Path(path).resolve()
    need(path.suffix.lower() not in ('.ck3', '.dmp', '.dll', '.exe') and path.stat().st_size <= 8 * 1024 * 1024, 'Bounded actual launch/source JSON only')
    raw = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def put(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

def now():
    return datetime.now(timezone.utc).isoformat()

class FirstOpenedHandleApi:
    """Hand the once-opened original HANDLE to the existing production observer."""

    def __init__(self, api, pid, handle):
        self.api, self.pid, self.handle = (api, pid, handle)
        self.handed_to_observer = False
        self.closed = False

    def open_process(self, access, pid):
        need(not self.handed_to_observer and (not self.closed) and (pid == self.pid) and (access == 1052672), 'Only the original pre-attach HANDLE can be handed to production observer')
        self.handed_to_observer = True
        return self.handle

    def process_id(self, handle):
        return self.api.process_id(handle)

    def creation_filetime(self, handle):
        return self.api.creation_filetime(handle)

    def wait(self, handle, timeout_ms):
        return self.api.wait(handle, timeout_ms)

    def exit_code(self, handle):
        return self.api.exit_code(handle)

    def close(self, handle):
        need(handle == self.handle and (not self.closed), 'Original HANDLE can be closed once only')
        self.api.close(handle)
        self.closed = True

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--launch', type=Path, required=True)
    parser.add_argument('--launch-sha256', required=True)
    parser.add_argument('--observer', type=Path, required=True)
    parser.add_argument('--observer-sha256', required=True)
    parser.add_argument('--raw-filetime-observation', type=Path, required=True)
    parser.add_argument('--raw-filetime-observation-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    launch_ref = ref(args.launch)
    need(launch_ref['sha256'] == args.launch_sha256.lower() and args.launch.resolve().is_relative_to(RUN), 'Actual current-run launch ref required')
    launch = json.loads(args.launch.read_bytes())
    need(launch['schema'] == 'lyd.r31.root-launch-profile-helper.v1' and launch['source_revision'] == HEAD and (launch['mode'] == 'launch') and (launch['game_started'] is True) and (launch['native_injected'] is False) and launch['live_run_id'].endswith('--li-yu-dao--R0031'), 'Actual R29 launch before injection required')
    pid, create_time = (launch['pid'], launch['process_create_time'])
    expected_probe_path = args.raw_filetime_observation
    need(expected_probe_path.resolve().is_relative_to(RUN), 'Actual current-run raw FILETIME artifact required')
    expected_probe_ref = ref(expected_probe_path)
    need(expected_probe_ref['sha256'] == args.raw_filetime_observation_sha256, 'Exact ROOT actual Win32 raw FILETIME observation SHA required')
    expected_probe = json.loads(expected_probe_path.read_bytes())
    need(expected_probe['pid'] == pid and expected_probe['launch_create_time'] == create_time and (type(expected_probe['raw_creation_filetime']) is int), 'Actual raw FILETIME observation must bind this launch')
    need(expected_probe['schema'] == 'lyd.r31.original-native-FILETIME-and-independent-launch-observation.v1' and expected_probe['status'] == 'ACTUAL_RAW_FILETIME_AND_INDEPENDENT_LAUNCH_IDENTITY_OBSERVED' and expected_probe['source_head'] == HEAD and expected_probe['launch'] == launch_ref and expected_probe['raw_FILETIME_to_float_conversion_performed'] is False and expected_probe['ctime_exact_matches'] is True and expected_probe['executable_exact_normalized_path_matches'] is True, 'Actual independently observed launch/Win32 identity required')
    need(type(pid) is int and pid > 0 and (type(create_time) is float) and (create_time > 0), 'Actual launch PID/create time required; future NULL refused')
    need(not (RUN / 'ROOT-ATTACHED-BINDING.actual.json').exists() and (not any(RUN.glob('*client-*/*-attach*.request.json'))), 'Start this passive holder before the first native attach request')
    observer_ref = ref(args.observer)
    need(observer_ref['sha256'] == args.observer_sha256.lower() == OBSERVER_SHA256, 'Exact existing production observer required')
    need(expected_probe['production_observer'] == observer_ref, 'Exact same production observer must author raw FILETIME and hold the original HANDLE')
    output = args.output.resolve()
    need(output.is_relative_to(RUN) and (not output.exists()), 'Fresh current-run game HANDLE output required')
    spec = importlib.util.spec_from_file_location('r29_existing_process_observer', args.observer)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    api = module.Win32ProcessApi()
    handle = api.open_process(module.SYNCHRONIZE | module.PROCESS_QUERY_LIMITED_INFORMATION, pid)
    adopted = FirstOpenedHandleApi(api, pid, handle)
    observer = None
    try:
        actual_pid = api.process_id(handle)
        actual_filetime = api.creation_filetime(handle)
        actual_create_time = psutil.Process(pid).create_time()
        put(RUN / 'game-handle-holder-PID-CTIME-OBSERVATION.actual.json', {'pid': actual_pid, 'raw_creation_filetime': actual_filetime, 'expected_raw_creation_filetime': expected_probe['raw_creation_filetime'], 'actual_psutil_create_time': actual_create_time, 'launch_create_time': create_time, 'raw_exact_matches': actual_filetime == expected_probe['raw_creation_filetime'], 'ctime_exact_matches': actual_create_time == create_time, 'observed_at_utc': now()})
        need(actual_pid == pid and actual_filetime == expected_probe['raw_creation_filetime'] and (actual_create_time == create_time) and (Path(psutil.Process(pid).exe()).resolve() == Path(launch['argv'][0]).resolve()), 'Exact original raw FILETIME and independent launch PID/create/exe must agree')
        observer = module.RetainedProcessObserver(adopted, pid, actual_filetime)
        original = observer.verify_before_dispatch()
        initial = observer.observe(0)
        need(initial['process_identity_verified'] is True and initial['wait_result'] == 258 and (initial['exit_code'] == 259) and (initial['errors'] == []), 'Original game must still be alive before attach')
        output.mkdir()
        capture = {'schema': 'lyd.root.original-game-handle-pre-attach.v1', 'status': 'ORIGINAL_GAME_HANDLE_CAPTURED_ALIVE_BEFORE_ATTACH', 'captured_at_utc': now(), 'source': ref(__file__), 'production_observer': observer_ref, 'actual_launch': launch_ref, 'source_head': HEAD, 'holder_pid': os.getpid(), 'handle_value': handle, 'handle_local_to_holder_pid': os.getpid(), 'pid': pid, 'process_create_time': create_time, 'original_identity': original, 'initial_observation': initial, 'OpenProcess_count': 1, 'reopened_process': False, 'native_driver_handle': False, 'external_passive_handle': True, 'typed_normal_exit_observed': None, 'autosave_verified': None, 'forced_exit': False, 'SDK_calls': 0, 'game_input_calls': 0, 'expected_raw_FILETIME_observation': expected_probe_ref}
        put(output / 'CAPTURED.actual.json', capture)
        print(json.dumps({'capture': ref(output / 'CAPTURED.actual.json'), 'holder_pid': os.getpid()}), flush=True)
        terminal_signal_deadline = None
        while True:
            observed = observer.observe(1000)
            if observed['wait_result'] == 258 and (not observed['errors']):
                if observed['exit_code'] == 259 and terminal_signal_deadline is None:
                    continue
                if observed['exit_code'] != 259:
                    if terminal_signal_deadline is None:
                        terminal_signal_deadline = time.monotonic() + 30.0
                    if time.monotonic() < terminal_signal_deadline:
                        continue
            result = {'schema': capture['schema'], 'status': 'ORIGINAL_GAME_HANDLE_EXIT_OBSERVED' if observed['process_exit_observed'] else 'ORIGINAL_GAME_HANDLE_OBSERVATION_UNKNOWN', 'observed_at_utc': now(), 'capture': ref(output / 'CAPTURED.actual.json'), 'observation': observed, 'reopened_process': False, 'OpenProcess_count': 1, 'native_driver_handle': False, 'external_passive_handle': True, 'typed_normal_exit_observed': None, 'autosave_verified': None, 'forced_exit': False, 'SDK_calls': 0, 'game_input_calls': 0}
            put(output / 'EXIT.actual.json', result)
            print(json.dumps(result), flush=True)
            return 0 if observed['process_identity_verified'] and observed['wait_result'] == 0 and (observed['exit_code'] == 0) else 1
    finally:
        if observer is not None:
            observer.close()
        elif not adopted.closed:
            adopted.close(handle)
if __name__ == '__main__':
    raise SystemExit(main())
