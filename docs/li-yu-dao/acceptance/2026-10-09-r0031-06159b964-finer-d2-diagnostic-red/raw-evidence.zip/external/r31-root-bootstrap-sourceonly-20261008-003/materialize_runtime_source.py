"""Bind R29 cache29 source templates to explicit actual static inputs; never launches."""
from pathlib import Path
import argparse,ast,hashlib,json,re,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve()
PINS_SHA256 = '11ac4b502407432197245c3bcf5c53d854eb3fe6fd3b695f797672c2f289c009'
KEYS={'schema','expected_head','source_export_report','compiled_result','metadata_result','allocation_receipt','previous_boundary','previous_boundary_verifier','native_gate','baseline_input','run_directory','attempt_id','screen_task','consumer_output','cold_input_output','diagnostic_overlay'}
def need(ok,message):
 if not ok:raise ValueError(message)
def ref(path):
 p=Path(path).resolve();need(p.suffix.lower()!='.ck3','Source/JSON only; no save body');raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def checked(row):
 need(type(row)is dict and set(row)=={'path','bytes','sha256'},'Complete actual ref3 required; NULL rejected');need(ref(row['path'])==row,'Actual file bytes/SHA changed');return Path(row['path']).resolve()
def read(row):return json.loads(checked(row).read_bytes())
def put(path,value):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('xb')as f:f.write(value if isinstance(value,bytes)else(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def replace_paths(raw,parent,out):
 text=raw.decode('utf-8-sig');tree=ast.parse(text);changes=[]
 class Paths(ast.NodeTransformer):
  def visit_Constant(self,n):
   if type(n.value)is str and parent.as_posix() in n.value:
    old=n.value;n.value=old.replace(parent.as_posix(),out.as_posix());changes.append({'line':n.lineno,'before':old,'after':n.value})
   return n
 new=Paths().visit(tree)
 if not changes:return raw,changes
 # Only path constants are projected; run/cache29 branches were frozen before actual inputs.
 result=ast.unparse(ast.fix_missing_locations(new))+'\n'
 need(ast.dump(ast.parse(result),include_attributes=False)==ast.dump(new,include_attributes=False),'Exact path-only AST projection required')
 return result.encode(),changes
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--request',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--production-manifest',type=Path,required=True);p.add_argument('--production-manifest-sha256',required=True);p.add_argument('--expected-head',required=True);p.add_argument('--canonical-index',type=Path,required=True);p.add_argument('--canonical-index-sha256',required=True);a=p.parse_args()
 pins_ref=ref(HERE/'RUNTIME-TEMPLATE-INVENTORY.json');need(pins_ref['sha256']==PINS_SHA256,'Sealed R29 runtime template inventory changed');pins=json.loads(Path(pins_ref['path']).read_bytes())
 r=ref(a.request);need(r['sha256']==a.sha256.lower(),'Actual request SHA changed');d=json.loads(a.request.read_bytes())
 need(type(d)is dict and set(d)==KEYS and d['schema']=='lyd.root.next-file-only-runtime-source-request.v1','Existing closed request required')
 head=d['expected_head'];need(type(head)is str and re.fullmatch('[0-9a-f]{40}',head)and head not in ('0'*40,'f'*40) and head==a.expected_head,'Explicit ROOT actual R29 iteration002 HEAD required; NULL refused')
 canonical_ref=ref(a.canonical_index);need(canonical_ref['sha256']==a.canonical_index_sha256.lower(),'Actual iteration002 canonical INDEX SHA differs');canonical=read(canonical_ref)
 need(canonical['source_head']==head and canonical['allocated_attempt']==read(d['allocation_receipt'])['run_id'],'Actual iteration002 canonical HEAD/allocated attempt must match')
 # R30 identity is supplied only by ROOT's actual allocation receipt.
 allocation=read(d['allocation_receipt'])
 need(allocation['schema']=='xar.ck3-live-run-identity.v1'and allocation['mod_key']=='li-yu-dao'and allocation['sequence']==31 and allocation['legacy_alias']in(None,'R31')and allocation['run_id'].endswith('--li-yu-dao--R0031')and d['attempt_id']=='R0031','Actual ROOT allocated R0031 required; never allocates')
 run=Path(d['run_directory']).resolve();need(run==BASE/'live-attempt-031','Exact R29 run path required')
 need(type(d['screen_task'])is str and re.fullmatch('[A-Za-z0-9_.:-]{6,160}',d['screen_task']),'Explicit actual screen task required; no lease credit')
 export=read(d['source_export_report']);meta=read(d['metadata_result'])
 need(export['source']['head']==meta['head']==head and meta['actual_export_report']==d['source_export_report']and meta['compiled_verification']==d['compiled_result'],'Actual source/export/native/metadata must match')
 need(meta['tool_count']==29 and meta['default_tool_count']==21 and meta['readonly_tool_count']==23 and meta['challenger_tool_count']==24 and meta['grant_tool_count']==28 and meta['private_bundle']=='CONFUCIAN_CHALLENGER_GRANT_ACTOR_CACHE_29' and meta['actor_cached_succession_opt_in']is True and meta['grant_title_picker_opt_in']is True and meta['actor_cache_transport']=='OFFICIAL_SDK_STDIO_LIST_TOOLS_ONLY','Actual explicit SDK cache29/default21/private23/challenger24/grant28 required')
 need(meta['factory_opt_in']=={'confucian_readonly_tools':False,'confucian_challenger_tools':True,'player_control_tools':False,'grant_title_picker_tools':True,'actor_cached_succession_tools':True},'Exact source factory opt-ins required')
 need(d['previous_boundary']==pins['previous_boundary']and d['previous_boundary_verifier']==pins['previous_boundary_verifier']and meta['previous_boundary']==d['previous_boundary']and meta['closure_verifier']==d['previous_boundary_verifier'],'Actual genuine R27 boundary/verifier required')
 for key in ('compiled_result','previous_boundary','previous_boundary_verifier','native_gate','baseline_input'):checked(d[key])
 need(d['native_gate']==canonical['metadata_gate'] and Path(d['native_gate']['path']).suffix.lower()=='.py' and Path(d['native_gate']['path']).name=='r14_clean_native_gate.py','Actual canonical native gate Python module required; qualification JSON is not a module')
 qualification=read(meta['native_clean_qualification'])
 need(qualification['source_revision']==head and qualification['compiled_route']=='CLEAN_HEAD_BUILD'and qualification['status']=='ACTUAL_COMPILED_NATIVE_BYTES_MATCH_ACTUAL_CLEAN_EXPORT'and qualification['actual_export_report']==d['source_export_report']and qualification['compiled_verification']==d['compiled_result'],'Existing actual clean-head qualification required; never reruns qualification')
 need(qualification['schema']=='lyd.next-cold.clean-export-native-byte-qualification.grant-numeric.v1'and len(qualification['actual_products'])==8 and len(qualification['actual_focused_tests'])==6,'Unchanged army-route eight/six contract required')
 production_ref=ref(a.production_manifest);need(production_ref['sha256']==a.production_manifest_sha256.lower() and production_ref==canonical['actual_reviewed_production_manifest'],'Actual fresh reviewed iteration002 production manifest and canonical pin required')
 production=json.loads(a.production_manifest.read_bytes());need(production==read(export['build']['manifest'])and production['git_sha']==head and production['product_id']=='mod_li_yu_dao','Actual production/export HEAD must match')
 production_paths=[row['path']for row in production['files']]
 expected=pins['actual_production_paths'];need(len(production_paths)==len(set(production_paths))==71 and set(production_paths)==set(expected)and len(set(production_paths)-{'descriptor.mod'})==70,'Exact declared71/70 pathset and immutable original69 universe retained')
 packet=read(d['baseline_input'])
 from signed_B3_diagnostic_baseline_adapter import validate_packet
 validate_packet(packet)
 from diagnostic_overlay_binding import load_binding
 load_binding(d['diagnostic_overlay'],head)
 out=a.output.resolve();need(out.is_relative_to(BASE)and not out.exists(),'Fresh external source packet required')
 for key in ('consumer_output','cold_input_output'):
  need(type(d[key])is str,'Actual fresh downstream output required');path=Path(d[key]).resolve();need(path.is_relative_to(BASE)and not path.exists()and not path.is_relative_to(out),'Fresh external downstream path required')
 rows=[(row['relative'],checked(row['ref']).read_bytes())for row in pins['files']];parent=Path(pins['parent_root']);out.mkdir();written=[];changes=[]
 try:
  for relative,raw in rows:
   data,delta=replace_paths(raw,parent,out)if relative.endswith('.py')else(raw,[]);put(out/relative,data);written.append(ref(out/relative))
   if delta:changes.append({'relative':relative,'paths':delta})
  dependencies=json.loads((out/'core/DEPENDENCIES.json').read_bytes())
  for key,row in dependencies.items():
   old=Path(row['path']).resolve()
   if old.is_relative_to(parent):dependencies[key]=ref(out/old.relative_to(parent))
  # Rewrite only the copied unfrozen dependency output; parent source and consumed pins remain untouched.
  dep=out/'core/DEPENDENCIES.json';dep.write_text(json.dumps(dependencies,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
  for folder in ('core','operations'):
   put(out/folder/'INDEX.json',{'schema':'lyd.root.file-only-runtime-subsource-index.v1','status':'R29_CACHE29_NAMESPACE_AND_ACTUAL_SOURCE_BOUND_ONLY','files':[ref(x)for x in sorted((out/folder).rglob('*'))if x.is_file()],'source_head':head,'attempt_id':'R0031','future_live_PID_profile_session':None,'SDK_game_OS_bus_calls':0})
  common=['--metadata-result',d['metadata_result']['path'],'--sha256',d['metadata_result']['sha256'],'--expected-head',head,'--run-directory',run.as_posix(),'--attempt-id','R0031','--screen-task',d['screen_task'],'--native-gate',d['native_gate']['path'],'--native-gate-sha256',d['native_gate']['sha256'],'--previous-boundary',d['previous_boundary']['path'],'--previous-boundary-sha256',d['previous_boundary']['sha256'],'--previous-boundary-verifier',d['previous_boundary_verifier']['path'],'--previous-boundary-verifier-sha256',d['previous_boundary_verifier']['sha256']]
  prefix=[sys.executable,'-B','-X','utf8']
  put(out/'ROOT-STATIC-ARGV.json',{'consumer_source':prefix+[(out/'core/prepare_formal_consumer.py').as_posix()]+common+['--output',d['consumer_output']],'cold_preparation':prefix+[(out/'core/run_cold_preparation.py').as_posix()]+common+['--baseline-input',d['baseline_input']['path'],'--baseline-input-sha256',d['baseline_input']['sha256'],'--diagnostic-overlay',d['diagnostic_overlay']['path'],'--diagnostic-overlay-sha256',d['diagnostic_overlay']['sha256'],'--output',d['cold_input_output']],'source_entry_directory':out.as_posix(),'source_input':r,'executed':False,'future_PID_profile_session':None})
  put(out/'PROJECTION.actual.json',{'source_parent':pins['parent'],'request':r,'path_constant_deltas':changes,'SDK_game_OS_bus_MAIN_build_body_calls':0,'native_qualification_rerun':False})
  put(out/'INDEX.json',{'schema':'lyd.root.file-only-next-runtime-source-index.v1','status':'R29_ACTUAL_STATIC_CACHE29_REFS_PINNED_FILE_ONLY_SOURCE_READY','source_head':head,'source_export':export['source_root'],'actual_allocation':d['allocation_receipt'],'actual_previous_typed_boundary':d['previous_boundary'],'actual_previous_boundary_verifier':d['previous_boundary_verifier'],'request':r,'files':[ref(x)for x in sorted(out.rglob('*'))if x.is_file()],'baseline_purpose':'SIGNED_B3_STAGED_FACTORY_DIAGNOSTIC_ONLY','actual_reviewed_production_manifest':production_ref,'actual_complete_tool_inventory_count':29,'queue_helper_name':'persistent_native_mcp_queue_29.py','PID_profile_session_Title_formal_pass':None,'SDK_game_OS_bus_MAIN_build_body_calls':0})
 except BaseException as e:
  put(out/'FAILURE.actual.json',{'status':'PARTIAL_SOURCE_PRESERVED_NO_RETRY','error':str(e),'helpers_executed':False});raise
 print(json.dumps({'source_packet_INDEX':ref(out/'INDEX.json'),'static_argv':ref(out/'ROOT-STATIC-ARGV.json'),'helpers_executed':False}));return 0
if __name__=='__main__':raise SystemExit(main())
