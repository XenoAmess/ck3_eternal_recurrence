from pathlib import Path
import ast, hashlib, json
P=Path(__file__).resolve().parent
p=P/'author_next_source_argv.py';raw=p.read_bytes();ast.parse(raw)
row={'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
with(P/'LATE-ARGV-SOURCE-INDEX.json').open('x',encoding='utf-8',newline='\n')as f:json.dump({'status':'SOURCE_READY_ROOT_ACTUAL_SIGNED_INPUT_REQUIRED','author':row,'future_PID_SID_saved_T_credit':None,'AST_checks':1,'SDK_process_bus_body_tests':0},f,indent=2);f.write('\n')
print(json.dumps({'author':row},indent=2))
