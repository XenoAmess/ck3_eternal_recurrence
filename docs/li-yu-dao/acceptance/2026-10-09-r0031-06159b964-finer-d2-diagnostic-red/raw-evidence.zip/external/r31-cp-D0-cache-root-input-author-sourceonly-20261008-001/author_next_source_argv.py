"""Emit D0 or finer-stage source argv from actual supplied input refs, never execute it."""
from pathlib import Path
import argparse, hashlib, json
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
SRC=B/'r31-finer-D2-capture-constructor-sourceonly-20261008-002'
PY='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
HEAD='06159b964d859d30f2f07f4b183284df7d6dac47'
RUN=B/'live-attempt-031'
def need(ok,msg):
 if not ok:raise ValueError(msg)
def ref(p):
 p=Path(p).resolve();need(p.is_file() and p.suffix=='.json' and 0<p.stat().st_size<=8*1024*1024,'compact actual source JSON only')
 raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def checked(p,sha):
 row=ref(p);need(row['sha256']==sha,'actual source ref changed');return row
def read(row):return json.loads(Path(row['path']).read_bytes())
def put(p,d):
 with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
def main():
 a=argparse.ArgumentParser(description=__doc__)
 a.add_argument('--mode',choices=('D0','finer'),required=True);a.add_argument('--signed-input',type=Path,required=True);a.add_argument('--signed-input-sha256',required=True);a.add_argument('--D0-source-index',type=Path);a.add_argument('--D0-source-index-sha256');a.add_argument('--client-output',type=Path);a.add_argument('--queue-root',type=Path);a.add_argument('--source-output',type=Path,required=True);a.add_argument('--output',type=Path,required=True);v=a.parse_args()
 seed=checked(v.signed_input,v.signed_input_sha256);s=read(seed)
 need(s['checkpoint']['sha256']=='c8601e7ba08406a551dcddd2a19e454423db2be6b559fad9985c6d1121b537c9' and s['checkpoint']['bytes']==91709349 and s['new_cold_validation'] is None and s['formal_acceptance'] is None,'immutable historical signed B3 only; no current acceptance')
 cp=checked(B/'r31-checkpoint-author-sourceonly-20261008-001/INDEX.json','84f68bf556f1dac2f40d04dce23e95e9668bc1c74288adf978448ee4b9b788c3')
 cap=checked(B/'r31-formal-capture-root-sourceonly-20261008-001/INDEX.json','544755b7d84131ff54df07ed6f3cdd75b9a1176c5428c0807d112516d02e9d23')
 cache=checked(B/'r31-root-cache-comparator-bound-source-20261008-001/INDEX.json','5f8738739a6a2a21d26550ac1394982b3d0f4a5743b2ad9f8399094dc7906f1d')
 out=v.output.resolve();target=v.source_output.resolve();need(out.is_relative_to(B) and not out.exists() and target.is_relative_to(B) and not target.exists() and out!=target,'fresh distinct external output paths required')
 if v.mode=='D0':
  need(v.D0_source_index is None and v.D0_source_index_sha256 is None and v.client_output is None and v.queue_root is None,'D0 source argv uses only current CP/CAP and actual signed input')
  argv=[PY,'-B','-X','utf8',(SRC/'materialize_D0_source.py').as_posix(),'--expected-head',HEAD,'--run-directory',RUN.as_posix(),'--signed-input',seed['path'],'--signed-input-sha256',seed['sha256'],'--checkpoint-source',str(Path(cp['path']).parent),'--checkpoint-index-sha256',cp['sha256'],'--capture-source',str(Path(cap['path']).parent),'--capture-index-sha256',cap['sha256'],'--output',target.as_posix()]
  out.mkdir();put(out/'ROOT-D0-SOURCE-ARGV.actual.json',{'argv':argv,'CP':cp,'CAP':cap,'signed_B3_input':seed,'constructor_index':ref(SRC/'INDEX.json'),'runtime_credit':None})
 else:
  need(v.D0_source_index is not None and v.D0_source_index_sha256 is not None and v.client_output is not None and v.queue_root is not None,'actual D0 INDEX and ROOT-selected Client/queue required')
  d0=checked(v.D0_source_index,v.D0_source_index_sha256);client=v.client_output.resolve();queue=v.queue_root.resolve()
  need(client==RUN/'persistent-client-001' and queue.parent==RUN and read(d0)['signed_B3_input']==seed,'actual same-run sole Client/queue and D0 signed input binding required')
  request={'schema':'lyd.r31.finer-D2-source-materializer-request.v1','expected_head':HEAD,'run_root':RUN.as_posix(),'client_output':client.as_posix(),'queue_root':queue.as_posix(),'checkpoint_index':cp,'D0_source_index':d0,'cache_comparator_index':cache,'source_export_report':checked(B/'r31-root-clean-export-20261008-001/REPORT.json','ba6a5fd88967c41909043f68d377e2e22d8c03fa21b3332e383d9a992ccdfc14'),'signed_B3_input':seed,'overlay_binding':checked(B/'r31-root-diagnostic-overlay-20261008-001/BINDING.actual.json','febe31ef3c82bba653871a4c8f3a88272df5d37c4362564637c978185a7619b5'),'previous_boundary':checked(B/'r30-root-actual-typed-closed-boundary-20261008-001/PREVIOUS-BOUNDARY.actual.json','2944ee5104746377a738ae5c1d625846cdb9bb9691ac5e4ca6504e4162b938da'),'output':target.as_posix()}
  out.mkdir();put(out/'FINER-SOURCE-REQUEST.actual.json',request);request_ref=ref(out/'FINER-SOURCE-REQUEST.actual.json')
  argv=[PY,'-B','-X','utf8',(SRC/'materialize_finer_D2_source.py').as_posix(),'--request',request_ref['path'],'--sha256',request_ref['sha256']]
  put(out/'ROOT-FINER-SOURCE-ARGV.actual.json',{'argv':argv,'request':request_ref,'constructor_index':ref(SRC/'INDEX.json'),'runtime_credit':None})
 print(json.dumps({'output':out.as_posix(),'argv':argv,'executed':False,'SDK_body_process_bus_calls':0},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
