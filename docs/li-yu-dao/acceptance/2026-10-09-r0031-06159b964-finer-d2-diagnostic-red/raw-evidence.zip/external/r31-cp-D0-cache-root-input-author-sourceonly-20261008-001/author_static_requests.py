"""Create ROOT argv for actual R31 source constructors; no runtime execution."""
from pathlib import Path
import hashlib, json
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
HERE=Path(__file__).resolve().parent
SRC=B/'r31-finer-D2-capture-constructor-sourceonly-20261008-002'
PY='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
HEAD='06159b964d859d30f2f07f4b183284df7d6dac47'
def ref(p):
 p=Path(p).resolve();raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def checked(p,sha):
 row=ref(p)
 if row['sha256']!=sha:raise ValueError('ROOT actual source ref changed '+str(p))
 return row
def put(name,d):
 with(HERE/name).open('x',encoding='utf-8',newline='\n')as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
export=checked(B/'r31-root-clean-export-20261008-001/REPORT.json','ba6a5fd88967c41909043f68d377e2e22d8c03fa21b3332e383d9a992ccdfc14')
report=json.loads(Path(export['path']).read_bytes())
prod=report['build']['manifest']
if ref(prod['path'])!=prod or report['source']['head']!=HEAD:raise ValueError('Actual exported manifest/source differs')
allocation=ref(B/'r31-root-live-run-allocation-original-exec-20261008-001/stdout')
identity=json.loads(Path(allocation['path']).read_bytes())
if identity['sequence']!=31 or identity['legacy_alias']!='R31' or not identity['run_id'].endswith('--li-yu-dao--R0031'):raise ValueError('Actual allocated31 differs')
request=json.loads((SRC/'CP-CAP-SOURCE-REQUEST.pending.json').read_bytes())
request.update(allocation_receipt=allocation,production_manifest=prod,run_directory=(B/'live-attempt-031').as_posix(),checkpoint_output=(B/'r31-checkpoint-author-sourceonly-20261008-001').as_posix(),capture_output=(B/'r31-formal-capture-root-sourceonly-20261008-001').as_posix(),baseline_specification_output=(B/'r31-baseline-capture-specification-sourceonly-20261008-001').as_posix())
for key in('checkpoint_output','capture_output','baseline_specification_output'):
 if Path(request[key]).exists():raise ValueError('Source target already exists '+key)
put('CP-CAP-SOURCE-REQUEST.actual.json',request)
request_ref=ref(HERE/'CP-CAP-SOURCE-REQUEST.actual.json')
put('ROOT-CP-CAP-ARGV.actual.json',{'argv':[PY,'-B','-X','utf8',(SRC/'project_r31_cp_cap_static.py').as_posix(),'--request',request_ref['path'],'--sha256',request_ref['sha256']],'source_index':ref(SRC/'INDEX.json'),'request':request_ref,'runtime_results':None})
cache=B/'r31-root-cache-comparator-bound-source-20261008-001'
if cache.exists():raise ValueError('Fresh cache source target required')
put('ROOT-CACHE-SOURCE-ARGV.actual.json',{'argv':[PY,'-B','-X','utf8',(SRC/'bind_cache_source.py').as_posix(),'--expected-head',HEAD,'--export-report',export['path'],'--export-report-sha256',export['sha256'],'--output',cache.as_posix()],'source_index':ref(SRC/'INDEX.json'),'runtime_results':None})
put('INDEX.json',{'status':'ACTUAL_STATIC_REQUESTS_READY_ROOT_EXECUTION_PENDING','source_head':HEAD,'constructor_index':ref(SRC/'INDEX.json'),'allocation':allocation,'request':request_ref,'CP_CAP_argv':ref(HERE/'ROOT-CP-CAP-ARGV.actual.json'),'cache_source_argv':ref(HERE/'ROOT-CACHE-SOURCE-ARGV.actual.json'),'SDK_process_bus_desktop_MAIN_Git_build_body_test_calls':0})
print(json.dumps({'INDEX':ref(HERE/'INDEX.json'),'request':request_ref,'CP_CAP_argv':ref(HERE/'ROOT-CP-CAP-ARGV.actual.json'),'cache_argv':ref(HERE/'ROOT-CACHE-SOURCE-ARGV.actual.json')},indent=2))
