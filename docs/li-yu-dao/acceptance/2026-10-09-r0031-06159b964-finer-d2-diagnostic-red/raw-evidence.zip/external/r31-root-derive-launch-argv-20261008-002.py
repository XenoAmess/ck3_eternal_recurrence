from pathlib import Path
import hashlib
import json
B = Path('C:/workspace/ck3_lyd_runtime_20261004')
source = B / 'r31-root-preflight-argv-20261008-001.json'
obj = json.loads(source.read_bytes())
argv = obj['argv']
matches = [i for i, x in enumerate(argv) if isinstance(x, str) and x.replace('\\', '/').endswith('/core/root_next_formal_launch_profile.py')]
assert len(matches) == 1
mode_index = matches[0] + 1
assert argv[mode_index] == 'preflight'
argv[mode_index] = 'launch'
i = argv.index('--output') + 1
assert argv[i] == 'C:/workspace/ck3_lyd_runtime_20261004/live-attempt-031/root-preflight-001'
argv[i] = 'C:/workspace/ck3_lyd_runtime_20261004/live-attempt-031/root-launch-001'
obj['source_argv'] = {'path': source.as_posix(), 'bytes': source.stat().st_size, 'sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'changed_fields': ['mode', '--output']}
obj['prior_failed_author_preserved'] = 'r31-root-derive-launch-argv-20261008-001.py'
target = B / 'r31-root-launch-argv-20261008-002.json'
with target.open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'path': target.as_posix(), 'bytes': target.stat().st_size, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))
