from pathlib import Path
import ast,json
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
for rel in ('r30-formal-capture-root-sourceonly-20261008-001/INDEX.json','r30-diagnostic-cp-cap-constructor-sourceonly-20261008-004/materialize_D0_source.py','r30-root-cache-comparator-bound-source-20261008-002/compare_actor_cached_succession.py'):
 p=B/rel;s=p.read_text(encoding='utf-8');print('\nFILE',rel)
 if p.suffix=='.json':
  d=json.loads(s);print(json.dumps({k:v for k,v in d.items() if k in ('baseline_specification_author','checkpoint_source','formal_capture','formal_author','formal_materializer')},indent=2));continue
 t=ast.parse(s)
 for n in t.body:
  if not isinstance(n,(ast.FunctionDef,ast.ClassDef)):print(ast.unparse(n))
  elif n.name=='main' and 'D0_source' in rel:print('\n'.join(s.splitlines()[n.lineno-1:min(n.lineno+65,n.end_lineno)]))
