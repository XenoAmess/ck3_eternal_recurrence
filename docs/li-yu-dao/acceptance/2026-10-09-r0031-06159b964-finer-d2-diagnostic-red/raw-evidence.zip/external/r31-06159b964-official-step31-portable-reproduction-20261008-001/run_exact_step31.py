from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, time

O = Path(__file__).parent
EXPORT = Path('C:/lr31s1')
PY = 'C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
SHA = '06159b964d859d30f2f07f4b183284df7d6dac47'
WORKFLOW = O / 'exact-workflow-001.source.yml'
raw = WORKFLOW.read_text(encoding='utf-8')
anchor = '      - name: Test shared CK3 acceptance without installed CK3\n'
assert raw.count(anchor) == 1
start = raw.index(anchor)
end = raw.index('\n      - name:', start + len(anchor))
block = raw[start:end]
commands = ['python -B -X utf8 tools/test_ck3_mod_acceptance.py', 'python -B -X utf8 tools/test_ck3_mod_acceptance_adapters.py', 'python -B -X utf8 tools/test_ck3_mod_acceptance_completion.py']
assert [v.strip() for v in block.splitlines() if v.strip().startswith('python ')] == commands
assert block.count('if not "%errorlevel%"=="0" exit /b %errorlevel%') == 3

def pin(path):
    data = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def keep(path, data):
    with path.open('xb') as f:
        f.write(data)
    return pin(path)

def write(path, data):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write('\n')

environment = os.environ.copy()
temp = O / 'portable-test-temp'
temp.mkdir(exist_ok=False)
environment.update(TEMP=str(temp), TMP=str(temp), PYTHONDONTWRITEBYTECODE='1')
source_pins = [pin(EXPORT / command.split()[-1]) for command in commands]
write(O / 'WORKFLOW-COMMANDS.actual-source.json', {'exact_head': SHA, 'workflow': pin(WORKFLOW), 'official_API_receipt': pin(O / 'exact-workflow-001.actual.json'), 'step_name': 'Test shared CK3 acceptance without installed CK3', 'original_run_block': block, 'commands': commands, 'clean_export': EXPORT.as_posix(), 'export_exact_head_provenance': 'ROOT explicitly supplied this clean export at exact 06159; no local Git command used.', 'script_pins': source_pins, 'stop_on_first_nonzero': True, 'MAIN_Git_runtime_actions': 0})
results = []
for index, command in enumerate(commands, 1):
    directory = O / ('command-' + str(index).zfill(3))
    directory.mkdir(exist_ok=False)
    argv = [PY, '-B', '-X', 'utf8', command.split()[-1]]
    write(directory / 'ARGV.actual.json', {'argv': argv, 'cwd': EXPORT.as_posix(), 'shell': False, 'source_command': command})
    started = datetime.now(timezone.utc).isoformat()
    t0 = time.monotonic()
    timed = False
    try:
        r = subprocess.run(argv, cwd=EXPORT, env=environment, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False, timeout=60)
        out, err, rc = r.stdout, r.stderr, r.returncode
    except subprocess.TimeoutExpired as e:
        out, err, rc, timed = e.stdout or b'', e.stderr or b'', None, True
    record = {'schema': 'exact-portable-workflow-command.actual.v1', 'exact_head': SHA, 'original_official_run_id': 37772862210, 'original_official_job_id': 113296449487, 'ordinal': index, 'argv': argv, 'cwd': EXPORT.as_posix(), 'shell': False, 'source_command': command, 'started_at_utc': started, 'finished_at_utc': datetime.now(timezone.utc).isoformat(), 'elapsed_seconds': time.monotonic() - t0, 'timeout_seconds': 60, 'timed_out': timed, 'exit_code': rc, 'stdout': keep(directory / 'stdout.actual.log', out), 'stderr': keep(directory / 'stderr.actual.log', err), 'script': source_pins[index - 1], 'explicit_environment_overrides': {'TEMP': str(temp), 'TMP': str(temp), 'PYTHONDONTWRITEBYTECODE': '1'}, 'MAIN_Git_game_SDK_Steam_screen_bus_native_actions': 0}
    write(directory / 'RESULT.actual.json', record)
    results.append(record)
    print(json.dumps({'ordinal': index, 'command': command, 'exit_code': rc, 'timed_out': timed, 'stdout_tail': out.decode('utf-8', 'replace')[-12000:], 'stderr_tail': err.decode('utf-8', 'replace')[-16000:]}, ensure_ascii=False), flush=True)
    if rc != 0 or timed:
        break
status = 'LOCAL_ALL_THREE_PASS_OFFICIAL_CAUSE_UNKNOWN' if len(results) == 3 and all(v['exit_code'] == 0 for v in results) else ('LOCAL_REPRO_TIMEOUT_CAUSE_UNKNOWN' if results[-1]['timed_out'] else 'ACTUAL_LOCAL_PORTABLE_STEP_REPRODUCED_RED')
write(O / 'REPRODUCTION.actual.json', {'schema': 'exact-portable-workflow-step.actual.v1', 'status': status, 'exact_head': SHA, 'workflow_command_source': pin(O / 'WORKFLOW-COMMANDS.actual-source.json'), 'commands_completed': len(results), 'results': results, 'first_nonpass': next((v for v in results if v['exit_code'] != 0 or v['timed_out']), None), 'remaining_commands_not_run': commands[len(results):], 'new_joblog_downloads': 0, 'source_changes': 0, 'MAIN_Git_game_SDK_Steam_screen_bus_native_actions': 0, 'actual_official_CI_remains': 'FAILURE', 'live_business_credit': None})
print(json.dumps({'status': status, 'result': pin(O / 'REPRODUCTION.actual.json')}, ensure_ascii=False), flush=True)
raise SystemExit(0 if status == 'LOCAL_ALL_THREE_PASS_OFFICIAL_CAUSE_UNKNOWN' else 1)
