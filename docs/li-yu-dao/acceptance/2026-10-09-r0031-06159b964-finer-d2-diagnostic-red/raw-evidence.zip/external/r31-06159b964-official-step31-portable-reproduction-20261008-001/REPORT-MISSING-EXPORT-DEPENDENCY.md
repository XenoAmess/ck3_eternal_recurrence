# R31 精确 CI step31：本地导出依赖缺失记录

HEAD：`06159b964d859d30f2f07f4b183284df7d6dac47`。官方 Official Runner run `37772862210` / job `113296449487` 的 step31 `Test shared CK3 acceptance without installed CK3` 已实际 FAILURE；本地结果不改变该原判定。原官方终态、两次日志下载超时和 NULL 原因保留在 `r30-06159b964-exact-official-ci-20261008-001/INDEX.json`。

在 ROOT 指定同 HEAD 的 clean export `C:/lr31s1`，使用实际 PY313 按该 HEAD 官方 workflow 的三条命令顺序执行，首个脚本即 exit1，后两脚本未执行。首脚本运行 10 tests，其中 1 ERROR：`SharedEntryTests.test_all_canonical_products_and_cases_select_the_same_runtime` 在 `tools/test_ck3_mod_acceptance.py:107` 读取 `workshop/products.json` 时发生 FileNotFoundError。该导出树没有 workshop 目录；`tools/ck3_mod_acceptance_products.json` 已存在。

这是本地导出投影缺少 canonical 产品清单，不能作为官方完整 checkout 的同一 case 或同一根因证明。`REPRODUCTION.actual.json` 内原状态文字 `ACTUAL_LOCAL_PORTABLE_STEP_REPRODUCED_RED` 保持原样，其含义限于本地实际 RED，不能解释为官方失败原因已复现。官方具体 case、生产原因和源码修复 candidate 仍为 NULL。

官方 workflow blob 为 `cd84d71fe06ba8aad124fe82d3875bc133b07cc7`；实际命令来源和单次执行 argv、exit、完整 stderr 分别保留在 WORKFLOW-COMMANDS、command-001 和 raw ZIP。首轮失败原件不修写。未运行第三次 joblog 下载，未执行后两脚本、额外 tests、Git、native build、游戏、SDK、Steam、存档读取或系统设置。MAIN 与 clean export 均零写入。需要补足同 HEAD 的清单到新的外置隔离投影后，才可另行验证完整 portable step；不得削弱用例或把缺清单当生产修复。
