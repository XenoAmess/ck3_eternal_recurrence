from pathlib import Path
import json

O = Path(__file__).parent
source = Path('C:/workspace/ck3_lyd_runtime_20261004/r30-06159b964-exact-official-ci-20261008-001/read_source_api.py')
target = O / 'read_source_api.py'
with target.open('xb') as f:
    f.write(source.read_bytes())
print(json.dumps({'created': target.as_posix(), 'old_ci_packet_writes': 0, 'MAIN_actions': 0}))
