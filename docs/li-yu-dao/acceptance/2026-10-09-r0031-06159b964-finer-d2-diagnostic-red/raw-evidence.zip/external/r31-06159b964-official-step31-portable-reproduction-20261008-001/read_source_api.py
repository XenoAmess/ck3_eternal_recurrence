from pathlib import Path
from datetime import datetime, timezone
import argparse, base64, hashlib, json, urllib.request, urllib.error

O = Path(__file__).parent
p = argparse.ArgumentParser()
p.add_argument('--label', required=True)
p.add_argument('--head', required=True)
p.add_argument('--path')
a = p.parse_args()
assert a.head in ['06159b964d859d30f2f07f4b183284df7d6dac47', 'd705eb32122ed2450cff6d6de0387f14ae457024']
repo = 'XenoAmess/ck3_eternal_recurrence'
endpoint = f'repos/{repo}/contents/{a.path}?ref={a.head}' if a.path else f'repos/{repo}/commits/{a.head}'
url = 'https://api.github.com/' + endpoint
started = datetime.now(timezone.utc).isoformat()
out, err, status, rc = b'', b'', None, 1
try:
    req = urllib.request.Request(url, headers={'Accept': 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'ck3-exact-ci-source-readonly'}, method='GET')
    with urllib.request.urlopen(req, timeout=20) as response:
        status, out = response.status, response.read()
    rc = 0 if status == 200 else 1
except urllib.error.HTTPError as e:
    status, out, err = e.code, e.read(), (type(e).__name__ + ': ' + str(e)).encode('utf-8')
except Exception as e:
    err = (type(e).__name__ + ': ' + str(e)).encode('utf-8')

def keep(name, raw):
    path = O / name
    with path.open('xb') as f:
        f.write(raw)
    return {'path': path.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

record = {'method': 'GET', 'url': url, 'source_head': a.head, 'source_path': a.path, 'started_at_utc': started, 'finished_at_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': rc, 'http_status': status, 'timeout_seconds': 20, 'stdout': keep(a.label + '.stdout', out), 'stderr': keep(a.label + '.stderr', err), 'MAIN_Git_runtime_setting_actions': 0, 'old_terminal_packet_writes': 0}
if rc == 0:
    data = json.loads(out)
    if a.path:
        raw = base64.b64decode(data['content'])
        assert data['path'] == a.path
        record['official_blob_sha'] = data['sha']
        record['decoded_source'] = keep(a.label + '.source' + Path(a.path).suffix, raw)
with (O / (a.label + '.actual.json')).open('x', encoding='utf-8', newline='\n') as f:
    json.dump(record, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps(record, ensure_ascii=False))
if rc == 0 and not a.path:
    print(json.dumps({'sha': data['sha'], 'parents': [v['sha'] for v in data['parents']], 'files': [v['filename'] for v in data['files']]}, ensure_ascii=False))
raise SystemExit(rc)
