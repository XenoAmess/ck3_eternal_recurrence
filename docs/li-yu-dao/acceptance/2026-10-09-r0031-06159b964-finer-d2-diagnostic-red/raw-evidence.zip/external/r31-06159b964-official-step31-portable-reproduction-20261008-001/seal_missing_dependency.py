from __future__ import annotations
import datetime as dt
import hashlib
import json
from pathlib import Path
import zipfile

PACK = Path(__file__).resolve().parent
EXPORT = Path('C:/lr31s1')
HEAD = '06159b964d859d30f2f07f4b183284df7d6dac47'
CI = PACK.parent / 'r30-06159b964-exact-official-ci-20261008-001'

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def put(rel: str, data: bytes) -> Path:
    path = PACK / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)
    return path

def encoded(value) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

def ref(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def main() -> None:
    observed = dt.datetime.now(dt.timezone.utc).isoformat().replace('+00:00', 'Z')
    reproduction = json.loads((PACK / 'REPRODUCTION.actual.json').read_text(encoding='utf-8-sig'))
    required = EXPORT / 'workshop/products.json'
    test = EXPORT / 'tools/test_ck3_mod_acceptance.py'
    registry = EXPORT / 'tools/ck3_mod_acceptance_products.json'
    helper = EXPORT / 'tools/ck3_mod_acceptance.py'
    for path in (test, registry):
        put('source-snapshots/' + path.relative_to(EXPORT).as_posix(), path.read_bytes())
    lines = test.read_text(encoding='utf-8-sig').splitlines()
    source = {
        'schema': 'exact-ci-portable-dependency-observation-v1',
        'observed_at_utc': observed,
        'expected_head': HEAD,
        'export': {'path': str(EXPORT), 'head_provenance': 'ROOT supplied actual clean export at expected_head; no Git operation or independent HEAD query'},
        'case': 'SharedEntryTests.test_all_canonical_products_and_cases_select_the_same_runtime',
        'source_file': ref(test),
        'lines_105_to_124': [{'line': n, 'text': lines[n-1]} for n in range(105, 125)],
        'existing_dependencies': [ref(registry), ref(helper)],
        'missing_dependency': {'path': str(required), 'exists': required.exists(), 'bytes': None, 'sha256': None},
        'interpretation': 'Local export lacks canonical products metadata; this local error is not an independently established official CI failure cause.',
        'official_failure_case': None,
        'official_failure_cause': None,
        'product_fix_candidate': None,
        'main_writes': 0, 'export_writes': 0, 'game_calls': 0, 'sdk_calls': 0,
    }
    if required.exists():
        raise RuntimeError('Missing dependency changed; do not reinterpret original reproduction')
    source_path = put('SOURCE-DEPENDENCY.actual.json', encoded(source))
    report = '''# R31 精确 CI step31：本地导出依赖缺失记录

HEAD：`06159b964d859d30f2f07f4b183284df7d6dac47`。官方 Official Runner run `37772862210` / job `113296449487` 的 step31 `Test shared CK3 acceptance without installed CK3` 已实际 FAILURE；本地结果不改变该原判定。原官方终态、两次日志下载超时和 NULL 原因保留在 `r30-06159b964-exact-official-ci-20261008-001/INDEX.json`。

在 ROOT 指定同 HEAD 的 clean export `C:/lr31s1`，使用实际 PY313 按该 HEAD 官方 workflow 的三条命令顺序执行，首个脚本即 exit1，后两脚本未执行。首脚本运行 10 tests，其中 1 ERROR：`SharedEntryTests.test_all_canonical_products_and_cases_select_the_same_runtime` 在 `tools/test_ck3_mod_acceptance.py:107` 读取 `workshop/products.json` 时发生 FileNotFoundError。该导出树没有 workshop 目录；`tools/ck3_mod_acceptance_products.json` 已存在。

这是本地导出投影缺少 canonical 产品清单，不能作为官方完整 checkout 的同一 case 或同一根因证明。`REPRODUCTION.actual.json` 内原状态文字 `ACTUAL_LOCAL_PORTABLE_STEP_REPRODUCED_RED` 保持原样，其含义限于本地实际 RED，不能解释为官方失败原因已复现。官方具体 case、生产原因和源码修复 candidate 仍为 NULL。

官方 workflow blob 为 `cd84d71fe06ba8aad124fe82d3875bc133b07cc7`；实际命令来源和单次执行 argv、exit、完整 stderr 分别保留在 WORKFLOW-COMMANDS、command-001 和 raw ZIP。首轮失败原件不修写。未运行第三次 joblog 下载，未执行后两脚本、额外 tests、Git、native build、游戏、SDK、Steam、存档读取或系统设置。MAIN 与 clean export 均零写入。需要补足同 HEAD 的清单到新的外置隔离投影后，才可另行验证完整 portable step；不得削弱用例或把缺清单当生产修复。
'''
    report_path = put('REPORT-MISSING-EXPORT-DEPENDENCY.md', report.encode('utf-8'))
    raw = [
        'exact-workflow-001.actual.json', 'exact-workflow-001.source.yml',
        'exact-workflow-001.stderr', 'exact-workflow-001.stdout',
        'WORKFLOW-COMMANDS.actual-source.json', 'REPRODUCTION.actual.json',
        'command-001/ARGV.actual.json', 'command-001/RESULT.actual.json',
        'command-001/stdout.actual.log', 'command-001/stderr.actual.log',
        'run_exact_step31.py', 'read_source_api.py', 'prepare_reader.py',
        'source-snapshots/tools/test_ck3_mod_acceptance.py',
        'source-snapshots/tools/ck3_mod_acceptance_products.json',
        'SOURCE-DEPENDENCY.actual.json', 'REPORT-MISSING-EXPORT-DEPENDENCY.md',
    ]
    records = [{'archive_member': rel, **ref(PACK / rel)} for rel in raw]
    archive = PACK / 'raw-portable-first-failure.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel in raw:
            z.write(PACK / rel, rel)
    with zipfile.ZipFile(archive) as z:
        checked = [{
            'archive_member': row['archive_member'],
            'bytes_match': len(z.read(row['archive_member'])) == row['bytes'],
            'sha256_match': sha(z.read(row['archive_member'])) == row['sha256'],
        } for row in records]
    check_path = put('ARCHIVE-FIRST-FAILURE-CHECK.actual.json', encoded({
        'schema': 'archive-exact-byte-check-v1', 'checked_at_utc': observed,
        'archive': ref(archive), 'member_count': len(checked),
        'all_match': all(row['bytes_match'] and row['sha256_match'] for row in checked),
        'members': checked,
    }))
    if not all(row['bytes_match'] and row['sha256_match'] for row in checked):
        raise RuntimeError('Archive verification failed')
    index = {
        'schema': 'exact-ci-portable-reproduction-first-failure-index-v1',
        'created_at_utc': observed, 'exact_head': HEAD,
        'official_workflow': 'Official Runner CI', 'official_run_id': 37772862210,
        'official_job_id': 113296449487,
        'official_job_url': 'https://github.com/XenoAmess/ck3_eternal_recurrence/actions/runs/37772862210/job/113296449487',
        'official_conclusion': 'failure', 'official_step_number': 31,
        'official_failure_case': None, 'official_failure_cause': None,
        'official_terminal_index': ref(CI / 'INDEX.json'),
        'local_status': 'FAILED_EXPORT_DEPENDENCY_MISSING',
        'local_case': source['case'], 'local_exit_code': 1,
        'remaining_two_commands': 'NOT_RUN_STOPPED_AT_FIRST_RED',
        'missing_dependency': source['missing_dependency'],
        'source_fix_candidate': None,
        'report': ref(report_path), 'source_observation': ref(source_path),
        'reproduction_receipt': ref(PACK / 'REPRODUCTION.actual.json'),
        'archive': ref(archive), 'archive_check': ref(check_path),
        'raw_objects': records,
        'suggested_delivery_subdirectory': 'docs/li-yu-dao/acceptance/2026-10-08-r0030-06159b964-exact-official-ci/local-reproduction-001',
        'claims': {'ci_green': False, 'native_green': None, 'live_green': None, 'business_green': None},
        'scope': {'main_writes': 0, 'export_writes': 0, 'git_calls': 0, 'game_calls': 0, 'sdk_calls': 0, 'new_joblog_downloads': 0},
    }
    index_path = put('INDEX-MISSING-EXPORT-DEPENDENCY.json', encoded(index))
    print(json.dumps({'index': ref(index_path), 'report': ref(report_path), 'archive': ref(archive), 'check': ref(check_path)}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
