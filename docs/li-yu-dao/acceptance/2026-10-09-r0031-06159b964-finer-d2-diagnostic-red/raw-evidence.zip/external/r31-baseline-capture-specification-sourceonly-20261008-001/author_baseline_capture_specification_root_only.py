"""ROOT file-only R31 original0240 baseline specification author. Actual runtime JSON mandatory; no save body/copy/SDK."""
from pathlib import Path
import argparse,hashlib,json,re,sys
sys.dont_write_bytecode=True
RUN=Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-031');BASE=RUN.parent
CP=None;CAP=None;CLIENT=None
HEAD=None;PY='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
def need(ok,msg):
 if not ok:raise ValueError(msg)
def ref(path):
 path=Path(path).resolve();need(path.suffix.lower() in ('.json','.py') and 0<path.stat().st_size<=8*1024*1024,'bounded JSON/source only');raw=path.read_bytes();return {'path':path.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(path):return json.loads(Path(path).read_bytes())
def put(path,obj):
 with Path(path).open('x',encoding='utf-8',newline='\n')as f:json.dump(obj,f,indent=2,ensure_ascii=False);f.write('\n')
def pair(stem,*,attach=False):
 need(re.fullmatch(r'[0-9]{4}-r31-root-attach-[0-9]{3}',stem) if attach else re.fullmatch(r'[0-9]{4}-r31-[0-9]{3}-baseline-(save|g2|g3)',stem),'closed R31 baseline Client stem')
 response=read(CLIENT/(stem+'.response.json'));need(response['status']=='MCP_RESULT_RECORDED' and len(response['native_receipts'])==1,'one actual completed native receipt')
 row=response['native_receipts'][0];original=Path(row['path']).resolve();copy=(CLIENT/row['copy']).resolve();sdk=(CLIENT/response['sdk_result']).resolve()
 need(original.is_relative_to(RUN/'native-evidence') and copy.is_relative_to(CLIENT) and sdk.is_relative_to(CLIENT),'actual same-run original artifacts')
 need(ref(original)['sha256']==ref(copy)['sha256']==row['sha256'] and ref(sdk)['sha256']==response['sdk_result_sha256'],'original SDK/native and exact Client copy binding')
 native=read(original);need(Path(native['receipt_path']).resolve()==original,'original native receipt path');return {'native_receipt':ref(original),'sdk_result':ref(sdk)}
DIRECT_RESPONSE_REF=None

def direct_attach_pair(stem,binding,session):
 # The actual late verification used the original official ClientSession,
 # not a sequence queue response. Never synthesize a queued attach result.
 need(re.fullmatch(r'direct-r31-[A-Za-z0-9_-]+',stem),'actual explicit direct R31 response stem required; no fabricated queue attach')
 def bound(row):
  need(type(row)is dict and set(row)=={'path','bytes','sha256'},'actual direct attach ref3')
  path=Path(row['path']).resolve();need(ref(path)==row,'actual direct attach bytes/SHA');return path
 copy=bound(binding['attach_native']);sdk=bound(binding['attach_sdk'])
 client=(CLIENT).resolve();need(copy.is_relative_to(client) and sdk.is_relative_to(client),'actual original Client direct attach copies')
 response_path=client/(stem+'.response.json');need(ref(response_path)==DIRECT_RESPONSE_REF,'actual direct route response bytes/SHA')
 response=read(response_path)
 need(response['schema']=='lyd.root.explicit-sdk-late-verification.v1' and response['status']=='OFFICIAL_SDK_RESULT_RECORDED' and response['request_id']==stem and response['name']=='ck3_attach_profile_bridge_v1' and response['arguments']=={},'actual official SDK direct attach response')
 need(response['route']=='ORIGINAL_CLIENT_OFFICIAL_SDK_EXPLICIT_CALL_AFTER_QUEUE_HARNESS_REFUSAL' and response['is_error']is not True,'actual original ClientSession explicit SDK route')
 need(response['client_session_id']==session['client_session_id']==binding['client_session_id'] and response['native_session_id']==binding['native_session_id'],'actual direct original Client/native sessions')
 need(response['queue_attach_requested_before']is True and response['queue_attach_requested_after']is True and all(response[key]is False for key in ('queue_attach_requested_reset','new_transport','new_client','new_server','reconnected','reinjected')),'actual refused queue preserved; no reset/reconnect/reinject')
 need(bound(response['sdk_result'])==sdk and len(response['native_receipts'])==1,'actual direct response ref3 SDK and single native receipt')
 row=response['native_receipts'][0];original=Path(row['path']).resolve()
 need(original.is_relative_to(RUN/'native-evidence') and (client/row['copy']).resolve()==copy and ref(original)['sha256']==ref(copy)['sha256']==row['sha256'],'original late verification and exact preserved Client native copy')
 native=read(copy);need(native['schema']=='ck3.native-profile-receipt.v1' and native['status']=='attached_snapshot_verified' and Path(native['receipt_path']).resolve()==original,'original typed successful late verification receipt')
 need(native['session_id']==binding['native_session_id'] and native['profile_sha256']==binding['profile_sha256']==session['profile_sha256'] and native['connection_generation']==1 and native['reinjected']is False and native['reconnected']is False,'actual same profile/native generation1 late verification')
 need(all(native['observation_after'][key]==session['target'][key] for key in ('pid','process_create_time')),'actual typed native original PID/create time')
 snapshot=native['snapshot'];need(snapshot['paused']is True and snapshot['date_raw']==binding['date_raw']==53144712 and snapshot['revision']==binding['revision'] and snapshot['native_revision']==binding['native_revision'],'actual original paused late-verification snapshot binding')
 value=read(sdk);texts=[json.loads(item['text']) for item in value['content'] if item.get('type')=='text']
 need(value['isError']is False and value['structuredContent']==native and texts==[native],'one exact successful SDK structured/text/native payload; original RED is never projected to success')
 return {'native_receipt':ref(original),'sdk_result':ref(sdk)}

def main():
 global HEAD,CP,CAP,DIRECT_RESPONSE_REF,CLIENT
 p=argparse.ArgumentParser(description=__doc__)
 for key in ('attach-stem','checkpoint-stem','g2-stem','g3-stem'):p.add_argument('--'+key,required=True)
 p.add_argument('--expected-head',required=True);p.add_argument('--client-output',type=Path,required=True)
 p.add_argument('--checkpoint-source',type=Path,required=True);p.add_argument('--checkpoint-index-sha256',required=True)
 p.add_argument('--capture-source',type=Path,required=True);p.add_argument('--capture-index-sha256',required=True)
 p.add_argument('--attach-route',choices=('queue','direct'),default='queue')
 p.add_argument('--direct-response',type=Path);p.add_argument('--direct-response-sha256')
 p.add_argument('--metadata-result',type=Path,required=True);p.add_argument('--metadata-result-sha256',required=True);p.add_argument('--output-prefix',type=Path,required=True);a=p.parse_args()
 need(re.fullmatch('[0-9a-f]{40}',a.expected_head or '') and a.expected_head not in ('0'*40,'f'*40),'actual final HEAD mandatory; future NULL rejected')
 HEAD=a.expected_head;CP=a.checkpoint_source.resolve();CAP=a.capture_source.resolve();CLIENT=a.client_output.resolve()
 need(CLIENT == (RUN/'persistent-client-001').resolve(),'Actual R31 original Client1 output must be this RUN persistent-client-001')
 need(ref(CP/'INDEX.json')['sha256']==a.checkpoint_index_sha256 and ref(CAP/'INDEX.json')['sha256']==a.capture_index_sha256,'actual new checkpoint/capture source INDEX SHA')
 need(read(CP/'INDEX.json')['source_head']==HEAD,'actual final new reader/author source HEAD; old bundled3 reader refused')
 if a.attach_route=='direct':
  need(a.direct_response is not None and a.direct_response_sha256 is not None,'actual direct response path/SHA mandatory')
  DIRECT_RESPONSE_REF=ref(a.direct_response);need(DIRECT_RESPONSE_REF['sha256']==a.direct_response_sha256,'actual direct response SHA')
 else:need(a.direct_response is None and a.direct_response_sha256 is None,'queued attach must not supply a direct route')
 metadata_ref=ref(a.metadata_result);need(metadata_ref['sha256']==a.metadata_result_sha256,'actual R31 metadata SHA');metadata=read(a.metadata_result);need(metadata['head']==HEAD,'actual R31 metadata HEAD')
 prepared_ref=ref(RUN/'PREPARED.json');session_ref=ref(CLIENT/'session.json');binding_ref=ref(RUN/'ROOT-ATTACHED-BINDING.actual.json');prepared=read(prepared_ref['path']);session=read(session_ref['path']);binding=read(binding_ref['path'])
 need(prepared['schema']=='lyd.r31.root-profile-bound-preparation.v1' and prepared['source_revision']==session['source_revision']==HEAD and session['client_session_id']==binding['client_session_id'],'actual fresh R31 prepared/Client tuple')
 attach_pair=direct_attach_pair(a.attach_stem,binding,session) if a.attach_route=='direct' else pair(a.attach_stem,attach=True)
 attach=read(attach_pair['native_receipt']['path']);attach_sdk=read(attach_pair['sdk_result']['path'])
 need(attach['status']=='attached_snapshot_verified' and attach['session_id']==binding['native_session_id'] and attach['profile_sha256']==binding['profile_sha256']==session['profile_sha256'],'actual verified same-Client/profile/native attach tuple')
 need(attach_sdk['isError'] is False and attach_sdk['structuredContent']==attach and [json.loads(x['text']) for x in attach_sdk['content'] if x.get('type')=='text']==[attach],'actual attach SDK structured/text/native exact equality')
 need(ref(binding['attach_native']['path'])['sha256']==ref(attach_pair['native_receipt']['path'])['sha256'] and ref(binding['attach_sdk']['path'])==attach_pair['sdk_result'],'actual ROOT retained attach references')
 profile=read(session['profile']);guard=read(profile['guard_profile'])
 need(profile['game_version']=='1.20.0.4' and guard['target']['executable_sha256']=='98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518','actual fresh .4 profile and exact installed executable required')
 pairs={'attach':attach_pair,**{key:pair(stem) for key,stem in (('checkpoint',a.checkpoint_stem),('G2',a.g2_stem),('G3',a.g3_stem))}};native=read(pairs['checkpoint']['native_receipt']['path']);saved=native['result']['checkpoint'];need(native['session_id']==binding['native_session_id'] and saved['status']=='saved','actual R31 native save tuple')
 index=read(CP/'INDEX.json');need(index['source_head']==HEAD,'actual sealed R31 checkpoint source')
 prefix=a.output_prefix.resolve();need(prefix.is_relative_to(RUN) and prefix.parent.is_dir() and not prefix.exists(),'fresh same-run prefix');spec=Path(str(prefix)+'.SPEC.actual.json');argv=Path(str(prefix)+'.ARGV.unexecuted.json');need(not spec.exists() and not argv.exists(),'fresh specification/argv')
 d={'schema':'lyd.r31.root-baseline-capture-specification.v1','source_head':HEAD,'prepared':prepared_ref,'client_session':session_ref,'attached_binding':binding_ref,**pairs,'metadata_result':metadata_ref,'compiled_result':metadata['compiled_verification'],'native_clean_qualification':metadata['native_clean_qualification'],'sdk_metadata_artifact':metadata['metadata'],'baseline_author':index['baseline_author'],'materializer':index['baseline_materializer'],'future_preserved_checkpoint':{'path':(RUN/'checkpoints/baseline-original0240/checkpoint.ck3').as_posix(),'bytes':saved['size'],'sha256':saved['sha256']},'input_output':(RUN/'ROOT-BASELINE-MATERIALIZER-INPUTS.actual.json').as_posix(),'materialize_argv_output':(RUN/'ROOT-BASELINE-MATERIALIZE-ARGV.actual.json').as_posix(),'materializer_output':(RUN/'baseline-original0240-author-input-001').as_posix(),'author_output':(RUN/'baseline-original0240-author-001').as_posix()}
 put(spec,d);helper=CAP/'capture_baseline_materializer_inputs_root_only.py';put(argv,{'argv':[PY,'-B','-X','utf8',helper.as_posix(),'--inputs',spec.as_posix(),'--sha256',ref(spec)['sha256'],'--root-create'],'executed':False,'helper':ref(helper),'future_baseline_author_result':None,'body_reads':0,'actual_copy':False})
 print(json.dumps({'specification':ref(spec),'capture_argv':ref(argv),'body_reads':0,'actual_copy':False,'SDK_calls':0},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
