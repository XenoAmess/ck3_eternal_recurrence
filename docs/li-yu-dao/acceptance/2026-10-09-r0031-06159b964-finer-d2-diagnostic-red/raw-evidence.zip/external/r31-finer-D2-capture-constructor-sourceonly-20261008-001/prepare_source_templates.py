"""Create-only R31 staged source templates from the retained R30 function parents."""
from pathlib import Path
import ast,difflib,hashlib,json
B=Path('C:/workspace/ck3_lyd_runtime_20261004');HERE=Path(__file__).parent
P=B/'r30-staged-capture-author-sourceonly-20261008-003'
PINS={'author_staged_capture_specification_root_only.py':'c3a6dfa02aff7fb6c72fa5fb63c399d8fb45f752135209602c7de158d7c0a100',
 'capture_staged_materializer_inputs_root_only.py':'06eecff467ca8eb9c36032c865b6151f411241a2d49521bf4d10fb43f67a9c68',
 'materialize_staged_checkpoint_request.py':'e811a7895f4c53d4d44be7e82f7b520e987559ee421f253cea2e64db4f191432',
 'author_staged_checkpoint.py':'461ce37b8d4d257f0de79a50720ec2af7c393d902b08889d90f38340602d11ac',
 'stage_json_binding.py':'7ff1c8f81b5d2da3c71b2f51f64362f048bf4fca77e41d47445b586274fda80e',
 'compare_staged_observations.py':'1727eae8e47a47ea5c3a9357b9985c9aed995468c140682b67fcd34798c035e8'}
WINDOWS={x+'-staged-observation':x for x in ('D1','D2a','D2b','D3','D4','D5','D6')}
OLD_WINDOWS={x+'-staged-observation':x for x in ('D1','D2','D3','D4','D5','D6')}
SIGNED={'path':(B/'r30-root-signed-B3-input.actual.json').as_posix(),'bytes':3015,'sha256':'5e5860c2d940da5701b954c1cbe568c5df8831ce5277e48562def029113f56af'}
def once(s,old,new):
 assert s.count(old)==1,('exact retained seam',old,s.count(old));return s.replace(old,new,1)
def ref(p):
 r=p.read_bytes();return {'path':p.resolve().as_posix(),'bytes':len(r),'sha256':hashlib.sha256(r).hexdigest()}
def put(p,v):
 with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
class SignedAndWindows(ast.NodeTransformer):
 def visit_Dict(self,node):
  self.generic_visit(node)
  try:v=ast.literal_eval(node)
  except (ValueError,TypeError):return node
  if v==SIGNED:return ast.copy_location(ast.Name(id='SIGNED_INPUT',ctx=ast.Load()),node)
  if v==OLD_WINDOWS:return ast.copy_location(ast.parse(repr(WINDOWS),mode='eval').body,node)
  return node
templates=HERE/'templates';templates.mkdir(exist_ok=False);manifest={};diff=[]
for name,sha in PINS.items():
 original=(P/name).read_text(encoding='utf-8');assert ref(P/name)['sha256']==sha
 s=original.replace('lyd.r30.','lyd.r31.').replace("r30_materializer_","r31_materializer_").replace('r30_exact_parent_','r31_exact_parent_').replace('r30_stage_frozen_','r31_stage_frozen_')
 if name!='stage_json_binding.py':
  s=s.replace("from stage_json_binding import need,read,ref,bind,cache,load_module,B,HEAD", "from stage_json_binding import need,read,ref,bind,cache,load_module,B,HEAD,SIGNED_INPUT")
  if name in ('author_staged_capture_specification_root_only.py','capture_staged_materializer_inputs_root_only.py','materialize_staged_checkpoint_request.py'):
   s=s.replace('sys.dont_write_bytecode=True','sys.dont_write_bytecode=True\nfrom stage_json_binding import SIGNED_INPUT',1)
 if name=='stage_json_binding.py':
  s=once(s,"CONTEXT=Path('C:/lr30s2/ck3_autonomous_player/src/xar_autoplayer/bridge/ingame_decision_outcome_contract.py')", "CONTEXT=Path('C:/lr30s2/ck3_autonomous_player/src/xar_autoplayer/bridge/ingame_decision_outcome_contract.py')\nSIGNED_INPUT=None\nfrom finer_d2_observations import STAGES,STAGE_VALUES")
  s=once(s,"need(stage in ('D1','D2','D3','D4','D5','D6'),'actual diagnostic stage required')","need(stage in STAGES,'actual finer-D2 diagnostic stage required')")
  s=s.replace("'lyd_factory_diag.'+stage[1:]","'lyd_factory_diag.'+str(STAGE_VALUES[stage])")
 if name=='materialize_staged_checkpoint_request.py':
  s=once(s,"d['stage_evidence']['stage']==d['window'][:2]", "d['stage_evidence']['stage']==d['window'].removesuffix('-staged-observation')")
 if name=='author_staged_checkpoint.py':
  s=s.replace('from copy import deepcopy','from copy import deepcopy\nfrom finer_d2_observations import STAGE_VALUES,title_observation,marked_title_rows',1)
  start=s.index(" raw_scan='\\n'.join(raw.splitlines()[node.lineno-1:node.end_lineno])+'\\n'")
  end=s.index(' original_scan=parent.raw_scan',start)
  s=s[:start]+''' # Match the one exact original political/current-head selector by AST.
 selector=ast.parse('tid in political_ids or tid==current_head',mode='eval').body
 matches=[n for n in ast.walk(node) if isinstance(n,ast.If) and ast.dump(n.test,include_attributes=False)==ast.dump(selector,include_attributes=False)]
 need(len(matches)==1,'Exact original Title selector AST required')
 matches[0].test=ast.parse("tid in political_ids or tid==current_head or holder==actor_id or any(k in reader.stored(entries)[0] for k in ('lyd_c2_owned_head_title','lyd_c2_owner_faith'))",mode='eval').body
 exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(Path(__file__)), 'exec'),parent.__dict__)
'''+s[end:]
  s=s.replace("'lyd_factory_diag.'+stage[1:]","'lyd_factory_diag.'+str(STAGE_VALUES[stage])")
  s=once(s,"  state['native_title']=None","  state['native_title']=None\n  state['diagnostic_scoped_title_observation']=title_observation(scan,bound,parent.reader)")
  s=once(s,"'faith_head_title_id':scan['current_head'],'actual_native_stage':bound", "'faith_head_title_id':scan['current_head'],'all_saved_factory_marker_Title_ASTs':marked_title_rows(scan),'scoped_title_observation':title_observation(scan,bound,parent.reader),'actual_native_stage':bound")
  s=once(s,"'faith_head_title_id':scan['current_head'],'result_title_reference':state['result_head_title_reference']", "'faith_head_title_id':scan['current_head'],'all_saved_factory_marker_Title_ASTs':marked_title_rows(scan),'scoped_title_observation':title_observation(scan,bound,parent.reader),'result_title_reference':state['result_head_title_reference']")
  s=once(s," return 0\nif __name__", " return 0 if observed['scoped_title_observation']['diagnostic_advance_allowed'] else 1\nif __name__")
 if name=='compare_staged_observations.py':
  s=once(s,'from stage_json_binding import need,read,ref,cache','from stage_json_binding import need,read,ref,cache\nfrom finer_d2_observations import STAGES,ORDER,title_delta')
  s=once(s,"need(stage in ('D1','D2','D3','D4','D5','D6'),'Actual D1-D6 observed stage')","need(stage in STAGES,'Actual finer-D2 observed stage')")
  s=once(s,"previous_stage='D0';old_titles=", "previous_stage='D0';prior_title=None;old_titles=")
  s=once(s,"need(int(previous_stage[1:])+1==int(stage[1:]),'Consecutive actual observed stage pair only');old_titles=po['political7']", "need(previous_stage in ORDER and ORDER[previous_stage]+1==ORDER[stage],'Consecutive actual D1/D2a/D2b/staged pair only');prior_title=po['scoped_title_observation'];old_titles=po['political7']")
  s=once(s,"'actor_landed_full_AST_deltas':landed", "'actor_landed_full_AST_deltas':landed,'scoped_title_full_AST_delta':title_delta(prior_title,observed['scoped_title_observation'],rowdiff),'all_saved_factory_marker_Title_ASTs':observed['all_saved_factory_marker_Title_ASTs']")
 tree=SignedAndWindows().visit(ast.parse(s));ast.fix_missing_locations(tree);s=ast.unparse(tree)+'\n'
 path=templates/name;path.write_text(s,encoding='utf-8',newline='\n');manifest[name]=ref(path)
 diff.extend(difflib.unified_diff(original.splitlines(keepends=True),s.splitlines(keepends=True),fromfile=str(P/name),tofile=str(path)))
put(HERE/'TEMPLATE-SOURCE-REFS.json',manifest)
(HERE/'R30-R31-SOURCE.diff').write_text(''.join(diff),encoding='utf-8',newline='\n')
print(json.dumps({'templates':len(manifest),'AST_parse_only':True,'future_actual_dependencies':None,'body_reads':0,'SDK_calls':0}))
