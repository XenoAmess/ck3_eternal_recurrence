from pathlib import Path
import ast,hashlib,json
H=Path(__file__).parent;B=H.parent
def ref(p):
 r=p.read_bytes();return {'path':p.resolve().as_posix(),'bytes':len(r),'sha256':hashlib.sha256(r).hexdigest()}
def put(p,v):
 with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
pending={'schema':'lyd.r31.finer-D2-source-materializer-request.v1',**{k:None for k in ('expected_head','run_root','client_output','queue_root','checkpoint_index','D0_source_index','cache_comparator_index','source_export_report','signed_B3_input','overlay_binding','output')},'previous_boundary':{'path':(B/'r30-root-actual-typed-closed-boundary-20261008-001/PREVIOUS-BOUNDARY.actual.json').as_posix(),'bytes':3103,'sha256':'2944ee5104746377a738ae5c1d625846cdb9bb9691ac5e4ca6504e4162b938da'}}
put(H/'SOURCE-REQUEST.pending.json',pending)
text='''R31 finer-D2 capture source, runtime PENDING

ROOT first fills SOURCE-REQUEST.pending.json in a new actual JSON file. The
constructor requires the actual new HEAD, exact CP/D0/cache INDEX ref3 values,
actual export REPORT, new validated signed-B3 input, actual finer-D2 overlay
BINDING, ROOT-selected run/Client/queue paths, and fresh external source output.
It rejects NULL and the old FA0 HEAD. No PID/SID/frame/Title is an input guess.

Invoke the implemented source constructor only after those actual sources exist:
  C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe -B -X utf8 <this-directory>/materialize_finer_D2_source.py --request <actual-source-request.json> --sha256 <actual-request-SHA256>

The resulting INDEX.json gives these exact executable files:
  author_staged_capture_specification_root_only.py
  capture_staged_materializer_inputs_root_only.py
  materialize_staged_checkpoint_request.py
  author_staged_checkpoint.py
  compare_staged_observations.py

For each actual D1/D2a/D2b/D3/D4/D5/D6 event: ROOT queries the current actual event
context and cache-before; SAVE once; cache-after, G2 and G3 at that SAVE-after
frame. No query or save is performed by this constructor. ROOT then runs:
  <PY> -B -X utf8 <source>/author_staged_capture_specification_root_only.py --window <D2a-staged-observation|D2b-staged-observation|other actual stage> --client-output <actual Client directory> --expected-head <actual HEAD> --checkpoint-source <actual CP directory> --checkpoint-index-sha256 <actual CP INDEX SHA> --stage-context-stem <actual context stem> --cache-before-stem <actual before-cache stem> --checkpoint-stem <actual SAVE stem> --cache-after-stem <actual after-cache stem> --g2-stem <actual after-SAVE G2 stem> --g3-stem <actual after-SAVE G3 stem> --runtime-inputs <new actual D0-live-runtime-input JSON> --runtime-inputs-sha256 <actual SHA> --output-prefix <fresh prefix inside actual run> --attempt-label diagnostic
Run the emitted copier argv, materializer argv, and single-body author argv once,
in that order. Formal Title/numeric/callback-registry hooks stay absent.

For comparisons fill the original seven-key STAGE-COMPARISON-INPUTS.pending.json
with actual outputs. D1 compares the new actual D0; then only consecutive
D1->D2a->D2b->D3->D4->D5->D6 pairs are accepted:
  <PY> -B -X utf8 <source>/compare_staged_observations.py --inputs <actual seven-ref JSON> --sha256 <actual SHA> --output <fresh comparison directory>

D2a: actual event lyd_factory_diag.20, native saved stage20. Title is genuinely
unheld; holder=NULL is required here. D2b: event .2/stage2, holder=actual actor
after the original atomic change-container+holder+resolve transaction. Capture
never pauses inside that transaction. Marker Title rows and complete ASTs come
from the same original save scan, including malformed marker rows. A candidate
does not become T unless the same-frame native new_title typed fullID matches
that saved row, the exact owner markers and four properties. D2a/D2b require no
premature head registration or law95. Missing native scope or saved entity is
UNKNOWN/RED, body artifacts remain, advance=false, author exits1; no replacement
Title, old R30 Title, holder fabrication, or auto retry. Consecutive comparisons
also record exact same-T continuity, full political7 and actor-landed AST/cache
deltas, including realm laws, and every original false protection check.

Original formal reader/protection functions are unchanged. Intermediate original
87 false values remain false. D6 uses the unchanged terminal 87/88 checks on the
already verified buffer without another body read. All current formal/B4/B5
credit stays NULL and wholemod is NOT_GREEN. The only seed is the immutable
R29 signed B3 c8601e... checkpoint; R30 failed T is not a cold seed. Templates are
function parents, not an executable binding to a future live run.
'''
(H/'ROOT-CLI.md').write_text(text,encoding='utf-8',newline='\n')
files={p.relative_to(H).as_posix():ref(p) for p in H.rglob('*') if p.is_file() and p.name not in ('INDEX.json','seal_source.py')}
parsed=[]
for p in (H/'materialize_finer_D2_source.py',H/'finer_d2_observations.py'):
 ast.parse(p.read_text(encoding='utf-8'));parsed.append(ref(p))
put(H/'SOURCE-CHECK.actual.json',{'status':'NEW_THIN_AST_PARSE_ONLY','new_source_ASTs':parsed,'template_ASTs_parsed_once_by_prepare_source':6,'old_tests_rerun':False,'body_reads':0,'SDK_calls':0,'Git_MAIN_process_bus_build_calls':0,'future_actual_source_HEAD_and_runtime':None})
files['SOURCE-CHECK.actual.json']=ref(H/'SOURCE-CHECK.actual.json')
put(H/'INDEX.json',{'status':'R31_FINER_D2_CAPTURE_CONSTRUCTOR_SOURCE_READY_ACTUAL_DEPENDENCIES_PENDING','source_head':None,'constructor':ref(H/'materialize_finer_D2_source.py'),'finer_D2_observations':ref(H/'finer_d2_observations.py'),'source_request_template':ref(H/'SOURCE-REQUEST.pending.json'),'ROOT_CLI':ref(H/'ROOT-CLI.md'),'parent_stage_source':{'path':(B/'r30-staged-capture-author-sourceonly-20261008-003/INDEX.json').as_posix(),'bytes':4425,'sha256':'7a39956cb3a526966cb178b19edf4325595f1bdbd321427d2faa05c2b7fcf8ec'},'stage_controller':ref(B/'r31-finer-d2-diagnostic-sourceonly-20261008-001/STAGE-CONTROLLER.source-only.json'),'previous_boundary':pending['previous_boundary'],'stage_values':{'D1':1,'D2a':20,'D2b':2,'D3':3,'D4':4,'D5':5,'D6':6},'original69_87_and_terminal88_unchanged':True,'all_files':files,'future_HEAD_export_CP_cache_D0_overlay_allocation_PID_SID_SAVE_Title':None,'formal_mandate_credit':None,'wholemod_GREEN':False})
print(json.dumps({'INDEX':ref(H/'INDEX.json'),'constructor':ref(H/'materialize_finer_D2_source.py'),'ROOT_CLI':ref(H/'ROOT-CLI.md'),'runtime':'PENDING'},indent=2))
