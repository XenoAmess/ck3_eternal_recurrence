"""Bind actual R31 source dependencies to fresh staged ROOT helpers; no runtime actions."""
from pathlib import Path
import argparse,ast,copy,hashlib,json,re,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).parent;B=Path('C:/workspace/ck3_lyd_runtime_20261004')
OLD_STAGE=B/'r30-staged-capture-author-sourceonly-20261008-003'
OLD_CP=B/'r30-checkpoint-author-sourceonly-20261008-001'
OLD_HEAD='fa0f5e1ee098ab6fab4635bedce939eab857610a'
OLD_PARENT_SHA='0def3969a365e0784c38e49acf11f21d0e8c7ac1af9de8e78b40aa941217a449'
OLD_CP_SHA='9c3b00e279df20c184b681b6bac258ea86aaf6fa502cdaba77ca2e331246eede'
OLD_CACHE=B/'r30-root-cache-comparator-bound-source-20261008-002/compare_actor_cached_succession.py'
OLD_CACHE_SHA='58c8355bdbf1b3eb790d8f1fbf88c4e7285e6abdd3841371dd13529a76086744'
KEYS={'schema','expected_head','run_root','client_output','queue_root','checkpoint_index','D0_source_index','cache_comparator_index','source_export_report','signed_B3_input','overlay_binding','previous_boundary','output'}
SCHEMA='lyd.r31.finer-D2-source-materializer-request.v1'
BOUNDARY={'path':(B/'r30-root-actual-typed-closed-boundary-20261008-001/PREVIOUS-BOUNDARY.actual.json').as_posix(),'bytes':3103,'sha256':'2944ee5104746377a738ae5c1d625846cdb9bb9691ac5e4ca6504e4162b938da'}
SEED={'path':(B/'live-attempt-029/checkpoints/B3-signed-precommit-r3-signed/checkpoint.ck3').as_posix(),'bytes':91709349,'sha256':'c8601e7ba08406a551dcddd2a19e454423db2be6b559fad9985c6d1121b537c9'}
def need(ok,msg):
 if not ok:raise ValueError(msg)
def ref(p):
 p=Path(p).resolve();need(p.suffix in ('.json','.py') and 0<p.stat().st_size<=8*1024*1024,'bounded source/JSON only');raw=p.read_bytes()
 return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(d):
 need(type(d)is dict and set(d)=={'path','bytes','sha256'} and type(d['bytes'])is int and type(d['sha256'])is str,'actual ref3 required; future NULL rejected')
 need(ref(d['path'])==d,'actual source/JSON ref differs');return json.loads(Path(d['path']).read_bytes())
def put(p,d):
 with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
def function_AST(path,name):
 nodes=[x for x in ast.parse(Path(path).read_text(encoding='utf-8')).body if isinstance(x,ast.FunctionDef) and x.name==name]
 need(len(nodes)==1,'one original '+name+' function');return ast.dump(nodes[0],include_attributes=False)
class Bind(ast.NodeTransformer):
 def __init__(self,d,assignments,desc_map):self.d=d;self.assignments=assignments;self.desc_map=desc_map;self.counts={k:0 for k in assignments}
 def visit_Assign(self,n):
  names=[x.id for x in n.targets if isinstance(x,ast.Name)]
  for name in names:
   if name in self.assignments:
    self.counts[name]+=1;n.value=ast.parse(self.assignments[name],mode='eval').body;return n
  return self.generic_visit(n)
 def visit_Dict(self,n):
  try:old=ast.literal_eval(n)
  except (ValueError,TypeError):old=None
  if type(old)is dict and set(old)=={'path','bytes','sha256'} and old['sha256'] in self.desc_map:
   return ast.copy_location(ast.parse(repr(self.desc_map[old['sha256']]),mode='eval').body,n)
  return self.generic_visit(n)
 def visit_Constant(self,n):
  if type(n.value)is not str:return n
  s=n.value;d=self.d
  exact={OLD_HEAD:d['expected_head'],OLD_PARENT_SHA:d['_parent']['sha256'],OLD_CP_SHA:d['checkpoint_index']['sha256'],OLD_CACHE_SHA:d['_cache']['sha256'],
         'persistent-client-001':Path(d['client_output']).name,'official-mcp-queue-002':Path(d['queue_root']).name}
  if s in exact:s=exact[s]
  else:
   for old,new in ((OLD_STAGE.as_posix(),d['output']),(OLD_CP.as_posix(),d['_cp_root']),
           ((B/'live-attempt-030').as_posix(),d['run_root']),('C:/lr30s2',d['_export_root']),
           (OLD_CACHE.parent.as_posix(),Path(d['_cache']['path']).parent.as_posix())):
    if s==old or s.startswith(old+'/'):s=new+s[len(old):];break
  s=s.replace('r30-', 'r31-').replace('R30','R31')
  return ast.copy_location(ast.Constant(s),n)
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--request',type=Path,required=True);p.add_argument('--sha256',required=True);a=p.parse_args()
 stamp=ref(a.request);need(stamp['sha256']==a.sha256,'explicit actual source request SHA');d=read(stamp)
 need(type(d)is dict and set(d)==KEYS and d['schema']==SCHEMA,'closed finer-D2 source request')
 for k in KEYS-{'schema'}:need(d[k] is not None,'future actual '+k+' remains NULL; source cannot be materialized')
 need(type(d['expected_head'])is str and re.fullmatch('[0-9a-f]{40}',d['expected_head']) and d['expected_head'] not in (OLD_HEAD,'0'*40,'f'*40),'actual new source HEAD required')
 need(d['previous_boundary']==BOUNDARY,'exact genuine R30 typed closed predecessor required');read(d['previous_boundary'])
 run=Path(d['run_root']).resolve();client=Path(d['client_output']).resolve();queue=Path(d['queue_root']).resolve();out=Path(d['output']).resolve()
 need(run==B/'live-attempt-031' and client.parent==run and queue.parent==run and client.name=='persistent-client-001','ROOT-selected R31 run/one Client/current queue, no old run or invented identity')
 need(out.is_relative_to(B) and not out.exists() and not out.is_relative_to(run),'fresh external source output only')
 cp=read(d['checkpoint_index']);d0=read(d['D0_source_index']);cache=read(d['cache_comparator_index']);export=read(d['source_export_report']);seed=read(d['signed_B3_input']);overlay=read(d['overlay_binding'])
 need(cp['source_head']==d0['source_head']==cache['source_head']==export['source']['head']==d['expected_head'],'actual CP/D0/cache/export exact current HEAD')
 need(d0['checkpoint_source']==d['checkpoint_index'] and d0['signed_B3_input']==d['signed_B3_input'],'new D0 source must bind this same CP and historical signed seed')
 need(seed['schema']=='lyd.signed-B3-diagnostic-cold-input.v1' and seed['purpose']=='SIGNED_B3_STAGED_FACTORY_DIAGNOSTIC_ONLY' and seed['checkpoint']==SEED and seed['historical_formal_credit']is True and seed['new_cold_validation']is None and seed['formal_acceptance']is None,'only immutable R29 signed B3 seed; no R30 failed T/current callback credit')
 need(overlay['source_head']==d['expected_head'],'actual new finer-D2 overlay/current source binding')
 need(cache['source_export_report']==d['source_export_report'],'current cache source export ref')
 contract=read(cache['contract']);need(contract['source_head']==d['expected_head'] and contract['source_root']==export['source_root'],'cache/provider actual export source tuple')
 parent=cp['formal_author'];need(ref(parent['path'])==parent,'exact current single-body CP author')
 for name in ('raw_scan','protection'):
  need(function_AST(parent['path'],name)==function_AST(OLD_CP/'source-008/author_actual_checkpoint.py',name),'unchanged original '+name+' AST; no relaxed original69/87/88 criteria')
 d.update(run_root=run.as_posix(),client_output=client.as_posix(),queue_root=queue.as_posix(),output=out.as_posix(),_parent=parent,_cache=cache['comparator'],_cp_root=Path(d['checkpoint_index']['path']).parent.as_posix(),_export_root=export['source_root'])
 need(ref(d['_cache']['path'])==d['_cache'],'exact current cache authenticator source')
 templates=json.loads((HERE/'TEMPLATE-SOURCE-REFS.json').read_bytes());source={}
 def emit(name,assignments=None,desc_map=None):
  need(ref(templates[name]['path'])==templates[name],'immutable finer-D2 source template')
  t=Bind(d,assignments or {},desc_map or {});tree=t.visit(ast.parse(Path(templates[name]['path']).read_text(encoding='utf-8')));ast.fix_missing_locations(tree)
  need(all(v==1 for v in t.counts.values()),'one exact top-level dependency assignment '+name)
  s=ast.unparse(tree)+'\n';ast.parse(s);dest=out/name
  with dest.open('x',encoding='utf-8',newline='\n')as f:f.write(s)
  source[name]=ref(dest)
 out.mkdir();(out/'finer_d2_observations.py').write_bytes((HERE/'finer_d2_observations.py').read_bytes());source['finer_d2_observations.py']=ref(out/'finer_d2_observations.py')
 emit('stage_json_binding.py',{'RUN':repr(run),'HEAD':repr(d['expected_head']),'CACHE':f"Path({d['_cache']['path']!r})",'CACHE_SHA':repr(d['_cache']['sha256']),'CONTEXT':f"Path({(Path(d['_export_root'])/'ck3_autonomous_player/src/xar_autoplayer/bridge/ingame_decision_outcome_contract.py').as_posix()!r})",'SIGNED_INPUT':repr(d['signed_B3_input'])})
 emit('author_staged_checkpoint.py',{'CP':f"Path({d['_cp_root']!r})",'PARENT':f"Path({parent['path']!r})",'PARENT_SHA':repr(parent['sha256'])})
 emit('compare_staged_observations.py')
 emit('materialize_staged_checkpoint_request.py',{'P':f"Path({d['_cp_root']!r})",'S':f"Path({Path(parent['path']).parent.as_posix()!r})",'RUN':f"Path({run.as_posix()!r})",'HEAD':repr(d['expected_head'])})
 mat=source['materialize_staged_checkpoint_request.py'];desc_map={'e811a7895f4c53d4d44be7e82f7b520e987559ee421f253cea2e64db4f191432':mat}
 emit('capture_staged_materializer_inputs_root_only.py',{'RUN':f"Path({run.as_posix()!r}).resolve()",'HEAD':repr(d['expected_head'])},desc_map)
 copier=source['capture_staged_materializer_inputs_root_only.py']
 emit('author_staged_capture_specification_root_only.py',{'RUN':f"Path({run.as_posix()!r})",'FORMAL_CAPTURE_HELPER_SHA256':repr(copier['sha256'])},desc_map)
 # Copier has an independent SHA-only check in addition to its exact ref3.
 copier_path=Path(copier['path']);raw=copier_path.read_text(encoding='utf-8');need(raw.count('e811a7895f4c53d4d44be7e82f7b520e987559ee421f253cea2e64db4f191432')==1,'one independent exact materializer SHA guard')
 raw=raw.replace('e811a7895f4c53d4d44be7e82f7b520e987559ee421f253cea2e64db4f191432',mat['sha256']);copier_path.write_text(raw,encoding='utf-8',newline='\n');source[copier_path.name]=ref(copier_path)
 # Rebind spec to the final copier bytes before the source INDEX is sealed.
 spec_path=out/'author_staged_capture_specification_root_only.py';tree=ast.parse(spec_path.read_text(encoding='utf-8'));pin=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='FORMAL_CAPTURE_HELPER_SHA256' for x in n.targets)]
 need(len(pin)==1,'one final copier source pin');pin[0].value=ast.Constant(source[copier_path.name]['sha256']);spec_path.write_text(ast.unparse(ast.fix_missing_locations(tree))+'\n',encoding='utf-8',newline='\n');source[spec_path.name]=ref(spec_path)
 refs={'event_normalizer_sources':[ref(Path(d['_export_root'])/'ck3_autonomous_player/src/xar_autoplayer/bridge'/name) for name in ('ingame_decision_outcome_contract.py','event_window_context_contract.py','event_contract.py')]};put(out/'STAGE-SOURCE-REFS.json',refs)
 put(out/'SOURCE-BINDING.actual.json',{'request':stamp,'source_head':d['expected_head'],'checkpoint_index':d['checkpoint_index'],'D0_source_index':d['D0_source_index'],'cache_comparator_index':d['cache_comparator_index'],'source_export_report':d['source_export_report'],'overlay_binding':d['overlay_binding'],'previous_boundary':d['previous_boundary'],'signed_B3_input':d['signed_B3_input'],'formal_credit':None,'SDK_calls':0,'body_reads':0})
 put(out/'STAGE-COMPARISON-INPUTS.pending.json',{k:None for k in ('prior_author_result','prior_state','prior_typed_protection','prior_cache_result','prior_stage_observations','current_author_result','current_stage_observations')})
 put(out/'INDEX.json',{'status':'R31_FINER_D2_SOURCES_BOUND_ACTUAL_STAGE_RUNTIME_PENDING','source_head':d['expected_head'],'source_files':source,'checkpoint_source':d['checkpoint_index'],'D0_source':d['D0_source_index'],'cache_comparator':d['cache_comparator_index'],'signed_B3_input':d['signed_B3_input'],'source_binding':ref(out/'SOURCE-BINDING.actual.json'),'stage_order':['D0','D1','D2a','D2b','D3','D4','D5','D6'],'original_full_reader_and_protection_unchanged':True,'future_actual_SAVE_body_stage_T_PID_session':None,'formal_mandate_credit':None,'wholemod_GREEN':False})
 print(json.dumps({'source_index':ref(out/'INDEX.json'),'SDK_calls':0,'body_reads':0,'actual_stage_results':None},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
