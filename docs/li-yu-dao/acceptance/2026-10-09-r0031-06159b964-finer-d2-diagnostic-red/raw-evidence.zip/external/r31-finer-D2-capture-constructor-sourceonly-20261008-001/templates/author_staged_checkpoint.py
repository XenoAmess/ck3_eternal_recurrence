"""One-body R30 D1-D6 observations; original formal author/reader/protection remain untouched."""
from pathlib import Path
from copy import deepcopy
from finer_d2_observations import STAGE_VALUES, title_observation, marked_title_rows
import argparse, ast, hashlib, importlib.util, json, sys
sys.dont_write_bytecode = True
from stage_json_binding import need, read, ref, bind, cache, load_module, B, HEAD, SIGNED_INPUT
CP = B / 'r30-checkpoint-author-sourceonly-20261008-001'
PARENT = CP / 'source-008/author_actual_checkpoint.py'
PARENT_SHA = '0def3969a365e0784c38e49acf11f21d0e8c7ac1af9de8e78b40aa941217a449'

def put(p, v):
    with Path(p).open('x', encoding='utf-8', newline='\n') as f:
        json.dump(v, f, ensure_ascii=False, indent=2)
        f.write('\n')

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--request', type=Path, required=True)
    ap.add_argument('--stage-evidence', type=Path, required=True)
    ap.add_argument('--stage-evidence-sha256', required=True)
    ap.add_argument('--read-checkpoint', action='store_true')
    ap.add_argument('--convert', action='store_true')
    a = ap.parse_args()
    need(a.read_checkpoint and a.convert, 'actual one-body read plus same-frame G2/G3 conversion required')
    need(ref(PARENT)['sha256'] == PARENT_SHA, 'Exact current CP source008 author required')
    parent = load_module('r31_exact_parent_single_body_author', PARENT)
    config = parent.validate_next_cold_request(parent.load_json(a.request))
    need(config['expected_source_head'] == HEAD and config['window'] == 'baseline', 'Dedicated staged materializer only; this is not an original0240 baseline author')
    ed = ref(a.stage_evidence)
    need(ed['sha256'] == a.stage_evidence_sha256, 'Actual stage evidence SHA required')
    evidence = read(ed)
    cp = parent.load_json(config['checkpoint_receipt'])
    bound = bind(evidence, cp, parent.converter)
    out = Path(config['output'])
    stage = bound['stage']
    scan_holder = {}
    raw = PARENT.read_text(encoding='utf-8')
    node = next((n for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef) and n.name == 'raw_scan'))
    selector = ast.parse('tid in political_ids or tid==current_head', mode='eval').body
    matches = [n for n in ast.walk(node) if isinstance(n, ast.If) and ast.dump(n.test, include_attributes=False) == ast.dump(selector, include_attributes=False)]
    need(len(matches) == 1, 'Exact original Title selector AST required')
    matches[0].test = ast.parse("tid in political_ids or tid==current_head or holder==actor_id or any(k in reader.stored(entries)[0] for k in ('lyd_c2_owned_head_title','lyd_c2_owner_faith'))", mode='eval').body
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])), str(Path(__file__)), 'exec'), parent.__dict__)
    original_scan = parent.raw_scan

    def observed_scan(text, binding, baseline):
        scan = original_scan(text, binding, baseline)
        scan_holder['value'] = scan
        return scan
    parent.raw_scan = observed_scan
    original_state = parent.baseline_state

    def observed_state(scan, identity, save_sha):
        state = original_state(scan, identity, save_sha)
        political_ids = {int(k) for k in parent.load_json(config['original_baseline'])['political7']}
        state['protected_titles'] = [deepcopy(scan['titles'][tid]) for tid in sorted(political_ids)]
        state['diagnostic_observed_faith_title'] = deepcopy(state['native_title'])
        state['native_title'] = None
        state['diagnostic_scoped_title_observation'] = title_observation(scan, bound, parent.reader)
        state.update(stage='diagnostic_stage_observation', diagnostic_stage=stage, authority='Observed staged diagnostic checkpoint; no current formal callback qualification.', formal_mandate_credit=None)
        state['formal_event_context_qualification'] = {'status': 'DIAGNOSTIC_STAGE_EVENT_ONLY', 'actual_event_definition_key': 'lyd_factory_diag.' + str(STAGE_VALUES[stage]), 'formal_mandate_credit': None}
        state['native_predicate_qualification'] = {'status': 'DIAGNOSTIC_OBSERVATIONS_ONLY', 'reason': 'Historical R29 callbacks cannot authorize this current staged run'}
        return state
    parent.baseline_state = observed_state
    original_write = parent.write_new

    def observed_write(path, obj):
        if Path(path).name == 'STATE.json':
            scan = scan_holder['value']
            political_ids = {int(k) for k in parent.load_json(config['original_baseline'])['political7']}
            original_write(out / 'STAGE-RAW-OBSERVATIONS.actual.json', {'schema': 'lyd.r31.staged-factory-raw-observations.v1', 'stage': stage, 'source_head': HEAD, 'identity': obj['identity'], 'checkpoint_sha256': obj['checkpoint_sha256'], 'actor': scan['actor'], 'faith': scan['faiths'][scan['faith_id']], 'rites': [scan['rites'][i] for i in scan['actual_rites']], 'political7': {str(i): scan['titles'][i] for i in sorted(political_ids)}, 'all_actor_held_Title_ASTs': {str(i): scan['titles'][i] for i in sorted(scan['held_by_protected'][scan['actor']['character_id']])}, 'faith_head_title_id': scan['current_head'], 'all_saved_factory_marker_Title_ASTs': marked_title_rows(scan), 'scoped_title_observation': title_observation(scan, bound, parent.reader), 'actual_native_stage': bound, 'formal_mandate_credit': None, 'formal_B4_B5_pass': None, 'wholemod_GREEN': False})
        if Path(path).name == 'RESULT.json':
            obj.update(diagnostic_stage=stage, diagnostic_author=ref(Path(__file__)), diagnostic_stage_evidence=ed, formal_mandate_credit=None, diagnostic_observations_only=True, formal_B4_B5_pass=None)
        original_write(path, obj)
    parent.write_new = observed_write
    result = parent.run(a.request, True, True)
    scan = scan_holder['value']
    state = parent.load_json(out / 'STATE.json')
    typed = parent.load_json(out / 'TYPED-PROTECTION.json')
    qualified = parent.load_json(out / 'native-qualification/QUALIFIED-NATIVE.json')
    saved_ids = cache.saved_ids(state)
    after_ids = bound['cache_after']['complete_cached_successor_ids']
    political_ids = {int(k) for k in parent.load_json(config['original_baseline'])['political7']}
    observed = {'schema': 'lyd.r31.staged-factory-observations.v1', 'stage': stage, 'source_head': HEAD, 'identity': state['identity'], 'checkpoint_sha256': state['checkpoint_sha256'], 'source_author_result': ref(out / 'RESULT.json'), 'state': ref(out / 'STATE.json'), 'typed_protection': ref(out / 'TYPED-PROTECTION.json'), 'qualified_native': ref(out / 'native-qualification/QUALIFIED-NATIVE.json'), 'stage_evidence': ed, 'actual_native_stage': bound, 'actor': state['actor'], 'faith': state['faith'], 'rites': state['rites'], 'political7': {str(i): scan['titles'][i] for i in sorted(political_ids)}, 'all_actor_held_Title_ASTs': {str(i): scan['titles'][i] for i in sorted(scan['held_by_protected'][scan['actor']['character_id']])}, 'faith_head_title_id': scan['current_head'], 'all_saved_factory_marker_Title_ASTs': marked_title_rows(scan), 'scoped_title_observation': title_observation(scan, bound, parent.reader), 'result_title_reference': state['result_head_title_reference'], 'saved_actor_cached_successor_ids': saved_ids, 'cache_after_SAVE_equals_saved_actor': saved_ids == after_ids, 'cache_before_SAVE_equals_cache_after_SAVE': bound['cache_before']['complete_cached_successor_ids'] == after_ids, 'original87_checks': typed['checks'], 'original87_protection_match': typed['protection_checks_match'], 'terminal_formal_observations': None, 'formal_mandate_credit': None, 'formal_B4_B5_pass': None, 'wholemod_GREEN': False, 'save_body_reads': result['save_body_reads'], 'extra_save_body_reads': 0, 'SDK_calls': 0}
    need(result['save_body_reads'] == 1 and len(typed['checks']) == 87 and (qualified['G2_status'] == 'BOUND_COMPLETE_NATIVE_OBSERVATION'), 'One actual body/original87/complete same-frame G2 qualification required')
    if stage == 'D6':
        variables = scan['actor']['variables']
        code = parent.reader.number(variables, 'lyd_i3b_result_code', required=False)
        if code in (1, 2, 3, 4, 5, 6, 7):
            req = deepcopy(parent.load_json(config['reader_request_template']))
            original = parent.load_json(config['original_baseline'])
            req.update(schema='lyd.i3b.checkpoint-reader-request.v2', mode='future_actual', identity=state['identity'], save={'path': config['preserved_checkpoint']['path'], 'bytes': config['preserved_checkpoint']['bytes'], 'sha256': state['checkpoint_sha256']}, stage='success_postcommit' if code == 1 else 'partial_postcommit', native_predicates=None, native_reference_binding=None, native_title_binding=None, output=str(out / 'terminal-reader-state'))
            req['saved_faith_semantics_binding'] = {'schema': 'lyd.saved-Faith-semantics-binding.v2', 'contract_sha256': parent.reader.SAVED_FAITH_SEMANTICS_SHA}
            req['baseline']['graphs']['faiths'][str(scan['faith_id'])]['entries'] = deepcopy(original['graphs']['faiths'][str(scan['faith_id'])]['entries'])
            req['expected'] = {'serial': parent.reader.number(variables, 'lyd_i3b_result_serial'), 'nonce': parent.reader.number(variables, 'lyd_i3b_result_nonce'), 'phase': 2}
            terminal = parent.reader.observe_text(scan['text'], req, state['checkpoint_sha256'])
            protected = parent.protection(scan, original, terminal)
            put(out / 'D6-TERMINAL-STATE.observed.json', terminal)
            put(out / 'D6-TERMINAL-TYPED-PROTECTION.observed.json', protected)
            observed['terminal_formal_observations'] = {'state': ref(out / 'D6-TERMINAL-STATE.observed.json'), 'typed_protection': ref(out / 'D6-TERMINAL-TYPED-PROTECTION.observed.json'), 'observation_checks_match': terminal['observation_checks_match'], 'protection_checks_match': protected['protection_checks_match'], 'protection_count': len(protected['checks']), 'actual_result_code': code, 'formal_mandate_credit': None, 'formal_B4_B5_pass': None}
        else:
            observed['terminal_formal_observations'] = {'status': 'NO_ACTUAL_TERMINAL_CODE', 'actual_result_code': code, 'formal_mandate_credit': None}
    put(out / 'DIAGNOSTIC-STAGE-OBSERVATIONS.actual.json', observed)
    print(json.dumps({'stage': stage, 'observations': ref(out / 'DIAGNOSTIC-STAGE-OBSERVATIONS.actual.json'), 'body_reads': 1, 'formal_mandate_credit': None, 'cache_after_SAVE_equals_saved_actor': observed['cache_after_SAVE_equals_saved_actor']}))
    return 0 if observed['scoped_title_observation']['diagnostic_advance_allowed'] else 1
if __name__ == '__main__':
    raise SystemExit(main())
