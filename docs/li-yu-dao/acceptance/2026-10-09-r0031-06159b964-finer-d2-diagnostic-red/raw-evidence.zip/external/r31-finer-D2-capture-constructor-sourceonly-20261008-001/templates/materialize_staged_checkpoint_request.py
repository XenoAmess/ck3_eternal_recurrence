"""Bind one R30 actual JSON tuple to a fresh single-scan author argv. No SDK or binary/save reads."""
from pathlib import Path
import argparse, copy, hashlib, importlib.util, json, re, sys
sys.dont_write_bytecode = True
from stage_json_binding import SIGNED_INPUT
P = Path('C:/workspace/ck3_lyd_runtime_20261004/r30-checkpoint-author-sourceonly-20261008-001')
S = P / 'source-008'
B = P.parent
RUN = B / 'live-attempt-030'
HEAD = 'fa0f5e1ee098ab6fab4635bedce939eab857610a'
SCHEMA = 'lyd.r31.staged-diagnostic-materializer-input.v1'
KEYS = {'stage_evidence', 'schema', 'prepared', 'client_session', 'attach', 'metadata_result', 'compiled_result', 'native_clean_qualification', 'sdk_metadata_artifact', 'checkpoint', 'G2', 'G3', 'preserved_checkpoint', 'window', 'author_output', 'signed_B3_input', 'native_title_reference_query', 'native_event_numeric_query', 'formal_callback_registry'}

def need(ok, msg):
    if not ok:
        raise ValueError(msg)

def unique(raw):

    def pairs(rows):
        result = {}
        for k, v in rows:
            need(k not in result, 'duplicate JSON key ' + k)
            result[k] = v
        return result
    return json.loads(raw.decode('utf-8-sig'), object_pairs_hook=pairs, parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite JSON')))

def sdk_wrapper_path(path):
    p = Path(path).resolve()
    need(p.name.endswith('.sdk-result.json') and p.parent == (Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-030') / 'persistent-client-001').resolve(), 'explicit original same-run Client SDK wrapper only')
    return p

def ref(path, *, sdk_wrapper=False):
    p = Path(path).resolve()
    need(p.suffix.lower() in ('.json', '.py', '.txt', '.md', '.mod', '.yml'), 'JSON/source reads only')
    need(type(sdk_wrapper) is bool, 'literal SDK wrapper role')
    limit = 16 * 1024 * 1024 if sdk_wrapper else 8 * 1024 * 1024
    if sdk_wrapper:
        sdk_wrapper_path(p)
    need(p.stat().st_size <= limit, 'bounded JSON/source only')
    raw = p.read_bytes()
    return {'path': p.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def read(stamp, *, sdk_wrapper=False):
    need(type(stamp) is dict and set(stamp) == {'path', 'bytes', 'sha256'} and (type(stamp['bytes']) is int) and (0 < stamp['bytes'] <= (16 * 1024 * 1024 if sdk_wrapper else 8 * 1024 * 1024)) and (type(stamp['sha256']) is str) and re.fullmatch('[0-9a-f]{64}', stamp['sha256']), 'explicit positive actual ref3 required')
    actual = ref(stamp['path'], sdk_wrapper=sdk_wrapper)
    need(actual['bytes'] == stamp['bytes'] and actual['sha256'] == stamp['sha256'], 'actual original artifact changed')
    return unique(Path(stamp['path']).read_bytes())

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m

def put(p, d):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
        f.write('\n')

def validate_inputs(d):
    need(type(d) is dict and set(d) == KEYS and (d['schema'] == SCHEMA), 'closed R30 materializer INPUT schema')
    for k in ('prepared', 'client_session', 'metadata_result', 'compiled_result', 'native_clean_qualification', 'sdk_metadata_artifact'):
        need(d[k] is not None, 'future mandatory actual ' + k + ' is NULL')
    need(d['window'] in {'D1-staged-observation': 'D1', 'D2a-staged-observation': 'D2a', 'D2b-staged-observation': 'D2b', 'D3-staged-observation': 'D3', 'D4-staged-observation': 'D4', 'D5-staged-observation': 'D5', 'D6-staged-observation': 'D6'}, 'Explicit D1-D6 diagnostic observation window only')
    need(type(d['stage_evidence']) is dict and set(d['stage_evidence']) == {'stage', 'stage_context', 'cache_before', 'cache_after'} and (d['stage_evidence']['stage'] == d['window'].removesuffix('-staged-observation')), 'Exact matching actual stage evidence required')
    need(type(d['author_output']) is str and Path(d['author_output']).is_absolute(), 'explicit fresh D0 author output required')
    for k in ('attach', 'checkpoint', 'G2', 'G3'):
        need(type(d[k]) is dict and set(d[k]) == {'native_receipt', 'sdk_result'}, 'explicit original SDK/native pair ' + k)
    need(d['signed_B3_input'] is not None, 'ROOT actual signed seed input required')
    need(all((d[k] is None for k in ('native_title_reference_query', 'native_event_numeric_query', 'formal_callback_registry'))), 'D0 may not reuse historical callbacks, Title/numeric queries or formal registry')
    return d

def authenticate_pair(pair, hook):
    native = read(pair['native_receipt'])
    sdk = read(pair['sdk_result'], sdk_wrapper=True)
    hook.validate_sdk_native(sdk, native)
    need(native['receipt_path'] and Path(native['receipt_path']).resolve() == Path(pair['native_receipt']['path']).resolve(), 'original native receipt_path differs')
    return native

def actual_signed_input(desc):
    need(desc == SIGNED_INPUT, 'Exact ROOT successful signed seed intake ref required')
    seed = read(desc)
    need(seed['schema'] == 'lyd.signed-B3-diagnostic-cold-input.v1' and seed['purpose'] == 'SIGNED_B3_STAGED_FACTORY_DIAGNOSTIC_ONLY' and (seed['historical_formal_credit'] is True) and (seed['new_cold_validation'] is None) and (seed['formal_acceptance'] is None), 'Historical seed authority stays historical; current formal credit remains NULL')
    return seed

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--inputs', type=Path, required=True)
    p.add_argument('--inputs-sha256', required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    stamp = ref(a.inputs)
    need(stamp['sha256'] == a.inputs_sha256, 'explicit ROOT actual INPUT SHA required')
    d = validate_inputs(read(stamp))
    f = unique((P / 'AUTHOR-FRAMEWORK.pending-runtime.json').read_bytes())
    f['schema'] = 'lyd.r31.actual-checkpoint-author-request.formal-registry.v2'
    prepared = read(d['prepared'])
    profile = read(prepared['profile'])
    original = read(prepared['original_profile'])
    session = read(d['client_session'])
    need(prepared['schema'] == 'lyd.r31.root-profile-bound-preparation.v1' and prepared['status'] == 'PREPARED_FILES_AND_ROOT_LIVE_PROFILE_ONLY' and (prepared['source_revision'] == HEAD), 'actual R30 prepared/head required')
    need(len(profile) == 10 and len(original) == 9 and (set(profile) == set(original) | {'normal_exit_source_inventory'}) and all((profile[k] == v for k, v in original.items())), 'actual final10 exact original9 relation required')
    need(session['schema'] == 'ck3.lyd.persistent-mcp-session.v1' and session['source_revision'] == HEAD and (session['profile_sha256'] == prepared['profile']['sha256']) and (Path(session['profile']).resolve() == Path(prepared['profile']['path']).resolve()) and (session['automatic_attach'] is False) and (session['automatic_retry'] is False), 'actual R30 Client/session/final10 tuple required')
    need(Path(profile['userdir']).resolve() == (RUN / 'userdir').resolve() and session['target']['pid'] == prepared['root_actual_live_binding']['process_id'], 'fresh current ROOT run/PID required')
    guard = read(prepared['guard'])
    need(guard['target']['pid'] == session['target']['pid'], 'reviewed actual guard PID')
    need(guard['target']['process_create_time'] == session['target']['process_create_time'] == prepared['root_actual_live_binding']['process_create_time'], 'actual creation identity required')
    metadata, compiled, qualification = [read(d[k]) for k in ('metadata_result', 'compiled_result', 'native_clean_qualification')]
    export = unique(Path(f['source_export_report']).read_bytes())
    need(d['native_clean_qualification'] == metadata['native_clean_qualification'] and d['sdk_metadata_artifact'] == metadata['metadata'], 'actual metadata qualification/tool artifact descriptors required')
    rows = read(d['sdk_metadata_artifact'])
    need(len(rows) == 29, 'actual metadata28 required')
    sys.path.insert(0, str(S / 'qualification'))
    q = module('r31_materializer_native_qualification', S / 'qualification/next_cold_qualification.py')
    declared = read(qualification['actual_ROOT_request'])
    refs = {'compiled_result': d['compiled_result'], 'source_export_report': ref(f['source_export_report'])}
    q.validate_bindings(qualification, metadata, compiled, export, profile, refs, HEAD, declared)
    author = module('r31_materializer_author', S / 'author_actual_checkpoint.py')
    author.validate_metadata28(rows, metadata, export)
    need(author.converter.lineage.verify_codec_artifact(f['sdk_codec_artifact'], f['sdk_codec_artifact']['sha256']) is not None, 'actual12 DTO contract required')
    sys.path.insert(0, str(S / 'title_reference'))
    hook = module('r31_materializer_title_hook', S / 'title_reference/title_reference_hook.py')
    receipts = {k: authenticate_pair(d[k], hook) for k in ('attach', 'checkpoint', 'G2', 'G3')}
    cp = receipts['checkpoint']
    before = author.converter.frame_binding(cp['snapshot_before'])
    prov = {'session_id': cp['session_id'], 'profile_sha256': prepared['profile']['sha256'], 'pipe_name': cp['pipe_name'], 'game_pid': before['game_pid'], 'connection_generation': before['connection_generation']}
    need(cp['profile_sha256'] == prepared['profile']['sha256'] and before['game_pid'] == session['target']['pid'], 'actual checkpoint/profile/PID')
    for k in ('session_id', 'profile_sha256', 'pipe_name'):
        need(receipts['attach'][k] == prov[k], 'actual attached native provenance ' + k)
    need(receipts['attach']['status'] == 'attached_snapshot_verified', 'actual native attach required')
    after, transition = author.converter.transition.bind_checkpoint_transition(cp, prov)
    for key, operation in (('G2', 'assembly_predicates'), ('G3', 'religious_title')):
        author.converter.outer_identity(receipts[key], prov)
        author.converter.sdk.normalize_public_query(receipts[key]['result'], after, operation)
    need(cp['status'] == 'native_gameplay_postcondition_verified', 'actual save postcondition required')
    saved = cp['result']['checkpoint']
    need(saved['status'] == 'saved' and saved['date_raw'] == after['date_raw'], 'actual saved descriptor required')
    preserve = d['preserved_checkpoint']
    need(type(preserve) is dict and set(preserve) == {'path', 'bytes', 'sha256'} and (preserve['bytes'] == saved['size']) and (preserve['sha256'] == saved['sha256']), 'actual immutable content descriptor must match originalSDK')
    savedpath = Path(preserve['path']).resolve()
    need(savedpath.is_relative_to(B) and savedpath.is_file() and (savedpath.stat().st_size == saved['size']), 'existing immutable external copy size required; body remains unopened')
    control = actual_signed_input(d['signed_B3_input'])
    target = a.output.resolve()
    out = Path(d['author_output']).resolve()
    need(target.is_relative_to(B) and (not target.exists()) and out.is_relative_to(RUN) and (not out.exists()), 'new external request/currentR30 author output required')
    config = copy.deepcopy(f)
    config.update(native_clean_qualification=d['native_clean_qualification'], profile=prepared['profile']['path'], compiled_result=d['compiled_result']['path'], metadata_result=d['metadata_result']['path'], sdk_metadata_artifact=d['sdk_metadata_artifact'], checkpoint_receipt=d['checkpoint']['native_receipt']['path'], G2_receipt=d['G2']['native_receipt']['path'], G3_receipt=d['G3']['native_receipt']['path'], preserved_checkpoint=preserve, window='baseline', output=out.as_posix())
    author.validate_next_cold_request(config)
    target.mkdir()
    put(target / 'STAGE-EVIDENCE.actual.json', d['stage_evidence'])
    argv = [sys.executable, '-B', '-X', 'utf8', 'C:/workspace/ck3_lyd_runtime_20261004/r30-staged-capture-author-sourceonly-20261008-003/author_staged_checkpoint.py', '--request', (target / 'AUTHOR-INPUT.actual.json').as_posix(), '--stage-evidence', (target / 'STAGE-EVIDENCE.actual.json').as_posix(), '--stage-evidence-sha256', ref(target / 'STAGE-EVIDENCE.actual.json')['sha256'], '--read-checkpoint', '--convert']
    options = {}
    for key, flag, schema in (('native_title_reference_query', '--native-title-reference-query', 'lyd.author.native-title-reference-query.v1'), ('native_event_numeric_query', '--native-event-numeric-query', 'lyd.author.native-event-value-query.v1')):
        if d[key] is not None:
            query = read(d[key])
            need(query['schema'] == schema, 'explicit current query schema')
            native = hook.authenticate_query_source(dict(query, schema=hook.QUERY_SCHEMA), prov)
            need(native['result']['source'] == {**{k: before[k] for k in ('snapshot_id', 'revision', 'native_revision', 'date_raw')}, 'paused': True, 'backend_id': 'native-headless'}, 'optional query must be exact saved before frame')
            argv.extend([flag, d[key]['path']])
            options[key] = d[key]
    need(d['formal_callback_registry'] is None or d['window'] in ('B3-signed-precommit', 'B4-factory-result', 'B5-final-protection'), 'callback registry limited to explicit formal windows')
    if d['formal_callback_registry'] is not None:
        registry = read(d['formal_callback_registry'])
        need(registry['source_head'] == HEAD and registry['window'] == d['window'], 'exact formal registry source/window')
        argv.extend(['--formal-callback-registry', d['formal_callback_registry']['path']])
    put(target / 'AUTHOR-INPUT.actual.json', config)
    put(target / 'AUTHOR-ARGV.actual.json', {'argv': argv, 'executed': False, 'requested_body_scans': 1})
    put(target / 'REQUEST-BINDING.actual.json', {'schema': 'lyd.r31.actual-checkpoint-request-source-bound.v1', 'status': 'ACTUAL_JSON_BOUND_AUTHOR_NOT_EXECUTED', 'inputs': stamp, 'prepared': d['prepared'], 'profile': prepared['profile'], 'original_profile9_retained': prepared['original_profile'], 'client_session': d['client_session'], 'original_refs': {k: d[k] for k in ('attach', 'checkpoint', 'G2', 'G3')}, 'before': before, 'after': after, 'actual_transition': transition, 'preserved': preserve, 'native_products_verified_from_observed_qualification_descriptors_only': True, 'native_product_binary_checks_deferred_to_exact_author': True, 'optional_queries': options, 'formal_callback_registry': d['formal_callback_registry'], 'signed_seed_input': d['signed_B3_input'], 'purpose': 'STAGED_FACTORY_DIAGNOSTIC_OBSERVATIONS_ONLY', 'diagnostic_stage': d['stage_evidence']['stage'], 'formal_reader_window_used': False, 'historical_callbacks_reused': False, 'body_reads': 0, 'binary_reads': 0, 'SDK_game_calls': 0, 'main_writes': 0, 'formal_acceptance': None, 'actual_pass': None})
    print(json.dumps({'request': ref(target / 'AUTHOR-INPUT.actual.json'), 'argv': argv, 'formal_acceptance': None, 'body_reads': 0}, indent=2))
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
