from pathlib import Path
import ast,json
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
p=B/'r30-checkpoint-author-sourceonly-20261008-001/source-008/reader/i3b_checkpoint_reader.py'
s=p.read_text(encoding='utf-8')
for n in ast.parse(s).body:
 if isinstance(n,ast.FunctionDef) and n.name in ('stored','number','scope','typed_ref','variable','scalar_id','one'):
  print('\nFUNCTION',n.name);print('\n'.join(s.splitlines()[n.lineno-1:n.end_lineno]))
p=Path('C:/lr30s2/ck3_autonomous_player/src/xar_autoplayer/bridge/event_window_context_contract.py')
s=p.read_text(encoding='utf-8')
for n in ast.parse(s).body:
 if isinstance(n,ast.FunctionDef) and ('named' in n.name or 'scope' in n.name):
  print('\nFUNCTION',n.name);print('\n'.join(s.splitlines()[n.lineno-1:n.end_lineno]))
for p in (B/'r31-finer-d2-diagnostic-sourceonly-20261008-001/STAGE-CONTROLLER.source-only.json',B/'r30-D0-capture-author-sourceonly-20261008-003/INDEX.json'):
 print('\nFILE',p);print(p.read_text(encoding='utf-8'))
