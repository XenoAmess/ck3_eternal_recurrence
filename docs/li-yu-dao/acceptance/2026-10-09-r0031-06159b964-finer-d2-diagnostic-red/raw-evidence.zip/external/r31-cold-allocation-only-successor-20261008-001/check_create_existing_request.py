"""ROOT-only once check/create of the existing immutable R31 request."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
def ref(p):
 p=Path(p).resolve();b=p.read_bytes();return {'path':p.as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,v):
 with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--request',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 request=ref(a.request)
 if request['sha256']!=a.sha256:raise ValueError('Exact original request SHA differs')
 out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);calls=[]
 for mode in('check','create'):
  command=[sys.executable,'-B','-X','utf8',str(HERE/'prepare_next_formal_cold.py'),'--request',request['path'],'--sha256',request['sha256'],'--'+mode]
  step=out/(mode+'-invocation');step.mkdir();put(step/'ARGV.json',{'argv':command,'cwd':'C:/workspace/ck3_eternal_recurrence'})
  with(step/'stdout.bin').open('xb')as stdout,(step/'stderr.bin').open('xb')as stderr:done=subprocess.run(command,cwd='C:/workspace/ck3_eternal_recurrence',stdout=stdout,stderr=stderr)
  item={'step':mode,'exit_code':done.returncode,'stdout':ref(step/'stdout.bin'),'stderr':ref(step/'stderr.bin')};put(step/'RESULT.json',item);calls.append(item)
  if done.returncode!=0:break
 ok=len(calls)==2 and all(item['exit_code']==0 for item in calls)
 result={'status':'ACTUAL_COLD_FILES_CREATED_NO_GAME'if ok else'COLD_PREPARATION_RED_PRESERVED','request':request,'calls':calls,'automatic_retry':False,'request_regenerated':False,'game_started':False,'consumer_started':False,'native_injected':False}
 if ok:
  run=Path(json.loads(a.request.read_bytes())['output']);result.update(inputs=ref(run/'INPUTS.json'),cold_receipt=ref(run/'COLD-MATERIALIZED.json'),cold_inventory=ref(run/'COLD-SOURCE-INVENTORY.json'))
 put(out/'RESULT.json',result);print(json.dumps(result,ensure_ascii=False,indent=2));return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
