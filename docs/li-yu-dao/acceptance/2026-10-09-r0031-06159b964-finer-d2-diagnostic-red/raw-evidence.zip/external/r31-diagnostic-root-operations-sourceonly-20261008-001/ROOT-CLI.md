R31 finite ROOT diagnostic operations source; no automatic execution.
PY = C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe
HERE = C:/workspace/ck3_lyd_runtime_20261004/r31-diagnostic-root-operations-sourceonly-20261008-001
RUN = C:/workspace/ck3_lyd_runtime_20261004/live-attempt-031

After ROOT's real bind/Client/attach records exist, create the exact existing
D0-live-runtime-inputs.v1 JSON once from retained actual files:
  <PY> -B -X utf8 <HERE>/author_diagnostic_operations.py runtime-inputs --prepared <RUN>/PREPARED.json --prepared-sha256 <actualSHA> --client-session <RUN>/persistent-client-001/session.json --client-session-sha256 <actualSHA> --attached-binding <RUN>/ROOT-ATTACHED-BINDING.actual.json --attached-binding-sha256 <actualSHA> --attach-stem <actual retained attach stem> --output <RUN>/D0-LIVE-RUNTIME-INPUTS.actual.json
The original strict dispatch pair function checks the actual mcp-queue-001,
Client copies, original native path, SDK SHA and request ID. This reuses exact
metadata/compile/native qualification refs already recorded by ROOT and does
not rerun any qualification. PID/session/profile facts are retained inputs.

Stage call arguments are the exact SDK inputSchema rows in TOOL-CONTRACTS.actual.json:
  ck3_take_profile_native_snapshot_v1 required=; optional=
  ck3_query_profile_event_window_v1 required=event_instance_id,expected_revision; optional=
  ck3_select_profile_event_option_v1 required=option_number,event_instance_id,expected_revision; optional=
  ck3_save_profile_checkpoint_v1 required=expected_revision; optional=
  ck3_query_profile_actor_cached_succession_v1 required=expected_revision; optional=
  ck3_query_profile_confucian_assembly_predicates_v1 required=expected_revision; optional=
  ck3_query_profile_confucian_religious_title_v1 required=expected_revision; optional=

Fill a fresh argument JSON from the actual profile/current public revision and
current event query. Required future values remain NULL in the pending template
and are rejected by the author. No option/event/Title ID is generated here.
  <PY> -B -X utf8 <HERE>/author_diagnostic_operations.py tool-spec --tool <one of the seven actual names> --arguments <actualARGS.json> --arguments-sha256 <actualSHA> --request-id <fresh r31-root-... ID> --output <RUN>/<fresh>.SPEC.actual.json
This emits the existing four-key ROOT spec only. ROOT then uses its current
operations/run_request.py attached phase and --execute on the existing Client,
actual consumer INDEX/source author/executor SHA and original attach binding.
This helper never invokes run_request or its executor.

For D0: cache-before SAVE -> SAVE once -> cache-after SAVE -> G2/G3 at the actual
SAVE-after public frame. Native cached query and both G2/G3 arguments must use
that actual frame, never a predicted increment. Use the single original copy.
  <PY> -B -X utf8 <HERE>/author_diagnostic_operations.py capture-argv --stage D0 --runtime-inputs <RUN>/D0-LIVE-RUNTIME-INPUTS.actual.json --runtime-inputs-sha256 <actualSHA> --checkpoint-stem <actualSAVE> --g2-stem <actualafterG2> --g3-stem <actualafterG3> --output-prefix <RUN>/<fresh-prefix> --output <RUN>/<fresh-D0-thin-argv.json>
ROOT runs this emitted argv to make the original D0 SPEC/copier argv, then its
copier, materializer, single body author in order. The new D0 wrapper fixes ONLY
the observed old queue literal official-mcp-queue-002 -> actual mcp-queue-001;
old D0 source stays immutable and all original guards/pins/11-key input contract
remain. Its emitted author directory is D0-diagnostic-author-001. Then use the
already delivered r31-D0-comparison-input-author-sourceonly-20261008-001 author
in cache mode, execute its comparator once, then D0 mode/six-ref comparison.

For each actual D1/D2a/D2b/D3/D4/D5/D6 event: query the actual current stage context,
cache-before SAVE -> SAVE once -> cache-after SAVE -> G2/G3 actual SAVE-after.
  <PY> -B -X utf8 <HERE>/author_diagnostic_operations.py capture-argv --stage <actualstage> --runtime-inputs <sameactualruntimeJSON> --runtime-inputs-sha256 <actualSHA> --stage-context-stem <actualquery> --cache-before-stem <actualbeforecache> --checkpoint-stem <actualSAVE> --cache-after-stem <actualaftercache> --g2-stem <actualafterG2> --g3-stem <actualafterG3> --output-prefix <RUN>/<fresh-stage-prefix> --output <RUN>/<fresh-stage-thin-argv.json>
Run emitted thin argv, copier, materializer and body author once; use retained
JSON for consecutive D0->D1->D2a->D2b->D3->D4->D5->D6 comparisons. No callback/
Title/numeric formal hooks are passed. D2a genuinely unheld T and D2b same T
after atomic holder/resolve stay explicit. Original false 87/88 checks remain
false; missing stage scope/Title stays UNKNOWN/RED. New diagnostic/formal credit
remains NULL. This packet creates no runtime or capture output before ROOT runs.
