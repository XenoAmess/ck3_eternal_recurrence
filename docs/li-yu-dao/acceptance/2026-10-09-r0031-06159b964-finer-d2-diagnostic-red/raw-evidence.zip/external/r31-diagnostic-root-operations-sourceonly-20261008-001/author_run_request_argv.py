"""Emit the original R31 once-only ROOT request entry; never enqueue or execute it."""
from pathlib import Path
import argparse,hashlib,json
B=Path('C:/workspace/ck3_lyd_runtime_20261004');RUN=B/'live-attempt-031'
S=B/'r31-root-actual-runtime-source-20261008-001';C=B/'r31-root-actual-consumer-source-20261008-001'
PY='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
HEAD='06159b964d859d30f2f07f4b183284df7d6dac47'
def need(ok,msg):
 if not ok:raise ValueError(msg)
def ref(p):
 p=Path(p).resolve();need(p.suffix in('.json','.py')and 0<p.stat().st_size<=8*1024*1024,'Compact actual source/spec JSON only')
 raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def main():
 a=argparse.ArgumentParser(description=__doc__)
 for name in('spec','attached-binding'):a.add_argument('--'+name,type=Path,required=True);a.add_argument('--'+name+'-sha256',required=True)
 a.add_argument('--request-argv-output',type=Path,required=True);a.add_argument('--execution-output',type=Path,required=True);a.add_argument('--output',type=Path,required=True);a.add_argument('--include-execute',action='store_true',help='Include ROOT explicit --execute flag in emitted argv; this helper never executes it')
 v=a.parse_args();sp=ref(v.spec);binding=ref(v.attached_binding)
 need(sp['sha256']==v.spec_sha256 and binding['sha256']==v.attached_binding_sha256,'Exact ROOT actual spec/binding SHA required')
 need(Path(sp['path']).is_relative_to(RUN)and Path(binding['path'])==RUN/'ROOT-ATTACHED-BINDING.actual.json','Actual current-run retained input paths required')
 index=ref(C/'INDEX.json');consumer=json.loads((C/'INDEX.json').read_bytes());need(consumer['source_revision']==HEAD and consumer['attempt_id']=='R0031' and Path(consumer['run_root']).resolve()==RUN,'Actual frozen current consumer required')
 locations=[v.request_argv_output.resolve(),v.execution_output.resolve(),v.output.resolve()]
 need(len(set(locations))==3 and all(p.is_relative_to(RUN)and not p.exists()for p in locations)and v.output.resolve().parent.is_dir(),'Fresh distinct same-run output locations required')
 author=ref(S/'core/author_formal_request.py');executor=ref(S/'operations/execute_request.py');entry=ref(S/'operations/run_request.py')
 argv=[PY,'-B','-X','utf8',entry['path'],'--run-directory',RUN.as_posix(),'--consumer-source',C.as_posix(),'--consumer-index-sha256',index['sha256'],'--request-author',author['path'],'--request-author-sha256',author['sha256'],'--executor',executor['path'],'--executor-sha256',executor['sha256'],'--spec',sp['path'],'--spec-sha256',sp['sha256'],'--argv-output',locations[0].as_posix(),'--execution-output',locations[1].as_posix(),'--phase','attached','--attached-binding',binding['path'],'--attached-binding-sha256',binding['sha256']]
 if v.include_execute:argv+=['--execute']
 with locations[2].open('x',encoding='utf-8',newline='\n')as f:json.dump({'argv':argv,'executed':False,'consumer_index':index,'request_author':author,'executor':executor,'run_request':entry,'actual_SPEC':sp,'actual_retained_attach':binding,'automatic_retry':False,'SDK_calls':0},f,ensure_ascii=False,indent=2);f.write('\n')
 print(json.dumps({'output':ref(locations[2]),'executed':False,'SDK_process_bus_body_calls':0},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
