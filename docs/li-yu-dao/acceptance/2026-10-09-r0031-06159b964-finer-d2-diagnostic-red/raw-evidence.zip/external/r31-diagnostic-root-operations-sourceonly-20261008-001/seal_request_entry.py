from pathlib import Path
import ast,hashlib,json
P=Path(__file__).resolve().parent;p=P/'author_run_request_argv.py';raw=p.read_bytes();ast.parse(raw)
row={'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
with(P/'REQUEST-ENTRY-SOURCE-INDEX.json').open('x',encoding='utf-8',newline='\n')as f:json.dump({'status':'SOURCE_READY_ACTUAL_SPEC_AND_RETAINED_ATTACH_REQUIRED','author':row,'parent_operations_index':'INDEX.json','future_actual_live_facts':None,'AST_checks':1,'SDK_process_bus_body_calls':0},f,indent=2);f.write('\n')
with(P/'ROOT-REQUEST-CLI.md').open('x',encoding='utf-8',newline='\n')as f:f.write('''After the actual SPEC and ROOT-ATTACHED-BINDING exist:
<PY> -B -X utf8 <HERE>/author_run_request_argv.py --spec <actual ROOT SPEC.json> --spec-sha256 <actual SHA> --attached-binding <RUN>/ROOT-ATTACHED-BINDING.actual.json --attached-binding-sha256 <actual SHA> --request-argv-output <RUN>/<fresh-executor-argv.json> --execution-output <RUN>/<fresh-request-execution-dir> --output <RUN>/<fresh-ROOT-run-request-argv.json> --include-execute
ROOT executes the resulting argv once. This invokes the existing run_request.py and once-only execute_request.py, original consumer INDEX, request author and retained attach. Omitting --include-execute emits the same file-only run_request entry. The source author itself never runs either route, reads no SDK receipt/session/probe and adds no retry or second attach.
''')
print(json.dumps({'author':row},indent=2))
