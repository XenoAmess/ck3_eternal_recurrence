from pathlib import Path
import ast,hashlib,json
B=Path('C:/workspace/ck3_lyd_runtime_20261004');P=Path(__file__).resolve().parent
def ref(p):
 p=Path(p).resolve();r=p.read_bytes();return {'path':p.as_posix(),'bytes':len(r),'sha256':hashlib.sha256(r).hexdigest()}
def put(name,d):
 with(P/name).open('x',encoding='utf-8',newline='\n')as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
for name in('d0_queue_successor.py','author_diagnostic_operations.py'):ast.parse((P/name).read_bytes(),filename=name)
mr=ref(B/'r31-root-actual-metadata-20261008-001/RESULT.json');assert mr['sha256']=='e312916a7ad9b210d9b48cd05d51fd43d79cda1d35698109c91dcc94e10dcde7'
m=json.loads(Path(mr['path']).read_bytes());rows=json.loads(Path(m['metadata']['path']).read_bytes());assert ref(m['metadata']['path'])==m['metadata']
names={'ck3_query_profile_event_window_v1','ck3_query_profile_actor_cached_succession_v1','ck3_save_profile_checkpoint_v1','ck3_query_profile_confucian_assembly_predicates_v1','ck3_query_profile_confucian_religious_title_v1','ck3_select_profile_event_option_v1','ck3_take_profile_native_snapshot_v1'}
tools=[r for r in rows if r['name']in names];assert len(tools)==7
put('TOOL-CONTRACTS.actual.json',{'metadata_result':mr,'actual_inventory':m['metadata'],'tools':tools,'SDK_calls':0})
put('TOOL-ARGUMENTS.pending.json',{r['name']:{k:None for k in r['inputSchema']['required']}for r in tools})
doc='''R31 finite ROOT diagnostic operations source; no automatic execution.
PY = C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe
HERE = C:/workspace/ck3_lyd_runtime_20261004/r31-diagnostic-root-operations-sourceonly-20261008-001
RUN = C:/workspace/ck3_lyd_runtime_20261004/live-attempt-031

After ROOT's real bind/Client/attach records exist, create the exact existing
D0-live-runtime-inputs.v1 JSON once from retained actual files:
  <PY> -B -X utf8 <HERE>/author_diagnostic_operations.py runtime-inputs --prepared <RUN>/PREPARED.json --prepared-sha256 <actualSHA> --client-session <RUN>/persistent-client-001/session.json --client-session-sha256 <actualSHA> --attached-binding <RUN>/ROOT-ATTACHED-BINDING.actual.json --attached-binding-sha256 <actualSHA> --attach-stem <actual retained attach stem> --output <RUN>/D0-LIVE-RUNTIME-INPUTS.actual.json
The original strict dispatch pair function checks the actual mcp-queue-001,
Client copies, original native path, SDK SHA and request ID. This reuses exact
metadata/compile/native qualification refs already recorded by ROOT and does
not rerun any qualification. PID/session/profile facts are retained inputs.

Stage call arguments are the exact SDK inputSchema rows in TOOL-CONTRACTS.actual.json:
'''
for r in tools:
 s=r['inputSchema'];doc+='  '+r['name']+' required='+','.join(s['required'])+'; optional='+','.join(k for k in s['properties']if k not in s['required'])+'\n'
doc+='''
Fill a fresh argument JSON from the actual profile/current public revision and
current event query. Required future values remain NULL in the pending template
and are rejected by the author. No option/event/Title ID is generated here.
  <PY> -B -X utf8 <HERE>/author_diagnostic_operations.py tool-spec --tool <one of the seven actual names> --arguments <actualARGS.json> --arguments-sha256 <actualSHA> --request-id <fresh r31-root-... ID> --output <RUN>/<fresh>.SPEC.actual.json
This emits the existing four-key ROOT spec only. ROOT then uses its current
operations/run_request.py attached phase and --execute on the existing Client,
actual consumer INDEX/source author/executor SHA and original attach binding.
This helper never invokes run_request or its executor.

For D0: cache-before SAVE -> SAVE once -> cache-after SAVE -> G2/G3 at the actual
SAVE-after public frame. Native cached query and both G2/G3 arguments must use
that actual frame, never a predicted increment. Use the single original copy.
  <PY> -B -X utf8 <HERE>/author_diagnostic_operations.py capture-argv --stage D0 --runtime-inputs <RUN>/D0-LIVE-RUNTIME-INPUTS.actual.json --runtime-inputs-sha256 <actualSHA> --checkpoint-stem <actualSAVE> --g2-stem <actualafterG2> --g3-stem <actualafterG3> --output-prefix <RUN>/<fresh-prefix> --output <RUN>/<fresh-D0-thin-argv.json>
ROOT runs this emitted argv to make the original D0 SPEC/copier argv, then its
copier, materializer, single body author in order. The new D0 wrapper fixes ONLY
the observed old queue literal official-mcp-queue-002 -> actual mcp-queue-001;
old D0 source stays immutable and all original guards/pins/11-key input contract
remain. Its emitted author directory is D0-diagnostic-author-001. Then use the
already delivered r31-D0-comparison-input-author-sourceonly-20261008-001 author
in cache mode, execute its comparator once, then D0 mode/six-ref comparison.

For each actual D1/D2a/D2b/D3/D4/D5/D6 event: query the actual current stage context,
cache-before SAVE -> SAVE once -> cache-after SAVE -> G2/G3 actual SAVE-after.
  <PY> -B -X utf8 <HERE>/author_diagnostic_operations.py capture-argv --stage <actualstage> --runtime-inputs <sameactualruntimeJSON> --runtime-inputs-sha256 <actualSHA> --stage-context-stem <actualquery> --cache-before-stem <actualbeforecache> --checkpoint-stem <actualSAVE> --cache-after-stem <actualaftercache> --g2-stem <actualafterG2> --g3-stem <actualafterG3> --output-prefix <RUN>/<fresh-stage-prefix> --output <RUN>/<fresh-stage-thin-argv.json>
Run emitted thin argv, copier, materializer and body author once; use retained
JSON for consecutive D0->D1->D2a->D2b->D3->D4->D5->D6 comparisons. No callback/
Title/numeric formal hooks are passed. D2a genuinely unheld T and D2b same T
after atomic holder/resolve stay explicit. Original false 87/88 checks remain
false; missing stage scope/Title stays UNKNOWN/RED. New diagnostic/formal credit
remains NULL. This packet creates no runtime or capture output before ROOT runs.
'''
with(P/'ROOT-CLI.md').open('x',encoding='utf-8',newline='\n')as f:f.write(doc)
put('INDEX.json',{'status':'SOURCE_READY_ACTUAL_LIVE_INPUTS_PENDING','source_head':m['head'],'metadata_result':mr,'sdk_inventory':m['metadata'],'author':ref(P/'author_diagnostic_operations.py'),'D0_queue_wrapper':ref(P/'d0_queue_successor.py'),'original_D0_source_index':ref(B/'r31-D0-capture-author-sourceonly-20261008-001/INDEX.json'),'finer_source_index':ref(B/'r31-finer-D2-capture-author-sourceonly-20261008-001/INDEX.json'),'tool_contracts':ref(P/'TOOL-CONTRACTS.actual.json'),'pending_arguments':ref(P/'TOOL-ARGUMENTS.pending.json'),'ROOT_CLI':ref(P/'ROOT-CLI.md'),'only_D0_queue_delta':'official-mcp-queue-002 -> actual RUN31/mcp-queue-001 in strict pair function','necessary_source_AST_checks':2,'future_PID_SID_revision_T_saved_copy_body_results_formal_credit':None,'SDK_process_bus_desktop_MAIN_capture_output_body_test_calls':0})
print(json.dumps({'INDEX':ref(P/'INDEX.json'),'author':ref(P/'author_diagnostic_operations.py'),'D0_wrapper':ref(P/'d0_queue_successor.py'),'ROOT_CLI':ref(P/'ROOT-CLI.md'),'contracts':[{'name':r['name'],'inputSchema':r['inputSchema']}for r in tools]},indent=2))
