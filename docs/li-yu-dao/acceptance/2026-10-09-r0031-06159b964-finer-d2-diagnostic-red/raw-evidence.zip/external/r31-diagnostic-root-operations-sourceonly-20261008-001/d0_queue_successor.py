"""Keep the original D0 author, binding its one queue literal to ROOT's actual queue."""
from pathlib import Path
import ast, hashlib, importlib.util, json, sys
sys.dont_write_bytecode=True
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
PARENT=BASE/'r31-D0-capture-author-sourceonly-20261008-001'
INDEX_SHA='289a90684d1fd66b182d69599c2dce9f5e4cd13025e2d851d0e9911d6074d5da'
def load_source():
 index_raw=(PARENT/'INDEX.json').read_bytes()
 if hashlib.sha256(index_raw).hexdigest()!=INDEX_SHA:raise ValueError('Exact ROOT materialized D0 source INDEX changed')
 index=json.loads(index_raw);path=Path(index['specification_author']['path']);raw=path.read_bytes()
 if hashlib.sha256(raw).hexdigest()!=index['specification_author']['sha256'] or len(raw)!=index['specification_author']['bytes']:raise ValueError('Original D0 author changed')
 spec=importlib.util.spec_from_file_location('r31_original_D0_specification_author',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 tree=ast.parse(raw);pairs=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='pair']
 if len(pairs)!=1:raise ValueError('One original exact D0 pair function required')
 values=[n for n in ast.walk(pairs[0]) if isinstance(n,ast.Constant)and n.value=='official-mcp-queue-002']
 if len(values)!=1:raise ValueError('One original exact queue binding required')
 values[0].value='mcp-queue-001'
 exec(compile(ast.fix_missing_locations(ast.Module(body=pairs,type_ignores=[])),str(path),'exec'),m.__dict__)
 return m
if __name__=='__main__':raise SystemExit(load_source().main())
