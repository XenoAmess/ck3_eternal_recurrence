"""Preserve the first source seal's missing optional required-key failure; finish source-only metadata projection."""
from pathlib import Path
import json
P=Path(__file__).resolve().parent
with(P/'SOURCE-SEAL-FAILURE-001.json').open('x',encoding='utf-8',newline='\n')as f:
 json.dump({'status':'PRESERVED_SOURCE_SEAL_METADATA_KEY_ERROR','error':'KeyError required: actual no-argument snapshot tool inputSchema legitimately omits required','written_original_file':'TOOL-CONTRACTS.actual.json','SDK_process_bus_body_runtime_output_calls':0,'new_source_AST_checks_already_completed':2},f,indent=2);f.write('\n')
old=P/'seal_source.py';raw=old.read_text(encoding='utf-8')
raw=raw.replace("r['inputSchema']['required']","r['inputSchema'].get('required',[])").replace("s['required']","s.get('required',[])")
line="for name in('d0_queue_successor.py','author_diagnostic_operations.py'):ast.parse((P/name).read_bytes(),filename=name)"
assert raw.count(line)==1
raw=raw.replace(line,'# The same two new sources were already parsed once by original seal001.')
old_put="def put(name,d):\n with(P/name).open('x',encoding='utf-8',newline='\\n')as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\\n')"
new_put="def put(name,d):\n if(P/name).exists():\n  assert json.loads((P/name).read_bytes())==d,'Preserved source metadata file differs'\n  return\n with(P/name).open('x',encoding='utf-8',newline='\\n')as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\\n')"
assert raw.count(old_put)==1
raw=raw.replace(old_put,new_put)
exec(compile(raw,str(old),'exec'),{'__file__':str(old),'__name__':'__main__'})
