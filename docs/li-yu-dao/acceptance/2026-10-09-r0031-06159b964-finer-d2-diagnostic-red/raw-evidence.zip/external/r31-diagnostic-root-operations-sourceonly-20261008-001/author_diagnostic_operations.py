"""ROOT creates retained inputs, capture argv or a tool spec; this source never executes them."""
from pathlib import Path
import argparse, hashlib, json, re, sys
sys.dont_write_bytecode=True
from d0_queue_successor import load_source
B=Path('C:/workspace/ck3_lyd_runtime_20261004');RUN=B/'live-attempt-031';CLIENT=RUN/'persistent-client-001';HERE=Path(__file__).resolve().parent
HEAD='06159b964d859d30f2f07f4b183284df7d6dac47'
PY='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
CP=B/'r31-checkpoint-author-sourceonly-20261008-001'
FINE=B/'r31-finer-D2-capture-author-sourceonly-20261008-001'
METADATA=B/'r31-root-actual-metadata-20261008-001/RESULT.json'
METADATA_SHA='e312916a7ad9b210d9b48cd05d51fd43d79cda1d35698109c91dcc94e10dcde7'
TOOLS={'ck3_query_profile_event_window_v1','ck3_query_profile_actor_cached_succession_v1','ck3_save_profile_checkpoint_v1','ck3_query_profile_confucian_assembly_predicates_v1','ck3_query_profile_confucian_religious_title_v1','ck3_select_profile_event_option_v1','ck3_take_profile_native_snapshot_v1'}
def need(ok,msg):
 if not ok:raise ValueError(msg)
def ref(path):
 p=Path(path).resolve();need(p.suffix in('.json','.py')and 0<p.stat().st_size<=8*1024*1024,'Compact retained JSON/source only; no save body')
 raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def pinned(path,sha):
 r=ref(path);need(r['sha256']==sha,'Actual explicit input SHA changed');return r
def read(r):return json.loads(Path(r['path']).read_bytes())
def checked(r):need(type(r)is dict and set(r)=={'path','bytes','sha256'}and ref(r['path'])==r,'Exact actual JSON/source ref3 required');return r
def put(path,d):
 p=Path(path).resolve();need(p.is_relative_to(RUN)and p.parent.is_dir()and not p.exists(),'Fresh file in existing ROOT run directory required')
 with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
 return ref(p)
def metadata():
 mr=pinned(METADATA,METADATA_SHA);m=read(mr);need(m['head']==HEAD and m['tool_count']==29,'Actual current 29-tool metadata required')
 tools_ref=checked(m['metadata']);rows=read(tools_ref);return mr,m,{r['name']:r for r in rows}
def main():
 p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='mode',required=True)
 live=sub.add_parser('runtime-inputs')
 for key in('prepared','client-session','attached-binding'):live.add_argument('--'+key,type=Path,required=True);live.add_argument('--'+key+'-sha256',required=True)
 live.add_argument('--attach-stem',required=True);live.add_argument('--output',type=Path,required=True)
 capture=sub.add_parser('capture-argv');capture.add_argument('--stage',choices=('D0','D1','D2a','D2b','D3','D4','D5','D6'),required=True)
 capture.add_argument('--runtime-inputs',type=Path,required=True);capture.add_argument('--runtime-inputs-sha256',required=True)
 for key in('checkpoint-stem','g2-stem','g3-stem'):capture.add_argument('--'+key,required=True)
 for key in('stage-context-stem','cache-before-stem','cache-after-stem'):capture.add_argument('--'+key)
 capture.add_argument('--output-prefix',type=Path,required=True);capture.add_argument('--output',type=Path,required=True)
 tool=sub.add_parser('tool-spec');tool.add_argument('--tool',choices=sorted(TOOLS),required=True);tool.add_argument('--arguments',type=Path,required=True);tool.add_argument('--arguments-sha256',required=True);tool.add_argument('--request-id',required=True);tool.add_argument('--output',type=Path,required=True)
 v=p.parse_args()
 if v.mode=='runtime-inputs':
  prepared=pinned(v.prepared,v.prepared_sha256);session_ref=pinned(v.client_session,v.client_session_sha256);binding_ref=pinned(v.attached_binding,v.attached_binding_sha256)
  need(Path(prepared['path'])==RUN/'PREPARED.json'and Path(session_ref['path'])==CLIENT/'session.json'and Path(binding_ref['path'])==RUN/'ROOT-ATTACHED-BINDING.actual.json','Exact actual same-run source paths required')
  session=read(session_ref);binding=read(binding_ref);need(session['source_revision']==HEAD and binding['client_session_id']==session['client_session_id']and binding['profile_sha256']==session['profile_sha256'],'Actual original session/source/profile must agree')
  original=load_source();original.CLIENT=CLIENT;attach=original.pair(v.attach_stem)
  need(binding['attach_native']['sha256']==attach['native_receipt']['sha256']and binding['attach_native']['bytes']==attach['native_receipt']['bytes']and binding['attach_sdk']==attach['sdk_result'],'Original retained attach binding and strict dispatch pair must agree')
  mr,m,_=metadata();base=json.loads((B/'r31-D0-capture-author-sourceonly-20261008-001/D0-LIVE-RUNTIME-INPUTS.pending.json').read_bytes())
  base.update(prepared=prepared,client_session=session_ref,attached_binding=binding_ref,attach=attach,metadata_result=mr,compiled_result=checked(m['compiled_verification']),native_clean_qualification=checked(m['native_clean_qualification']),sdk_metadata_artifact=checked(m['metadata']))
  need(all(base[k]is not None for k in base),'Actual late inputs required; future NULL rejected')
  out=put(v.output,base)
 elif v.mode=='capture-argv':
  runtime=pinned(v.runtime_inputs,v.runtime_inputs_sha256);base=read(runtime);need(base['schema']=='lyd.r31.D0-live-runtime-inputs.v1'and base['source_head']==HEAD and Path(runtime['path']).is_relative_to(RUN),'Existing actual runtime-input contract required')
  cp_ref=pinned(CP/'INDEX.json','84f68bf556f1dac2f40d04dce23e95e9668bc1c74288adf978448ee4b9b788c3')
  prefix=v.output_prefix.resolve();need(prefix.is_relative_to(RUN)and prefix.parent.is_dir()and not prefix.exists(),'Fresh ROOT capture prefix required')
  stage_values={k:getattr(v,k)for k in('stage_context_stem','cache_before_stem','cache_after_stem')}
  if v.stage=='D0':need(all(x is None for x in stage_values.values()),'D0 SAVE/G2/G3 only here; cache comparison uses the separate existing author');author=HERE/'d0_queue_successor.py';window='D0-signed-precommit-cold'
  else:need(all(type(x)is str and x for x in stage_values.values()),'Actual stage-context and both cache stems required');author=FINE/'author_staged_capture_specification_root_only.py';window=v.stage+'-staged-observation'
  argv=[PY,'-B','-X','utf8',author.as_posix(),'--window',window,'--client-output',CLIENT.as_posix(),'--expected-head',HEAD,'--checkpoint-source',CP.as_posix(),'--checkpoint-index-sha256',cp_ref['sha256'],'--checkpoint-stem',v.checkpoint_stem,'--g2-stem',v.g2_stem,'--g3-stem',v.g3_stem,'--runtime-inputs',runtime['path'],'--runtime-inputs-sha256',runtime['sha256'],'--output-prefix',prefix.as_posix(),'--attempt-label','diagnostic']
  if v.stage!='D0':
   for key,value in stage_values.items():argv+=['--'+key.replace('_','-'),value]
  out=put(v.output,{'argv':argv,'executed':False,'source_author':ref(author),'runtime_inputs':runtime,'future_copy_body_stage_result_credit':None})
 else:
  mr,m,tools=metadata();args_ref=pinned(v.arguments,v.arguments_sha256);args=read(args_ref);schema=tools[v.tool]['inputSchema']
  need(type(args)is dict and schema.get('additionalProperties')is False and set(schema.get('required',[]))<=set(args)<=set(schema.get('properties',{})),'Only exact required SDK keys and declared optional keys')
  need(all(x is not None for x in args.values()),'Actual arguments required; future NULL rejected')
  if 'expected_revision'in args:need(type(args['expected_revision'])is int and 0<args['expected_revision']<2**64,'Actual positive uint64 revision, not guessed')
  need(type(v.request_id)is str and re.fullmatch(r'r31-(?:[0-9]{3}-[A-Za-z0-9_-]+|root-[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*)',v.request_id),'Actual current-run portable request ID')
  out=put(v.output,{'request_id':v.request_id,'operation':'call_tool','name':v.tool,'arguments':args})
 print(json.dumps({'mode':v.mode,'output':out,'executed':False,'SDK_calls':0,'body_reads':0,'process_bus_calls':0},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
