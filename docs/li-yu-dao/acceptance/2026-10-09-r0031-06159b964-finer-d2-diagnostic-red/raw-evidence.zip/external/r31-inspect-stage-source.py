from pathlib import Path
import ast
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
for n in ('materialize_staged_checkpoint_request.py','capture_staged_materializer_inputs_root_only.py','INDEX.json'):
 p=B/'r30-staged-capture-author-sourceonly-20261008-003'/n
 print('\nFILE',p);print(p.read_text(encoding='utf-8'))
p=B/'r30-checkpoint-author-sourceonly-20261008-001/source-008/reader/i3b_checkpoint_reader.py'
s=p.read_text(encoding='utf-8');t=ast.parse(s)
for n in t.body:
 if isinstance(n,ast.FunctionDef) and n.name in ('title_row','native_link_id','vars_map','typed_variable','one','saved_entry'):
  print('\nFUNCTION',n.name);print('\n'.join(s.splitlines()[n.lineno-1:n.end_lineno]))
