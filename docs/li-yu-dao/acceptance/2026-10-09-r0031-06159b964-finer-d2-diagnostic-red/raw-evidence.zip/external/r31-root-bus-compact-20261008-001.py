import argparse,json,subprocess
from pathlib import Path
P='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
CLI='C:/workspace/ck3_eternal_recurrence/tools/codex_task_bus.py'
p=argparse.ArgumentParser(); p.add_argument('--task',required=True); p.add_argument('--output',type=Path,required=True); a=p.parse_args()
a.output.mkdir(); out=[]
for operation in [['poll','--task',a.task,'--ack','--limit','10000'],['list']]:
 r=subprocess.run([P,'-B','-X','utf8',CLI,'--bus-dir','C:/workspace/.codex-task-bus',*operation],capture_output=True)
 stem=operation[0]
 (a.output/(stem+'.stdout')).write_bytes(r.stdout); (a.output/(stem+'.stderr')).write_bytes(r.stderr)
 if r.returncode: raise RuntimeError(stem+' failed')
 data=json.loads(r.stdout)
 if stem=='poll': out.append({'operation':stem,'acknowledged_cursor':data['acknowledged_cursor'],'remaining':data['remaining'],'events':len(data['events'])})
 else: out.append({'operation':stem,'active':[t for t in data['tasks'] if not t['stale'] and t['state'] not in ('done','cancelled')]})
with (a.output/'RESULT.actual.json').open('x',encoding='utf-8') as f: json.dump(out,f,ensure_ascii=False,indent=2)
print(json.dumps(out))
