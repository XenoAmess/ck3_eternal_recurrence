from pathlib import Path
import argparse
import hashlib
import json

p = argparse.ArgumentParser()
p.add_argument('--input', type=Path, required=True)
p.add_argument('--key', required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
raw = a.input.read_bytes()
argv = json.loads(raw)[a.key]
assert isinstance(argv, list) and all(isinstance(x, str) for x in argv)
obj = {'argv': argv, 'cwd': 'C:/workspace/ck3_eternal_recurrence', 'source': {'path': a.input.resolve().as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}, 'source_key': a.key}
with a.output.open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'path': a.output.resolve().as_posix(), 'bytes': a.output.stat().st_size, 'sha256': hashlib.sha256(a.output.read_bytes()).hexdigest()}))
