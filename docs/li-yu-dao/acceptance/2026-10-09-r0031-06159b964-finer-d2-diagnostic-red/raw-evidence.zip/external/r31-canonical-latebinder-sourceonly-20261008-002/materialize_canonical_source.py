from pathlib import Path
import ast, copy, hashlib, json, re, shutil

import argparse
parser=argparse.ArgumentParser(description='R31 file-only canonical source constructor. Export/build/metadata are not executed.')
parser.add_argument('--head',required=True)
parser.add_argument('--reviewed-prod-manifest',type=Path,required=True)
parser.add_argument('--reviewed-prod-manifest-sha256',required=True)
parser.add_argument('--production-review',type=Path,required=True)
parser.add_argument('--production-review-sha256',required=True)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--source-dir',type=Path,required=True)
parser.add_argument('--export-output',type=Path,required=True)
parser.add_argument('--build-dir',type=Path,required=True)
parser.add_argument('--native-output',type=Path,required=True)
parser.add_argument('--build-preparation-output',type=Path,required=True)
parser.add_argument('--metadata-request-output',type=Path,required=True)
parser.add_argument('--metadata-output',type=Path,required=True)
args=parser.parse_args()
if not re.fullmatch('[0-9a-f]{40}',args.head)or args.head in('0'*40,'f'*40):raise ValueError('Actual published full HEAD required; NULL refused')
for digest in(args.reviewed_prod_manifest_sha256,args.production_review_sha256):
 if not re.fullmatch('[0-9a-f]{64}',digest):raise ValueError('Actual SHA required; NULL refused')

B=Path('C:/workspace/ck3_lyd_runtime_20261004')
OLD=B/'r30-root-canonical-source-20261008-002'
OUT=args.output.resolve()
HEAD=args.head
MANIFEST=args.reviewed_prod_manifest.resolve()
MANIFEST_SHA=args.reviewed_prod_manifest_sha256
REVIEW=args.production_review.resolve()
PYTHON='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'

def need(ok, message):
    if not ok: raise ValueError(message)

def ref(path):
    path=Path(path).resolve(); raw=path.read_bytes()
    return {'path':path.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def read_ref(stamp):
    need(set(stamp)=={'path','bytes','sha256'} and ref(stamp['path'])==stamp,'Actual ref3 changed')
    return json.loads(Path(stamp['path']).read_bytes())

def put(path,value):
    raw=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    with Path(path).open('xb') as stream:stream.write(raw)

def rows(data):
    need(data.get('product_id')=='mod_li_yu_dao' and len(data['files'])==71,'Actual production71 required')
    result=[]
    for row in data['files']:
        name=row['path']; size=row.get('size',row.get('bytes')); digest=row['sha256']
        need(type(name)is str and not Path(name).is_absolute() and '\\' not in name and '..' not in name.split('/')
             and type(size)is int and size>=0 and re.fullmatch('[0-9a-f]{64}',digest),'Invalid actual manifest row')
        result.append({'path':name,'bytes':size,'sha256':digest})
    need(len({r['path'].casefold() for r in result})==71,'Duplicate production path')
    return sorted(result,key=lambda r:r['path'])

def replace_once(text,old,new):
    need(text.count(old)==1,'Expected source binding occurrence differs: '+old)
    return text.replace(old,new)

def functions(text):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}

need(not OUT.exists()and OUT.is_relative_to(B),'Fresh external successor source directory required')
need(ref(REVIEW)['sha256']==args.production_review_sha256,'Actual production review digest differs')
old_index=read_ref(ref(OLD/'INDEX.json'))
review=read_ref(ref(REVIEW))
need(set(review)=={'status','source_head','current','previous','business_files_changed','diagnostic_overlay_in_production','business_credit'},'Original ROOT production review shape differs')
need(review['status']=='ACTUAL_NEW_HEAD_RENDERED_PRODUCTION71_EXACT_ORDERED_BYTES_EQUAL'
     and review['source_head']==HEAD and review['current']==ref(MANIFEST)
     and review['previous']==old_index['actual_reviewed_production_manifest']
     and review['business_files_changed']==0 and review['diagnostic_overlay_in_production'] is False
     and review['business_credit'] is False,'Actual ROOT production continuity review differs')
need(ref(MANIFEST)['sha256']==MANIFEST_SHA,'Actual current manifest digest differs')
current=read_ref(ref(MANIFEST)); previous=read_ref(review['previous'])
need(current['git_sha']==HEAD and previous['git_sha']==old_index['source_head'],'Actual creation HEAD differs')
current_rows=rows(current); previous_rows=rows(previous)
need(current['files']==previous['files'] and current_rows==previous_rows,'Exact ordered 71 runtime rows differ')

OUT.mkdir()
for stamp in old_index['files']:
    need(ref(stamp['path'])==stamp,'Frozen parent canonical source changed')
    src=Path(stamp['path']); relative=src.relative_to(OLD)
    if relative.as_posix() in {'PRODUCTION71-BINDING.actual.json', 'SOURCE-PROJECTION-CHECKS.actual.json'}:
        continue  # Both authenticated parent reports are regenerated for this HEAD.
    dst=OUT/relative
    dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dst)

changes=[]
def project(relative, transform, binding_names=()):
    path=OUT/relative; before=path.read_text(encoding='utf-8-sig'); after=transform(before)
    need(functions(before)==functions(after),'Function/class AST changed: '+relative)
    old_tree=ast.parse(before); new_tree=ast.parse(after)
    def masked(tree):
        for node in tree.body:
            if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in binding_names for t in node.targets):
                node.value=ast.Constant(value='ACTUAL_BINDING_PROJECTION')
        return ast.dump(tree,include_attributes=False)
    if binding_names:
        need(masked(old_tree)==masked(new_tree),'Non-binding module AST changed: '+relative)
    else:
        # Dependency digest occurs in a top-level import-integrity condition only.
        before_ast=ast.dump(ast.parse(before),include_attributes=False)
        after_ast=ast.dump(ast.parse(after),include_attributes=False)
        need(before_ast.replace(old_support_sha,new_support_sha)==after_ast,'Other dependency AST changed: '+relative)
    path.write_bytes(after.encode('utf-8'))
    changes.append({'relative_path':relative,'before':ref(OLD/relative),'after':ref(path),'function_class_AST_equal':True})

old_support_sha=ref(OLD/'source_preparation_support.py')['sha256']
def support_projection(text):
    text=replace_once(text,"REVIEWED_HEAD = '"+old_index['source_head']+"'","REVIEWED_HEAD = '"+HEAD+"'")
    text=replace_once(text,"REVIEWED_MANIFEST_HEAD = '"+old_index['source_head']+"'","REVIEWED_MANIFEST_HEAD = '"+HEAD+"'")
    return replace_once(text,"REVIEWED_MANIFEST_SHA = '"+review['previous']['sha256']+"'","REVIEWED_MANIFEST_SHA = '"+MANIFEST_SHA+"'")
for name in ['source_preparation_support.py','metadata/source_preparation_support.py']:
    project(name,support_projection,('REVIEWED_HEAD','REVIEWED_MANIFEST_HEAD','REVIEWED_MANIFEST_SHA'))
new_support_sha=ref(OUT/'source_preparation_support.py')['sha256']
for name in ['export_reviewed_clean_head_root_only.py','root_build_reviewed_clean.py','metadata/root_build_reviewed_clean.py']:
    project(name,lambda s:replace_once(s,old_support_sha,new_support_sha))

old_wrapper=old_index['canonical_builder']; new_wrapper=ref(OUT/'root_build_reviewed_clean.py')
def gate_projection(text):
    match=re.search(r'^EXPECTED_WRAPPER = (.+)$',text,re.MULTILINE)
    need(match is not None and ast.literal_eval(match[1])==old_wrapper,'Frozen metadata wrapper pin differs')
    return replace_once(text,match[0],'EXPECTED_WRAPPER = '+repr(new_wrapper))
project('metadata/r14_clean_native_gate.py',gate_projection,('EXPECTED_WRAPPER',))

need(ref(OUT/'root_build_reviewed_clean.py')['sha256']==ref(OUT/'metadata/root_build_reviewed_clean.py')['sha256'],'Builder qualification copy differs')
need(new_support_sha==ref(OUT/'metadata/source_preparation_support.py')['sha256'],'Support qualification copy differs')
for p in OUT.rglob('*.py'):ast.parse(p.read_text(encoding='utf-8-sig'),filename=str(p))
put(OUT/'PRODUCTION71-BINDING.actual.json',{
    'status':'SOURCE_ONLY_ACTUAL_PRODUCTION71_CONTINUITY_BOUND',
    'actual_target_source_head':HEAD,'actual_current_manifest':ref(MANIFEST),'prior_reviewed_manifest':review['previous'],
    'original_ROOT_production_continuity_review':ref(REVIEW),'ordered_all71_manifest_rows_equal':True,
    'complete_pathset_equal':True,'runtime_product_files':71,'diagnostic_overlay_in_production':False,
    'business_acceptance_credit':None,'production_rows':current_rows})
put(OUT/'SOURCE-PROJECTION-CHECKS.actual.json',{
    'status':'BOUNDED_SOURCE_BINDING_AST_AND_DEPENDENCY_CLOSURE_VERIFIED',
    'changes':changes,'source_python_files_AST_parsed':len(list(OUT.rglob('*.py'))),
    'all_function_class_AST_equal':True,'exporter_builder_support_hash_exact':True,
    'metadata_wrapper_exact':True,'all_other_parent_files_byte_exact':True,
    'native_build_game_SDK_bus_process_calls':0,'old_tests_repeated':0})

proof=copy.deepcopy(old_index['actual_reviewed_product_proof'])
proof['reviewed_manifest']=ref(MANIFEST);proof['reviewed_manifest_head']=HEAD;proof['actual_target_source_head']=HEAD
index=copy.deepcopy(old_index)
index.update({'status':'ACTUAL_R31_HEAD_PRODUCTION71_BOUND_SOURCE_ONLY_NATIVE_NOT_RUN',
    'source_head':HEAD,'allocated_attempt':None,'attempt_allocated_or_started_by_author':False,
    'actual_reviewed_production_manifest':ref(MANIFEST),'actual_reviewed_product_proof':proof,
    'parent_canonical_source':ref(OLD/'INDEX.json'),'actual_production71_continuity_review':ref(REVIEW),
    'actual_production71_binding':ref(OUT/'PRODUCTION71-BINDING.actual.json'),
    'source_projection_checks':ref(OUT/'SOURCE-PROJECTION-CHECKS.actual.json'),
    'canonical_exporter':ref(OUT/'export_reviewed_clean_head_root_only.py'),
    'canonical_builder':new_wrapper,'metadata_author':ref(OUT/'metadata/author_r14_metadata_request.py'),
    'metadata_gate':ref(OUT/'metadata/r14_clean_native_gate.py'),
    'constructor':ref(__file__),'actual_native_result':None,'actual_metadata_result':None,'actual_runtime':None,
    'whole_mod_green':False})
index['files']=[ref(p) for p in sorted(OUT.rglob('*')) if p.is_file()]
put(OUT/'INDEX.json',index)
argv=[PYTHON,'-B','-X','utf8',index['canonical_exporter']['path'],'--head',HEAD,
    '--output',str(args.export_output.resolve()),'--source-dir',str(args.source_dir.resolve()),
    '--reviewed-prod-manifest',str(MANIFEST),'--reviewed-prod-manifest-sha256',MANIFEST_SHA]
put(OUT/'ROOT-EXPORT-ARGV.json',{'argv':argv,'executed':False,'source_only':True})
print(json.dumps({'INDEX':ref(OUT/'INDEX.json'),'support':ref(OUT/'source_preparation_support.py'),
    'exporter':index['canonical_exporter'],'builder':new_wrapper,'metadata_gate':index['metadata_gate'],
    'ROOT_EXPORT_ARGV':ref(OUT/'ROOT-EXPORT-ARGV.json'),'export_or_build_executed':False},ensure_ascii=False,indent=2))

CLOSED_BOUNDARY = {'path': 'C:/workspace/ck3_lyd_runtime_20261004/r30-root-actual-typed-closed-boundary-20261008-001/PREVIOUS-BOUNDARY.actual.json', 'bytes': 3103, 'sha256': '2944ee5104746377a738ae5c1d625846cdb9bb9691ac5e4ca6504e4162b938da'}
CLOSED_VERIFIER = {'path': 'C:/workspace/ck3_lyd_runtime_20261004/r30-root-typed-close-actual-source-20261008-001/verify_previous_boundary.py', 'bytes': 24731, 'sha256': '6239df5be60613f9b39e88ef905880b4652ecd19e5a58c53497d5289af16c510'}

put(OUT/'ROOT-BUILD-PREPARE-ARGV.pending.json',{'argv':[PYTHON,'-B','-X','utf8',new_wrapper['path'],'--prepare','--expected-head',HEAD,'--export-root',str(args.source_dir.resolve()),'--build-dir',str(args.build_dir.resolve()),'--output',str(args.native_output.resolve()),'--preparation-dir',str(args.build_preparation_output.resolve()),'--reviewed-prod-manifest',str(MANIFEST),'--reviewed-prod-manifest-sha256',MANIFEST_SHA,'--export-report',str(args.export_output.resolve()/'REPORT.json'),'--export-report-sha256',None,'--grant-title-picker-tools'],'executed':False,'actual_export_report_sha256':None})
put(OUT/'ROOT-BUILD-EXECUTE-ARGV.pending.json',{'argv':[PYTHON,'-B','-X','utf8',new_wrapper['path'],'--execute','--request',str(args.build_preparation_output.resolve()/'REQUEST.json'),'--request-sha256',None],'executed':False})
put(OUT/'ROOT-METADATA-AUTHOR-ARGV.pending.json',{'argv':[PYTHON,'-B','-X','utf8',index['metadata_author']['path'],'--head',HEAD,'--export-report',str(args.export_output.resolve()/'REPORT.json'),'--export-report-sha256',None,'--native-result',str(args.native_output.resolve()/'RESULT.json'),'--native-result-sha256',None,'--previous-boundary',CLOSED_BOUNDARY['path'],'--previous-boundary-sha256',CLOSED_BOUNDARY['sha256'],'--closure-verifier',CLOSED_VERIFIER['path'],'--closure-verifier-sha256',CLOSED_VERIFIER['sha256'],'--closure-function','verify_previous_boundary_v3','--metadata-output',str(args.metadata_output.resolve()),'--output',str(args.metadata_request_output.resolve()),'--grant-title-picker-tools','--actor-cached-succession-tools'],'executed':False,'actual_compiled_qualification':None,'actual_metadata_result':None})
