from pathlib import Path
import argparse
import hashlib
import json
B = Path('C:/workspace/ck3_lyd_runtime_20261004')
RUN = B / 'live-attempt-031'
CORE = B / 'r31-root-actual-runtime-source-20261008-001/core'
p = argparse.ArgumentParser()
p.add_argument('--mode', choices=('draft','bind-argv'), required=True)
p.add_argument('--helper-output', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--root-review', type=Path)
a = p.parse_args()
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def add(argv, key, path):
    path = Path(path).resolve()
    argv.extend(['--' + key, path.as_posix(), '--' + key + '-sha256', sha(path)])
frozen = json.loads((B / 'r31-root-profile-freezer-original-exec-20261008-003/stdout').read_bytes())
assert frozen['status'] == 'PROFILE_FROZEN_READ_ONLY'
launch = json.loads((RUN / 'launch.json').read_bytes())
obs = frozen['observation']
assert obs['pid'] == launch['pid'] and obs['process_create_time'] == launch['process_create_time']
argv = ['C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe', '-B', '-X', 'utf8', (B / 'r31-postlaunch-lateargv-sourceonly-20261008-001/root_live_review_r31.py').as_posix(), a.mode]
argv += ['--cold-source', CORE.as_posix(), '--cold-source-index-sha256', sha(CORE/'INDEX.json'), '--cold-helper-sha256', sha(CORE/'prepare_next_formal_cold.py'), '--run-directory', RUN.as_posix(), '--attempt-id', 'R0031', '--head', launch['source_revision'], '--screen-task', 'lyd-r0031-06159-finer-D2-root', '--cold-sha256', sha(RUN/'COLD-MATERIALIZED.json')]
for key, value in [('pid',obs['pid']), ('hwnd',obs['hwnd']), ('steam-ui-pid',obs['steam_pid']), ('steam-client-pid',obs['steam_client_pid']), ('process-create-time',obs['process_create_time'])]:
    argv.extend(['--'+key, str(value)])
for key, path in [
    ('profile-request', frozen['request_path']),
    ('profile-build-receipt', Path(frozen['native_profile']).parent/'profile-build-receipt.json'),
    ('profile', frozen['native_profile']),
    ('offline-review', B/'r31-root-fresh-offline-prelaunch-20261008-002/OFFLINE-REVIEW.actual.json'),
    ('postlaunch-appmanifest-delta', B/'r31-root-postlaunch-appmanifest-20261008-001/APP-MANIFEST-DYNAMIC-DELTA.actual.json'),
    ('launch', RUN/'launch.json'),
]:
    add(argv, key, path)
if a.mode == 'bind-argv':
    assert a.root_review is not None
    add(argv, 'root-review', a.root_review)
else:
    assert a.root_review is None
argv += ['--output', a.helper_output.resolve().as_posix()]
with a.output.open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps({'argv': argv, 'cwd': 'C:/workspace/ck3_eternal_recurrence', 'actual_freezer_result': 'r31-root-profile-freezer-original-exec-20261008-003/stdout', 'original_failed_freezer_preserved': True}, indent=2) + '\n')
print(json.dumps({'path': a.output.resolve().as_posix(), 'bytes': a.output.stat().st_size, 'sha256': sha(a.output)}))
