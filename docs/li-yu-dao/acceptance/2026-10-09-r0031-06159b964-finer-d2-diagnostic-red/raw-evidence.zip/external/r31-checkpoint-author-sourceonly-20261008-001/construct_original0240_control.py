"""Create an actual baseline control descriptor from existing single-scan author JSON."""
from pathlib import Path
import argparse,json,sys
sys.dont_write_bytecode=True
import materialize_checkpoint_request_v4 as io
P=Path(__file__).parent;HEAD=io.HEAD
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--author-output',type=Path,required=True);p.add_argument('--author-result-sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 root=a.author_output.resolve();result_ref=io.ref(root/'RESULT.json');io.need(result_ref['sha256']==a.author_result_sha256,'explicit completed original author RESULT SHA')
 desc={'schema':'lyd.r31.original0240-baseline-control.v1','author_input':io.ref(root/'INPUT.exact.json'),'author_result':result_ref,'state':io.ref(root/'STATE.json'),'typed_protection':io.ref(root/'TYPED-PROTECTION.json'),'qualified_native':io.ref(root/'native-qualification/QUALIFIED-NATIVE.json')}
 # Use the existing exact actual-control validator against this tuple in memory.
 framework=io.unique((P/'AUTHOR-FRAMEWORK.pending-runtime.json').read_bytes())
 source_input=io.read(desc['author_input']);framework['schema']=source_input['schema']
 io.need(source_input['schema'] in ('lyd.r17.actual-checkpoint-author-request.grant-numeric.v1','lyd.r31.actual-checkpoint-author-request.formal-registry.v2'),'actual R31 baseline source version')
 result=io.read(result_ref);state=io.read(desc['state']);typed=io.read(desc['typed_protection']);qualified=io.read(desc['qualified_native'])
 io.need(source_input['expected_source_head']==HEAD and source_input['window']=='baseline' and source_input['original_baseline']==framework['original_baseline'],'original0240 actual baseline INPUT required')
 io.need(result['save_body_reads']==1 and result['strict_formal_reader_executed'] is False and result['status']=='ACTUAL_COMPACT_NATIVE_SAVED_OBSERVATIONS_JOINED','one completed baseline scan required')
 io.need(result['source_refs']['profile']==io.ref(source_input['profile']) and result['source_refs']['checkpoint_receipt']==io.ref(source_input['checkpoint_receipt']),'baseline source original refs required')
 io.need(all(desc[k] in result['outputs'] for k in ('state','typed_protection','qualified_native')),'baseline original retained output inventory')
 io.need(typed['protection_checks_match'] is True and len(typed['checks'])==87 and all(c['matches'] is True for c in typed['checks']),'all actual baseline87 protections required')
 io.need(qualified['schema']=='lyd.sdk-checkpoint-qualified-native.v3' and qualified['G2_status']=='BOUND_COMPLETE_NATIVE_OBSERVATION' and qualified['runtime_binding']['source_head']==HEAD,'actual complete source-bound G2 baseline required')
 io.need(qualified['runtime_binding']['session_id']==state['identity']['session_id'] and qualified['runtime_binding']['game_pid']==state['identity']['pid'] and qualified['runtime_binding']['queried_native_revision']==state['identity']['revision'] and qualified['runtime_binding']['checkpoint']['sha256']==state['checkpoint_sha256'],'original actual baseline STATE/native frame required')
 output=a.output.resolve();io.need(output.is_relative_to(P.parent) and output.suffix=='.json' and output.parent.is_dir() and not output.exists(),'fresh external existing-parent descriptor path')
 io.put(output,desc);print(json.dumps({'original0240_control':io.ref(output),'body_reads':0,'SDK_game_calls':0,'formal_acceptance':None},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
