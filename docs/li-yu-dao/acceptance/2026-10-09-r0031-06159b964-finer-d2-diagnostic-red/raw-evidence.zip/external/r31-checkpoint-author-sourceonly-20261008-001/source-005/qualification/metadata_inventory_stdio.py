"""Metadata-only stdio server. No profile/process/pipe or business method is used."""
from pathlib import Path
import argparse,hashlib,importlib.util,sys
sys.dont_write_bytecode=True
class Uncallable:
 calls=0
 def __getattr__(self,name):
  self.calls+=1;raise RuntimeError('Metadata business callback forbidden: '+name)
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,required=True);p.add_argument('--server-sha256',required=True);a=p.parse_args()
 source=a.source.resolve();path=source/'tools/ck3_native_profile_mcp.py'
 if hashlib.sha256(path.read_bytes()).hexdigest()!=a.server_sha256:raise ValueError('Actual exported metadata server bytes changed')
 sys.path[:0]=[str(source/'tools'),str(source/'ck3_autonomous_player/src'),str(source/'ck3_workshop_mcp/src')]
 spec=importlib.util.spec_from_file_location('ck3_native_profile_mcp',path);profile=importlib.util.module_from_spec(spec);sys.modules[spec.name]=profile;spec.loader.exec_module(profile)
 service=Uncallable();server=profile.create_server(service,player_control_tools=False,confucian_readonly_tools=False,confucian_challenger_tools=True,grant_title_picker_tools=True,actor_cached_succession_tools=True)
 server.run(transport='stdio')
 if service.calls:raise RuntimeError('Metadata business callback occurred')
if __name__=='__main__':main()
