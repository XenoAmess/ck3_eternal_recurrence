"""Explicit cache29 metadata; original G2/G3 schemas and credit remain independent."""
import ast
from pathlib import Path
from r14_metadata_semantics import need,check_revision_schema,READONLY_HINTS,number
ACTOR_CACHE_TOOL='ck3_query_profile_actor_cached_succession_v1'
ACTOR_CACHE_BUNDLE='CONFUCIAN_CHALLENGER_GRANT_ACTOR_CACHE_29'
def check_actor_cache_tool(tool):
 need(tool.get('name')==ACTOR_CACHE_TOOL,'Exact actor-cache alias required')
 schema=tool.get('inputSchema',{})
 need(schema.get('additionalProperties') is False and schema.get('required')==['expected_revision'] and set(schema.get('properties',{}))=={'expected_revision'},'Exact closed actor-cache arguments required')
 check_revision_schema(schema['properties']['expected_revision'])
 need(all(tool.get('annotations',{}).get(k) is v for k,v in READONLY_HINTS.items()),'Readonly cache annotations differ')
 return tool
def actor_cache_source_declarations(path):
 tree=ast.parse(Path(path).read_text(encoding='utf-8-sig'))
 aliases=[n.value for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='ActorCachedSuccessionRevisionV1'for t in n.targets)]
 need(len(aliases)==1 and isinstance(aliases[0],ast.Subscript)and ast.unparse(aliases[0].value)=='Annotated','Exact strict cache revision alias required')
 args=aliases[0].slice.elts;need(ast.unparse(args[0])=='int','Cache revision must be int')
 field=[x for x in args[1:]if isinstance(x,ast.Call)and ast.unparse(x.func)=='Field'];need(len(field)==1,'Cache Field required')
 kw={x.arg:x.value for x in field[0].keywords};expected={'strict':True,'gt':0,'lt':2**64}
 need(set(kw)==set(expected)and all(type(number(kw[k]))is type(v)and number(kw[k])==v for k,v in expected.items()),'Strict cache uint64 bounds differ')
 factory=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='create_server'];need(len(factory)==1,'Actual create_server required')
 opts=dict(zip((a.arg for a in factory[0].args.kwonlyargs),factory[0].args.kw_defaults))
 need('actor_cached_succession_tools'in opts and ast.literal_eval(opts['actor_cached_succession_tools'])is False,'Cache opt-in must default OFF')
 tools=[n for n in ast.walk(factory[0])if isinstance(n,ast.FunctionDef)and n.name==ACTOR_CACHE_TOOL];need(len(tools)==1,'One cache tool declaration required')
 tool=tools[0]
 need([(a.arg,ast.unparse(a.annotation))for a in tool.args.args]==[('expected_revision','ActorCachedSuccessionRevisionV1')]and not tool.args.defaults and not tool.args.kwonlyargs and tool.args.vararg is None and tool.args.kwarg is None,'Exact cache typed signature required')
 annotations=[k.value for d in tool.decorator_list if isinstance(d,ast.Call)for k in d.keywords if k.arg=='annotations'];need(len(annotations)==1 and isinstance(annotations[0],ast.Call)and ast.unparse(annotations[0].func)=='ToolAnnotations','Cache annotations required')
 hints={k.arg:ast.literal_eval(k.value)for k in annotations[0].keywords};need(hints==READONLY_HINTS,'Exact cache readonly hints required')
 parents=[n for n in ast.walk(factory[0])if isinstance(n,ast.If)and tool in list(ast.walk(n))and ast.unparse(n.test)=='actor_cached_succession_tools'];need(len(parents)==1,'Cache must be registered only by explicit opt-in')
 return {ACTOR_CACHE_TOOL:{'signature':[('expected_revision','ActorCachedSuccessionRevisionV1')],'annotations':hints,'default_opt_in':False,'G2_or_formal_credit':False}}
