"""Create the existing closed metadata request from explicit actual references only."""
from pathlib import Path
import argparse
import json
import re
import sys
sys.dont_write_bytecode = True
from r14_metadata_common import BASE, need, ref, read_ref, jread
from root_build_reviewed_clean import RESULT_SCHEMA
HERE = Path(__file__).resolve().parent

def checked_native_mode(receipt,grant_opt_in=False):
    need(type(grant_opt_in) is bool and receipt.get('schema')==RESULT_SCHEMA
         and receipt.get('grant_title_picker_opt_in') is grant_opt_in,'Actual successor native receipt schema/grant mode differs')

def put(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream: stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--head', required=True)
    for name in ('export-report', 'native-result', 'previous-boundary', 'closure-verifier'):
        parser.add_argument('--' + name, type=Path, required=True)
        parser.add_argument('--' + name + '-sha256', required=True)
    parser.add_argument('--closure-function', default='verify_previous_boundary_v3')
    parser.add_argument('--metadata-output', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--grant-title-picker-tools',action='store_true',help='Explicit native grant ON plus challenger28 metadata; default remains grant OFF/challenger24')
    parser.add_argument('--actor-cached-succession-tools',action='store_true',help='Explicit cache29 metadata; requires grant; default OFF')
    args = parser.parse_args()
    need(not args.actor_cached_succession_tools or args.grant_title_picker_tools,'cache29 requires explicit grant28 mode')
    need(re.fullmatch('[0-9a-f]{40}', args.head), 'Actual full HEAD required')
    actual = {}
    for name in ('export_report', 'native_result', 'previous_boundary', 'closure_verifier'):
        stamp = ref(getattr(args, name))
        digest = getattr(args, name + '_sha256')
        need(stamp['sha256'] == digest and re.fullmatch('[0-9a-f]{64}', digest), 'Actual SHA differs: ' + name)
        actual[name] = stamp
    report = jread(read_ref(actual['export_report']))
    receipt = jread(read_ref(actual['native_result']))
    need(report['source']['head'] == args.head and receipt['source_revision'] == args.head, 'Actual export/build HEAD differs')
    checked_native_mode(receipt,args.grant_title_picker_tools)
    output, metadata_output = args.output.resolve(), args.metadata_output.resolve()
    need(BASE in output.parents and BASE in metadata_output.parents and output != metadata_output
         and not output.exists() and not metadata_output.exists(), 'Distinct fresh external request/metadata outputs required')
    request = {'schema': 'lyd.next-cold.clean-source-metadata-grant-numeric-request.v1', 'source_revision': args.head,
               'export_report': actual['export_report'], 'compiled_route': 'CLEAN_HEAD_BUILD',
               'compiled_verification': actual['native_result'], 'baseline': jread((HERE / 'BASELINE.inherited.json').read_bytes()),
               'previous_boundary': actual['previous_boundary'], 'private_bundle': 'CONFUCIAN_CHALLENGER_GRANT_ACTOR_CACHE_29' if args.actor_cached_succession_tools else ('CONFUCIAN_CHALLENGER_GRANT_28' if args.grant_title_picker_tools else 'CONFUCIAN_CHALLENGER_24'),
               'grant_title_picker_opt_in':args.grant_title_picker_tools,'actor_cached_succession_opt_in':args.actor_cached_succession_tools,'output_directory': metadata_output.as_posix()}
    output.mkdir()
    put(output / 'REQUEST.actual.json', request)
    request_ref = ref(output / 'REQUEST.actual.json')
    argv = [sys.executable, '-B', '-X', 'utf8', str(HERE / 'capture_r14_metadata_root_only.py'), '--request', request_ref['path'],
            '--sha256', request_ref['sha256'], '--closure-verifier', actual['closure_verifier']['path'],
            '--closure-verifier-sha256', actual['closure_verifier']['sha256'], '--closure-function', args.closure_function]
    put(output / 'CHECK-ARGV.json', {'argv': argv + ['--check'], 'executed': False})
    put(output / 'CREATE-ARGV.json', {'argv': argv + ['--create'], 'executed': False})
    result = {'status': 'ACTUAL_REFERENCES_WRITTEN_CAPTURE_NOT_EXECUTED', 'request': request_ref,
              'closure_verifier': actual['closure_verifier'], 'check_argv': argv + ['--check'], 'create_argv': argv + ['--create'],
              'SDK_Client_started': False, 'game_calls': 0}
    put(output / 'RESULT.json', result)
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__': main()
