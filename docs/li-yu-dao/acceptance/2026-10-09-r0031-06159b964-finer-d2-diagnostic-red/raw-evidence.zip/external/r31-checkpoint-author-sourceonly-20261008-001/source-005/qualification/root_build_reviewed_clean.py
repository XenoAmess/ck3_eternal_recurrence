"""Root-only fresh R14 native build. --prepare binds actual future HEAD/export.

The template has not built a DLL or contacted CK3. The canonical repository
MSVC producer owns configuration, compilation and project EXE registration.
Each designated output/build directory must be new; failed attempts stay intact.
"""
from __future__ import annotations
import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

sys.dont_write_bytecode = True
sys.path.insert(0,str(Path(__file__).resolve().parent))
if hashlib.sha256((Path(__file__).resolve().parent/'source_preparation_support.py').read_bytes()).hexdigest()!='eba78f64184821689d6185030df50eadf479eb0231510fb771f9fe9bc9ee81d2': raise ValueError('Frozen preparation support changed')
from source_preparation_support import reviewed_production, private_option_census, game_reference, manifest_rows
REPO = Path('C:/workspace/ck3_eternal_recurrence')
NATIVE_REL = 'ck3_autonomous_player/native_bridge'
BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
PYTHON = Path('C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe')
FLAGS = (
    'XAR_CK3_ENABLE_FEUDAL_1066_BOOKMARK_MODEL_PRIVATE_V1',
    'XAR_CK3_ENABLE_FEUDAL_1066_SELECTED_BOOKMARK_START_PRIVATE_V1',
    'XAR_CK3_ENABLE_INGAME_DECISIONS_OPEN_PRIVATE_V1',
    'XAR_CK3_ENABLE_INGAME_DECISION_ITEM_ACTIONS_PRIVATE_V1',
    'XAR_CK3_ENABLE_INGAME_DECISION_OUTCOME_PRIVATE_V1',
    'XAR_CK3_ENABLE_CURRENT_ACTOR_STRESS_ADJUSTMENT_PRIVATE_V1',
    'XAR_CK3_ENABLE_ORDINARY_INTERACTION_PRIVATE_V1',
    'XAR_CK3_ENABLE_NORMAL_EXIT_MAP_PRIVATE_V1',
    'XAR_CK3_ENABLE_CONFUCIAN_ASSEMBLY_PREDICATES_PRIVATE_QUERY_V1',
    'XAR_CK3_ENABLE_CONFUCIAN_RELIGIOUS_TITLE_PRIVATE_QUERY_V1',
    'XAR_CK3_ENABLE_CONFUCIAN_CHALLENGER_GRAPH_PRIVATE_QUERY_V1',
)
PLAYER = 'XAR_CK3_ENABLE_PLAYER_CONTROL_PRIVATE_V1'
GRANT = 'XAR_CK3_ENABLE_GRANT_TITLE_PICKER_PRIVATE_V1'
REQUEST_SCHEMA = 'lyd.next-cold.root-clean-grant-numeric-army-route-request.v1'
RESULT_SCHEMA = 'lyd.next-cold.actual-clean-source-native-build-grant-numeric-army-route.v1'
TARGETS = (
    'xar_ck3_bridge', 'xar_ck3_bridge_injector',
    'xar_confucian_assembly_predicates_v1_test',
    'xar_confucian_religious_title_readback_v1_test',
    'xar_confucian_challenger_graph_v1_test',
    'xar_ck3_main_thread_query_mailbox_v1_test',
    'xar_ck3_12002_event_window_context_test',
    'xar_ck3_12004_army_route_binding_test',
)
HELPERS = ('tools/run_native_msvc.py', 'tools/register_project_exe_exclusions.py',
           'tools/project_exe_exclusion_broker_client.py')


def need(condition, reason):
    if not condition:
        raise ValueError(reason)

def enabled_flags(grant_opt_in=False):
    need(type(grant_opt_in) is bool, 'Grant opt-in must be an actual boolean')
    return FLAGS + ((GRANT,) if grant_opt_in else ())

def flag_plan(census, grant_opt_in=False):
    on=enabled_flags(grant_opt_in)
    need(type(census) is dict and type(census.get('names')) is list and
         all(type(name) is str and re.fullmatch(r'XAR_CK3_ENABLE_[A-Z0-9_]+',name) for name in census['names']) and
         len(census['names'])==len(set(census['names'])), 'Complete unique actual source option census required')
    names=set(census['names'])
    need(set(FLAGS)|{PLAYER,GRANT}<=names, 'Existing eleven flags, player and new grant option must occur in actual source census')
    return {'flags_ON':list(on),'flags_OFF':sorted(names-set(on)-{PLAYER})}

def parsed_private_flags(raw,census,grant_opt_in=False):
    plan=flag_plan(census,grant_opt_in);flags={}
    for line in raw.decode('utf-8').splitlines():
        match=re.fullmatch(r'(XAR_CK3_ENABLE_[A-Z0-9_]+|BUILD_TESTING):BOOL=(ON|OFF)',line)
        if match:
            need(match[1] not in flags,'Duplicate actual private CMake flag')
            flags[match[1]]=match[2]
        elif re.match(r'(XAR_CK3_ENABLE_[A-Z0-9_]+|BUILD_TESTING):',line):
            need(False,'Private cache flag must have exact BOOL ON/OFF type/value')
    need(set(flags)==set(census['names'])|{'BUILD_TESTING'},'Unknown or missing actual cache private flag; no option may be skipped')
    need({name for name,value in flags.items() if name!='BUILD_TESTING' and value=='ON'}==set(plan['flags_ON']), 'Actual enabled flag set differs from explicit grant mode')
    need(flags.get(PLAYER)=='OFF' and flags.get('BUILD_TESTING')=='ON','Player OFF and testing ON required')
    need(all(flags.get(name)=='OFF' for name in plan['flags_OFF']),'Every other actual source option must be OFF')
    return flags


def read(path):
    path = Path(path).resolve()
    return (Path('\\\\?\\' + str(path)) if os.name == 'nt' else path).read_bytes()


def ref(path):
    data = read(path)
    return {'path': Path(path).resolve().as_posix(), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def put(path, value):
    with Path(path).open('xb') as output:
        output.write((json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf-8'))


def git(*args):
    completed = subprocess.run(['git', '--no-optional-locks', '-C', str(REPO), *args], capture_output=True)
    need(completed.returncode == 0, 'Read-only Git observation failed: ' + repr(args))
    return completed.stdout


def binding(expected_head, export_root):
    need(re.fullmatch('[0-9a-f]{40}', expected_head), 'Exact actual future HEAD required')
    need(git('rev-parse', 'HEAD').decode().strip() == expected_head, 'Current HEAD changed')
    need(not git('status', '--porcelain=v1', '-z', '--untracked-files=all'), 'Clean committed source required')
    export_root = Path(export_root).resolve()
    native = export_root / NATIVE_REL
    need(native.is_dir() and export_root != REPO.resolve(), 'Existing independent clean export required')
    entries = []
    for row in git('ls-tree', '-r', '-z', expected_head, '--', NATIVE_REL).split(b'\0'):
        if not row:
            continue
        meta, raw_path = row.split(b'\t', 1)
        mode, kind, oid = meta.decode('ascii').split()
        need(kind == 'blob' and mode in ('100644', '100755'), 'Native export links are unsupported')
        entries.append((raw_path.decode('utf-8'), oid))
    need(entries, 'Native source tree is empty')
    batch = subprocess.run(['git', '--no-optional-locks', '-C', str(REPO), 'cat-file', '--batch'],
                           input=''.join(oid + '\n' for _, oid in entries).encode(), capture_output=True)
    need(batch.returncode == 0, 'Git blob batch failed')
    offset = 0
    rows = []
    for name, oid in entries:
        stop = batch.stdout.index(b'\n', offset)
        actual_oid, kind, size = batch.stdout[offset:stop].decode('ascii').split()
        need(actual_oid == oid and kind == 'blob', 'Unexpected Git blob response')
        count = int(size)
        data = batch.stdout[stop + 1:stop + 1 + count]
        offset = stop + 1 + count + 1
        exported = export_root / name
        need(not exported.is_symlink() and not exported.is_junction(), 'Native source link encountered')
        need(read(exported) == data == read(REPO / name), 'HEAD/main/export native bytes differ: ' + name)
        rows.append({'relative_path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    expected_names = {row['relative_path'] for row in rows}
    actual_names = set()
    for folder, dirs, files in os.walk(native, followlinks=False):
        for name in [*dirs, *files]:
            path = Path(folder) / name
            need(not path.is_symlink() and not path.is_junction(), 'Export native census encountered a link')
        for name in files:
            actual_names.add((Path(folder) / name).relative_to(export_root).as_posix())
    need(actual_names == expected_names, 'Export has missing or extra native files')
    helpers = {}
    for name in HELPERS:
        expected = git('show', expected_head + ':' + name)
        need(read(REPO / name) == read(export_root / name) == expected, 'Canonical helper HEAD/export bytes differ: ' + name)
        helpers[name] = ref(REPO / name)
    cmake = read(native / 'CMakeLists.txt').decode('utf-8')
    for target in (*TARGETS[2:6], *TARGETS[7:]):
        need('add_executable(' + target in cmake, 'Required focused target absent: ' + target)
    need('src/ck3_12002_*_test.cpp' in cmake and 'set(fixture_target "xar_${fixture_name}")' in cmake
         and (native/'src/ck3_12002_event_window_context_test.cpp').is_file(), 'Existing numeric fixture glob/source target missing')
    need('xar_ck3_native_bridge_confucian_executor_registration_v1' in cmake,
         'Repository mailbox regression CTest entry is missing')
    for flag in FLAGS[-3:]:
        need(re.search(r'option\(' + re.escape(flag) + r'\s+"[^"]*"\s+OFF\)', cmake), 'Confucian native default must remain OFF')
    need(re.search(r'option\(' + re.escape(GRANT) + r'\s+"[^"]*"\s+OFF\)',cmake),'Grant native default must remain OFF')
    return {'actual_HEAD': expected_head, 'native_tree': git('rev-parse', expected_head + ':' + NATIVE_REL).decode().strip(),
            'export_root': export_root.as_posix(), 'native_export': native.as_posix(),
            'native_files': rows, 'canonical_helpers': helpers, 'clean_source': True}


def build_argv(request):
    argv = [str(PYTHON), '-B', '-X', 'utf8', str(REPO / HELPERS[0]),
            '--source-dir', request['source']['native_export'], '--build-dir', request['build_directory'],
            '--defender-external-candidate', 'Post-R14 exact clean export ' + request['source']['actual_HEAD'],
            '--configuration', 'Release', '--jobs', '64', '--target', *TARGETS,
            '--cmake-define', 'BUILD_TESTING:BOOL=ON', '--cmake-define', PLAYER + ':BOOL=OFF',
            '--cmake-define', 'XAR_CK3_EXECUTABLE_PATH:FILEPATH=' + request['game_reference']['executable']['path']]
    need(request['flags_ON']==list(enabled_flags(request['grant_title_picker_opt_in'])),'Prepared enabled flag set differs')
    for flag in request['flags_ON']: argv.extend(['--cmake-define', flag + ':BOOL=ON'])
    for flag in request['flags_OFF']: argv.extend(['--cmake-define', flag + ':BOOL=OFF'])
    return argv + ['--configure', '--build']

def input_proofs(head, export_root, reviewed_ref, report_ref, grant_opt_in=False):
    reviewed = reviewed_production(reviewed_ref['path'],reviewed_ref['sha256'],head)
    need(reviewed['reviewed_manifest']==reviewed_ref, 'Reviewed ref3 bytes differ')
    need(ref(report_ref['path'])==report_ref, 'Exact actual export report bytes/SHA required')
    report=json.loads(read(report_ref['path']))
    need(report.get('schema')=='lyd.root.exact-head-export-build.v1' and report['source']['head']==head
         and Path(report['source_root']).resolve()==Path(export_root).resolve(), 'Actual export HEAD/root differs')
    comparison=report['production_comparison']
    need(comparison['reviewed_manifest']==reviewed_ref and comparison['runtime_files']==71
         and comparison['all71_runtime_bytes_equal_to_reviewed'] is True
         and comparison['final_reviewed_business_delta']==reviewed['final_reviewed_business_delta'],
         'Export must prove exact reviewed seven changes, sole M3 addition, complete pathset and all71')
    actual_manifest=Path(report_ref['path']).parent/'production/mod_li_yu_dao.manifest.json'
    data=json.loads(read(actual_manifest))
    need(data['git_sha']==head and manifest_rows(data)==reviewed['rows'], 'Exported formal production differs from review')
    census=private_option_census(Path(export_root)/NATIVE_REL)
    off=flag_plan(census,grant_opt_in)['flags_OFF']
    return {'reviewed_production':reviewed,'private_option_census':census,'flags_OFF':off,'game_reference':game_reference()}


def external_destinations(export_root, *paths):
    export_root = Path(export_root).resolve()
    for path in paths:
        resolved = Path(path).resolve()
        need(not resolved.is_relative_to(REPO.resolve()) and not resolved.is_relative_to(export_root),
             'Build/report/preparation must stay outside main and the frozen export')


def focused_argv(request, target):
    executable = str(Path(request['build_directory']) / (target + '.exe'))
    if target == TARGETS[4]:
        return [executable, str(Path(request['output']) / 'actual-graph-native-fixtures')]
    if target == TARGETS[5]:
        return [executable, '--confucian-registration-only', str(Path(request['source']['native_export']) / 'src/bridge.cpp')]
    if target == TARGETS[6]:
        return [executable, '--numeric-value-scope']
    return [executable]


def no_ck3():
    need(os.name == 'nt', 'Windows process census required')
    class Entry(ctypes.Structure):
        _fields_ = [('dwSize', wintypes.DWORD), ('cntUsage', wintypes.DWORD), ('th32ProcessID', wintypes.DWORD),
                    ('th32DefaultHeapID', ctypes.c_size_t), ('th32ModuleID', wintypes.DWORD), ('cntThreads', wintypes.DWORD),
                    ('th32ParentProcessID', wintypes.DWORD), ('pcPriClassBase', wintypes.LONG),
                    ('dwFlags', wintypes.DWORD), ('szExeFile', wintypes.WCHAR * 260)]
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    kernel.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    kernel.Process32FirstW.argtypes = kernel.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(Entry)]
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = kernel.CreateToolhelp32Snapshot(2, 0)
    need(handle not in (None, ctypes.c_void_p(-1).value), 'Process snapshot failed')
    entry = Entry(); entry.dwSize = ctypes.sizeof(entry)
    found = []
    try:
        success = kernel.Process32FirstW(handle, ctypes.byref(entry))
        need(success, 'Process census first entry failed')
        while success:
            if entry.szExeFile.casefold() == 'ck3.exe':
                found.append({'pid': entry.th32ProcessID, 'name': entry.szExeFile})
            success = kernel.Process32NextW(handle, ctypes.byref(entry))
        need(ctypes.get_last_error() == 18, 'Process census incomplete')
    finally:
        kernel.CloseHandle(handle)
    need(not found, 'CK3 active; fresh build not submitted')
    return {'utc': datetime.now(timezone.utc).isoformat(), 'ck3_processes': found, 'all_ck3_processes_absent': True}


def prepare(args):
    external_destinations(args.export_root, args.build_dir, args.output, args.preparation_dir)
    need(not args.build_dir.exists() and not args.output.exists() and not args.preparation_dir.exists(), 'Fresh preparation/build/output required')
    source = binding(args.expected_head, args.export_root)
    proofs = input_proofs(args.expected_head,args.export_root,ref(args.reviewed_prod_manifest),ref(args.export_report),args.grant_title_picker_tools)
    need(proofs['reviewed_production']['reviewed_manifest']['sha256']==args.reviewed_prod_manifest_sha256
         and ref(args.export_report)['sha256']==args.export_report_sha256, 'Explicit input SHA differs')
    request = {'schema': REQUEST_SCHEMA, 'source': source,
               'wrapper': ref(__file__), 'build_directory': args.build_dir.resolve().as_posix(),
               'output': args.output.resolve().as_posix(), 'flags_ON': list(enabled_flags(args.grant_title_picker_tools)),
               'grant_title_picker_opt_in':args.grant_title_picker_tools,'player_control': 'OFF',
               'BUILD_TESTING': 'ON', 'configuration': 'Release', 'jobs': 64, 'targets': list(TARGETS),
               'runtime_acceptance': 'NOT_RUN', 'author_built': False}
    request.update(proofs)
    request['reviewed_prod_manifest']=ref(args.reviewed_prod_manifest)
    request['actual_export_report']=ref(args.export_report)
    request['canonical_builder_argv'] = build_argv(request)
    request['focused_test_argv'] = {target: focused_argv(request, target) for target in TARGETS[2:]}
    args.preparation_dir.mkdir(parents=True, exist_ok=False)
    path = args.preparation_dir / 'REQUEST.json'; put(path, request)
    invocation = [str(PYTHON), '-I', '-B', str(Path(__file__).resolve()), '--execute', '--request', str(path),
                  '--request-sha256', ref(path)['sha256']]
    put(args.preparation_dir / 'ROOT-ARGV.json', {'argv': invocation, 'executed': False})
    print(json.dumps({'prepared': ref(path), 'ROOT_argv': invocation, 'build_submitted': False}))
    return 0


def execute(args):
    need(ref(args.request)['sha256'] == args.request_sha256, 'Request bytes changed')
    request = json.loads(read(args.request))
    need(request['schema'] == REQUEST_SCHEMA and request['wrapper'] == ref(__file__), 'Request/wrapper identity differs')
    need(request['canonical_builder_argv'] == build_argv(request) and request['flags_ON'] == list(enabled_flags(request['grant_title_picker_opt_in']))
         and request['targets'] == list(TARGETS), 'Canonical invocation differs')
    need(request['focused_test_argv'] == {target: focused_argv(request, target) for target in TARGETS[2:]}, 'Focused invocation differs')
    build, output = Path(request['build_directory']), Path(request['output'])
    external_destinations(request['source']['export_root'], build, output)
    need(not build.exists() and not output.exists(), 'No build reuse or automatic retry')
    need(binding(request['source']['actual_HEAD'], request['source']['export_root']) == request['source'], 'Prepared source changed')
    need(git('config', '--local', '--bool', '--get', 'xar.defenderProjectExeExclusions').strip() == b'true'
         and not os.environ.get('CI'), 'Existing canonical project EXE opt-in required')
    proofs=input_proofs(request['source']['actual_HEAD'],request['source']['export_root'],request['reviewed_prod_manifest'],request['actual_export_report'],request['grant_title_picker_opt_in'])
    need(all(request[key]==value for key,value in proofs.items()), 'Prepared review/census/game identity changed')
    census = no_ck3()
    output.mkdir(parents=True, exist_ok=False)
    put(output / 'ROOT-INVOCATION.json', {'request': ref(args.request), 'explicit_ROOT_execute': True, 'automatic_retry': False})
    put(output / 'FRESH-NO-CK3-BEFORE.json', census)
    with (output / 'build.stdout').open('xb') as stdout, (output / 'build.stderr').open('xb') as stderr:
        completed = subprocess.run(build_argv(request), cwd=REPO, stdout=stdout, stderr=stderr)
    producer_path = build / 'native-msvc-result.json'
    producer = json.loads(read(producer_path)) if producer_path.is_file() else {}
    cache_path = build / 'CMakeCache.txt'
    cache = read(cache_path).decode('utf-8') if cache_path.is_file() else ''
    flags={};flags_error=None
    try: flags=parsed_private_flags(cache.encode('utf-8'),request['private_option_census'],request['grant_title_picker_opt_in'])
    except ValueError as error:flags_error=str(error)
    exact_flags=flags_error is None
    products = {}
    for target in TARGETS:
        path = build / (target + ('.dll' if target == TARGETS[0] else '.exe'))
        if path.is_file(): products[target] = ref(path)
    runtime = build / 'xar_ck3_12002_runtime.lib'
    compiled = bool(producer.get('build_succeeded') is True and producer.get('configured') is True
                    and producer.get('built') is True and producer.get('configuration') == 'Release'
                    and producer.get('jobs') == 64 and producer.get('targets') == list(TARGETS)
                    and Path(producer.get('source_dir','')).resolve() == Path(request['source']['native_export']).resolve()
                    and Path(producer.get('build_dir','')).resolve() == build.resolve()
                    and producer.get('local_ck3_contacted') is False and len(products) == len(TARGETS)
                    and runtime.is_file() and exact_flags and 'CMAKE_BUILD_TYPE:STRING=Release' in cache
                    and 'CMAKE_GENERATOR:INTERNAL=Ninja' in cache)
    tests = []
    if compiled:
        put(output / 'FRESH-NO-CK3-BEFORE-TESTS.json', no_ck3())
        for target in TARGETS[2:]:
            argv = focused_argv(request, target)
            need(ref(argv[0]) == products[target], 'Focused executable changed')
            with (output / (target + '.stdout')).open('xb') as stdout, (output / (target + '.stderr')).open('xb') as stderr:
                test = subprocess.run(argv, cwd=build, stdout=stdout, stderr=stderr)
            tests.append({'target': target, 'argv': argv, 'exit_code': test.returncode,
                          'executable': products[target], 'stdout': ref(output / (target + '.stdout')),
                          'stderr': ref(output / (target + '.stderr'))})
    source_unchanged = binding(request['source']['actual_HEAD'], request['source']['export_root']) == request['source']
    after_proofs=input_proofs(request['source']['actual_HEAD'],request['source']['export_root'],request['reviewed_prod_manifest'],request['actual_export_report'],request['grant_title_picker_opt_in'])
    source_unchanged = source_unchanged and all(request[key]==value for key,value in after_proofs.items())
    test_pass = len(tests) == len(TARGETS)-2 and all(row['exit_code'] == 0 for row in tests)
    defender = producer.get('defender_exclusions')
    defender_refs = {}
    if isinstance(defender, dict):
        for key in ('receipt','manifest'):
            if defender.get(key): defender_refs[key] = ref(defender[key])
        if defender_refs.get('receipt'):
            need(defender_refs['receipt']['sha256'] == defender.get('receipt_sha256'), 'Defender receipt SHA differs')
    result = {'schema': RESULT_SCHEMA,
              'source_revision': request['source']['actual_HEAD'], 'source_kind': 'EXACT_CLEAN_HEAD_EXPORT',
              'source_binding': request['source'], 'source_before_after_unchanged': source_unchanged,
              'actual_compilation_pass': compiled, 'actual_focused_tests_pass': test_pass,
              'original_outer_exit_code': completed.returncode, 'actual_flags': flags, 'exact_private_flags': exact_flags,
              'private_flags_error':flags_error,'private_flags_ON':request['flags_ON'],
              'private_option_census':request['private_option_census'],'grant_title_picker_opt_in':request['grant_title_picker_opt_in'],
              'canonical_producer': ref(producer_path) if producer_path.is_file() else None,
              'raw_CMakeCache': ref(cache_path) if cache_path.is_file() else None,
              'targets': products, 'new_runtime_library': ref(runtime) if runtime.is_file() else None,
              'actual_focused_tests': tests, 'Defender': defender, 'Defender_refs': defender_refs,
              'runtime_acceptance': 'NOT_RUN', 'main_writes': 0, 'game_calls': 0, 'native_pipe_calls': 0,
              'automatic_retry': False, 'old_objects_or_DLL_reused': False}
    put(output / 'RESULT.json', result)
    put(output / 'INDEX.json', {'files': [ref(path) for path in sorted(output.rglob('*')) if path.is_file()]})
    print(json.dumps({'RESULT': ref(output / 'RESULT.json'), 'actual_compilation_pass': compiled,
                      'actual_focused_tests_pass': test_pass, 'original_outer_exit_code': completed.returncode}))
    return completed.returncode or (0 if compiled and test_pass and source_unchanged else 1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--prepare', action='store_true'); mode.add_argument('--execute', action='store_true')
    parser.add_argument('--expected-head'); parser.add_argument('--export-root',type=Path)
    parser.add_argument('--build-dir',type=Path); parser.add_argument('--output',type=Path)
    parser.add_argument('--preparation-dir',type=Path)
    parser.add_argument('--reviewed-prod-manifest',type=Path); parser.add_argument('--reviewed-prod-manifest-sha256')
    parser.add_argument('--export-report',type=Path); parser.add_argument('--export-report-sha256')
    parser.add_argument('--request',type=Path); parser.add_argument('--request-sha256')
    parser.add_argument('--grant-title-picker-tools',action='store_true',help='Explicit future grant mode: native grant ON and metadata28; default remains OFF/native11')
    args=parser.parse_args()
    need(Path(sys.executable).resolve()==PYTHON.resolve(),'Verified Python313 required')
    if args.prepare:
        need(args.expected_head and re.fullmatch('[0-9a-f]{40}',args.expected_head)
             and args.expected_head not in ('0'*40,'f'*40),'Actual final clean HEAD required; pending rejected')
        need(all(getattr(args,key) is not None for key in ('export_root','build_dir','output','preparation_dir',
             'reviewed_prod_manifest','reviewed_prod_manifest_sha256','export_report','export_report_sha256'))
             and not args.request and not args.request_sha256,'Explicit actual inputs and fresh directories required')
        need(all(re.fullmatch('[0-9a-f]{64}',value or '') for value in (args.reviewed_prod_manifest_sha256,args.export_report_sha256)),
             'Actual reviewed manifest/export report SHA required')
        return prepare(args)
    need(args.request and re.fullmatch('[0-9a-f]{64}',args.request_sha256 or '') and not args.expected_head and not args.grant_title_picker_tools,
         'Execute requires exact prepared request SHA')
    return execute(args)


if __name__ == '__main__':
    raise SystemExit(main())
