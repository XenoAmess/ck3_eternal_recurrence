"""ROOT-only frozen-source SDK inventories 21/23/24 and explicit grant28. No business callbacks."""
from pathlib import Path
import argparse
import asyncio
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import re
import sys
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from r14_metadata_common import BASE, TOOLS, need, exact, jread, read_ref, ref, path_identity, long_path
from r14_clean_native_gate import verify_native
from r14_metadata_semantics import READONLY_TOOLS, CHALLENGER_TOOL, check_readonly_tool, source_declarations
from grant_metadata_semantics import GRANT_TOOLS, check_grant_tool, grant_source_declarations
from actor_cache_metadata_semantics import ACTOR_CACHE_TOOL,ACTOR_CACHE_BUNDLE,check_actor_cache_tool,actor_cache_source_declarations
LEGACY_CAPTURE = Path('C:\\workspace\\ck3_lyd_runtime_20261004\\r13-clean-source-metadata-sdk-render-20261006-003\\capture_r13_metadata_root_only.py')
LEGACY_SHA = 'fe525eb0ef05b3d27dcca624a92355500eead25073347e2178e5f0d2b6fbb487'
need(ref(LEGACY_CAPTURE)['sha256'] == LEGACY_SHA, 'Preserved canonical metadata source changed')
spec = importlib.util.spec_from_file_location('_r14_preserved_capture', LEGACY_CAPTURE)
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)
BASELINE = jread((HERE / 'BASELINE.inherited.json').read_bytes())
REQUEST_SCHEMA = 'lyd.next-cold.clean-source-metadata-grant-numeric-request.v1'
REQUEST_FIELDS = legacy.REQUEST_FIELDS | {'grant_title_picker_opt_in','actor_cached_succession_opt_in'}
CLOSURE_VERIFIER = None
CLOSURE_FUNCTION = 'verify_previous_boundary_v3'

def bundle_mode(request):
    need(type(request.get('grant_title_picker_opt_in')) is bool and type(request.get('actor_cached_succession_opt_in')) is bool,'Explicit boolean grant/cache opt-ins required')
    grant=request['grant_title_picker_opt_in'];cache=request['actor_cached_succession_opt_in']
    need(not cache or grant,'R28 cache29 bundle requires explicit grant28 opt-in')
    need(request.get('private_bundle')==(ACTOR_CACHE_BUNDLE if cache else ('CONFUCIAN_CHALLENGER_GRANT_28' if grant else 'CONFUCIAN_CHALLENGER_24')),'Explicit metadata bundle/mode differs')
    return grant

def validate_request_shape(request):
    exact(request, REQUEST_FIELDS, 'R14 metadata request')
    need(request['schema'] == REQUEST_SCHEMA, 'Next-cold metadata request schema differs')
    need(not legacy.pending(request), 'Actual metadata inputs are pending')
    need(type(request['source_revision']) is str and re.fullmatch('[0-9a-f]{40}', request['source_revision']), 'Actual full source HEAD required')
    need(request['compiled_route'] == 'CLEAN_HEAD_BUILD', 'New actual clean native build required')
    bundle_mode(request)
    need(request['baseline'] == BASELINE, 'Original checkpoint0240 baseline differs')
    read_ref(request['previous_boundary'])
    need(CLOSURE_VERIFIER is not None, 'Explicit actual previous-boundary verifier required')
    read_ref(CLOSURE_VERIFIER)
    return {'baseline': BASELINE, 'previous_boundary': request['previous_boundary'], 'closure_verifier': CLOSURE_VERIFIER}

def cached_baseline_and_boundary(request, binding):
    baseline = request['baseline']
    report = jread(read_ref(baseline['readback']))
    index = jread(read_ref(baseline['readback_index']))
    need(report.get('schema') == 'lyd.r10.second-final-DETACH-independent-readback.v1' and report.get('save') == baseline['save'], 'Immutable0240 report/save binding differs')
    need(report.get('final_DETACH_credit') is True and report.get('status') == 'ACTUAL_FINAL_DETACH_RESULT1_NEW_FAITH107_AND_FEES_PROVEN_WITH_ROUND16_AUTHORIZATION', 'Actual0240 detach credit missing')
    need(any(row.get('bytes') == baseline['readback']['bytes'] and row.get('sha256') == baseline['readback']['sha256'] for row in index['files']), '0240 readback absent from sealed index')
    verifier = binding['closure_verifier']
    spec = importlib.util.spec_from_file_location('_r14_actual_previous_closed_boundary', verifier['path'])
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    boundary = getattr(module, CLOSURE_FUNCTION)({'review': request['previous_boundary']}, legacy_context=None)
    return {'baseline': baseline, 'baseline_save_body_read': False, 'baseline_cached_report_semantics_checked': True,
            'previous_boundary': request['previous_boundary'], 'previous_boundary_verified': boundary, 'closure_verifier': verifier}

legacy.validate_request_shape = validate_request_shape
legacy.cached_baseline_and_boundary = cached_baseline_and_boundary
legacy.verify_native = verify_native

def checked_tools(rows, label):
    need(label in ('default21','private23','challenger24','grant28','cache29'),'Unknown official inventory label')
    need(type(rows) is list and all(type(row) is dict and type(row.get('name')) is str for row in rows), 'Actual serialized tool list required')
    names = [row['name'] for row in rows]
    expected = set(TOOLS) | (set(READONLY_TOOLS) if label != 'default21' else set()) | ({CHALLENGER_TOOL} if label in ('challenger24','grant28','cache29') else set()) | (set(GRANT_TOOLS) if label in ('grant28','cache29') else set()) | ({ACTOR_CACHE_TOOL} if label=='cache29' else set())
    need(len(names) == len(set(names)) == len(expected) and set(names) == expected, 'Exact official ' + label + ' tool inventory differs')
    need(all(row.get('inputSchema', {}).get('additionalProperties') is False for row in rows), 'Official input schema is not closed')
    for row in rows:
        if row['name'] in READONLY_TOOLS: check_readonly_tool(row)
        elif row['name'] == CHALLENGER_TOOL: check_readonly_tool(row, challenger=True)
        elif row['name'] in GRANT_TOOLS:check_grant_tool(row)
        elif row['name']==ACTOR_CACHE_TOOL:check_actor_cache_tool(row)
    return names

async def capture(profile,grant_opt_in=False,actor_cache_opt_in=False):
    need(type(grant_opt_in) is bool and type(actor_cache_opt_in) is bool and (not actor_cache_opt_in or grant_opt_in),'Actual boolean grant/cache modes required')
    from mcp import Client
    class Uncallable:
        calls = 0
        def __getattr__(self, name):
            self.calls += 1
            raise RuntimeError('Metadata business callback forbidden: ' + name)
    actual = {}
    bundles=[('default21',False,False,False),('private23',True,False,False),('challenger24',False,True,False)]
    if grant_opt_in:bundles.append(('grant28',False,True,True))
    for label, readonly, challenger, grant in bundles:
        service = Uncallable()
        async with Client(profile.create_server(service, player_control_tools=False, confucian_readonly_tools=readonly,
                                                confucian_challenger_tools=challenger,grant_title_picker_tools=grant,actor_cached_succession_tools=False)) as client:
            response = await client.list_tools()
        need(getattr(response, 'nextCursor', None) in (None, ''), 'Complete official SDK inventory required')
        rows = [tool.model_dump(mode='json', by_alias=True, exclude_none=False) for tool in response.tools]
        checked_tools(rows, label)
        need(service.calls == 0, 'Business callback occurred during official list_tools')
        actual[label] = (response, rows)
    base = {row['name']: row for row in actual['default21'][1]}
    private = {row['name']: row for row in actual['private23'][1]}
    challenger = {row['name']: row for row in actual['challenger24'][1]}
    need(all(private[name] == row and challenger[name] == row for name, row in base.items()), 'Readonly/challenger opt-in changed default21 metadata')
    need(all(challenger[name] == row for name, row in private.items()), 'Challenger24 changed private23 metadata')
    if grant_opt_in:
        grant={row['name']:row for row in actual['grant28'][1]}
        need(all(grant[name]==row for name,row in challenger.items()),'Grant28 changed existing challenger24 metadata')
    if actor_cache_opt_in:
        from mcp.client.stdio import StdioServerParameters,stdio_client
        source=Path(profile.__file__).resolve().parent.parent
        parameters=StdioServerParameters(command=sys.executable,args=['-B','-X','utf8',str(HERE/'metadata_inventory_stdio.py'),'--source',source.as_posix(),'--server-sha256',ref(source/'tools/ck3_native_profile_mcp.py')['sha256']],cwd=str(source),env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8'})
        async with Client(stdio_client(parameters),cache=None) as client:
            response=await client.list_tools()
        need(getattr(response,'nextCursor',None) in (None,''),'Complete stdio cache29 inventory required')
        rows=[tool.model_dump(mode='json',by_alias=True,exclude_none=False)for tool in response.tools]
        checked_tools(rows,'cache29');cache={row['name']:row for row in rows}
        need(all(cache[name]==row for name,row in grant.items()),'Cache29 changed existing grant28 metadata')
        actual['cache29']=(response,rows)
    return actual

def execute(request, request_ref, create):
    source, paths, code, qualification, smallproof, output = legacy.checked_inputs(request)
    need(qualification['grant_title_picker_opt_in'] is request['grant_title_picker_opt_in'],'Actual native and metadata grant modes differ')
    declarations = grant_source_declarations(source / 'tools/ck3_native_profile_mcp.py')
    declarations.update(actor_cache_source_declarations(source / 'tools/ck3_native_profile_mcp.py'))
    if not create:
        return {'status': 'CHECKED_ACTUAL_SOURCE_NATIVE_AND_CACHED_BOUNDARY_NO_SDK_CAPTURE', 'head': request['source_revision'],
                'qualification': qualification, 'source_declarations': declarations, 'output_created': False, 'game_calls': 0, 'runtime_acceptance': 'NOT_RUN'}
    for name in tuple(sys.modules):
        if name in {'ck3_native_profile_mcp', 'xar_autoplayer', 'ck3_workshop_mcp', 'tools'} or name.startswith(('xar_autoplayer.', 'ck3_workshop_mcp.', 'tools.')): del sys.modules[name]
    sys.path[:0] = [str(source / 'tools'), str(source / 'ck3_autonomous_player/src'), str(source / 'ck3_workshop_mcp/src')]
    import ck3_native_profile_mcp as profile
    need(path_identity(profile.__file__) == source / 'tools/ck3_native_profile_mcp.py', 'Official profile imported outside new frozen export')
    origins = legacy.imported_origins(source, paths)
    actual = asyncio.run(capture(profile,request['grant_title_picker_opt_in'],request['actor_cached_succession_opt_in']))
    origins.update(legacy.imported_origins(source, paths))
    for row in code:
        stamp = ref(source / row['path'])
        need(stamp['bytes'] == row['bytes'] and stamp['sha256'] == row['sha256'], 'Actual exported code changed during metadata capture')
    long_path(output).mkdir(exist_ok=False)
    def put(name, value):
        with long_path(output / name).open('xb') as stream: stream.write((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())
    for label, (response, rows) in actual.items():
        put('ACTUAL-' + label + '-profile-all-tools.json', rows)
        put('REFERENCE-' + label + '-TOOLS.json', rows)
        with long_path(output / (label + '.list-tools.sdk-result.json')).open('xb') as stream:
            stream.write((response.model_dump_json(by_alias=True, exclude_none=False, indent=2) + '\n').encode())
    put('SOURCE-INVENTORY.actual.json', code)
    put('ACTUAL-IMPORTED-SOURCE-ORIGINS.json', origins)
    put('SOURCE-TOOL-DECLARATIONS.actual.json', declarations)
    put('NATIVE-CLEAN-QUALIFICATION.actual.json', qualification)
    put('CACHED-BASELINE-AND-CLOSED-BOUNDARY.json', smallproof)
    put('REQUEST.actual.json', request)
    selected='cache29' if request['actor_cached_succession_opt_in'] else ('grant28' if request['grant_title_picker_opt_in'] else 'challenger24')
    tool_count=29 if request['actor_cached_succession_opt_in'] else (28 if request['grant_title_picker_opt_in'] else 24)
    result = {'status': 'ACTUAL_OFFICIAL_CLIENT_METADATA_AND_FRESH_CODE_INVENTORY', 'head': request['source_revision'],
              'sdk_version': importlib.metadata.version('mcp'), 'pydantic_version': importlib.metadata.version('pydantic'),
              'tool_count': tool_count, 'tool_names': checked_tools(actual[selected][1], selected),
              'metadata': ref(output / ('ACTUAL-'+selected+'-profile-all-tools.json')),
              'default_tool_count': 21, 'default_metadata': ref(output / 'ACTUAL-default21-profile-all-tools.json'),
              'readonly_tool_count': 23, 'readonly_metadata': ref(output / 'ACTUAL-private23-profile-all-tools.json'),
              'sdk_references': {label: ref(output / ('REFERENCE-' + label + '-TOOLS.json')) for label in actual},
              'source_inventory': ref(output / 'SOURCE-INVENTORY.actual.json'), 'source_file_count': len(code),
              'actual_export_report': request['export_report'], 'native_clean_qualification': ref(output / 'NATIVE-CLEAN-QUALIFICATION.actual.json'),
              'compiled_verification': request['compiled_verification'], 'actual_imported_origins': ref(output / 'ACTUAL-IMPORTED-SOURCE-ORIGINS.json'),
              'source_tool_declarations': ref(output / 'SOURCE-TOOL-DECLARATIONS.actual.json'), 'request': request_ref,
              'private_bundle': request['private_bundle'], 'grant_title_picker_opt_in':request['grant_title_picker_opt_in'],
              'actor_cached_succession_opt_in':request['actor_cached_succession_opt_in'],
              'grant_tool_count':28 if request['grant_title_picker_opt_in'] else None,'grant_metadata':ref(output/'ACTUAL-grant28-profile-all-tools.json') if request['grant_title_picker_opt_in'] else None,
              'actor_cache_transport':'OFFICIAL_SDK_STDIO_LIST_TOOLS_ONLY' if request['actor_cached_succession_opt_in'] else None,
              'challenger_tool_count':24,'challenger_metadata':ref(output/'ACTUAL-challenger24-profile-all-tools.json'),
              'factory_opt_in': {'confucian_readonly_tools': False, 'confucian_challenger_tools': True, 'player_control_tools': False,'grant_title_picker_tools':request['grant_title_picker_opt_in'],'actor_cached_succession_tools':request['actor_cached_succession_opt_in']},
              'baseline': request['baseline'], 'previous_boundary': request['previous_boundary'], 'closure_verifier': CLOSURE_VERIFIER,
              'business_callbacks': 0, 'game_calls': 0, 'actual_game_client_started': False, 'runtime_acceptance': 'NOT_RUN'}
    put('RESULT.json', result)
    put('INDEX.json', {'schema': 'lyd.next-cold.actual-clean-source-metadata-grant-index.v1', 'files': [ref(path) for path in sorted(long_path(output).iterdir()) if path.is_file()]})
    for path in long_path(output).iterdir():
        if path.is_file(): os.chmod(path, 0o444)
    return {'RESULT': ref(output / 'RESULT.json'), 'INDEX': ref(output / 'INDEX.json'), 'head': request['source_revision'], 'tool_count': tool_count, 'runtime_acceptance': 'NOT_RUN'}

def main():
    global CLOSURE_VERIFIER, CLOSURE_FUNCTION
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--closure-verifier', type=Path, required=True)
    parser.add_argument('--closure-verifier-sha256', required=True)
    parser.add_argument('--closure-function', default='verify_previous_boundary_v3')
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check', action='store_true')
    mode.add_argument('--create', action='store_true')
    args = parser.parse_args()
    request_ref = ref(args.request)
    CLOSURE_VERIFIER = ref(args.closure_verifier)
    CLOSURE_FUNCTION = args.closure_function
    need(re.fullmatch('[A-Za-z_][A-Za-z0-9_]*', CLOSURE_FUNCTION), 'Explicit callable verifier name required')
    need(request_ref['sha256'] == args.sha256 and re.fullmatch('[0-9a-f]{64}', args.sha256), 'Actual request SHA differs')
    need(CLOSURE_VERIFIER['sha256'] == args.closure_verifier_sha256 and re.fullmatch('[0-9a-f]{64}', args.closure_verifier_sha256), 'Actual closure verifier SHA differs')
    print(json.dumps(execute(jread(read_ref(request_ref)), request_ref, args.create), ensure_ascii=False, indent=2))

if __name__ == '__main__': main()
