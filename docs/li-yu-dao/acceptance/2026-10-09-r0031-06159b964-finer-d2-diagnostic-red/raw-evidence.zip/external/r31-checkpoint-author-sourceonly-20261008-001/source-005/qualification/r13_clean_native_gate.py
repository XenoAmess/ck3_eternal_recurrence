"""Read-only qualification of actual compiled source bytes against a new clean export."""
from pathlib import Path
import hashlib, json, re
from r13_metadata_common import need, exact, jread, read_ref, path_identity, source_path

FLAGS_ON = {
 'XAR_CK3_ENABLE_FEUDAL_1066_BOOKMARK_MODEL_PRIVATE_V1',
 'XAR_CK3_ENABLE_FEUDAL_1066_SELECTED_BOOKMARK_START_PRIVATE_V1',
 'XAR_CK3_ENABLE_INGAME_DECISIONS_OPEN_PRIVATE_V1',
 'XAR_CK3_ENABLE_INGAME_DECISION_ITEM_ACTIONS_PRIVATE_V1',
 'XAR_CK3_ENABLE_INGAME_DECISION_OUTCOME_PRIVATE_V1',
 'XAR_CK3_ENABLE_CURRENT_ACTOR_STRESS_ADJUSTMENT_PRIVATE_V1',
 'XAR_CK3_ENABLE_ORDINARY_INTERACTION_PRIVATE_V1',
 'XAR_CK3_ENABLE_NORMAL_EXIT_MAP_PRIVATE_V1',
 'XAR_CK3_ENABLE_CONFUCIAN_ASSEMBLY_PREDICATES_PRIVATE_QUERY_V1',
 'XAR_CK3_ENABLE_CONFUCIAN_RELIGIOUS_TITLE_PRIVATE_QUERY_V1'}
TARGETS = ('xar_ck3_bridge','xar_ck3_bridge_injector','xar_confucian_assembly_predicates_v1_test','xar_confucian_religious_title_readback_v1_test')
NATIVE = 'ck3_autonomous_player/native_bridge/'
PLAYER = 'XAR_CK3_ENABLE_PLAYER_CONTROL_PRIVATE_V1'
DIRTY_SCHEMA = 'lyd.r13.actual-compiled-first-focused-supplement.v1'
CLEAN_SCHEMA = 'lyd.r13.actual-clean-source-native-build.v1'
CLEAN_FIELDS = {'schema','source_revision','source_kind','actual_compilation_pass','actual_focused_tests_pass','source_before','source_after','canonical_producer','raw_CMakeCache','actual_flags','targets','actual_focused_tests','original_outer_exit_code','Defender','runtime_acceptance'}

def parsed_flags(raw):
    flags={}
    for line in raw.decode('utf-8').splitlines():
        match=re.fullmatch(r'(XAR_CK3_ENABLE_[A-Z0-9_]+|BUILD_TESTING):BOOL=(ON|OFF)',line)
        if match:
            need(match[1] not in flags,'Duplicate actual CMake flag');flags[match[1]]=match[2]
        elif re.match(r'(XAR_CK3_ENABLE_[A-Z0-9_]+|BUILD_TESTING):',line):
            need(False,'Actual CMake flag type/value is not exact BOOL ON/OFF')
    need({k for k,v in flags.items() if v=='ON' and k!='BUILD_TESTING'}==FLAGS_ON,'Exact ten private flags ON required')
    need(flags.get('BUILD_TESTING')=='ON' and flags.get(PLAYER)=='OFF','Testing ON and player-control OFF required')
    return flags

def inventory(state_ref):
    state=jread(read_ref(state_ref));inv=jread(read_ref(state['native_inventory']))
    need(inv.get('schema')=='lyd.r13.complete-native-raw-inventory.v1','Actual complete native inventory required')
    exact(inv,{'schema','root','files','file_count','tracked_count','nontracked_count','tracked_missing_paths','raw_content_digest'},'complete raw native inventory')
    root=path_identity(inv['root']);rows={};fold=set()
    need(type(inv.get('files')) is list and bool(inv['files']),'Actual native census missing')
    for row in inv['files']:
        exact(row,{'relative_path','bytes','sha256','tracked'},'native raw row')
        name=source_path(row['relative_path'])
        need(name.casefold() not in fold,'Native row duplicate');fold.add(name.casefold())
        need(type(row['bytes']) is int and row['bytes']>=0 and type(row['tracked']) is bool and re.fullmatch('[0-9a-f]{64}',row['sha256']),'Native row stamp differs')
        rows[name]=row
    need(inv.get('file_count')==len(rows) and inv.get('tracked_missing_paths')==[],'Native census count/missing tracked paths differ')
    need(inv['tracked_count']==sum(r['tracked'] for r in rows.values()) and inv['nontracked_count']==sum(not r['tracked'] for r in rows.values()),'Native tracked/nontracked counts differ')
    need(hashlib.sha256(json.dumps(inv['files'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==inv['raw_content_digest'],'Complete native raw row digest differs')
    return state,inv,root,rows

def actual_test_rows(tests,products):
    need(type(tests) is list and len(tests)==2,'Both actual focused tests required')
    seen=set()
    for row in tests:
        need(type(row) is dict,'Actual focused test object required')
        standard={'target','argv','executable','exit_code','stdout','stderr'}
        need(set(row) in (standard,standard|{'first_actual_R13_focused_run'}),'Focused test closed fields differ')
        name=row['target'];need(name in TARGETS[2:] and name not in seen,'Focused test target differs/duplicates');seen.add(name)
        need(row['executable']==products[name] and row['argv']==[row['executable']['path']],'Actual focused argv/executable binding differs')
        need(type(row['exit_code']) is int and row['exit_code']==0,'Actual focused test did not pass')
        if 'first_actual_R13_focused_run' in row:need(row['first_actual_R13_focused_run'] is True,'First focused run marker differs')
        for key in ('executable','stdout','stderr'):read_ref(row[key])
    return tests

def clean_state_proof(state,expected_head):
    need(state.get('actual_HEAD')==expected_head and state.get('whole_worktree_clean') is True and state.get('native_worktree_clean') is True,'Actual clean build source identity required')
    observations=state['observations']
    for name in ('head','whole_worktree_status','native_status'):
        observation=observations[name]
        need(observation.get('exit_code')==0,'Source observation failed: '+name)
        raw=read_ref(observation['stdout'])
        need(raw.decode('ascii').strip()==expected_head if name=='head' else raw==b'','Clean HEAD/status raw proof differs: '+name)

def verify_native(compiled_ref,route,export_report,export_inventory,expected_head):
    receipt=jread(read_ref(compiled_ref))
    need(route in {'DIRTY_SUPPLEMENT','CLEAN_HEAD_BUILD'},'Explicit compiled route required')
    if route=='DIRTY_SUPPLEMENT':
        need(receipt.get('schema')==DIRTY_SCHEMA and receipt.get('source_kind')=='ORIGINAL_DIRTY_WORKTREE','R13 original dirty supplement required')
        need(receipt.get('whole_native_raw_build_and_test_sources_unchanged') is True,'Actual build/test source unchanged proof missing')
        original=jread(read_ref(receipt['original_dirty_RESULT']))
        need(original.get('schema')=='lyd.r13.actual-dirty-source-native-build.v1' and original.get('source_kind')=='ACTUAL_DIRTY_WORKTREE_NOT_A_CLEAN_HEAD_ARTIFACT','Original dirty result provenance differs')
        need(original.get('original_outer_exit_code')==receipt.get('original_outer_exit_code') and original.get('targets')==receipt.get('targets'),'Original outer status/products changed')
        need(receipt.get('original_operational_status')=='ACTUAL_BUILD_OPERATIONAL_RED_PRESERVED','Original operational RED must be preserved')
        facts=jread(read_ref(receipt['corrected_compile_facts']))
        need(facts.get('schema')=='lyd.r13.corrected-existing-compile-facts.v1' and facts.get('actual_compilation_pass') is True and facts.get('exact_10_ON_player_OFF_BUILD_TESTING_ON') is True,'Corrected actual compile facts missing')
        for key in ('canonical_producer','actual_flags','targets','raw_CMakeCache'):
            need(facts[key]==receipt[key],'Corrected compile fact cross-reference differs: '+key)
        state_refs=[receipt[k] for k in ('original_source_before','original_source_after_build','source_before_tests','source_after_tests')]
        read_ref(receipt['original_attempt_index'])
        need(original['source_before']==state_refs[0] and original['source_after_build']==state_refs[1],'Original dirty source references differ')
    else:
        exact(receipt,CLEAN_FIELDS,'new clean build receipt')
        need(receipt['schema']==CLEAN_SCHEMA and receipt['source_kind']=='ACTUAL_CLEAN_HEAD_WORKTREE' and receipt['source_revision']==expected_head,'Genuinely new clean HEAD compiled receipt required')
        state_refs=[receipt['source_before'],receipt['source_after']]
    need(receipt.get('actual_compilation_pass') is True and receipt.get('actual_focused_tests_pass') is True,'Actual compilation and two focused tests required')
    states=[inventory(r) for r in state_refs];before,inv,native_root,native_rows=states[0]
    for state,other,root,rows in states[1:]:
        need(other==inv and root==native_root and rows==native_rows,'Complete tracked/nontracked native inventory drift')
        need(state.get('canonical_helpers')==before.get('canonical_helpers'),'Actual canonical build helper drift')
    if route=='CLEAN_HEAD_BUILD':
        for state,*unused in states:clean_state_proof(state,expected_head)
    else:
        need(all(state.get('actual_HEAD')==receipt['actual_HEAD_historical'] for state,*unused in states),'Historical dirty HEAD proof differs')
    products=receipt['targets'];exact(products,TARGETS,'actual four products')
    for value in products.values():read_ref(value)
    cache=read_ref(receipt['raw_CMakeCache']);flags=parsed_flags(cache)
    need(flags==receipt['actual_flags'],'Actual full CMake flags differ from receipt')
    need('CMAKE_BUILD_TYPE:STRING=Release' in cache.decode('utf-8') and 'CMAKE_GENERATOR:INTERNAL=Ninja' in cache.decode('utf-8'),'Actual Release/Ninja configuration differs')
    producer=jread(read_ref(receipt['canonical_producer']))
    need(all(producer.get(k) is True for k in ('configured','built','build_succeeded')) and producer.get('configuration')=='Release' and producer.get('jobs')==64,'Canonical producer actual compile/link proof differs')
    need(producer.get('targets')==list(TARGETS) and producer.get('local_ck3_contacted') is False and path_identity(producer['source_dir'])==native_root,'Canonical producer targets/source/game boundary differs')
    build_root=path_identity(producer['build_dir'])
    need(path_identity(receipt['canonical_producer']['path'])==build_root/'native-msvc-result.json' and path_identity(receipt['raw_CMakeCache']['path'])==build_root/'CMakeCache.txt','Actual producer/cache escaped bound build directory')
    homes=[line.split('=',1)[1] for line in cache.decode('utf-8').splitlines() if line.startswith('CMAKE_HOME_DIRECTORY:INTERNAL=')]
    need(len(homes)==1 and path_identity(homes[0])==native_root,'Actual CMake home directory differs from compiled source inventory')
    need(all(path_identity(value['path']).parent==build_root for value in products.values()),'Product escaped actual build directory')
    for name,value in products.items():
        need(path_identity(value['path']).name==name+('.dll' if name==TARGETS[0] else '.exe'),'Actual target filename differs')
    tests=actual_test_rows(receipt['actual_focused_tests'],products)
    exported={r['path']:r for r in export_inventory['files']}
    native_export={name[len(NATIVE):]:row for name,row in exported.items() if name.startswith(NATIVE)}
    need(bool(native_export),'Actual clean export native files absent')
    for name,row in native_export.items():
        actual=native_rows.get(name)
        need(actual is not None and actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],'Compiled source differs from actual clean HEAD export: '+name)
    extras=[]
    for name,row in native_rows.items():
        if name in native_export:continue
        need(row['tracked'] is False,'Tracked compiled-source file absent from clean export: '+name)
        historical=name.startswith('build-core-20261001/') or name.startswith('research/__pycache__/') and name.endswith('.pyc')
        need(historical,'Unreviewed nonexport compiled-source file: '+name);extras.append(row)
    for name,value in before.get('canonical_helpers',{}).items():
        need(name in exported and exported[name]['bytes']==value['bytes'] and exported[name]['sha256']==value['sha256'],'Canonical compile helper differs from exact export: '+name)
    defender=receipt['Defender'];need(type(defender) is dict,'Actual Defender result missing')
    for key in ('receipt','manifest'):
        if key in defender and defender[key] is not None:read_ref(defender[key])
    return {'schema':'lyd.r13.clean-export-native-byte-qualification.v1','status':'ACTUAL_COMPILED_NATIVE_BYTES_MATCH_ACTUAL_CLEAN_EXPORT','source_revision':expected_head,'compiled_route':route,'original_compiled_source_kind':receipt['source_kind'],'compiled_verification':compiled_ref,'actual_export_report':export_report,'actual_export_source_inventory':jread(read_ref(export_report))['source_inventory'],'compiled_source_states':state_refs,'compiled_source_inventory':before['native_inventory'],'complete_compiled_source_count':len(native_rows),'exact_export_native_count':len(native_export),'export_native_exact_subset':True,'whole_compiled_source_before_after_unchanged':True,'nonexport_historical_rows':extras,'canonical_producer':receipt['canonical_producer'],'raw_CMakeCache':receipt['raw_CMakeCache'],'actual_flags':flags,'actual_products':products,'native_artifacts':{'dll':products[TARGETS[0]],'injector':products[TARGETS[1]]},'actual_focused_tests':tests,'original_outer_exit_code':receipt['original_outer_exit_code'],'Defender':defender,'player_control':'OFF','player_compiled20_credit':False,'default_MCP_tool_count':21,'private_MCP_tool_count':23,'runtime_verified':False}
