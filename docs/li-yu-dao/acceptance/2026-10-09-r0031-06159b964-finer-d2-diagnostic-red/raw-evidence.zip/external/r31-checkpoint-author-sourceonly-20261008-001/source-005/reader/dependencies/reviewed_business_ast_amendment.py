"""Explicit finite R27 source inverse; no generic business bypass or runtime credit."""
from pathlib import Path
from dataclasses import replace
import copy,hashlib,json
D=Path(__file__).parent
TABLE_SHA='405b9ba3b569727b66c65a9e249c307a1bf0273455233b08c539bacf5dff4519'
def need(c,m):
 if not c:raise ValueError(m)
def reference(path):
 p=Path(path);raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def table():
 p=D/'finite_business_inverse_table.json';need(reference(p)['sha256']==TABLE_SHA,'exact finite inverse table bytes');return json.loads(p.read_bytes())['files']
def parse_file(rel,raw,m):
 if rel.endswith('.yml'):return {'AST_kind':'localization-complete-source-lines.v1','lines':raw.decode('utf-8').splitlines(keepends=True)}
 return m.parse_clausewitz(raw.decode('utf-8-sig'))
def fp(x,m):return [(e.key,e.operator,fp(e.value,m))for e in x.entries]if isinstance(x,m.Block)else x
def tree(x,m):return {'block':[{'key':e.key,'operator':e.operator,'value':tree(e.value,m)}for e in x.entries]}if isinstance(x,m.Block)else x
def ah(x,m):return hashlib.sha256(json.dumps(fp(x,m),ensure_ascii=True,separators=(',',':')).encode()).hexdigest()
def read_prior(row):
 p=Path(row['path']);need(reference(p)==row,'approved prior source bytes differ');return p.read_bytes()
def inverse_file(rel,current,m):
 rows=table();need(rel in rows,'unregistered source inverse file');row=rows[rel]
 need(ah(current,m)==row['candidate_complete_AST_sha256'],'unreviewed complete candidate AST')
 value=copy.deepcopy(tree(current,m))
 for op in row['inverse_operations']:
  if not op['path']:
   need(op['kind']=='replace' and value==op['current'],'complete exact root inverse');value=copy.deepcopy(op['prior']);continue
  node=value
  for key in op['path'][:-1]:node=node[key]
  key=op['path'][-1]
  if op['kind']=='replace':need(node[key]==op['current'],'finite exact inverse target');node[key]=copy.deepcopy(op['prior'])
  elif op['kind']=='splice':
   target=node[key];start=op['start'];need(target[start:start+len(op['current'])]==op['current'],'finite exact inverse splice');target[start:start+len(op['current'])]=copy.deepcopy(op['prior'])
  else:raise ValueError('unregistered finite inverse operation')
 prior=parse_file(rel,read_prior(row['before']),m)if row['before']is not None else None
 need(value==tree(prior,m) and ah(prior,m)==row['prior_complete_AST_sha256'],'complete prior AST differs after explicit finite inverse')
 return prior
def inverse_factory(current,m):return inverse_file('common/scripted_effects/lyd_c3_head_factory.txt',current,m)
def inverse_events(current,m):return inverse_file('events/lyd_i3b_institution_events.txt',current,m)
