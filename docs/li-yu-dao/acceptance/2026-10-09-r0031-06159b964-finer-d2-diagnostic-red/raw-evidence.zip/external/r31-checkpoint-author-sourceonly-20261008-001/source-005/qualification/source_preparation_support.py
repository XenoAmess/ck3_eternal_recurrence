"""Pure source/manifest census and read-only local .4 game identity checks."""
from pathlib import Path
import ctypes
from ctypes import wintypes
import hashlib
import json
import re

OLD_MANIFEST = Path('C:/workspace/ck3_lyd_runtime_20261004/r24-reviewed-production-release-20261007-003.manifest.json')
OLD_MANIFEST_SHA = '9695fff36f4fdcb45f9082371ea80c32a4a64908d7cdfdd02592d14d2df3417a'
GAME = Path('C:/Program Files (x86)/Steam/steamapps/common/Crusader Kings III/binaries/ck3.exe')
GAME_SHA = '98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518'
APP_MANIFEST = Path('C:/Program Files (x86)/Steam/steamapps/appmanifest_1158310.acf')
OLD_PROFILE = Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-014/native-profile-with-exit-inventory.json')
OLD_PROFILE_SHA = '6676d37ebae3f2d80e35c4e6cbd440c9e0882eec1713df19ebd57ff3f9b26150'
OLD_GUARD = Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-014/root-profile-request-002/native-profile-fresh-001/guard-profile.json')
OLD_GUARD_SHA = '8f353334d43284a862c69a0c1f155da7c2f67f410c93b5a7364a1db8292a5faf'
CRITICAL = ('common/scripted_effects/lyd_c3_head_factory.txt', 'common/scripted_effects/lyd_i3b_setup_effects.txt')

def need(ok, reason):
    if not ok: raise ValueError(reason)

def raw(path):
    path = Path(path).resolve()
    for parent in (path, *path.parents):
        need(not parent.is_symlink() and not parent.is_junction(), 'Linked source/reference refused')
    return Path('\\\\?\\' + str(path)).read_bytes()

def ref(path):
    path = Path(path).resolve(); data = raw(path)
    return {'path': path.as_posix(), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def manifest_rows(data, expected_count=71):
    need(type(expected_count) is int and expected_count in (70, 71), 'Declared current71 or retained prior70 manifest required')
    need(data.get('product_id') == 'mod_li_yu_dao' and type(data.get('files')) is list and len(data['files']) == expected_count,
         'Reviewed exact product manifest count differs')
    rows = []
    for item in data['files']:
        path = item['path']; size = item.get('size', item.get('bytes')); digest = item['sha256']
        need(type(path) is str and bool(path) and not Path(path).is_absolute() and '\\' not in path and '..' not in path.split('/')
             and type(size) is int and size >= 0 and type(digest) is str and re.fullmatch('[0-9a-f]{64}', digest), 'Invalid reviewed production row')
        rows.append({'path': path, 'bytes': size, 'sha256': digest})
    need(len({row['path'].casefold() for row in rows}) == expected_count, 'Duplicate reviewed runtime paths')
    return sorted(rows, key=lambda row: row['path'])

def reviewed_production(path, digest, expected_head):
    need(expected_head == REVIEWED_HEAD, 'Actual ROOT reviewed clean HEAD required')
    need(type(digest) is str and re.fullmatch('[0-9a-f]{64}', digest), 'Actual reviewed manifest SHA required')
    stamp = ref(path); need(stamp['sha256'] == digest == REVIEWED_MANIFEST_SHA, 'Actual reviewed manifest bytes/SHA changed')
    need(ref(AUTHORIZED_DELIVERY['path']) == AUTHORIZED_DELIVERY, 'Reviewed R27 business amendment source changed')
    need(ref(SOURCEFIX_DELIVERY['path']) == SOURCEFIX_DELIVERY, 'Reviewed seven-change/sole-added source delivery changed')
    sourcefix = json.loads(raw(SOURCEFIX_DELIVERY['path']))
    source_rows = sourcefix['sources']
    need(type(source_rows) is list and len(source_rows) == 8, 'Exact R24 seven changed files plus one M3 addition required')
    declared = {row['relative'].removeprefix('mod_li_yu_dao/'): row for row in source_rows}
    need(len(declared) == 8 and set(declared) == set(REVIEWED_CHANGED_SHA256), 'Complete reviewed sourcefix paths differ')
    data = json.loads(raw(path)); need(data.get('git_sha') == REVIEWED_MANIFEST_HEAD, 'Actual reviewed production creation HEAD changed')
    rows = manifest_rows(data)
    need(ref(OLD_MANIFEST)['sha256'] == OLD_MANIFEST_SHA, 'Retained actual R24 manifest changed')
    before = manifest_rows(json.loads(raw(OLD_MANIFEST)), 70)
    old = {row['path']: row for row in before}; current = {row['path']: row for row in rows}
    need(ADDED_RUNTIME_KEY not in old and set(current) == set(old) | {ADDED_RUNTIME_KEY}, 'Exact retained product path set plus sole M3 key required')
    changed = sorted(name for name in old if current[name] != old[name])
    need(set(changed) == set(REVIEWED_CHANGED_SHA256) - {ADDED_RUNTIME_KEY} and len(changed) == 7, 'Only seven reviewed R24 runtime changes allowed')
    for name, wanted in REVIEWED_CHANGED_SHA256.items():
        row = declared[name]
        need(ref(row['after']['path']) == row['after'] and current[name]['sha256'] == wanted == row['after']['sha256']
             and current[name]['bytes'] == row['after']['bytes'], 'Exact reviewed changed/added production bytes required: ' + name)
        if name == ADDED_RUNTIME_KEY:
            need(row['before'] is None, 'M3 addition requires exact prior absence')
        else:
            need(ref(row['before']['path']) == row['before'] and old[name]['sha256'] == row['before']['sha256']
                 and old[name]['bytes'] == row['before']['bytes'], 'Exact reviewed R24 preimage differs: ' + name)
    need(sum(current[name] == old[name] for name in old) == 63, 'Other62 R24 business files and descriptor must remain byte exact')
    changed_rows = [{'path': name, 'before': old[name], 'after': current[name]} for name in changed]
    added_rows = [{'path': ADDED_RUNTIME_KEY, 'before': None, 'after': current[ADDED_RUNTIME_KEY]}]
    proof = {'changed_existing_runtime_files': changed_rows, 'added_runtime_files': added_rows,
             'unchanged_existing_runtime_files': 63, 'complete_runtime_pathset': sorted(current),
             'original_business_protection_universe': 69, 'current_business_files': 70, 'runtime_product_files': 71,
             'authorized_business_amendment_source': AUTHORIZED_DELIVERY, 'sourcefix_delivery': SOURCEFIX_DELIVERY}
    return {'reviewed_manifest': stamp, 'reviewed_manifest_head': data['git_sha'], 'actual_target_source_head': expected_head, 'rows': rows,
            'prior_actual_R24_manifest': ref(OLD_MANIFEST), 'unchanged_prior_R24_runtime_files': 63,
            'authorized_actual_sourcefix_delivery': AUTHORIZED_DELIVERY,
            'reviewed_changed_runtime_files': changed_rows, 'reviewed_added_runtime_files': added_rows,
            'final_reviewed_business_delta': proof}

def private_option_census(native_root):
    root = Path(native_root).resolve(); pending = [root / 'CMakeLists.txt']; sources, names = {}, set()
    while pending:
        path = pending.pop().resolve()
        if path.as_posix() in sources: continue
        need(path.is_relative_to(root) and path.is_file(), 'Actual local included CMake source required')
        text = raw(path).decode('utf-8-sig')
        text = re.sub(r'(?m)^\s*#.*$', '', text)
        sources[path.as_posix()] = ref(path)
        names.update(re.findall(r'\b(?:option|cmake_dependent_option)\s*\(\s*(XAR_CK3_ENABLE_[A-Z0-9_]+)\b', text))
        for match in re.finditer(r'(?m)^\s*include\s*\(\s*(?:"([^"]+)"|([^\s)]+))', text):
            value = match[1] or match[2]
            value = value.replace('${CMAKE_CURRENT_SOURCE_DIR}', str(root)).replace('${CMAKE_CURRENT_LIST_DIR}', str(path.parent))
            if '${' in value: raise ValueError('Unknown variable in local CMake include; explicit source adaptation required')
            candidate = Path(value)
            if not candidate.is_absolute(): candidate = root / candidate
            if candidate.is_file(): pending.append(candidate)
            elif value.casefold().endswith('.cmake'): raise ValueError('Declared local CMake include missing: ' + value)
    need(bool(names), 'Nonempty actual private option census required')
    return {'names': sorted(names), 'source_files': [sources[name] for name in sorted(sources)],
            'method': 'literal XAR option declarations in root and recursively declared local CMake includes'}

def file_version(path):
    version = ctypes.WinDLL('version', use_last_error=True)
    version.GetFileVersionInfoSizeW.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(wintypes.DWORD)]
    version.GetFileVersionInfoSizeW.restype = wintypes.DWORD
    version.GetFileVersionInfoW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, wintypes.LPVOID]
    version.GetFileVersionInfoW.restype = wintypes.BOOL
    version.VerQueryValueW.argtypes = [wintypes.LPCVOID, wintypes.LPCWSTR, ctypes.POINTER(wintypes.LPVOID), ctypes.POINTER(wintypes.UINT)]
    version.VerQueryValueW.restype = wintypes.BOOL
    handle = wintypes.DWORD(); size = version.GetFileVersionInfoSizeW(str(path), ctypes.byref(handle))
    if not size: return {'available': False, 'winerror': ctypes.get_last_error()}
    buffer = ctypes.create_string_buffer(size)
    need(version.GetFileVersionInfoW(str(path), 0, size, buffer), 'Version-info read failed')
    pointer = wintypes.LPVOID(); count = wintypes.UINT()
    need(version.VerQueryValueW(buffer, '\\', ctypes.byref(pointer), ctypes.byref(count)), 'Version fixed-info query failed')
    values = ctypes.cast(pointer, ctypes.POINTER(wintypes.DWORD))
    need(count.value >= 52 and values[0] == 0xFEEF04BD, 'Actual fixed file info differs')
    def dotted(high, low): return '.'.join(str(number) for number in (high >> 16, high & 0xFFFF, low >> 16, low & 0xFFFF))
    return {'available': True, 'FileVersion': dotted(values[2], values[3]), 'ProductVersion': dotted(values[4], values[5])}

def game_reference():
    stamp = ref(GAME)
    need(stamp['bytes'] == 101040248 and stamp['sha256'] == GAME_SHA,
         'Exact installed Steam .4 executable98702 required; old .3 rejected')
    data = raw(GAME); need(data[:2] == b'MZ', 'Current game PE header missing')
    offset = int.from_bytes(data[60:64], 'little')
    need(data[offset:offset + 4] == b'PE\0\0', 'Current game PE signature missing')
    need(int.from_bytes(data[offset + 4:offset + 6], 'little') == 0x8664,
         'Current game must be AMD64')
    app = raw(APP_MANIFEST).decode('utf-8-sig')
    ids = re.findall(r'"buildid"\s+"([0-9]+)"', app)
    need(ids == ['25734779'], 'Exact installed Steam .4 buildid required')
    launcher = GAME.parents[1] / 'launcher/launcher-settings.json'
    need(json.loads(raw(launcher)).get('rawVersion') == '1.20.0.4',
         'Actual installed launcher version must be 1.20.0.4')
    return {'executable': stamp, 'Steam_appmanifest': ref(APP_MANIFEST),
            'actual_Steam_buildid': ids[0], 'actual_PE_machine': 'AMD64',
            'actual_file_version_resource': file_version(GAME),
            'known_exact_hash_game_version': '1.20.0.4',
            'version_mapping_basis': {'launcher_settings': ref(launcher),
                                    'exact_install_identity': 'ROOT supplied Steam build25734779 and executable98702'},
            'Steam_or_game_contacted': False, 'new_runtime_acceptance': 'NOT_RUN'}

REVIEWED_HEAD = '06159b964d859d30f2f07f4b183284df7d6dac47'
REVIEWED_MANIFEST_SHA = '326aa6798dd4efb011fddac48c0a14361c9f2b27fdbbefefcdfa327ff6e5fdf8'
REVIEWED_CHANGED_SHA256 = {'common/scripted_effects/lyd_c3_head_factory.txt': 'bf1b40de272467afd9b1e0eb2e3c59c4f62285d0daef314cb066446467efccc7', 'events/lyd_i3b_institution_events.txt': '954219d1bfee6242d0135c7d4426202259e63f01989c22153cf19036bbfbe116', 'common/scripted_triggers/lyd_i3b_institution_triggers.txt': '42e169066766eab63dd1dd51803cbfb6c197f288223e3416a925bd37354fcb2d', 'common/scripted_triggers/lyd_c2_consent_triggers.txt': '7d79760cc3e6eb63cc67b1a10efd84d38cda098a7bff2276612f82939ad4615f', 'events/lyd_c2_consent_events.txt': '55a9a51e144b23c5b0942e054b44626372ffd63a6817b3ec1d90114d0a237496', 'localization/english/lyd_c2_consent_l_english.yml': 'fedcf23c88738a5d9bfa8b11c27868e32d3152f36ad005ee81da352e761f0c17', 'localization/simp_chinese/lyd_c2_consent_l_simp_chinese.yml': '12dfc97d4176f31ba33bbc78defe2bdd5100ac99dbabba945e6dcfa93fc16797', 'common/scripted_triggers/lyd_m3_faith_asset_triggers.txt': '29e7070d62e94e35b83f5b9cbbfab7fda1139a5d8c73982cd357bffed3086baa'}
AUTHORIZED_DELIVERY = {'path': 'C:/workspace/ck3_lyd_runtime_20261004/r27-reviewed-business-amendment-sourceonly-20261008-001/INDEX.json', 'bytes': 12835, 'sha256': 'b4468e88196fe8fbe2bb3faed6dc54a9150b4b50fc0562b542c2fbc1be9a0ace'}
ADDED_RUNTIME_KEY = 'common/scripted_triggers/lyd_m3_faith_asset_triggers.txt'
SOURCEFIX_DELIVERY = {'path': 'C:/workspace/ck3_lyd_runtime_20261004/r27-reviewed-business-amendment-sourceonly-20261008-001/SOURCEFIX-DELIVERY.source-only.json', 'bytes': 7285, 'sha256': '8f364527932fa0b7173797d5bc191ffc2d8f841f387900b864c96f744ec45d73'}
REVIEWED_MANIFEST_HEAD = '06159b964d859d30f2f07f4b183284df7d6dac47'
