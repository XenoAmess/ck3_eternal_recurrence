"""ROOT-only qualification of retained JSON; never opens a checkpoint body or rewrites RED."""
from pathlib import Path
from hashlib import sha256
import argparse, importlib.util, json, sys, traceback
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
CP=P
RUN=Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-031').resolve()
HEAD='06159b964d859d30f2f07f4b183284df7d6dac47'
GENERAL_LIMIT=8*1024*1024

def need(condition,message):
    if not condition:raise ValueError(message)

def closed_pairs(items):
    result={}
    for key,value in items:
        need(key not in result,'duplicate JSON key '+key);result[key]=value
    return result

def artifact(path):
    path=Path(path).resolve()
    need(path.suffix=='.json' and 0<path.stat().st_size<=GENERAL_LIMIT,'retained general JSON boundary')
    raw=path.read_bytes()
    return {'path':path.as_posix(),'bytes':len(raw),'sha256':sha256(raw).hexdigest()},json.loads(raw.decode('utf-8-sig'),object_pairs_hook=closed_pairs)

def source_ref(path):
    path=Path(path).resolve()
    need(path.suffix in ('.py','.txt','.json'),'source artifact only')
    raw=path.read_bytes();return {'path':path.as_posix(),'bytes':len(raw),'sha256':sha256(raw).hexdigest()}

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);sys.modules[name]=value;spec.loader.exec_module(value);return value

def put(path,value):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--author-output',type=Path,required=True)
    p.add_argument('--author-result-sha256',required=True)
    p.add_argument('--formal-callback-registry',type=Path,required=True)
    p.add_argument('--formal-callback-registry-sha256',required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    old=a.author_output.resolve();out=a.output.resolve()
    need(old.is_relative_to(RUN) and out.is_relative_to(RUN) and not out.exists(),'distinct create-only current RUN output required')
    result_ref,result=artifact(old/'RESULT.json')
    need(result_ref['sha256']==a.author_result_sha256,'original completed author RESULT hash differs')
    rows=result['outputs'];need(type(rows)is list and len({Path(r['path']).resolve() for r in rows})==len(rows),'original output inventory unique')
    originals={Path(r['path']).resolve():r for r in rows}
    def original(name):
        path=(old/name).resolve();need(path in originals,'retained artifact absent from original author inventory '+name)
        actual,value=artifact(path);declared=originals[path]
        need(actual['bytes']==declared['bytes'] and actual['sha256']==declared['sha256'],'original author retained artifact bytes differ '+name)
        return actual,value
    inp_ref,inp=original('INPUT.exact.json')
    initial_ref,initial=original('STATE.json')
    qualified_ref,qualified=original('native-qualification/QUALIFIED-NATIVE.json')
    typed_ref,typed=original('TYPED-PROTECTION.json')
    prov_ref,provenance=original('PROVENANCE.actual-or-pending.json')
    conversion_ref,conversion=original('CONVERSION-REQUEST.actual-or-pending.json')
    need(inp['expected_source_head']==HEAD and inp['window'] in ('B3-signed-precommit','B4-factory-result','B5-final-protection'),'exact retained formal source/window')
    need(provenance['source_head']==HEAD,'retained provenance source HEAD')
    registry_ref,registry=artifact(a.formal_callback_registry)
    need(Path(registry_ref['path']).is_relative_to(RUN) and registry_ref['sha256']==a.formal_callback_registry_sha256,'exact actual RUN callback registry hash')
    need(registry['source_head']==HEAD and registry['window']==inp['window'],'actual callback registry source/window')
    cp_ref,cp=artifact(inp['checkpoint_receipt'])
    need(cp_ref==conversion['artifacts']['checkpoint_receipt'],'original native checkpoint descriptor drift')
    need(initial_ref==conversion['artifacts']['saved_state'] and prov_ref==conversion['artifacts']['provenance'],'original conversion STATE/provenance descriptors drift')
    rb=qualified['runtime_binding']
    for key,ref in (('saved_state',initial_ref),('checkpoint_receipt',cp_ref),('provenance',prov_ref)):
        need(rb['artifact_sha256'][key]==ref['sha256'],'already-qualified original retained binding '+key)
    for key in ('G2_receipt','G3_receipt'):
        actual,_=artifact(inp[key]);need(actual==conversion['artifacts'][key] and rb['artifact_sha256'][key]==actual['sha256'],'already-qualified original native query binding '+key)
    export_ref,export=artifact(inp['source_export_report'])
    need(export['source']['head']==HEAD,'actual retained export HEAD')
    need(provenance['executing_reader_artifact']['sha256']=='eb68af08c5d636e4b91caa4e0290bb889ae912ca5b7e0158f4e4d99f85958736','unchanged actual reader contract')
    expected_reader=Path(export['source_root'])/'tools/lyd_i3b_checkpoint_readback/reader/i3b_checkpoint_reader.py'
    need(Path(provenance['executing_reader_artifact']['path']).resolve()==expected_reader.resolve(),'actual executing reader must be clean export reader')
    need(source_ref(expected_reader)==provenance['executing_reader_artifact'],'actual reader source bytes differ')
    need(source_ref(CP/'source-008/reader/i3b_checkpoint_reader.py')['sha256']==provenance['executing_reader_artifact']['sha256'],'external exact reader mirror differs')
    # Load the same exact CP005 module paths used by the unchanged B4/B5 author.
    # Export and executing-copy reader hashes are independently equal above.
    sys.path.insert(0,str(CP/'source-008/reader/dependencies'))
    sys.path.insert(0,str(CP/'source-008/reader'))
    sys.path.insert(0,str(CP/'source-008/title_reference'))
    reader=module('r31_retained_actual_bound_reader',CP/'source-008/reader/i3b_checkpoint_reader.py')
    converter=module('r31_retained_checkpoint_transition_converter_v3',CP/'source-008/reader/sdk_checkpoint_transition_qualification_v3.py')
    leaf=module('r31_retained_independent_formal_leaf',CP/'source-008/title_reference/formal_native_qualification.py')
    # Use an existing original native-joined JSON only when it was already
    # produced and inventoried. B3's preserved failed author has no such file.
    joined_ref=None;state=initial
    if (old/'STATE.native-qualified.json').exists():
        joined_ref,state=original('STATE.native-qualified.json')
    need(state['observation_checks_match'] is True,'retained original STATE checks must all match')
    need(all(row['matches'] is True for row in state['checks']),'retained original STATE has a failed check')
    out.mkdir()
    report={'schema':'lyd.r31.retained-json-formal-qualification-execution.v1','status':'RUNNING','original_author_RESULT':result_ref,'source_adapter':source_ref(Path(__file__)),'source_leaf':source_ref(CP/'source-008/title_reference/formal_native_qualification.py'),'save_body_reads':0,'SDK_game_calls':0,'old_RED_rewritten':False,'formal_qualification_credit':None}
    try:
        observation=leaf.qualify(registry,cp,state,qualified,provenance,reader,converter,export,typed)
        observation['original_input_registry']=registry_ref
        observation['retained_source_artifacts']={'author_input':inp_ref,'initial_state':initial_ref,'native_joined_state':joined_ref,'qualified_native':qualified_ref,'typed_protection':typed_ref,'checkpoint_receipt':cp_ref,'provenance':prov_ref}
        target=out/'FORMAL-NATIVE-QUALIFICATION.actual-or-pending.json';put(target,observation)
        report['certificate']=artifact(target)[0];report['status']=observation['qualification_status'];report['qualification_pass']=observation['qualification_pass'];report['formal_qualification_credit']=observation['formal_mandate_credit']
        report['legacy_STATE_unchanged']=True
    except Exception as error:
        report['status']='RED_PRESERVED';report['error_type']=type(error).__name__;report['error']=str(error)
        with (out/'stderr.traceback.txt').open('x',encoding='utf-8',newline='\n') as stream:stream.write(traceback.format_exc())
        raise
    finally:
        put(out/'RESULT.actual.json',report)
    print(json.dumps({'status':report['status'],'qualification_pass':report.get('qualification_pass'),'save_body_reads':0,'SDK_game_calls':0,'output':out.as_posix()}))

if __name__=='__main__':main()
