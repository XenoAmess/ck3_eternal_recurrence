"""Qualify retained R31 author JSON once; never opens checkpoint or native products."""
from pathlib import Path
import argparse,importlib.util,json,sys
sys.dont_write_bytecode=True
P=Path(__file__).parent;S=P/'source-008'
sys.path.insert(0,str(S/'title_reference'))
import formal_native_qualification as leaf
import materialize_checkpoint_request_v4 as io
leaf.HEAD=io.HEAD
ACCEPTED_AUTHORS={'ac4c80e8919a0ea87fdf73f9aa15c086755ad9d42bc5fbb450448300110b75e8'}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--author-output',type=Path,required=True);p.add_argument('--author-result-sha256',required=True);p.add_argument('--registry',type=Path,required=True);p.add_argument('--registry-sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 root=a.author_output.resolve();result_ref=io.ref(root/'RESULT.json');io.need(result_ref['sha256']==a.author_result_sha256,'explicit retained author RESULT SHA')
 result=io.read(result_ref);io.need(result['executing_author']['sha256'] in ACCEPTED_AUTHORS and result['save_body_reads']==1 and result['strict_formal_reader_executed'] is True and result['status'] in ('ACTUAL_COMPACT_NATIVE_SAVED_OBSERVATIONS_JOINED','RED_PRESERVED'),'exact R31 single-scan formal author must already have executed')
 io.need(io.ref(result['executing_author']['path'])==result['executing_author'],'executing source artifact changed')
 artifacts={}
 for name in ('INPUT.exact.json','STATE.json','TYPED-PROTECTION.json','PROVENANCE.actual-or-pending.json','native-qualification/QUALIFIED-NATIVE.json'):
  stamp=io.ref(root/name);io.need(stamp in result['outputs'],'retained output not in original author inventory '+name);artifacts[name]=stamp
 joined=root/'STATE.native-qualified.json'
 if joined.exists():
  stamp=io.ref(joined);io.need(stamp in result['outputs'],'retained joined STATE not in original output inventory');artifacts['STATE.native-qualified.json']=stamp
 inp=io.read(artifacts['INPUT.exact.json']);io.need(inp['expected_source_head']==leaf.HEAD and inp['window'] in ('B3-signed-precommit','B4-factory-result','B5-final-protection'),'retained actual R31 formal window INPUT')
 provenance=io.read(artifacts['PROVENANCE.actual-or-pending.json']);qualified=io.read(artifacts['native-qualification/QUALIFIED-NATIVE.json']);typed=io.read(artifacts['TYPED-PROTECTION.json']);state=io.read(artifacts.get('STATE.native-qualified.json',artifacts['STATE.json']))
 cp_ref=result['source_refs']['checkpoint_receipt'];cp=io.read(cp_ref)
 for name,stamp in (('checkpoint_receipt',cp_ref),('saved_state',artifacts['STATE.json']),('G2_receipt',result['source_refs']['G2_receipt']),('G3_receipt',result['source_refs']['G3_receipt']),('provenance',artifacts['PROVENANCE.actual-or-pending.json'])):io.need(qualified['runtime_binding']['artifact_sha256'][name]==stamp['sha256'],'original converter artifact binding differs '+name)
 for name in ('profile','source_export_report','metadata_result','compiled_result'):io.need(io.ref(inp[name])==result['source_refs'][name],'actual retained source tuple changed '+name)
 export=io.read(result['source_refs']['source_export_report']);io.need(export['source']['head']==leaf.HEAD and provenance['source_head']==leaf.HEAD,'actual clean R31 source/provenance HEAD')
 author=io.module('r31_retained_formal_source006',S/'author_actual_checkpoint.py')
 after,_=author.converter.transition.bind_checkpoint_transition(cp,provenance)
 for name,operation in (('G2_receipt','assembly_predicates'),('G3_receipt','religious_title')):
  receipt=io.read(result['source_refs'][name]);author.converter.outer_identity(receipt,provenance);author.converter.sdk.normalize_public_query(receipt['result'],after,operation)
 registry_ref=io.ref(a.registry);io.need(registry_ref['sha256']==a.registry_sha256,'explicit original registry SHA');registry=io.read(registry_ref);io.need(registry['window']==inp['window'],'retained actual registry/window')
 observed=leaf.qualify(registry,cp,state,qualified,provenance,author.reader,author.converter,export,typed)
 observed['retained_source_artifacts']={'author_input':artifacts['INPUT.exact.json'],'initial_state':artifacts['STATE.json'],'native_joined_state':artifacts.get('STATE.native-qualified.json'),'qualified_native':artifacts['native-qualification/QUALIFIED-NATIVE.json'],'typed_protection':artifacts['TYPED-PROTECTION.json'],'checkpoint_receipt':cp_ref,'provenance':artifacts['PROVENANCE.actual-or-pending.json']};observed['original_author_result']=result_ref;observed['original_input_registry']=registry_ref
 out=a.output.resolve();io.need(out.is_relative_to(P.parent) and not out.exists(),'fresh external pure JSON output');out.mkdir()
 io.put(out/'FORMAL-NATIVE-QUALIFICATION.actual-or-pending.json',observed)
 io.put(out/'RESULT.actual.json',{'schema':'lyd.r31.retained-json-formal-qualification-result.v1','status':observed['qualification_status'],'qualification_pass':observed['qualification_pass'],'formal_mandate_credit':observed['formal_mandate_credit'],'whole_product_pass':None,'original_author_result':result_ref,'input_registry':registry_ref,'output':io.ref(out/'FORMAL-NATIVE-QUALIFICATION.actual-or-pending.json'),'checkpoint_body_reads':0,'binary_reads':0,'SDK_game_calls':0,'main_writes':0})
 print(json.dumps({'status':observed['qualification_status'],'qualification_pass':observed['qualification_pass'],'output':str(out),'whole_product_pass':None},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
