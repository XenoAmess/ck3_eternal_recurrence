from pathlib import Path
import ast,json
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
p=B/'r30-checkpoint-author-sourceonly-20261008-001/source-008/reader/i3b_checkpoint_reader.py'
s=p.read_text(encoding='utf-8')
for n in ast.parse(s).body:
 if isinstance(n,ast.FunctionDef) and n.name in ('var_ref','saved_title_bool','title_flag'):
  print('\nFUNCTION',n.name);print('\n'.join(s.splitlines()[n.lineno-1:n.end_lineno]))
p=B/'r30-checkpoint-author-sourceonly-20261008-001/source-008/reader/sdk_checkpoint_transition_qualification_v3.py'
s=p.read_text(encoding='utf-8');print('\nCONVERTER TITLE');print('\n'.join(s.splitlines()[179:222]))
p=B/'live-attempt-030/persistent-client-001/0018-r30-root-D2-event-context-001.native-01.json'
d=json.loads(p.read_bytes());print('\nD2 actual context');print(json.dumps(d['result']['current_event_window_context'],indent=2))
p=B/'live-attempt-030/D2-diagnostic-author-001/STAGE-RAW-OBSERVATIONS.actual.json';d=json.loads(p.read_bytes())
for k,r in d['all_actor_held_Title_ASTs'].items():
 if 'lyd_c2_owned_head_title' in r['variables']:
  print('\nActual historical Title row',k);print(json.dumps(r,indent=2))
