"""ROOT-only exact copy and baseline INPUT/argv creation. Never runs materializer/author or SDK/game."""
from pathlib import Path
import argparse,hashlib,json,sys
sys.dont_write_bytecode=True
PY='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
RUN=Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-031').resolve()
SCHEMA='lyd.r31.root-baseline-capture-specification.v1'
KEYS={'schema','source_head','prepared','client_session','attached_binding','attach','checkpoint','G2','G3','metadata_result','compiled_result','native_clean_qualification','sdk_metadata_artifact','baseline_author','materializer','future_preserved_checkpoint','input_output','materialize_argv_output','materializer_output','author_output'}
def need(ok,message):
 if not ok:raise ValueError(message)
def ref(path):
 p=Path(path).resolve();need(p.suffix in ('.json','.py'),'compact JSON/source reference only');need(p.stat().st_size<=8*1024*1024,'bounded8MiB JSON/source');raw=p.read_bytes()
 return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(row):
 need(type(row)is dict and set(row)=={'path','bytes','sha256'},'exact ref3');need(ref(row['path'])==row,'frozen JSON/source changed')
 return json.loads(Path(row['path']).read_bytes())
def put(path,obj):
 with Path(path).open('x',encoding='utf-8',newline='\n')as f:json.dump(obj,f,indent=2,ensure_ascii=False);f.write('\n')
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--inputs',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--root-create',action='store_true',required=True);a=p.parse_args()
 specification=ref(a.inputs);need(specification['sha256']==a.sha256,'explicit frozen capture specification SHA');d=read(specification)
 need(type(d)is dict and set(d)==KEYS and d['schema']==SCHEMA,'closed current R31 capture specification')
 need(d['source_head']=='06159b964d859d30f2f07f4b183284df7d6dac47','actual R31 source HEAD')
 prepared,session,binding=[read(d[key]) for key in ('prepared','client_session','attached_binding')]
 need(prepared['source_revision']==session['source_revision']==d['source_head'],'actual current source binding')
 need(session['client_session_id']==binding['client_session_id'] and session['profile_sha256']==binding['profile_sha256']==prepared['profile']['sha256'],'original Client/profile binding')
 need(session['target']['pid']==prepared['root_actual_live_binding']['process_id']and type(session['target']['pid'])is int and session['target']['pid']>0 and session['target']['process_create_time']==prepared['root_actual_live_binding']['process_create_time'],'original current R31 PID/create time')
 need(type(binding['native_session_id'])is str and len(binding['native_session_id'])==32 and all(c in '0123456789abcdef' for c in binding['native_session_id']),'current native session')
 for key in ('attach','checkpoint','G2','G3'):
  pair=d[key];need(type(pair)is dict and set(pair)=={'native_receipt','sdk_result'},'original SDK/native pair '+key)
  native=read(pair['native_receipt']);read(pair['sdk_result'])
  need(native['session_id']==binding['native_session_id'] and native['profile_sha256']==prepared['profile']['sha256'],'same native session/profile '+key)
  need(Path(native['receipt_path']).resolve()==Path(pair['native_receipt']['path']).resolve(),'original native receipt path '+key)
 metadata=read(d['metadata_result']);need(metadata['head']==d['source_head'] and metadata['native_clean_qualification']==d['native_clean_qualification'] and metadata['metadata']==d['sdk_metadata_artifact'] and metadata['compiled_verification']==d['compiled_result'],'actual ROOT metadata tuple')
 need(ref(d['baseline_author']['path'])==d['baseline_author'] and d['baseline_author']['sha256']=='d23daeb7d5cfbebd55af9bcf8776a3087bd75acda863be054e255de2c68fba77','exact frozen R31 cache29 baseline author')
 need(ref(d['materializer']['path'])==d['materializer'],'frozen R31 baseline materializer')
 native=read(d['checkpoint']['native_receipt']);saved=native['result']['checkpoint'];expected=d['future_preserved_checkpoint']
 source=Path(saved['path']).resolve();target=Path(expected['path']).resolve()
 need(source==RUN/'userdir/save games/xar_checkpoint.ck3' and target==RUN/'checkpoints/baseline-original0240/checkpoint.ck3','exact actual saved source and future immutable destination')
 need(native['status']=='native_gameplay_postcondition_verified' and saved['status']=='saved' and saved['date_raw']==53144712 and saved['size']==expected['bytes'] and saved['sha256']==expected['sha256'],'original saved descriptor')
 output=Path(d['input_output']).resolve();argv_output=Path(d['materialize_argv_output']).resolve()
 locations=[target.parent,output,argv_output,Path(d['materializer_output']).resolve(),Path(d['author_output']).resolve()]
 need(all(path.is_relative_to(RUN) and not path.exists() for path in locations),'all new baseline copy/input/materializer/author targets must be fresh inside R31 run')
 need(source.stat().st_size==saved['size'],'actual saved source size before copy')
 target.parent.mkdir(parents=True,exist_ok=False);digest=hashlib.sha256();copied=0
 with source.open('rb')as reader,target.open('xb')as writer:
  for chunk in iter(lambda:reader.read(1024*1024),b''):
   writer.write(chunk);digest.update(chunk);copied+=len(chunk)
 preserved={'path':target.as_posix(),'bytes':copied,'sha256':digest.hexdigest()}
 need(preserved==expected and target.stat().st_size==saved['size'] and source.stat().st_size==saved['size'],'actual immutable copy must equal original SDK bytes/SHA')
 fields={'schema':'lyd.r31.actual-checkpoint-materializer-input.v1','prepared':d['prepared'],'client_session':d['client_session'],'attach':d['attach'],'metadata_result':d['metadata_result'],'compiled_result':d['compiled_result'],'native_clean_qualification':d['native_clean_qualification'],'sdk_metadata_artifact':d['sdk_metadata_artifact'],'checkpoint':d['checkpoint'],'G2':d['G2'],'G3':d['G3'],'preserved_checkpoint':preserved,'window':'baseline','author_output':d['author_output'],'original0240_control':None,'native_title_reference_query':None,'native_event_numeric_query':None,'formal_callback_registry':None}
 put(output,fields)
 argv=[PY,'-B','-X','utf8',d['materializer']['path'],'--inputs',output.as_posix(),'--inputs-sha256',ref(output)['sha256'],'--output',d['materializer_output']]
 put(argv_output,{'argv':argv,'executed':False,'future_author_body_scans_requested':1,'baseline_author':d['baseline_author']})
 put(target.parent/'CAPTURE.actual.json',{'schema':'lyd.r31.root-preserved-baseline-capture.v1','specification':specification,'source_saved_descriptor':saved,'actual_immutable_copy':preserved,'inputs':ref(output),'materializer_argv':ref(argv_output),'exact_copy_stream_passes':1,'save_parser_scans':0,'materializer_executed':False,'author_executed':False,'SDK_game_calls':0,'future_baseline_control':None,'wholemod_PASS':None})
 print(json.dumps({'inputs':ref(output),'preserved_checkpoint':preserved,'argv_file':ref(argv_output),'materializer_executed':False,'author_executed':False},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
