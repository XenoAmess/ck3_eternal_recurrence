from pathlib import Path
from hashlib import sha256
import argparse, json, sys
B = Path('C:/workspace/ck3_lyd_runtime_20261004')
R = B / 'live-attempt-031'
C = R / 'persistent-client-001'
CP = B / 'r31-checkpoint-author-sourceonly-20261008-001'
if sha256((CP / 'INDEX.json').read_bytes()).hexdigest() != '84f68bf556f1dac2f40d04dce23e95e9668bc1c74288adf978448ee4b9b788c3':
    raise ValueError('Exact SDK-wrapper checkpoint source004 INDEX required')
HEAD = '06159b964d859d30f2f07f4b183284df7d6dac47'
p = argparse.ArgumentParser()
p.add_argument('--baseline-spec', type=Path, required=True)
p.add_argument('--window', choices=['B3-signed-precommit', 'B4-factory-result', 'B5-final-protection'], required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--review')
p.add_argument('--reference')
p.add_argument('--signed', type=Path)
p.add_argument('--previous', type=Path)
p.add_argument('--action', nargs=2)
for e in ('410', '412', '411', '413'):
    p.add_argument('--callback-' + e, nargs=2)
a = p.parse_args()

def ref(q, *, sdk_wrapper=False):
    q = Path(q).resolve()
    limit=16 * 1024 * 1024 if sdk_wrapper else 8 * 1024 * 1024
    if sdk_wrapper and not (q.parent == C.resolve() and q.name.endswith('.sdk-result.json')):
        raise ValueError('Explicit original Client001 SDK wrapper required')
    if not (q.is_relative_to(R) and q.suffix == '.json' and (q.stat().st_size <= limit)):
        raise ValueError('Existing actual-formal-registry-author input predicate rejected at original line 9')
    raw = q.read_bytes()
    return {'path': q.as_posix(), 'bytes': len(raw), 'sha256': sha256(raw).hexdigest()}

def read(q):
    return json.loads(Path(q).read_bytes())
sys.path.insert(0, str(CP / 'source-008/title_reference'))
import formal_native_qualification as leaf
ref(a.baseline_spec)
base = read(a.baseline_spec)
attach = read(base['attach']['native_receipt']['path'])
prov = {k: attach[k] for k in ('session_id', 'profile_sha256', 'pipe_name')}

def pair(rid):
    root = read(R / (rid + '.ROOT-EXECUTION-001/RESULT.actual.json'))
    if not (root['status'] == 'EXPLICIT_REQUEST_RECORDED' and root['sdk_isError'] is False):
        raise ValueError('Existing actual-formal-registry-author input predicate rejected at original line 15')
    rows = root['official_native_copies']
    if not len(rows) == 1:
        raise ValueError('Existing actual-formal-registry-author input predicate rejected at original line 16')
    copy = rows[0]
    if not ref(copy['path']) == copy:
        raise ValueError('Existing actual-formal-registry-author input predicate rejected at original line 16')
    stem = Path(copy['path']).name.removesuffix('.native-01.json')
    response = read(C / (stem + '.response.json'))
    if not (response['status'] == 'MCP_RESULT_RECORDED' and len(response['native_receipts']) == 1):
        raise ValueError('Existing actual-formal-registry-author input predicate rejected at original line 17')
    row = response['native_receipts'][0]
    sdk = ref(C / response['sdk_result'], sdk_wrapper=True)
    if not sdk['sha256'] == response['sdk_result_sha256']:
        raise ValueError('Existing actual-formal-registry-author input predicate rejected at original line 18')
    original = ref(row['path'])
    if not original['sha256'] == copy['sha256'] == row['sha256']:
        raise ValueError('Existing actual-formal-registry-author input predicate rejected at original line 18')
    v = {'native_receipt': original, 'sdk_result': sdk}
    n, _ = leaf.query_pair(v, prov)
    return (v, n)

def callback(ids, event):
    if not ids is not None:
        raise ValueError('Existing actual-formal-registry-author input predicate rejected at original line 21')
    q, n = pair(ids[0])
    s, selection = pair(ids[1])
    if not (n['status'] == 'native_event_query_verified' and n['result']['event_definition_key'] == event):
        raise ValueError('Existing actual-formal-registry-author input predicate rejected at original line 21')
    if not (selection['status'] == 'native_gameplay_postcondition_verified' and selection['result']['step'] == 'select-event-option-1'):
        raise ValueError('Existing actual-formal-registry-author input predicate rejected at original line 22')
    if not selection['snapshot_before']['revision'] == n['result']['queried_revision']:
        raise ValueError('Existing actual-formal-registry-author input predicate rejected at original line 23')
    return {'query': q, 'select': s}

def cert(q, window):
    if not q is not None:
        raise ValueError('Existing actual-formal-registry-author input predicate rejected at original line 25')
    v = read(q)
    if not (v['source_head'] == HEAD and v['window'] == window and (v['qualification_pass'] is True)):
        raise ValueError('Existing actual-formal-registry-author input predicate rejected at original line 25')
    return ref(q)
if a.window == 'B3-signed-precommit':
    callbacks = {'lyd.' + e: [callback(getattr(a, 'callback_' + e), 'lyd.' + e)] for e in ('410', '412', '411', '413')}
    review, n = pair(a.review)
    reference, rn = pair(a.reference)
    if not n['result']['event_definition_key'] == rn['result']['event_definition_key'] == 'lyd.430':
        raise ValueError('Existing actual-formal-registry-author input predicate rejected at original line 28')
    registry = {'schema': leaf.REGISTRY_SCHEMA, 'source_head': HEAD, 'window': a.window, 'callback_pairs': callbacks, 'review_query': review, 'reference_query': reference}
    numeric = {'schema': 'lyd.author.native-event-value-query.v1', **review}
else:
    registry = {'schema': leaf.POST_SCHEMA, 'source_head': HEAD, 'window': a.window, 'signed_precommit': cert(a.signed, 'B3-signed-precommit'), 'previous_postcommit': cert(a.previous, 'B4-factory-result') if a.window == 'B5-final-protection' else None, 'action': callback(a.action, 'lyd.430' if a.window == 'B4-factory-result' else 'lyd.431')}
    numeric = None
if not a.output.resolve().is_relative_to(R):
    raise ValueError('Existing actual-formal-registry-author input predicate rejected at original line 33')
a.output.mkdir()
for filename, value in [('REGISTRY.actual.json', registry), ('NATIVE-EVENT-VALUE-QUERY.actual.json', numeric)]:
    if value is not None:
        with (a.output / filename).open('x', encoding='utf-8', newline='\n') as f:
            json.dump(value, f, indent=2)
            f.write('\n')
print(json.dumps({'registry': ref(a.output / 'REGISTRY.actual.json'), 'numeric': ref(a.output / 'NATIVE-EVENT-VALUE-QUERY.actual.json') if numeric else None, 'SDK_calls': 0, 'save_body_reads': 0, 'formal_acceptance': None}))
