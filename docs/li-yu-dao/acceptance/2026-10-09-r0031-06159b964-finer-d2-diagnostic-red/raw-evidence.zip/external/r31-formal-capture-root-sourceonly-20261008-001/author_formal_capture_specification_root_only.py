"""ROOT file-only reusable B1-B5 capture specification/argv author. Never copies or parses a save."""
from pathlib import Path
import argparse,hashlib,json,re,sys
sys.dont_write_bytecode=True
PY='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004');RUN=BASE/'live-attempt-031';HERE=Path(__file__).parent
CP=None;HEAD=None;CLIENT=None;FORMAL_CAPTURE_HELPER_SHA256='8a1fabd59a57b551a04da8eda13173d39fd5c0d3a749183ba03ff872d556bdc7'
WINDOWS={'B1-phase1':'B1','B2-representatives':'B2','B3-signed-precommit':'B3','B4-factory-result':'B4','B5-final-protection':'B5'}
def need(ok,msg):
 if not ok:raise ValueError(msg)
def sdk_wrapper_path(path):
 p=Path(path).resolve();need(p.name.endswith('.sdk-result.json') and p.parent == (Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-031')/'persistent-client-001').resolve(),'explicit original same-run Client SDK wrapper only');return p

def ref(path,*,sdk_wrapper=False):
 path=Path(path).resolve();need(type(sdk_wrapper)is bool,'literal SDK wrapper role');limit=16*1024*1024 if sdk_wrapper else 8*1024*1024
 if sdk_wrapper:sdk_wrapper_path(path)
 need(path.suffix.lower() in ('.json','.py') and 0<path.stat().st_size<=limit,'compact actual JSON/source by explicit role');raw=path.read_bytes();return {'path':path.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(path):return json.loads(Path(path).read_bytes())
def put(path,obj):
 with Path(path).open('x',encoding='utf-8',newline='\n')as f:json.dump(obj,f,indent=2,ensure_ascii=False);f.write('\n')
def pair(stem):
 need(type(stem)is str,'actual R31 Client stem must be a string')
 matched=re.fullmatch(r'([0-9]{4})-(r31-(?:[0-9]{3}-[A-Za-z0-9_-]+|root-[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*))',stem)
 need(matched is not None,'actual R31 Client stem without path: legacy numbered or exact ROOT request ID')
 response=read(CLIENT/(stem+'.response.json'));need(response['schema']=='ck3.lyd.mcp-dispatch.v1' and response['status']=='MCP_RESULT_RECORDED' and len(response['native_receipts'])==1,'one completed actual native receipt')
 need(type(response['sequence'])is int and 0<response['sequence']<=9999 and response['sequence']==int(matched.group(1)) and response['request_id']==matched.group(2) and stem==format(response['sequence'],'04d')+'-'+response['request_id'],'actual response sequence/request_id must exactly produce this stem')
 queue=(RUN/'official-mcp-queue-002').resolve();request_id=response['request_id']
 request_path=Path(response['request_path']).resolve();request_copy=(CLIENT/(stem+'.request.json')).resolve()
 need(request_path.parent==queue and request_path.name==request_id+'.request.json' and request_copy.parent==CLIENT,'actual same-run matching queue request and Client request copy')
 need(ref(request_path)['sha256']==ref(request_copy)['sha256']==response['request_sha256'],'actual queue request and Client request copy exact SHA')
 request=read(request_path);need(request['schema']=='ck3.lyd.mcp-request.v1' and request['request_id']==request_id,'actual request body ID must match response/stem')
 row=response['native_receipts'][0];original=Path(row['path']).resolve();copy=(CLIENT/row['copy']).resolve()
 need(row['copy']==stem+'.native-01.json' and original.is_relative_to(RUN/'native-evidence') and copy.parent==CLIENT,'actual same-run original native receipt and same-stem Client copy')
 need(ref(original)['sha256']==ref(copy)['sha256']==row['sha256'],'original native and Client copy exact SHA')
 native=read(original);need(Path(native['receipt_path']).resolve()==original,'original native receipt path')
 sdk=(CLIENT/response['sdk_result']).resolve();need(response['sdk_result']==stem+'.sdk-result.json' and sdk.parent==CLIENT and ref(sdk,sdk_wrapper=True)['sha256']==response['sdk_result_sha256'],'original same-stem SDK response binding')
 return {'native_receipt':ref(original),'sdk_result':ref(sdk,sdk_wrapper=True)}
def main():
 global CP,HEAD,CLIENT
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--window',choices=list(WINDOWS),required=True)
 p.add_argument('--client-output',type=Path,required=True);p.add_argument('--expected-head',required=True)
 p.add_argument('--checkpoint-source',type=Path,required=True);p.add_argument('--checkpoint-index-sha256',required=True)
 for key in ('checkpoint-stem','g2-stem','g3-stem'):p.add_argument('--'+key,required=True)
 p.add_argument('--baseline-capture-specification',type=Path,required=True);p.add_argument('--baseline-capture-specification-sha256',required=True);p.add_argument('--output-prefix',type=Path,required=True);p.add_argument('--attempt-label',required=True)
 for key in ('native-title-reference-query','native-event-numeric-query','formal-callback-registry'):
  p.add_argument('--'+key,type=Path);p.add_argument('--'+key+'-sha256')
 a=p.parse_args();CLIENT=a.client_output.resolve();CP=a.checkpoint_source.resolve();HEAD=a.expected_head
 need(CLIENT == (RUN/'persistent-client-001').resolve(),'Actual R31 Client output must be this RUN mcp-client-001 or mcp-client-002')
 need(re.fullmatch('[0-9a-f]{40}',HEAD or '') and HEAD not in ('0'*40,'f'*40),'Actual current HEAD required; future HEAD NULL rejected')
 need(ref(CP/'INDEX.json')['sha256']==a.checkpoint_index_sha256 and read(CP/'INDEX.json')['source_head']==HEAD,'Actual R31 checkpoint source INDEX/head binding')
 need(re.fullmatch(r'r[1-9][0-9]*-(pending|signed)',a.attempt_label),'strict positive-round pending/signed ROOT attempt label required');slug=WINDOWS[a.window]+'-'+a.attempt_label
 prefix=a.output_prefix.resolve();need(prefix.is_relative_to(RUN) and prefix.parent.is_dir() and not prefix.exists(),'fresh ROOT prefix inside actual run')
 specification_path=Path(str(prefix)+'.SPEC.actual.json');argv_path=Path(str(prefix)+'.ARGV.unexecuted.json');need(not specification_path.exists() and not argv_path.exists(),'fresh specification and argv')
 base_ref=ref(a.baseline_capture_specification);need(base_ref['sha256']==a.baseline_capture_specification_sha256 and Path(base_ref['path']).is_relative_to(RUN),'explicit actual same-run R31 baseline capture specification');base=read(a.baseline_capture_specification);need(base['schema']=='lyd.r31.root-baseline-capture-specification.v1' and base['source_head']==HEAD and Path(base['client_session']['path']).resolve()==CLIENT/'session.json','actual R31 baseline runtime tuple');index=read(CP/'INDEX.json')
 checkpoint,g2,g3=[pair(stem) for stem in (a.checkpoint_stem,a.g2_stem,a.g3_stem)]
 native=read(checkpoint['native_receipt']['path']);saved=native['result']['checkpoint'];need(saved['status']=='saved' and native['status']=='native_gameplay_postcondition_verified','actual successful checkpoint required')
 optional={}
 for key in ('native_title_reference_query','native_event_numeric_query','formal_callback_registry'):
  path=getattr(a,key);sha=getattr(a,key+'_sha256');need((path is None)==(sha is None),'optional artifact requires path and exact SHA together: '+key)
  if path is None:optional[key]=None
  else:
   stamp=ref(path);need(stamp['sha256']==sha and Path(stamp['path']).is_relative_to(RUN),'actual same-run optional artifact SHA '+key);read(path);optional[key]=stamp
 need(optional['formal_callback_registry'] is None or a.window in ('B3-signed-precommit','B4-factory-result','B5-final-protection'),'callback registry limited to supported windows')
 specification={'schema':'lyd.r31.root-formal-capture-specification.attempt.v2','source_head':base['source_head'],'window':a.window,'attempt_label':a.attempt_label,**{key:base[key] for key in ('prepared','client_session','attached_binding','attach','metadata_result','compiled_result','native_clean_qualification','sdk_metadata_artifact')},'checkpoint':checkpoint,'G2':g2,'G3':g3,'checkpoint_source_index':ref(CP/'INDEX.json'),'formal_author':index['formal_author'],'materializer':index['formal_materializer'],'original0240_control':ref(RUN/'ORIGINAL0240-CONTROL.actual.json'),**optional,'future_preserved_checkpoint':{'path':(RUN/'checkpoints'/(a.window+'-'+a.attempt_label)/'checkpoint.ck3').as_posix(),'bytes':saved['size'],'sha256':saved['sha256']},'input_output':(RUN/('ROOT-'+slug+'-MATERIALIZER-INPUTS.actual.json')).as_posix(),'materialize_argv_output':(RUN/('ROOT-'+slug+'-MATERIALIZE-ARGV.actual.json')).as_posix(),'materializer_output':(RUN/(slug+'-author-input-001')).as_posix(),'author_output':(RUN/(slug+'-author-001')).as_posix()}
 helper=HERE/'capture_formal_materializer_inputs_root_only.py';need(ref(helper)['sha256']==FORMAL_CAPTURE_HELPER_SHA256,'sealed generic capture helper')
 put(specification_path,specification);put(argv_path,{'argv':[PY,'-B','-X','utf8',helper.as_posix(),'--inputs',specification_path.as_posix(),'--sha256',ref(specification_path)['sha256'],'--root-create'],'executed':False,'future_immutable_copy':None,'future_author_result':None,'future_formal_PASS':None})
 print(json.dumps({'specification':ref(specification_path),'ROOT_capture_argv':ref(argv_path),'body_reads':0,'actual_copy':False,'materializer_executed':False,'author_executed':False},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
