"""ROOT file-only authentic original Title query descriptor; no SDK/game/save access."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,re,sys
from types import ModuleType
sys.dont_write_bytecode=True
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004');RUN=(BASE/'live-attempt-031').resolve()
HEAD='06159b964d859d30f2f07f4b183284df7d6dac47'
CP=BASE/'r31-checkpoint-author-sourceonly-20261008-001'
CAP=BASE/'r31-formal-capture-root-sourceonly-20261008-001'
PINS={
 CP/'INDEX.json':'84f68bf556f1dac2f40d04dce23e95e9668bc1c74288adf978448ee4b9b788c3',
 CAP/'author_formal_capture_specification_root_only.py':'ed6ab7bf4e6c454f6f3ea4725dfb42cf6212b6777b8f3395bbc19801d9f2f9a4',
 CP/'source-008/title_reference/title_reference_hook.py':'c69b7c4c186db8bdb3edc8a02470a68089842684d2cbbdbb2975b65391fa3510',
 CP/'source-008/title_reference/derive_saved_title_reference_v3.py':'587d2608f18d9a4d74f4e875a08cbe6103965512464eef447351e143718ba3d7',
 CP/'source-008/title_reference/bind_existing_join_request.py':'0fdb6e2289de4ae4a65b7196dae526c9819d708adaee6521b2076d71bba82ec8',
 CP/'source-008/reader/sdk_checkpoint_qualification.py':'75002dc344dda87cf18ec8093e68dace76c1f1b6e3ab7d525437b7a128a08d6f',
 CP/'source-008/reader/dependencies/confucian_dto_primitives.py':'39c6b004baf91a79db9beaa991a3a4a462ce81418f58b3a7f78c86805f935944',
 CP/'source-008/reader/dependencies/save_fields.py':'f23f4901f44c0aa015332256f9de02ede9006d66e59a2c2ec30fbdd752ab4933',
 CP/'source-008/reader/dependencies/bounded_save_parser.py':'12bae20f113f57e144fb422fbac2b53b8cbd5fce2ae92cb9d09f779c123f4489',
 Path('C:/lr31s1/ck3_autonomous_player/src/xar_autoplayer/bridge/event_window_context_contract.py'):'9deee2902b0b9a61cf515f030a0a9971ecce95feef8f560f92c2f6bee5b3745a',
 Path('C:/lr31s1/ck3_autonomous_player/src/xar_autoplayer/bridge/version_identity.py'):'9f7665ed680238f6904bc3ef22e1d67ef9b4ccd047e699542d5dbaff24b01086'}
def need(ok,message):
 if not ok:raise ValueError(message)
def raw(path):
 p=Path(path).resolve();need(p.suffix.lower()in('.json','.py') and 0<p.stat().st_size<=8*1024*1024,'bounded compact JSON/source only');return p.read_bytes()
def ref(path):
 p=Path(path).resolve();b=raw(p);return {'path':p.as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def unique(data):
 def pairs(rows):
  out={}
  for k,v in rows:need(k not in out,'duplicate JSON key '+k);out[k]=v
  return out
 return json.loads(data.decode('utf-8-sig'),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('nonfinite JSON '+x)))
def read(desc):
 need(type(desc)is dict and set(desc)=={'path','bytes','sha256'} and ref(desc['path'])==desc,'exact compact ref3 changed');return unique(raw(desc['path']))
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def put(path,obj):
 with path.open('x',encoding='utf-8',newline='\n')as f:json.dump(obj,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--request-id',required=True);p.add_argument('--client-output',required=True,type=Path);p.add_argument('--baseline-capture-specification',required=True,type=Path);p.add_argument('--baseline-capture-specification-sha256',required=True);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
 client=a.client_output.resolve();output=a.output.resolve();audit=output.with_name(output.stem+'.AUTHENTICATION.actual.json')
 need(client == (RUN/'persistent-client-001').resolve(),'actual R31 Client001/002 required')
 need(re.fullmatch(r'r31-(?:[0-9]{3}-[A-Za-z0-9_-]+|root-[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*)',a.request_id)is not None,'actual R31 request ID without path')
 need(output.suffix=='.json' and output.is_relative_to(RUN) and output.parent.is_dir() and not output.exists() and not audit.exists(),'fresh descriptor and audit JSON inside actual R31 RUN')
 for path,sha in PINS.items():need(ref(path)['sha256']==sha,'frozen source dependency differs '+str(path))
 basis_ref=ref(a.baseline_capture_specification);need(basis_ref['sha256']==a.baseline_capture_specification_sha256 and Path(basis_ref['path']).is_relative_to(RUN),'explicit same-run baseline specification SHA')
 basis=read(basis_ref);need(basis['schema']=='lyd.r31.root-baseline-capture-specification.v1' and basis['source_head']==HEAD,'actual baseline capture source/schema')
 need(Path(basis['client_session']['path']).resolve()==client/'session.json','baseline specification actual Client session path')
 session,prepared,binding=[read(basis[k]) for k in ('client_session','prepared','attached_binding')]
 need(session['schema']=='ck3.lyd.persistent-mcp-session.v1' and session['source_revision']==prepared['source_revision']==HEAD,'actual Client/PREPARED source tuple')
 need(session['automatic_attach']is False and session['automatic_retry']is False,'existing non-retrying explicit Client')
 need(session['client_session_id']==binding['client_session_id'] and session['profile_sha256']==binding['profile_sha256']==prepared['profile']['sha256'],'actual Client/profile/attach tuple')
 need(session['target']['pid']==prepared['root_actual_live_binding']['process_id'] and session['target']['process_create_time']==prepared['root_actual_live_binding']['process_create_time'],'actual PID/create-time tuple from authenticated JSON')
 profile_ref=ref(session['profile']);need(profile_ref['sha256']==session['profile_sha256'] and profile_ref==prepared['profile'],'actual known10 profile bytes')
 need(Path(session['queue']).resolve()==(RUN/'official-mcp-queue-002').resolve(),'actual same Client queue')
 matches=list(client.glob('????-'+a.request_id+'.response.json'));need(len(matches)==1,'one original recorded response for this actual request ID')
 stem=matches[0].name[:-len('.response.json')]
 cap=module('r31_title_descriptor_cap003',CAP/'author_formal_capture_specification_root_only.py');cap.CLIENT=client
 pair=cap.pair(stem)
 response=unique(raw(matches[0]));request=unique(raw(response['request_path']))
 need(request['operation']=='call_tool' and request['name']=='ck3_query_profile_event_window_v1','original request must be the exact native event-context query')
 sys.path.insert(0,str(CP/'source-008/title_reference'))
 hook=module('r31_title_descriptor_original_hook',CP/'source-008/title_reference/title_reference_hook.py')
 strict=module('r31_title_descriptor_original_frame',CP/'source-008/reader/sdk_checkpoint_qualification.py')
 attach=read(basis['attach']['native_receipt']);attach_sdk=read(basis['attach']['sdk_result']);hook.validate_sdk_native(attach_sdk,attach)
 need(Path(attach['receipt_path']).resolve()==Path(basis['attach']['native_receipt']['path']).resolve() and attach['session_id']==binding['native_session_id'] and attach['profile_sha256']==session['profile_sha256'],'original authenticated attach receipt and Client binding')
 need(binding['attach_native']['sha256']==basis['attach']['native_receipt']['sha256'] and binding['attach_sdk']==basis['attach']['sdk_result'],'actual attached-binding original SDK/native SHA tuple')
 need(attach['status']=='attached_snapshot_verified' and attach['uses_ocr']is False and attach['uses_desktop_input']is False,'actual successful native attach contract')
 attach_frame=strict.frame_binding(attach['snapshot'])
 need(attach_frame['game_pid']==session['target']['pid'],'actual attach snapshot PID matches Client target')
 host_rows={}
 for key in ('observation_before','observation_after'):
  host=attach[key]
  need(host['pid']==host['window_pid']==session['target']['pid'] and host['process_create_time']==session['target']['process_create_time'],'actual attach host PID/create time differs '+key)
  host_rows[key]={k:host[k] for k in ('pid','window_pid','process_create_time','executable','executable_sha256','build_id')}
 need(attach['snapshot']['diagnostics']['pipe_name']==attach['pipe_name'],'actual attach snapshot native pipe identity')
 provenance={'session_id':binding['native_session_id'],'profile_sha256':session['profile_sha256'],'pipe_name':attach['pipe_name']}
 descriptor={'schema':hook.QUERY_SCHEMA,**pair};native=hook.authenticate_query_source(descriptor,provenance)
 result=native['result'];source=result['source'];bound=result['binding']
 need(type(source)is dict and set(source)=={'snapshot_id','revision','native_revision','date_raw','paused','backend_id'},'closed compact query source')
 need(type(source['snapshot_id'])is str and source['snapshot_id'] and all(type(source[k])is int and source[k]>0 for k in ('revision','native_revision')) and type(source['date_raw'])is int and -(2**31)<=source['date_raw']<2**31 and source['paused']is True and source['backend_id']=='native-headless','actual paused compact query source fields')
 frame={k:source[k] for k in ('snapshot_id','revision','native_revision','date_raw')}
 need(type(bound)is dict and set(bound)==set(frame)|{'expected_revision','event_instance_id'} and {k:bound[k] for k in frame}==frame and bound['expected_revision']==source['revision'] and type(bound['event_instance_id'])is int and bound['event_instance_id']>0,'actual compact query source/binding equality')
 need(type(request['arguments'])is dict and set(request['arguments'])=={'expected_revision','event_instance_id'} and request['arguments']=={'expected_revision':bound['expected_revision'],'event_instance_id':bound['event_instance_id']},'actual request revision/event equals compact binding')
 need(result['step']=='query-current-event-window-context-v1' and result['accepted']is True and result['status']=='available' and result['scope']=='exact-current-event-window' and result['backend_id']=='native-headless','actual available native query operation')
 for key,wanted in (('queried_snapshot_id',source['snapshot_id']),('queried_revision',source['revision']),('queried_native_revision',source['native_revision']),('snapshot_revision',source['native_revision']),('date_raw',source['date_raw'])):
  need(type(result[key])is type(wanted) and result[key]==wanted,'actual queried frame differs '+key)
 export=read(unique(raw(CP/'INDEX.json'))['actual_export'])
 need(export['source']['head']==HEAD and Path(export['source_root']).resolve()==Path('C:/lr31s1').resolve(),'actual exported pure event-contract source')
 namespace='r31_title_descriptor_actual_context';package=ModuleType(namespace);package.__path__=[str(Path('C:/lr31s1/ck3_autonomous_player/src/xar_autoplayer/bridge'))];sys.modules[namespace]=package
 module(namespace+'.version_identity',Path(package.__path__[0])/'version_identity.py')
 contract=module(namespace+'.event_window_context_contract',Path(package.__path__[0])/'event_window_context_contract.py')
 context=contract.normalize_current_event_window_context_v1(result['current_event_window_context'],expected_event_instance_id=bound['event_instance_id'],expected_date_raw=source['date_raw'],expected_snapshot_revision=source['native_revision'])
 need(context['status']=='available' and context['window_match_count']==1 and context['event_definition_key']=='lyd.430' and result['current_event_window_context_ready']is True,'actual single formal review430 query context')
 for key,value in context.items():need(key in result and hook.proof.json_bytes(result[key])==hook.proof.json_bytes(value),'raw normalized/flattened event context differs '+key)
 actor=attach_frame['played_character_id']
 need(context['root_scope']=={'status':'available','raw_type_index':4,'type_key':'character','subtype':0,'typed_identity':{'status':'available','kind':'character','character_id':actor}},'actual raw typed event root actor differs from native attached actor')
 need(type(result['query_sequence'])is int and result['query_sequence']>0 and result['current_event_effect_indicators_ready']is True,'actual query sequence/readiness')
 wrapper_keys={'scope','source','binding'};raw_keys=set(context)|{'step','accepted','query_sequence','backend_id','current_event_window_context','current_event_window_context_ready','current_event_effect_indicators_ready','queried_snapshot_id','queried_revision','queried_native_revision'}
 need(set(result)==raw_keys|wrapper_keys,'closed raw native query result')
 observation={'schema':'lyd.r31.authenticated-title-query-descriptor-author.v2','source_head':HEAD,'request_id':a.request_id,'response':ref(matches[0]),'request':ref(response['request_path']),'baseline_specification':basis_ref,'client_session':basis['client_session'],'attached_binding':basis['attached_binding'],'prepared':basis['prepared'],'profile':profile_ref,'descriptor':None,'authenticated_original_pair':pair,'actual_query_source':source,'actual_query_binding':bound,'actual_query_typed_root_scope':context['root_scope'],'actual_query_direct_game_PID':None,'actual_query_direct_process_create_time':None,'actual_query_direct_connection_generation':None,'actual_attach_snapshot_frame':attach_frame,'actual_attach_host_observations':host_rows,'actual_pipe_name':provenance['pipe_name'],'source_artifacts':[ref(x) for x in PINS],'query_identity_binding_authority':'Original query SDK/native bytes authenticate native session/profile/pipe; game PID/create time and generation are separately observed by the original attach and Client/PREPARED tuple. Compact query itself provides no new host or connection-generation observation.','title_binding_qualified':None,'last_checkpoint_before_history_verified':None,'qualification_pass':None,'formal_PASS':None,'wholemod_PASS':None,'SDK_game_calls':0,'checkpoint_body_reads':0}
 put(output,descriptor);observation['descriptor']=ref(output);put(audit,observation)
 print(json.dumps({'descriptor':ref(output),'authentication':ref(audit),'query_source':source,'qualification_pass':None,'body_reads':0},indent=2,ensure_ascii=False));return 0
if __name__=='__main__':raise SystemExit(main())
