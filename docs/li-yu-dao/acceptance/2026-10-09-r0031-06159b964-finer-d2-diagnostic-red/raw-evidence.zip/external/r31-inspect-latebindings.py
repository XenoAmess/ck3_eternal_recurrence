from pathlib import Path
import json
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
for p in (B/'r30-root-signed-B3-input.actual.json',B/'r30-root-cache-comparator-bound-source-20261008-002/INDEX.json',B/'r30-root-cache-comparator-bound-source-20261008-002/SOURCE-CONTRACT.json'):
 print('\nFILE',p);print(p.read_text(encoding='utf-8'))
p=B/'r30-root-canonical-export-20261008-002/REPORT.json';d=json.loads(p.read_bytes());print('\nREPORT source');print(json.dumps(d['source'],indent=2))
