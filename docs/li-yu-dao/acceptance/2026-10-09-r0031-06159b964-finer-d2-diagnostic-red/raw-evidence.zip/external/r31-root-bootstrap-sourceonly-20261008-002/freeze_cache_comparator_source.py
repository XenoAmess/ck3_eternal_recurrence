"""Freeze the existing cache equality comparator against ROOT's actual new export."""
from pathlib import Path
import argparse,ast,hashlib,json,re
HERE=Path(__file__).resolve().parent
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve()
PARENT=BASE/'r29-cache-comparator-export-archive-fix-sourceonly-20261008-003'
HEAD_OLD='487da05f6c1cf231490fd1fe480ccc704ed0a80f'
def need(ok,message):
    if not ok:raise ValueError(message)
def ref(path):
    p=Path(path).resolve();need(p.suffix.lower()!='.ck3','Source or JSON only');raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def put(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    raw=value.encode()if type(value)is str else(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
    with path.open('xb')as f:f.write(raw)
def once(code,before,after):
    need(code.count(before)==1,'Original finite comparator source seam differs');return code.replace(before,after)
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--expected-head',required=True);p.add_argument('--source-root',type=Path,required=True)
    p.add_argument('--export-report',type=Path,required=True);p.add_argument('--export-report-sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    need(re.fullmatch('[0-9a-f]{40}',a.expected_head)and a.expected_head!=HEAD_OLD,'Actual new clean diagnostic source HEAD required')
    report_ref=ref(a.export_report);need(report_ref['sha256']==a.export_report_sha256.lower(),'Actual export REPORT SHA differs')
    report=json.loads(a.export_report.read_bytes());source=a.source_root.resolve()
    need(report['source']['head']==a.expected_head and Path(report['source_root']).resolve()==source and report['source_clean_before_and_after']is True,'Actual clean export binding required')
    prior=json.loads((PARENT/'SOURCE-CONTRACT.json').read_bytes());module_refs={rel:ref(source/rel)for rel in prior['pure_module_refs']}
    old_code=(PARENT/'compare_actor_cached_succession.py').read_text(encoding='utf-8-sig')
    code=once(old_code,"HEAD = '"+HEAD_OLD+"'",'HEAD = '+repr(a.expected_head));code=once(code,"SOURCE = Path('C:/lr29s2')",'SOURCE = Path('+repr(source.as_posix())+')')
    # Namespace projection preserves the actual provider/DTO/SDK/frame guards.
    code=code.replace('lyd.r29.actor-cache-saved-JSON','lyd.r30.actor-cache-saved-JSON').replace('R29 comparator','R30 diagnostic comparator').replace('authenticated R29','authenticated R30 diagnostic')
    ast.parse(code)
    out=a.output.resolve();need(out.is_relative_to(BASE) and not out.exists(),'Fresh external source-only comparator output required');out.mkdir()
    contract={**prior,'schema':'lyd.r30.actor-cache-saved-JSON-source-contract.v1','source_head':a.expected_head,'source_root':source.as_posix(),'pure_module_refs':module_refs,'required_pure_module_byte_contract':{rel:{k:x[k]for k in('bytes','sha256')}for rel,x in module_refs.items()},'actual_source_export_report':report_ref,'source_iteration_parent':ref(PARENT/'INDEX.json'),'actual_runtime_INPUTs':None,'actual_native_to_saved_equality':None,'business_acceptance_credit':None}
    put(out/'SOURCE-CONTRACT.json',contract);put(out/'compare_actor_cached_succession.py',code)
    put(out/'INDEX.json',{'status':'ACTUAL_NEW_EXPORT_COMPARATOR_SOURCE_FROZEN_NO_RUNTIME_EXECUTION','source_head':a.expected_head,'source_export_report':report_ref,'parent_source':ref(PARENT/'compare_actor_cached_succession.py'),'comparator':ref(out/'compare_actor_cached_succession.py'),'contract':ref(out/'SOURCE-CONTRACT.json'),'SDK_game_process_bus_build_body_calls':0})
    print(json.dumps({'INDEX':ref(out/'INDEX.json'),'comparator':ref(out/'compare_actor_cached_succession.py'),'executed':False}))
if __name__=='__main__':main()
