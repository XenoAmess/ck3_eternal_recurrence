"""Create the existing 16-field runtime request and exact ROOT materializer argv."""
from pathlib import Path
import argparse,hashlib,json,re
PY='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve()
SOURCE=Path(__file__).resolve().parent
MATERIALIZER_SHA='f3cd047f499e5641e82f26f611a76c850ad2bc533faacc0e713f6c33b78608c4'
def need(ok,message):
    if not ok:raise ValueError(message)
def ref(path):
    path=Path(path).resolve();need(path.suffix.lower()!='.ck3','JSON/source only; no checkpoint body');raw=path.read_bytes();return {'path':path.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(row):
    need(type(row)is dict and set(row)=={'path','bytes','sha256'}and ref(row['path'])==row,'Actual ref3 bytes/SHA differ');return json.loads(Path(row['path']).read_bytes())
def put(path,value):
    with path.open('x',encoding='utf-8',newline='\n')as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--expected-head',required=True)
    for key in('canonical-index','source-export-report','compiled-result','metadata-result','allocation-receipt','baseline-input','diagnostic-overlay'):
        p.add_argument('--'+key,type=Path,required=True);p.add_argument('--'+key+'-sha256',required=True)
    for key in('run-directory','attempt-id','screen-task','consumer-output','cold-input-output','runtime-source-output','output'):
        p.add_argument('--'+key,required=True)
    a=p.parse_args();refs={}
    for key in('canonical_index','source_export_report','compiled_result','metadata_result','allocation_receipt','baseline_input','diagnostic_overlay'):
        row=ref(getattr(a,key));need(row['sha256']==getattr(a,key+'_sha256').lower(),'Explicit actual input SHA differs: '+key);refs[key]=row
    canonical=read(refs['canonical_index']);meta=read(refs['metadata_result']);allocation=read(refs['allocation_receipt']);export=read(refs['source_export_report'])
    need(re.fullmatch('[0-9a-f]{40}',a.expected_head)and canonical['source_head']==meta['head']==export['source']['head']==a.expected_head,'Actual canonical/metadata/export HEAD differs')
    need(canonical['allocated_attempt']==allocation['run_id']and allocation['sequence']==31 and a.attempt_id=='R0031','Actual allocation-bound canonical INDEX required')
    need(meta['actual_export_report']==refs['source_export_report']and meta['compiled_verification']==refs['compiled_result'],'Actual metadata/export/compiled result pairing differs')
    native_gate=canonical['metadata_gate'];need(Path(native_gate['path']).suffix=='.py'and Path(native_gate['path']).name=='r14_clean_native_gate.py','Actual native gate module required, never qualification JSON')
    inventory=json.loads((SOURCE/'RUNTIME-TEMPLATE-INVENTORY.json').read_bytes())
    request={'schema':'lyd.root.next-file-only-runtime-source-request.v1','expected_head':a.expected_head,'source_export_report':refs['source_export_report'],'compiled_result':refs['compiled_result'],'metadata_result':refs['metadata_result'],'allocation_receipt':refs['allocation_receipt'],'previous_boundary':inventory['previous_boundary'],'previous_boundary_verifier':inventory['previous_boundary_verifier'],'native_gate':native_gate,'baseline_input':refs['baseline_input'],'run_directory':a.run_directory,'attempt_id':a.attempt_id,'screen_task':a.screen_task,'consumer_output':a.consumer_output,'cold_input_output':a.cold_input_output,'diagnostic_overlay':refs['diagnostic_overlay']}
    need(set(request)==set(json.loads((SOURCE/'RUNTIME-REQUEST.pending.json').read_bytes())),'Existing sixteen-field request shape must remain unchanged')
    script=ref(SOURCE/'materialize_runtime_source.py');need(script['sha256']==MATERIALIZER_SHA,'SOURCE004 materializer bytes changed')
    out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False);put(out/'REQUEST.actual.json',request)
    request_ref=ref(out/'REQUEST.actual.json');prod=canonical['actual_reviewed_production_manifest']
    argv=[PY,'-B','-X','utf8',script['path'],'--request',request_ref['path'],'--sha256',request_ref['sha256'],'--output',a.runtime_source_output,'--production-manifest',prod['path'],'--production-manifest-sha256',prod['sha256'],'--expected-head',a.expected_head,'--canonical-index',refs['canonical_index']['path'],'--canonical-index-sha256',refs['canonical_index']['sha256']]
    put(out/'ROOT-MATERIALIZE-RUNTIME-ARGV.actual.json',{'argv':argv,'cwd':'C:/workspace/ck3_eternal_recurrence','executed':False})
    cache_argv=[PY,'-B','-X','utf8',str(SOURCE/'freeze_cache_comparator_source.py'),'--expected-head',a.expected_head,'--source-root',export['source_root'],'--export-report',refs['source_export_report']['path'],'--export-report-sha256',refs['source_export_report']['sha256'],'--output',str(out/'cache-comparator-source')]
    put(out/'ROOT-FREEZE-CACHE-COMPARATOR-ARGV.actual.json',{'argv':cache_argv,'cwd':'C:/workspace/ck3_eternal_recurrence','executed':False})
    put(out/'RESULT.actual.json',{'request':request_ref,'materializer_argv':ref(out/'ROOT-MATERIALIZE-RUNTIME-ARGV.actual.json'),'cache_freeze_argv':ref(out/'ROOT-FREEZE-CACHE-COMPARATOR-ARGV.actual.json'),'runtime_executed':False,'source_function_or_gate_changed':False,'SDK_game_process_bus_MAIN_build_body_calls':0})
    print(json.dumps({'result':ref(out/'RESULT.actual.json'),'request':request_ref,'materializer_argv':ref(out/'ROOT-MATERIALIZE-RUNTIME-ARGV.actual.json')}))
if __name__=='__main__':main()
