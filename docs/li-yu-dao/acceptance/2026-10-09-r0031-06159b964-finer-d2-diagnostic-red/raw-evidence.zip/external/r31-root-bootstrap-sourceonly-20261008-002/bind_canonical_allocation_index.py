"""Copy a sealed canonical INDEX, binding only ROOT's actual allocated attempt."""
from pathlib import Path
import argparse,hashlib,json,re
def need(ok,message):
    if not ok:raise ValueError(message)
def ref(path):
    p=Path(path).resolve();raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(path,expected):
    stamp=ref(path);need(stamp['sha256']==expected.lower(),'Explicit actual JSON SHA differs');return stamp,json.loads(Path(path).read_bytes())
def put(path,value):
    with path.open('x',encoding='utf-8',newline='\n')as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--canonical-index',type=Path,required=True);p.add_argument('--canonical-index-sha256',required=True)
    p.add_argument('--allocation-receipt',type=Path,required=True);p.add_argument('--allocation-receipt-sha256',required=True)
    p.add_argument('--expected-head',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    original_ref,original=read(a.canonical_index,a.canonical_index_sha256);allocation_ref,allocation=read(a.allocation_receipt,a.allocation_receipt_sha256)
    need(re.fullmatch('[0-9a-f]{40}',a.expected_head)and original['source_head']==a.expected_head,'Actual canonical source HEAD must match')
    need(allocation['schema']=='xar.ck3-live-run-identity.v1'and allocation['mod_key']=='li-yu-dao'and type(allocation['sequence'])is int and allocation['sequence']==31 and allocation['legacy_alias']in(None,'R0031')and allocation['run_id'].endswith('--li-yu-dao--R0031'),'ROOT actual R0031 allocation required; no allocation performed')
    need(original['allocated_attempt']in(None,allocation['run_id']),'Original canonical allocation conflicts')
    bound={**original,'allocated_attempt':allocation['run_id']}
    need({k:v for k,v in bound.items()if k!='allocated_attempt'}=={k:v for k,v in original.items()if k!='allocated_attempt'},'Only allocated_attempt may change')
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
    put(out/'INDEX.json',bound)
    put(out/'ALLOCATION-BINDING.actual.json',{'parent_canonical_index':original_ref,'actual_allocation_receipt':allocation_ref,'bound_index':ref(out/'INDEX.json'),'changed_fields':['allocated_attempt'],'source_file_refs_and_functions_changed':False,'new_native_or_metadata_credit':None,'SDK_game_process_bus_MAIN_build_body_calls':0})
    print(json.dumps({'canonical_index':ref(out/'INDEX.json'),'binding':ref(out/'ALLOCATION-BINDING.actual.json'),'allocated_attempt':allocation['run_id'],'helpers_executed':False}))
if __name__=='__main__':main()
