from pathlib import Path
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
for rel in ('r30-diagnostic-cp-cap-constructor-sourceonly-20261008-002/project_r30_cp_cap_static.py','r30-diagnostic-cp-cap-constructor-sourceonly-20261008-004/materialize_D0_source.py','r29-cache-comparator-export-archive-fix-sourceonly-20261008-003/author_successor_source.py','r29-cp-cap-source-constructor-20261008-001/author_next_cp_cap_actual_inputs.py'):
 p=B/rel;print('\nFILE',p);print(p.read_text(encoding='utf-8'))
