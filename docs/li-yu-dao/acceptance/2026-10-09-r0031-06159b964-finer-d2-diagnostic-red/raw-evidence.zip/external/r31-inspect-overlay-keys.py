from pathlib import Path
import json
p=Path('C:/workspace/ck3_lyd_runtime_20261004/r30-root-diagnostic-overlay-20261008-002/BINDING.actual.json')
d=json.loads(p.read_bytes());print(json.dumps(d,indent=2))
