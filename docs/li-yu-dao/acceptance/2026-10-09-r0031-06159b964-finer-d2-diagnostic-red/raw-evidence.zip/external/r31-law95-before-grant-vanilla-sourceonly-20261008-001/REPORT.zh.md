# R31 条件性 law95 放置审阅（仅文件）

配置先于授予有原版依据，而且当前 factory 已这样做；当前读取到的原版实例不能证明 law95 可在未持有、尚未关联 Faith head 的标题上提前应用。因此 law-before-grant 仍是条件性实验假设，不是已证明修复。R31 D2a/D2b 结果、未来 Title、源码 HEAD 和业务资格均 NULL。

本包只读当前 production factory、其 authored template，以及安装目录内七份被有界 rg 定位的原版脚本。未读 EXE、存档正文或进程现场，未调用 SDK、Git、构建、测试，未修改 MAIN。原有限 native grant 审计未恢复。原 lookup 因 cmd 路径转义错误返回 2，纠正后的三个有界 rg 均返回 0，来源与 argv 保留在 LOOKUPS.actual.json。

## 已读顺序

- 当前 `mod_li_yu_dao/common/scripted_effects/lyd_c3_head_factory.txt`：23 创建；25–31 写 owned/owner-Faith 和四属性；34 holder；36 resolve；37 Faith head；51 才 add temporal law，并生成 CoA。实际 3022 B / SHA-256 `bf1b40de272467afd9b1e0eb2e3c59c4f62285d0daef314cb066446467efccc7`。模板路径和实际 hash 另存 FINDINGS。
- 原版 `common/scripted_effects/pam_antipope_effects.txt:128`：128–139 在 holder 前设置 destroy/no-claims/definitive/follows-primary-heir，以及名字、capital、landless；146–151 才 holder/resolve。该动态创建块没有预装 temporal law。152 的注释明确 CoA 需要 holder，154 才 generate_coa。该文件 24354 B / SHA `c74caedc55a76f3d7158ecb586a33473a2c80d65b79f77f336e5fced7c3713f0`。
- 原版 `common/scripted_effects/00_religion_effects.txt:347`：349 创建，360–363 属性，364–369 holder/resolve，370 Faith head，379 temporal law。该文件 41530 B / SHA `5bf6b0df3316f72f711507c310a349d508a3b83aef99373ea6440de20e4e4931`。
- 原版 `00_major_decisions_scripted_effects_2.txt:156`：156–162 holder/resolve，170 law，172 Faith head。它支持“law 可早于 head setter”的具体脚本顺序，但 holder 已存在，不能外推成 unheld 可用。
- 原版 `03_dlc_fp3_scripted_effects.txt:17`（另外 45、73、101 同类分支）：各自 holder/resolve 后才 Faith head 与 law。
- 原版 `events/religion_events/faith_creation_events.txt:111`：重建已有但无 holder 的 temporal HoF，143–148 holder/resolve，150 才 law。75–108 的 law 校正事件也要求现任 holder。

七份文件的完整路径、实际整文件 bytes/SHA、505 行有限窗口及其独立 hash 在 SPANS.actual.json。这里的安装目录版本归属沿 ROOT 的 actual .4 身份；没有重新读取或验证 PE。law95 是 ROOT 的既有 native 注册绑定，不能由下述 vanilla index=6 推出来。

## 未持有标题的准入缺口

`common/laws/01_title_succession_laws.txt:215` 的 temporal law 仅把 succession 配置为 `order_of_succession=player_heir`（231–232）。219–220 的 can_title_have 调 `is_temporal_head_of_faith_trigger`。`common/scripted_triggers/00_law_triggers.txt:537` 的实际定义要求 `is_head_of_faith=yes`，且 `holder.faith` 有 `doctrine_temporal_head`（538–539）。这些源码不能给 D2a 的 unheld/pre-head 模型一个 TRUE 准入证明。直接脚本 add_title_law 是否强制评估 can_title_have 仍 UNKNOWN；本任务不扩读 engine 来猜。

## 仅在真实 D2a45 → D2b40 后的最小实验建议

若未来原始回执确实给出该模式，它只能把当前观察到的变化定位到原子 holder/resolve 段，仍分不开 holder 与 resolve，也不证明 law 或缓存 writer 原因。

可供 ROOT 审阅的一项最小假设是：仅将 authored template 后段的 `add_title_law = temporal_head_of_faith_succession_law` 移入现有 `scope:new_title` 配置块，在 `change_title_holder` 前；`generate_coa` 留在 holder/resolve 后，Faith head setter 不移动，四属性、owner-Faith 标记、same-faith-law 原有保护/清理及全部政治保护不减。此处只给文字建议，没有修改模板或生成文件。

该建议没有原版“unheld law95”实例背书。必须先在尚未授予的实际新标题上读回 law 已落地，才能把后续 D2b 视为“配置过 law95 后授予”的实验；law 缺失即实验未实现，不可拿 Send/脚本 ACK 代替。若成功读回后依旧 cache40，则这次配置不足以解决保护变化；若回读45，也必须完成完整保护及后续正式验收，不能把单列表恢复授为业务 PASS。

本报告到当前脚本事实为止，后续读口计划为空，六项既有保护失败与所有旧 RED 保留。
