import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--input',type=Path,required=True); p.add_argument('--output',type=Path,required=True); a=p.parse_args()
request=json.loads(a.input.read_bytes()); argv=request['argv']; bindings=[]
for i,value in enumerate(argv):
 if value is not None: continue
 flag=argv[i-1]
 if not flag.endswith('-sha256'): raise ValueError('Only actual SHA late-binding supported')
 source=Path(argv[argv.index(flag[:-7])+1]); raw=source.read_bytes()
 stamp={'path':source.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 argv[i]=stamp['sha256']; bindings.append(stamp)
if not all(type(value)is str for value in argv): raise ValueError('Complete actual argv required')
with a.output.open('x',encoding='utf-8',newline='\n') as f: json.dump({'argv':argv,'bindings':bindings,'pending_parent':str(a.input),'executed':False},f,ensure_ascii=False,indent=2); f.write('\n')
raw=a.output.read_bytes(); print(json.dumps({'path':a.output.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'bindings':bindings}))
