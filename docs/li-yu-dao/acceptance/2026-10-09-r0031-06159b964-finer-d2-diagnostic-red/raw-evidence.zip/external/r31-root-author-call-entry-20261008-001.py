from pathlib import Path
import argparse
import hashlib
import json
B = Path('C:/workspace/ck3_lyd_runtime_20261004')
RUN = B / 'live-attempt-031'
CONSUMER = B / 'r31-root-actual-consumer-source-20261008-001'
CORE = B / 'r31-root-actual-runtime-source-20261008-001/core'
OPS = B / 'r31-root-actual-runtime-source-20261008-001/operations'
p = argparse.ArgumentParser()
p.add_argument('--spec', type=Path, required=True)
p.add_argument('--phase', choices=('pre-attach','attached'), required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
spec = json.loads(a.spec.read_bytes())
stem = spec['request_id']
assert a.spec.resolve().is_relative_to(RUN) and a.output.resolve().is_relative_to(RUN)
argv = ['C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe','-B','-X','utf8',(OPS/'run_request.py').as_posix(), '--run-directory',RUN.as_posix(),'--consumer-source',CONSUMER.as_posix(),'--consumer-index-sha256',sha(CONSUMER/'INDEX.json'),'--request-author',(CORE/'author_formal_request.py').as_posix(),'--request-author-sha256',sha(CORE/'author_formal_request.py'),'--executor',(OPS/'execute_request.py').as_posix(),'--executor-sha256',sha(OPS/'execute_request.py'),'--spec',a.spec.resolve().as_posix(),'--spec-sha256',sha(a.spec),'--argv-output',(RUN/(stem+'.once-argv.json')).as_posix(),'--execution-output',(RUN/(stem+'.execution')).as_posix(),'--phase',a.phase,'--execute']
if a.phase == 'attached':
    attached = RUN/'ROOT-ATTACHED-BINDING.actual.json'
    argv += ['--attached-binding',attached.as_posix(),'--attached-binding-sha256',sha(attached)]
with a.output.open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps({'argv':argv,'cwd':'C:/workspace/ck3_eternal_recurrence'},indent=2)+'\n')
print(json.dumps({'argv_file':a.output.resolve().as_posix(),'request_id':stem,'phase':a.phase,'SDK_calls':0,'game_calls':0}))
