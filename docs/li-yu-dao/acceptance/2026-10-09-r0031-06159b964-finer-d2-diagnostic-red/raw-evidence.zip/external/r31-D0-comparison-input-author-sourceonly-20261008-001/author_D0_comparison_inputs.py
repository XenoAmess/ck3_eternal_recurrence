"""Create-only retained JSON input/argv author; never runs either comparator or reads a save."""
from pathlib import Path
import argparse,hashlib,json,sys
sys.dont_write_bytecode=True
B=Path('C:/workspace/ck3_lyd_runtime_20261004');RUN=B/'live-attempt-031';CLIENT=RUN/'persistent-client-001'
HEAD='06159b964d859d30f2f07f4b183284df7d6dac47'
PY='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
CACHE=Path('C:/workspace/ck3_lyd_runtime_20261004/r31-root-cache-comparator-bound-source-20261008-001/compare_actor_cached_succession.py')
CACHE_SHA='3e9d1ea61d9e922db41656a576923c3f821e16d679e0e2b9812ef3b22ddd0aa5'
D0=Path(__file__).parent/'compare_signed_B3_cold_D0.py'
SEED=None;SEED_SHA=None
SAVE_STEM=None;CACHE_STEM=None
def need(ok,msg):
 if not ok:raise ValueError(msg)
def ref(p):
 p=Path(p).resolve();need(p.suffix.lower()=='.json' and 0<p.stat().st_size<=8*1024*1024,'bounded actual JSON only; no checkpoint body')
 raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(d):
 need(type(d)is dict and set(d)=={'path','bytes','sha256'} and ref(d['path'])==d,'Exact actual JSON ref3 required');return json.loads(Path(d['path']).read_bytes())
def put(p,v):
 with Path(p).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def source_ref(p):
 p=Path(p).resolve();raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def unique_output(author,name):
 rows=[r for r in author['outputs'] if Path(r['path']).name==name];need(len(rows)==1,'One actual original D0 '+name+' output required');need(ref(rows[0]['path'])==rows[0],'Exact original D0 output bytes/SHA '+name);return rows[0]
def original_native(stem):
 copy_ref=ref(CLIENT/(stem+'.native-01.json'));copy=read(copy_ref);original=ref(copy['receipt_path']);need(original['bytes']==copy_ref['bytes'] and original['sha256']==copy_ref['sha256'],'Original native receipt/copy bytes differ');return original,copy
def actual_tuple(path):
 desc=ref(path);need(Path(desc['path']).resolve()==(RUN/'D0-diagnostic-author-001/RESULT.json').resolve(),'This actual completed D0 result only')
 author=read(desc);need(author['status']=='ACTUAL_COMPACT_NATIVE_SAVED_OBSERVATIONS_JOINED' and author['save_body_reads']==1,'Actual single-body D0 completed required')
 state=unique_output(author,'STATE.json');typed=unique_output(author,'TYPED-PROTECTION.json');qualified=unique_output(author,'QUALIFIED-NATIVE.json')
 q=read(qualified);need(q['runtime_binding']['source_head']==HEAD and q['G2_status']=='BOUND_COMPLETE_NATIVE_OBSERVATION','Actual current R31 complete same-frame G2 qualified D0 required')
 return desc,author,state,typed,qualified,q
def cache_inputs(path):
 desc,author,state,typed,qualified,q=actual_tuple(path)
 save,cp=original_native(SAVE_STEM);cache_native,native=original_native(CACHE_STEM)
 need(author['source_refs']['checkpoint_receipt']==save,'Actual completed D0 original SAVE differs')
 response_ref=ref(CLIENT/(CACHE_STEM+'.response.json'));response=read(response_ref);request_ref=ref(response['request_path'])
 need(Path(request_ref['path']).resolve().parent==QUEUE,'Same actual ROOT queue required')
 sdk_path=CLIENT/response['sdk_result'];raw=sdk_path.read_bytes();need(sdk_path.name==CACHE_STEM+'.sdk-result.json' and 0<len(raw)<=16*1024*1024,'Original same-stem SDK wrapper role only');sdk_ref={'path':sdk_path.resolve().as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 need(response['status']=='MCP_RESULT_RECORDED' and response['request_sha256']==request_ref['sha256'] and response['sdk_result_sha256']==sdk_ref['sha256'],'Actual cache request/dispatch/SDK references differ')
 need(len(response['native_receipts'])==1 and response['native_receipts'][0]['sha256']==cache_native['sha256'] and Path(response['native_receipts'][0]['path']).resolve()==Path(cache_native['path']).resolve(),'Actual cache native dispatch binding')
 captured_ref=ref(CAPTURED);captured=read(captured_ref)
 need(captured['status']=='ORIGINAL_GAME_HANDLE_CAPTURED_ALIVE_BEFORE_ATTACH' and captured['source_head']==HEAD and captured['OpenProcess_count']==1 and captured['reopened_process'] is False and captured['initial_observation']['wait_result']==258,'Original preattach HANDLE capture required')
 raw_ref=captured['expected_raw_FILETIME_observation'];raw_host=read(raw_ref);launch=read(captured['actual_launch'])
 need(raw_host['launch']==captured['actual_launch'] and raw_host['source_head']==HEAD and raw_host['raw_creation_filetime']==captured['original_identity']['creation_filetime_100ns'],'Captured original HANDLE/rawFILETIME/actual launch chain differs')
 need(raw_host['pid']==captured['pid']==captured['original_identity']['pid']==launch['pid'] and raw_host['actual_psutil_create_time']==captured['process_create_time']==launch['process_create_time'],'Exact captured PID/ctime source chain differs')
 observation=cp['observation_after'];generation=cp['snapshot_after']['diagnostics']['connection_generation']
 need(observation['pid']==captured['pid'] and observation['process_create_time']==captured['process_create_time'] and observation['executable']==raw_host['actual_executable'] and generation==q['runtime_binding']['connection_generation'],'Actual SAVE attached/captured identity differs')
 config={'schema':'lyd.r30.actor-cache-saved-JSON-equality-request.v1','stage':'B3','author_result':desc,'state':state,'qualified_native':qualified,'save_receipt':save,'query_request':request_ref,'query_dispatch':response_ref,'query_sdk_result':sdk_ref,'query_native_receipt':cache_native,'source_export_report':author['source_refs']['source_export_report'],'profile':author['source_refs']['profile'],'metadata29':q['runtime_binding']['sdk_metadata_artifact'],'host_identities':{'captured':{'artifact':raw_ref,'pid_pointer':'/pid','ctime_pointer':'/actual_psutil_create_time','executable_pointer':'/actual_executable'},'attached':{'artifact':save,'pid_pointer':'/observation_after/pid','ctime_pointer':'/observation_after/process_create_time','executable_pointer':'/observation_after/executable','connection_generation_pointer':'/snapshot_after/diagnostics/connection_generation'}}}
 provenance={'original_HANDLE_capture':captured_ref,'captured_raw_host_observation':raw_ref,'captured_actual_launch':captured['actual_launch'],'attached_SAVE_original':save,'reason':'CAPTURED has no executable field; its exact referenced independent raw identity observation supplies the actual executable, bound to captured PID/ctime/rawFILETIME and original launch. No pointer or observation is invented.','body_reads':0,'SDK_process_bus_calls':0}
 return config,provenance
def main():
 global CLIENT,QUEUE,CAPTURED,SEED,SEED_SHA,SAVE_STEM,CACHE_STEM
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--mode',choices=('cache','D0'),required=True);p.add_argument('--author-result',type=Path,required=True);p.add_argument('--cache-result',type=Path);p.add_argument('--output',type=Path,required=True);p.add_argument('--client-output',type=Path,required=True);p.add_argument('--queue-root',type=Path,required=True);p.add_argument('--captured-handle',type=Path,required=True);p.add_argument('--signed-input',type=Path,required=True);p.add_argument('--signed-input-sha256',required=True);p.add_argument('--save-stem',required=True);p.add_argument('--cache-stem',required=True);a=p.parse_args()
 CLIENT=a.client_output.resolve();QUEUE=a.queue_root.resolve();CAPTURED=a.captured_handle.resolve();SEED=a.signed_input.resolve();SEED_SHA=a.signed_input_sha256;SAVE_STEM=a.save_stem;CACHE_STEM=a.cache_stem
 need(CLIENT==RUN/'persistent-client-001' and QUEUE.parent==RUN and CAPTURED.is_relative_to(RUN),'actual sole current Client/ROOT queue/captured HANDLE paths required')
 need(all(type(stem)is str and stem.startswith('0') and '-r31-'in stem and Path(stem).name==stem and '/'not in stem and '\\'not in stem for stem in (SAVE_STEM,CACHE_STEM)),'actual current-run retained SAVE/cache stems required')
 seed=read(ref(SEED));need(ref(SEED)['sha256']==SEED_SHA and seed['checkpoint']['sha256']=='c8601e7ba08406a551dcddd2a19e454423db2be6b559fad9985c6d1121b537c9' and seed['new_cold_validation'] is None and seed['formal_acceptance'] is None,'only exact historical signed B3 input; current credit NULL')
 need(source_ref(CACHE)['sha256']==CACHE_SHA,'Actual frozen cache comparator source changed')
 pins=json.loads((Path(__file__).parent/'SOURCE-REFS.json').read_bytes());need(source_ref(D0)==pins['D0_comparer'],'Actual existing SOURCE004 D0 comparer changed')
 out=a.output.resolve();need(out.is_relative_to(RUN) and not out.exists(),'Fresh explicit ROOT output under actual RUN31 required')
 if a.mode=='cache':
  need(a.cache_result is None,'Cache result not yet consumed in cache-input mode');config,provenance=cache_inputs(a.author_result);out.mkdir()
  put(out/'CACHE-COMPARATOR.INPUT.actual.json',config);put(out/'CAPTURED-ATTACHED-HOST-BINDING.actual.json',provenance)
  argv=[PY,'-B','-X','utf8',CACHE.as_posix(),'--input',(out/'CACHE-COMPARATOR.INPUT.actual.json').as_posix(),'--input-sha256',ref(out/'CACHE-COMPARATOR.INPUT.actual.json')['sha256'],'--output',(out/'cache-comparison-001').as_posix()]
  put(out/'ROOT-CACHE-COMPARATOR.ARGV.unexecuted.json',{'argv':argv,'executed':False,'formal_acceptance':None})
 else:
  need(a.cache_result is not None,'Actual cache comparison result required; future NULL rejected');desc,author,state,typed,qualified,q=actual_tuple(a.author_result);cr=ref(a.cache_result);c=read(cr)
  need(c.get('native_to_saved_equality') is True and c['input_artifacts']['author_result']==desc and c['input_artifacts']['state']==state and c['input_artifacts']['qualified_native']==qualified,'Actual same-D0 authenticated cache match required')
  seed=ref(SEED);need(seed['sha256']==SEED_SHA,'ROOT actual signed seed input changed')
  config={'signed_B3_input':seed,'new_cold_author_result':desc,'new_cold_state':state,'new_cold_typed_protection':typed,'new_cold_qualified_native':qualified,'new_cold_cache_result':cr};out.mkdir();put(out/'D0-COMPARISON.INPUT.actual.json',config)
  argv=[PY,'-B','-X','utf8',D0.as_posix(),'--inputs',(out/'D0-COMPARISON.INPUT.actual.json').as_posix(),'--sha256',ref(out/'D0-COMPARISON.INPUT.actual.json')['sha256'],'--output',(out/'D0-comparison-001').as_posix()]
  put(out/'ROOT-D0-COMPARISON.ARGV.unexecuted.json',{'argv':argv,'executed':False,'formal_acceptance':None})
 print(json.dumps({'mode':a.mode,'output':out.as_posix(),'argv':argv,'body_reads':0,'comparators_executed':False}));return 0
if __name__=='__main__':raise SystemExit(main())
