"""Dedicated actual R29 signed-B3 intake. Reads existing JSON only, never .ck3."""
from pathlib import Path
import hashlib
import json
import re

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve()
SAVE_SHA='c8601e7ba08406a551dcddd2a19e454423db2be6b559fad9985c6d1121b537c9'
SAVE_BYTES=91709349
SCHEMA='lyd.signed-B3-diagnostic-cold-input.v1'
PURPOSE='SIGNED_B3_STAGED_FACTORY_DIAGNOSTIC_ONLY'
PRIOR_HEAD='487da05f6c1cf231490fd1fe480ccc704ed0a80f'
SEED_DIRECTORY=BASE/'live-attempt-029/B3-r3-signed-author-001'
SEED_PATH=BASE/'live-attempt-029/checkpoints/B3-signed-precommit-r3-signed/checkpoint.ck3'
FIELDS={'schema','purpose','checkpoint','capture','materializer_input','author_input','author_result','state','typed_protection','formal_qualification','qualified_native','provenance','original0240_control','prior_source_head','historical_formal_credit','new_cold_validation','formal_acceptance'}

def need(ok,message):
    if not ok:raise ValueError(message)

def read_ref(row):
    need(type(row)is dict and set(row)=={'path','bytes','sha256'},'Exact existing JSON ref3 required')
    need(type(row['bytes'])is int and 0<row['bytes']<=16*1024*1024,'Bounded actual JSON size required')
    need(type(row['sha256'])is str and re.fullmatch('[0-9a-f]{64}',row['sha256']),'Exact JSON SHA required')
    path=Path(row['path']).resolve()
    need(path.is_relative_to(BASE) and path.suffix.lower()=='.json','Only existing external JSON is read')
    raw=path.read_bytes()
    need(len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],'Existing JSON bytes/SHA changed: '+str(path))
    return json.loads(raw)

def full_id(value,label):
    need(type(value) is int or type(value)is str and re.fullmatch('[1-9][0-9]*',value),'Actual positive decimal full ID required: '+label)
    number=int(value)
    need(0<number<4294967295,'Actual positive uint32 full ID required: '+label)
    return number

def actor_successors(state):
    actor=state['actor'];need(actor['character_id']==31254,'Exact saved actor required')
    rows=actor['landed_data']
    need(type(rows)is list,'Complete saved landed_data required')
    raw=[r['value'] for r in actor['entries'] if r.get('key')=='landed_data']
    need(len(raw)==1 and raw[0]==rows,'Actor landed_data must equal original full saved AST projection')
    caches=[r['value'] for r in rows if r.get('key')=='succession']
    need(len(caches)==1 and type(caches[0])is list,'Single complete ordered saved succession array required')
    return [full_id(r['value'],'successor') for r in caches[0] if need(r.get('key')is None,'Saved successor token shape differs') is None]

def political_projection(state):
    out={}
    for title in state['protected_titles']:
        tid=full_id(title['title_id'],'title')
        need(tid not in out,'Unique protected political title required')
        heirs=[r['value'] for r in title['entries'] if r.get('key')=='heir']
        need(len(heirs)<=1,'Unique saved political heir field required')
        out[str(tid)]={'holder':full_id(title['holder'],'holder'),'full_AST_sha256':title['AST_sha256'],'heir_AST':heirs[0] if heirs else None}
    need(set(out)=={'2230','2231','2232','2235','2262','2263','2264'},'All original seven political Titles required')
    return out

def validate_packet(packet):
    need(type(packet)is dict and set(packet)==FIELDS and packet['schema']==SCHEMA and packet['purpose']==PURPOSE,'Dedicated signed-B3 diagnostic input required')
    checkpoint=packet['checkpoint']
    need(checkpoint=={'path':SEED_PATH.as_posix(),'bytes':SAVE_BYTES,'sha256':SAVE_SHA},'Only original immutable R29 R3 B3 is a legal seed; B4/B5 refused')
    need(SEED_PATH.stat().st_size==SAVE_BYTES,'Existing exact-size original B3 capture copy required; body is not read')
    need(packet['prior_source_head']==PRIOR_HEAD and packet['historical_formal_credit']is True and packet['new_cold_validation']is None and packet['formal_acceptance']is None,'Historical signed mandate is input; new cold/formal credit stays NULL')
    values={k:read_ref(packet[k]) for k in ('capture','materializer_input','author_input','author_result','state','typed_protection','formal_qualification','qualified_native','provenance','original0240_control')}
    capture,inputs,request,result,state,typed,formal,qualified,provenance,control=(values[k] for k in ('capture','materializer_input','author_input','author_result','state','typed_protection','formal_qualification','qualified_native','provenance','original0240_control'))
    need(capture['schema']=='lyd.r29.root-preserved-formal-capture.v1' and capture['window']=='B3-signed-precommit' and capture['actual_immutable_copy']==checkpoint and capture['inputs']==packet['materializer_input'] and capture['exact_copy_stream_passes']==1,'Original B3 capture/input binding required')
    need(inputs['window']==request['window']=='B3-signed-precommit' and inputs['preserved_checkpoint']==request['preserved_checkpoint']==checkpoint,'Actual signed B3 request/window required')
    need(result['status']=='ACTUAL_COMPACT_NATIVE_SAVED_OBSERVATIONS_JOINED' and result['save_body_reads']==1 and result['actual_pass']is None,'Original one-body compact B3 result required')
    for key in ('author_input','state','typed_protection','formal_qualification','qualified_native','provenance'):
        need(packet[key] in result['outputs'],'Original RESULT must inventory '+key)
    need(state['schema']=='lyd.i3b.checkpoint-observations.v1' and state['stage']=='signed_precommit' and state['checkpoint_sha256']==SAVE_SHA,'Only actual signed precommit saved STATE required')
    need(state['round']==formal['actual_round']=={'serial':3,'nonce':6,'phase':2,'result_code':None},'Actual R3 signed S3/N6/P2 required')
    identity=state['identity']
    need(identity==typed['identity']==formal['identity'] and (identity['actor_id'],identity['faith_id'],identity['main_rite_id'])==(31254,107,169),'Actual seed actor/Faith/mainRite identity differs')
    need(typed['checkpoint_sha256']==SAVE_SHA and typed['protection_checks_match']is True and len(typed['checks'])==87 and all(x['matches']is True for x in typed['checks']),'All original 87 protections must match; no relaxation')
    need(typed['actual_added_religious_title']is None,'Pre-factory seed may not contain new religious Title')
    need(formal['schema']=='lyd.r17.independent-native-formal-qualification.v1' and formal['window']=='B3-signed-precommit' and formal['source_head']==PRIOR_HEAD and formal['actual_checkpoint_sha256']==SAVE_SHA and formal['qualification_status']=='FORMAL_NATIVE_CALLBACK_SAVED_MANDATE_PASS' and formal['qualification_pass']is True and formal['formal_mandate_credit']is True and formal['whole_product_pass']is None and not formal['missing_actual_observations'],'Original independently qualified B3 mandate required; no whole-product credit')
    need(request['expected_source_head']==provenance['source_head']==PRIOR_HEAD and provenance['game_pid']==identity['pid'] and provenance['session_id']==identity['session_id'],'Historical B3 source/session provenance differs')
    need(qualified['schema']=='lyd.sdk-checkpoint-qualified-native.v3' and qualified['G2_status']=='BOUND_COMPLETE_NATIVE_OBSERVATION','Historical complete actual native join required')
    retained=formal['retained_source_artifacts']
    for key,name in [('author_input','author_input'),('state','initial_state'),('typed_protection','typed_protection'),('qualified_native','qualified_native'),('provenance','provenance')]:
        need(retained[name]==packet[key],'Original formal certificate retained '+key+' binding differs')
    need(capture['original0240_control']==packet['original0240_control'] and control['schema']=='lyd.r29.original0240-baseline-control.v1','Original0240 control remains a historical input')
    seed_cache=actor_successors(state)
    need(len(seed_cache)==45,'Actual signed seed must retain all 45 ordered actor successor IDs')
    political_projection(state)
    return packet

def load_packet(row):
    return validate_packet(read_ref(row))

def verify_baseline(item,helper):
    need(type(item)is dict and set(item)=={'path','bytes','sha256','original0240_source'},'Existing cold baseline reference shape required')
    packet=load_packet(item['original0240_source'])
    need({k:item[k] for k in ('path','bytes','sha256')}==packet['checkpoint'],'Cold copy descriptor must equal the one legal B3 seed')
    baseline={**packet['checkpoint'],'check_only_save_hash':'ACTUAL_B3_CAPTURE_AND_FORMAL_JSON_ONLY_EXACT_COPY_SHA_REQUIRED_AT_CREATE'}
    proof={k:packet[k] for k in ('capture','author_result','state','typed_protection','formal_qualification','qualified_native','original0240_control')}
    proof.update(baseline_purpose=PURPOSE,signed_B3_source=item['original0240_source'],historical_formal_credit=True,new_cold_validation=None,formal_acceptance=None)
    return baseline,proof
