from pathlib import Path
import ast, hashlib, json, shutil
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
HERE=Path(__file__).resolve().parent
OLD=B/'r30-D0-comparison-input-author-sourceonly-20261008-001'
BOOT=B/'r31-root-bootstrap-sourceonly-20261008-003'
CACHE=B/'r31-root-cache-comparator-bound-source-20261008-001'
HEAD='06159b964d859d30f2f07f4b183284df7d6dac47'
def ref(p):
 p=Path(p).resolve();raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def put(p,d):
 with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
assert ref(CACHE/'INDEX.json')['sha256']=='5f8738739a6a2a21d26550ac1394982b3d0f4a5743b2ad9f8399094dc7906f1d'
ci=json.loads((CACHE/'INDEX.json').read_bytes());assert ci['source_head']==HEAD
assert ref(BOOT/'INDEX.json')['sha256']=='5c5a7a2bd584aafb9ae40db98efea511839298bc7488df8aae9f0bbbd62a35fc'
parent=OLD/'author_D0_comparison_inputs.py';raw=parent.read_text(encoding='utf-8');lines=raw.splitlines(keepends=True);offset=[0]
for line in lines:offset.append(offset[-1]+len(line))
tree=ast.parse(raw);edits=[]
assignments={'RUN':"B/'live-attempt-031'",'HEAD':repr(HEAD),'CACHE':'Path('+repr(ci['comparator']['path'])+')','CACHE_SHA':repr(ci['comparator']['sha256']),'D0':"Path(__file__).parent/'compare_signed_B3_cold_D0.py'",'SEED':'None','SEED_SHA':'None','SAVE_STEM':'None','CACHE_STEM':'None'}
for name,new in assignments.items():
 nodes=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name)and t.id==name for t in n.targets)]
 assert len(nodes)==1,name
 n=nodes[0].value;edits.append((offset[n.lineno-1]+n.col_offset,offset[n.end_lineno-1]+n.end_col_offset,new))
for start,end,new in sorted(edits,reverse=True):raw=raw[:start]+new+raw[end:]
def once(old,new):
 global raw
 assert raw.count(old)==1,old
 raw=raw.replace(old,new,1)
once("(RUN/'official-mcp-queue-002').resolve()",'QUEUE')
once("ref(RUN/'game-original-handle-holder-001/CAPTURED.actual.json')",'ref(CAPTURED)')
once('def main():\n', 'def main():\n global CLIENT,QUEUE,CAPTURED,SEED,SEED_SHA,SAVE_STEM,CACHE_STEM\n')
once("a=p.parse_args()", "p.add_argument('--client-output',type=Path,required=True);p.add_argument('--queue-root',type=Path,required=True);p.add_argument('--captured-handle',type=Path,required=True);p.add_argument('--signed-input',type=Path,required=True);p.add_argument('--signed-input-sha256',required=True);p.add_argument('--save-stem',required=True);p.add_argument('--cache-stem',required=True);a=p.parse_args()\n CLIENT=a.client_output.resolve();QUEUE=a.queue_root.resolve();CAPTURED=a.captured_handle.resolve();SEED=a.signed_input.resolve();SEED_SHA=a.signed_input_sha256;SAVE_STEM=a.save_stem;CACHE_STEM=a.cache_stem\n need(CLIENT==RUN/'persistent-client-001' and QUEUE.parent==RUN and CAPTURED.is_relative_to(RUN),'actual sole current Client/ROOT queue/captured HANDLE paths required')\n need(all(type(stem)is str and stem.startswith('0') and '-r31-'in stem and Path(stem).name==stem and '/'not in stem and '\\\\'not in stem for stem in (SAVE_STEM,CACHE_STEM)),'actual current-run retained SAVE/cache stems required')\n seed=read(ref(SEED));need(ref(SEED)['sha256']==SEED_SHA and seed['checkpoint']['sha256']=='c8601e7ba08406a551dcddd2a19e454423db2be6b559fad9985c6d1121b537c9' and seed['new_cold_validation'] is None and seed['formal_acceptance'] is None,'only exact historical signed B3 input; current credit NULL')")
raw=raw.replace('Actual fa0 complete same-frame','Actual current R31 complete same-frame').replace('actual RUN30 required','actual RUN31 required')
ast.parse(raw)
(HERE/'author_D0_comparison_inputs.py').write_text(raw,encoding='utf-8',newline='\n')
comparer=B/'r30-signed-B3-diagnostic-runtime-sourceonly-20261008-004/compare_signed_B3_cold_D0.py'
assert ref(comparer)['sha256']=='4420fcab0935e3e007d8bb2a9fe56454abe2e2fd69f81092ca11ef8f4bdcd0ea'
shutil.copyfile(comparer,HERE/comparer.name)
adapter=BOOT/'signed_B3_diagnostic_baseline_adapter.py';shutil.copyfile(adapter,HERE/adapter.name)
put(HERE/'SOURCE-REFS.json',{'D0_comparer':ref(HERE/comparer.name),'cache_comparator':ci['comparator']})
with(HERE/'ROOT-CLI.md').open('x',encoding='utf-8',newline='\n')as f:
 f.write('''R31 retained D0 input author; both comparators remain ROOT-executed.
<PY> -B -X utf8 <HERE>/author_D0_comparison_inputs.py --mode cache --author-result <RUN>/D0-diagnostic-author-001/RESULT.json --client-output <RUN>/persistent-client-001 --queue-root <actual ROOT queue under RUN> --captured-handle <actual current CAPTURED.actual.json> --signed-input <actual signed-intake JSON> --signed-input-sha256 <actual SHA> --save-stem <actual SAVE stem> --cache-stem <actual after-cache stem> --output <fresh RUN D0-cache-input directory>
Run the emitted ROOT-CACHE-COMPARATOR.ARGV.unexecuted.json exactly once. Only after its actual result exists:
<PY> -B -X utf8 <HERE>/author_D0_comparison_inputs.py --mode D0 --author-result <same D0 RESULT.json> --cache-result <actual cache-comparison-001/RESULT.actual.json> --client-output <same actual Client> --queue-root <same ROOT queue> --captured-handle <same current CAPTURED> --signed-input <same actual signed-intake> --signed-input-sha256 <actual SHA> --save-stem <same actual SAVE stem> --cache-stem <same actual after-cache stem> --output <fresh RUN D0-six-ref-input directory>
Run the emitted ROOT-D0-COMPARISON.ARGV.unexecuted.json once. It requires all87, actor45 ordered equality, seven political fullAST and same actual cache-native frame. Historical R29 formal credit remains only input; current formal acceptance NULL. Original cache request schema lyd.r30.actor-cache-saved-JSON-equality-request.v1 is deliberately retained because unchanged comparator functions require that exact schema. HEAD, module paths and native tuple are current R31; no old runtime fact is copied. This author reads compact retained JSON only and never .ck3 or SDK/OS/bus. SAVE/cache stems are required actual parameters, not predicted ordinals.
''')
put(HERE/'INDEX.json',{'status':'SOURCE_READY_ACTUAL_D0_OUTPUTS_PENDING','source_head':HEAD,'author':ref(HERE/'author_D0_comparison_inputs.py'),'parent_author':ref(parent),'source_refs':ref(HERE/'SOURCE-REFS.json'),'D0_comparer':ref(HERE/comparer.name),'signed_seed_adapter':ref(HERE/adapter.name),'adapter_parent':ref(adapter),'cache_source_index':ref(CACHE/'INDEX.json'),'bootstrap_source_index':ref(BOOT/'INDEX.json'),'ROOT_CLI':ref(HERE/'ROOT-CLI.md'),'future_D0_SAVE_G2_G3_cache_FRAME_PID_session_credit':None,'source_AST_checks':1,'SDK_process_bus_body_MAIN_test_calls':0})
print(json.dumps({'INDEX':ref(HERE/'INDEX.json'),'author':ref(HERE/'author_D0_comparison_inputs.py'),'CLI':ref(HERE/'ROOT-CLI.md')},indent=2))
