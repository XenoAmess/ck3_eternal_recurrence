"""Read retained new-cold JSON and cache equality result; emit D0 diagnosis only."""
from pathlib import Path
import argparse,json,hashlib
from signed_B3_diagnostic_baseline_adapter import read_ref,load_packet,actor_successors,political_projection,need

def ref(p):
    p=Path(p).resolve();raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--inputs',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    stamp=ref(a.inputs);need(stamp['sha256']==a.sha256.lower(),'Actual D0 input SHA changed')
    d=json.loads(a.inputs.read_bytes());need(set(d)=={'signed_B3_input','new_cold_author_result','new_cold_state','new_cold_typed_protection','new_cold_qualified_native','new_cold_cache_result'},'Actual D0 JSON inputs required; future NULL rejected')
    seed=load_packet(d['signed_B3_input']);before=read_ref(seed['state'])
    author=read_ref(d['new_cold_author_result']);state=read_ref(d['new_cold_state']);typed=read_ref(d['new_cold_typed_protection']);qualified=read_ref(d['new_cold_qualified_native']);cache=read_ref(d['new_cold_cache_result'])
    for key in ('new_cold_state','new_cold_typed_protection','new_cold_qualified_native'):need(d[key]in author['outputs'],'Actual new cold author must inventory '+key)
    need(author['save_body_reads']==1 and qualified['G2_status']=='BOUND_COMPLETE_NATIVE_OBSERVATION','One new cold body and complete actual same-frame join required')
    rb=qualified['runtime_binding'];need(rb['source_head']!=seed['prior_source_head'] and rb['game_pid']==state['identity']['pid'] and rb['session_id']==state['identity']['session_id'],'Fresh qualified cold identity required, historical identity cannot substitute')
    ids=actor_successors(state);old_ids=actor_successors(before);titles=political_projection(state);old_titles=political_projection(before)
    changed=[tid for tid in old_titles if titles[tid]!=old_titles[tid]]
    protected=typed['protection_checks_match']is True and len(typed['checks'])==87 and all(x['matches']is True for x in typed['checks'])
    cache_true=cache.get('native_to_saved_equality')is True and cache.get('saved_count')==cache.get('native_count')==45 and cache.get('complete_saved_successor_ids_in_original_order')==cache.get('complete_native_successor_ids_in_original_order')==ids
    need(cache.get('source_head')==rb['source_head'],'Cache comparator source must match exact new qualified cold HEAD')
    need(cache.get('input_artifacts',{}).get('state')==d['new_cold_state'] and cache.get('input_artifacts',{}).get('qualified_native')==d['new_cold_qualified_native'],'Cache result must authenticate this exact new cold STATE and native frame')
    conditions={'actor_45_ordered_ids_match_seed':len(ids)==45 and ids==old_ids,'seven_political_full_AST_holder_heir_match_seed':not changed,'original87_protection_checks_true':protected,'cache_native_saved_same_after_frame_equal_45':cache_true,'signed_seed_round_preserved':state['round']==before['round'],'no_new_title_before_stage':typed['actual_added_religious_title']is None}
    passed=all(conditions.values())
    report={'status':'ACTUAL_DIAGNOSTIC_D0_BASELINE_MATCH' if passed else 'ACTUAL_DIAGNOSTIC_D0_BASELINE_RED','stage_advance_allowed':passed,'conditions':conditions,'changed_political_title_ids':changed,'actor_successor_before':old_ids,'actor_successor_cold':ids,'before_political':old_titles,'cold_political':titles,'cold_frame':cache.get('after_save_binding'),'inputs':d,'historical_R29_formal_credit':True,'new_formal_acceptance':None,'wholemod_GREEN':False,'factory_cause_inferred':False,'body_reads_by_comparator':0,'SDK_game_process_bus_calls':0}
    a.output.mkdir(parents=True,exist_ok=False)
    with (a.output/'RESULT.actual.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'result':ref(a.output/'RESULT.actual.json'),'status':report['status'],'stage_advance_allowed':passed}))
    return 0 if passed else 1

if __name__=='__main__':raise SystemExit(main())
