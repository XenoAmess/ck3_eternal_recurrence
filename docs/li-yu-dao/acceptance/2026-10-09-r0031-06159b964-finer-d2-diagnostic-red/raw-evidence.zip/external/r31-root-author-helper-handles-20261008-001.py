from pathlib import Path
import hashlib
import json
import psutil
B = Path('C:/workspace/ck3_lyd_runtime_20261004')
RUN = B/'live-attempt-031'
CORE = B/'r31-root-actual-runtime-source-20261008-001/core'
CONSUMER = B/'r31-root-actual-consumer-source-20261008-001'
def ref(path):
    path = Path(path).resolve()
    return {'path':path.as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
session = json.loads((RUN/'persistent-client-001/session.json').read_bytes())
attached = json.loads((RUN/'ROOT-ATTACHED-BINDING.actual.json').read_bytes())
capture = json.loads((RUN/'game-original-handle-holder-001/CAPTURED.actual.json').read_bytes())
rows = {}
for role, source in [('client',CONSUMER/'persistent_native_mcp_queue_29.py'),('keeper',CORE/'screen_lease_entry_r0031.py')]:
    matches = []
    for process in psutil.process_iter(['pid','exe','create_time','cmdline']):
        info = process.info
        if any(str(arg).replace('\\','/').lower() == source.as_posix().lower() for arg in (info['cmdline'] or [])):
            matches.append(info)
    assert len(matches) == 1, (role, len(matches))
    row = matches[0]
    rows[role] = {'pid':row['pid'],'create_time':row['create_time'],'exe':row['exe'],'cmdline':row['cmdline']}
    if role == 'client': rows[role]['source'] = ref(source)
    else: rows[role]['READY.json'] = ref(B/'r31-root-screen-keeper-20261008-001/READY.json')
request = {'processes':rows,'client_session':ref(RUN/'persistent-client-001/session.json'),'attach_native_receipt':attached['attach_native'],'client_session_id':session['client_session_id'],'native_session_id':attached['native_session_id'],'source_revision':session['source_revision'],'epoch_id':session['epoch_id'],'screen_task':'lyd-r0031-06159-finer-D2-root','game_original_handle_owner':{'holder_pid':capture['holder_pid'],'capture':ref(RUN/'game-original-handle-holder-001/CAPTURED.actual.json')}}
out = B/'r31-root-helper-handle-inputs-20261008-001'
out.mkdir(exist_ok=False)
path = out/'REQUEST.actual.json'
with path.open('x',encoding='utf-8',newline='\n') as f: f.write(json.dumps(request,ensure_ascii=False,indent=2)+'\n')
argv = ['C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe','-B','-X','utf8',(CORE/'retain_helper_handles.py').as_posix(),'hold','--request',path.as_posix(),'--sha256',ref(path)['sha256'],'--output',(RUN/'helper-original-handle-holder-001').as_posix()]
with (out/'ARGV.actual.json').open('x',encoding='utf-8',newline='\n') as f: f.write(json.dumps({'argv':argv,'cwd':'C:/workspace/ck3_eternal_recurrence'},indent=2)+'\n')
print(json.dumps({'request':ref(path),'argv':ref(out/'ARGV.actual.json'),'actual_helper_PIDs':{k:v['pid'] for k,v in rows.items()}}))
