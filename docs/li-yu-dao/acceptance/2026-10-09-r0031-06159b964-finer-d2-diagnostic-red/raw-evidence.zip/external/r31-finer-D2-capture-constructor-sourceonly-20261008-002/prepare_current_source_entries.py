"""Source-only finite R30->R31 projection; no constructors/body/runtime executed."""
from pathlib import Path
import ast,hashlib,json
B=Path('C:/workspace/ck3_lyd_runtime_20261004');H=Path(__file__).parent
HEAD='06159b964d859d30f2f07f4b183284df7d6dac47'
OLD='fa0f5e1ee098ab6fab4635bedce939eab857610a'
CP=B/'r30-checkpoint-author-sourceonly-20261008-001';CAP=B/'r30-formal-capture-root-sourceonly-20261008-001';THIN=B/'r30-baseline-capture-specification-sourceonly-20261008-001'
def ref(p):
 r=p.read_bytes();return {'path':p.resolve().as_posix(),'bytes':len(r),'sha256':hashlib.sha256(r).hexdigest()}
def put(p,v):
 with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def save(p,s):
 ast.parse(s)
 with p.open('x',encoding='utf-8',newline='\n')as f:f.write(s)
def once(s,old,new):
 assert s.count(old)==1,(old,s.count(old));return s.replace(old,new,1)
parent=B/'r30-diagnostic-cp-cap-constructor-sourceonly-20261008-002/project_r30_cp_cap_static.py'
source=parent.read_text(encoding='utf-8');tree=ast.parse(source)
cpmap={'r29-checkpoint-author-sourceonly-20261008-002':CP.name,'r29-formal-capture-root-sourceonly-20261008-003':CAP.name,'r29-baseline-capture-specification-sourceonly-20261008-002':THIN.name,
 '487da05f6c1cf231490fd1fe480ccc704ed0a80f':OLD,OLD:HEAD,
 '1d5b5511e5ef91a8d0c6aba9e012c1b5b3dfe8b9dd4d7064c6a48d853c7db5ea':ref(CP/'INDEX.json')['sha256'],
 '86a51a5b97b19f57d0a34e32298256d134ff19c07aec45a17d08e9cb675f0d09':ref(CAP/'INDEX.json')['sha256'],
 'C:/lr29s2':'C:/lr30s2','C:/lr29s2/tools/lyd_i3b_checkpoint_readback/reader/sdk_checkpoint_qualification.py':'C:/lr30s2/tools/lyd_i3b_checkpoint_readback/reader/sdk_checkpoint_qualification.py',
 'live-attempt-029':'live-attempt-030','live-attempt-030':'live-attempt-031','R0029':'R0030','R0030':'R0031','--li-yu-dao--R0030':'--li-yu-dao--R0031',
 'lyd.r29.':'lyd.r30.','lyd.r30.':'lyd.r31.','r29_':'r30_','r30_':'r31_','r29-':'r30-','r30-':'r31-',
 'R29':'R30','R30':'R31','r29-root-actual-formal-registry-author.py':'r30-root-actual-formal-registry-author.py','r30-root-actual-formal-registry-author.py':'r31-root-actual-formal-registry-author.py'}
def cpvalue(s):
 if s in cpmap:return cpmap[s]
 if s.startswith('r29-checkpoint-author-sourceonly-20261008-'):return s.replace('r29-','r30-',1)
 if s.startswith('r29-formal-capture-root-sourceonly-20261008-'):return s.replace('r29-','r30-',1)
 if s.startswith('r29-baseline-capture-specification-sourceonly-20261008-'):return s.replace('r29-','r30-',1)
 if s.startswith('lyd.r30.'):return s.replace('lyd.r30.','lyd.r31.',1)
 if 'R0030' in s:return s.replace('R0030','R0031')
 if 'R30' in s:return s.replace('R30','R31')
 return s
# Replace source literals in place so its textual projection seams and all
# qualification functions retain original formatting/structure.
edits=[]
lines=source.splitlines(keepends=True);offset=[0]
for l in lines:offset.append(offset[-1]+len(l))
count30=0
for n in ast.walk(tree):
 if isinstance(n,ast.Constant) and (type(n.value)is str or type(n.value)is int and n.value==30):
  value=cpvalue(n.value) if type(n.value)is str else 31
  if type(n.value)is int:count30+=1
  if value!=n.value:edits.append((offset[n.lineno-1]+n.col_offset,offset[n.end_lineno-1]+n.end_col_offset,repr(value)))
assert count30==1,'one exact current allocation sequence guard'
for a,b,new in sorted(edits,reverse=True):source=source[:a]+new+source[b:]
save(H/'project_r31_cp_cap_static.py',source)
put(H/'CP-CAP-SOURCE-REQUEST.pending.json',{'schema':'lyd.root.next-cp-cap-source-request.v1','expected_head':HEAD,**{k:None for k in ('allocation_receipt','production_manifest','run_directory','checkpoint_output','capture_output','baseline_specification_output')},'source_export_report':{'path':(B/'r31-root-clean-export-20261008-001/REPORT.json').as_posix(),'bytes':35463,'sha256':'ba6a5fd88967c41909043f68d377e2e22d8c03fa21b3332e383d9a992ccdfc14'},'canonical_source_index':{'path':(B/'r31-root-canonical-source-20261008-002/INDEX.json').as_posix(),'bytes':22402,'sha256':'f2d7f625a692a3272ebbbd0df58a3be95b2e1b8be1192078336be2479f801ec9'},'previous_boundary':{'path':(B/'r30-root-actual-typed-closed-boundary-20261008-001/PREVIOUS-BOUNDARY.actual.json').as_posix(),'bytes':3103,'sha256':'2944ee5104746377a738ae5c1d625846cdb9bb9691ac5e4ca6504e4162b938da'},'previous_boundary_verifier':{'path':(B/'r30-root-typed-close-actual-source-20261008-001/verify_previous_boundary.py').as_posix(),'bytes':24731,'sha256':'6239df5be60613f9b39e88ef905880b4652ecd19e5a58c53497d5289af16c510'}})
parent_D0=B/'r30-diagnostic-cp-cap-constructor-sourceonly-20261008-004/materialize_D0_source.py';s=parent_D0.read_text(encoding='utf-8')
s=s.replace('lyd.r30.','lyd.r31.').replace('live-attempt-030','live-attempt-031').replace('R30','R31').replace('r30-root-signed-B3-input.actual.json','r31-root-signed-B3-input.actual.json')
s=once(s,"HEAD='"+OLD+"'","HEAD=None\nACTUAL_HEAD='"+HEAD+"'")
s=once(s,'def main():\n p=argparse.ArgumentParser', 'def main():\n global HEAD,RUN,SIGNED_INPUT,SIGNED_INPUT_SHA\n p=argparse.ArgumentParser')
s=once(s," p.add_argument('--checkpoint-source',type=Path,required=True);", " p.add_argument('--expected-head',required=True);p.add_argument('--run-directory',type=Path,required=True);p.add_argument('--signed-input',type=Path,required=True);p.add_argument('--signed-input-sha256',required=True)\n p.add_argument('--checkpoint-source',type=Path,required=True);")
s=once(s," C=a.checkpoint_source.resolve();K=a.capture_source.resolve();O=a.output.resolve()", " HEAD=a.expected_head;RUN=a.run_directory.resolve();SIGNED_INPUT=a.signed_input.resolve();SIGNED_INPUT_SHA=a.signed_input_sha256\n need(HEAD==ACTUAL_HEAD and RUN==B/'live-attempt-031','actual R31 source/run required')\n seed=read(SIGNED_INPUT);need(seed['checkpoint']['sha256']=='c8601e7ba08406a551dcddd2a19e454423db2be6b559fad9985c6d1121b537c9' and seed['checkpoint']['bytes']==91709349 and seed['new_cold_validation'] is None and seed['formal_acceptance'] is None,'only immutable R29 signed B3 input; no R30 failed T credit')\n C=a.checkpoint_source.resolve();K=a.capture_source.resolve();O=a.output.resolve()")
save(H/'materialize_D0_source.py',s)
put(H/'FUNCTION-PARENT-REFS.json',{'CP_CAP':ref(parent),'D0':ref(parent_D0),'cache_comparator':ref(B/'r30-root-cache-comparator-bound-source-20261008-002/compare_actor_cached_succession.py'),'cache_contract':ref(B/'r30-root-cache-comparator-bound-source-20261008-002/SOURCE-CONTRACT.json'),'finer_D2_constructor':ref(B/'r31-finer-D2-capture-constructor-sourceonly-20261008-001/materialize_finer_D2_source.py')})
print(json.dumps({'CP_CAP_constructor':ref(H/'project_r31_cp_cap_static.py'),'D0_constructor':ref(H/'materialize_D0_source.py'),'actual_source_HEAD':HEAD,'native_metadata_allocation_runtime_results':None}))
