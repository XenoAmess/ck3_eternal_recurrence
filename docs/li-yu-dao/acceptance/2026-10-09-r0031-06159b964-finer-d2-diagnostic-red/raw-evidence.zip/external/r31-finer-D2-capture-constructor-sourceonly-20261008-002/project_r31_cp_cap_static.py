"""ROOT file-only CP/CAP projection after R29; all actual static inputs are mandatory."""
from pathlib import Path
import argparse,ast,hashlib,json,re,shutil,sys
sys.dont_write_bytecode=True
B=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve();HERE=Path(__file__).resolve().parent
P=B/'r30-checkpoint-author-sourceonly-20261008-001';PK=B/'r30-formal-capture-root-sourceonly-20261008-001';PT=B/'r30-baseline-capture-specification-sourceonly-20261008-001'
OLD_HEAD='fa0f5e1ee098ab6fab4635bedce939eab857610a'
INVERSE_SHA='e8e4c79d6328b4ba5d9641968d1605e93ebc98d0637f2d439101142efa0bad13';TABLE_SHA='405b9ba3b569727b66c65a9e249c307a1bf0273455233b08c539bacf5dff4519'
KEYS={'schema','expected_head','allocation_receipt','source_export_report','production_manifest','canonical_source_index','previous_boundary','previous_boundary_verifier','run_directory','checkpoint_output','capture_output','baseline_specification_output'}
def need(ok,message):
 if not ok:raise ValueError(message)
def ref(p):
 p=Path(p).resolve();need(p.is_file()and p.suffix.lower()!='.ck3'and 0<p.stat().st_size<=8*1024*1024,'bounded source/JSON only; no save body');raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def checked(row):
 need(type(row)is dict and set(row)=={'path','bytes','sha256'},'complete actual ref3 mandatory; NULL rejected');need(ref(row['path'])==row,'actual source/JSON bytes differ');return Path(row['path']).resolve()
def read(p):return json.loads(Path(p).read_bytes())
def put(p,value):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf-8',newline='\n')as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def write(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def text(p,raw):p.write_text(raw,encoding='utf-8',newline='\n')
def replace_pin(p,prior,new,required=True):
 raw=p.read_text(encoding='utf-8');need(not required or prior in raw,'exact declared pin missing '+p.name);text(p,raw.replace(prior,new))
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--request',type=Path,required=True);a.add_argument('--sha256',required=True);args=a.parse_args()
 request_ref=ref(args.request);need(request_ref['sha256']==args.sha256.lower(),'explicit ROOT request SHA required');d=read(args.request)
 need(type(d)is dict and set(d)==KEYS and d['schema']=='lyd.root.next-cp-cap-source-request.v1','closed source request')
 head=d['expected_head'];need(type(head)is str and re.fullmatch('[0-9a-f]{40}',head)and head=='06159b964d859d30f2f07f4b183284df7d6dac47','actual new HEAD required; NULL/old R29 refused')
 for key in ('allocation_receipt','source_export_report','production_manifest','canonical_source_index','previous_boundary','previous_boundary_verifier'):checked(d[key])
 allocation=read(d['allocation_receipt']['path']);need(allocation['schema']=='xar.ck3-live-run-identity.v1'and allocation['mod_key']=='li-yu-dao'and type(allocation['sequence'])is int and allocation['sequence']==31 and allocation['legacy_alias']in(None,'R31')and type(allocation['run_id'])is str and allocation['run_id'].endswith('--li-yu-dao--R0031'),'actual ROOT allocated R0031 required; no allocation action')
 run=Path(d['run_directory']).resolve();need(run==B/'live-attempt-031','actual allocation must bind exact next RUN')
 export=read(d['source_export_report']['path']);prod=read(d['production_manifest']['path']);canonical=read(d['canonical_source_index']['path']);E=Path(export['source_root']).resolve()
 need(export['source']['head']==prod['git_sha']==canonical['source_head']==head and prod==read(checked(export['build']['manifest'])),'actual clean export/canonical/production HEAD must match')
 wrapper=canonical['canonical_builder'];checked(wrapper);gate=checked(canonical['metadata_gate'])
 boundary=read(d['previous_boundary']['path']);need(boundary['schema']=='lyd.root.previous-cold-boundary-review.v3'and boundary['status']=='ROOT_REVIEWED_ACTUAL_CLOSED_RELEASED_BOUNDARY'and boundary['source_head']==OLD_HEAD and Path(boundary['consumer_session']['path']).resolve().is_relative_to(B/'live-attempt-030'),'actual R29 typed predecessor only; no older closure reuse')
 need(ref(P/'INDEX.json')['sha256']=='9c3b00e279df20c184b681b6bac258ea86aaf6fa502cdaba77ca2e331246eede'and ref(PK/'INDEX.json')['sha256']=='dd49c7cdfbb52de9513aba5e01fc84992a911077e517165f3bcc5fc051bfd086','sealed corrected CP003/CAP004 parents')
 ci=read(P/'INDEX.json');ki=read(PK/'INDEX.json');parent_registry=read(P/'business-registry/BUSINESS-MIGRATION-REGISTRY.actual.json');parent_bm=read(parent_registry['business_manifest']['path'])
 business={r['path']:r['sha256']for r in prod['files']if r['path']!='descriptor.mod'};need(len(prod['files'])==71 and len(business)==70 and business==parent_bm['files'],'exact complete current71/70 byte map; immutable original69 and reviewed9 inverse unchanged')
 for rel,wanted in business.items():need(ref(E/'mod_li_yu_dao'/rel)['sha256']==wanted,'actual export complete business bytes '+rel)
 er=E/'tools/lyd_i3b_checkpoint_readback/reader';need(ref(er/'sdk_checkpoint_qualification.py')['sha256']==ref(Path('C:/lr30s2/tools/lyd_i3b_checkpoint_readback/reader/sdk_checkpoint_qualification.py'))['sha256'],'canonical qualification must retain exact existing current-event overlay seam')
 need('ck3_query_profile_actor_cached_succession_v1'in(er/'sdk_artifact_lineage.py').read_text(encoding='utf-8'),'actual newexport reader exact29 lineage required')
 codec=ref(E/'ck3_autonomous_player/src/xar_autoplayer/bridge/confucian_readonly_private_v1.py');lineage=read(P/'ACTUAL-CODEC12-SOURCE-LINEAGE.json');need(codec['sha256']==lineage['actual_artifact']['sha256'],'unchanged production12AST/2helper codec required')
 outputs=[Path(d[k]).resolve()for k in ('checkpoint_output','capture_output','baseline_specification_output')];C,K,T=outputs
 need(len(set(outputs))==3 and all(p.is_relative_to(B)and not p.exists()and not p.is_relative_to(run)for p in outputs)and all(not a.is_relative_to(b)and not b.is_relative_to(a)for i,a in enumerate(outputs)for b in outputs[i+1:]),'three fresh separate external source outputs')
 def project(raw):
  # Runtime source only. Do not project reader dependency modules, inverse, table or semantic schemas.
  for prefix,new in [('r30-checkpoint-author-sourceonly-20261008-',C),('r30-formal-capture-root-sourceonly-20261008-',K),('r30-baseline-capture-specification-sourceonly-20261008-',T)]:
   for suffix in ('001','002','003','004','005'):raw=raw.replace((B/(prefix+suffix)).as_posix(),new.as_posix()).replace(prefix+suffix,new.name)
  for old,new in [(OLD_HEAD,head),('C:/lr30s2',E.as_posix()),('live-attempt-030',run.name),('lyd.r30.','lyd.r31.'),('r30_','r31_'),('r30-','r31-'),('R0030','R0031'),('R30','R31')]:raw=raw.replace(old,new)
  return raw
 for source,target in ((P,C),(PK,K),(PT,T)):shutil.copytree(source,target,ignore=shutil.ignore_patterns('INDEX.json','SOURCE-DELIVERY.actual.json','__pycache__','*.pyc'))
 try:
  changed=[]
  for root in (C,K,T):
   for p in root.rglob('*.py'):
    if root==C and '/reader/'in p.as_posix():continue
    raw=p.read_text(encoding='utf-8-sig');new=project(raw)
    if raw!=new:text(p,new);changed.append(p)
  for branch in ('source-005','source-008'):
   rr=C/branch/'reader';old_overlay=project((P/branch/'reader/sdk_checkpoint_qualification.py').read_text(encoding='utf-8'))
   extras={f.relative_to(rr):f.read_bytes()for f in rr.rglob('*')if f.is_file()and not(er/f.relative_to(rr)).exists()};migration=(rr/'business_contract_migration_v2.py').read_bytes()
   for source in er.rglob('*'):
    if source.is_file()and '__pycache__'not in source.parts and source.suffix!='.pyc':dest=rr/source.relative_to(er);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
   for rel,raw in extras.items():dest=rr/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
   (rr/'business_contract_migration_v2.py').write_bytes(migration);text(rr/'sdk_checkpoint_qualification.py',old_overlay)
   for source in gate.parent.glob('*.py'):shutil.copyfile(source,C/branch/'qualification'/source.name)
   if(gate.parent/'source_preparation_support.py').exists():shutil.copyfile(gate.parent/'source_preparation_support.py',C/branch/'source_preparation_support.py')
   for rel,wanted in [('reviewed_business_ast_amendment.py',INVERSE_SHA),('finite_business_inverse_table.json',TABLE_SHA)]:
    source=P/branch/'reader/dependencies'/rel;need(ref(source)['sha256']==wanted,'corrected reviewed inverse/table parent required');shutil.copyfile(source,rr/'dependencies'/rel);need(ref(rr/'dependencies'/rel)['sha256']==wanted,'inverse/table original bytes must remain exact')
   qp=C/branch/'qualification/next_cold_qualification.py';raw=qp.read_text(encoding='utf-8');tree=ast.parse(raw);nodes=[n for n in ast.walk(tree)if isinstance(n,ast.Compare)and isinstance(n.left,ast.Name)and n.left.id=='wrapper'and len(n.comparators)==1 and isinstance(n.comparators[0],ast.Dict)];need(len(nodes)==1,'one exact canonical wrapper dictionary');literal=ast.get_source_segment(raw,nodes[0].comparators[0]);text(qp,raw.replace(literal,repr(wrapper),1));changed.append(qp)
  policy=read(P/'source-008/reader/dependencies/business_migration_policy_v2.json');policy['new_actual_source_head']=head
  for rel,row in policy['allowed_exact_changed_files'].items():row['after']=ref(E/'mod_li_yu_dao'/rel)
  added='common/scripted_triggers/lyd_m3_faith_asset_triggers.txt';policy['explicit_added_exact_files']={added:policy['allowed_exact_changed_files'][added]['after']};policy['r27_finite_actual_source_amendment']['actual_HEAD']=head
  pp=C/'source-008/reader/dependencies/business_migration_policy_v2.json';write(pp,policy);reg=read(P/'source-008/reader/dependencies/final_business_policy_registration.json');reg.update(actual_new_source_HEAD=head,approved_policy_file=ref(pp),approved_policy_sha256=ref(pp)['sha256']);rp=pp.parent/'final_business_policy_registration.json';write(rp,reg)
  migration=(P/'source-008/reader/business_contract_migration_v2.py').read_text(encoding='utf-8');migration=migration.replace(OLD_HEAD,head).replace(parent_registry['policy_sha256'],ref(pp)['sha256']).replace(ref(P/'source-008/reader/dependencies/final_business_policy_registration.json')['sha256'],ref(rp)['sha256'])
  for branch in ('source-005','source-008'):
   rr=C/branch/'reader';text(rr/'business_contract_migration_v2.py',migration)
   if branch=='source-005':
    for name in ('business_migration_policy_v2.json','final_business_policy_registration.json'):shutil.copyfile(pp.parent/name,rr/'dependencies'/name)
   formal=C/branch/'title_reference/formal_native_qualification.py';tree=ast.parse(formal.read_text(encoding='utf-8'));pins=[n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='EVENT_SOURCE_SHA'for t in n.targets)];need(len(pins)==1 and ast.literal_eval(pins[0].value)==ref(E/'mod_li_yu_dao/events/lyd_i3b_institution_events.txt')['sha256'],'actual formal event unchanged; never refresh original69 or callback qualification')
  bm=parent_bm;bm['source_head']=head;bmp=C/'business-registry/BUSINESS-MANIFEST-original69-plus-M3.actual.json';write(bmp,bm)
  br=parent_registry;br.update(source_head=head,policy_sha256=ref(pp)['sha256'],source_export_report=d['source_export_report'],source_root=E.as_posix(),production_root=(Path(d['source_export_report']['path']).parent/'production/mod_li_yu_dao').as_posix(),production_manifest=export['build']['manifest'],business_manifest=ref(bmp),changed_source_files={rel:ref(E/'mod_li_yu_dao'/rel)for rel in policy['allowed_exact_changed_files']},executing_reader_artifact=ref(er/'i3b_checkpoint_reader.py'),saved_faith_semantics_artifact=ref(er/'dependencies/saved_faith_semantics_12003.json'));need(len(br['AST_projection'])==9,'complete final9 parent proof required');brp=C/'business-registry/BUSINESS-MIGRATION-REGISTRY.actual.json';write(brp,br)
  windows=read(P/'FIVE-SOURCE-WINDOWS.expected.json');windows.update(source_head=head,business_migration_registry=ref(brp),executing_reader_artifact=br['executing_reader_artifact'],saved_faith_semantics_artifact=br['saved_faith_semantics_artifact']);write(C/'FIVE-SOURCE-WINDOWS.expected.json',windows)
  framework=read(P/'AUTHOR-FRAMEWORK.pending-runtime.json');framework.update(expected_source_head=head,source_export_report=d['source_export_report']['path'],reader_request_template=(E/'tools/lyd_i3b_checkpoint_readback/CHECKPOINT-REQUEST.template.json').as_posix(),windows=(C/'FIVE-SOURCE-WINDOWS.expected.json').as_posix(),business_migration_registry=ref(brp),sdk_codec_artifact=codec);write(C/'AUTHOR-FRAMEWORK.pending-runtime.json',framework);lineage['actual_artifact']=codec;write(C/'ACTUAL-CODEC12-SOURCE-LINEAGE.json',lineage)
  replace_pin(C/'qualify_retained_formal.py',ci['formal_author']['sha256'],ref(C/'source-008/author_actual_checkpoint.py')['sha256'])
  copy_rows=[]
  for branch in ('source-005','source-008'):
   for source in sorted(er.rglob('*')):
    if source.is_file()and '__pycache__'not in source.parts and source.suffix!='.pyc':
     dest=C/branch/'reader'/source.relative_to(er);copy_rows.append({'source':ref(source),'actual_executing_copy':ref(dest),'byte_exact':ref(source)['sha256']==ref(dest)['sha256'],'declared_overlay':source.name in ('sdk_checkpoint_qualification.py','business_contract_migration_v2.py','business_migration_policy_v2.json','final_business_policy_registration.json')})
  write(C/'ACTUAL-EXPORT-READER-COPY-INVENTORY.json',{'source_head':head,'copies':copy_rows,'inverse_original_SHA_unchanged':INVERSE_SHA,'finite_table_original_SHA_unchanged':TABLE_SHA,'SDK_max_bytes':16*1024*1024,'general_JSON_max_bytes':8*1024*1024,'original69_87_current70_71_preserved':True,'future_runtime_credit':None})
  for p in changed:ast.parse(p.read_text(encoding='utf-8-sig'),filename=str(p))
  ci.update(schema='lyd.r31.checkpoint-source-projection.v1',status='SOURCE_READY_STRICT_R0031_RUNTIME_PENDING',source_head=head,parent_index=ref(P/'INDEX.json'),actual_export=d['source_export_report'],production_manifest=d['production_manifest'],actual_allocation=d['allocation_receipt'],actual_metadata=None,actual_native_qualification=None,actual_runtime_source_index=None,planned_run=run.as_posix(),previous_operational_boundary=d['previous_boundary'])
  ci.pop('exact_inverse_restoration',None)
  for key,name in [('baseline_author','source-005/author_actual_checkpoint.py'),('formal_author','source-008/author_actual_checkpoint.py'),('baseline_materializer','materialize_baseline_checkpoint_request.py'),('formal_materializer','materialize_formal_checkpoint_request.py'),('retained_formal_qualifier','qualify_retained_formal.py'),('retained_JSON_qualification_entry','qualify_retained_formal_json_root_only.py'),('original0240_control_author','construct_original0240_control.py'),('framework','AUTHOR-FRAMEWORK.pending-runtime.json'),('source_windows','FIVE-SOURCE-WINDOWS.expected.json'),('actual_business_registry','business-registry/BUSINESS-MIGRATION-REGISTRY.actual.json'),('current_codec12','ACTUAL-CODEC12-SOURCE-LINEAGE.json'),('exact_export_reader_copies','ACTUAL-EXPORT-READER-COPY-INVENTORY.json')]:ci[key]=ref(C/name)
  ci['files']=[ref(p)for p in sorted(C.rglob('*'))if p.is_file()];put(C/'INDEX.json',ci);cpref=ref(C/'INDEX.json')
  fc=K/'capture_formal_materializer_inputs_root_only.py';replace_pin(fc,ki['checkpoint_source']['sha256'],cpref['sha256']);replace_pin(fc,ki['formal_author']['sha256'],ci['formal_author']['sha256'])
  bc=K/'capture_baseline_materializer_inputs_root_only.py';replace_pin(bc,read(P/'INDEX.json')['baseline_author']['sha256'],ci['baseline_author']['sha256'])
  fs=K/'author_formal_capture_specification_root_only.py';replace_pin(fs,ki['formal_capture']['sha256'],ref(fc)['sha256'])
  registry_author=K/'r30-root-actual-formal-registry-author.py';registry_author.rename(K/'r31-root-actual-formal-registry-author.py');replace_pin(K/'r31-root-actual-formal-registry-author.py',ki['checkpoint_source']['sha256'],cpref['sha256'])
  title=K/'author_title_reference_descriptor.py';replace_pin(title,ki['checkpoint_source']['sha256'],cpref['sha256']);replace_pin(title,ki['formal_specification_author']['sha256'],ref(fs)['sha256'])
  for p in (fc,bc,fs,title,K/'r31-root-actual-formal-registry-author.py',T/'author_baseline_capture_specification_root_only.py'):ast.parse(p.read_text(encoding='utf-8-sig'),filename=str(p))
  ti={'schema':'lyd.r31.baseline-stem-source-successor.v1','status':'SOURCE_READY_ACTUAL_ROOT_CAPTURE_PENDING','source_head':head,'author':ref(T/'author_baseline_capture_specification_root_only.py'),'checkpoint_source':cpref,'planned_run':run.as_posix(),'actual_metadata':None,'future_profile_PID_session_baseline_result':None,'parent_author':ref(PT/'author_baseline_capture_specification_root_only.py')};put(T/'INDEX.json',ti)
  ki.update(schema='lyd.r31.root-capture-sourceonly-index.v1',status='SOURCE_READY_STRICT_R0031_RUNTIME_PENDING',source_head=head,parent_capture_index=ref(PK/'INDEX.json'),checkpoint_source=cpref,baseline_specification_author=ti['author'],actual_metadata=None,actual_allocation=d['allocation_receipt'],planned_run=run.as_posix(),retained_JSON_qualification_entry=ci['retained_JSON_qualification_entry'])
  for key,name in [('baseline_capture','capture_baseline_materializer_inputs_root_only.py'),('formal_capture','capture_formal_materializer_inputs_root_only.py'),('formal_specification_author','author_formal_capture_specification_root_only.py'),('formal_registry_convenience','r31-root-actual-formal-registry-author.py'),('Title_descriptor_convenience','author_title_reference_descriptor.py')]:ki[key]=ref(K/name)
  for key in ('baseline_author','formal_author','baseline_materializer','formal_materializer'):ki[key]=ci[key]
  ki['files']=[ref(p)for p in sorted(K.rglob('*'))if p.is_file()];put(K/'INDEX.json',ki)
  put(C/'SOURCE-DELIVERY.actual.json',{'status':'SOURCE_READY_RUNTIME_PENDING','source_request':request_ref,'CP_INDEX':cpref,'CAP_INDEX':ref(K/'INDEX.json'),'THIN_INDEX':ref(T/'INDEX.json'),'actual_source_head':head,'actual_allocation':d['allocation_receipt'],'original_inverse_table_69_87_full9_guards_preserved':True,'B2_preseal_B3_LAST_historical_phase1Title_preserved':True,'SDK_OS_bus_MAIN_build_body_old_test_calls':0,'future_native_metadata_PID_profile_session_saved_T_formal_credit':None});print(json.dumps({'CP_INDEX':cpref,'CAP_INDEX':ref(K/'INDEX.json'),'THIN_INDEX':ref(T/'INDEX.json'),'future_runtime_credit':None}));return 0
 except BaseException as error:
  put(C/'SOURCE-FREEZE-FAILURE.actual.json',{'status':'RED_SOURCE_ATTEMPT_PRESERVED','error':str(error),'SDK_OS_bus_MAIN_build_body_calls':0});raise
if __name__=='__main__':raise SystemExit(main())
