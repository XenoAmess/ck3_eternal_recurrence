"""Create-only file-only D0 capture/materializer projection; ROOT later supplies current live receipts."""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import re

B=Path('C:/workspace/ck3_lyd_runtime_20261004')
HEAD=None
ACTUAL_HEAD='06159b964d859d30f2f07f4b183284df7d6dac47'
SIGNED_INPUT=B/'r31-root-signed-B3-input.actual.json'
SIGNED_INPUT_SHA='5e5860c2d940da5701b954c1cbe568c5df8831ce5277e48562def029113f56af'
RUN=B/'live-attempt-031'
def need(ok,msg):
 if not ok:raise ValueError(msg)
def ref(p):
 p=Path(p).resolve();need(p.suffix.lower()!='.ck3' and 0<p.stat().st_size<=8*1024*1024,'bounded source/JSON only; no body');raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(p):return json.loads(Path(p).read_bytes())
def put(p,v):
 with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def once(raw,old,new):
 need(raw.count(old)==1,'One exact D0 source seam required: '+old[:100]);return raw.replace(old,new,1)
def save(p,raw):
 ast.parse(raw)
 with p.open('x',encoding='utf-8',newline='\n')as f:f.write(raw)
def main():
 global HEAD,RUN,SIGNED_INPUT,SIGNED_INPUT_SHA
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--expected-head',required=True);p.add_argument('--run-directory',type=Path,required=True);p.add_argument('--signed-input',type=Path,required=True);p.add_argument('--signed-input-sha256',required=True)
 p.add_argument('--checkpoint-source',type=Path,required=True);p.add_argument('--checkpoint-index-sha256',required=True)
 p.add_argument('--capture-source',type=Path,required=True);p.add_argument('--capture-index-sha256',required=True)
 p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 HEAD=a.expected_head;RUN=a.run_directory.resolve();SIGNED_INPUT=a.signed_input.resolve();SIGNED_INPUT_SHA=a.signed_input_sha256
 need(HEAD==ACTUAL_HEAD and RUN==B/'live-attempt-031','actual R31 source/run required')
 seed=read(SIGNED_INPUT);need(seed['checkpoint']['sha256']=='c8601e7ba08406a551dcddd2a19e454423db2be6b559fad9985c6d1121b537c9' and seed['checkpoint']['bytes']==91709349 and seed['new_cold_validation'] is None and seed['formal_acceptance'] is None,'only immutable R29 signed B3 input; no R30 failed T credit')
 C=a.checkpoint_source.resolve();K=a.capture_source.resolve();O=a.output.resolve()
 cpref=ref(C/'INDEX.json');kpref=ref(K/'INDEX.json');ci=read(C/'INDEX.json');ki=read(K/'INDEX.json')
 need(cpref['sha256']==a.checkpoint_index_sha256 and kpref['sha256']==a.capture_index_sha256,'actual CP/CAP exact SHA required')
 need(ci['source_head']==ki['source_head']==HEAD and ci['planned_run']==ki['planned_run']==RUN.as_posix() and ki['checkpoint_source']==cpref,'actual strict R31 CP/CAP/source tuple required')
 signed_ref=ref(SIGNED_INPUT);need(signed_ref['sha256']==SIGNED_INPUT_SHA,'ROOT actual signed intake input changed')
 need(O.is_relative_to(B) and not O.exists() and not O.is_relative_to(C) and not O.is_relative_to(K),'fresh distinct external D0 source output required')
 O.mkdir()
 materializer=Path(ci['formal_materializer']['path']);raw=materializer.read_text(encoding='utf-8')
 raw=raw.replace('original0240_control','signed_B3_input')
 raw=once(raw,"P=Path(__file__).parent;S=P/'source-008';B=P.parent;RUN=B/'live-attempt-031'",
   "P=Path("+repr(C.as_posix())+");S=P/'source-008';B=P.parent;RUN=B/'live-attempt-031'")
 raw=once(raw,"SCHEMA='lyd.r31.actual-checkpoint-materializer-input.v1'","SCHEMA='lyd.r31.signed-precommit-cold-diagnostic-materializer-input.v1'")
 start=raw.index(" need(d['window'] in ('baseline','B1-phase1','B2-representatives','B3-signed-precommit','B4-factory-result','B5-final-protection')")
 end=raw.index(' return d',start)
 raw=raw[:start]+""" need(d['window']=='D0-signed-precommit-cold','D0 diagnostic window only')
 need(type(d['author_output'])is str and Path(d['author_output']).is_absolute(),'explicit fresh D0 author output required')
 for k in ('attach','checkpoint','G2','G3'):
  need(type(d[k])is dict and set(d[k])=={'native_receipt','sdk_result'},'explicit original SDK/native pair '+k)
 need(d['signed_B3_input'] is not None,'ROOT actual signed seed input required')
 need(all(d[k] is None for k in ('native_title_reference_query','native_event_numeric_query','formal_callback_registry')),'D0 may not reuse historical callbacks, Title/numeric queries or formal registry')
"""+raw[end:]
 begin=raw.index('def actual_control(');end=raw.index('def main():',begin)
 raw=raw[:begin]+"def actual_signed_input(desc):\n need(desc=="+repr(signed_ref)+",'Exact ROOT successful signed seed intake ref required')\n seed=read(desc)\n need(seed['schema']=='lyd.signed-B3-diagnostic-cold-input.v1' and seed['purpose']=='SIGNED_B3_STAGED_FACTORY_DIAGNOSTIC_ONLY' and seed['historical_formal_credit'] is True and seed['new_cold_validation'] is None and seed['formal_acceptance'] is None,'Historical seed authority stays historical; current formal credit remains NULL')\n return seed\n"+raw[end:]
 raw=once(raw,"control=actual_control(d['signed_B3_input'],f) if d['window']!='baseline' else None\n if control:need(control['input']['profile']==prepared['profile']['path'] and control['state']['identity']['session_id']==prov['session_id'],'same actual baseline runtime provenance required')",
   "control=actual_signed_input(d['signed_B3_input'])")
 raw=once(raw,"window=d['window'],output=out.as_posix())","window='B3-signed-precommit',output=out.as_posix())")
 raw=once(raw,"'baseline_control':d['signed_B3_input']","'signed_seed_input':d['signed_B3_input'],'purpose':'D0_SIGNED_PRECOMMIT_COLD_DIAGNOSTIC','strict_reader_stage':'signed_precommit','reader_window':'B3-signed-precommit','historical_callbacks_reused':False")
 matpath=O/'materialize_D0_checkpoint_request.py';save(matpath,raw);matref=ref(matpath)

 raw=Path(ki['formal_capture']['path']).read_text(encoding='utf-8').replace('original0240_control','signed_B3_input')
 raw=once(raw,"SCHEMA='lyd.r31.root-formal-capture-specification.attempt.v2'","SCHEMA='lyd.r31.root-D0-capture-specification.v1'")
 raw=once(raw,"WINDOWS={'B1-phase1':'B1','B2-representatives':'B2','B3-signed-precommit':'B3','B4-factory-result':'B4','B5-final-protection':'B5'}","WINDOWS={'D0-signed-precommit-cold':'D0'}")
 raw=once(raw,"re.fullmatch(r'r[1-9][0-9]*-(pending|signed)',d['attempt_label'])","d['attempt_label']=='diagnostic'")
 raw=once(raw,"index['formal_materializer']==d['materializer']","d['materializer']=="+repr(matref))
 # The emitted CAP has a historical literal pin independent of its INDEX ref.
 # Match only this exact materializer SHA Compare, preserving the rest of its guard.
 pattern=r"d\['materializer'\]\['sha256'\]==('[0-9a-f]{64}')"
 matches=list(re.finditer(pattern,raw));need(len(matches)==1,'One exact copier materializer SHA seam required')
 match=matches[0];need(ast.literal_eval(match.group(1)) in (ki['formal_materializer']['sha256'],'ef717ea07e41518ed6d3dc466f1194cef713d7c0f185b54251ce0d122b34ec20'),'Known original copier materializer SHA required')
 raw=raw[:match.start(1)]+repr(matref['sha256'])+raw[match.end(1):]
 raw=once(raw,"control=read(d['signed_B3_input']);need(control['schema']=='lyd.r31.original0240-baseline-control.v1','actual completed baseline control required')",
   "need(d['signed_B3_input']=="+repr(signed_ref)+",'Exact ROOT signed seed intake required');control=read(d['signed_B3_input'])\n need(control['schema']=='lyd.signed-B3-diagnostic-cold-input.v1' and control['formal_acceptance'] is None,'Signed historical seed is not current formal credit')")
 raw=once(raw,"need(d['formal_callback_registry'] is None or d['window'] in ('B3-signed-precommit','B4-factory-result','B5-final-protection'),'formal registry only supported explicit windows')",
   "need(all(d[k] is None for k in ('native_title_reference_query','native_event_numeric_query','formal_callback_registry')),'D0 forbids historical or current formal callback/Title/numeric hooks')")
 raw=once(raw,"'schema':'lyd.r31.actual-checkpoint-materializer-input.v1'","'schema':'lyd.r31.signed-precommit-cold-diagnostic-materializer-input.v1'")
 capath=O/'capture_D0_materializer_inputs_root_only.py';save(capath,raw);capref=ref(capath)

 raw=Path(ki['formal_specification_author']['path']).read_text(encoding='utf-8')
 raw=once(raw,"FORMAL_CAPTURE_HELPER_SHA256="+repr(ki['formal_capture']['sha256']),"FORMAL_CAPTURE_HELPER_SHA256="+repr(capref['sha256']))
 raw=once(raw,"WINDOWS={'B1-phase1':'B1','B2-representatives':'B2','B3-signed-precommit':'B3','B4-factory-result':'B4','B5-final-protection':'B5'}","WINDOWS={'D0-signed-precommit-cold':'D0'}")
 raw=raw.replace('baseline-capture-specification','runtime-inputs').replace('baseline_capture_specification','runtime_inputs')
 raw=once(raw,"re.fullmatch(r'r[1-9][0-9]*-(pending|signed)',a.attempt_label)","a.attempt_label=='diagnostic'")
 raw=once(raw,"base['schema']=='lyd.r31.root-runtime-inputs.v1'","set(base)=={'schema','source_head','prepared','client_session','attached_binding','attach','metadata_result','compiled_result','native_clean_qualification','sdk_metadata_artifact','signed_B3_input'} and base['schema']=='lyd.r31.D0-live-runtime-inputs.v1' and base['signed_B3_input']=="+repr(signed_ref))
 raw=once(raw,"need(optional['formal_callback_registry'] is None or a.window in ('B3-signed-precommit','B4-factory-result','B5-final-protection'),'callback registry limited to supported windows')",
   "need(all(v is None for v in optional.values()),'D0 may not receive formal callback/Title/numeric hooks')")
 raw=once(raw,"'schema':'lyd.r31.root-formal-capture-specification.attempt.v2'","'schema':'lyd.r31.root-D0-capture-specification.v1'")
 raw=once(raw,"'materializer':index['formal_materializer'],'original0240_control':ref(RUN/'ORIGINAL0240-CONTROL.actual.json')",
   "'materializer':"+repr(matref)+",'signed_B3_input':base['signed_B3_input']")
 raw=once(raw,"helper=HERE/'capture_formal_materializer_inputs_root_only.py'","helper=HERE/'capture_D0_materializer_inputs_root_only.py'")
 specpath=O/'author_D0_capture_specification_root_only.py';save(specpath,raw)
 runtime={'schema':'lyd.r31.D0-live-runtime-inputs.v1','source_head':HEAD,**{k:None for k in ('prepared','client_session','attached_binding','attach','metadata_result','compiled_result','native_clean_qualification','sdk_metadata_artifact')},'signed_B3_input':signed_ref}
 put(O/'D0-LIVE-RUNTIME-INPUTS.pending.json',runtime)
 put(O/'INDEX.json',{'status':'R31_D0_DIAGNOSTIC_SOURCES_READY_ACTUAL_RUNTIME_PENDING','source_head':HEAD,
  'checkpoint_source':cpref,'capture_source':kpref,'signed_B3_input':signed_ref,
  'specification_author':ref(specpath),'copier':capref,'materializer':matref,
  'single_body_author':ci['formal_author'],'live_runtime_template':ref(O/'D0-LIVE-RUNTIME-INPUTS.pending.json'),
  'strict_reader_stage':'signed_precommit','internal_reader_window':'B3-signed-precommit',
  'purpose':'D0_SIGNED_PRECOMMIT_COLD_DIAGNOSTIC','historical_callback_registry_reused':False,
  'formal_acceptance':None,'wholemod_GREEN':False,'future_runtime_PID_session_SAVE_G2_G3_cache_body_result':None,
  'original0240_formal_materializer_unchanged':True,'original69_87_complete9_contract_unchanged':True,
  'SDK_calls':0,'OS_queries':0,'bus_calls':0,'body_reads':0,'MAIN_writes':0})
 print(json.dumps({'D0_INDEX':ref(O/'INDEX.json'),'specification_author':ref(specpath),'copier':capref,'materializer':matref,'runtime_pending':ref(O/'D0-LIVE-RUNTIME-INPUTS.pending.json')}))
if __name__=='__main__':main()
