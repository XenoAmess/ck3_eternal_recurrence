R31 source constructors; current runtime evidence remains pending.

PY = C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe
SRC = C:/workspace/ck3_lyd_runtime_20261004/r31-finer-D2-capture-constructor-sourceonly-20261008-002

1. Fill CP-CAP-SOURCE-REQUEST.pending.json into a fresh actual request. Its
closed 12 fields are schema, expected_head, allocation_receipt,
source_export_report, production_manifest, canonical_source_index,
previous_boundary, previous_boundary_verifier, run_directory,
checkpoint_output, capture_output, baseline_specification_output. Actual
allocation_receipt is the allocated xar.ck3-live-run-identity.v1 JSON ref3,
sequence31/R0031 with the actual allocator legacy_alias R31. The exact R30
closed boundary remains the predecessor.
All real static refs must exist; NULL input is rejected.
  <PY> -B -X utf8 <SRC>/project_r31_cp_cap_static.py --request <actual-request.json> --sha256 <actual-request-SHA256>
This creates CP, CAP and ordinary thin source only. It does not run the ordinary
0240 baseline author for the signed-seed diagnostic. The signed diagnostic uses
the specialized D0 materializer below.

2. Use actual CP/CAP INDEX refs emitted in step 1 and the actual signed input
validated by ROOT's R31 runtime intake. The input still binds only the immutable
R29 signed B3 c8601e... seed, not current callbacks or acceptance:
  <PY> -B -X utf8 <SRC>/materialize_D0_source.py --expected-head 06159b964d859d30f2f07f4b183284df7d6dac47 --run-directory C:/workspace/ck3_lyd_runtime_20261004/live-attempt-031 --signed-input <actual-signed-input.json> --signed-input-sha256 <actual-SHA> --checkpoint-source <actual-CP-directory> --checkpoint-index-sha256 <actual-CP-INDEX-SHA> --capture-source <actual-CAP-directory> --capture-index-sha256 <actual-CAP-INDEX-SHA> --output <fresh-D0-source-directory>

3. Freeze the unchanged pure cache comparator functions to the actual export:
  <PY> -B -X utf8 <SRC>/bind_cache_source.py --expected-head 06159b964d859d30f2f07f4b183284df7d6dac47 --export-report C:/workspace/ck3_lyd_runtime_20261004/r31-root-clean-export-20261008-001/REPORT.json --export-report-sha256 ba6a5fd88967c41909043f68d377e2e22d8c03fa21b3332e383d9a992ccdfc14 --output <fresh-cache-source-directory>

4. Fill constructor001's SOURCE-REQUEST.pending.json into a fresh actual request
using the real CP, D0 and cache INDEX ref3 values, current export, actual signed
input, actual finer-D2 overlay BINDING, ROOT-selected RUN/Client/queue and fresh
source output. Invoke the corrected constructor002 entry, which retains every
parent guard and changes only its generated RUN expression to Path(...):
  <PY> -B -X utf8 <SRC>/materialize_finer_D2_source.py --request <actual-finer-stage-source-request.json> --sha256 <actual-request-SHA256>

Stage execution and the one-SAVE/one-body capture sequence are in parent
constructor001/ROOT-CLI.md, whose source bytes remain immutable. The resulting
source INDEX emits the actual CLI files. D2a is event .20/stage20 and requires
actual unheld T; D2b is event .2/stage2 after the atomic container/holder/resolve.
Only consecutive D0->D1->D2a->D2b->D3->D4->D5->D6 comparisons are used. Missing
native scope/marker Title or cross-event T loss stays UNKNOWN/RED. Original
87/88 and full political/actor AST predicates remain unchanged; diagnostic
formal/current factory credit is NULL. Runtime/bootstrap and cold materializer
are owned by r13_live_preparation's R31 SOURCE004 projection; this packet does
not duplicate them.
