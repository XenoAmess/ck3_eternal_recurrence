"""R31 successor: one exact generated RUN expression fix; parent guards unchanged."""
from pathlib import Path
import ast,hashlib,importlib.util,sys
sys.dont_write_bytecode=True
PARENT=Path('C:/workspace/ck3_lyd_runtime_20261004/r31-finer-D2-capture-constructor-sourceonly-20261008-001/materialize_finer_D2_source.py')
PARENT_SHA='b912dedb45f909252ad66a90df152a86a7fd3fdf38c81bfab5431cc9c24c4dd2'
def main():
 if hashlib.sha256(PARENT.read_bytes()).hexdigest()!=PARENT_SHA:raise ValueError('immutable constructor001 parent changed')
 spec=importlib.util.spec_from_file_location('r31_finer_d2_constructor001',PARENT);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 original=m.Bind
 class ExactPathBind(original):
  def __init__(self,d,assignments,desc_map):
   corrected=dict(assignments)
   if 'RUN' in corrected:
    value=ast.parse(corrected['RUN'],mode='eval').body
    if isinstance(value,ast.Call) and isinstance(value.func,ast.Name) and value.func.id in ('WindowsPath','PosixPath'):
     m.need(len(value.args)==1 and not value.keywords and isinstance(value.args[0],ast.Constant) and type(value.args[0].value)is str,'one exact original RUN path expression')
     m.need(Path(value.args[0].value).resolve()==Path(d['run_root']).resolve(),'generated RUN must equal ROOT actual request')
     corrected['RUN']='Path('+repr(value.args[0].value)+')'
   super().__init__(d,corrected,desc_map)
 m.Bind=ExactPathBind
 return m.main()
if __name__=='__main__':raise SystemExit(main())
