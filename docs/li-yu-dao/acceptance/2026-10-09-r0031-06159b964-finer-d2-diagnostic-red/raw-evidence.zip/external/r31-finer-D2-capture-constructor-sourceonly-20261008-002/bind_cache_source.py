"""Freeze the retained cache comparator against ROOT's exact current export; source only."""
from pathlib import Path
import argparse,ast,copy,hashlib,json,sys
sys.dont_write_bytecode=True
B=Path('C:/workspace/ck3_lyd_runtime_20261004');P=B/'r30-root-cache-comparator-bound-source-20261008-002'
HEAD='06159b964d859d30f2f07f4b183284df7d6dac47'
def need(ok,msg):
 if not ok:raise ValueError(msg)
def ref(p):
 p=Path(p).resolve();need(p.suffix in ('.json','.py') and 0<p.stat().st_size<=8*1024*1024,'compact JSON/source only');r=p.read_bytes();return {'path':p.as_posix(),'bytes':len(r),'sha256':hashlib.sha256(r).hexdigest()}
def put(p,d):
 with p.open('x',encoding='utf-8',newline='\n')as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--expected-head',required=True);a.add_argument('--export-report',type=Path,required=True);a.add_argument('--export-report-sha256',required=True);a.add_argument('--output',type=Path,required=True);v=a.parse_args()
 report_ref=ref(v.export_report);need(report_ref['sha256']==v.export_report_sha256 and v.expected_head==HEAD,'exact current source HEAD/export ref required; NULL rejected');report=json.loads(v.export_report.read_bytes());need(report['source']['head']==HEAD,'actual export HEAD differs')
 out=v.output.resolve();need(out.is_relative_to(B) and not out.exists(),'fresh external cache source only')
 parent=P/'compare_actor_cached_succession.py';need(ref(parent)['sha256']=='58c8355bdbf1b3eb790d8f1fbf88c4e7285e6abdd3841371dd13529a76086744','immutable R30 cache function parent')
 contract=json.loads((P/'SOURCE-CONTRACT.json').read_bytes());source=Path(report['source_root']).resolve();module_refs={}
 for rel,expected in contract['required_pure_module_byte_contract'].items():
  actual=ref(source/rel);need({k:actual[k]for k in ('bytes','sha256')}==expected,'unchanged pure provider function byte contract '+rel);module_refs[rel]=actual
 raw=parent.read_text(encoding='utf-8');tree=ast.parse(raw);edits=[];lines=raw.splitlines(keepends=True);offset=[0]
 for l in lines:offset.append(offset[-1]+len(l))
 for name,new in (('HEAD',repr(HEAD)),('SOURCE','Path('+repr(source.as_posix())+')')):
  matches=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets)];need(len(matches)==1,'one exact source '+name+' assignment');n=matches[0].value;edits.append((offset[n.lineno-1]+n.col_offset,offset[n.end_lineno-1]+n.end_col_offset,new))
 for x,y,s in sorted(edits,reverse=True):raw=raw[:x]+s+raw[y:]
 ast.parse(raw);out.mkdir();(out/'compare_actor_cached_succession.py').write_text(raw,encoding='utf-8',newline='\n')
 contract.update(schema='lyd.r31.actor-cache-saved-JSON-source-contract.v1',source_head=HEAD,source_root=source.as_posix(),pure_module_refs=module_refs,actual_source_export_report=report_ref,actual_runtime_INPUTs=None,actual_native_to_saved_equality=None,business_acceptance_credit=None,source_iteration_parent=ref(P/'INDEX.json'))
 put(out/'SOURCE-CONTRACT.json',contract)
 put(out/'INDEX.json',{'status':'ACTUAL_NEW_EXPORT_CACHE_COMPARATOR_SOURCE_FROZEN_NO_RUNTIME_EXECUTION','source_head':HEAD,'source_export_report':report_ref,'parent_source':ref(parent),'comparator':ref(out/'compare_actor_cached_succession.py'),'contract':ref(out/'SOURCE-CONTRACT.json'),'SDK_game_process_bus_build_body_calls':0})
 print(json.dumps({'INDEX':ref(out/'INDEX.json'),'comparator':ref(out/'compare_actor_cached_succession.py'),'runtime_results':None},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
