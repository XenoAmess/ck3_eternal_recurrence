from pathlib import Path
import json
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
p=B/'r30-checkpoint-author-sourceonly-20261008-001/INDEX.json';d=json.loads(p.read_bytes())
print('CP INDEX keys',list(d));print(json.dumps({k:v for k,v in d.items() if any(x in k.lower() for x in ('constructor','author','inputs','parent','projection'))},indent=2))
for p in B.iterdir():
 if p.is_dir() and ('cp-cap' in p.name or 'constructor' in p.name or 'cache-comparator' in p.name) and any(n in p.name for n in ('r29','r30')):
  print('SOURCE DIRECTORY',p.as_posix())
  for f in p.glob('*.py'):print('PY',f.as_posix())
