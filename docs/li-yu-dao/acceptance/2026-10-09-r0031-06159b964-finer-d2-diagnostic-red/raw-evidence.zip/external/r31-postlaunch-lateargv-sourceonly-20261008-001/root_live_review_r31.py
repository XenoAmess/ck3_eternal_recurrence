"""ROOT file-only draft of the existing eleven-field review or bind argv.

Never approves a live binding, probes a process, accesses SDK/GUI/task bus,
executes the binder, or changes the game. ROOT separately reviews actual live
identity and writes ROOT_REVIEWED_ACTUAL_LIVE_BINDING to a new actual review.
"""
from pathlib import Path
import argparse,hashlib,json,math,re,sys

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve()
PROFILE_KEYS={'schema_version','guard_profile','guard_profile_sha256','userdir','state_directory','evidence_directory','game_version','dll','injector'}
REQUEST_KEYS={'schema','pid','hwnd','steam_ui_pid','steam_client_pid','offline_review','offline_image_sha256','lease_receipt','screen_task_id','task_bus_script','task_bus_sha256','native_template','actions_file','output'}
REVIEW_KEYS={'schema','status','source_head','root_screen_task','process_id','process_create_time','window_hwnd','profile','fresh_steam_offline_review','fresh_sole_owner_receipt','launch_receipt'}

def need(value,message):
    if not value:raise ValueError(message)
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def ref(path):
    path=Path(path).resolve();raw=path.read_bytes()
    return {'path':path.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def pinned(path,expected):
    path=Path(path).resolve()
    need(type(expected) is str and re.fullmatch('[0-9a-f]{64}',expected) is not None,'Explicit lower-case actual SHA required')
    need(digest(path)==expected,'Actual SHA changed: '+str(path));return path
def ref_read(row):
    need(type(row) is dict and set(row)=={'path','bytes','sha256'},'Exact actual ref3 required')
    path=pinned(row['path'],row['sha256']);need(type(row['bytes']) is int and path.stat().st_size==row['bytes'],'Actual bytes changed')
    return read(path)
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def same(a,b):return Path(a).resolve()==Path(b).resolve()
def put(path,value):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
def identity_args(args):
    need(re.fullmatch('R[0-9]{4}',args.attempt_id) is not None,'Actual allocated attempt ID required')
    number=int(args.attempt_id[1:]);run=Path(args.run_directory).resolve()
    need(number==31 and run.parent==BASE and run.name=='live-attempt-'+str(number).zfill(3),'Actual allocated run path differs')
    need(re.fullmatch('[0-9a-f]{40}',args.head) is not None,'Actual source HEAD required')
    need(re.fullmatch('[A-Za-z0-9_.:-]{6,160}',args.screen_task) is not None,'Actual screen task required')
    need(all(type(getattr(args,k)) is int and getattr(args,k)>0 for k in ('pid','hwnd','steam_ui_pid','steam_client_pid')),'Actual positive PID/HWND/Steam PIDs required')
    need(type(args.process_create_time) in (int,float) and math.isfinite(args.process_create_time) and args.process_create_time>0,'Exact actual process creation time required')
    return run,'lyd.r'+str(number)+'.'
def facts(args):
    run,namespace=identity_args(args)
    source=Path(args.cold_source).resolve();pinned(source/'INDEX.json',args.cold_source_index_sha256);pinned(source/'prepare_next_formal_cold.py',args.cold_helper_sha256)
    references={}
    for key in ('profile_request','profile_build_receipt','profile','offline_review','postlaunch_appmanifest_delta','launch'):
        path=pinned(getattr(args,key),getattr(args,key+'_sha256'));references[key]=ref(path)
    cold_path=pinned(run/'COLD-MATERIALIZED.json',args.cold_sha256);references['cold']=ref(cold_path);cold=read(cold_path)
    need(cold.get('schema')==namespace+'cold-materialized-only.v1' and cold.get('status')=='COLD_MATERIALIZED_NOT_ATTACHABLE' and cold.get('source_revision')==args.head,'Actual same-run cold receipt required')
    need(cold.get('prepared') is False and not (run/'PREPARED.json').exists(),'Actual unbound cold attempt required')
    inputs=ref_read(cold['inputs']);cold_request=ref_read(cold['input_request']);ref_read(cold['cold_inventory'])
    need(inputs['source']['head']==args.head and inputs['root_screen_task']==args.screen_task and cold_request['expected_head']==args.head and cold_request['output']==run.as_posix(),'Cold source/task/run differs')
    request=ref_read(references['profile_request']);receipt=ref_read(references['profile_build_receipt']);profile=ref_read(references['profile'])
    need(set(request)==REQUEST_KEYS and request['schema']=='ck3.lyd.fresh-profile-request.v1','Original closed fresh-profile request required')
    need(request['pid']==args.pid and request['hwnd']==args.hwnd and request['steam_ui_pid']==args.steam_ui_pid and request['steam_client_pid']==args.steam_client_pid and request['screen_task_id']==args.screen_task,'Actual request identities differ')
    need(receipt['schema']=='ck3.lyd.fresh-profile-build.v1' and receipt['status']=='PROFILE_FROZEN_READ_ONLY','Actual freezer success required')
    need(receipt['side_effects']=={'input_sent':False,'game_started':False,'bridge_injected':False},'Freezer side-effect contract differs')
    need(same(receipt['request_path'],references['profile_request']['path']) and receipt['request_sha256']==references['profile_request']['sha256'],'Actual freezer request binding differs')
    need(same(receipt['native_profile'],references['profile']['path']) and receipt['native_sha256']==references['profile']['sha256'] and same(request['output'],Path(receipt['native_profile']).parent),'Actual frozen profile binding differs')
    need(set(profile)==PROFILE_KEYS and all(profile[k] is not None for k in PROFILE_KEYS),'Actual original nine-field profile required')
    guard_path=pinned(profile['guard_profile'],profile['guard_profile_sha256']);guard=read(guard_path);references['guard']=ref(guard_path)
    need(same(receipt['guard_profile'],guard_path) and receipt['guard_sha256']==profile['guard_profile_sha256'],'Freezer/guard binding differs')
    target=guard['target'];steam=guard['steam']
    need(target['pid']==args.pid and target['hwnd']==args.hwnd and target['process_create_time']==args.process_create_time and guard['screen_task_id']==args.screen_task,'Actual guard identity/task differs')
    need(same(target['executable'],inputs['game']['executable']['path']) and target['executable_sha256']==inputs['game']['executable']['sha256'],'Guard executable differs from cold inputs')
    need(steam['pid']==args.steam_ui_pid and steam['client_pid']==args.steam_client_pid and steam['offline_visual_reviewed'] is True,'Actual Steam guard identity/review differs')
    need(profile['schema_version']==1 and profile['game_version']=='1.20.0.4','Exact current .4 profile required')
    for key,relative in [('userdir','userdir'),('state_directory','native-state'),('evidence_directory','native-evidence')]:need(same(profile[key],run/relative),'Profile isolated directory differs')
    for key in ('dll','injector'):
        need(set(profile[key])=={'path','sha256'} and same(profile[key]['path'],inputs['native_build'][key]['path']) and profile[key]['sha256']==inputs['native_build'][key]['sha256'],'Profile native artifact differs');pinned(profile[key]['path'],profile[key]['sha256'])
    offline=ref_read(references['offline_review']);need(offline.get('steam_offline_confirmed') is True and same(request['offline_review'],references['offline_review']['path']),'Actual ROOT offline wrapper differs')
    frame_path=Path(references['offline_review']['path']).parent/offline['fresh_frame_receipt'];frame_ref=ref(frame_path);frame=read(frame_path)
    need(same(steam['offline_evidence'],frame_path) and steam['offline_evidence_sha256']==frame_ref['sha256'] and frame['schema']=='ck3.steam_fresh_desktop_frame.v1' and frame['moving_edge_changed'] is True and frame['steam_pid']==args.steam_ui_pid,'Actual guard frame differs')
    image=Path(references['offline_review']['path']).parent/offline['image'];pinned(image,offline['image_sha256'])
    need(request['offline_image_sha256'].lower()==offline['image_sha256'].lower() and same(frame['moved_path'],image) and frame['moved_sha256'].lower()==offline['image_sha256'].lower(),'Actual reviewed moving image differs')
    owner_ref=ref(request['lease_receipt']);owner=read(request['lease_receipt'])
    need(owner.get('schema')=='codex.task_bus.v1' and owner.get('ok') is True and owner['task']['task_id']==args.screen_task and owner['task']['state']=='running' and 'ck3-screen:acquired' in owner['task']['resources'],'Actual fresh sole-owner receipt differs')
    launch=ref_read(references['launch'])
    need(same(references['launch']['path'],run/'launch.json') and launch['schema']==namespace+'root-launch-profile-helper.v1' and launch['source_revision']==args.head and launch['pid']==args.pid and launch['process_create_time']==args.process_create_time and launch['game_started'] is True and launch['status']=='GAME_CREATED_REQUIRES_NATIVE_LOAD_READBACK','Actual launch binding differs')
    delta=ref_read(references['postlaunch_appmanifest_delta'])
    need(delta.get('schema')=='lyd.r14.exact-appmanifest-lastplayed-only-proof.v1','Preserved exact LastPlayed protocol required')
    # Full immutable manifest and inventory validation stays in the real cold
    # binder. This draft only binds explicit files and never supplies approval.
    review={'schema':namespace+'root-live-guard-review.v1','status':'ROOT_REVIEW_REQUIRED','source_head':args.head,'root_screen_task':args.screen_task,'process_id':args.pid,'process_create_time':args.process_create_time,'window_hwnd':args.hwnd,'profile':references['profile'],'fresh_steam_offline_review':frame_ref,'fresh_sole_owner_receipt':owner_ref,'launch_receipt':references['launch']}
    need(set(review)==REVIEW_KEYS,'Review fields changed')
    return run,review,references
def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('mode',choices=('draft','bind-argv'))
    for key in ('cold-source','cold-source-index-sha256','cold-helper-sha256'):parser.add_argument('--'+key,required=True)
    for key in ('run-directory','attempt-id','head','screen-task','process-create-time','output','cold-sha256'):parser.add_argument('--'+key,required=True,type=float if key=='process-create-time' else str)
    for key in ('pid','hwnd','steam-ui-pid','steam-client-pid'):parser.add_argument('--'+key,required=True,type=int)
    for key in ('profile-request','profile-build-receipt','profile','offline-review','postlaunch-appmanifest-delta','launch'):
        parser.add_argument('--'+key,required=True);parser.add_argument('--'+key+'-sha256',required=True)
    parser.add_argument('--root-review');parser.add_argument('--root-review-sha256')
    args=parser.parse_args()
    try:
        run,review,references=facts(args)
        out=Path(args.output).resolve();need(BASE in out.parents and not out.exists(),'Fresh external output required')
        if args.mode=='bind-argv':
            need(args.root_review is not None and args.root_review_sha256 is not None,'Explicit ROOT actual reviewed file and SHA required')
            actual_path=pinned(args.root_review,args.root_review_sha256);actual=read(actual_path)
            expected={**review,'status':'ROOT_REVIEWED_ACTUAL_LIVE_BINDING'}
            need(actual==expected and set(actual)==REVIEW_KEYS,'Only exact existing eleven-field actual ROOT review admitted')
            out.mkdir(parents=True)
            common=[sys.executable,'-B','-X','utf8',str(Path(args.cold_source).resolve()/'prepare_next_formal_cold.py'),'--bind-live-review',str(actual_path),'--sha256',args.root_review_sha256,'--output',str(run),'--postlaunch-appmanifest-delta',args.postlaunch_appmanifest_delta,'--postlaunch-appmanifest-delta-sha256',args.postlaunch_appmanifest_delta_sha256]
            for flag in ('check','create'):put(out/('ROOT-LIVE-BIND-'+flag.upper()+'.argv.json'),{'argv':common+['--'+flag],'cwd':'C:/workspace/ck3_eternal_recurrence','executed':False,'actual_root_review':ref(actual_path)})
        else:
            need(args.root_review is None and args.root_review_sha256 is None,'Draft cannot consume or create an approval')
            out.mkdir(parents=True);put(out/'ROOT-LIVE-GUARD-REVIEW.draft.json',review)
        put(out/'FILE-REFERENCES.json',{'actual_inputs':references,'review_refs':{k:review[k] for k in ('profile','fresh_steam_offline_review','fresh_sole_owner_receipt','launch_receipt')},'root_live_observation_performed_by_helper':False,'approval_written':False,'bind_executed':False,'SDK_calls':0,'process_calls':0,'bus_calls':0,'input_sent':False})
        print(json.dumps({'status':'DRAFT_FILES_ONLY_ROOT_REVIEW_REQUIRED' if args.mode=='draft' else 'ACTUAL_ROOT_REVIEW_BOUND_ARGV_ONLY_NOT_EXECUTED','output':str(out),'files':[ref(p) for p in sorted(out.iterdir())],'prepared_credit':False},ensure_ascii=False));return 0
    except Exception as error:
        print(json.dumps({'status':'RED','error':str(error),'approval_written':False,'bind_executed':False,'prepared_credit':False},ensure_ascii=False));return 1
if __name__=='__main__':raise SystemExit(main())
