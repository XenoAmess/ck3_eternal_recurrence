"""ROOT file-only late argv author for existing R31 postlaunch/profile/review/binding tools.
No SDK, process query, focus/input, bus operation, approval, or helper execution.
"""
from pathlib import Path
import argparse,hashlib,json,sys
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
RUN=BASE/'live-attempt-031'
CORE=BASE/'r31-root-actual-runtime-source-20261008-001/core'
CONSUMER=BASE/'r31-root-actual-consumer-source-20261008-001'
HERE=Path(__file__).resolve().parent
PY='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
HEAD='06159b964d859d30f2f07f4b183284df7d6dac47'
TASK='lyd-r0031-06159-finer-D2-root'
def ref(p):
 p=Path(p).resolve();data=p.read_bytes()
 return {'path':p.as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def read(p):return json.loads(Path(p).read_bytes())
def add(argv,key,value):argv.extend(['--'+key,str(value)])
def addref(argv,key,path):
 row=ref(path);add(argv,key,row['path']);add(argv,key+'-sha256',row['sha256']);return row
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('stage',choices=('postlaunch','profile','draft','bind','consumer'))
 p.add_argument('--output',type=Path,required=True,help='Create-only structured argv file; never executed')
 p.add_argument('--helper-output',type=Path)
 p.add_argument('--profile-request-directory',type=Path)
 p.add_argument('--postlaunch-delta',type=Path)
 p.add_argument('--offline-review',type=Path)
 for k in ('pid','hwnd','steam-ui-pid','steam-client-pid'):p.add_argument('--'+k,type=int)
 p.add_argument('--process-create-time',type=float)
 p.add_argument('--root-review',type=Path)
 p.add_argument('--epoch-id')
 for k in ('queue-directory','client-output','binding-output','author-output'):p.add_argument('--'+k,type=Path)
 p.add_argument('--execute-binder',action='store_true',help='Only includes ROOT explicit binder flag in emitted argv')
 a=p.parse_args()
 if a.output.exists():raise FileExistsError(a.output)
 argv=[PY,'-B','-X','utf8'];provenance={}
 if a.stage=='postlaunch':
  if a.helper_output is None:p.error('--helper-output required')
  request=RUN/'COLD-MATERIALIZED.json';cold=read(request);r=cold['input_request']
  argv += [(CORE/'preserve_postlaunch_appmanifest.py').as_posix(),'--request',r['path'],'--sha256',r['sha256'],'--output',a.helper_output.resolve().as_posix()]
  provenance={'actual_cold':ref(request),'actual_cold_request':r}
 elif a.stage=='profile':
  if any(getattr(a,k) is None for k in ('helper_output','postlaunch_delta','offline_review','pid','hwnd','steam_ui_pid','steam_client_pid')):p.error('Actual helper-output/delta/offline/PID/HWND/Steam identities required')
  launch=RUN/'launch.json';l=read(launch)
  if l['pid']!=a.pid or l['source_revision']!=HEAD:p.error('Actual same R31 launch PID/source required')
  argv += [(CORE/'write_launch_argv.py').as_posix(),'--mode','profile-request','--run-directory',RUN.as_posix(),'--attempt-id','R0031','--keeper-directory',(BASE/'r31-root-screen-keeper-20261008-001').as_posix(),'--screen-task',TASK]
  addref(argv,'offline-review',a.offline_review);addref(argv,'live-run-id',RUN/'live-run-id.json')
  addref(argv,'profile-freezer',CONSUMER/'prepare_fresh_native_profile.py')
  for k in ('pid','hwnd','steam_ui_pid','steam_client_pid'):add(argv,k.replace('_','-'),getattr(a,k))
  add(argv,'launch-sha256',ref(launch)['sha256']);addref(argv,'postlaunch-appmanifest-delta',a.postlaunch_delta)
  add(argv,'helper-output',a.helper_output.resolve().as_posix())
  # The existing writer creates this operational argv; this author only emits writer argv.
  add(argv,'output',(RUN/'ROOT-PROFILE-REQUEST-ARGV.actual.json').as_posix())
  provenance={'actual_launch':ref(launch),'profile_freezer':ref(CONSUMER/'prepare_fresh_native_profile.py')}
 elif a.stage in ('draft','bind'):
  if any(getattr(a,k) is None for k in ('helper_output','profile_request_directory','postlaunch_delta','offline_review','pid','hwnd','steam_ui_pid','steam_client_pid','process_create_time')):p.error('Actual profile directory/delta/offline and complete process/window identities required')
  argv += [(HERE/'root_live_review_r31.py').as_posix(),'draft' if a.stage=='draft' else 'bind-argv','--cold-source',CORE.as_posix(),'--cold-source-index-sha256',ref(CORE/'INDEX.json')['sha256'],'--cold-helper-sha256',ref(CORE/'prepare_next_formal_cold.py')['sha256'],'--run-directory',RUN.as_posix(),'--attempt-id','R0031','--head',HEAD,'--screen-task',TASK,'--cold-sha256',ref(RUN/'COLD-MATERIALIZED.json')['sha256']]
  for k in ('pid','hwnd','steam_ui_pid','steam_client_pid','process_create_time'):add(argv,k.replace('_','-'),getattr(a,k))
  d=a.profile_request_directory.resolve()
  for key,path in [('profile-request',d/'native-profile-request.json'),('profile-build-receipt',d/'native-profile-fresh-001/profile-build-receipt.json'),('profile',d/'native-profile-fresh-001/native-profile.json'),('offline-review',a.offline_review),('postlaunch-appmanifest-delta',a.postlaunch_delta),('launch',RUN/'launch.json')]:addref(argv,key,path)
  if a.stage=='bind':
   if a.root_review is None:p.error('ROOT separately reviewed actual eleven-field --root-review required')
   addref(argv,'root-review',a.root_review)
  add(argv,'output',a.helper_output.resolve().as_posix())
  provenance={'review_author':ref(HERE/'root_live_review_r31.py'),'actual_profile_request':ref(d/'native-profile-request.json')}
 else:
  if a.epoch_id is None or any(getattr(a,k) is None for k in ('queue_directory','client_output','binding_output','author_output')):p.error('Actual epoch and four fresh binding locations required')
  argv += [(CORE/'author_formal_root_inputs.py').as_posix(),'--consumer-source',CONSUMER.as_posix(),'--consumer-index-sha256',ref(CONSUMER/'INDEX.json')['sha256']]
  addref(argv,'prepared',RUN/'PREPARED.json');add(argv,'epoch-id',a.epoch_id)
  for k in ('queue_directory','client_output','binding_output','author_output'):add(argv,k.replace('_','-'),getattr(a,k).resolve().as_posix())
  if a.execute_binder:argv += ['--execute-binder']
  provenance={'actual_PREPARED':ref(RUN/'PREPARED.json'),'actual_consumer':ref(CONSUMER/'INDEX.json')}
 a.output.parent.mkdir(parents=True,exist_ok=True)
 with a.output.open('x',encoding='utf-8',newline='\n') as f:json.dump({'argv':argv,'cwd':'C:/workspace/ck3_eternal_recurrence','executed':False,'provenance':provenance},f,indent=2);f.write('\n')
 print(json.dumps({'argv_file':ref(a.output),'executed':False}))
if __name__=='__main__':main()
