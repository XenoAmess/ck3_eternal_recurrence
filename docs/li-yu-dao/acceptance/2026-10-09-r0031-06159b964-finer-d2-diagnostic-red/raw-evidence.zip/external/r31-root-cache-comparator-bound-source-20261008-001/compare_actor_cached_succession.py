"""Authenticate an existing after-save cache query and compare complete saved IDs; no I/O to CK3."""
from pathlib import Path
import argparse, hashlib, importlib, json, math, re, sys, types
sys.dont_write_bytecode = True
HERE = Path(__file__).parent
HEAD = '06159b964d859d30f2f07f4b183284df7d6dac47'
SOURCE = Path('C:/lr31s1')
TOOL = 'ck3_query_profile_actor_cached_succession_v1'
STAGES = {'B0':'pre_proposal_baseline','B3':'signed_precommit','B4':'success_postcommit'}
INPUT_KEYS = {'schema','stage','author_result','state','qualified_native','save_receipt','query_request','query_dispatch','query_sdk_result','query_native_receipt','source_export_report','profile','metadata29','host_identities'}

class Rejected(ValueError): pass
def need(ok, message):
    if not ok: raise Rejected(message)
def digest(raw): return hashlib.sha256(raw).hexdigest()
def canonical(o): return json.dumps(o, ensure_ascii=True, separators=(',',':'), sort_keys=True).encode()
def same(a,b): return canonical(a)==canonical(b)
def exact(o,keys,label): need(type(o)is dict and set(o)==set(keys),'closed '+label); return o
def integer(v, low, high, label): need(type(v)is int and low<=v<=high,'actual integer '+label); return v
def unique_json(raw):
    def pairs(rows):
        d={}
        for k,v in rows: need(k not in d,'duplicate JSON key '+k); d[k]=v
        return d
    def constant(v): raise Rejected('nonfinite JSON '+v)
    return json.loads(raw.decode('utf-8-sig'),object_pairs_hook=pairs,parse_constant=constant)
def artifact(desc, *, sdk=False):
    exact(desc,{'path','bytes','sha256'},'artifact ref3')
    need(type(desc['path'])is str and Path(desc['path']).suffix.lower()=='.json','JSON artifact only')
    integer(desc['bytes'],1,(16 if sdk else 8)*1024*1024,'artifact bytes')
    need(type(desc['sha256'])is str and re.fullmatch('[0-9a-f]{64}',desc['sha256'])is not None,'actual artifact SHA')
    p=Path(desc['path']); need(p.stat().st_size==desc['bytes'],'artifact size differs '+p.name)
    raw=p.read_bytes(); need(digest(raw)==desc['sha256'],'artifact SHA differs '+p.name)
    return unique_json(raw)
def pointer(o,path):
    need(type(path)is str and path.startswith('/')and not re.search(r'~(?![01])',path),'explicit valid JSON pointer required')
    for part in path[1:].split('/'):
        key=part.replace('~1','/').replace('~0','~')
        if type(o)is list:
            need(re.fullmatch('0|[1-9][0-9]*',key)is not None and int(key)<len(o),'JSON array pointer missing')
            o=o[int(key)]
        else:
            need(type(o)is dict and key in o,'actual host field absent at '+path); o=o[key]
    return o
def provider():
    contract=unique_json((HERE/'SOURCE-CONTRACT.json').read_bytes())
    need(contract['source_head']==HEAD and contract['source_root']==SOURCE.as_posix(),'source-only contract identity differs')
    for rel,desc in contract['pure_module_refs'].items():
        path=SOURCE/rel
        need(path.as_posix()==desc['path']and path.stat().st_size==desc['bytes']and digest(path.read_bytes())==desc['sha256'],'frozen actual source module differs '+rel)
    root=SOURCE/'ck3_autonomous_player/src'
    # Namespace packages prevent the broad bridge __init__ from importing backend drivers.
    for name,path in [('xar_autoplayer',root/'xar_autoplayer'),('xar_autoplayer.bridge',root/'xar_autoplayer/bridge')]:
        need(name not in sys.modules,'fresh isolated comparator process required')
        module=types.ModuleType(name); module.__path__=[str(path)]; module.__package__=name; sys.modules[name]=module
    module=importlib.import_module('xar_autoplayer.bridge.actor_cached_succession_private_v1')
    need(Path(module.__file__).resolve()==(root/'xar_autoplayer/bridge/actor_cached_succession_private_v1.py').resolve(),'executing actual DTO module path differs')
    return module,contract
def sdk_native(sdk,native):
    exact(sdk,{'_meta','content','structuredContent','isError','resultType'},'original SDK result')
    need(sdk['isError']is False and sdk['resultType']=='complete','successful complete SDK result required')
    need(sdk['_meta']=={'io.modelcontextprotocol/serverInfo':{'name':'CK3 frozen native profile','version':''}},'frozen SDK server identity differs')
    content=sdk['content']; need(type(content)is list and len(content)==1,'one original native text receipt required')
    row=exact(content[0],{'type','text','annotations','_meta'},'SDK text block')
    need(row['type']=='text'and type(row['text'])is str and row['annotations']is None and row['_meta']is None,'SDK native text shape')
    need(same(unique_json(row['text'].encode()),native)and same(sdk['structuredContent'],native),'original SDK text/structured/native objects differ')
def host_identities(spec,binding):
    exact(spec,{'captured','attached'},'actual HANDLE/attached host references')
    values={}
    for role in ('captured','attached'):
        keys={'artifact','pid_pointer','ctime_pointer','executable_pointer'}
        if role=='attached': keys.add('connection_generation_pointer')
        row=exact(spec[role],keys,role+' actual host descriptor'); raw=artifact(row['artifact'])
        pid=integer(pointer(raw,row['pid_pointer']),1,2**32-1,role+' PID')
        ctime=pointer(raw,row['ctime_pointer']); need(type(ctime)in(int,float)and math.isfinite(ctime)and ctime>0,'actual numeric '+role+' process ctime')
        exe=pointer(raw,row['executable_pointer']); need(type(exe)is str and exe and Path(exe).name.lower()=='ck3.exe','actual CK3 executable path '+role)
        values[role]={'pid':pid,'ctime':ctime,'executable':exe}
        need(pid==binding['game_pid'],'host PID differs from native/saved binding')
        if role=='attached':
            generation=integer(pointer(raw,row['connection_generation_pointer']),1,2**64-1,'actual attached generation')
            need(generation==binding['connection_generation'],'attached/native generation differs')
            values[role]['connection_generation']=generation
    for key in ('pid','ctime','executable'):
        need(type(values['captured'][key])is type(values['attached'][key])and values['captured'][key]==values['attached'][key],'original HANDLE/attached identity differs '+key)
    return values
def saved_ids(state):
    actor=state['actor']; need(actor['character_id']==31254,'saved actor full ID differs')
    rows=actor['landed_data']; need(type(rows)is list,'complete saved actor landed_data required')
    copies=[r['value']for r in actor['entries']if r.get('key')=='landed_data']
    need(len(copies)==1 and same(copies[0],rows),'saved full AST and landed projection differ')
    cached=[r['value']for r in rows if r.get('key')=='succession']
    need(len(cached)==1 and type(cached[0])is list,'single complete saved succession array required; absence is not empty')
    out=[]
    for row in cached[0]:
        exact(row,{'key','value'},'saved succession ID row')
        value=row['value']; need(row['key']is None and type(value)is str and re.fullmatch('0|[1-9][0-9]*',value)is not None,'saved full ID token required')
        out.append(integer(int(value),0,2**32-2,'saved full successor ID'))
    return out
def verify(config):
    exact(config,INPUT_KEYS,'R30 diagnostic comparator request')
    need(config['schema']=='lyd.r30.actor-cache-saved-JSON-equality-request.v1','request schema differs')
    stage=config['stage']; need(stage in STAGES,'actual B0/B3/B4 stage required')
    author=artifact(config['author_result']); state=artifact(config['state']); q=artifact(config['qualified_native'])
    for name in ('state','qualified_native'):
        matches=[r for r in author['outputs']if same(r,config[name])]
        need(len(matches)==1,'existing original author must inventory '+name)
    need(author['source_refs']['checkpoint_receipt']==config['save_receipt'],'original same-stage save receipt pin differs')
    need(author['source_refs']['profile']==config['profile']and author['source_refs']['source_export_report']==config['source_export_report'],'author source/profile descriptors differ')
    need(state['schema']=='lyd.i3b.checkpoint-observations.v1'and state['stage']==STAGES[stage],'actual saved STATE stage differs')
    need(q['schema']=='lyd.sdk-checkpoint-qualified-native.v3'and q['G2_status']=='BOUND_COMPLETE_NATIVE_OBSERVATION','existing actual qualified native object required')
    rb=q['runtime_binding']; need(rb['source_head']==HEAD,'actual clean source HEAD differs')
    export=artifact(config['source_export_report']); need(export['source']['head']==HEAD and Path(export['source_root']).resolve()==SOURCE.resolve(),'actual export binding differs')
    need(rb['source_export_sha256']==export['source_archive']['sha256'],'qualified export hash differs')
    migration=rb['versioned_business_migration']
    need((migration['original_business_files'],migration['business_files'],migration['production_files'])==(69,70,71),'original69/current70/71 qualification differs')
    need(migration['source_head']==HEAD and migration['source_export_report']==config['source_export_report'],'business qualification source differs')
    profile=artifact(config['profile']); need(rb['profile_sha256']==config['profile']['sha256']and profile['dll']['sha256']==rb['DLL_sha256'],'actual connected profile/DLL metadata differs')
    need(rb['sdk_metadata_tool_count']==29 and rb['sdk_metadata_artifact']==config['metadata29']and rb['sdk_metadata_sha256']==config['metadata29']['sha256'],'actual metadata29 qualification differs')
    metadata=artifact(config['metadata29']); need(type(metadata)is list and len(metadata)==29,'complete official 29-tool array required')
    tools=[row for row in metadata if row.get('name')==TOOL]; need(len(tools)==1,'actual registered cached-succession tool required')
    save=artifact(config['save_receipt']); need(save['status']=='native_gameplay_postcondition_verified'and save['result']['step']=='save-checkpoint'and save['result']['accepted']is True,'actual verified SAVE action required'); need(save['schema']=='ck3.native-profile-receipt.v1'and save['session_id']==rb['session_id']and save['profile_sha256']==rb['profile_sha256']and save['pipe_name']==rb['pipe_name'],'original saved receipt actual provenance differs')
    need(save['result']['checkpoint']==rb['checkpoint']and save['result']['checkpoint']['sha256']==state['checkpoint_sha256'],'original saved checkpoint object differs')
    binding=q['checkpoint_transition']['after_binding']
    need(binding=={k:rb[v]for k,v in [('revision','queried_revision'),('native_revision','queried_native_revision'),('date_raw','date_raw'),('game_pid','game_pid'),('connection_generation','connection_generation'),('played_character_id','played_character_id'),('snapshot_id','queried_snapshot_id')]},'qualified actual after-save frame differs')
    need(q['checkpoint_transition']['snapshot_after_original']==save['snapshot_after'],'original SAVE after-frame differs from qualification')
    need(save['snapshot_after']['paused']is True and save['snapshot_after']['map_ready']is True,'saved frame must be actually paused/map-ready')
    need(state['identity']['actor_id']==31254 and state['identity']['pid']==binding['game_pid']and state['identity']['session_id']==rb['session_id']and state['identity']['revision']==binding['native_revision'],'STATE actual actor/process/native revision differs')
    need(rb['played_character_full_id']==binding['played_character_id']==31254 and rb['checkpoint']['date_raw']==binding['date_raw'],'actual full actor/date differs')
    request=artifact(config['query_request']); dispatch=artifact(config['query_dispatch']); sdk=artifact(config['query_sdk_result'],sdk=True); native=artifact(config['query_native_receipt'])
    exact(request,{'schema','request_id','operation','name','arguments'},'original ROOT query request')
    need(request['schema']=='ck3.lyd.mcp-request.v1'and request['operation']=='call_tool'and request['name']==TOOL and type(request['request_id'])is str and request['request_id'],'actual cache query request differs')
    need(request['arguments']=={'expected_revision':binding['revision']},'cache query must follow the exact saved public revision')
    need(dispatch['schema']=='ck3.lyd.mcp-dispatch.v1'and dispatch['status']=='MCP_RESULT_RECORDED'and dispatch['request_id']==request['request_id']and dispatch['request_sha256']==config['query_request']['sha256'],'actual dispatch/request authentication differs')
    need(dispatch['sdk_result_sha256']==config['query_sdk_result']['sha256']and (Path(config['query_dispatch']['path']).parent/dispatch['sdk_result']).resolve()==Path(config['query_sdk_result']['path']).resolve(),'actual SDK wrapper dispatch binding differs')
    receipts=dispatch['native_receipts']; need(type(receipts)is list and len(receipts)==1 and receipts[0]['sha256']==config['query_native_receipt']['sha256']and Path(receipts[0]['path']).resolve()==Path(config['query_native_receipt']['path']).resolve(),'actual native receipt dispatch binding differs')
    sdk_native(sdk,native)
    need(native['schema']=='ck3.native-profile-receipt.v1'and native['status']=='native_actor_cached_succession_observed','available actual native cache receipt required')
    for key in ('session_id','profile_sha256','pipe_name'): need(native[key]==rb[key],'native/qualified provenance differs '+key)
    need(type(native['recorded_at_utc'])is str and native['recorded_at_utc']and Path(native['receipt_path']).resolve()==Path(config['query_native_receipt']['path']).resolve(),'original native receipt path/time differs')
    need(native['business_effects_verified']is False and native['full_product_acceptance_credit']is False,'native query credit must remain false')
    module,source_contract=provider(); public=module.normalize_public_query(native['result'],binding)
    payload=public['native_result']['actor_cached_succession']
    need(payload['available']is True and payload['roster_complete']is True and payload['unavailable_reason']is None,'complete available actual cache required')
    host=host_identities(config['host_identities'],binding)
    native_ids=payload['complete_cached_successor_ids']; ids=saved_ids(state)
    equal=native_ids==ids
    mismatch=next((i for i in range(max(len(native_ids),len(ids)))if (native_ids[i]if i<len(native_ids)else None)!=(ids[i]if i<len(ids)else None)),None)
    return {'status':'AUTHENTICATED_NATIVE_SAVED_CACHE_EQUAL'if equal else'AUTHENTICATED_NATIVE_SAVED_CACHE_DIFFERENT','stage':stage,'STATE_stage':state['stage'],'checkpoint_sha256':state['checkpoint_sha256'],'native_to_saved_equality':equal,'native_count':payload['native_count'],'saved_count':len(ids),'complete_native_successor_ids_in_original_order':native_ids,'complete_saved_successor_ids_in_original_order':ids,'first_difference_index':mismatch,'after_save_binding':binding,'native_capture_epoch':payload['capture_epoch'],'native_recorded_at_utc':native['recorded_at_utc'],'host_identity_observations':host,'exact_native_DTO_validated':True,'source_head':HEAD,'metadata_tool_count':29,'missing_fields_or_refs':[],'factory_intermediate_trace_observed':False,'business_postcondition_verified':False,'full_product_acceptance_credit':False,'actual_pass':None,'formal_mandate_credit':None}
def main():
    ap=argparse.ArgumentParser(description='JSON-only authenticated R30 diagnostic after-save actor cached-succession comparison; no SDK/process/body/binary/main actions.')
    ap.add_argument('--input',required=True);ap.add_argument('--input-sha256',required=True);ap.add_argument('--output',required=True)
    args=ap.parse_args();out=Path(args.output)
    if out.exists():ap.error('create-only output directory already exists')
    out.mkdir(parents=True); report={'schema':'lyd.r30.actor-cache-saved-JSON-equality-result.v1','native_to_saved_equality':None,'actual_pass':None,'full_product_acceptance_credit':False,'factory_intermediate_trace_observed':False,'SDK_calls':0,'process_calls':0,'checkpoint_body_reads':0,'binary_reads':0,'main_writes':0}
    try:
        p=Path(args.input)
        need(p.suffix.lower()=='.json'and 0<p.stat().st_size<=8*1024*1024,'bounded JSON input only')
        raw=p.read_bytes();need(digest(raw)==args.input_sha256,'exact original input JSON SHA required')
        config=unique_json(raw);report['input']={'path':p.as_posix(),'bytes':len(raw),'sha256':digest(raw)};report['input_artifacts']=config
        report.update(verify(config));code=0 if report['native_to_saved_equality']is True else 1
    except Exception as error:
        report.update(status='REJECTED_MISSING_OR_DIFFERENT_ACTUAL_BINDING',missing_fields_or_refs=[str(error)],native_to_saved_equality=None);code=2
    with (out/'RESULT.actual.json').open('x',encoding='utf-8',newline='\n')as stream:json.dump(report,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps({'status':report['status'],'stage':report.get('stage'),'native_to_saved_equality':report['native_to_saved_equality'],'missing_fields_or_refs':report.get('missing_fields_or_refs',[]),'output':str(out/'RESULT.actual.json')}))
    return code
if __name__=='__main__':raise SystemExit(main())
