"""ROOT-only clean-HEAD export and formal Li Yu Dao staging, create-only.

Copies exact Git archive paths mod_li_yu_dao, complete ck3_autonomous_player,
tools, and the complete ck3_workshop_mcp/src package. It imports the archived product's builder and passes revision=head.
No native compile, game, Steam, desktop, queue, lease or tracked write occurs.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tarfile
import zipfile

sys.dont_write_bytecode=True
REPO=Path('C:/workspace/ck3_eternal_recurrence').resolve()
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004').resolve()
GAME=Path('C:/Program Files (x86)/Steam/steamapps/common/Crusader Kings III').resolve()
ARCHIVE_PATHS=('mod_li_yu_dao','ck3_autonomous_player','tools','ck3_workshop_mcp/src')
COMMIT=re.compile(r'[0-9a-f]{40}\Z')
BASELINE_HEAD='632f0a57a07aa6299052004589ed6f7632e7d8f7'
REVIEWED_PRODUCTION=None
sys.path.insert(0,str(Path(__file__).resolve().parent))
if hashlib.sha256((Path(__file__).resolve().parent/'source_preparation_support.py').read_bytes()).hexdigest()!='eba78f64184821689d6185030df50eadf479eb0231510fb771f9fe9bc9ee81d2': raise ValueError('Frozen preparation support changed')
from source_preparation_support import reviewed_production, game_reference
BASELINE_MANIFEST=BASE/'r11-root-head-export-20261006-002/production/mod_li_yu_dao.manifest.json'
BASELINE_MANIFEST_SHA='f0ef038814af21d9d0fde45bcbbbb9adeb11a8a7f876cbed99788985c77afe1e'


def validate_head(head: str) -> str:
    if type(head) is not str or not COMMIT.fullmatch(head) or head in ('0'*40,'f'*40,BASELINE_HEAD):
        raise ValueError('Explicit new actual40hex HEAD required; placeholders and old632 refused')
    return head


def tracked_inventory(text: str) -> list[dict]:
    if type(text) is not str or not text or not text.endswith('\x00'):
        raise ValueError('Complete NUL-terminated actual ls-tree inventory required')
    rows=[];seen=set()
    for item in text.split('\x00')[:-1]:
        if item.count('\t')!=1:raise ValueError('Closed ls-tree header/path required')
        header,name=item.split('\t');parts=header.split(' ')
        if len(parts)!=3:raise ValueError('Closed ls-tree mode/type/object required')
        mode,kind,identity=parts;name=relative(name)
        if mode not in ('100644','100755') or kind!='blob' or not COMMIT.fullmatch(identity):
            raise ValueError('Only tracked regular Git blob files admitted')
        if name.casefold() in seen:raise ValueError('Duplicate tracked path refused')
        seen.add(name.casefold());rows.append({'path':name,'git_mode':mode,'git_type':kind,'git_object_id':identity})
    if not all(any(row['path'].startswith(prefix+'/') for row in rows) for prefix in ARCHIVE_PATHS):
        raise ValueError('All four tracked archive roots must be nonempty')
    return sorted(rows,key=lambda row:row['path'])


def long_path(path: Path) -> Path:
    raw=str(path.absolute())
    if os.name=='nt' and not raw.startswith('\\\\?\\'):
        if raw.startswith('\\\\'): raw='\\\\?\\UNC\\'+raw[2:]
        else: raw='\\\\?\\'+raw
    return Path(raw)


def actual_origin_path(value: str) -> Path:
    raw=str(value)
    if raw.startswith('\\\\?\\UNC\\'):raw='\\\\'+raw[8:]
    elif raw.startswith('\\\\?\\'):raw=raw[4:]
    return Path(raw).resolve()


def no_links(path: Path) -> None:
    for part in (path.absolute(),*path.absolute().parents):
        item=long_path(part)
        if not item.exists() and not item.is_symlink():continue
        info=item.lstat()
        if item.is_symlink() or item.is_junction() or getattr(info,'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise ValueError('Symlink/junction/reparse refused: '+str(part))


def absolute(value: Path | str, *, below: Path | None=None, fresh: bool=False) -> Path:
    path=Path(value)
    if not path.is_absolute() or '..' in path.parts or any(c in str(path) for c in ('\x00','\r','\n','"')):
        raise ValueError('Explicit absolute path without traversal required')
    no_links(path)
    result=path.resolve()
    if below is not None and below not in result.parents:
        raise ValueError('Output must be strictly below '+str(below))
    if fresh and long_path(result).exists():raise ValueError('Existing target refused: '+str(result))
    return result


def sha_file(path: Path) -> str:
    with long_path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def record(path: Path) -> dict:
    no_links(path)
    return {'path':path.as_posix(),'bytes':long_path(path).stat().st_size,'sha256':sha_file(path)}


def encoded(value: object) -> bytes:
    return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')


def write(path: Path, raw: bytes, root: Path) -> None:
    target=absolute(path,below=root)
    long_path(target.parent).mkdir(parents=True,exist_ok=True)
    with long_path(target).open('xb') as stream:stream.write(raw)


def relative(name: str) -> str:
    if type(name) is not str or not name or '\\' in name or ':' in name or any(c in name for c in ('\x00','\r','\n','\t')):
        raise ValueError('Unsafe archive relative path')
    parts=name.rstrip('/').split('/')
    if name.startswith('/') or any(p in ('','.','..') for p in parts):raise ValueError('Archive traversal refused')
    if any(p.endswith((' ','.')) or re.match(r'(?i)^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)',p) for p in parts):
        raise ValueError('Ambiguous Windows archive name refused')
    result='/'.join(parts)
    if PurePosixPath(result).as_posix()!=result or not any(result==p or result.startswith(p+'/') or p.startswith(result+'/') for p in ARCHIVE_PATHS):
        raise ValueError('Archive member outside requested trees')
    return result


class GitRunner:
    def __init__(self,repo: Path):
        if actual_origin_path(str(repo))!=REPO:raise ValueError('ROOT exporter accepts only fixed main repository identity')
        self.repo=REPO
        self.audit=[]

    def read(self,args: list[str]) -> str:
        argv=['git','-C',str(self.repo),*args]
        result=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8',errors='replace')
        self.audit.append({'argv':argv,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
        if result.returncode:raise ValueError('Read-only source query failed')
        return result.stdout

    def archive(self,head: str,path: Path,out: Path) -> None:
        argv=['git','-C',str(self.repo),'archive','--format=tar',head,*ARCHIVE_PATHS]
        stderr_path=out/'archive.stderr'
        with long_path(path).open('xb') as stream:
            result=subprocess.run(argv,stdout=stream,stderr=subprocess.PIPE)
        os.chmod(long_path(path),0o444)
        write(stderr_path,result.stderr,out)
        self.audit.append({'argv':argv,'returncode':result.returncode,'stdout_file':record(path),'stderr_file':record(stderr_path)})
        if result.returncode:raise ValueError('Exact HEAD archive failed; partial preserved')


def clean_snapshot(runner: GitRunner,head: str) -> dict:
    validate_head(head)
    actual_top=runner.read(['rev-parse','--show-toplevel']).strip()
    if actual_origin_path(actual_top)!=REPO:raise ValueError('Actual Git top-level differs from fixed main repository')
    queries={'head':['rev-parse','HEAD'],'tree':['rev-parse','HEAD^{tree}'],
             'product_tree':['rev-parse','HEAD:mod_li_yu_dao'],
             'native_tree':['rev-parse','HEAD:ck3_autonomous_player/native_bridge'],
             'autoplayer_tree':['rev-parse','HEAD:ck3_autonomous_player'],
             'tools_tree':['rev-parse','HEAD:tools'],
             'workshop_src_tree':['rev-parse','HEAD:ck3_workshop_mcp/src']}
    values={key:runner.read(args).strip() for key,args in queries.items()}
    values['repository_root']=REPO.as_posix()
    values['status']=runner.read(['status','--porcelain=v1','--untracked-files=all'])
    if values['head']!=head or values['status'] or any(not COMMIT.fullmatch(values[k]) for k in queries):
        raise ValueError('Expected actual exact clean HEAD and trees')
    return values


def extract_exact(archive: Path,source: Path,tracked: dict | None=None) -> list[dict]:
    with tarfile.open(long_path(archive),mode='r:') as tar:
        members=tar.getmembers()
        names, prefixes, files={}, {}, []
        for member in members:
            name=relative(member.name)
            if not member.isfile() and not member.isdir():raise ValueError('Nonregular archive member refused: '+name)
            if name.casefold() in names:raise ValueError('Case-insensitive duplicate archive path')
            names[name.casefold()]=name
            parts=name.split('/')
            for length in range(1,len(parts)+1):
                prefix='/'.join(parts[:length]);folded=prefix.casefold()
                if folded in prefixes and prefixes[folded]!=prefix:raise ValueError('Case-inconsistent archive directory')
                prefixes[folded]=prefix
            if member.isfile():
                if not any(name==p or name.startswith(p+'/') for p in ARCHIVE_PATHS):raise ValueError('File outside exact four requested prefixes')
                files.append((member,name))
        if not files or not all(any(n.startswith(p+'/') for _,n in files) for p in ARCHIVE_PATHS):
            raise ValueError('Archive must contain all four complete requested trees')
        long_path(source).mkdir(parents=True,exist_ok=False)
        rows=[]
        for member,name in files:
            content=tar.extractfile(member).read()
            if len(content)!=member.size:raise ValueError('Archive member byte count differs')
            if tracked is not None:
                expected=tracked.get(name)
                identity=hashlib.sha1(b'blob '+str(len(content)).encode('ascii')+b'\x00'+content).hexdigest()
                if expected is None or expected['git_object_id']!=identity:
                    raise ValueError('Archive bytes are not exact tracked Git blob: '+name)
            write(source/name,content,source)
            rows.append({'path':name,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()})
    return sorted(rows,key=lambda r:r['path'])


def inventory(root: Path) -> list[dict]:
    rows=[]
    extended=long_path(root)
    for path in sorted(extended.rglob('*')):
        if path.is_symlink() or path.is_junction():raise ValueError('Linked exported source refused')
        if path.is_file():
            relative_name=path.relative_to(extended).as_posix()
            actual=root/relative_name
            no_links(actual)
            rows.append({'path':relative_name,'bytes':path.stat().st_size,'sha256':sha_file(actual)})
    return sorted(rows,key=lambda r:r['path'])


def subset(rows: list[dict],prefix: str) -> list[dict]:
    return [{**r,'path':r['path'][len(prefix)+1:]} for r in rows if r['path'].startswith(prefix+'/')]


def verify_continuation_payload(payload: list[dict], staging: Path) -> None:
    if REVIEWED_PRODUCTION is None: raise ValueError('Explicit actual reviewed production required')
    expected = REVIEWED_PRODUCTION['rows']
    if payload != expected: raise ValueError('New clean HEAD formal runtime differs from explicitly reviewed final manifest')
    if inventory(staging) != expected: raise ValueError('Actual formal staging differs from reviewed 71-file manifest')


def build_archived_product(source: Path,out: Path,head: str) -> dict:
    builder_path=source/'mod_li_yu_dao/tools/build_release.py'
    if not long_path(builder_path).is_file():raise ValueError('Archived formal builder missing')
    # The ROOT CLI gets fresh definitions from the archived tree, including
    # complete package __init__ imports. Do not retain cached main/installed
    # publication modules from any prior import in this process.
    for name in list(sys.modules):
        if name=='workshop_compatibility_tags' or name=='ck3_workshop_mcp' or name.startswith('ck3_workshop_mcp.') or name=='tools' or name.startswith('tools.'):
            del sys.modules[name]
    sys.path.insert(0,str(source/'tools'))
    sys.path.insert(0,str(source/'ck3_workshop_mcp/src'))
    spec=importlib.util.spec_from_file_location('lyd_exact_export_builder',long_path(builder_path))
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    import_roots=[]
    for name,loaded in sorted(sys.modules.items()):
        if name=='workshop_compatibility_tags' or name=='ck3_workshop_mcp' or name.startswith('ck3_workshop_mcp.'):
            origin=getattr(loaded,'__file__',None)
            if not origin or source not in actual_origin_path(origin).parents:raise ValueError('Actual builder dependency escaped new archived HEAD: '+name)
            import_roots.append({'module':name,'raw_origin':origin,'source':record(actual_origin_path(origin))})
    if not any(r['module']=='ck3_workshop_mcp.compatibility_tags' for r in import_roots):raise ValueError('Archived native publication registry was not imported')
    build=module.build_release(source/'mod_li_yu_dao',out/'production/mod_li_yu_dao',revision=head)
    staging=Path(build['staging']).resolve()
    manifest=Path(build['manifest']).resolve()
    archive=Path(build['archive']).resolve()
    if any(out not in p.parents for p in (staging,manifest,archive)):
        raise ValueError('Formal builder output escaped requested new export directory')
    data=json.loads(long_path(manifest).read_bytes())
    if data.get('format_version')!=1 or data.get('product_id')!='mod_li_yu_dao' or data.get('git_sha')!=head:
        raise ValueError('Formal manifest lost actual export HEAD binding')
    payload=[]
    for row in data.get('files',[]):
        name=row.get('path')
        if type(name) is not str or PurePosixPath(name).is_absolute() or '..' in PurePosixPath(name).parts:
            raise ValueError('Unsafe formal manifest path')
        size=row.get('size',row.get('bytes'))
        if type(size) is not int or size<0 or not re.fullmatch('[0-9a-f]{64}',str(row.get('sha256'))):
            raise ValueError('Invalid formal manifest inventory row')
        payload.append({'path':name,'bytes':size,'sha256':row['sha256']})
    payload.sort(key=lambda r:r['path'])
    if not payload or len({r['path'].casefold() for r in payload})!=len(payload) or inventory(staging)!=payload or build.get('file_count')!=len(payload):
        raise ValueError('Formal staged payload does not match exact manifest')
    expected={'mod_li_yu_dao/'+r['path']:r for r in payload}
    with zipfile.ZipFile(long_path(archive)) as zipped:
        if len(zipped.namelist())!=len(expected) or set(zipped.namelist())!=set(expected):raise ValueError('ZIP set differs from formal staging')
        for name,row in expected.items():
            content=zipped.read(name)
            if len(content)!=row['bytes'] or hashlib.sha256(content).hexdigest()!=row['sha256']:raise ValueError('ZIP bytes differ from formal staging')
    verify_continuation_payload(payload,staging)
    return {**build,'archived_import_sources':import_roots,'manifest':record(manifest),'archive':record(archive),'staging':staging.as_posix(),
            'files':payload,'builder':record(builder_path),'source_revision':head}


def validate_paths(head: str,out: Path,source_dir: Path | None) -> tuple[Path,Path]:
    validate_head(head)
    output=absolute(out,below=BASE,fresh=True)
    source=absolute(source_dir if source_dir is not None else output/'source',fresh=True)
    if source==output or source in output.parents:raise ValueError('Source cannot equal or contain export output')
    protected=(REPO,GAME,Path('C:/Users').resolve(),Path('C:/Windows').resolve())
    if any(source==p or p in source.parents or source in p.parents for p in protected):
        raise ValueError('Source must be a new isolated external directory')
    return output,source


def export(head: str,out: Path,source_dir: Path | None=None,runner: GitRunner | None=None) -> dict:
    output,source=validate_paths(head,out,source_dir)
    runner=runner or GitRunner(REPO)
    before=clean_snapshot(runner,head)
    long_path(output).mkdir(parents=True,exist_ok=False)
    try:
        tracked=tracked_inventory(runner.read(['ls-tree','-r','-z',head,'--',*ARCHIVE_PATHS]))
        tracked_names=[row['path'] for row in tracked]
        tracked_by_name={row['path']:row for row in tracked}
        archive=output/'SOURCE.tar'
        runner.archive(head,archive,output)
        rows=extract_exact(archive,source,tracked_by_name)
        if {r['path'] for r in rows}!=set(tracked_names):
            raise ValueError('Git archive omitted requested tracked paths; complete export required')
        if inventory(source)!=rows:raise ValueError('Extracted source bytes differ from exact archive')
        mod_rows=subset(rows,'mod_li_yu_dao')
        native_rows=subset(rows,'ck3_autonomous_player/native_bridge')
        autoplayer_rows=subset(rows,'ck3_autonomous_player')
        tools_rows=subset(rows,'tools')
        workshop_rows=subset(rows,'ck3_workshop_mcp/src')
        if any(not v for v in (mod_rows,native_rows,autoplayer_rows,tools_rows,workshop_rows)):raise ValueError('Required source subtree empty')
        tracked_rows=[{**tracked_by_name[row['path']], 'bytes':row['bytes'],'sha256':row['sha256']} for row in rows]
        write(output/'TRACKED-FILES.json',encoded({'schema':'lyd.r13.actual-tracked-head-file-inventory.v1','source_revision':head,
                                                'repository':REPO.as_posix(),'archive_paths':list(ARCHIVE_PATHS),'files':tracked_rows}),output)
        source_data={'schema':'lyd.root.exact-head-export-inventory.v1','source_revision':head,'root':source.as_posix(),'files':rows}
        write(output/'SOURCE-INVENTORY.json',encoded(source_data),output)
        write(output/'MOD-SOURCE-INVENTORY.json',encoded({'schema':'lyd.r8.authoritative-source-inventory.v1','source_revision':head,
                                                       'root':(source/'mod_li_yu_dao').as_posix(),'files':mod_rows}),output)
        write(output/'NATIVE-SOURCE-INVENTORY.json',encoded({'schema':'lyd.root.native-source-inventory.v1','source_revision':head,
                                                          'native_tree':before['native_tree'],'root':(source/'ck3_autonomous_player/native_bridge').as_posix(),'files':native_rows}),output)
        build=build_archived_product(source,output,head)
        if inventory(source)!=rows:raise ValueError('Archived source changed during formal build')
        after=clean_snapshot(runner,head)
        if before!=after:raise ValueError('Source HEAD/tree/clean state changed during export/build')
        readback={'before':before,'after':after,'commands':runner.audit}
        write(output/'SOURCE-CLEAN-READBACK.json',encoded(readback),output)
        binding={'head':head,'tree':before['tree'],'product_tree':before['product_tree'],'native_tree':before['native_tree'],
                 'autoplayer_tree':before['autoplayer_tree'],'tools_tree':before['tools_tree'],'workshop_src_tree':before['workshop_src_tree'],
                 'product_file_count':build['file_count'],'inventory':record(output/'MOD-SOURCE-INVENTORY.json')}
        fragment={'schema':'lyd.root.cold-source-production-fragment.v1','complete_cold_request':False,
                  'source':{k:binding[k] for k in ('head','tree','product_tree','native_tree','inventory')},
                  'production':{k:build[k] for k in ('staging','manifest','archive')},
                  'native_source_root':(source/'ck3_autonomous_player/native_bridge').as_posix(),
                  'native_build_tool':(source/'tools/run_native_msvc.py').as_posix(),
                  'new_fixture_native_guard_inputs':'REQUIRED_FROM_ROOT_SEPARATELY'}
        write(output/'COLD-SOURCE-PRODUCTION.FRAGMENT.json',encoded(fragment),output)
        report={'schema':'lyd.root.exact-head-export-build.v1','status':'ACTUAL_CLEAN_HEAD_EXPORTED_FORMAL_STAGE_BUILT',
                'utc':datetime.now(timezone.utc).isoformat(),'workspace':REPO.as_posix(),'source':binding,
                'source_root':source.as_posix(),'source_archive':record(archive),
                 'source_inventory':record(output/'SOURCE-INVENTORY.json'),'native_inventory':record(output/'NATIVE-SOURCE-INVENTORY.json'),
                 'tracked_file_inventory':record(output/'TRACKED-FILES.json'),'archive_readonly':bool(long_path(archive).stat().st_file_attributes & 1),
                 'archive_only_actual_tracked_files':True,'all_archive_file_bytes_equal_tracked_Git_blobs':True,
                 'production_comparison':{**{key:value for key,value in REVIEWED_PRODUCTION.items() if key!='rows'},
                                          'runtime_files':71,'all71_runtime_bytes_equal_to_reviewed':True},
                 'native_artifact_reuse_credit':None,'future_native_build_receipt':None,
                'source_counts':{'all_exported':len(rows),'mod_li_yu_dao':len(mod_rows),'native_bridge':len(native_rows),
                                 'complete_ck3_autonomous_player':len(autoplayer_rows),'tools':len(tools_rows),'ck3_workshop_mcp_src':len(workshop_rows)},
                'archive_paths':list(ARCHIVE_PATHS),'build':build,'source_clean_before_and_after':True,
                'imported_builder_from_archived_HEAD':True,'native_compiled':False,'game_launched':False,
                'queue_invoked':False,'lease_mutated':False,'tracked_written':False,
                'static_and_native_acceptance':'NOT_RUN_BY_THIS_EXPORT_HELPER'}
        write(output/'REPORT.json',encoded(report),output)
        # External short source is bound independently; INDEX includes all output
        # files (including source when nested), while SOURCE-INVENTORY always binds
        # every exported file even when --source-dir chooses a separate short root.
        write(output/'INDEX.json',encoded({'schema':'lyd.root.exact-head-export-index.v1','files':inventory(output),
                                          'external_source_inventory':record(output/'SOURCE-INVENTORY.json')}),output)
        return {'status':report['status'],'source':binding,'source_root':source.as_posix(),'source_counts':report['source_counts'],
                'build':{k:build[k] for k in ('staging','manifest','archive','file_count','source_revision')},
                'REPORT':record(output/'REPORT.json'),'INDEX':record(output/'INDEX.json'),'runtime':'NOT_RUN'}
    except Exception as error:
        failure={'schema':'lyd.root.exact-head-export-failure.v1','status':'EXPORT_BUILD_RED_PARTIAL_PRESERVED',
                 'error_type':type(error).__name__,'error':str(error),'head':head,'output':output.as_posix(),
                 'source_root':source.as_posix(),'commands':runner.audit,'native_compiled':False,
                 'game_launched':False,'tracked_written':False}
        if not long_path(output/'FAILURE.json').exists():write(output/'FAILURE.json',encoded(failure),output)
        raise


def main() -> int:
    global REVIEWED_PRODUCTION
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--head',required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--source-dir',type=Path,required=True)
    parser.add_argument('--reviewed-prod-manifest',type=Path,required=True)
    parser.add_argument('--reviewed-prod-manifest-sha256',required=True)
    args=parser.parse_args()
    try:
        REVIEWED_PRODUCTION=reviewed_production(args.reviewed_prod_manifest,args.reviewed_prod_manifest_sha256,args.head)
        game=game_reference()
        result=export(args.head,args.output,args.source_dir)
        with (args.output/'CURRENT-C-MACHINE-GAME-REFERENCE.json').open('xb') as f:
            f.write((json.dumps(game,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
        print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0
    except Exception as error:
        print(json.dumps({'status':'EXPORT_BUILD_RED','error_type':type(error).__name__,'error':str(error),
                          'native_compiled':False,'game_launched':False,'tracked_written':False},ensure_ascii=False,indent=2))
        return 1


if __name__=='__main__':raise SystemExit(main())
