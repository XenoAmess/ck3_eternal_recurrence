"""Create and verify an append-only R31 JSON/source/stdio evidence archive."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

B = Path("C:/workspace/ck3_lyd_runtime_20261004")
RUN = B / "live-attempt-031"
OUT = Path("C:/workspace/ck3_eternal_recurrence/docs/li-yu-dao/acceptance/2026-10-09-r0031-06159b964-finer-d2-diagnostic-red")
HEAD = "06159b964d859d30f2f07f4b183284df7d6dac47"
SKIP_RUN_TOP = {"content", "userdir", "checkpoints", "native-state"}
ALLOWED_SUFFIX = {".json", ".txt", ".log", ".input", ".py", ".md"}
ALLOWED_BASENAME = {"stdout", "stderr"}
MAX_FILE = 16 * 1024 * 1024

def sha(path):
    h = hashlib.sha256()
    n = 0
    with path.open("rb") as stream:
        while True:
            part = stream.read(1024 * 1024)
            if not part:
                break
            h.update(part)
            n += len(part)
    return {"path": path.as_posix(), "bytes": n, "sha256": h.hexdigest()}

def save(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")

assert OUT.is_dir() and (OUT / "REPORT.md").is_file()
assert not any((OUT / name).exists() for name in ("INDEX.json", "raw-evidence.zip", "ARCHIVE-VALIDATION.actual.json"))
selected = {}
for path in RUN.rglob("*"):
    if not path.is_file():
        continue
    rel = path.relative_to(RUN)
    if rel.parts[0] in SKIP_RUN_TOP:
        continue
    if path.suffix.lower() not in ALLOWED_SUFFIX and path.name not in ALLOWED_BASENAME:
        continue
    if path.stat().st_size > MAX_FILE:
        raise ValueError(f"unexpected oversized original {path}")
    selected["runtime/" + rel.as_posix()] = path
for top in sorted(B.glob("r31-*")):
    if top == RUN or top == OUT:
        continue
    if top.is_dir():
        paths = top.rglob("*")
    elif top.is_file():
        paths = [top]
    else:
        continue
    for path in paths:
        if not path.is_file():
            continue
        if path.suffix.lower() not in ALLOWED_SUFFIX and path.name not in ALLOWED_BASENAME:
            continue
        if path.stat().st_size > MAX_FILE:
            raise ValueError(f"unexpected oversized original {path}")
        rel = path.relative_to(B)
        selected["external/" + rel.as_posix()] = path
selected["report/REPORT.md"] = OUT / "REPORT.md"
selected["author/" + Path(__file__).name] = Path(__file__)
rows = []
for entry, path in sorted(selected.items()):
    rows.append({"zip_entry": entry, **sha(path)})
archive = OUT / "raw-evidence.zip"
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for row in rows:
        info = zipfile.ZipInfo(row["zip_entry"], date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        with Path(row["path"]).open("rb") as src, z.open(info, "w") as dst:
            while True:
                part = src.read(1024 * 1024)
                if not part:
                    break
                dst.write(part)
with zipfile.ZipFile(archive, "r") as z:
    assert z.namelist() == [row["zip_entry"] for row in rows]
    for row in rows:
        h = hashlib.sha256()
        n = 0
        with z.open(row["zip_entry"]) as src:
            while True:
                part = src.read(1024 * 1024)
                if not part:
                    break
                h.update(part)
                n += len(part)
        if n != row["bytes"] or h.hexdigest() != row["sha256"]:
            raise ValueError("ZIP extracted bytes differ: " + row["zip_entry"])
index = {
    "schema": "lyd.r31.closed-diagnostic-original-byte-inventory.v1",
    "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "loaded_source_head": HEAD,
    "runtime": RUN.as_posix(),
    "whole_mod": "NOT_GREEN",
    "formal_acceptance": None,
    "stages": ["D0", "D1", "D2a", "D2b"],
    "original_files": rows,
    "external_checkpoints": [
        {"stage": "D0", "path": (RUN / "checkpoints/D0-signed-precommit-cold-diagnostic/checkpoint.ck3").as_posix(), "bytes": 91709380, "sha256": "274b8617fe361e701f7c16b082886dc2fbd6bebb179fb2a2c1e530ca5d8fdc70"},
        {"stage": "D1", "path": (RUN / "checkpoints/D1-staged-observation-diagnostic/checkpoint.ck3").as_posix(), "bytes": 91711107, "sha256": "1b3baa9cf83b6e0bacfa561fbfdb6a316fdbad6b4a46ec514aee4e494ef4a5ea"},
        {"stage": "D2a", "path": (RUN / "checkpoints/D2a-staged-observation-diagnostic/checkpoint.ck3").as_posix(), "bytes": 91711719, "sha256": "060603f055d86b04bebe61247ba647b76751315cc21b179a5f7e2847a2a50b76"},
        {"stage": "D2b", "path": (RUN / "checkpoints/D2b-staged-observation-diagnostic/checkpoint.ck3").as_posix(), "bytes": 91713240, "sha256": "036b5536f14d69038cf72b959dd16128f3e2c41ba055c91dd6b5c8f3f4b02b24"},
    ],
    "archive": sha(archive),
    "save_body_reads_added_by_archive": 0,
}
save(OUT / "INDEX.json", index)
save(OUT / "ARCHIVE-VALIDATION.actual.json", {
    "status": "ORIGINAL_BYTES_ZIP_VERIFIED_ONLY",
    "loaded_source_head": HEAD,
    "original_files": len(rows),
    "archive": sha(archive),
    "all_original_bytes_sha_match": True,
    "save_body_reads": 0,
    "SDK_calls": 0,
    "game_calls": 0,
    "formal_acceptance": None,
})
print(json.dumps({"status": "ORIGINAL_BYTES_ZIP_VERIFIED_ONLY", "files": len(rows), "archive": sha(archive)}, ensure_ascii=False))
