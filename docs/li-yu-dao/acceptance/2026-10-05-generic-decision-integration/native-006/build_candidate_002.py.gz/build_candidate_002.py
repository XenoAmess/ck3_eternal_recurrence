from pathlib import Path
import subprocess,os,json,time,hashlib,ctypes
out=Path(__file__).parent
source=Path('C:/ldn6/source')
build=Path('C:/ldn6/build-002')
cmake=Path('C:/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe')
ninja=Path('C:/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe')
vcvars=Path('C:/Program Files/Microsoft Visual Studio/18/Community/VC/Auxiliary/Build/vcvars64.bat')
python=Path('C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe')
for p in (source,cmake,ninja,vcvars,python):
    if not p.exists():raise SystemExit('missing '+str(p))
if build.exists():raise SystemExit('fresh build root exists')
short=ctypes.create_unicode_buffer(32768)
if not ctypes.windll.kernel32.GetShortPathNameW(str(vcvars),short,len(short)):raise SystemExit('vcvars short path unavailable')
env_result=subprocess.run(['cmd.exe','/d','/c',short.value,'&&','set'],capture_output=True)
(out/'build-env-002.stdout').write_bytes(env_result.stdout);(out/'build-env-002.stderr').write_bytes(env_result.stderr)
if env_result.returncode:raise SystemExit('vcvars environment failed')
env=os.environ.copy()
for line in env_result.stdout.decode('utf-8',errors='replace').splitlines():
    if '=' in line and not line.startswith('='):
        k,v=line.split('=',1);env[k]=v
records=[]
def run(label,args,expect=0):
    started=time.time();p=subprocess.run([str(x) for x in args],env=env,capture_output=True)
    (out/f'{label}-002.stdout').write_bytes(p.stdout);(out/f'{label}-002.stderr').write_bytes(p.stderr)
    record={'label':label,'argv':[str(x) for x in args],'exit_code':p.returncode,'expected_exit':expect,'elapsed_seconds':time.time()-started}
    records.append(record);(out/'build-receipts-002.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(record),flush=True)
    if p.returncode!=expect:raise SystemExit(f'{label} unexpected exit {p.returncode}')
base=[cmake,'-G','Ninja',f'-DCMAKE_MAKE_PROGRAM={ninja}','-DCMAKE_BUILD_TYPE=Release','-DBUILD_TESTING=ON',f'-DPython3_EXECUTABLE={python}','-DXAR_CK3_EXECUTABLE_PATH=C:/Program Files (x86)/Steam/steamapps/common/Crusader Kings III/binaries/ck3.exe']
run('configure-bad-dependency',base+['-S',source,'-B','C:/ldn6/config-bad-dependency-002','-DXAR_CK3_ENABLE_INGAME_DECISION_OUTCOME_PRIVATE_V1=ON'],expect=1)
flags=['-DXAR_CK3_ENABLE_FEUDAL_1066_BOOKMARK_MODEL_PRIVATE_V1=ON','-DXAR_CK3_ENABLE_FEUDAL_1066_SELECTED_BOOKMARK_START_PRIVATE_V1=ON','-DXAR_CK3_ENABLE_INGAME_DECISIONS_OPEN_PRIVATE_V1=ON','-DXAR_CK3_ENABLE_INGAME_DECISION_ITEM_ACTIONS_PRIVATE_V1=ON','-DXAR_CK3_ENABLE_INGAME_DECISION_OUTCOME_PRIVATE_V1=ON']
run('configure-candidate',base+['-S',source,'-B',build]+flags)
run('compile-focused-contract',[cmake,'--build',build,'--target','xar_ck3_ingame_decision_outcome_contract_v1_test','--parallel','4'])
run('test-focused-contract',[build/'xar_ck3_ingame_decision_outcome_contract_v1_test.exe'])
run('compile-candidate-dll',[cmake,'--build',build,'--target','xar_ck3_bridge','--parallel','4'])
artifacts=[]
for rel in ['xar_ck3_bridge.dll','xar_ck3_ingame_decision_outcome_contract_v1_test.exe']:
    p=build/rel;data=p.read_bytes();artifacts.append({'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'compiled-artifacts-002.json').write_text(json.dumps(artifacts,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'build':'PASS','native_game':'NOT_RUN','artifacts':artifacts}),flush=True)
