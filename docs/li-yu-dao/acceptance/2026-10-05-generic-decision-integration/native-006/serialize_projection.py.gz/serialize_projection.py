from pathlib import Path
out=Path(__file__).parent
def extract(text,anchor):
    start=text.index(anchor);op=text.index('{',start);level=0;state='code';escaped=False;i=op
    while i<len(text):
        c=text[i];n=text[i+1] if i+1<len(text) else ''
        if state=='line':
            if c=='\n':state='code'
        elif state=='block':
            if c=='*' and n=='/':state='code';i+=1
        elif state in ['string','char']:
            if escaped:escaped=False
            elif c=='\\':escaped=True
            elif c==('"' if state=='string' else "'"):state='code'
        elif c=='/' and n=='/':state='line';i+=1
        elif c=='/' and n=='*':state='block';i+=1
        elif c=='"':state='string'
        elif c=="'":state='char'
        elif c=='{':level+=1
        elif c=='}':
            level-=1
            if level==0:return text[start:i+1]
        i+=1
    raise RuntimeError(anchor)
old=(out/'before/src/ingame_decision_item_v1.cpp').read_text(encoding='utf-8-sig')
new=Path('C:/ldn6/source/src/ingame_decision_item_v1.cpp').read_text(encoding='utf-8-sig')
body='#include "xar_bridge/ingame_decision_item_v1.hpp"\n#include <cassert>\n#include <iostream>\n'
for tag,text in [('baseline',old),('candidate',new)]:
    body+='namespace '+tag+' {\nusing namespace xar::ck3_11906;\n'
    for anchor in ['std::string SerializeIngameDecisionItemV1(', 'std::string SerializeIngameDecisionItemActionV1(']:body+=extract(text,anchor)+'\n'
    body+='}\n'
body+=r'''
int main(){
  using namespace xar::ck3_11906;
  for(int n=0;n<128;++n){
    IngameDecisionItemActionResultV1 v{};
    v.action=(n&1)?IngameDecisionItemActionKindV1::select:IngameDecisionItemActionKindV1::confirm;
    v.before.available=(n&2)!=0;v.before.native_revision=3456+n;v.before.connection_generation=7;
    v.before.game_pid=234;v.before.played_character_id=31254;v.before.date_raw=53144376;
    v.before.decision_key="vivhite_courtier";v.before.detail_decision_key="vivhite_courtier";
    v.before.owner_thread_verified=(n&4)!=0;v.before.source_abi_pins_verified=(n&8)!=0;
    v.receiver_qualified=(n&16)!=0;v.native_handled=(n&32)!=0;v.dispatch_invoked=(n&64)!=0;
    v.native_call_completed=v.dispatch_invoked;v.frame_verified=true;v.postcondition_verified=(n&8)!=0;
    v.status=v.postcondition_verified?"observed_postcondition":"acknowledged_verification_pending";
    v.target_child_path="0/2/1";v.after=v.before;
    v.expected_outcome="event_window";v.expected_event_definition_key="lyd.010";
    assert(baseline::SerializeIngameDecisionItemActionV1(v)==candidate::SerializeIngameDecisionItemActionV1(v));
  }
  IngameDecisionItemActionResultV1 v{};v.action=IngameDecisionItemActionKindV1::confirm_outcome;
  v.expected_outcome="event_window";v.expected_event_definition_key="lyd_im.1";
  v.dispatch_invoked=true;v.native_call_completed=true;v.postcondition_verified=false;
  const auto json=candidate::SerializeIngameDecisionItemActionV1(v);
  assert(json.find("\"schema\":\"ck3-ingame-decision-outcome-confirm-v1\"")!=std::string::npos);
  assert(json.find("\"step\":\"confirm-ingame-decision-outcome-v1\"")!=std::string::npos);
  assert(json.find("\"action\":\"confirm_outcome\"")!=std::string::npos);
  assert(json.find("\"expected_event_definition_key\":\"lyd_im.1\"")!=std::string::npos);
  assert(json.find("\"postcondition_verified\":false")!=std::string::npos);
  assert(json.find("\"verification_pending\":true")!=std::string::npos);
  v.expected_outcome="decision_closed";v.expected_event_definition_key="";
  const auto state=candidate::SerializeIngameDecisionItemActionV1(v);
  assert(state.find("\"expected_outcome\":\"decision_closed\"")!=std::string::npos);
  assert(state.find("\"expected_event_definition_key\":\"\"")!=std::string::npos);
  std::cout<<"PASS: 128 legacy select/confirm literal production serializer projections byte-identical; two typed outcome ACKs preserve pending\n";
}
'''
(out/'serialize-production-projection-test.cpp').write_text(body,encoding='utf-8')
print('Projected exact original and candidate serializers for compiled offline JSON comparison; no native entrypoints')
