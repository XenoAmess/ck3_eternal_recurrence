from pathlib import Path
import os,subprocess,json
out=Path(__file__).parent
source=Path('C:/ldn6/source')
env=os.environ.copy()
for line in (out/'build-env-002.stdout').read_text(encoding='utf-8',errors='replace').splitlines():
    if '=' in line and not line.startswith('='):
        k,v=line.split('=',1);env[k]=v
header=(source/'include/xar_bridge/ingame_decision_outcome_contract_v1.hpp').read_text(encoding='utf-8')
test=(source/'tests/ingame_decision_outcome_contract_v1_test.cpp').read_text(encoding='utf-8')
test=test.replace('int main(){','#undef assert\n#define assert(expression) do { if(!(expression)){ std::cout<<"REJECTED_REGRESSION\\n";return 73; } } while(false)\nint main(){')
mutants=[
 ('closed_branch_accepts_eventkey','if(outcome=="decision_closed")return event_key.empty();','if(outcome=="decision_closed")return true;'),
 ('closed_branch_accepts_event','if(outcome=="event_window"){','if(true){'),
 ('allows_date_drift','return normalized==before;','normalized.date_raw=before.date_raw; return normalized==before;'),
 ('allows_actor_drift','return normalized==before;','normalized.played_character_id=before.played_character_id; return normalized==before;'),
 ('allows_resource_scale_drift','normalized.played_character_gold.raw=before.played_character_gold.raw;','normalized.played_character_gold=before.played_character_gold;'),
 ('allows_preexisting_event','if(before.has_active_event||before.has_pending_character_interaction','if(before.has_pending_character_interaction'),
 ('allows_pending_interaction','if(before.has_active_event||before.has_pending_character_interaction||','if(before.has_active_event||')]
cl='C:/Program Files/Microsoft Visual Studio/18/Community/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe'
records=[]
for name,old,new in mutants:
    assert header.count(old)==1
    folder=Path('C:/ldn6/mutation-checks')/name
    if folder.exists():raise SystemExit('mutation root exists')
    hp=folder/'include/xar_bridge/ingame_decision_outcome_contract_v1.hpp';hp.parent.mkdir(parents=True,exist_ok=True);hp.write_text(header.replace(old,new),encoding='utf-8')
    tp=folder/'test.cpp';tp.write_text(test,encoding='utf-8')
    args=[cl,'/nologo','/std:c++20','/EHsc','/W4','/WX','/UNDEBUG','/I',str(folder/'include'),'/I',str(source/'include'),str(tp),'/Fo:'+str(folder/'test.obj'),'/Fe:'+str(folder/'test.exe')]
    build=subprocess.run(args,env=env,capture_output=True)
    (out/(name+'.compile.stdout')).write_bytes(build.stdout);(out/(name+'.compile.stderr')).write_bytes(build.stderr)
    if build.returncode:raise SystemExit(name+' compile failed')
    run=subprocess.run([str(folder/'test.exe')],env=env,capture_output=True)
    (out/(name+'.run.stdout')).write_bytes(run.stdout);(out/(name+'.run.stderr')).write_bytes(run.stderr)
    r={'mutation':name,'source_old':old,'source_new':new,'compile_exit_code':build.returncode,'test_exit_code':run.returncode,'detected':run.returncode==73,'proof':'Offline regression test projects actual helper with one intentional weakening; custom assertion returns without Windows abort UI'}
    records.append(r);(out/'mutation-checks.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'mutation':name,'detected':r['detected']}),flush=True)
    if not r['detected']:raise SystemExit('mutant survived '+name)
print(json.dumps({'mutation_negative_tests':len(records),'native_game':'NOT_RUN'}),flush=True)
