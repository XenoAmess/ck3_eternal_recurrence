from pathlib import Path
import json,re,hashlib
out=Path(__file__).parent
root=Path('C:/ldn6/source')
old=(out/'before/src/ingame_decision_item_v1.cpp').read_text(encoding='utf-8-sig')
new=(root/'src/ingame_decision_item_v1.cpp').read_text(encoding='utf-8-sig')
checks=[]
def check(name,value):
    checks.append({'name':name,'pass':bool(value)})
    if not value:raise AssertionError(name)
def body(text,anchor,occurrence=0):
    begin=-1
    for _ in range(occurrence+1):begin=text.index(anchor,begin+1)
    opening=text.index('{',begin);level=0
    for i in range(opening,len(text)):
        if text[i]=='{':level+=1
        elif text[i]=='}':
            level-=1
            if level==0:return text[begin:i+1]
    raise AssertionError(anchor)
for name in ['ConfirmReceiver','NoVisibleModals','CodePins','ActionPins','ActualActor','InnerPanel','CallOnSelect','ExecuteIngameDecisionItemQueryV1']:
    anchor=('bool '+name+'(')
    check(name+'_body_unchanged',body(old,anchor)==body(new,anchor))
for index in (0,1):
    anchor='if(query.action==IngameDecisionItemActionKindV1::select)'
    check('select_body_'+str(index)+'_unchanged',body(old,anchor,index)==body(new,anchor,index))
action=body(new,'bool ExecuteIngameDecisionItemActionV1(')
check('fresh_predispatch_full_snapshot_stays_exact','predispatch!=query.observation.expected_snapshot' in action)
check('native_outcome_dispatch_consumed_before_call',action.index('out.dispatch_invoked=true; // Consume')<action.index('out.native_call_completed=DispatchFixedGuiWidgetNativeV1'))
check('generic_postcondition_never_ack_proved','out.postcondition_verified=!outcome&&' in action)
check('generic_initial_activeevent_interaction_guard','query.observation.expected_snapshot.has_active_event||query.observation.expected_snapshot.has_pending_character_interaction' in action)
check('outcome_modal_guard_checked_twice',action.count('if(outcome&&!NoVisibleModals(context))')==1 and 'source_outcome_confirm_blocked_by_visible_modal' in action)
check('no_new_script_or_native_decision_execute_api',action.count('DispatchFixedGuiWidgetNativeV1')==2 and 'CallOnSelect(env' in action)
bridge=(root/'src/bridge.cpp').read_text(encoding='utf-8')
check('pipe_generic_exact_binding',all(x in bridge for x in ['expected_player_character_id','expected_game_pid','expected_connection_generation','(outcome&&(current.has_active_event||current.has_pending_character_interaction))']))
check('pipe_outcome_contract_validation','IngameDecisionOutcomeRequestValidV1(expected_outcome,event_key)' in bridge)
check('pipe_outcome_completion_uses_controlled_after','IngameDecisionOutcomeFrameMatchesV1(current,completion,expected_outcome)' in bridge)
cmake=(root/'CMakeLists.txt').read_text(encoding='utf-8')
check('feature_default_OFF',re.search(r'option\(XAR_CK3_ENABLE_INGAME_DECISION_OUTCOME_PRIVATE_V1\s+"[^"]+" OFF\)',cmake))
check('feature_existing_actions_dependency','if(XAR_CK3_ENABLE_INGAME_DECISION_OUTCOME_PRIVATE_V1 AND\n   NOT XAR_CK3_ENABLE_INGAME_DECISION_ITEM_ACTIONS_PRIVATE_V1)' in cmake)
check('old_vivhite_pipe_guard_retained','!select&&!outcome&&(!xar::bridge::JsonStringField(incoming.payload,"expected_window_kind",window_kind,32)||window_kind!="vivhite_courtier")' in bridge)
check('old_vivhite_innerpanel_only_route_retained','if(!outcome&&query.expected_window_kind!="vivhite_courtier")' in action)
serializer=body(new,'std::string SerializeIngameDecisionItemActionV1(')
oldserializer=body(old,'std::string SerializeIngameDecisionItemActionV1(')
oldfields=re.findall(r'(?:number|boolean|text)\("([^"]+)"',oldserializer)
newfields=re.findall(r'(?:number|boolean|text)\("([^"]+)"',serializer)
check('all_old_ACK_fields_retained_in_order',newfields[:len(oldfields)]==oldfields)
check('exactly_two_new_generic_echo_fields',newfields[len(oldfields):]==['expected_outcome','expected_event_definition_key'])
record={'status':'PASS_STATIC_ONLY','checks':checks,'source':'C:/ldn6/source','native_runtime':'NOT_RUN','old_source_sha256':hashlib.sha256(old.encode()).hexdigest(),'new_source_sha256':hashlib.sha256(new.encode()).hexdigest()}
(out/'static-review-final006.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'pass':len(checks),'native_runtime':'NOT_RUN'}))
