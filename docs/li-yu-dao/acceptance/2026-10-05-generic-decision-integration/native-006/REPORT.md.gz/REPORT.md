# Generic decision outcome confirmation C++ candidate

Status: compiled offline candidate. Native game, new DLL HELLO and real decision postconditions are NOT_RUN.

The new default-OFF `confirm-ingame-decision-outcome-v1` route reuses the exact .3 stock `ConfirmReceiver` and one original `DispatchFixedGuiWidgetNativeV1` invocation. The existing vivhite route and its InnerPanel postcondition remain intact. Generic event-window and closed-detail ACKs always require independent verification; they never prove a product effect.

Final author delta: 7 files under `candidate/`, with baseline SHA values in `delta-manifest.json`. The adapter delta was rebased to the current c40 source, preserving upstream army loss bindings, and all current non-target native source changes entered the real build. Every baseline target matched the current checkout when sealed. Source and actual CMake/Ninja build inputs bind the compiled DLL to this candidate; the root must rebuild its integrated commit for R7.

Validation: final full DLL compiled using actual MSVC 14.51.36231 and CMake/Ninja; focused actual-header DTO/branch tests passed; 25 source constraints passed; 7 intentional weakenings were detected by compiled negative tests; 128 old select/confirm serializer projections produced byte-identical JSON; both generic ACK examples retained pending verification. The final focused compiled test also links actual protocol.cpp: event and explicit empty closed wires pass; missing/null/nonempty/duplicate/nested/escaped malformed closed fields are rejected. Actual default-OFF configuration passed and missing item-action dependency was rejected with the expected reason.

Post-dispatch comparison permits stress and three resource raw values, with scales preserved, plus event fields only for the event-window branch. Date, player, alive/paused/map state, relations, pending interactions, wars/armies and settlement remain guarded. Actual faith/rite changes are not fields of this Snapshot DTO and must be proven by the root's save reader.

Failed local helper attempts and old source/build materials are retained externally. Complete environment captures are private raw files and are excluded from this review/import package. No tracked source, Git state, game, native endpoint, desktop, Steam, Defender, injector or game process was changed by this task.
