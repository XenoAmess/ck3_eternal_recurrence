#include "xar_bridge/ingame_decision_item_v1.hpp"
#include <cassert>
#include <iostream>
namespace baseline {
using namespace xar::ck3_11906;
std::string SerializeIngameDecisionItemV1(const IngameDecisionItemResultV1 &v) {
  std::string s="{\"schema\":\"ck3-ingame-decision-item-v1\",\"step\":\"query-ingame-decision-item-v1\",\"read_only\":true,\"game_version\":\"1.20.0.3\",\"executable_sha256\":\"94B55397ABB687A3DCD436805A5D885E6BE90FA6C693FEB44A9E3BBEEADE02A6\"";
  const auto number=[&](const char *key,auto n){s+=",\"";s+=key;s+="\":";s+=std::to_string(n);};
  const auto boolean=[&](const char *key,bool b){s+=",\"";s+=key;s+="\":";s+=b?"true":"false";};
  const auto text=[&](const char *key,const std::string &value){s+=",\"";s+=key;s+="\":\"";s+=value;s+='"';};
  number("native_revision",v.native_revision);number("connection_generation",v.connection_generation);number("game_pid",v.game_pid);
  number("played_character_id",v.played_character_id);number("date_raw",v.date_raw);number("group_count",v.group_count);
  number("row_count",v.row_count);number("matching_row_count",v.matching_row_count);number("row_context_reference_key",v.row_context_reference_key);
  number("detail_actor_reference_key",v.detail_actor_reference_key);
  boolean("available",v.available);boolean("owner_thread_verified",v.owner_thread_verified);boolean("frame_verified",v.frame_verified);
  boolean("source_abi_pins_verified",v.source_abi_pins_verified);boolean("gui_owner_binding_verified",v.gui_owner_binding_verified);
  boolean("decisions_tree_complete",v.decisions_tree_complete);boolean("decisions_root_visible",v.decisions_root_visible);
  boolean("row_owner_verified",v.row_owner_verified);boolean("row_scope_reference_available",v.row_scope_reference_available);
  boolean("detail_tree_complete",v.detail_tree_complete);boolean("detail_root_visible",v.detail_root_visible);
  boolean("detail_definition_available",v.detail_definition_available);boolean("detail_definition_matches_target",v.detail_definition_matches_target);
  boolean("detail_actor_binding_verified",v.detail_actor_binding_verified);
  // Scope/context scalar is observed but deliberately not cast to player identity or action qualification.
  boolean("row_widget_datacontext_verified",false);boolean("action_qualified",false);
  if(!v.model_failed_stage.empty()){
    text("model_read_pass",v.model_read_pass);text("model_failed_stage",v.model_failed_stage);
    number("model_observed_pointer",v.model_observed_pointer);number("model_expected_pointer",v.model_expected_pointer);
  }
  text("decision_key",v.decision_key);text("detail_decision_key",v.detail_decision_key);text("unavailable_reason",v.unavailable_reason);return s+'}';
}
std::string SerializeIngameDecisionItemActionV1(const IngameDecisionItemActionResultV1 &v){
  const bool select=v.action==IngameDecisionItemActionKindV1::select;
  std::string s="{\"schema\":\"ck3-ingame-decision-item-action-v1\",\"step\":\"";
  s+=select?kIngameDecisionItemSelectV1Step:kIngameDecisionItemConfirmV1Step;
  s+="\",\"action\":\"";s+=select?"select":"confirm";
  s+="\",\"game_version\":\"1.20.0.3\",\"executable_sha256\":\"94B55397ABB687A3DCD436805A5D885E6BE90FA6C693FEB44A9E3BBEEADE02A6\"";
  const auto number=[&](const char *key,auto n){s+=",\"";s+=key;s+="\":";s+=std::to_string(n);};
  const auto boolean=[&](const char *key,bool b){s+=",\"";s+=key;s+="\":";s+=b?"true":"false";};
  const auto text=[&](const char *key,const std::string &value){s+=",\"";s+=key;s+="\":\"";s+=value;s+='"';};
  number("native_revision",v.before.native_revision);number("connection_generation",v.before.connection_generation);
  number("game_pid",v.before.game_pid);number("played_character_id",v.before.played_character_id);number("date_raw",v.before.date_raw);
  boolean("owner_thread_verified",v.before.owner_thread_verified);boolean("source_abi_pins_verified",v.before.source_abi_pins_verified);
  boolean("action_abi_pins_verified",v.action_abi_pins_verified);boolean("receiver_qualified",v.receiver_qualified);
  boolean("detail_actor_binding_verified",v.detail_actor_binding_verified);boolean("no_blocking_modal_verified",v.no_blocking_modal_verified);
  boolean("before_already_selected",v.before_already_selected);boolean("dispatch_invoked",v.dispatch_invoked);
  boolean("native_call_completed",v.native_call_completed);boolean("native_handled",v.native_handled);
  boolean("gui_owner_binding_verified",v.gui_owner_binding_verified);boolean("frame_verified",v.frame_verified);
  boolean("native_after_read",v.native_after_read);boolean("selected_after_verified",v.selected_after_verified);
  boolean("inner_modal_visible",v.inner_modal_visible);boolean("inner_modal_tree_complete",v.inner_modal_tree_complete);
  boolean("postcondition_verified",v.postcondition_verified);boolean("verification_pending",!v.postcondition_verified&&(v.dispatch_invoked||v.before_already_selected));
  text("decision_key",v.before.decision_key);text("target_child_path",v.target_child_path);text("status",v.status);text("unavailable_reason",v.unavailable_reason);
  s+=",\"before_actual_model\":";s+=baseline::SerializeIngameDecisionItemV1(v.before);
  s+=",\"after_actual_model\":";s+=baseline::SerializeIngameDecisionItemV1(v.after);return s+'}';
}
}
namespace candidate {
using namespace xar::ck3_11906;
std::string SerializeIngameDecisionItemV1(const IngameDecisionItemResultV1 &v) {
  std::string s="{\"schema\":\"ck3-ingame-decision-item-v1\",\"step\":\"query-ingame-decision-item-v1\",\"read_only\":true,\"game_version\":\"1.20.0.3\",\"executable_sha256\":\"94B55397ABB687A3DCD436805A5D885E6BE90FA6C693FEB44A9E3BBEEADE02A6\"";
  const auto number=[&](const char *key,auto n){s+=",\"";s+=key;s+="\":";s+=std::to_string(n);};
  const auto boolean=[&](const char *key,bool b){s+=",\"";s+=key;s+="\":";s+=b?"true":"false";};
  const auto text=[&](const char *key,const std::string &value){s+=",\"";s+=key;s+="\":\"";s+=value;s+='"';};
  number("native_revision",v.native_revision);number("connection_generation",v.connection_generation);number("game_pid",v.game_pid);
  number("played_character_id",v.played_character_id);number("date_raw",v.date_raw);number("group_count",v.group_count);
  number("row_count",v.row_count);number("matching_row_count",v.matching_row_count);number("row_context_reference_key",v.row_context_reference_key);
  number("detail_actor_reference_key",v.detail_actor_reference_key);
  boolean("available",v.available);boolean("owner_thread_verified",v.owner_thread_verified);boolean("frame_verified",v.frame_verified);
  boolean("source_abi_pins_verified",v.source_abi_pins_verified);boolean("gui_owner_binding_verified",v.gui_owner_binding_verified);
  boolean("decisions_tree_complete",v.decisions_tree_complete);boolean("decisions_root_visible",v.decisions_root_visible);
  boolean("row_owner_verified",v.row_owner_verified);boolean("row_scope_reference_available",v.row_scope_reference_available);
  boolean("detail_tree_complete",v.detail_tree_complete);boolean("detail_root_visible",v.detail_root_visible);
  boolean("detail_definition_available",v.detail_definition_available);boolean("detail_definition_matches_target",v.detail_definition_matches_target);
  boolean("detail_actor_binding_verified",v.detail_actor_binding_verified);
  // Scope/context scalar is observed but deliberately not cast to player identity or action qualification.
  boolean("row_widget_datacontext_verified",false);boolean("action_qualified",false);
  if(!v.model_failed_stage.empty()){
    text("model_read_pass",v.model_read_pass);text("model_failed_stage",v.model_failed_stage);
    number("model_observed_pointer",v.model_observed_pointer);number("model_expected_pointer",v.model_expected_pointer);
  }
  text("decision_key",v.decision_key);text("detail_decision_key",v.detail_decision_key);text("unavailable_reason",v.unavailable_reason);return s+'}';
}
std::string SerializeIngameDecisionItemActionV1(const IngameDecisionItemActionResultV1 &v){
  const bool select=v.action==IngameDecisionItemActionKindV1::select;
  const bool outcome=v.action==IngameDecisionItemActionKindV1::confirm_outcome;
  std::string s="{\"schema\":\"";s+=outcome?"ck3-ingame-decision-outcome-confirm-v1":"ck3-ingame-decision-item-action-v1";
  s+="\",\"step\":\"";
  s+=outcome?kIngameDecisionOutcomeConfirmV1Step:select?kIngameDecisionItemSelectV1Step:kIngameDecisionItemConfirmV1Step;
  s+="\",\"action\":\"";s+=outcome?"confirm_outcome":select?"select":"confirm";
  s+="\",\"game_version\":\"1.20.0.3\",\"executable_sha256\":\"94B55397ABB687A3DCD436805A5D885E6BE90FA6C693FEB44A9E3BBEEADE02A6\"";
  const auto number=[&](const char *key,auto n){s+=",\"";s+=key;s+="\":";s+=std::to_string(n);};
  const auto boolean=[&](const char *key,bool b){s+=",\"";s+=key;s+="\":";s+=b?"true":"false";};
  const auto text=[&](const char *key,const std::string &value){s+=",\"";s+=key;s+="\":\"";s+=value;s+='"';};
  number("native_revision",v.before.native_revision);number("connection_generation",v.before.connection_generation);
  number("game_pid",v.before.game_pid);number("played_character_id",v.before.played_character_id);number("date_raw",v.before.date_raw);
  boolean("owner_thread_verified",v.before.owner_thread_verified);boolean("source_abi_pins_verified",v.before.source_abi_pins_verified);
  boolean("action_abi_pins_verified",v.action_abi_pins_verified);boolean("receiver_qualified",v.receiver_qualified);
  boolean("detail_actor_binding_verified",v.detail_actor_binding_verified);boolean("no_blocking_modal_verified",v.no_blocking_modal_verified);
  boolean("before_already_selected",v.before_already_selected);boolean("dispatch_invoked",v.dispatch_invoked);
  boolean("native_call_completed",v.native_call_completed);boolean("native_handled",v.native_handled);
  boolean("gui_owner_binding_verified",v.gui_owner_binding_verified);boolean("frame_verified",v.frame_verified);
  boolean("native_after_read",v.native_after_read);boolean("selected_after_verified",v.selected_after_verified);
  boolean("inner_modal_visible",v.inner_modal_visible);boolean("inner_modal_tree_complete",v.inner_modal_tree_complete);
  boolean("postcondition_verified",v.postcondition_verified);boolean("verification_pending",!v.postcondition_verified&&(v.dispatch_invoked||v.before_already_selected));
  text("decision_key",v.before.decision_key);text("target_child_path",v.target_child_path);text("status",v.status);text("unavailable_reason",v.unavailable_reason);
  if(outcome){text("expected_outcome",v.expected_outcome);text("expected_event_definition_key",v.expected_event_definition_key);}
  s+=",\"before_actual_model\":";s+=candidate::SerializeIngameDecisionItemV1(v.before);
  s+=",\"after_actual_model\":";s+=candidate::SerializeIngameDecisionItemV1(v.after);return s+'}';
}
}

int main(){
  using namespace xar::ck3_11906;
  for(int n=0;n<128;++n){
    IngameDecisionItemActionResultV1 v{};
    v.action=(n&1)?IngameDecisionItemActionKindV1::select:IngameDecisionItemActionKindV1::confirm;
    v.before.available=(n&2)!=0;v.before.native_revision=3456+n;v.before.connection_generation=7;
    v.before.game_pid=234;v.before.played_character_id=31254;v.before.date_raw=53144376;
    v.before.decision_key="vivhite_courtier";v.before.detail_decision_key="vivhite_courtier";
    v.before.owner_thread_verified=(n&4)!=0;v.before.source_abi_pins_verified=(n&8)!=0;
    v.receiver_qualified=(n&16)!=0;v.native_handled=(n&32)!=0;v.dispatch_invoked=(n&64)!=0;
    v.native_call_completed=v.dispatch_invoked;v.frame_verified=true;v.postcondition_verified=(n&8)!=0;
    v.status=v.postcondition_verified?"observed_postcondition":"acknowledged_verification_pending";
    v.target_child_path="0/2/1";v.after=v.before;
    v.expected_outcome="event_window";v.expected_event_definition_key="lyd.010";
    assert(baseline::SerializeIngameDecisionItemActionV1(v)==candidate::SerializeIngameDecisionItemActionV1(v));
  }
  IngameDecisionItemActionResultV1 v{};v.action=IngameDecisionItemActionKindV1::confirm_outcome;
  v.expected_outcome="event_window";v.expected_event_definition_key="lyd_im.1";
  v.dispatch_invoked=true;v.native_call_completed=true;v.postcondition_verified=false;
  const auto json=candidate::SerializeIngameDecisionItemActionV1(v);
  assert(json.find("\"schema\":\"ck3-ingame-decision-outcome-confirm-v1\"")!=std::string::npos);
  assert(json.find("\"step\":\"confirm-ingame-decision-outcome-v1\"")!=std::string::npos);
  assert(json.find("\"action\":\"confirm_outcome\"")!=std::string::npos);
  assert(json.find("\"expected_event_definition_key\":\"lyd_im.1\"")!=std::string::npos);
  assert(json.find("\"postcondition_verified\":false")!=std::string::npos);
  assert(json.find("\"verification_pending\":true")!=std::string::npos);
  v.expected_outcome="decision_closed";v.expected_event_definition_key="";
  const auto state=candidate::SerializeIngameDecisionItemActionV1(v);
  assert(state.find("\"expected_outcome\":\"decision_closed\"")!=std::string::npos);
  assert(state.find("\"expected_event_definition_key\":\"\"")!=std::string::npos);
  std::cout<<"PASS: 128 legacy select/confirm literal production serializer projections byte-identical; two typed outcome ACKs preserve pending\n";
}
