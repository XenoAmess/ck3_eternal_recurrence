from pathlib import Path
import hashlib,json,shutil,subprocess,difflib
out=Path(__file__).parent
root=Path('C:/workspace/ck3_eternal_recurrence/ck3_autonomous_player/native_bridge')
candidate=Path('C:/ldn5/source')
if candidate.exists():raise SystemExit('new source root already exists')
candidate.mkdir(parents=True)
snapshot=[]
for source in root.rglob('*'):
    rel=source.relative_to(root)
    if any(p.startswith('build') for p in rel.parts) or not source.is_file():continue
    data=source.read_bytes();target=candidate/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    snapshot.append({'path':rel.as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'source-snapshot-manifest.json').write_text(json.dumps(snapshot,indent=2)+'\n',encoding='utf-8')
changed=[]
def patch(rel,pairs):
    p=candidate/rel;data=p.read_bytes();text=data.decode('utf-8-sig')
    before=out/'before'/rel;before.parent.mkdir(parents=True,exist_ok=True)
    if before.exists() and before.read_bytes()!=data:raise RuntimeError('before source drift '+rel)
    before.write_bytes(data)
    for old,new in pairs:
        if text.count(old)!=1:raise RuntimeError(f'patch count {rel} {text.count(old)} {old[:80]}')
        text=text.replace(old,new)
    after=text.encode('utf-8');p.write_bytes(after)
    target=out/'candidate'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(after)
    (out/'diffs').mkdir(exist_ok=True)
    (out/'diffs'/ (rel.replace('/','__')+'.diff')).write_text(''.join(difflib.unified_diff(data.decode('utf-8-sig').splitlines(True),text.splitlines(True),fromfile='before/'+rel,tofile='candidate/'+rel)),encoding='utf-8')
    changed.append({'path':rel,'before_sha256':hashlib.sha256(data).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest()})
def new(rel,text):
    if (candidate/rel).exists():raise RuntimeError('new path exists '+rel)
    data=text.encode('utf-8')
    for base in (candidate,out/'candidate'):
        p=base/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    changed.append({'path':rel,'before_sha256':None,'after_sha256':hashlib.sha256(data).hexdigest()})
new('include/xar_bridge/ingame_decision_outcome_contract_v1.hpp',r'''#pragma once
#include "xar_bridge/game_contract.hpp"
#include <string_view>
namespace xar::ck3_11906 {
inline bool IngameDecisionOutcomeKeySyntaxV1(std::string_view key) noexcept {
  if(key.empty()||key.size()>192)return false;
  for(char c:key)if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'))return false;
  return true;
}
inline bool IngameDecisionOutcomeRequestValidV1(std::string_view outcome,std::string_view event_key) noexcept {
  if(outcome=="decision_closed")return event_key.empty();
  if(outcome!="event_window"||event_key.size()>192)return false;
  const auto dot=event_key.find('.');
  return dot!=std::string_view::npos&&dot>0&&dot+1<event_key.size()&&event_key.find('.',dot+1)==std::string_view::npos&&
      IngameDecisionOutcomeKeySyntaxV1(event_key.substr(0,dot))&&IngameDecisionOutcomeKeySyntaxV1(event_key.substr(dot+1));
}
// ReadSnapshot contains business data as well as control-frame data. The current
// generic route admits resource/stress effects, and event fields only for the
// event-window branch. This comparison proves no product effect or event identity.
inline bool IngameDecisionOutcomeFrameMatchesV1(const game::Snapshot &before,
    const game::Snapshot &observed,std::string_view outcome) {
  if(before.has_active_event||!before.paused||!before.map_ready||!before.has_played_character||
      !before.played_character_alive||before.played_character_id<=0||
      (outcome!="event_window"&&outcome!="decision_closed"))return false;
  auto normalized=observed;
  normalized.played_character_stress_points=before.played_character_stress_points;
  normalized.played_character_gold=before.played_character_gold;
  normalized.played_character_prestige=before.played_character_prestige;
  normalized.played_character_piety=before.played_character_piety;
  if(outcome=="event_window"){
    normalized.has_active_event=before.has_active_event;
    normalized.active_event_instance_id=before.active_event_instance_id;
    normalized.active_event_option_count=before.active_event_option_count;
  }
  return normalized==before;
}
} // namespace xar::ck3_11906
''')
patch('include/xar_bridge/ingame_decision_item_v1.hpp',[
('#include "xar_bridge/game_adapter.hpp"','#include "xar_bridge/game_adapter.hpp"\n#include "xar_bridge/ingame_decision_outcome_contract_v1.hpp"'),
('struct IngameDecisionItemResultV1 {','inline constexpr std::string_view kIngameDecisionOutcomeConfirmV1Step = "confirm-ingame-decision-outcome-v1";\ninline constexpr std::string_view kIngameDecisionOutcomeConfirmV1Capability = "game.command.confirm-ingame-decision-outcome-v1";\nstruct IngameDecisionItemResultV1 {'),
('enum class IngameDecisionItemActionKindV1 { select, confirm };','enum class IngameDecisionItemActionKindV1 { select, confirm, confirm_outcome };'),
('std::string target_child_path,status="unavailable",unavailable_reason;','std::string target_child_path,status="unavailable",unavailable_reason;\n  std::string expected_outcome,expected_event_definition_key;'),
('std::string expected_window_kind;','std::string expected_window_kind;\n  std::string expected_outcome,expected_event_definition_key;')])
patch('src/ingame_decision_item_v1.cpp',[
('auto &out=query.result;out={};out.action=query.action;','auto &out=query.result;out={};out.action=query.action;\n  const bool outcome=query.action==IngameDecisionItemActionKindV1::confirm_outcome;\n  if(outcome){out.expected_outcome=query.expected_outcome;out.expected_event_definition_key=query.expected_event_definition_key;}'),
('if(!ExecuteIngameDecisionItemQueryV1(query.observation,mailbox,stamp,env))return reject("keyed_before_execution_unavailable");','if(outcome&&(!IngameDecisionOutcomeRequestValidV1(query.expected_outcome,query.expected_event_definition_key)||\n        query.observation.expected_snapshot.has_active_event))return reject("typed_outcome_or_empty_event_before_unqualified");\n    if(!ExecuteIngameDecisionItemQueryV1(query.observation,mailbox,stamp,env))return reject("keyed_before_execution_unavailable");'),
('if(query.expected_window_kind!="vivhite_courtier")return reject("fixed_expected_modal_scope_unavailable");','if(!outcome&&query.expected_window_kind!="vivhite_courtier")return reject("fixed_expected_modal_scope_unavailable");'),
('bool modal_before=false,modal_complete=false;\n      if(!InnerPanel(env,context,query.expected_window_kind,modal_before,modal_complete)||!modal_complete||modal_before)\n        return reject("actual_expected_inner_modal_before_not_closed_or_incomplete");','if(outcome){\n        if(!NoVisibleModals(context))return reject("source_outcome_confirm_blocked_by_visible_modal");\n        out.no_blocking_modal_verified=true;\n      }else{\n        bool modal_before=false,modal_complete=false;\n        if(!InnerPanel(env,context,query.expected_window_kind,modal_before,modal_complete)||!modal_complete||modal_before)\n          return reject("actual_expected_inner_modal_before_not_closed_or_incomplete");\n      }'),
('// Resolve and qualify the source receiver again immediately before its one dispatcher invocation.','// Resolve and qualify the source receiver again immediately before its one dispatcher invocation.\n      if(outcome&&!NoVisibleModals(context))return reject("source_outcome_confirm_predispatch_modal_changed");'),
('out.dispatch_invoked=DispatchFixedGuiWidgetNativeV1(&dispatch,game::ZhongguoScoreboardActionV1::open,target,vtable,out.native_handled);\n      if(!out.dispatch_invoked)return reject("native_confirm_dispatch_failed_no_retry");\n      // Take first sets open_pending. Only the production GUI bridge can open the actual inner modal.\n      out.native_after_read=InnerPanel(env,context,query.expected_window_kind,out.inner_modal_visible,out.inner_modal_tree_complete);','if(outcome){\n        out.dispatch_invoked=true; // Consume the one attempt before entering the original dispatcher, including faults.\n        out.native_call_completed=DispatchFixedGuiWidgetNativeV1(&dispatch,game::ZhongguoScoreboardActionV1::open,target,vtable,out.native_handled);\n        if(!out.native_call_completed)return reject("native_outcome_confirm_result_unknown_no_retry");\n        // An ACK cannot prove either event identity or business state. An independent fresh reader must follow.\n      }else{\n        out.dispatch_invoked=DispatchFixedGuiWidgetNativeV1(&dispatch,game::ZhongguoScoreboardActionV1::open,target,vtable,out.native_handled);\n        if(!out.dispatch_invoked)return reject("native_confirm_dispatch_failed_no_retry");\n        // Take first sets open_pending. Only the production GUI bridge can open the actual inner modal.\n        out.native_after_read=InnerPanel(env,context,query.expected_window_kind,out.inner_modal_visible,out.inner_modal_tree_complete);\n      }'),
('out.frame_verified=game::ReadSnapshot(*query.observation.game,after)&&after==query.observation.expected_snapshot&&ActualActor(env,out.before.played_character_id);','out.frame_verified=game::ReadSnapshot(*query.observation.game,after)&&\n        (outcome?IngameDecisionOutcomeFrameMatchesV1(query.observation.expected_snapshot,after,query.expected_outcome):\n            after==query.observation.expected_snapshot)&&ActualActor(env,out.before.played_character_id);'),
('out.postcondition_verified=out.gui_owner_binding_verified&&out.frame_verified&&','out.postcondition_verified=!outcome&&out.gui_owner_binding_verified&&out.frame_verified&&'),
('const bool select=v.action==IngameDecisionItemActionKindV1::select;\n  std::string s="{\\\"schema\\\":\\\"ck3-ingame-decision-item-action-v1\\\",\\\"step\\\":\\\"";\n  s+=select?kIngameDecisionItemSelectV1Step:kIngameDecisionItemConfirmV1Step;\n  s+="\\\",\\\"action\\\":\\\"";s+=select?"select":"confirm";','const bool select=v.action==IngameDecisionItemActionKindV1::select;\n  const bool outcome=v.action==IngameDecisionItemActionKindV1::confirm_outcome;\n  std::string s="{\\\"schema\\\":\\\"";s+=outcome?"ck3-ingame-decision-outcome-confirm-v1":"ck3-ingame-decision-item-action-v1";\n  s+="\\\",\\\"step\\\":\\\"";\n  s+=outcome?kIngameDecisionOutcomeConfirmV1Step:select?kIngameDecisionItemSelectV1Step:kIngameDecisionItemConfirmV1Step;\n  s+="\\\",\\\"action\\\":\\\"";s+=outcome?"confirm_outcome":select?"select":"confirm";'),
('text("decision_key",v.before.decision_key);text("target_child_path",v.target_child_path);text("status",v.status);text("unavailable_reason",v.unavailable_reason);','text("decision_key",v.before.decision_key);text("target_child_path",v.target_child_path);text("status",v.status);text("unavailable_reason",v.unavailable_reason);\n  if(outcome){text("expected_outcome",v.expected_outcome);text("expected_event_definition_key",v.expected_event_definition_key);}')])
patch('src/bridge.cpp',[
('} else if (step == xar::ck3_11906::kIngameDecisionItemSelectV1Step || step == xar::ck3_11906::kIngameDecisionItemConfirmV1Step) {','} else if (step == xar::ck3_11906::kIngameDecisionItemSelectV1Step || step == xar::ck3_11906::kIngameDecisionItemConfirmV1Step\n#if defined(XAR_CK3_ENABLE_INGAME_DECISION_OUTCOME_PRIVATE_V1)\n              || step == xar::ck3_11906::kIngameDecisionOutcomeConfirmV1Step\n#endif\n              ) {'),
('std::string decision_key,window_kind; xar::game::Snapshot current{};','std::string decision_key,window_kind,expected_outcome,event_key; xar::game::Snapshot current{};'),
('const bool select=step==xar::ck3_11906::kIngameDecisionItemSelectV1Step;','const bool select=step==xar::ck3_11906::kIngameDecisionItemSelectV1Step;\n            const bool outcome=step==xar::ck3_11906::kIngameDecisionOutcomeConfirmV1Step;'),
('(!select&&(!xar::bridge::JsonStringField(incoming.payload,"expected_window_kind",window_kind,32)||window_kind!="vivhite_courtier")) ||','(!select&&!outcome&&(!xar::bridge::JsonStringField(incoming.payload,"expected_window_kind",window_kind,32)||window_kind!="vivhite_courtier")) ||\n                (outcome&&(!xar::bridge::JsonStringField(incoming.payload,"expected_outcome",expected_outcome,32)||\n                  !xar::bridge::JsonStringField(incoming.payload,"expected_event_definition_key",event_key,192)||\n                  !xar::ck3_11906::IngameDecisionOutcomeRequestValidV1(expected_outcome,event_key))) ||'),
('current.played_character_id<=0 || expected_actor!=static_cast<std::uint64_t>(current.played_character_id) ||\n                game.descriptor().game_version!="1.20.0.3" ||\n                game.descriptor().executable_sha256!="94B55397ABB687A3DCD436805A5D885E6BE90FA6C693FEB44A9E3BBEEADE02A6") {\n              connected=write_frame(pipe,CommandResultFrame(request_id,step,false,"exact_alive_paused_decision_action_binding_changed"));','current.played_character_id<=0 || expected_actor!=static_cast<std::uint64_t>(current.played_character_id) ||\n                (outcome&&current.has_active_event) ||\n                game.descriptor().game_version!="1.20.0.3" ||\n                game.descriptor().executable_sha256!="94B55397ABB687A3DCD436805A5D885E6BE90FA6C693FEB44A9E3BBEEADE02A6") {\n              connected=write_frame(pipe,CommandResultFrame(request_id,step,false,"exact_alive_paused_decision_action_binding_changed"));'),
('action.action=select?xar::ck3_11906::IngameDecisionItemActionKindV1::select:xar::ck3_11906::IngameDecisionItemActionKindV1::confirm;','action.action=outcome?xar::ck3_11906::IngameDecisionItemActionKindV1::confirm_outcome:\n                  select?xar::ck3_11906::IngameDecisionItemActionKindV1::select:xar::ck3_11906::IngameDecisionItemActionKindV1::confirm;\n              action.expected_outcome=expected_outcome;action.expected_event_definition_key=event_key;'),
('if(!xar::game::ReadSnapshot(game,completion)||completion!=current||state_revision!=expected_revision) {\n                    action.result.frame_verified=false;action.result.postcondition_verified=false;','if(!xar::game::ReadSnapshot(game,completion)||\n                      (outcome?!xar::ck3_11906::IngameDecisionOutcomeFrameMatchesV1(current,completion,expected_outcome):completion!=current)||\n                      state_revision!=expected_revision) {\n                    action.result.frame_verified=false;action.result.postcondition_verified=false;')])
patch('src/ck3_12003_adapter.cpp',[
('result.push_back(ck3_11906::kIngameDecisionItemConfirmV1Capability);','result.push_back(ck3_11906::kIngameDecisionItemConfirmV1Capability);\n#if defined(XAR_CK3_ENABLE_INGAME_DECISION_OUTCOME_PRIVATE_V1)\n    result.push_back(ck3_11906::kIngameDecisionOutcomeConfirmV1Capability);\n#endif')])
patch('CMakeLists.txt',[
('option(\n  XAR_CK3_FEUDAL_1066_TARGET_ROBERT_V1','option(XAR_CK3_ENABLE_INGAME_DECISION_OUTCOME_PRIVATE_V1\n  "Admit guarded stock Confirm once with independent event-window or closed-detail verification" OFF)\nif(XAR_CK3_ENABLE_INGAME_DECISION_OUTCOME_PRIVATE_V1 AND\n   NOT XAR_CK3_ENABLE_INGAME_DECISION_ITEM_ACTIONS_PRIVATE_V1)\n  message(FATAL_ERROR "Decision outcome confirmation requires exact .3 keyed item actions")\nendif()\n\noption(\n  XAR_CK3_FEUDAL_1066_TARGET_ROBERT_V1'),
('    XAR_CK3_ENABLE_INGAME_DECISION_ITEM_ACTIONS_PRIVATE_V1\n','    XAR_CK3_ENABLE_INGAME_DECISION_ITEM_ACTIONS_PRIVATE_V1\n    XAR_CK3_ENABLE_INGAME_DECISION_OUTCOME_PRIVATE_V1\n'),
('if(XAR_CK3_ENABLE_FRONTEND_GAME_RULES_PRIVATE_V1)\n  target_compile_definitions','if(XAR_CK3_ENABLE_INGAME_DECISION_OUTCOME_PRIVATE_V1)\n  target_compile_definitions(xar_ck3_bridge PRIVATE XAR_CK3_ENABLE_INGAME_DECISION_OUTCOME_PRIVATE_V1=1)\nendif()\nif(XAR_CK3_ENABLE_FRONTEND_GAME_RULES_PRIVATE_V1)\n  target_compile_definitions'),
('# Fixed text memory/UTF-8 tests; this target never starts or attaches CK3.','# Outcome invariants are synthetic DTO tests and never start or attach CK3.\nif(BUILD_TESTING AND XAR_CK3_ENABLE_INGAME_DECISION_OUTCOME_PRIVATE_V1)\n  add_executable(xar_ck3_ingame_decision_outcome_contract_v1_test tests/ingame_decision_outcome_contract_v1_test.cpp)\n  target_include_directories(xar_ck3_ingame_decision_outcome_contract_v1_test PRIVATE include)\n  target_compile_features(xar_ck3_ingame_decision_outcome_contract_v1_test PRIVATE cxx_std_20)\n  if(MSVC)\n    target_compile_options(xar_ck3_ingame_decision_outcome_contract_v1_test PRIVATE /W4 /WX /EHsc /UNDEBUG)\n  endif()\n  add_test(NAME xar_ck3_ingame_decision_outcome_contract_v1 COMMAND xar_ck3_ingame_decision_outcome_contract_v1_test)\nendif()\n\n# Fixed text memory/UTF-8 tests; this target never starts or attaches CK3.')])
new('tests/ingame_decision_outcome_contract_v1_test.cpp',r'''#include "xar_bridge/ingame_decision_outcome_contract_v1.hpp"
#include <cassert>
#include <iostream>
using namespace xar::ck3_11906;
int main(){
  assert(IngameDecisionOutcomeRequestValidV1("event_window","lyd.010"));
  assert(IngameDecisionOutcomeRequestValidV1("decision_closed",""));
  for(auto invalid:{"","lyd",".010","lyd.","lyd.010.extra","lyd.0\"10","lyd.0/10"})
    assert(!IngameDecisionOutcomeRequestValidV1("event_window",invalid));
  assert(!IngameDecisionOutcomeRequestValidV1("decision_closed","lyd.010"));
  assert(!IngameDecisionOutcomeRequestValidV1("arbitrary_callback",""));
  xar::game::Snapshot before{};
  before.date_raw=53144376;before.speed=1;before.paused=true;before.player_id=0;before.map_ready=true;
  before.has_played_character=true;before.played_character_id=31254;before.played_character_alive=true;
  assert(IngameDecisionOutcomeFrameMatchesV1(before,before,"decision_closed"));
  auto business=before;business.played_character_stress_points=50;business.played_character_gold.raw=200000;
  business.played_character_piety.raw=900000;business.played_character_prestige.raw=40000;
  assert(IngameDecisionOutcomeFrameMatchesV1(before,business,"decision_closed"));
  auto opened=business;opened.has_active_event=true;opened.active_event_instance_id=23;opened.active_event_option_count=4;
  assert(IngameDecisionOutcomeFrameMatchesV1(before,opened,"event_window"));
  assert(!IngameDecisionOutcomeFrameMatchesV1(before,opened,"decision_closed"));
  auto changed=opened;++changed.date_raw;assert(!IngameDecisionOutcomeFrameMatchesV1(before,changed,"event_window"));
  changed=opened;changed.paused=false;assert(!IngameDecisionOutcomeFrameMatchesV1(before,changed,"event_window"));
  changed=opened;++changed.speed;assert(!IngameDecisionOutcomeFrameMatchesV1(before,changed,"event_window"));
  changed=opened;++changed.player_id;assert(!IngameDecisionOutcomeFrameMatchesV1(before,changed,"event_window"));
  changed=opened;++changed.played_character_id;assert(!IngameDecisionOutcomeFrameMatchesV1(before,changed,"event_window"));
  changed=opened;changed.played_character_alive=false;assert(!IngameDecisionOutcomeFrameMatchesV1(before,changed,"event_window"));
  changed=opened;changed.map_ready=false;assert(!IngameDecisionOutcomeFrameMatchesV1(before,changed,"event_window"));
  changed=opened;changed.has_played_character=false;assert(!IngameDecisionOutcomeFrameMatchesV1(before,changed,"event_window"));
  changed=opened;changed.played_character_spouse_ids.push_back(36311);assert(!IngameDecisionOutcomeFrameMatchesV1(before,changed,"event_window"));
  changed=opened;changed.has_pending_character_interaction=true;assert(!IngameDecisionOutcomeFrameMatchesV1(before,changed,"event_window"));
  changed=opened;changed.has_one_life_settlement=true;assert(!IngameDecisionOutcomeFrameMatchesV1(before,changed,"event_window"));
  auto blocked_before=before;blocked_before.has_active_event=true;
  assert(!IngameDecisionOutcomeFrameMatchesV1(blocked_before,blocked_before,"event_window"));
  assert(!IngameDecisionOutcomeFrameMatchesV1(before,before,"unknown"));
  std::cout<<"PASS: typed branch validation and controlled post-dispatch DTO invariants; no CK3 attached\n";
}
''')
(out/'delta-manifest.json').write_text(json.dumps(changed,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'candidate':str(candidate),'changed_files':len(changed),'source_files':len(snapshot)}))
