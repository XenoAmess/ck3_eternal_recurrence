from pathlib import Path
import hashlib,json,shutil,subprocess,os,time,difflib
out=Path(__file__).parent;source=Path('C:/ldn6/source');build=Path('C:/ldn6/build-002')
if not (out/'compiled-artifacts-003.json').exists():raise SystemExit('revision003 must complete')
if (out/'delta-manifest-revision-004.json').exists():raise SystemExit('revision004 exists')
shutil.copytree(source,Path('C:/ldn6/source-revision-003-preserved'))
shutil.copytree(build,Path('C:/ldn6/build-revision-003-preserved'))
delta=json.loads((out/'delta-manifest-revision-003.json').read_text(encoding='utf-8'))
normalization=[]
for entry in delta:
    rel=entry['path'];p=source/rel;before=p.read_bytes();data=before.replace(b'\r\n',b'\n')
    assert before.replace(b'\r\n',b'\n')==data
    p.write_bytes(data)
    target=out/'candidate-revision-004'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    entry['after_sha256']=hashlib.sha256(data).hexdigest();entry['bytes']=len(data)
    normalization.append({'path':rel,'revision003_sha256':hashlib.sha256(before).hexdigest(),'revision004_sha256':entry['after_sha256'],'only_LF_normalization':True})
    bp=out/'before'/rel;bt=bp.read_bytes().decode('utf-8-sig') if bp.exists() else ''
    target=out/'diffs-revision-004'/(rel.replace('/','__')+'.diff');target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(''.join(difflib.unified_diff(bt.splitlines(True),data.decode('utf-8-sig').splitlines(True),fromfile='before/'+rel,tofile='candidate/'+rel)).encode('utf-8'))
(out/'delta-manifest-revision-004.json').write_bytes((json.dumps(delta,indent=2)+'\n').encode('utf-8'))
(out/'LF-normalization-revision004.json').write_bytes((json.dumps(normalization,indent=2)+'\n').encode('utf-8'))
env=os.environ.copy()
for line in (out/'build-env-002.stdout').read_text(encoding='utf-8',errors='replace').splitlines():
    if '=' in line and not line.startswith('='):
        k,v=line.split('=',1);env[k]=v
cmake=Path('C:/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe')
records=[]
for label,args in [('compile-focused-contract-004',[cmake,'--build',build,'--target','xar_ck3_ingame_decision_outcome_contract_v1_test','--parallel','4']),('test-focused-contract-004',[build/'xar_ck3_ingame_decision_outcome_contract_v1_test.exe']),('compile-candidate-dll-004',[cmake,'--build',build,'--target','xar_ck3_bridge','--parallel','4'])]:
    started=time.time();p=subprocess.run([str(x) for x in args],env=env,capture_output=True)
    (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
    r={'label':label,'argv':[str(x) for x in args],'exit_code':p.returncode,'elapsed_seconds':time.time()-started};records.append(r)
    (out/'build-receipts-004.json').write_bytes((json.dumps(records,indent=2)+'\n').encode('utf-8'))
    print(json.dumps(r),flush=True)
    if p.returncode:raise SystemExit(p.returncode)
artifacts=[]
for rel in ['xar_ck3_bridge.dll','xar_ck3_ingame_decision_outcome_contract_v1_test.exe']:
    p=build/rel;data=p.read_bytes();target=out/'compiled-revision-004'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    artifacts.append({'path':str(p),'preserved_path':str(target),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'compiled-artifacts-004.json').write_bytes((json.dumps(artifacts,indent=2)+'\n').encode('utf-8'))
print(json.dumps({'compiled':'PASS','native_game':'NOT_RUN','artifacts':artifacts}),flush=True)
