from pathlib import Path
import os,subprocess,json,hashlib
out=Path(__file__).parent
env=os.environ.copy()
for line in (out/'build-env-002.stdout').read_text(encoding='utf-8',errors='replace').splitlines():
    if '=' in line and not line.startswith('='):
        key,value=line.split('=',1);env[key]=value
cl=Path('C:/Program Files/Microsoft Visual Studio/18/Community/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe')
args=[str(cl),'/nologo','/std:c++20','/EHsc','/W4','/WX','/UNDEBUG','/Gy','/I','C:/ldn6/source/include',str(out/'serialize-production-projection-test-002.cpp'),'/Fo:C:/ldn6/serializer-projection-002.obj','/Fe:C:/ldn6/serializer-projection-002.exe','/link','/OPT:REF']
records=[]
for label,command in [('compile-serializer-projection-002',args),('run-serializer-projection-002',['C:/ldn6/serializer-projection-002.exe'])]:
    result=subprocess.run(command,env=env,capture_output=True)
    (out/(label+'.stdout')).write_bytes(result.stdout);(out/(label+'.stderr')).write_bytes(result.stderr)
    records.append({'label':label,'argv':command,'exit_code':result.returncode})
    (out/'serializer-projection-receipts-002.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'label':label,'exit_code':result.returncode,'stdout':result.stdout.decode('mbcs',errors='replace')}))
    if result.returncode:raise SystemExit(result.returncode)
data=Path('C:/ldn6/serializer-projection-002.exe').read_bytes()
(out/'serializer-projection-artifact-002.json').write_text(json.dumps({'path':'C:/ldn6/serializer-projection-002.exe','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'proof':'Synthetic DTOs through exact literal production serializer bodies only; no native GUI or game route executed'},indent=2)+'\n',encoding='utf-8')
