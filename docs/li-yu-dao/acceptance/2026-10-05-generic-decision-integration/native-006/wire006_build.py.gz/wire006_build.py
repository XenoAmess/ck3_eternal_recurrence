from pathlib import Path
import hashlib,json,shutil,subprocess,os,time,difflib
out=Path(__file__).parent;source=Path('C:/ldn6/source');build=Path('C:/ldn6/build-002')
if not (out/'compiled-artifacts-005.json').exists():raise SystemExit('revision005 must complete; active inputs immutable')
if (out/'delta-manifest-revision-006.json').exists():raise SystemExit('revision006 exists')
shutil.copytree(source,Path('C:/ldn6/source-revision-005-preserved'))
shutil.copytree(build,Path('C:/ldn6/build-revision-005-preserved'))
rel='include/xar_bridge/ingame_decision_outcome_contract_v1.hpp';p=source/rel;t=p.read_bytes().decode('utf-8')
anchor='// ReadSnapshot contains business data as well as control-frame data.'
helper=r'''// Route-local empty-key parser for the compact native protocol. The shared
// JsonStringField intentionally rejects empty strings and remains unchanged.
inline bool IngameDecisionOutcomeEmptyEventKeyWireV1(std::string_view json) noexcept {
  constexpr std::string_view field="\"expected_event_definition_key\":";
  if(json.empty()||json.front()!='{'||json.back()!='}')return false;
  const auto at=json.find(field);
  if(at==std::string_view::npos||json.find(field,at+field.size())!=std::string_view::npos)return false;
  bool quoted=false,escaped=false;std::size_t objects=0,arrays=0;
  for(std::size_t i=0;i<at;++i){
    const char c=json[i];
    if(quoted){if(escaped)escaped=false;else if(c=='\\')escaped=true;else if(c=='"')quoted=false;}
    else if(c=='"')quoted=true;
    else if(c=='{')++objects;
    else if(c=='}'){if(!objects)return false;--objects;}
    else if(c=='[')++arrays;
    else if(c==']'){if(!arrays)return false;--arrays;}
  }
  if(quoted||objects!=1||arrays!=0||at==0||(json[at-1]!='{'&&json[at-1]!=','))return false;
  const auto value=at+field.size();
  return value+2<json.size()&&json[value]=='"'&&json[value+1]=='"'&&
      (json[value+2]==','||json[value+2]=='}');
}
'''
assert t.count(anchor)==1;t=t.replace(anchor,helper+anchor);p.write_bytes(t.encode('utf-8'))
rel='src/bridge.cpp';p=source/rel;t=p.read_bytes().decode('utf-8')
old='!xar::bridge::JsonStringField(incoming.payload,"expected_event_definition_key",event_key,192)||'
new='(expected_outcome=="decision_closed"?!xar::ck3_11906::IngameDecisionOutcomeEmptyEventKeyWireV1(incoming.payload):\n                    !xar::bridge::JsonStringField(incoming.payload,"expected_event_definition_key",event_key,192))||'
assert t.count(old)==1;t=t.replace(old,new);p.write_bytes(t.encode('utf-8'))
rel='CMakeLists.txt';p=source/rel;t=p.read_bytes().decode('utf-8')
old='add_executable(xar_ck3_ingame_decision_outcome_contract_v1_test tests/ingame_decision_outcome_contract_v1_test.cpp)'
new='add_executable(xar_ck3_ingame_decision_outcome_contract_v1_test\n    tests/ingame_decision_outcome_contract_v1_test.cpp src/protocol.cpp)'
assert t.count(old)==1;t=t.replace(old,new);p.write_bytes(t.encode('utf-8'))
rel='tests/ingame_decision_outcome_contract_v1_test.cpp';p=source/rel;t=p.read_bytes().decode('utf-8')
t=t.replace('#include <cassert>','#include "xar_bridge/protocol.hpp"\n#include <cassert>')
anchor='  xar::game::Snapshot before{};'
wire=r'''  const std::string closed_wire=R"({"expected_outcome":"decision_closed","expected_event_definition_key":""})";
  const std::string event_wire=R"({"expected_outcome":"event_window","expected_event_definition_key":"lyd_im.1"})";
  std::string parsed;
  assert(!xar::bridge::JsonStringField(closed_wire,"expected_event_definition_key",parsed,192));
  assert(IngameDecisionOutcomeEmptyEventKeyWireV1(closed_wire));
  assert(xar::bridge::JsonStringField(event_wire,"expected_event_definition_key",parsed,192)&&parsed=="lyd_im.1");
  assert(IngameDecisionOutcomeRequestValidV1("event_window",parsed));
  for(auto invalid:{R"({"expected_outcome":"decision_closed"})",
      R"({"expected_event_definition_key":null})",R"({"expected_event_definition_key":"lyd_im.1"})",
      R"({"expected_event_definition_key":"","expected_event_definition_key":""})",
      R"({"nested":{"expected_event_definition_key":""}})",
      R"({"nested":[{"expected_event_definition_key":""}]})",
      R"({"expected_event_definition_key":"\u0000"})",
      R"({"expected_event_definition_key":"\""})",
      R"({"expected_event_definition_key":""junk})"})
    assert(!IngameDecisionOutcomeEmptyEventKeyWireV1(invalid));
'''
assert t.count(anchor)==1;t=t.replace(anchor,wire+anchor);p.write_bytes(t.encode('utf-8'))
delta=json.loads((out/'delta-manifest-revision-005.json').read_text(encoding='utf-8'))
for entry in delta:
    rel=entry['path'];data=(source/rel).read_bytes();target=out/'candidate-revision-006'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    entry['after_sha256']=hashlib.sha256(data).hexdigest();entry['bytes']=len(data)
    bp=out/'before-revision-005'/rel;bt=bp.read_bytes().decode('utf-8-sig') if bp.exists() else ''
    target=out/'diffs-revision-006'/(rel.replace('/','__')+'.diff');target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(''.join(difflib.unified_diff(bt.splitlines(True),data.decode('utf-8-sig').splitlines(True),fromfile='before/'+rel,tofile='candidate/'+rel)).encode('utf-8'))
(out/'delta-manifest-revision-006.json').write_bytes((json.dumps(delta,indent=2)+'\n').encode('utf-8'))
env=os.environ.copy()
for line in (out/'build-env-002.stdout').read_text(encoding='utf-8',errors='replace').splitlines():
    if '=' in line and not line.startswith('='):
        k,v=line.split('=',1);env[k]=v
cmake=Path('C:/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe')
records=[]
for label,args in [('compile-focused-contract-006',[cmake,'--build',build,'--target','xar_ck3_ingame_decision_outcome_contract_v1_test','--parallel','4']),('test-focused-contract-006',[build/'xar_ck3_ingame_decision_outcome_contract_v1_test.exe']),('compile-candidate-dll-006',[cmake,'--build',build,'--target','xar_ck3_bridge','--parallel','4'])]:
    started=time.time();p=subprocess.run([str(x) for x in args],env=env,capture_output=True)
    (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
    r={'label':label,'argv':[str(x) for x in args],'exit_code':p.returncode,'elapsed_seconds':time.time()-started};records.append(r)
    (out/'build-receipts-006.json').write_bytes((json.dumps(records,indent=2)+'\n').encode('utf-8'))
    print(json.dumps(r),flush=True)
    if p.returncode:raise SystemExit(p.returncode)
artifacts=[]
for rel in ['xar_ck3_bridge.dll','xar_ck3_ingame_decision_outcome_contract_v1_test.exe']:
    p=build/rel;data=p.read_bytes();target=out/'compiled-revision-006'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    artifacts.append({'path':str(p),'preserved_path':str(target),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'compiled-artifacts-006.json').write_bytes((json.dumps(artifacts,indent=2)+'\n').encode('utf-8'))
print(json.dumps({'compiled':'PASS','native_game':'NOT_RUN','artifacts':artifacts}),flush=True)
