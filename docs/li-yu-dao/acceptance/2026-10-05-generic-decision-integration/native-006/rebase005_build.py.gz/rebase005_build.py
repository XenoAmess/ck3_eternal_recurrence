from pathlib import Path
import hashlib,json,shutil,subprocess,os,time,difflib
out=Path(__file__).parent;source=Path('C:/ldn6/source');build=Path('C:/ldn6/build-002');checkout=Path('C:/workspace/ck3_eternal_recurrence/ck3_autonomous_player/native_bridge')
if not (out/'compiled-artifacts-004.json').exists():raise SystemExit('revision004 must complete')
if (out/'delta-manifest-revision-005.json').exists():raise SystemExit('revision005 exists')
shutil.copytree(source,Path('C:/ldn6/source-revision-004-preserved'))
shutil.copytree(build,Path('C:/ldn6/build-revision-004-preserved'))
old_delta=json.loads((out/'delta-manifest-revision-004.json').read_text(encoding='utf-8'));targets={e['path'] for e in old_delta};baseline=[];source_changes=[]
for p in checkout.rglob('*'):
    rel=p.relative_to(checkout)
    if not p.is_file() or any(x.startswith('build') for x in rel.parts):continue
    data=p.read_bytes();relative=rel.as_posix();baseline.append({'path':relative,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
    if relative not in targets:
        target=source/rel
        previous=target.read_bytes() if target.exists() else None
        if previous!=data:
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
            source_changes.append({'path':relative,'old_sha256':hashlib.sha256(previous).hexdigest() if previous is not None else None,'new_sha256':hashlib.sha256(data).hexdigest()})
delta=[]
for entry in old_delta:
    rel=entry['path'];p=checkout/rel;before=p.read_bytes() if p.exists() else None
    if rel=='src/ck3_12003_adapter.cpp':
        text=before.decode('utf-8-sig');anchor='result.push_back(ck3_11906::kIngameDecisionItemConfirmV1Capability);'
        assert text.count(anchor)==1
        data=text.replace(anchor,anchor+'\n#if defined(XAR_CK3_ENABLE_INGAME_DECISION_OUTCOME_PRIVATE_V1)\n    result.push_back(ck3_11906::kIngameDecisionOutcomeConfirmV1Capability);\n#endif').encode('utf-8')
    else:
        actual=hashlib.sha256(before).hexdigest() if before is not None else None
        if actual!=entry['before_sha256']:raise SystemExit('new target drift requiring reviewed rebase '+rel)
        data=(out/'candidate-revision-004'/rel).read_bytes()
    if before is not None:
        target=out/'before-revision-005'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(before)
    target=out/'candidate-revision-005'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    target=source/rel
    if not target.exists() or target.read_bytes()!=data:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    delta.append({'path':rel,'before_sha256':hashlib.sha256(before).hexdigest() if before is not None else None,'after_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
    target=out/'diffs-revision-005'/(rel.replace('/','__')+'.diff');target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(''.join(difflib.unified_diff(before.decode('utf-8-sig').splitlines(True) if before is not None else [],data.decode('utf-8-sig').splitlines(True),fromfile='before/'+rel,tofile='candidate/'+rel)).encode('utf-8'))
(out/'delta-manifest-revision-005.json').write_bytes((json.dumps(delta,indent=2)+'\n').encode('utf-8'))
(out/'rebase005-current-native-baseline.json').write_bytes((json.dumps({'checkout_head':subprocess.run(['git','rev-parse','HEAD'],cwd=str(checkout),capture_output=True,check=True).stdout.decode().strip(),'files':baseline,'non_target_native_source_changes':source_changes,'adapter_three_way_rebase':'Only outcome capability append applied to current source; upstream army loss bindings retained unchanged.'},indent=2)+'\n').encode('utf-8'))
env=os.environ.copy()
for line in (out/'build-env-002.stdout').read_text(encoding='utf-8',errors='replace').splitlines():
    if '=' in line and not line.startswith('='):
        k,v=line.split('=',1);env[k]=v
cmake=Path('C:/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe')
records=[]
for label,args in [('compile-focused-contract-005',[cmake,'--build',build,'--target','xar_ck3_ingame_decision_outcome_contract_v1_test','--parallel','4']),('test-focused-contract-005',[build/'xar_ck3_ingame_decision_outcome_contract_v1_test.exe']),('compile-candidate-dll-005',[cmake,'--build',build,'--target','xar_ck3_bridge','--parallel','4'])]:
    started=time.time();p=subprocess.run([str(x) for x in args],env=env,capture_output=True)
    (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
    r={'label':label,'argv':[str(x) for x in args],'exit_code':p.returncode,'elapsed_seconds':time.time()-started};records.append(r)
    (out/'build-receipts-005.json').write_bytes((json.dumps(records,indent=2)+'\n').encode('utf-8'))
    print(json.dumps(r),flush=True)
    if p.returncode:raise SystemExit(p.returncode)
artifacts=[]
for rel in ['xar_ck3_bridge.dll','xar_ck3_ingame_decision_outcome_contract_v1_test.exe']:
    p=build/rel;data=p.read_bytes();target=out/'compiled-revision-005'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    artifacts.append({'path':str(p),'preserved_path':str(target),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'compiled-artifacts-005.json').write_bytes((json.dumps(artifacts,indent=2)+'\n').encode('utf-8'))
print(json.dumps({'compiled':'PASS','native_game':'NOT_RUN','artifacts':artifacts,'non_target_native_source_changes':len(source_changes)}),flush=True)
