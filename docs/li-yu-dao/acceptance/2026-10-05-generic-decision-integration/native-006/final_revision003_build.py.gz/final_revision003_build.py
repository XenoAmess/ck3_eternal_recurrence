from pathlib import Path
import hashlib,json,shutil,subprocess,os,time,difflib
out=Path(__file__).parent
source=Path('C:/ldn6/source');build=Path('C:/ldn6/build-002')
if not (out/'compiled-artifacts-002.json').exists():raise SystemExit('revision002 full build has not completed; do not mutate its source')
if (out/'delta-manifest-revision-003.json').exists():raise SystemExit('revision003 already exists')
shutil.copytree(source,Path('C:/ldn6/source-revision-002-preserved'))
shutil.copytree(build,Path('C:/ldn6/build-revision-002-preserved'))
preserved=[]
for rel in ['xar_ck3_bridge.dll','xar_ck3_ingame_decision_outcome_contract_v1_test.exe']:
    p=Path('C:/ldn6/build-revision-002-preserved')/rel;data=p.read_bytes();preserved.append({'path':str(p),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(out/'revision002-preserved-build-artifacts.json').write_text(json.dumps(preserved,indent=2)+'\n',encoding='utf-8')
rel='include/xar_bridge/ingame_decision_outcome_contract_v1.hpp'
p=source/rel;t=p.read_text(encoding='utf-8')
for field in ['gold','prestige','piety']:
    t=t.replace(f'normalized.played_character_{field}=before.played_character_{field};',f'normalized.played_character_{field}.raw=before.played_character_{field}.raw;')
p.write_text(t,encoding='utf-8')
rel='tests/ingame_decision_outcome_contract_v1_test.cpp'
p=source/rel;t=p.read_text(encoding='utf-8')
add=''
for field in ['gold','prestige','piety']:
    add+=f'  changed=business;++changed.played_character_{field}.scale;assert(!IngameDecisionOutcomeFrameMatchesV1(before,changed,"decision_closed"));\n'
t=t.replace('  auto blocked_before=before;blocked_before.has_active_event=true;',add+'  auto blocked_before=before;blocked_before.has_active_event=true;')
p.write_text(t,encoding='utf-8')
delta=json.loads((out/'delta-manifest-revision-002.json').read_text(encoding='utf-8'))
for entry in delta:
    rel=entry['path'];data=(source/rel).read_bytes()
    p=out/'candidate-revision-003'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    entry['after_sha256']=hashlib.sha256(data).hexdigest();entry['bytes']=len(data)
    bp=out/'before'/rel;bt=bp.read_text(encoding='utf-8-sig') if bp.exists() else ''
    p=out/'diffs-revision-003'/(rel.replace('/','__')+'.diff');p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(''.join(difflib.unified_diff(bt.splitlines(True),data.decode('utf-8-sig').splitlines(True),fromfile='before/'+rel,tofile='candidate/'+rel)),encoding='utf-8')
(out/'delta-manifest-revision-003.json').write_text(json.dumps(delta,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy()
for line in (out/'build-env-002.stdout').read_text(encoding='utf-8',errors='replace').splitlines():
    if '=' in line and not line.startswith('='):
        k,v=line.split('=',1);env[k]=v
cmake=Path('C:/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe')
records=[]
for label,args in [('compile-focused-contract-003',[cmake,'--build',build,'--target','xar_ck3_ingame_decision_outcome_contract_v1_test','--parallel','4']),('test-focused-contract-003',[build/'xar_ck3_ingame_decision_outcome_contract_v1_test.exe']),('compile-candidate-dll-003',[cmake,'--build',build,'--target','xar_ck3_bridge','--parallel','4'])]:
    started=time.time();p=subprocess.run([str(x) for x in args],env=env,capture_output=True)
    (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
    r={'label':label,'argv':[str(x) for x in args],'exit_code':p.returncode,'elapsed_seconds':time.time()-started};records.append(r)
    (out/'build-receipts-003.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(r),flush=True)
    if p.returncode:raise SystemExit(p.returncode)
artifacts=[]
for rel in ['xar_ck3_bridge.dll','xar_ck3_ingame_decision_outcome_contract_v1_test.exe']:
    p=build/rel;data=p.read_bytes();target=out/'compiled-revision-003'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    artifacts.append({'path':str(p),'preserved_path':str(target),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'compiled-artifacts-003.json').write_text(json.dumps(artifacts,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'compiled':'PASS','native_game':'NOT_RUN','artifacts':artifacts}),flush=True)
