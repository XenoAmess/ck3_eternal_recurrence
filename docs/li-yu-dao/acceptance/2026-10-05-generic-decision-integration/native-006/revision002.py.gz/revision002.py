from pathlib import Path
import shutil,json,hashlib,difflib
out=Path(__file__).parent
old=Path('C:/ldn5/source');new=Path('C:/ldn6/source')
if new.exists():raise SystemExit('revision root exists')
shutil.copytree(old,new)
rel='include/xar_bridge/ingame_decision_outcome_contract_v1.hpp'
p=new/rel;t=p.read_text();t=t.replace('if(before.has_active_event||!before.paused','if(before.has_active_event||before.has_pending_character_interaction||!before.paused');p.write_text(t,encoding='utf-8')
rel='src/ingame_decision_item_v1.cpp'
p=new/rel;t=p.read_text();t=t.replace('query.observation.expected_snapshot.has_active_event))','(query.observation.expected_snapshot.has_active_event||query.observation.expected_snapshot.has_pending_character_interaction)))');p.write_text(t,encoding='utf-8')
rel='src/bridge.cpp'
p=new/rel;t=p.read_text();t=t.replace('(outcome&&current.has_active_event) ||','(outcome&&(current.has_active_event||current.has_pending_character_interaction)) ||');p.write_text(t,encoding='utf-8')
rel='tests/ingame_decision_outcome_contract_v1_test.cpp'
p=new/rel;t=p.read_text();t=t.replace('assert(!IngameDecisionOutcomeFrameMatchesV1(before,before,"unknown"));','blocked_before=before;blocked_before.has_pending_character_interaction=true;\n  assert(!IngameDecisionOutcomeFrameMatchesV1(blocked_before,blocked_before,"decision_closed"));\n  assert(!IngameDecisionOutcomeFrameMatchesV1(before,before,"unknown"));');p.write_text(t,encoding='utf-8')
delta=json.loads((out/'delta-manifest.json').read_text())
for entry in delta:
    rel=entry['path'];data=(new/rel).read_bytes()
    target=out/'candidate-revision-002'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    entry['after_sha256']=hashlib.sha256(data).hexdigest()
    before=out/'before'/rel
    beforetext=before.read_text(encoding='utf-8-sig') if before.exists() else ''
    target=out/'diffs-revision-002'/(rel.replace('/','__')+'.diff');target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(''.join(difflib.unified_diff(beforetext.splitlines(True),data.decode('utf-8-sig').splitlines(True),fromfile='before/'+rel,tofile='candidate/'+rel)),encoding='utf-8')
(out/'delta-manifest-revision-002.json').write_text(json.dumps(delta,indent=2)+'\n',encoding='utf-8')
build=(out/'build_candidate.py').read_text().replace("Path('C:/ldn5/source')","Path('C:/ldn6/source')").replace("Path('C:/ldn5/build-001')","Path('C:/ldn6/build-002')").replace("'C:/ldn5/config-bad-dependency-001'","'C:/ldn6/config-bad-dependency-002'")
build=build.replace('import subprocess,os,json,time,hashlib','import subprocess,os,json,time,hashlib,ctypes')
build=build.replace('env_result=subprocess.run([\'cmd.exe\',\'/d\',\'/s\',\'/c\',f\'call "{vcvars}" > nul && set\'],capture_output=True)',"short=ctypes.create_unicode_buffer(32768)\nif not ctypes.windll.kernel32.GetShortPathNameW(str(vcvars),short,len(short)):raise SystemExit('vcvars short path unavailable')\nenv_result=subprocess.run(['cmd.exe','/d','/c',short.value,'&&','set'],capture_output=True)")
for oldname in ['build-env.stdout','build-env.stderr','build-receipts.json','compiled-artifacts.json']:
    build=build.replace(oldname,oldname.replace('.', '-002.',1))
build=build.replace("f'{label}.stdout'","f'{label}-002.stdout'").replace("f'{label}.stderr'","f'{label}-002.stderr'")
(out/'build_candidate_002.py').write_text(build,encoding='utf-8')
print('created immutable revision 002 source and build script')
