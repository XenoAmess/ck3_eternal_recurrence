from pathlib import Path
import os, sys, unittest, importlib, json, hashlib
ROOT=Path('C:/workspace/ck3_eternal_recurrence')
OUT=Path(__file__).resolve().parent
CHECK=OUT/(sys.argv[1] if len(sys.argv)>1 else 'checks-002')
CHECK.mkdir(exist_ok=False)
sys.dont_write_bytecode=True
sys.path[:0]=[str(ROOT/'ck3_autonomous_player/src'),str(ROOT/'ck3_autonomous_player/tests/unit'),
              str(OUT/'candidate/ck3_autonomous_player/tests/unit'),str(OUT/'candidate/tools'),str(ROOT/'tools')]
import xar_autoplayer.bridge
xar_autoplayer.bridge.__path__.insert(0,str(OUT/'candidate/ck3_autonomous_player/src/xar_autoplayer/bridge'))
for name in ['xar_autoplayer.bridge.native_driver','xar_autoplayer.bridge.service','xar_autoplayer.bridge.mcp_server',
             'xar_autoplayer.bridge.ingame_decision_outcome_contract']:
 sys.modules.pop(name,None)
os.environ['XAR_DECISION_OUTCOME_TEST_ARTIFACTS']='\\\\?\\'+str((CHECK/'claims').resolve())
os.environ['XAR_WHITE_DECISION_ACTION_TEST_ARTIFACTS']='\\\\?\\'+str((CHECK/'legacy-claims').resolve())
os.environ['XAR_WHITE_DECISIONS_TEST_ARTIFACTS']='\\\\?\\'+str((CHECK/'opener-claims').resolve())
modules=['test_ingame_decision_outcomes','test_ingame_decision_item_actions','test_ingame_decisions_open_contract',
         'test_ck3_native_profile_mcp']
suite=unittest.TestSuite()
for name in modules:
 module=importlib.import_module(name)
 suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
with (CHECK/'tests.log').open('w',encoding='utf-8') as stream:
 result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
print((CHECK/'tests.log').read_text(encoding='utf-8'))
report={'schema':'lyd-mcp-decision-python-focused-tests-v1','runtime':'synthetic-only-no-game-no-native-callback',
        'python':sys.version,'executable':sys.executable,'tests_run':result.testsRun,
        'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),
        'status':'PASS' if result.wasSuccessful() else 'RED',
        'modules':{name:sys.modules[name].__file__ for name in modules},
        'candidate_modules':{name:sys.modules[name].__file__ for name in ['xar_autoplayer.bridge.native_driver',
                                 'xar_autoplayer.bridge.service','xar_autoplayer.bridge.mcp_server','ck3_native_profile_mcp']}}
(CHECK/'REPORT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
raise SystemExit(0 if result.wasSuccessful() else 1)
