"""Planner-facing service shared by MCP tools and direct autonomous mode."""

from __future__ import annotations

import copy
import json
from collections.abc import Callable
from pathlib import Path
import uuid

from .version_identity import require_exact_native_build

from .driver import (
    BridgeUnavailableError,
    GameplayBridgeDriver,
    PreSubmissionRevisionMismatchError,
    StepPostconditionError,
    UnsupportedStepError,
)
from ..vanilla_events.outcome import (
    evaluate_registered_event_material_postcondition_v1,
)
from .event_contract import (
    action_step_set,
    choose_event_option_number,
    event_option_step,
    normalize_active_event,
    parse_event_option_step,
)
from .declaration_contract import (
    QUERY_DECLARABLE_WARS_STEP,
    declare_war_step,
    is_native_declaration_step,
)
from .marriage_contract import (
    QUERY_ARRANGE_MARRIAGE_CHOICES_STEP,
    arrange_marriage_step,
)
from .combat_contract import (
    QUERY_COMBAT_SIMULATION_INPUTS_CAPABILITY,
    combat_simulation_encounter_scope,
    combat_simulation_inputs_status,
    normalize_combat_simulation_inputs,
    normalize_combat_simulation_request,
    query_combat_simulation_inputs_step,
)
from .combat_phase_contract import (
    QUERY_COMBAT_SIMULATION_INPUTS_V3_CAPABILITY,
    combat_simulation_inputs_v3_status,
    normalize_combat_simulation_inputs_v3,
    parse_query_combat_simulation_inputs_v3_step,
    query_combat_simulation_inputs_v3_step,
)
from .combat_phase_event_trace_contract import (
    QUERY_COMBAT_PHASE_EVENT_TRACE_V1_CAPABILITY,
    normalize_combat_phase_event_trace_v1,
    query_combat_phase_event_trace_v1_step,
)
from .war_exit_terms_contract import (
    WAR_TERMINATION_EXIT_TERMS_PRODUCTION_ENABLED,
    query_war_termination_exit_terms_step,
)
from .war_entry_contract import (
    QUERY_WAR_ENTRY_ASSESSMENTS_CAPABILITY,
    normalize_war_entry_assessments,
    normalize_war_entry_target_ids,
    query_war_entry_assessments_step,
    require_war_entry_assessment_targets,
    war_entry_assessment_target_scopes,
)
from .projected_contact_contract import (
    QUERY_PROJECTED_CONTACT_SCOPE_V1_CAPABILITY,
    normalize_projected_contact_scope,
    projected_contact_subject_scope,
    query_projected_contact_scope_v1_step,
)
from .actual_contact_contract import query_actual_contact_scope_step
from .army_commander_candidates import (
    QUERY_ARMY_COMMANDER_CANDIDATES_V1_CAPABILITY,
    commander_query_army_scope,
    normalize_army_commander_candidates_v1,
    query_army_commander_candidates_v1_step,
)
from .army_commander_assignment import (
    ASSIGN_ARMY_COMMANDER_V1_CAPABILITY,
    assign_army_commander_v1_step,
    commander_assignment_readback_v1,
    normalize_army_commander_assignment_v1,
)
from .battle_control_contract import (
    QUERY_BATTLE_CONTROL_SNAPSHOT_V1_CAPABILITY,
    normalize_active_combat_resume_inputs_v1,
    normalize_battle_control_snapshot_v1,
    query_battle_control_snapshot_v1_step,
)
from .battle_transition_contract import (
    QUERY_BATTLE_TRANSITION_V1_CAPABILITY,
    normalize_battle_transition_v1,
    query_battle_transition_v1_step,
)
from .battle_terminal_transition_contract import (
    QUERY_BATTLE_TERMINAL_TRANSITION_V1_CAPABILITY,
    normalize_battle_terminal_transition_v1,
    parse_query_battle_terminal_transition_v1_step,
    query_battle_terminal_transition_v1_step,
)
from .battle_reinforcement_assignment_contract import (
    QUERY_BATTLE_REINFORCEMENT_ASSIGNMENT_V1_CAPABILITY,
    normalize_battle_reinforcement_assignment_v1,
    query_battle_reinforcement_assignment_v1_step,
)
from .campaign_root_context_contract import (
    is_baseline_campaign_root_context_12002,
    QUERY_CAMPAIGN_ROOT_CONTEXT_V1_CAPABILITY,
    QUERY_CAMPAIGN_ROOT_CONTEXT_V1_STEP,
    normalize_campaign_root_context_v1,
)
from .council_composition_candidates_contract import (
    COUNCIL_COMPOSITION_CANDIDATES_V1_SCHEMA,
    QUERY_COUNCIL_COMPOSITION_CANDIDATES_V1_CAPABILITY,
    QUERY_COUNCIL_COMPOSITION_CANDIDATES_V1_STEP,
    STEWARD_POSITION_KEY,
    build_council_composition_candidates_request_v1,
    normalize_council_composition_candidates_v1,
)
from .council_assign_councillor_action_contract import (
    ASSIGN_COUNCILLOR_V1_STEP,
)
from .steward_develop_county_contract import (
    QUERY_STEWARD_DEVELOP_COUNTY_CANDIDATES_V1_CAPABILITY,
    QUERY_STEWARD_DEVELOP_COUNTY_CANDIDATES_V1_STEP,
    normalize_steward_develop_county_candidates_v1,
)
from .steward_develop_county_action_contract import (
    CHANGE_STEWARD_DEVELOP_COUNTY_TASK_V1_CAPABILITY,
    CHANGE_STEWARD_DEVELOP_COUNTY_TASK_V1_TRANSPORT_CAPABILITY,
    build_change_steward_develop_county_request_v1,
    normalize_change_steward_develop_county_ack_v1,
)
from .player_faction_alerts_contract import (
    QUERY_PLAYER_FACTION_ALERTS_V1_CAPABILITY,
    QUERY_PLAYER_FACTION_ALERTS_V1_STEP,
    normalize_player_faction_alerts_v1,
    validate_player_faction_war_handoffs_v1,
)
from .entity_directory_contract import build_entity_directory_v1
from .turn_bundle_contract import build_turn_bundle_v1
from .zhongguo_case_snapshot_contract import (
    QUERY_ZHONGGUO_CASE_SNAPSHOT_V1_CAPABILITY,
    QUERY_ZHONGGUO_CASE_SNAPSHOT_V1_STEP,
    ZHONGGUO_CASE_SNAPSHOT_V1_CONSUMER_ID,
    normalize_native_zhongguo_case_snapshot_v1,
    normalize_zhongguo_case_snapshot_v1_response,
    parse_query_zhongguo_case_snapshot_v1_step,
    query_zhongguo_case_snapshot_v1_step,
)
from .zhongguo_b1_cycle_snapshot_contract import (
    QUERY_ZHONGGUO_B1_CYCLE_SNAPSHOT_V1_CAPABILITY,
    QUERY_ZHONGGUO_B1_CYCLE_SNAPSHOT_V1_STEP,
    normalize_native_zhongguo_b1_cycle_snapshot_v1,
    parse_query_zhongguo_b1_cycle_snapshot_v1_step,
    query_zhongguo_b1_cycle_snapshot_v1_step,
)
from .zhongguo_ai_owned_case_snapshot_contract import (
    QUERY_ZHONGGUO_AI_OWNED_CASE_SNAPSHOT_V1_CAPABILITY,
    QUERY_ZHONGGUO_AI_OWNED_CASE_SNAPSHOT_V1_STEP,
    ZHONGGUO_AI_OWNED_CASE_SNAPSHOT_V1_CONSUMER_ID,
    normalize_native_zhongguo_ai_owned_case_snapshot_v1,
    normalize_zhongguo_ai_owned_case_snapshot_v1_response,
    parse_query_zhongguo_ai_owned_case_snapshot_v1_step,
    query_zhongguo_ai_owned_case_snapshot_v1_step,
)
from .zhongguo_result_case_snapshot_contract import (
    QUERY_ZHONGGUO_RESULT_CASE_SNAPSHOT_V1_CAPABILITY,
    QUERY_ZHONGGUO_RESULT_CASE_SNAPSHOT_V1_STEP,
    ZHONGGUO_RESULT_CASE_SNAPSHOT_V1_CONSUMER_ID,
    normalize_native_zhongguo_result_case_snapshot_v1,
    normalize_zhongguo_result_case_snapshot_v1_response,
    parse_query_zhongguo_result_case_snapshot_v1_step,
    query_zhongguo_result_case_snapshot_v1_step,
)
from .zhongguo_b2_pip_snapshot_contract import (
    QUERY_ZHONGGUO_B2_PIP_SNAPSHOT_V1_CAPABILITY,
    QUERY_ZHONGGUO_B2_PIP_SNAPSHOT_V1_STEP,
    ZHONGGUO_B2_PIP_SNAPSHOT_V1_CONSUMER_ID,
    normalize_native_zhongguo_b2_pip_snapshot_v1,
    normalize_zhongguo_b2_pip_snapshot_v1_response,
    parse_query_zhongguo_b2_pip_snapshot_v1_step,
    query_zhongguo_b2_pip_snapshot_v1_step,
)
from .zhongguo_promotion_compensation_postcondition_contract import (
    QUERY_ZHONGGUO_PROMOTION_COMPENSATION_V1_CAPABILITY,
    QUERY_ZHONGGUO_PROMOTION_COMPENSATION_V1_STEP,
    normalize_native_zhongguo_promotion_compensation_v1,
    parse_query_zhongguo_promotion_compensation_v1_step,
    query_zhongguo_promotion_compensation_v1_step,
)
from .zhongguo_compensation_af5_snapshot_contract import (
    QUERY_ZHONGGUO_COMPENSATION_AF5_SNAPSHOT_V1_CAPABILITY,
    QUERY_ZHONGGUO_COMPENSATION_AF5_SNAPSHOT_V1_STEP,
    normalize_native_zhongguo_compensation_af5_snapshot_v1,
    parse_query_zhongguo_compensation_af5_snapshot_v1_step,
    query_zhongguo_compensation_af5_snapshot_v1_step,
)
from .zhongguo_workforce_owner_snapshot_contract import (
    QUERY_ZHONGGUO_WORKFORCE_OWNER_SNAPSHOT_V1_CAPABILITY,
    QUERY_ZHONGGUO_WORKFORCE_OWNER_SNAPSHOT_V1_STEP,
    normalize_native_zhongguo_workforce_owner_snapshot_v1,
    parse_query_zhongguo_workforce_owner_snapshot_v1_step,
    query_zhongguo_workforce_owner_snapshot_v1_step,
)
from .zhongguo_promotion_source_progress_contract import (
    ACTIVATE_REVIEW_NOW_V1_TRANSPORT_CAPABILITY,
    QUERY_PROMOTION_SOURCE_PROGRESS_V1_TRANSPORT_CAPABILITY,
    build_review_now_action_v1_request,
    parse_query_promotion_source_progress_v1_step,
    query_promotion_source_progress_v1_step,
    widget_visible,
)
from .zhongguo_projects_metrics_postcondition_contract import (
    QUERY_ZHONGGUO_PROJECTS_METRICS_V1_CAPABILITY,
    QUERY_ZHONGGUO_PROJECTS_METRICS_V1_STEP,
    normalize_native_zhongguo_projects_metrics_v1,
    parse_query_zhongguo_projects_metrics_v1_step,
    query_zhongguo_projects_metrics_v1_step,
)
from .zhongguo_career_hc_workforce_postcondition_contract import (
    QUERY_ZHONGGUO_CAREER_HC_WORKFORCE_V1_CAPABILITY,
    QUERY_ZHONGGUO_CAREER_HC_WORKFORCE_V1_STEP,
    normalize_native_zhongguo_career_hc_workforce_v1,
    parse_query_zhongguo_career_hc_workforce_v1_step,
    query_zhongguo_career_hc_workforce_v1_step,
)
from .zhongguo_workforce_collective_snapshot_contract import (
    QUERY_ZHONGGUO_WORKFORCE_COLLECTIVE_SNAPSHOT_V1_CAPABILITY,
    QUERY_ZHONGGUO_WORKFORCE_COLLECTIVE_SNAPSHOT_V1_STEP,
    ZHONGGUO_WORKFORCE_COLLECTIVE_SNAPSHOT_V1_CONSUMER_ID,
    normalize_native_zhongguo_workforce_collective_snapshot_v1,
    normalize_zhongguo_workforce_collective_snapshot_v1_response,
    parse_query_zhongguo_workforce_collective_snapshot_v1_step,
    query_zhongguo_workforce_collective_snapshot_v1_step,
)
from .zhongguo_workforce_normal_exit_snapshot_contract import (
    QUERY_ZHONGGUO_WORKFORCE_NORMAL_EXIT_SNAPSHOT_V1_CAPABILITY,
    QUERY_ZHONGGUO_WORKFORCE_NORMAL_EXIT_SNAPSHOT_V1_STEP,
    ZHONGGUO_WORKFORCE_NORMAL_EXIT_CONSUMER_ID_V1,
    normalize_native_zhongguo_workforce_normal_exit_snapshot_v1,
    normalize_zhongguo_workforce_normal_exit_snapshot_v1_response,
    parse_query_zhongguo_workforce_normal_exit_snapshot_v1_step,
    query_zhongguo_workforce_normal_exit_snapshot_v1_step,
)
from .zhongguo_incident_snapshot_contract import (
    QUERY_ZHONGGUO_INCIDENT_SNAPSHOT_V1_CAPABILITY,
    QUERY_ZHONGGUO_INCIDENT_SNAPSHOT_V1_STEP,
    ZHONGGUO_INCIDENT_SNAPSHOT_V1_CONSUMER_ID,
    normalize_native_zhongguo_incident_snapshot_v1,
    normalize_zhongguo_incident_snapshot_v1_response,
    parse_query_zhongguo_incident_snapshot_v1_step,
    query_zhongguo_incident_snapshot_v1_step,
)
from .zhongguo_manager_governance_snapshot_contract import (
    QUERY_ZHONGGUO_MANAGER_GOVERNANCE_SNAPSHOT_V1_CAPABILITY,
    QUERY_ZHONGGUO_MANAGER_GOVERNANCE_SNAPSHOT_V1_STEP,
    ZHONGGUO_MANAGER_GOVERNANCE_SNAPSHOT_V1_CONSUMER_ID,
    normalize_native_zhongguo_manager_governance_snapshot_v1,
    normalize_zhongguo_manager_governance_snapshot_v1_response,
    parse_query_zhongguo_manager_governance_snapshot_v1_step,
    query_zhongguo_manager_governance_snapshot_v1_step,
)
from .zhongguo_manager_subordinate_selector_contract import (
    QUERY_ZHONGGUO_MANAGER_SUBORDINATE_SELECTOR_V1_CAPABILITY,
    QUERY_ZHONGGUO_MANAGER_SUBORDINATE_SELECTOR_V1_STEP,
    normalize_native_zhongguo_manager_subordinate_selector_v1,
    parse_query_zhongguo_manager_subordinate_selector_v1_step,
    query_zhongguo_manager_subordinate_selector_v1_step,
)
from .zhongguo_scoreboard_state_contract import (
    QUERY_ZHONGGUO_SCOREBOARD_STATE_V1_CAPABILITY,
    QUERY_ZHONGGUO_SCOREBOARD_STATE_V1_STEP,
    ZHONGGUO_SCOREBOARD_STATE_V1_CONSUMER_ID,
    normalize_native_zhongguo_scoreboard_state_v1,
    parse_query_zhongguo_scoreboard_state_v1_step,
    query_zhongguo_scoreboard_state_v1_step,
)
from .zhongguo_scoreboard_action_contract import (
    ACTIVATE_ZHONGGUO_SCOREBOARD_V1_CAPABILITY,
    ACTIVATE_ZHONGGUO_SCOREBOARD_V1_STEP,
    ZHONGGUO_SCOREBOARD_ACTION_V1_TRANSPORT_CAPABILITY,
    build_zhongguo_scoreboard_action_v1_request,
    normalize_native_zhongguo_scoreboard_action_v1_result,
)
from .title_map_navigation_contract import (
    CENTER_MAP_ON_LANDED_TITLE_V1_CAPABILITY,
    CENTER_MAP_ON_LANDED_TITLE_V1_STEP,
    normalize_title_map_navigation_v1_binding,
    normalize_title_map_navigation_v1_result,
    validate_landed_title_key,
)
from .set_played_character_contract import (
    SET_PLAYED_CHARACTER_V1_CAPABILITY,
    validate_character_id,
)
from .coat_of_arms_source_probe_contract import (
    COAT_OF_ARMS_SOURCE_V1_EXECUTABLE_SHA256,
    COAT_OF_ARMS_SOURCE_V1_GAME_VERSION,
    PROBE_COAT_OF_ARMS_SOURCE_V1_CAPABILITY,
    coat_of_arms_source_frontend_binding_from_capabilities,
    encode_coat_of_arms_source_v1,
    encode_coat_of_arms_source_transport_v2,
    normalize_coat_of_arms_source_v1_binding,
    normalize_coat_of_arms_source_v1_result,
    validate_coat_of_arms_source_probe_apply,
)
from .coat_of_arms_source_upload_v2 import (
    CoatOfArmsSourceUploadManagerV2,
)
from .coat_of_arms_source_export_contract import (
    EXPORT_COAT_OF_ARMS_SOURCE_V1_CAPABILITY,
    normalize_coat_of_arms_source_export_v1_result,
)
from .coat_of_arms_framebuffer import (
    CoatOfArmsFramebufferError,
    CoatOfArmsFramebufferCalibrationStoreV2,
    CoatOfArmsFramebufferCalibrationStoreV3,
    capture_and_compare_coat_of_arms_framebuffer_v1,
    prepare_ck3_framebuffer_capture_v1,
)
from .frontend_applied_game_rules_contract import normalize_frontend_applied_game_rules_v1
from .frontend_game_rules_control_contract import (
    normalize_frontend_game_rules_window_v1,
    normalize_frontend_game_rules_mutation_v1,
    require_game_rule_script_key,
)
from .frontend_game_rules_contract import normalize_frontend_game_rule_selections_v1
from .frontend_gui_route_contract import (
    frontend_gui_route_binding_from_capabilities,
)
from .loaded_feature_manifest_contract import (
    QUERY_LOADED_FEATURE_MANIFEST_V1_CAPABILITY,
    QUERY_LOADED_FEATURE_MANIFEST_V1_STEP,
    normalize_loaded_feature_manifest_v1,
)
from .event_window_context_contract import (
    QUERY_CURRENT_EVENT_WINDOW_CONTEXT_V1_CAPABILITY,
    QUERY_CURRENT_EVENT_WINDOW_CONTEXT_V1_STEP,
    normalize_current_event_window_context_v1,
)
from .timeline_blocker_context_contract import (
    QUERY_CURRENT_TIMELINE_BLOCKER_CONTEXT_V1_STEP,
    normalize_current_timeline_blocker_context_v1,
)
from .pending_character_interaction_context_contract import (
    ACKNOWLEDGE_PENDING_CHARACTER_INTERACTION_STEP,
    QUERY_PENDING_CHARACTER_INTERACTION_CONTEXT_V1_CAPABILITY,
    QUERY_PENDING_CHARACTER_INTERACTION_CONTEXT_V1_STEP,
    normalize_pending_interaction_id,
    normalize_pending_character_interaction_context_v1,
)
from .active_combat_retreat_contract import (
    normalize_active_combat_retreat_v1_order_ack,
    normalize_active_combat_retreat_v1_preview,
    order_active_combat_retreat_v1_step,
    preview_active_combat_retreat_v1_step,
)
from ..simulation.loaded_playset_proof import (
    LoadedPlaysetProofError,
    build_loaded_playset_proof,
    unavailable_loaded_playset_proof,
)
from .settlement_contract import (
    ONE_LIFE_SETTLEMENT_CAPABILITY,
    normalize_fixed_score,
    normalize_one_life_settlement,
    settlement_ready_for_episode,
)
from .war_occupation_targets_contract import (
    QUERY_WAR_OCCUPATION_TARGETS_V1_CAPABILITY,
    QUERY_WAR_OCCUPATION_TARGETS_V1_STEP_PREFIX,
    normalize_war_occupation_targets_v1,
    parse_query_war_occupation_targets_v1_step,
    query_war_occupation_targets_v1_step,
    war_occupation_query_scope,
)
from .title_holder_contract import (
    QUERY_TITLE_HOLDER_V1_CAPABILITY,
    normalize_title_holder_v1,
    query_title_holder_v1_step,
    title_holder_query_actor,
)
from .war_contract import (
    BATTLE_DECISION_EPOCH_ADVANCE_STEP,
    COMMITTED_ROUTE_SENTINEL_ADVANCE_STEP,
    WAR_OBJECTIVE_HOLD_SENTINEL_ADVANCE_STEP,
    QUERY_ARMY_STRENGTHS_STEP,
    RAISE_TROOPS_STEP,
    army_strength_query_status,
    army_strength_scope,
    disband_army_step,
    enforce_demands_step,
    move_army_step,
    normalize_active_wars,
    normalize_army_strength_request_ids,
    normalize_army_strengths,
    offer_white_peace_step,
    parse_battle_decision_epoch_advance_step,
    parse_committed_route_sentinel_advance_step,
    parse_war_objective_hold_sentinel_advance_step,
    player_armies_from_state,
    query_outbound_war_white_peace_status_step,
    query_war_termination_options_step,
    query_war_termination_terms_step,
    start_assault_step,
    stop_assault_step,
    surrender_war_step,
)
from ..strategy import (
    choose_one_life_turn,
    consume_one_life_lifestyle_private_trial,
    read_one_life_strategy,
)
from ..lifestyle_formal_consumer import (
    PERK_SUBMIT_STEP as PRIVATE_LIFESTYLE_PERK_STEP,
    FOCUS_SUBMIT_STEP as PRIVATE_LIFESTYLE_FOCUS_STEP,
    RECEIPT_STEP as PRIVATE_LIFESTYLE_RECEIPT_STEP,
    ROOT_QUERY_STEP as PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP,
    latest_lifestyle_applied_receipt,
    same_frame_feudal_lifestyle_scope,
    same_frame_feudal_peace_scope,
    unresolved_lifestyle_perk_action,
)
from .player_lifestyle_private_transport_v1 import PERK_TARGETS
from .player_lifestyle_private_transport_v1 import (
    query_player_lifestyle_stock_focus_combined_private_v1,
)
from ..lifestyle_min_policy import choose_first_focus_target
from ..construction_formal_consumer import (
    SUBMIT_STEP as PRIVATE_CONSTRUCTION_SUBMIT_STEP,
    RECEIPT_STEP as PRIVATE_CONSTRUCTION_RECEIPT_STEP,
    ROOT_QUERY_STEP as PRIVATE_CONSTRUCTION_INCOME_QUERY_STEP,
    plan_construction_private,
    read_construction_ledger,
)
from ..family_marriage_formal_consumer import (
    SUBMIT_STEP as PRIVATE_FAMILY_MARRIAGE_SUBMIT_STEP,
    RESULT_STEP as PRIVATE_FAMILY_MARRIAGE_RESULT_STEP,
    ALLIANCE_RESULT_STEP as PRIVATE_FAMILY_MARRIAGE_ALLIANCE_RESULT_STEP,
    plan_family_marriage_private,
    submit_family_marriage_private,
    query_family_marriage_result_private,
    query_family_marriage_alliance_result_private,
)
from ..current_first_heir_betrothal_formal_consumer import (
    SUBMIT_STEP as PRIVATE_CURRENT_BETROTHAL_SUBMIT_STEP,
    plan_current_first_heir_betrothal_fulfillment_private,
    submit_current_first_heir_betrothal_fulfillment_private,
    query_current_first_heir_betrothal_fulfillment_result_private,
)
from ..player_child_matrilineal_formal_consumer import (
    ALLIANCE_RESULT_STEP as PRIVATE_CHILD_MATRILINEAL_ALLIANCE_STEP,
    RESULT_STEP as PRIVATE_CHILD_MATRILINEAL_RESULT_STEP,
    SUBMIT_STEP as PRIVATE_CHILD_MATRILINEAL_SUBMIT_STEP,
    plan_child_matrilineal_private,
    read_child_matrilineal_ledger,
    query_child_matrilineal_result_private,
    query_child_matrilineal_alliance_private,
    submit_child_matrilineal_private,
)
from ..player_child_default_formal_consumer import (
    ALLIANCE_RESULT_STEP as PRIVATE_CHILD_DEFAULT_ALLIANCE_STEP,
    RESULT_STEP as PRIVATE_CHILD_DEFAULT_RESULT_STEP,
    SUBMIT_STEP as PRIVATE_CHILD_DEFAULT_SUBMIT_STEP,
    plan_child_default_private,
    query_child_default_result_private,
    query_child_default_alliance_private,
    submit_child_default_private,
)
from ..prisoner_ransom_formal_consumer import (
    SUBMIT_STEP as PRIVATE_PRISONER_RANSOM_SUBMIT_STEP,
    RECEIPT_STEP as PRIVATE_PRISONER_RANSOM_RECEIPT_STEP,
    plan_ransom_private,
    submit_ransom_private,
    read_ransom_receipt_private,
)
from .domain_construction_private_transport_v1 import (
    _identity as construction_process_identity,
    submit_construction_private, query_construction_receipt,
)
from .faction_gift_formal_route_v1 import (
    COLD_RECOVERY_STEP as PRIVATE_FACTION_COLD_RECOVERY_STEP,
    RECEIPT_STEP as PRIVATE_FACTION_RECEIPT_STEP,
    SUBMIT_STEP as PRIVATE_FACTION_SUBMIT_STEP,
    plan_faction_gift_private_v1,
)
from ..m5_formal_proposal_collector import (
    plan_m5_formal_query_only, plan_m5_wartime_query_only,
)


class GameplayBridgeService:
    def __init__(self, driver: GameplayBridgeDriver) -> None:
        self.driver = driver
        self._zhongguo_scoreboard_surface_preparer_v1 = None
        self._coat_of_arms_source_uploads_v2 = (
            CoatOfArmsSourceUploadManagerV2()
        )
        self._coat_of_arms_framebuffer_calibrations_v2 = (
            CoatOfArmsFramebufferCalibrationStoreV2()
        )
        self._coat_of_arms_framebuffer_calibrations_v3 = (
            CoatOfArmsFramebufferCalibrationStoreV3()
        )
        # Repeated wartime queries on one native frame need no duplicate LIFE
        # read. A new actor, date or native revision may expose a new point.
        self._last_war_lifestyle_observation: tuple[object, object, object, object] | None = None
        self._last_war_family_observation: tuple[object, object, object] | None = None
        self._opening_martial_episode_v1: str | None = None
        self._opening_martial_observation_v1: dict[str, object] | None = None

    def bind_zhongguo_scoreboard_surface_preparer_v1(self, preparer: object) -> None:
        """Bind the runner-owned real product-checkpoint provider once."""

        if not callable(preparer):
            raise TypeError("scoreboard surface preparer must be callable")
        if self._zhongguo_scoreboard_surface_preparer_v1 is not None:
            raise BridgeUnavailableError(
                "scoreboard surface preparer is already bound"
            )
        self._zhongguo_scoreboard_surface_preparer_v1 = preparer

    def prepare_zhongguo_scoreboard_surface_v1(
        self, surface_id: str
    ) -> dict[str, object]:
        """Prepare one real surface or return a typed unavailable receipt."""

        preparer = self._zhongguo_scoreboard_surface_preparer_v1
        if not callable(preparer):
            return {
                "schema_version": 1,
                "surface_id": surface_id,
                "status": "unavailable",
                "failure_reason": (
                    "scoreboard_surface_checkpoint_registry_missing"
                ),
                "provider_observed": False,
                "action_ack_used_as_postcondition": False,
            }
        result = preparer(surface_id)
        if not isinstance(result, dict):
            raise BridgeUnavailableError(
                "scoreboard surface preparer returned a non-object"
            )
        return result

    def submit_player_religion_conversion_private_v1(
        self, *, expected_revision: int, target_rite_id: int,
        max_piety_cost_raw: int, action_id: str,
    ) -> dict[str, object]:
        """Submit a caller-selected paid target; native ACK remains pending."""
        submit = getattr(self.driver, "submit_player_religion_conversion_private_v1", None)
        if not callable(submit):
            raise UnsupportedStepError("selected backend cannot submit player religion conversion")
        return submit(expected_revision=expected_revision, target_rite_id=target_rite_id,
                      max_piety_cost_raw=max_piety_cost_raw, action_id=action_id)

    def query_player_religion_conversion_result_private_v1(
        self, *, expected_revision: int, request_id: str, action_id: str,
    ) -> dict[str, object]:
        """Read actual material associated with an owning request/action pair."""
        read = getattr(self.driver, "query_player_religion_conversion_result_private_v1", None)
        if not callable(read):
            raise UnsupportedStepError("selected backend cannot read player conversion results")
        return read(expected_revision=expected_revision, request_id=request_id, action_id=action_id)

    def submit_call_ally_to_war_private_v1(
        self, *, expected_revision: int, war_id: int, recipient_character_id: int,
    ) -> dict[str, object]:
        """Forward one selected invitation without turning its ACK into a join."""
        submit = getattr(self.driver, "submit_call_ally_to_war_private_v1", None)
        if not callable(submit):
            raise UnsupportedStepError("selected backend cannot submit call ally to war")
        return submit(expected_revision=expected_revision, war_id=war_id,
                      recipient_character_id=recipient_character_id)

    def submit_county_conversion_task_private_v1(
        self, *, expected_revision: int, expected_active_task_id: int,
        expected_incumbent_character_id: int, province_id: int,
        replace_existing_task: bool, action_id: str,
    ) -> dict[str, object]:
        """Queue one selected county task; its ACK does not verify assignment."""
        submit = getattr(self.driver, "submit_county_conversion_task_private_v1", None)
        if not callable(submit):
            raise UnsupportedStepError("selected backend cannot submit county conversion tasks")
        return submit(
            expected_revision=expected_revision,
            expected_active_task_id=expected_active_task_id,
            expected_incumbent_character_id=expected_incumbent_character_id,
            province_id=province_id, replace_existing_task=replace_existing_task,
            action_id=action_id,
        )

    def query_county_conversion_task_result_private_v1(
        self, *, expected_revision: int, submitted_request_id: str, action_id: str,
    ) -> dict[str, object]:
        """Read the task actually retained by the native player and incumbent."""
        read = getattr(self.driver, "query_county_conversion_task_result_private_v1", None)
        if not callable(read):
            raise UnsupportedStepError("selected backend cannot read county conversion task results")
        return read(expected_revision=expected_revision,
                    submitted_request_id=submitted_request_id, action_id=action_id)

    def capabilities(self) -> dict[str, object]:
        return self.driver.capabilities()

    def snapshot(
        self, *, include_native_command_history: bool = True,
    ) -> dict[str, object]:
        if include_native_command_history is False:
            finite_reader = getattr(
                self.driver, "take_snapshot_without_native_command_history", None,
            )
            if callable(finite_reader):
                return finite_reader()
        return self.driver.take_snapshot()

    def bridge_diagnostics(self) -> dict[str, object]:
        """Return transport/private observer diagnostics without advertising capability."""
        diagnostics = getattr(self.driver, "diagnostics", None)
        if callable(diagnostics):
            value = diagnostics()
            if isinstance(value, dict):
                return value
        capabilities = self.capabilities()
        nested = capabilities.get("diagnostics")
        if isinstance(nested, dict):
            return nested
        return {
            "backend_id": capabilities.get("backend_id"),
            "connected": capabilities.get("connected"),
            "private_observers": {},
        }

    def _prepare_succession_transition_v1(
        self,
        snapshot: dict[str, object],
        available_steps: set[str],
    ) -> dict[str, object]:
        """Freeze or reconcile the private same-campaign succession ledger."""

        retain = getattr(
            self.driver, "retain_succession_expectation_v1", None
        )
        reconcile = getattr(
            self.driver, "reconcile_retained_succession_transition_v1", None
        )
        if not (
            callable(retain)
            and callable(reconcile)
            and snapshot.get("paused") is True
            and snapshot.get("map_ready") is True
            and QUERY_CAMPAIGN_ROOT_CONTEXT_V1_STEP in available_steps
        ):
            return snapshot
        revision = snapshot.get("revision")
        if isinstance(revision, bool) or not isinstance(revision, int):
            return snapshot
        terminal_reason = snapshot.get("one_life_terminal_reason")
        expectation = snapshot.get("succession_expectation")
        reconciliation = snapshot.get("succession_reconciliation")
        if terminal_reason == "played_character_changed":
            successor_binding = (
                reconciliation.get("successor_binding")
                if isinstance(reconciliation, dict)
                else None
            )
            reconciliation_is_current = bool(
                isinstance(successor_binding, dict)
                and all(
                    successor_binding.get(key) == snapshot.get(key)
                    for key in (
                        "snapshot_id",
                        "revision",
                        "native_revision",
                        "date_raw",
                    )
                )
            )
            if isinstance(expectation, dict) and not reconciliation_is_current:
                turn_bundle = self.query_turn_bundle_v1(
                    expected_revision=revision
                )
                reconcile(turn_bundle, expected_revision=revision)
                refreshed = getattr(
                    self.driver, "take_internal_semantic_snapshot", None
                )
                return refreshed() if callable(refreshed) else self.snapshot()
            return snapshot
        if terminal_reason is not None:
            return snapshot
        if (
            snapshot.get("active_event") is not None
            or snapshot.get("pending_character_interaction") is not None
        ):
            return snapshot
        binding = (
            expectation.get("binding")
            if isinstance(expectation, dict)
            else None
        )
        current_binding = {
            key: snapshot.get(key)
            for key in (
                "snapshot_id",
                "revision",
                "native_revision",
                "date_raw",
            )
        }
        if not isinstance(binding, dict) or any(
            binding.get(key) != value
            for key, value in current_binding.items()
        ):
            root_query_retry = None
            query_history_index = None
            history_view = getattr(self.driver, "_with_internal_planning_view", None)
            history_snapshot = getattr(self.driver, "_history_snapshot", None)
            if (
                not isinstance(snapshot.get("native_command_history"), list)
                and callable(history_view)
                and callable(history_snapshot)
            ):
                # Internal semantic frames omit transcript evidence. Keep only
                # its position here; copy the real prefix on a rejected read.
                query_history_index = history_view(
                    snapshot, lambda _frame, history: {"index": len(history)}
                )["index"]
            try:
                turn_bundle = self.query_turn_bundle_v1(
                    expected_revision=revision
                )
            except BridgeUnavailableError as error:
                if getattr(error, "native_error", None) not in {
                    "campaign-root snapshot changed or is not ready",
                    "application-main typed query failed or its snapshot changed",
                }:
                    raise
                retry_snapshot = snapshot
                if query_history_index is not None:
                    retry_snapshot = {
                        **snapshot,
                        "native_command_history": history_snapshot()[:query_history_index],
                    }
                root_query_retry = self._retry_rejected_campaign_root_read(
                    retry_snapshot, {"revision": revision}, error
                )
                if root_query_retry is None:
                    raise
                revision = int(root_query_retry["fresh_snapshot"]["revision"])
                try:
                    turn_bundle = self.query_turn_bundle_v1(
                        expected_revision=revision
                    )
                except BridgeUnavailableError as retry_error:
                    error.read_only_query_retry = {
                        key: value
                        for key, value in root_query_retry.items()
                        if key not in ("fresh_snapshot", "starting_snapshot")
                    }
                    error.read_only_query_retry["second_error"] = (
                        f"{type(retry_error).__name__}: {retry_error}"
                    )
                    raise error from retry_error
            retain(turn_bundle, expected_revision=revision)
            refreshed = getattr(
                self.driver, "take_internal_semantic_snapshot", None
            )
            prepared = refreshed() if callable(refreshed) else self.snapshot()
            if root_query_retry is not None:
                prepared = {
                    **prepared,
                    "read_only_query_retry": {
                        key: value
                        for key, value in root_query_retry.items()
                        if key not in ("fresh_snapshot", "starting_snapshot")
                    },
                }
            return prepared
        return snapshot

    def _ordinary_government_context_v1(self, snapshot: dict[str, object]) -> dict[str, object]:
        from ..ordinary_campaign_government_context_v1 import build_ordinary_campaign_government_context_v1

        permitted = getattr(self.driver, "allow_private_government_runtime_adapter_query", False) is True
        lifecycle = snapshot.get("succession_lifecycle")
        observation = None
        query_error = None
        if (permitted and isinstance(lifecycle, dict)
                and lifecycle.get("lifecycle") == "ordinary_campaign_succession"
                and isinstance(snapshot.get("campaign_goal"), dict)
                and snapshot.get("paused") is True and snapshot.get("map_ready") is True
                and snapshot.get("active_event") is None
                and snapshot.get("pending_character_interaction") is None
                and snapshot.get("one_life_terminal_reason") is None):
            try:
                observation = self.driver.query_government_runtime_adapter_private_v1(
                    expected_revision=int(snapshot["revision"]),
                )
            except (BridgeUnavailableError, UnsupportedStepError, ValueError) as error:
                query_error = {"type": type(error).__name__, "message": str(error)}
        context = build_ordinary_campaign_government_context_v1(
            snapshot, government_observation=observation, query_permitted=permitted,
        )
        if query_error is not None:
            context["government_query_error"] = query_error
        return context

    def plan_nonwar_turn(self) -> dict[str, object]:
        """Plan lifecycle work and permitted nonwar opportunities on the actual frame."""
        from ..strategy import (
            _same_frame_campaign_root_context, choose_nonwar_turn_v1,
            ordinary_campaign_goal_plan_v1, _effective_command, _effective_command_result,
        )
        from ..private_council_formal_consumer_v1 import plan_council_private
        from .current_first_heir_relationship_private_transport import (
            _same_frame_campaign_root_result,
        )

        internal = getattr(self.driver, "take_internal_semantic_snapshot", None)
        snapshot = internal() if callable(internal) else self.snapshot()
        caps = self.capabilities()
        available = action_step_set(caps)
        snapshot = self._prepare_succession_transition_v1(snapshot, available)
        caps = self.capabilities()
        available = action_step_set(caps)
        planning_view = getattr(self.driver, "_with_internal_planning_view", None)

        feast_lifecycle_observation = None
        feast_following_turn = None
        state_dir = self._strategy_state_dir()
        if (getattr(self.driver, "allow_private_activity_feast_lifecycle_observation", False) is True
                and state_dir is not None and snapshot.get("paused") is True):
            from ..activity_feast_stage5_start_formal_consumer import (
                consume_feast_start_following_turn,
                reconcile_feast_lifecycle_private_v1,
            )

            feast_lifecycle_observation = reconcile_feast_lifecycle_private_v1(
                self.driver, snapshot=snapshot,
            )
            feast_following_turn = consume_feast_start_following_turn(state_dir, snapshot)

        def seed(view, native_history):
            history = [row for row in view.get("history", []) if isinstance(row, dict)]
            history.extend(row for row in native_history if isinstance(row, dict))
            plan = choose_nonwar_turn_v1(history, snapshot=view, action_steps=available,
                                        bridge_capabilities=caps.get("bridge_capabilities", []))
            if (plan.get("selected_step") == "life-advance"
                    and QUERY_CAMPAIGN_ROOT_CONTEXT_V1_STEP in available
                    and _same_frame_campaign_root_context(history, view) is None):
                plan = {**plan, "selected_step": QUERY_CAMPAIGN_ROOT_CONTEXT_V1_STEP,
                        "phase": "nonwar_campaign_root_query",
                        "reason": "read the current campaign root before nonwar opportunities"}
            goal = view.get("campaign_goal")
            if isinstance(goal, dict):
                plan["campaign_goal_plan_used"] = ordinary_campaign_goal_plan_v1(goal)
            if feast_lifecycle_observation is not None:
                plan["activity_feast_lifecycle_observation"] = feast_lifecycle_observation
            if feast_following_turn is not None:
                plan["activity_feast_start_following_turn"] = feast_following_turn
            campaign_root_result = None
            for row in reversed(history):
                if (row.get("ok") is True
                        and _effective_command(row) == QUERY_CAMPAIGN_ROOT_CONTEXT_V1_STEP):
                    campaign_root_result = _same_frame_campaign_root_result(
                        _effective_command_result(row), view,
                    )
                    if campaign_root_result is not None:
                        break
            return {"snapshot_id": view["snapshot_id"], "revision": view["revision"],
                    "plan": plan, "_nonwar_history": history,
                    "_nonwar_campaign_root_result": campaign_root_result}

        planned = (planning_view(snapshot, seed) if callable(planning_view)
                   else seed(snapshot, snapshot.get("native_command_history", [])))
        history = planned.pop("_nonwar_history")
        campaign_root_result = planned.pop("_nonwar_campaign_root_result")
        if isinstance(snapshot.get("read_only_query_retry"), dict):
            planned["plan"]["read_only_query_retry"] = copy.deepcopy(
                snapshot["read_only_query_retry"]
            )
        planned["plan"]["campaign_government_context_used"] = self._ordinary_government_context_v1(snapshot)
        if planned["plan"].get("selected_step") != "life-advance":
            return planned
        if getattr(self.driver, "require_initial_lifestyle_focus_before_date_advance", False) is True:
            return self._plan_initial_lifestyle_focus_first_v1(planned, available)

        planned = plan_council_private(self.driver, planned, snapshot, history, available,
                                       state_dir=self._strategy_state_dir(),
                                       **({"campaign_root_result": campaign_root_result}
                                          if campaign_root_result is not None else {}))
        council = planned["plan"]
        if (council.get("phase") == "council_pending_later_frame"
                and isinstance(council.get("council_pending_action"), dict)
                and council["council_pending_action"].get("stage") == "receipt_pending"):
            return {**planned, "plan": {**council, "selected_step": "life-advance",
                    "reason": "advance to an independent frame for the pending council receipt"}}
        if council.get("selected_step") != "life-advance":
            return planned
        if getattr(self.driver, "allow_private_lifestyle_formal_trial", False) is True:
            applied = latest_lifestyle_applied_receipt(snapshot, history)
            if applied is not None:
                planned["plan"]["lifestyle_receipt_consumed"] = applied
            planned["_private_lifestyle_scope_v1"] = same_frame_feudal_lifestyle_scope(snapshot, history)
            planned["_private_lifestyle_pending_v1"] = unresolved_lifestyle_perk_action(snapshot, history)
            planned = self._plan_private_lifestyle_trial_v1(planned, available)
        if planned["plan"].get("selected_step") != "life-advance":
            return planned
        if getattr(self.driver, "allow_private_construction_formal_trial", False) is True:
            planned = plan_construction_private(self.driver, planned, snapshot, history, available)
        if planned["plan"].get("selected_step") != "life-advance":
            return planned
        if getattr(self.driver, "allow_private_family_marriage_formal_trial", False) is True:
            planned = self._plan_private_family_opportunity_v1(
                planned, snapshot, wartime_arbitration=bool(snapshot.get("active_wars")),
                **({"campaign_root_result": campaign_root_result}
                   if campaign_root_result is not None else {}),
            )
        target = getattr(self.driver, "child_matrilineal_target_v1", None)
        if (getattr(self.driver, "allow_private_player_child_matrilineal_action", False) is True
                and isinstance(target, tuple) and len(target) == 2):
            planned = plan_child_matrilineal_private(self.driver, planned, snapshot,
                subject_character_id=target[0], candidate_character_id=target[1])
        if getattr(self.driver, "allow_private_guy_default_formal_trial", False) is True:
            planned = plan_child_default_private(self.driver, planned, snapshot)
        return planned

    def plan_turn(self) -> dict[str, object]:
        internal_snapshot = getattr(
            self.driver, "take_internal_semantic_snapshot", None
        )
        internal_planning_view = getattr(
            self.driver, "_with_internal_planning_view", None
        )
        use_internal_view = callable(internal_snapshot) and callable(
            internal_planning_view
        )
        snapshot = (
            internal_snapshot() if use_internal_view else self.snapshot()
        )
        capabilities = self.capabilities()
        available_steps = action_step_set(capabilities)
        snapshot = self._prepare_succession_transition_v1(
            snapshot, available_steps
        )
        capabilities = self.capabilities()
        available_steps = action_step_set(capabilities)
        bridge_capabilities = (
            capabilities.get("bridge_capabilities")
            if isinstance(capabilities.get("bridge_capabilities"), list)
            else []
        )
        battle_speed_readiness = (
            capabilities.get("battle_speed_readiness")
            if isinstance(capabilities.get("battle_speed_readiness"), dict)
            else None
        )
        cross_run_plan = None
        campaign_goal_plan = None
        campaign_goal = snapshot.get("campaign_goal")
        if isinstance(campaign_goal, dict):
            from ..strategy import ordinary_campaign_goal_plan_v1

            campaign_goal_plan = ordinary_campaign_goal_plan_v1(campaign_goal)
        state_dir = self._strategy_state_dir()
        feast_lifecycle_observation = None
        if (getattr(self.driver, "allow_private_activity_feast_lifecycle_observation", False) is True
                and state_dir is not None and snapshot.get("paused") is True):
            from ..activity_feast_stage5_start_formal_consumer import (
                reconcile_feast_lifecycle_private_v1,
            )

            feast_lifecycle_observation = reconcile_feast_lifecycle_private_v1(
                self.driver, snapshot=snapshot,
            )
        if state_dir is not None and campaign_goal_plan is None:
            strategy = read_one_life_strategy(state_dir)
            if strategy.get("episodes"):
                candidate = strategy.get("next_run_plan")
                if isinstance(candidate, dict):
                    cross_run_plan = candidate

        def plan_from_view(
            planning_snapshot: dict[str, object],
            native_history: list[dict[str, object]],
        ) -> dict[str, object]:
            raw_history = planning_snapshot.get("history")
            history = (
                [row for row in raw_history if isinstance(row, dict)]
                if isinstance(raw_history, list)
                else []
            )
            history.extend(
                row for row in native_history if isinstance(row, dict)
            )
            played_character = planning_snapshot.get("played_character")
            opening_focus_first = getattr(
                self.driver, "require_initial_lifestyle_focus_before_date_advance",
                False,
            ) is True
            plan = (
                {
                    "policy": "initial-lifestyle-focus-first-v1",
                    "phase": "initial_lifestyle_focus_first",
                    "selected_step": "life-advance",
                    "reason": "observe and settle the opening focus before war planning",
                }
                if opening_focus_first
                else choose_one_life_turn(
                    history,
                    snapshot=planning_snapshot,
                    action_steps=available_steps,
                    bridge_capabilities=bridge_capabilities,
                    next_run_plan=campaign_goal_plan or cross_run_plan,
                    battle_speed_readiness=battle_speed_readiness,
                )
            )
            if getattr(
                self.driver, "allow_private_lifestyle_formal_trial", False
            ) is True:
                applied_life = latest_lifestyle_applied_receipt(
                    planning_snapshot, history
                )
                if applied_life is not None:
                    plan = {
                        **plan,
                        "lifestyle_receipt_consumed": applied_life,
                    }
            if (
                getattr(self.driver, "allow_private_construction_formal_trial", False) is True
                and state_dir is not None
            ):
                applied_construction = read_construction_ledger(state_dir).get("applied")
                if (
                    isinstance(applied_construction, dict)
                    and applied_construction.get("episode_run_id") == planning_snapshot.get("episode_run_id")
                    and construction_process_identity(self.driver) == (
                        applied_construction.get("post_bridge_pid"),
                        applied_construction.get("post_bridge_creation_date"),
                    )
                ):
                    plan = {**plan, "construction_receipt_consumed": applied_construction}
            if cross_run_plan is not None:
                plan = {**plan, "cross_run_plan_used": cross_run_plan}
            if campaign_goal_plan is not None:
                plan = {
                    **plan,
                    "campaign_goal_plan_used": copy.deepcopy(campaign_goal_plan),
                }
            if feast_lifecycle_observation is not None:
                plan = {**plan, "activity_feast_lifecycle_observation": feast_lifecycle_observation}
            routable_steps = set(available_steps)
            selected_step = plan.get("selected_step")
            if (
                parse_query_battle_terminal_transition_v1_step(
                    selected_step
                )
                is not None
                and QUERY_BATTLE_TERMINAL_TRANSITION_V1_CAPABILITY
                in bridge_capabilities
            ):
                routable_steps.add(str(selected_step))
            if (
                parse_query_combat_simulation_inputs_v3_step(selected_step)
                is not None
                and QUERY_COMBAT_SIMULATION_INPUTS_V3_CAPABILITY
                in bridge_capabilities
            ):
                routable_steps.add(str(selected_step))
            if (
                parse_battle_decision_epoch_advance_step(selected_step)
                is not None
                and BATTLE_DECISION_EPOCH_ADVANCE_STEP in available_steps
            ):
                routable_steps.add(str(selected_step))
            if (
                parse_committed_route_sentinel_advance_step(selected_step)
                is not None
                and COMMITTED_ROUTE_SENTINEL_ADVANCE_STEP in available_steps
            ):
                routable_steps.add(str(selected_step))
            if (
                parse_war_objective_hold_sentinel_advance_step(selected_step)
                is not None
                and WAR_OBJECTIVE_HOLD_SENTINEL_ADVANCE_STEP
                in available_steps
            ):
                routable_steps.add(str(selected_step))
            return {
                "snapshot_id": planning_snapshot["snapshot_id"],
                "revision": planning_snapshot["revision"],
                "plan": _route_plan_to_available_step(
                    plan, routable_steps
                ),
                "_private_lifestyle_scope_v1": (
                    same_frame_feudal_lifestyle_scope(planning_snapshot, history)
                    if getattr(
                        self.driver, "allow_private_lifestyle_formal_trial", False
                    ) is True
                    else None
                ),
                "_private_lifestyle_pending_v1": (
                    unresolved_lifestyle_perk_action(
                        planning_snapshot, history
                    )
                    if getattr(
                        self.driver, "allow_private_lifestyle_formal_trial", False
                    ) is True
                    else None
                ),
                "_private_lifestyle_war_frame_v1": (
                    (
                        planning_snapshot.get("episode_run_id"),
                        played_character.get("character_id")
                        if isinstance(played_character, dict) else None,
                        planning_snapshot.get("date_raw"),
                        planning_snapshot.get("native_revision"),
                    )
                    if getattr(
                        self.driver, "allow_private_lifestyle_formal_trial", False
                    ) is True
                    and not opening_focus_first
                    and isinstance(planning_snapshot.get("active_wars"), list)
                    and planning_snapshot["active_wars"]
                    else None
                ),
                "_private_faction_snapshot_v1": (
                    planning_snapshot
                    if getattr(
                        self.driver,
                        "allow_private_faction_gift_formal_trial",
                        False,
                    ) is True
                    else None
                ),
                "_private_faction_history_v1": (
                    history
                    if getattr(
                        self.driver,
                        "allow_private_faction_gift_formal_trial",
                        False,
                    ) is True
                    else None
                ),
                "_private_construction_snapshot_v1": (
                    planning_snapshot
                    if getattr(self.driver, "allow_private_construction_formal_trial", False) is True
                    else None
                ),
                "_private_construction_history_v1": (
                    history
                    if getattr(self.driver, "allow_private_construction_formal_trial", False) is True
                    else None
                ),
                "_private_family_marriage_snapshot_v1": (
                    planning_snapshot
                    if getattr(self.driver, "allow_private_family_marriage_formal_trial", False) is True
                    else None
                ),
                "_private_m5_snapshot_v1": (
                    planning_snapshot
                    if getattr(
                        self.driver, "allow_private_m5_joint_collector", False
                    ) is True
                    else None
                ),
                "_private_m5_history_v1": (
                    history
                    if getattr(
                        self.driver, "allow_private_m5_joint_collector", False
                    ) is True
                    else None
                ),
            }

        if use_internal_view:
            planned = internal_planning_view(snapshot, plan_from_view)
        else:
            public_native_history = snapshot.get("native_command_history")
            planned = plan_from_view(
                snapshot,
                (
                    public_native_history
                    if isinstance(public_native_history, list)
                    else []
                ),
            )
        if getattr(
            self.driver, "require_initial_lifestyle_focus_before_date_advance",
            False,
        ) is True:
            # The runner consumes the opening focus proof on its own root
            # query turn. A family proposal or joint choice cannot replace
            # that selected step while retaining the unconsumed proof.
            return self._plan_initial_lifestyle_focus_first_v1(
                planned, available_steps
            )
        m5_snapshot = planned.pop("_private_m5_snapshot_v1", None)
        m5_history = planned.pop("_private_m5_history_v1", None)
        m5_enabled = getattr(
            self.driver, "allow_private_m5_joint_collector", False
        ) is True
        def observe_m5_wartime(
            current: dict[str, object],
        ) -> dict[str, object]:
            # The peacetime collector cannot consume an active-war frame. Its
            # war cash contract still needs a formal, read-only observation
            # path after the existing LIFE/construction/family consumers have
            # kept their action and material-receipt priority.
            if not (m5_enabled and isinstance(m5_snapshot, dict)
                    and isinstance(m5_snapshot.get("active_wars"), list)
                    and m5_snapshot["active_wars"]
                    and m5_snapshot.get("paused") is True
                    and m5_snapshot.get("map_ready") is True
                    and m5_snapshot.get("active_event") is None
                    and m5_snapshot.get("pending_character_interaction") is None):
                return current
            if not isinstance(m5_history, list):
                plan = current.get("plan")
                if not isinstance(plan, dict):
                    return current
                return {**current, "plan": {**plan,
                    "m5_joint_wartime_observation": {
                        "status": "source_unavailable",
                        "read_only": True,
                        "missing": ["formal_planning_history"],
                        "formal_action_ready": False}}}
            try:
                return plan_m5_wartime_query_only(
                    self.driver, current, snapshot=m5_snapshot,
                    history=m5_history, available_steps=available_steps,
                )
            except ValueError as error:
                plan = current.get("plan")
                if not isinstance(plan, dict):
                    raise
                return {**current, "plan": {**plan,
                    "m5_joint_wartime_observation": {
                        "status": "source_red", "read_only": True,
                        "formal_action_ready": False, "reason": str(error)}}}
        m5_ineligible = None
        if isinstance(m5_snapshot, dict):
            wars = m5_snapshot.get("active_wars")
            armies = m5_snapshot.get("player_armies")
            if isinstance(wars, list) and wars:
                m5_ineligible = "ineligible_active_war"
            elif isinstance(armies, list) and armies:
                m5_ineligible = "ineligible_player_army"
        if m5_enabled and m5_ineligible is not None:
            current_plan = planned.get("plan")
            if (
                isinstance(current_plan, dict)
                and current_plan.get("selected_step") == "life-advance"
            ):
                planned = {
                    **planned,
                    "plan": {
                        **current_plan,
                        "m5_joint_status": m5_ineligible,
                        "m5_joint_formal_action_ready": False,
                    },
                }
        if (
            m5_enabled
            and m5_ineligible is None
            and isinstance(planned.get("plan"), dict)
            and planned["plan"].get("selected_step") == "life-advance"
        ):
            if not isinstance(m5_snapshot, dict) or not isinstance(
                m5_history, list
            ):
                raise BridgeUnavailableError(
                    "private M5 collector lacks its formal planning view"
                )
            # M5's current source is peaceful building/gift only. Preserve an
            # already due LIFE action or receipt before its private comparison.
            if getattr(
                self.driver, "allow_private_lifestyle_formal_trial", False
            ) is True:
                planned = (
                    self._plan_initial_lifestyle_focus_first_v1(
                        planned, available_steps
                    )
                    if getattr(
                        self.driver,
                        "require_initial_lifestyle_focus_before_date_advance",
                        False,
                    ) is True
                    else self._plan_private_lifestyle_trial_v1(
                        planned, available_steps
                    )
                )
            family_snapshot = planned.get("_private_family_marriage_snapshot_v1")
            joint = plan_m5_formal_query_only(
                self.driver,
                planned,
                snapshot=m5_snapshot,
                history=m5_history,
                available_steps=available_steps,
            )
            joint_plan = joint.get("plan")
            if not (
                isinstance(joint_plan, dict)
                and joint_plan.get("selected_step") in {None, "life-advance"}
                and getattr(
                    self.driver, "allow_private_family_marriage_formal_trial", False
                ) is True
                and isinstance(family_snapshot, dict)
            ):
                return (
                    plan_child_default_private(
                        self.driver, joint, snapshot)
                    if getattr(self.driver,
                               "allow_private_guy_default_formal_trial",
                               False) is True else joint
                )
            # M5 has no typed building action. Give the independent family
            # consumer its ordinary baseline, then retain any M5 RED when
            # no family step is available.
            family_input = {
                **joint,
                "plan": {**joint_plan, "selected_step": "life-advance"},
            }
            family = self._plan_private_family_opportunity_v1(
                family_input, family_snapshot,
            )
            family_plan = family.get("plan")
            if not isinstance(family_plan, dict):
                return joint
            if joint_plan.get("phase") == "m5_joint_query_only_red":
                independent_fixed_pair = (
                    family_plan.get("current_betrothal_fulfillment") is True
                    and family_plan.get("selected_step") in {
                        PRIVATE_CURRENT_BETROTHAL_SUBMIT_STEP,
                        PRIVATE_FAMILY_MARRIAGE_RESULT_STEP,
                    }
                )
                family_plan = {**family_plan,
                    "m5_joint_red_reason": joint_plan.get("reason")}
                if not independent_fixed_pair:
                    family_plan = {**family_plan,
                        "selected_step": None,
                        "phase": joint_plan["phase"],
                        "reason": joint_plan.get("reason")}
            elif family_plan.get("selected_step") == "life-advance":
                family_plan = {
                    **family_plan,
                    "selected_step": joint_plan.get("selected_step"),
                    "phase": joint_plan.get("phase", family_plan.get("phase")),
                    "reason": joint_plan.get("reason", family_plan.get("reason")),
                }
            family = {**family, "plan": family_plan}
            return (
                plan_child_default_private(self.driver, family, snapshot)
                if getattr(self.driver,
                           "allow_private_guy_default_formal_trial",
                           False) is True else family
            )
        lifestyle_trial = getattr(
            self.driver, "allow_private_lifestyle_formal_trial", False
        ) is True
        before_lifestyle = planned.get("plan")
        before_lifestyle_step = (
            before_lifestyle.get("selected_step")
            if isinstance(before_lifestyle, dict) else None
        )
        if lifestyle_trial:
            planned = (
                self._plan_initial_lifestyle_focus_first_v1(
                    planned, available_steps
                )
                if getattr(
                    self.driver,
                    "require_initial_lifestyle_focus_before_date_advance",
                    False,
                ) is True
                else self._plan_private_lifestyle_trial_v1(
                    planned, available_steps
                )
            )
        plan = planned.get("plan")
        prewar_arbitration = (
            isinstance(plan, dict)
            and is_native_declaration_step(plan.get("selected_step"))
            and snapshot.get("paused") is True
            and snapshot.get("map_ready") is True
            and snapshot.get("active_event") is None
            and snapshot.get("pending_character_interaction") is None
            and snapshot.get("active_wars") == []
        )
        if (lifestyle_trial and isinstance(plan, dict)
                and plan.get("selected_step") != "life-advance"
                and not prewar_arbitration):
            construction_snapshot = planned.get("_private_construction_snapshot_v1")
            construction_history = planned.get("_private_construction_history_v1")
            if (getattr(self.driver, "allow_private_construction_formal_trial", False) is True
                    and isinstance(construction_snapshot, dict)
                    and isinstance(construction_history, list)
                    and plan.get("selected_step") == before_lifestyle_step
                    and (before_lifestyle_step is not None
                         or (m5_enabled
                             and isinstance(construction_snapshot.get("active_wars"), list)
                             and bool(construction_snapshot["active_wars"])))
                    and construction_snapshot.get("paused") is True
                    and construction_snapshot.get("map_ready") is True
                    and construction_snapshot.get("active_event") is None
                    and construction_snapshot.get("pending_character_interaction") is None):
                # Keep old receipts visible on ordinary war turns and feed a
                # blocked war plan's same-frame building read to M5. Neither
                # path admits a new spend or clears the selected war RED.
                construction_result = plan_construction_private(
                    self.driver, planned, construction_snapshot,
                    construction_history, available_steps,
                )
                if before_lifestyle_step is None:
                    # A due receipt for an already submitted building is a
                    # read-only follow-up, even when the war planner is RED.
                    # Retain the blocked war plan for the next formal turn;
                    # this query cannot spend resources or advance the date.
                    construction_plan = construction_result.get("plan")
                    observation = (construction_plan.get(
                        "construction_wartime_observation")
                        if isinstance(construction_plan, dict) else None)
                    readout_step = (construction_plan.get("selected_step")
                                    if isinstance(construction_plan, dict) else None)
                    due_receipt = (
                        (readout_step == PRIVATE_CONSTRUCTION_RECEIPT_STEP
                         and isinstance(construction_plan.get(
                             "construction_pending_action"), dict))
                        or (readout_step == PRIVATE_CONSTRUCTION_INCOME_QUERY_STEP
                            and isinstance(construction_plan.get(
                                "construction_receipt_consumed"), dict))
                    )
                    if due_receipt:
                        planned = {**construction_result, "plan": {
                            **construction_plan,
                            "construction_readout_war_red": {
                                "status": "blocked_deferred_for_read_only_receipt",
                                "phase": plan.get("phase"),
                                "reason": plan.get("reason"),
                                "selected_step": None,
                            },
                        }}
                    elif isinstance(observation, dict):
                        planned = {**planned, "plan": {**plan,
                            "construction_wartime_observation": observation}}
                else:
                    planned = construction_result
            family_snapshot = planned.pop("_private_family_marriage_snapshot_v1", None)
            planned = self._plan_private_family_wartime_v1(
                planned, family_snapshot,
            )
            # LIFE's wartime priority return also needs to consume an already
            # submitted child proposal on a new PID. Only its read-only result
            # step may displace the unchanged war plan here; a fresh proposal
            # remains on the ordinary domain route.
            target = getattr(self.driver, "child_matrilineal_target_v1", None)
            child_state_dir = getattr(self.driver, "state_dir", None)
            current_plan = planned.get("plan")
            if (getattr(self.driver,
                        "allow_private_player_child_matrilineal_action",
                        False) is True
                    and isinstance(target, tuple) and len(target) == 2
                    and isinstance(child_state_dir, Path)
                    and isinstance(current_plan, dict)
                    and current_plan.get("selected_step") == before_lifestyle_step
                    and isinstance(read_child_matrilineal_ledger(
                        child_state_dir).get("pending"), dict)):
                pending_read = plan_child_matrilineal_private(
                    self.driver, planned, snapshot,
                    subject_character_id=target[0],
                    candidate_character_id=target[1],
                )
                pending_plan = pending_read.get("plan")
                if (isinstance(pending_plan, dict)
                        and pending_plan.get("selected_step")
                        == PRIVATE_CHILD_MATRILINEAL_RESULT_STEP):
                    if (before_lifestyle_step is None
                            and isinstance(snapshot.get("active_wars"), list)
                            and snapshot["active_wars"]
                            and isinstance(current_plan.get("phase"), str)
                            and current_plan["phase"].startswith("native_war")):
                        pending_read = {**pending_read, "plan": {
                            **pending_plan,
                            "child_matrilineal_deferred_war_red": {
                                "status": "blocked_deferred_for_read_only_result",
                                "phase": current_plan.get("phase"),
                                "reason": current_plan.get("reason"),
                                "selected_step": None,
                            },
                        }}
                    planned = pending_read
            if getattr(self.driver, "allow_private_guy_default_formal_trial", False) is True:
                planned = plan_child_default_private(self.driver, planned, snapshot)
            planned.pop("_private_faction_snapshot_v1", None)
            planned.pop("_private_faction_history_v1", None)
            planned.pop("_private_construction_snapshot_v1", None)
            planned.pop("_private_construction_history_v1", None)
            return observe_m5_wartime(planned)
        planned.pop("_private_lifestyle_scope_v1", None)
        planned.pop("_private_lifestyle_pending_v1", None)
        planned.pop("_private_lifestyle_war_frame_v1", None)
        if getattr(
            self.driver, "allow_private_faction_gift_formal_trial", False
        ) is True:
            faction_snapshot = planned.pop("_private_faction_snapshot_v1", None)
            faction_history = planned.pop("_private_faction_history_v1", None)
            if (
                isinstance(faction_snapshot, dict)
                and isinstance(faction_history, list)
            ):
                planned = plan_faction_gift_private_v1(
                    self.driver, planned, faction_snapshot,
                    faction_history, available_steps,
                )
        planned.pop("_private_faction_snapshot_v1", None)
        planned.pop("_private_faction_history_v1", None)
        construction_snapshot = planned.pop("_private_construction_snapshot_v1", None)
        construction_history = planned.pop("_private_construction_history_v1", None)
        construction_red_plan = None
        if (
            getattr(self.driver, "allow_private_construction_formal_trial", False) is True
            and isinstance(construction_snapshot, dict)
            and isinstance(construction_history, list)
        ):
            planned = plan_construction_private(
                self.driver, planned, construction_snapshot,
                construction_history, available_steps,
                prewar_arbitration=prewar_arbitration,
            )
            construction_plan = planned.get("plan")
            if (isinstance(construction_plan, dict)
                    and isinstance(plan, dict)
                    and (plan.get("selected_step") == "life-advance"
                         or prewar_arbitration)
                    and construction_plan.get("selected_step") is None
                    and isinstance(construction_plan.get("construction_private_query"), dict)
                    and construction_plan["construction_private_query"].get("status")
                    in {"source_red", "evidence_insufficient"}):
                construction_red_plan = construction_plan
                planned = {**planned, "plan": {**construction_plan,
                    "selected_step": plan["selected_step"]}}
        family_snapshot = planned.pop("_private_family_marriage_snapshot_v1", None)
        if (getattr(self.driver, "allow_private_family_marriage_formal_trial", False) is True
                and isinstance(family_snapshot, dict)):
            if isinstance(family_snapshot.get("active_wars"), list) and family_snapshot["active_wars"]:
                planned = self._plan_private_family_wartime_v1(
                    planned, family_snapshot,
                )
            else:
                planned = self._plan_private_family_opportunity_v1(
                    planned, family_snapshot,
                    prewar_arbitration=prewar_arbitration,
                )
        target = getattr(self.driver, "child_matrilineal_target_v1", None)
        if (getattr(self.driver, "allow_private_player_child_matrilineal_action", False) is True
                and isinstance(target, tuple) and len(target) == 2):
            planned = plan_child_matrilineal_private(
                self.driver, planned, snapshot,
                subject_character_id=target[0], candidate_character_id=target[1],
            )
        if getattr(self.driver, "allow_private_guy_default_formal_trial", False) is True:
            planned = plan_child_default_private(self.driver, planned, snapshot)
        if (construction_red_plan is not None
                and isinstance(planned.get("plan"), dict)
                and planned["plan"].get("selected_step") == plan["selected_step"]):
            planned = {**planned, "plan": {**planned["plan"],
                "selected_step": None,
                "reason": construction_red_plan["reason"]}}
        planned = observe_m5_wartime(planned)
        if getattr(self.driver, "allow_private_prisoner_ransom_action", False) is True:
            planned = plan_ransom_private(self.driver, planned, snapshot)
        return planned

    def _plan_private_family_opportunity_v1(
        self, planned: dict[str, object], snapshot: dict[str, object], *,
        prewar_arbitration: bool = False, wartime_arbitration: bool = False,
        campaign_root_result: dict[str, object] | None = None,
    ) -> dict[str, object]:
        """Use the fixed existing pair before the ordinary unpartnered route."""
        if getattr(
            self.driver, "allow_private_current_first_heir_betrothal_fulfillment", False
        ) is True:
            query_history_index = None
            history_view = getattr(self.driver, "_with_internal_planning_view", None)
            history_snapshot = getattr(self.driver, "_history_snapshot", None)
            if callable(history_view) and callable(history_snapshot):
                query_history_index = history_view(
                    snapshot, lambda _frame, history: {"index": len(history)}
                )["index"]
            try:
                current = plan_current_first_heir_betrothal_fulfillment_private(
                    self.driver, planned, snapshot,
                    prewar_arbitration=prewar_arbitration,
                    wartime_arbitration=wartime_arbitration,
                    **({"campaign_root_result": campaign_root_result}
                       if campaign_root_result is not None else {}),
                )
            except BridgeUnavailableError as error:
                if getattr(error, "native_error", None) not in {
                    "campaign-root snapshot changed or is not ready",
                    "application-main typed query failed or its snapshot changed",
                }:
                    raise
                retry_snapshot = snapshot
                if query_history_index is not None:
                    retry_snapshot = {
                        **snapshot,
                        "native_command_history": history_snapshot()[:query_history_index],
                    }
                root_query_retry = self._retry_rejected_campaign_root_read(
                    retry_snapshot, planned, error
                )
                if root_query_retry is None:
                    raise
                snapshot = root_query_retry["fresh_snapshot"]
                retry_evidence = {
                    key: value
                    for key, value in root_query_retry.items()
                    if key not in ("fresh_snapshot", "starting_snapshot")
                }
                planned = {
                    **planned,
                    "snapshot_id": snapshot["snapshot_id"],
                    "revision": snapshot["revision"],
                    "plan": {**planned["plan"], "read_only_query_retry": retry_evidence},
                }
                try:
                    current = plan_current_first_heir_betrothal_fulfillment_private(
                        self.driver, planned, snapshot,
                        prewar_arbitration=prewar_arbitration,
                        wartime_arbitration=wartime_arbitration,
                    )
                except BridgeUnavailableError as retry_error:
                    error.read_only_query_retry = {
                        **retry_evidence,
                        "second_error": f"{type(retry_error).__name__}: {retry_error}",
                    }
                    raise error from retry_error
            current_plan = current.get("plan")
            if (isinstance(current_plan, dict)
                    and current_plan.get("current_betrothal_fulfillment") is True):
                return current
        return plan_family_marriage_private(
            self.driver, planned, snapshot,
            prewar_arbitration=prewar_arbitration,
            **({"wartime_arbitration": True} if wartime_arbitration else {}),
        )

    def _plan_private_family_wartime_v1(
        self, planned: dict[str, object], snapshot: object,
    ) -> dict[str, object]:
        """Inspect one war date without repeatedly enumerating family rows."""
        if (getattr(self.driver, "allow_private_family_marriage_formal_trial", False) is not True
                or not isinstance(snapshot, dict)):
            return planned
        plan = planned.get("plan")
        selected = plan.get("selected_step") if isinstance(plan, dict) else None
        actor = snapshot.get("played_character")
        frame = (snapshot.get("episode_run_id"),
                 actor.get("character_id") if isinstance(actor, dict) else None,
                 snapshot.get("date_raw"))
        if (not isinstance(selected, str)
                or not (selected == "life-advance" or selected.startswith("query-"))
                or not isinstance(snapshot.get("active_wars"), list)
                or not snapshot["active_wars"]
                or not isinstance(frame[0], str)
                or type(frame[1]) is not int or frame[1] <= 0
                or type(frame[2]) is not int
                or frame == self._last_war_family_observation):
            return planned
        result = self._plan_private_family_opportunity_v1(
            planned, snapshot, wartime_arbitration=True,
        )
        result_plan = result.get("plan")
        if (isinstance(result_plan, dict)
                and result_plan.get("selected_step") == selected
                and "family_marriage_pending" not in result_plan
                and "current_betrothal_pending" not in result_plan):
            self._last_war_family_observation = frame
        return result

    def _observe_opening_lifestyle_perks_v1(
        self, *, before: dict[str, object], focus: dict[str, object],
        revision: int, formal_query: dict[str, object] | None = None,
    ) -> dict[str, object]:
        """Record final perk legality without changing the opening focus gate."""
        unknown: dict[str, object] = {
            "status": "unknown", "query_status": "not_executed",
            "formal_precondition_status": None,
            "candidate_scope": None,
            "legal_candidate_count_in_scope": None,
            "policy_target_final_legal": None,
            "policy_target_owned": None,
        }
        if getattr(self.driver, "allow_private_lifestyle_formal_trial", False) is not True:
            return {**unknown, "query_status": "trial_off"}
        try:
            if formal_query is None:
                reader = getattr(
                    self.driver, "query_player_lifestyle_formal_private_v1", None,
                )
                if not callable(reader):
                    return {**unknown, "query_status": "reader_unavailable"}
                query = reader(expected_revision=revision)
            else:
                query = formal_query
            after = self.snapshot()
        except Exception as error:
            return {**unknown, "query_status": "query_error",
                    "error_type": type(error).__name__}
        if not isinstance(query, dict) or query.get("status") != "available":
            return {**unknown, "query_status": (
                query.get("status") if isinstance(query, dict) else "malformed_result"
            ), "native_error": (
                query.get("native_error") if isinstance(query, dict) else None
            )}
        source = query.get("source_frame")
        bound = (
            after.get("paused") is True
            and all(after.get(key) == before.get(key) for key in (
                "snapshot_id", "revision", "native_revision", "date_raw",
                "episode_run_id",
            ))
            and isinstance(source, dict)
            and all(source.get(key) == before.get(key) for key in (
                "snapshot_id", "revision", "native_revision", "date_raw",
            ))
            and query.get("episode_run_id") == before.get("episode_run_id")
            and source.get("player_character_id") == (
                before.get("played_character", {}).get("character_id")
                if isinstance(before.get("played_character"), dict) else None
            )
        )
        if not bound:
            return {**unknown, "query_status": "paused_frame_mismatch"}
        life = query.get("snapshot")
        readiness = life.get("readiness") if isinstance(life, dict) else None
        candidates = life.get("legal_perk_candidates") if isinstance(life, dict) else None
        owned = life.get("owned_perk_keys") if isinstance(life, dict) else None
        formal_focus = life.get("current_focus") if isinstance(life, dict) else None
        items = candidates.get("items") if isinstance(candidates, dict) else None
        scope = candidates.get("scope") if isinstance(candidates, dict) else None
        if not (
            isinstance(readiness, dict)
            and readiness.get("same_frame_ready") is True
            and readiness.get("legal_perk_candidates_ready") is True
            and readiness.get("owned_perks_ready") is True
            and isinstance(candidates, dict)
            and candidates.get("status") == "available"
            and (scope is None or scope == "policy_target")
            and isinstance(items, list)
            and all(isinstance(row, dict)
                    and isinstance(row.get("key"), str)
                    and isinstance(row.get("lifestyle_key"), str)
                    for row in items)
            and isinstance(owned, list)
            and all(isinstance(key, str) for key in owned)
            and isinstance(formal_focus, dict)
            and formal_focus.get("key") == focus.get("key")
            and formal_focus.get("lifestyle_key") == focus.get("lifestyle_key")
        ):
            return {**unknown, "query_status": "legal_candidates_unavailable"}
        keys = {row["key"] for row in items}
        policy_scoped = scope == "policy_target"
        return {
            "status": "observed", "query_status": "available",
            "formal_precondition_status": query.get("formal_precondition_status"),
            "candidate_scope": "policy_target" if policy_scoped else "full_inventory",
            "legal_candidate_count_in_scope": len(items),
            "policy_target_final_legal": {
                key: (True if key in keys else None if policy_scoped else False)
                for key in sorted(PERK_TARGETS)
            },
            "policy_target_owned": {
                key: key in owned for key in sorted(PERK_TARGETS)
            },
        }

    def _observe_opening_martial_authority_v1(
        self, *, before: dict[str, object], revision: int,
        require_current_frame: bool = False,
    ) -> dict[str, object] | None:
        """Read one private alternative on this episode's opening frame."""
        if getattr(self.driver, "allow_private_lifestyle_formal_trial", False) is not True:
            return None
        episode = before.get("episode_run_id")
        if not isinstance(episode, str) or not episode:
            return {"status": "episode_unavailable"}
        if episode == self._opening_martial_episode_v1:
            cached = dict(self._opening_martial_observation_v1 or {})
            source = cached.get("source_frame")
            if not require_current_frame or (
                cached.get("status") == "observed"
                and isinstance(source, dict)
                and all(source.get(key) == before.get(key) for key in (
                    "snapshot_id", "native_revision", "date_raw", "episode_run_id",
                ))
            ):
                return cached
        reader = getattr(
            self.driver, "query_player_lifestyle_martial_authority_private_v1", None,
        )
        if not callable(reader):
            result: dict[str, object] = {"status": "query_route_unavailable"}
        else:
            try:
                query = reader(expected_revision=revision)
                after = self.snapshot()
            except Exception as error:
                result = {"status": "query_error", "error_type": type(error).__name__}
            else:
                binding = (
                    "snapshot_id", "revision", "native_revision", "date_raw",
                    "episode_run_id",
                )
                if (after.get("paused") is not True or any(
                    after.get(key) != before.get(key) for key in binding
                )):
                    result = {"status": "red", "issue": "opening_frame_changed"}
                elif not isinstance(query, dict):
                    result = {"status": "malformed_query_result"}
                else:
                    result = {key: query[key] for key in (
                        "status", "issue", "native_legal", "target_key",
                        "target_lifestyle_key", "target_lifestyle_progress",
                        "source_frame",
                    ) if key in query}
        self._opening_martial_episode_v1 = episode
        self._opening_martial_observation_v1 = dict(result)
        return result

    def _plan_initial_lifestyle_focus_first_v1(
        self, planned: dict[str, object], available_steps: set[str]
    ) -> dict[str, object]:
        """Opt-in opening LIFE observation before any war query or date step."""
        plan = planned.get("plan")
        if not isinstance(plan, dict):
            return planned

        readback_diagnostic: dict[str, object] = {}

        def summarize_readback(value: object) -> dict[str, object]:
            if not isinstance(value, dict):
                return {"status": "not_a_mapping"}
            summary = {
                key: value.get(key)
                for key in ("status", "issue", "native_error", "source_frame")
                if key in value
            }
            native_result = value.get("native_result")
            if isinstance(native_result, dict):
                summary["native_result_status"] = native_result.get("status")
            for key in ("state", "focus", "focus_query"):
                if key in value:
                    summary[key] = summarize_readback(value[key])
            return summary

        def blocked(reason: str) -> dict[str, object]:
            return {
                **planned,
                "plan": {
                    **plan, "phase": "initial_lifestyle_focus_observation_red",
                    "selected_step": None, "reason": reason,
                    "opening_lifestyle_readback_diagnostic": readback_diagnostic,
                },
            }

        stage = getattr(
            self.driver, "initial_lifestyle_focus_gate_stage", "await_submit"
        )
        if stage == "await_receipt":
            if not isinstance(planned.get("_private_lifestyle_pending_v1"), dict):
                return blocked("opening focus receipt has no one-time pending action")
            receipt = self._plan_private_lifestyle_trial_v1(planned, available_steps)
            receipt_plan = receipt.get("plan")
            if not (
                isinstance(receipt_plan, dict)
                and receipt_plan.get("selected_step") == PRIVATE_LIFESTYLE_RECEIPT_STEP
            ):
                return blocked("opening focus receipt lacks an independent later frame")
            return receipt
        if stage == "await_consumption":
            consumed = plan.get("lifestyle_receipt_consumed")
            if not isinstance(consumed, dict):
                return blocked("opening focus receipt has not reached the following turn")
            if PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP not in available_steps:
                return blocked("opening focus consumption query is unavailable")
            return {
                **planned,
                "plan": {
                    **plan, "phase": "initial_lifestyle_focus_consumption",
                    "selected_step": PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP,
                    "lifestyle_receipt_consumed": consumed,
                },
            }
        if stage != "await_submit":
            return blocked("opening focus gate stage is unknown")

        revision = planned.get("revision")
        if isinstance(revision, bool) or not isinstance(revision, int):
            return blocked("opening focus has no paused public revision")
        before = self.snapshot()
        if not (
            before.get("paused") is True
            and before.get("snapshot_id") == planned.get("snapshot_id")
            and before.get("revision") == revision
        ):
            return blocked("opening focus planning frame changed")
        binding = (
            "snapshot_id", "revision", "native_revision", "date_raw",
            "episode_run_id",
        )
        readback_diagnostic["before"] = {
            key: before.get(key) for key in binding
        }
        current_reader = getattr(
            self.driver, "query_player_lifestyle_current_state_private_v1", None,
        )
        if callable(current_reader):
            current = current_reader(expected_revision=revision)
            current_after = self.snapshot()
            readback_diagnostic["current_state"] = summarize_readback(current)
            readback_diagnostic["after_current_state"] = {
                key: current_after.get(key) for key in binding
            }
            current_source = (
                current.get("source_frame") if isinstance(current, dict) else None
            )
            current_life = (
                current.get("snapshot") if isinstance(current, dict) else None
            )
            current_focus = (
                current_life.get("current_focus")
                if isinstance(current_life, dict) else None
            )
            current_progress = (
                current_life.get("current_lifestyle_progress")
                if isinstance(current_life, dict) else None
            )
            current_readiness = (
                current_life.get("readiness")
                if isinstance(current_life, dict) else None
            )
            if (
                isinstance(current, dict)
                and current.get("status") == "available"
                and current_after.get("paused") is True
                and all(before.get(key) == current_after.get(key)
                        for key in binding)
                and isinstance(current_source, dict)
                and all(current_source.get(key) == before.get(key)
                        for key in ("snapshot_id", "revision",
                                    "native_revision", "date_raw"))
                and isinstance(current_focus, dict)
                and current_focus.get("presence") == "absent"
            ):
                martial_observation = self._observe_opening_martial_authority_v1(
                    before=before, revision=revision,
                    require_current_frame=True,
                )
                if isinstance(martial_observation, dict):
                    plan = {**plan, "opening_lifestyle_martial_observation":
                            martial_observation}
            if (
                isinstance(current, dict)
                and current.get("status") == "available"
                and current_after.get("paused") is True
                and all(before.get(key) == current_after.get(key) for key in binding)
                and isinstance(current_source, dict)
                and all(
                    current_source.get(key) == before.get(key)
                    for key in ("snapshot_id", "revision", "native_revision", "date_raw")
                )
                and isinstance(current_focus, dict)
                and current_focus.get("presence") == "present"
            ):
                numeric = (
                    "xp_total_raw", "xp_within_level_raw", "xp_per_level",
                    "unspent_perk_points", "used_perk_points",
                )
                if not (
                    isinstance(current_readiness, dict)
                    and current_readiness.get("current_focus_ready") is True
                    and current_readiness.get("lifestyle_progress_ready") is True
                    and isinstance(current_focus.get("key"), str)
                    and current_focus.get("key")
                    and isinstance(current_focus.get("lifestyle_key"), str)
                    and isinstance(current_progress, dict)
                    and current_progress.get("presence") == "present"
                    and current_progress.get("lifestyle_key")
                    == current_focus.get("lifestyle_key")
                    and all(
                        isinstance(current_progress.get(key), int)
                        and not isinstance(current_progress.get(key), bool)
                        and current_progress[key] >= 0
                        for key in numeric
                    )
                    and current_progress["xp_per_level"] > 0
                ):
                    return blocked("existing opening focus lacks exact current XP/points")
                if PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP not in available_steps:
                    return blocked("opening existing-focus read-only turn is unavailable")
                perk_observation = self._observe_opening_lifestyle_perks_v1(
                    before=before, focus=current_focus, revision=revision,
                )
                martial_observation = self._observe_opening_martial_authority_v1(
                    before=before, revision=revision,
                )
                return {
                    **planned,
                    "plan": {
                        **plan, "phase": "initial_lifestyle_focus_already_present",
                        "selected_step": PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP,
                        **({"opening_lifestyle_martial_observation":
                            martial_observation}
                           if isinstance(martial_observation, dict) else {}),
                        "initial_lifestyle_focus_existing": {
                            "status": "verified_existing",
                            "readback_source": "native_current_state_only",
                            "source_frame": current_source,
                            "current_focus": current_focus,
                            "current_lifestyle_progress": current_progress,
                            "perk_opportunity": perk_observation,
                            **(
                                {"actor_traits": current_life["actor_traits"]}
                                if isinstance(current_life.get("actor_traits"), dict)
                                else {}
                            ),
                        },
                    },
                }
        formal_reader = getattr(
            self.driver, "query_player_lifestyle_formal_private_v1", None
        )
        stock_reader = getattr(
            self.driver,
            "query_player_lifestyle_stock_focus_combined_private_v1", None,
        )
        if not callable(formal_reader) or not callable(stock_reader):
            return blocked("opening LIFE2 or stock final-legal query is missing")
        formal = formal_reader(expected_revision=revision)
        stock = stock_reader(expected_revision=revision)
        after = self.snapshot()
        readback_diagnostic["formal"] = summarize_readback(formal)
        readback_diagnostic["stock"] = summarize_readback(stock)
        readback_diagnostic["after_formal_stock"] = {
            key: after.get(key) for key in binding
        }
        formal_source = (
            formal.get("source_frame") if isinstance(formal, dict) else None
        )
        failed_predicates = []
        if not (
            after.get("paused") is True
            and all(before.get(key) == after.get(key) for key in binding)
        ):
            failed_predicates.append("service_paused_frame_drift")
        if not isinstance(formal, dict) or formal.get("status") != "available":
            failed_predicates.append("formal_status_unavailable")
        elif not (
            isinstance(formal_source, dict)
            and formal_source.get("snapshot_id") == before.get("snapshot_id")
            and formal_source.get("revision") == revision
            and formal_source.get("native_revision")
            == before.get("native_revision")
            and formal_source.get("date_raw") == before.get("date_raw")
        ):
            failed_predicates.append("formal_source_frame_mismatch")
        if not isinstance(stock, dict) or stock.get("status") not in {
            "stock_focus_available", "stock_focus_readback_red",
        }:
            failed_predicates.append("stock_status_unavailable")
        if failed_predicates:
            readback_diagnostic["failed_predicates"] = failed_predicates
            return blocked("opening LIFE2/stock readback is not one paused frame")
        stock_focus = (
            stock.get("focus_query")
            if stock.get("status") == "stock_focus_available"
            else stock.get("focus")
        )
        if not (
            isinstance(stock_focus, dict)
            and stock_focus.get("status") == "observed"
            and isinstance(stock_focus.get("native_legal"), bool)
            and isinstance(stock_focus.get("source_frame"), dict)
            and stock_focus["source_frame"].get("snapshot_id")
            == before.get("snapshot_id")
            and stock_focus["source_frame"].get("native_revision")
            == before.get("native_revision")
            and stock_focus["source_frame"].get("date_raw")
            == before.get("date_raw")
        ):
            return blocked("opening stock focus final legality was not observed")
        life = formal.get("snapshot")
        readiness = life.get("readiness") if isinstance(life, dict) else None
        focus = life.get("current_focus") if isinstance(life, dict) else None
        progress = (
            life.get("current_lifestyle_progress")
            if isinstance(life, dict) else None
        )
        if not (
            isinstance(readiness, dict)
            and readiness.get("current_focus_ready") is True
            and readiness.get("lifestyle_progress_ready") is True
            and isinstance(focus, dict)
            and isinstance(progress, dict)
        ):
            return blocked("opening LIFE2 current focus or XP/points are unavailable")
        martial_observation = self._observe_opening_martial_authority_v1(
            before=before, revision=revision,
            require_current_frame=focus.get("presence") == "absent",
        )
        if isinstance(martial_observation, dict):
            plan = {**plan, "opening_lifestyle_martial_observation":
                    martial_observation}
        if focus.get("presence") == "present":
            numeric = (
                "xp_total_raw", "xp_within_level_raw", "xp_per_level",
                "unspent_perk_points", "used_perk_points",
            )
            if not (
                isinstance(focus.get("key"), str) and focus.get("key")
                and isinstance(focus.get("lifestyle_key"), str)
                and progress.get("presence") == "present"
                and progress.get("lifestyle_key") == focus.get("lifestyle_key")
                and all(
                    isinstance(progress.get(key), int)
                    and not isinstance(progress.get(key), bool)
                    and progress[key] >= 0
                    for key in numeric
                )
                and progress["xp_per_level"] > 0
            ):
                return blocked("existing opening focus lacks exact current XP/points")
            if PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP not in available_steps:
                return blocked("opening existing-focus read-only turn is unavailable")
            return {
                **planned,
                "plan": {
                    **plan, "phase": "initial_lifestyle_focus_already_present",
                    "selected_step": PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP,
                    "initial_lifestyle_focus_existing": {
                        "status": "verified_existing",
                        "readback_source": "native_formal_and_stock",
                        "source_frame": formal["source_frame"],
                        "current_focus": focus,
                        "current_lifestyle_progress": progress,
                        "stock_focus_native_legal": stock_focus["native_legal"],
                        "perk_opportunity": self._observe_opening_lifestyle_perks_v1(
                            before=before, focus=focus, revision=revision,
                            formal_query=formal,
                        ),
                        **(
                            {"actor_traits": life["actor_traits"]}
                            if isinstance(life.get("actor_traits"), dict)
                            else {}
                        ),
                    },
                },
            }
        if not (
            focus.get("presence") == "absent"
            and progress.get("presence") == "absent"
        ):
            return blocked("opening focus absence or target progress is unproved")
        scope = planned.get("_private_lifestyle_scope_v1")
        if not isinstance(scope, dict) or scope.get("status") not in {
            "admitted", "root_query_needed",
        }:
            return blocked("opening standard-feudal scope is unproved")
        first_focus = choose_first_focus_target(
            wealth=stock_focus, martial=martial_observation,
            actor_traits=life.get("actor_traits"),
            at_peace=scope.get("at_peace") is True,
        )
        plan = {**plan, "opening_first_focus_comparison": first_focus}
        selected_focus = first_focus.get("target_key")
        if selected_focus not in {
            "stewardship_wealth_focus", "martial_authority_focus",
        }:
            return blocked("opening focus has no observed native-legal target")
        if isinstance(scope, dict) and scope.get("status") == "root_query_needed":
            if PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP not in available_steps:
                return blocked("opening feudal root query is unavailable")
            return {
                **planned,
                "plan": {
                    **plan, "phase": "initial_lifestyle_feudal_scope_query",
                    "selected_step": PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP,
                    "opening_lifestyle_readback": "absent_native_legal",
                },
            }
        # The exact target query must be last before typed submit. Reading the
        # other target for comparison cannot authorize this one.
        selected_query = query_player_lifestyle_stock_focus_combined_private_v1(
            self.driver, expected_revision=revision, target_key=selected_focus,
        )
        if selected_query.get("status") != "stock_focus_available":
            return blocked("selected opening focus lacks a fresh final-legal frame")
        consumed = consume_one_life_lifestyle_private_trial(
            plan, same_frame_feudal_scope=scope, private_query=selected_query,
            preferred_focus_target_key=selected_focus,
            allow_wartime_initial_focus=True,
        )
        if consumed.get("selected_step") != PRIVATE_LIFESTYLE_FOCUS_STEP:
            return blocked("opening stock focus was not selected by policy")
        if not callable(getattr(
            self.driver, "submit_player_lifestyle_stock_focus_private_v1", None
        )):
            return blocked("opening typed focus route is unavailable")
        return {
            **planned,
            "plan": _route_plan_to_available_step(
                consumed, {PRIVATE_LIFESTYLE_FOCUS_STEP}
            ),
        }

    def _plan_private_lifestyle_trial_v1(
        self, planned: dict[str, object], available_steps: set[str]
    ) -> dict[str, object]:
        """Spend a ready perk before time advance or a deferrable read."""

        scope = planned.pop("_private_lifestyle_scope_v1", None)
        pending = planned.pop("_private_lifestyle_pending_v1", None)
        war_frame = planned.pop("_private_lifestyle_war_frame_v1", None)
        plan = planned.get("plan")
        selected = plan.get("selected_step") if isinstance(plan, dict) else None
        combat_read = (
            parse_query_combat_simulation_inputs_v3_step(selected) is not None
        )
        root_read = selected == PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP
        # A blocked war plan has no action to displace. Keep its RED visible
        # while the independent, native-gated LIFE consumer uses this frame.
        blocked_war_step = (
            selected is None
            and isinstance(plan, dict)
            and isinstance(plan.get("phase"), str)
            and plan["phase"].startswith("native_war")
        )
        deferred_war_red = (
            {key: plan.get(key) for key in (
                "policy", "phase", "selected_step", "reason",
            )}
            if blocked_war_step else None
        )
        peaceful_root_read = (
            root_read
            and isinstance(scope, dict)
            and scope.get("status") == "admitted"
            and scope.get("at_peace") is True
        )
        war_read_step = (
            (blocked_war_step or
             isinstance(selected, str) and selected.startswith("query-"))
            and isinstance(scope, dict)
            and scope.get("at_peace") is False
            and isinstance(war_frame, tuple)
            and len(war_frame) == 4
            and isinstance(war_frame[0], str)
            and isinstance(war_frame[1], int)
            and not isinstance(war_frame[1], bool)
            and isinstance(war_frame[2], int)
            and not isinstance(war_frame[2], bool)
            and isinstance(war_frame[3], int)
            and not isinstance(war_frame[3], bool)
            and war_frame[3] > 0
        )
        war_read_due = (
            war_read_step
            and war_frame != self._last_war_lifestyle_observation
        )
        deferrable_read = combat_read or peaceful_root_read or war_read_due
        if isinstance(pending, dict):
            # The previous typed request may already have changed CK3.  A
            # later paused frame is required before any new LIFE choice.
            if not isinstance(plan, dict):
                return planned
            if selected != "life-advance" and not (
                combat_read or root_read or war_read_step
            ):
                return planned
            pre_revision = pending.get("pre_public_revision")
            if (
                isinstance(pre_revision, int)
                and not isinstance(pre_revision, bool)
                and int(planned["revision"]) > pre_revision
            ):
                receipt_plan = {
                    **plan,
                    "phase": "lifestyle_selection_receipt_query",
                    "selected_step": PRIVATE_LIFESTYLE_RECEIPT_STEP,
                    "lifestyle_pending_action": pending,
                    "reason": "confirm the material focus or perk on a later paused frame",
                    **({"lifestyle_deferred_war_red": deferred_war_red}
                       if deferred_war_red is not None else {}),
                }
                return {
                    **planned,
                    "plan": _route_plan_to_available_step(
                        receipt_plan,
                        {PRIVATE_LIFESTYLE_RECEIPT_STEP},
                    ),
                }
            waiting = {**plan, "lifestyle_pending_action": pending}
            if selected == "life-advance":
                waiting["reason"] = (
                    "advance a bounded native interval to an independent receipt frame"
                )
            return {**planned, "plan": waiting}
        if not isinstance(plan, dict) or (
            selected != "life-advance" and not deferrable_read
        ):
            return planned
        if not isinstance(scope, dict):
            scope = {"status": "scope_unavailable"}
        query = None
        if scope.get("status") == "admitted":
            reader = getattr(
                self.driver, "query_player_lifestyle_formal_private_v1", None
            )
            query = (
                reader(expected_revision=int(planned["revision"]))
                if callable(reader)
                else {"status": "private_query_route_missing"}
            )
            formal_life = query.get("snapshot") if isinstance(query, dict) else None
            formal_focus = (
                formal_life.get("current_focus")
                if isinstance(formal_life, dict) else None
            )
            if (
                (not (combat_read or war_read_due) or scope.get("at_peace") is True)
                and isinstance(query, dict)
                and (
                    query.get("status") != "available"
                    or (
                        isinstance(formal_focus, dict)
                        and formal_focus.get("presence") == "absent"
                    )
                )
            ):
                focus_reader = getattr(
                    self.driver,
                    "query_player_lifestyle_stock_focus_combined_private_v1",
                    None,
                )
                if callable(focus_reader):
                    query = focus_reader(expected_revision=int(planned["revision"]))
            ending = self.snapshot()
            if not (
                ending.get("paused") is True
                and ending.get("snapshot_id") == planned.get("snapshot_id")
                and ending.get("revision") == planned.get("revision")
            ):
                query = {"status": "paused_frame_changed_during_private_query"}
        consumed = consume_one_life_lifestyle_private_trial(
            plan if not deferrable_read else {**plan, "selected_step": "life-advance"},
            same_frame_feudal_scope=scope,
            private_query=query,
        )
        if war_read_due and isinstance(query, dict) and query.get("status") == "available":
            decision = consumed.get("lifestyle_decision")
            if (
                isinstance(decision, dict)
                and decision.get("status") in {
                    "no_legal_minimum", "outside_admitted_scene",
                }
            ):
                # Cache only a completed no-action assessment for this exact
                # native revision. A selected action still needs a material
                # receipt and may be rejected before any native submit.
                self._last_war_lifestyle_observation = war_frame
        if war_read_due and isinstance(query, dict):
            life = query.get("snapshot")
            focus = life.get("current_focus") if isinstance(life, dict) else None
            progress = (
                life.get("current_lifestyle_progress")
                if isinstance(life, dict) else None
            )
            consumed = {
                **consumed,
                "lifestyle_war_observation": {
                    "query_status": query.get("status"),
                    "date_raw": war_frame[2],
                    "native_revision": war_frame[3],
                    "source_frame": query.get("source_frame"),
                    "unspent_perk_points": (
                        progress.get("unspent_perk_points")
                        if isinstance(progress, dict) else None
                    ),
                    "current_focus": (
                        {key: focus.get(key) for key in (
                            "presence", "key", "lifestyle_key",
                        )} if isinstance(focus, dict) else None
                    ),
                    "current_lifestyle_progress": (
                        {key: progress.get(key) for key in (
                            "presence", "lifestyle_key", "xp_total_raw",
                            "xp_within_level_raw", "xp_per_level",
                            "unspent_perk_points", "used_perk_points",
                        )} if isinstance(progress, dict) else None
                    ),
                    "policy_decision_status": (
                        consumed.get("lifestyle_decision", {}).get("status")
                        if isinstance(consumed.get("lifestyle_decision"), dict)
                        else None
                    ),
                },
            }
        if deferrable_read and consumed.get("selected_step") not in {
            PRIVATE_LIFESTYLE_PERK_STEP,
            PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP,
        }:
            # Keep the original read when this frame has no final-legal perk
            # or the LIFE source is unavailable.
            return {
                **planned,
                "plan": {
                    **plan,
                    "lifestyle_opportunity_status": (
                        consumed["lifestyle_decision"].get("status")
                        if war_read_due
                        and isinstance(consumed.get("lifestyle_decision"), dict)
                        else consumed.get("phase", "no_legal_minimum")
                    ),
                    "lifestyle_decision": consumed.get("lifestyle_decision"),
                    **(
                        {"lifestyle_war_observation": consumed[
                            "lifestyle_war_observation"
                        ]}
                        if "lifestyle_war_observation" in consumed else {}
                    ),
                },
            }
        if (
            deferrable_read
            and consumed.get("selected_step") == PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP
            and PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP not in available_steps
        ):
            return {
                **planned,
                "plan": {
                    **plan,
                    "lifestyle_opportunity_status": "feudal_scope_query_unavailable",
                },
            }
        if (
            consumed.get("selected_step") == PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP
            and PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP not in available_steps
        ):
            consumed = {
                **consumed,
                "selected_step": None,
                "required_step": PRIVATE_LIFESTYLE_SCOPE_QUERY_STEP,
                "reason": "bounded LIFE trial cannot observe feudal scope via the public root query",
            }
        if (deferred_war_red is not None
                and consumed.get("selected_step") is not None):
            consumed = {
                **consumed, "lifestyle_deferred_war_red": deferred_war_red,
            }
        routable = set(available_steps)
        if callable(
            getattr(self.driver, "submit_player_lifestyle_perk_private_v1", None)
        ):
            routable.add(PRIVATE_LIFESTYLE_PERK_STEP)
        if callable(
            getattr(self.driver, "submit_player_lifestyle_stock_focus_private_v1", None)
        ):
            routable.add(PRIVATE_LIFESTYLE_FOCUS_STEP)
        return {
            **planned,
            "plan": _route_plan_to_available_step(consumed, routable),
        }

    def _strategy_state_dir(self):
        state_dir = getattr(self.driver, "state_dir", None)
        if state_dir is not None:
            return state_dir
        native = getattr(self.driver, "native", None)
        return getattr(native, "state_dir", None)

    def _loaded_playset_proof_for_snapshot(
        self, snapshot: dict[str, object]
    ) -> dict[str, object]:
        """Attest the managed loaded playset without changing static manifest truth."""
        episode_run_id = snapshot.get("episode_run_id")
        state_dir = self._strategy_state_dir()
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello")
            if isinstance(diagnostics, dict)
            else None
        )
        snapshot_binding = {
            "snapshot_id": snapshot.get("snapshot_id"),
            "revision": snapshot.get("revision"),
            "native_revision": snapshot.get("native_revision"),
        }
        if state_dir is None:
            return unavailable_loaded_playset_proof(
                episode_run_id=episode_run_id,
                reason="managed_state_dir_unavailable",
            )
        try:
            proof = build_loaded_playset_proof(
                state_dir,
                episode_run_id=episode_run_id,
                snapshot_binding=snapshot_binding,
                native_hello=hello,
            )
            latest = self.snapshot()
            latest_binding = {
                "snapshot_id": latest.get("snapshot_id"),
                "revision": latest.get("revision"),
                "native_revision": latest.get("native_revision"),
            }
            if not (
                latest.get("paused") is True
                and latest.get("episode_run_id") == episode_run_id
                and latest_binding == snapshot_binding
            ):
                return unavailable_loaded_playset_proof(
                    episode_run_id=episode_run_id,
                    reason="snapshot_changed_during_loaded_playset_proof",
                )
            return proof
        except (LoadedPlaysetProofError, OSError, UnicodeError) as error:
            return unavailable_loaded_playset_proof(
                episode_run_id=episode_run_id,
                reason=f"{type(error).__name__}: {error}",
            )

    def auto_turn(
        self,
        *,
        before_submit: Callable[[dict[str, object]], dict[str, object] | None]
        | None = None,
    ) -> dict[str, object]:
        """Plan and execute exactly one backend-supported gameplay turn."""
        return self._execute_planned_turn(self.plan_turn(), before_submit=before_submit)

    def auto_nonwar_turn(
        self, *, before_submit: Callable[[dict[str, object]], dict[str, object] | None] | None = None,
    ) -> dict[str, object]:
        """Execute one planned nonwar action through the existing typed dispatch."""
        return self._execute_planned_turn(self.plan_nonwar_turn(), before_submit=before_submit)

    def _execute_planned_turn(
        self, planned: dict[str, object], *,
        before_submit: Callable[[dict[str, object]], dict[str, object] | None] | None = None,
    ) -> dict[str, object]:
        plan = planned.get("plan")
        selected_step = plan.get("selected_step") if isinstance(plan, dict) else None
        if not isinstance(selected_step, str) or not selected_step:
            succession_lifecycle = (
                plan.get("succession_lifecycle")
                if isinstance(plan, dict)
                else None
            )
            has_succession_reconciliation_route = all(
                callable(getattr(self.driver, method, None))
                for method in (
                    "retain_succession_expectation_v1",
                    "reconcile_retained_succession_transition_v1",
                )
            )
            legacy_rogue_terminal_without_reconciliation = bool(
                isinstance(plan, dict)
                and plan.get("phase")
                == "terminal_successor_reconciliation_pending"
                and isinstance(succession_lifecycle, dict)
                and succession_lifecycle.get("lifecycle") == "rogue_one_life"
                and not has_succession_reconciliation_route
            )
            return {
                "status": (
                    "terminal"
                    if isinstance(plan, dict)
                    and (
                        plan.get("phase") == "terminal_complete"
                        or legacy_rogue_terminal_without_reconciliation
                    )
                    else "blocked"
                ),
                "plan": plan,
                "snapshot_id": planned.get("snapshot_id"),
                "revision": planned.get("revision"),
            }
        if before_submit is not None:
            interception = before_submit(
                {
                    "plan": copy.deepcopy(plan),
                    "selected_step": selected_step,
                    "snapshot_id": planned.get("snapshot_id"),
                    "revision": planned.get("revision"),
                }
            )
            if interception is not None:
                if not isinstance(interception, dict):
                    raise TypeError("before_submit must return a mapping or None")
                return {
                    "status": "intercepted",
                    "plan": plan,
                    "selected_step": selected_step,
                    "snapshot_id": planned.get("snapshot_id"),
                    "revision": planned.get("revision"),
                    "interception": copy.deepcopy(interception),
                }
        planned_event = (
            plan.get("active_event") if isinstance(plan, dict) else None
        )
        planned_event_id = (
            planned_event.get("instance_id")
            if isinstance(planned_event, dict)
            else None
        )
        event_option_number = parse_event_option_step(selected_step)
        root_query_start = None
        root_query_retry = None
        try:
            if selected_step == QUERY_CAMPAIGN_ROOT_CONTEXT_V1_STEP:
                root_query_start = self.snapshot()
            if (
                event_option_number is not None
                and isinstance(planned_event_id, int)
                and not isinstance(planned_event_id, bool)
                and 1 <= planned_event_id <= 2**31 - 1
            ):
                result = self.select_event_option(
                    event_option_number,
                    event_instance_id=planned_event_id,
                    expected_revision=int(planned["revision"]),
                )
            elif selected_step == "private-assign-councillor-v1":
                from ..private_council_formal_consumer_v1 import submit_council_private

                result = submit_council_private(self.driver, plan=plan,
                                               expected_revision=int(planned["revision"]))
            elif selected_step == "private-query-assign-councillor-receipt-v1":
                from ..private_council_formal_consumer_v1 import read_council_receipt_private

                pending = plan.get("council_pending_action")
                if not isinstance(pending, dict):
                    raise UnsupportedStepError("private council receipt lacks its pending assignment")
                result = read_council_receipt_private(self.driver, pending=pending,
                                                     expected_revision=int(planned["revision"]))
            elif selected_step == ASSIGN_COUNCILLOR_V1_STEP:
                assignment = (
                    plan.get("council_assignment")
                    if isinstance(plan, dict)
                    else None
                )
                executor = getattr(self.driver, "assign_councillor_v1", None)
                if not (
                    isinstance(assignment, dict)
                    and isinstance(assignment.get("observation"), dict)
                    and isinstance(assignment.get("candidate_character_id"), int)
                    and not isinstance(
                        assignment.get("candidate_character_id"), bool
                    )
                    and callable(executor)
                ):
                    raise UnsupportedStepError(
                        "selected backend has no typed assign-councillor executor"
                    )
                result = executor(
                    assignment["observation"],
                    candidate_character_id=assignment[
                        "candidate_character_id"
                    ],
                    expected_revision=int(planned["revision"]),
                )
            elif selected_step == PRIVATE_LIFESTYLE_PERK_STEP:
                action = plan.get("lifestyle_action")
                query = plan.get("lifestyle_query")
                executor = getattr(
                    self.driver, "submit_player_lifestyle_perk_private_v1", None
                )
                if not (
                    isinstance(action, dict)
                    and isinstance(query, dict)
                    and callable(executor)
                ):
                    raise UnsupportedStepError(
                        "controlled LIFE perk lacks a typed private executor"
                    )
                result = executor(
                    query=query,
                    action=action,
                    expected_revision=int(planned["revision"]),
                )
            elif selected_step == PRIVATE_LIFESTYLE_FOCUS_STEP:
                action = plan.get("lifestyle_action")
                query = plan.get("lifestyle_query")
                executor = getattr(
                    self.driver,
                    "submit_player_lifestyle_stock_focus_private_v1", None,
                )
                if not (
                    isinstance(action, dict)
                    and isinstance(query, dict)
                    and callable(executor)
                ):
                    raise UnsupportedStepError(
                        "controlled LIFE focus lacks a typed private executor"
                    )
                result = executor(
                    query=query,
                    action=action,
                    expected_revision=int(planned["revision"]),
                )
            elif selected_step == PRIVATE_LIFESTYLE_RECEIPT_STEP:
                pending = plan.get("lifestyle_pending_action")
                executor = getattr(
                    self.driver, "query_player_lifestyle_receipt_private_v1", None
                )
                if not (isinstance(pending, dict) and callable(executor)):
                    raise UnsupportedStepError(
                        "controlled LIFE receipt lacks its pending action ID"
                    )
                result = executor(
                    pending=pending,
                    expected_revision=int(planned["revision"]),
                )
            elif selected_step == PRIVATE_CONSTRUCTION_SUBMIT_STEP:
                query = plan.get("construction_private_query")
                if not isinstance(query, dict):
                    raise UnsupportedStepError("controlled construction lacks typed candidate")
                result = submit_construction_private(
                    self.driver, query=query, expected_revision=int(planned["revision"]),
                )
            elif selected_step == PRIVATE_CONSTRUCTION_RECEIPT_STEP:
                pending = plan.get("construction_pending_action")
                if not isinstance(pending, dict):
                    raise UnsupportedStepError("controlled construction receipt lacks pending identity")
                result = query_construction_receipt(
                    self.driver, pending=pending, expected_revision=int(planned["revision"]),
                )
            elif selected_step == PRIVATE_CURRENT_BETROTHAL_SUBMIT_STEP:
                result = submit_current_first_heir_betrothal_fulfillment_private(
                    self.driver, plan=plan, snapshot=self.snapshot())
            elif (selected_step == PRIVATE_FAMILY_MARRIAGE_RESULT_STEP
                  and plan.get("current_betrothal_fulfillment") is True):
                pending = plan.get("current_betrothal_pending")
                if not isinstance(pending, dict):
                    raise UnsupportedStepError(
                        "controlled betrothal fulfillment lacks pending identity")
                result = query_current_first_heir_betrothal_fulfillment_result_private(
                    self.driver, pending=pending,
                    cold=plan.get("current_betrothal_cold_recovery") is True)
            elif selected_step == PRIVATE_FAMILY_MARRIAGE_SUBMIT_STEP:
                if not (isinstance(plan.get("family_marriage_legality"), dict)
                        and isinstance(plan.get("family_marriage_choice"), dict)):
                    raise UnsupportedStepError("controlled first-heir marriage lacks a valued candidate")
                result = submit_family_marriage_private(
                    self.driver, plan=plan, snapshot=self.snapshot())
            elif selected_step == PRIVATE_FAMILY_MARRIAGE_RESULT_STEP:
                pending = plan.get("family_marriage_pending")
                if not isinstance(pending, dict):
                    raise UnsupportedStepError("controlled first-heir marriage lacks pending identity")
                result = query_family_marriage_result_private(
                    self.driver, pending=pending,
                    cold=plan.get("family_marriage_cold_recovery") is True)
            elif selected_step == PRIVATE_FAMILY_MARRIAGE_ALLIANCE_RESULT_STEP:
                resolved = plan.get("family_marriage_resolved")
                if not isinstance(resolved, dict):
                    raise UnsupportedStepError(
                        "controlled first-heir alliance lacks resolved identity")
                result = query_family_marriage_alliance_result_private(
                    self.driver, resolved=resolved)
            elif selected_step == PRIVATE_CHILD_MATRILINEAL_SUBMIT_STEP:
                result = submit_child_matrilineal_private(
                    self.driver, plan=plan, snapshot=self.snapshot())
            elif selected_step == PRIVATE_CHILD_MATRILINEAL_RESULT_STEP:
                pending = plan.get("child_matrilineal_pending")
                if not isinstance(pending, dict):
                    raise UnsupportedStepError(
                        "controlled child proposal lacks pending identity")
                result = query_child_matrilineal_result_private(
                    self.driver, pending=pending,
                    cold=plan.get("child_matrilineal_cold_recovery") is True)
            elif selected_step == PRIVATE_CHILD_MATRILINEAL_ALLIANCE_STEP:
                resolved = plan.get("child_matrilineal_resolved")
                if not isinstance(resolved, dict):
                    raise UnsupportedStepError(
                        "controlled child alliance lacks resolved pair")
                result = query_child_matrilineal_alliance_private(
                    self.driver, resolved=resolved)
            elif selected_step == PRIVATE_CHILD_DEFAULT_SUBMIT_STEP:
                if not (isinstance(plan.get("child_default_legality"), dict)
                        and isinstance(plan.get("child_default_value"), dict)):
                    raise UnsupportedStepError(
                        "controlled child default proposal lacks valued pair")
                result = submit_child_default_private(
                    self.driver, plan=plan, snapshot=self.snapshot())
            elif selected_step == PRIVATE_CHILD_DEFAULT_RESULT_STEP:
                pending = plan.get("child_default_pending")
                if not isinstance(pending, dict):
                    raise UnsupportedStepError(
                        "controlled child default result lacks pending pair")
                result = query_child_default_result_private(
                    self.driver, pending=pending,
                    cold=plan.get("child_default_cold_recovery") is True,
                    material_recheck=plan.get(
                        "child_default_material_recheck") is True)
            elif selected_step == PRIVATE_CHILD_DEFAULT_ALLIANCE_STEP:
                resolved = plan.get("child_default_resolved")
                if not isinstance(resolved, dict):
                    raise UnsupportedStepError(
                        "controlled child default alliance lacks material pair")
                result = query_child_default_alliance_private(
                    self.driver, resolved=resolved)
            elif selected_step == PRIVATE_PRISONER_RANSOM_SUBMIT_STEP:
                result = submit_ransom_private(self.driver, plan=plan)
            elif selected_step == PRIVATE_PRISONER_RANSOM_RECEIPT_STEP:
                pending = plan.get("prisoner_ransom_pending")
                if not isinstance(pending, dict):
                    raise UnsupportedStepError(
                        "controlled prisoner ransom lacks pending identity")
                result = read_ransom_receipt_private(
                    self.driver, pending=pending)
            elif selected_step == PRIVATE_FACTION_SUBMIT_STEP:
                candidate = plan.get("faction_gift_action")
                checkpoint = plan.get("faction_gift_pre_submit_checkpoint")
                executor = getattr(
                    self.driver, "submit_faction_gift_private_v1", None
                )
                if not (
                    isinstance(candidate, dict)
                    and isinstance(checkpoint, dict)
                    and callable(executor)
                ):
                    raise UnsupportedStepError(
                        "controlled faction gift lacks typed candidate/checkpoint"
                    )
                result = executor(
                    candidate=candidate, checkpoint=checkpoint,
                    expected_revision=int(planned["revision"]),
                )
            elif selected_step in {
                PRIVATE_FACTION_RECEIPT_STEP,
                PRIVATE_FACTION_COLD_RECOVERY_STEP,
            }:
                pending = plan.get("faction_gift_pending_action")
                method = (
                    "query_faction_gift_receipt_private_v1"
                    if selected_step == PRIVATE_FACTION_RECEIPT_STEP
                    else "query_faction_gift_cold_recovery_private_v1"
                )
                executor = getattr(self.driver, method, None)
                if not (isinstance(pending, dict) and callable(executor)):
                    raise UnsupportedStepError(
                        "controlled faction gift verification lacks pending identity"
                    )
                result = executor(
                    pending=pending,
                    expected_revision=int(planned["revision"]),
                )
            else:
                result = self.execute_step(
                    selected_step,
                    expected_revision=int(planned["revision"]),
                )
        except (BridgeUnavailableError, UnsupportedStepError) as error:
            # Preserve the exact planner context for every bridge failure.
            # The concrete exception type remains the sole authority on
            # whether a request was sent; plan attachment only proves which
            # step was selected, allowing a non-save failure to retain the
            # previous durable checkpoint.
            error.selected_step = selected_step
            error.plan = copy.deepcopy(plan)
            if (
                not isinstance(error, BridgeUnavailableError)
                or selected_step != QUERY_CAMPAIGN_ROOT_CONTEXT_V1_STEP
                or getattr(error, "native_error", None)
                not in {
                    "campaign-root snapshot changed or is not ready",
                    "application-main typed query failed or its snapshot changed",
                }
                or not isinstance(root_query_start, dict)
            ):
                raise
            root_query_retry = self._retry_rejected_campaign_root_read(
                root_query_start, planned, error
            )
            if root_query_retry is None:
                raise
            try:
                result = self.execute_step(
                    selected_step,
                    expected_revision=root_query_retry["fresh_snapshot"]["revision"],
                )
            except BridgeUnavailableError as retry_error:
                error.read_only_query_retry = {
                    key: value
                    for key, value in root_query_retry.items()
                    if key not in ("fresh_snapshot", "starting_snapshot")
                }
                error.read_only_query_retry["second_error"] = (
                    f"{type(retry_error).__name__}: {retry_error}"
                )
                raise error from retry_error
        material_expectation = (
            plan.get("event_material_postcondition")
            if isinstance(plan, dict)
            else None
        )
        if isinstance(material_expectation, dict):
            result = {
                **result,
                "event_material_postcondition": (
                    evaluate_registered_event_material_postcondition_v1(
                        material_expectation,
                        result.get("event_selection"),
                    )
                ),
            }
        outcome = {
            "status": "executed",
            "selected_step": selected_step,
            "plan": plan,
            "result": result,
        }
        if root_query_retry is not None:
            outcome["read_only_query_retry"] = root_query_retry
        return outcome

    def _retry_rejected_campaign_root_read(
        self,
        starting: dict[str, object],
        planned: dict[str, object],
        rejection: BridgeUnavailableError,
    ) -> dict[str, object] | None:
        """Retry one rejected *read* only on a new, unchanged paused root."""
        revision = starting.get("revision")
        native_revision = starting.get("native_revision")
        old_history = starting.get("native_command_history")
        old_diagnostics = starting.get("diagnostics")

        def decline(reason, *, fresh=None, failed_checks=None, tail=None, wait_error=None):
            fresh_diagnostics = fresh.get("diagnostics") if isinstance(fresh, dict) else None
            fresh_history = fresh.get("native_command_history") if isinstance(fresh, dict) else None
            evidence = {
                "status": "declined", "reason": reason,
                "failed_checks": failed_checks or [],
                "old_frame": {key: starting.get(key) for key in (
                    "snapshot_id", "revision", "native_revision", "date_raw", "paused", "map_ready",
                )},
                "fresh_frame": ({key: fresh.get(key) for key in (
                    "snapshot_id", "revision", "native_revision", "date_raw", "paused", "map_ready",
                )} if isinstance(fresh, dict) else None),
                "old_connection": ({key: old_diagnostics.get(key) for key in (
                    "bridge_pid", "connection_generation",
                )} if isinstance(old_diagnostics, dict) else None),
                "fresh_connection": ({key: fresh_diagnostics.get(key) for key in (
                    "bridge_pid", "connection_generation",
                )} if isinstance(fresh_diagnostics, dict) else None),
                "old_history_length": len(old_history) if isinstance(old_history, list) else None,
                "fresh_history_length": len(fresh_history) if isinstance(fresh_history, list) else None,
                "history_tail_length": len(tail) if isinstance(tail, list) else None,
                "history_tail": [{key: row.get(key) for key in (
                    "index", "command", "ok", "error",
                )} for row in tail[:3] if isinstance(row, dict)] if isinstance(tail, list) else None,
                "wait_error": wait_error,
            }
            rejection.read_only_query_retry_decline = evidence
            # The existing formal harness retains traceback notes even when
            # it serializes only the original exception text and traceback.
            rejection.add_note("campaign_root_fresh_read_v1 " + json.dumps(evidence, sort_keys=True))

        if not (
            isinstance(revision, int)
            and not isinstance(revision, bool)
            and isinstance(native_revision, int)
            and not isinstance(native_revision, bool)
            and planned.get("revision") == revision
            and isinstance(old_history, list)
            and isinstance(old_diagnostics, dict)
            and starting.get("paused") is True
            and starting.get("map_ready") is True
        ):
            decline("starting_frame_missing_retry_inputs")
            return None
        try:
            fresh = self.driver.wait_for_change(
                revision, timeout_seconds=1.5
            )
        except BridgeUnavailableError as wait_error:
            decline("fresh_snapshot_wait_failed", wait_error=f"{type(wait_error).__name__}: {wait_error}")
            return None
        if not isinstance(fresh, dict):
            decline("fresh_snapshot_not_mapping")
            return None
        played = starting.get("played_character")
        fresh_played = fresh.get("played_character")
        fresh_history = fresh.get("native_command_history")
        fresh_diagnostics = fresh.get("diagnostics")
        tail = (
            fresh_history[len(old_history):]
            if isinstance(fresh_history, list)
            and fresh_history[:len(old_history)] == old_history
            else None
        )
        checks = {
            "fresh_public_revision": isinstance(fresh.get("revision"), int)
            and not isinstance(fresh.get("revision"), bool)
            and fresh["revision"] > revision,
            "fresh_native_revision": isinstance(fresh.get("native_revision"), int)
            and not isinstance(fresh.get("native_revision"), bool)
            and fresh["native_revision"] > native_revision,
            "paused_ready": fresh.get("paused") is True and fresh.get("map_ready") is True,
            "same_date": fresh.get("date_raw") == starting.get("date_raw"),
            "same_episode": fresh.get("episode_run_id") == starting.get("episode_run_id")
            and fresh.get("episode_character_id") == starting.get("episode_character_id"),
            "same_living_actor": isinstance(played, dict)
            and played.get("alive") is True
            and isinstance(fresh_played, dict)
            and fresh_played == played,
            "nonterminal": fresh.get("one_life_terminal") is False
            and fresh.get("one_life_terminal_reason") is None,
            "no_event": starting.get("active_event") is None and fresh.get("active_event") is None,
            "no_interaction": starting.get("pending_character_interaction") is None
            and fresh.get("pending_character_interaction") is None,
            "same_wars": fresh.get("active_wars") == starting.get("active_wars"),
            "same_armies": fresh.get("player_armies") == starting.get("player_armies"),
            "same_connection": isinstance(fresh_diagnostics, dict)
            and all(
                isinstance(old_diagnostics.get(key), int)
                and old_diagnostics.get(key) == fresh_diagnostics.get(key)
                for key in ("bridge_pid", "connection_generation")
            ),
            "single_failed_root_history": isinstance(tail, list)
            and len(tail) == 1
            and isinstance(tail[0], dict)
            and tail[0].get("command") == QUERY_CAMPAIGN_ROOT_CONTEXT_V1_STEP
            and tail[0].get("ok") is False
            and isinstance(tail[0].get("error"), str)
            and str(rejection) in tail[0]["error"],
        }
        if not all(checks.values()):
            decline("fresh_frame_checks_failed", fresh=fresh, tail=tail,
                    failed_checks=[key for key, value in checks.items() if not value])
            return None
        return {
            "rejection": f"{type(rejection).__name__}: {rejection}",
            "old_snapshot_id": starting.get("snapshot_id"),
            "old_revision": revision,
            "old_native_revision": native_revision,
            "fresh_snapshot_id": fresh.get("snapshot_id"),
            "fresh_revision": fresh["revision"],
            "fresh_native_revision": fresh["native_revision"],
            "failed_history_index": tail[0].get("index"),
            "starting_snapshot": starting,
            "fresh_snapshot": fresh,
        }

    def one_life_settlement(self) -> dict[str, object]:
        """Return the terminal settlement state without scheduling heir play."""
        snapshot = self.snapshot()
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        supported = bool(
            isinstance(bridge_capabilities, list)
            and ONE_LIFE_SETTLEMENT_CAPABILITY in bridge_capabilities
        )
        settlement = normalize_one_life_settlement(
            snapshot.get("one_life_settlement")
        )
        episode_character_id = snapshot.get("episode_character_id")
        terminal = snapshot.get("one_life_terminal") is True or isinstance(
            snapshot.get("one_life_terminal_reason"), str
        )
        if not terminal:
            status = "not_terminal"
        elif not supported:
            status = "settlement_unavailable"
        elif settlement_ready_for_episode(settlement, episode_character_id):
            status = "ready"
        elif isinstance(settlement, dict) and settlement.get("ready") is True:
            status = "source_mismatch"
        else:
            status = "pending"
        return {
            "status": status,
            "supported": supported,
            "terminal": terminal,
            "terminal_reason": snapshot.get("one_life_terminal_reason"),
            "episode_character_id": episode_character_id,
            "one_life_settlement": settlement,
            "continue_as_heir_after_death": False,
            "heir_gameplay_actions": 0,
            "snapshot_id": snapshot["snapshot_id"],
            "revision": snapshot["revision"],
            "backend_id": snapshot.get("backend_id"),
        }

    def settle_one_life(
        self, *, expected_revision: int | None = None
    ) -> dict[str, object]:
        """Wait for and record the current episode's bounded terminal handoff."""
        snapshot = self.snapshot()
        if not (
            snapshot.get("one_life_terminal") is True
            or isinstance(snapshot.get("one_life_terminal_reason"), str)
            or (
                isinstance(snapshot.get("played_character"), dict)
                and snapshot["played_character"].get("alive") is False
            )
        ):
            raise BridgeUnavailableError(
                "CK3 has not reached a one-life terminal"
            )
        if "death-terminal" not in action_step_set(self.capabilities()):
            raise UnsupportedStepError(
                "selected backend cannot finalize the one-life terminal"
            )
        result = self.execute_step(
            "death-terminal",
            expected_revision=(
                expected_revision
                if expected_revision is not None
                else int(snapshot["revision"])
            ),
        )
        if (
            result.get("terminal") is not True
            or result.get("continue_as_heir_after_death") is not False
            or result.get("heir_gameplay_actions", 0) != 0
        ):
            raise BridgeUnavailableError(
                "one-life terminal result violates the no-heir contract"
            )
        if result.get("settlement_status") != "settlement_unavailable":
            result = {
                **result,
                "score": normalize_fixed_score(result.get("score"), "score"),
            }
        return result

    def select_event_option(
        self,
        option_number: int,
        *,
        event_instance_id: int | None = None,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Select one authored native option by its public 1-based number."""
        step = event_option_step(option_number)
        if event_instance_id is not None and (
            isinstance(event_instance_id, bool)
            or not isinstance(event_instance_id, int)
            or not 1 <= event_instance_id <= 2**31 - 1
        ):
            raise ValueError("event_instance_id must be a positive full int32")

        snapshot = self.snapshot()
        active_event = normalize_active_event(
            snapshot.get("active_event", snapshot.get("current_event")),
            default_source=str(snapshot.get("source") or "bridge"),
        )
        if active_event is None:
            raise BridgeUnavailableError("CK3 has no active event")
        actual_instance_id = active_event.get("instance_id")
        if event_instance_id is not None:
            if actual_instance_id is None:
                raise BridgeUnavailableError(
                    "the active event backend cannot verify event_instance_id"
                )
            if actual_instance_id != event_instance_id:
                raise BridgeUnavailableError(
                    "active event instance mismatch: "
                    f"expected {event_instance_id}, current {actual_instance_id}"
                )

        option = next(
            (
                row
                for row in active_event["options"]
                if isinstance(row, dict)
                and row.get("option_number") == option_number
            ),
            None,
        )
        if option is None:
            raise BridgeUnavailableError(
                f"active event does not expose option {option_number}"
            )
        if option.get("enabled") is not True:
            raise BridgeUnavailableError(
                f"active event option {option_number} is disabled"
            )
        if step not in action_step_set(self.capabilities()):
            raise UnsupportedStepError(
                f"selected backend does not implement gameplay step {step}"
            )

        selected_revision = (
            expected_revision
            if expected_revision is not None
            else int(snapshot["revision"])
        )
        result = self.execute_step(step, expected_revision=selected_revision)
        return {
            **result,
            "event_instance_id": actual_instance_id,
            "option_number": option_number,
            "option_index": option_number - 1,
        }

    def resolve_active_event(
        self,
        *,
        event_instance_id: int | None = None,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Choose and dispatch the best enabled option on the active event."""
        snapshot = self.snapshot()
        active_event = normalize_active_event(
            snapshot.get("active_event", snapshot.get("current_event")),
            default_source=str(snapshot.get("source") or "bridge"),
        )
        option_number = choose_event_option_number(active_event)
        if option_number is None:
            raise BridgeUnavailableError(
                "CK3 has no active event with an enabled option"
            )
        selected_revision = (
            expected_revision
            if expected_revision is not None
            else int(snapshot["revision"])
        )
        selected_instance_id = (
            event_instance_id
            if event_instance_id is not None
            else active_event.get("instance_id")
        )
        result = self.select_event_option(
            option_number,
            event_instance_id=(
                selected_instance_id
                if isinstance(selected_instance_id, int)
                else None
            ),
            expected_revision=selected_revision,
        )
        selected_option = next(
            (
                option
                for option in active_event["options"]
                if isinstance(option, dict)
                and option.get("option_number") == option_number
            ),
            {},
        )
        return {
            **result,
            "ordinary_events": [
                {
                    "event_index": 1,
                    "event_instance_id": active_event.get("instance_id"),
                    "title": active_event.get("title"),
                    "visible_options": active_event.get("options", []),
                    "selected_option_number": option_number,
                    "selected_option_index": option_number - 1,
                    "selected_visible_text": selected_option.get("label"),
                    "strategy": "backend-neutral-event-v1",
                    "source": active_event.get("source"),
                }
            ],
        }

    def execute_step(
        self, step: str, *, expected_revision: int | None = None,
        expected_h2743_frame: dict[str, object] | None = None,
    ) -> dict[str, object]:
        if step == CENTER_MAP_ON_LANDED_TITLE_V1_STEP:
            raise UnsupportedStepError(
                "title-map navigation requires its typed MCP facade"
            )
        if step in {"navigate-ingame-ui-v1", "query-ingame-ui-window-v1"}:
            raise UnsupportedStepError("ingame UI requires its explicit typed MCP facade")
        from .h2743_preaction_existing_truce_v1 import QUERY_STEP
        if step == QUERY_STEP or expected_h2743_frame is not None:
            if (step != QUERY_STEP or type(expected_revision) is not int
                    or expected_h2743_frame is None):
                raise BridgeUnavailableError(
                    "H2743 read-only query requires an explicit before-frame claim"
                )
            reader = getattr(self.driver, "query_h2743_preaction_existing_truce_v1", None)
            if not callable(reader):
                raise BridgeUnavailableError("H2743 native read-only reader unavailable")
            return reader(expected_h2743_frame, expected_revision=expected_revision)
        return self.driver.execute_step(step, expected_revision=expected_revision)

    def save_checkpoint(
        self, *, expected_revision: int | None = None
    ) -> dict[str, object]:
        """Execute the shared checkpoint step and return its materialization."""
        if "save-checkpoint" not in action_step_set(self.capabilities()):
            raise UnsupportedStepError(
                "selected backend does not implement gameplay step save-checkpoint"
            )
        result = self.execute_step(
            "save-checkpoint", expected_revision=expected_revision
        )
        if not isinstance(result.get("checkpoint"), dict):
            raise BridgeUnavailableError(
                "save-checkpoint result lacks checkpoint materialization"
            )
        return result

    def restore_checkpoint(
        self, *, expected_revision: int | None = None
    ) -> dict[str, object]:
        """Restart the managed pure-native session at its latest checkpoint."""
        if "restore-checkpoint" not in action_step_set(self.capabilities()):
            raise UnsupportedStepError(
                "selected backend does not implement gameplay step "
                "restore-checkpoint"
            )
        result = self.execute_step(
            "restore-checkpoint", expected_revision=expected_revision
        )
        if (
            not isinstance(result.get("checkpoint"), dict)
            or not isinstance(result.get("restored_date"), dict)
        ):
            raise BridgeUnavailableError(
                "restore-checkpoint result lacks checkpoint or restored date"
            )
        return result

    def restore_phase2_span_source_checkpoint_v1(
        self,
        *,
        checkpoint_path: str,
        expected_checkpoint_bytes: int,
        expected_checkpoint_sha256: str,
        expected_save_lineage_id: str,
        expected_event_definition_key: str,
        expected_owner_character_id: int,
        expected_player_character_id: int,
        expected_date_raw: int,
        allow_generic_character_rebind: bool,
        allow_fixture: bool,
        allow_console: bool,
    ) -> dict[str, object]:
        """Restore one canonical Phase2 source through the managed lifecycle."""

        if not (
            allow_generic_character_rebind is False
            and allow_fixture is False
            and allow_console is False
        ):
            raise BridgeUnavailableError(
                "Phase2 source restore forbids generic rebind, fixture, and console"
            )
        restore = getattr(
            self.driver, "restore_phase2_span_source_checkpoint_v1", None
        )
        if not callable(restore):
            raise UnsupportedStepError(
                "selected backend does not implement the canonical Phase2 "
                "source-checkpoint restore"
            )
        result = restore(
            checkpoint_path=checkpoint_path,
            expected_checkpoint_bytes=expected_checkpoint_bytes,
            expected_checkpoint_sha256=expected_checkpoint_sha256,
            expected_save_lineage_id=expected_save_lineage_id,
            expected_event_definition_key=expected_event_definition_key,
            expected_owner_character_id=expected_owner_character_id,
            expected_player_character_id=expected_player_character_id,
            expected_date_raw=expected_date_raw,
            allow_generic_character_rebind=False,
            allow_fixture=False,
            allow_console=False,
        )
        expected_sha256 = (
            expected_checkpoint_sha256.upper()
            if isinstance(expected_checkpoint_sha256, str)
            else None
        )
        lifecycle = result.get("lifecycle") if isinstance(result, dict) else None
        if not (
            isinstance(result, dict)
            and result.get("result") == "GREEN"
            and result.get("provider_observed") is True
            and result.get("restore_materialized") is True
            and result.get("checkpoint_sha256") == expected_sha256
            and result.get("checkpoint_bytes") == expected_checkpoint_bytes
            and result.get("save_lineage_id") == expected_save_lineage_id
            and result.get("event_definition_key")
            == expected_event_definition_key
            and result.get("owner_character_id")
            == expected_owner_character_id
            and result.get("player_character_id")
            == expected_player_character_id
            and result.get("date_raw") == expected_date_raw
            and result.get("fixture_used") is False
            and result.get("console_used") is False
            and result.get("generic_character_rebind_used") is False
            and isinstance(lifecycle, dict)
            and lifecycle.get("lifecycle_intent") == "restore"
            and isinstance(lifecycle.get("previous_pid"), int)
            and not isinstance(lifecycle.get("previous_pid"), bool)
            and lifecycle.get("previous_pid") > 0
            and isinstance(lifecycle.get("pid"), int)
            and not isinstance(lifecycle.get("pid"), bool)
            and lifecycle.get("pid") > 0
            and lifecycle.get("pid") != lifecycle.get("previous_pid")
            and isinstance(
                lifecycle.get("previous_connection_generation"), int
            )
            and not isinstance(
                lifecycle.get("previous_connection_generation"), bool
            )
            and lifecycle.get("previous_connection_generation") > 0
            and isinstance(lifecycle.get("connection_generation"), int)
            and not isinstance(lifecycle.get("connection_generation"), bool)
            and lifecycle.get("connection_generation") > 0
        ):
            raise BridgeUnavailableError(
                "canonical Phase2 source restore returned an incomplete typed ACK"
            )
        return result

    def phase2_span_source_checkpoint_restore_available_v1(self) -> bool:
        """Report whether this concrete backend owns the narrow restore."""

        return callable(
            getattr(
                self.driver,
                "restore_phase2_span_source_checkpoint_v1",
                None,
            )
        )

    def restore_hc_workforce_route_b_checkpoint_v1(
        self,
        *,
        checkpoint_path: str,
        expected_checkpoint_bytes: int,
        expected_checkpoint_sha256: str,
        expected_save_lineage_id: str,
        expected_event_definition_key: str,
        expected_owner_character_id: int,
        expected_player_character_id: int,
        expected_date_raw: int,
    ) -> dict[str, object]:
        """Restore one sealed M360 Route-B source with its transition fixture."""

        if (
            expected_event_definition_key != "zg361we.360"
            or expected_owner_character_id != expected_player_character_id
        ):
            raise BridgeUnavailableError(
                "HC-workforce Route-B restore identity is invalid"
            )
        restore = getattr(
            self.driver, "restore_hc_workforce_route_b_checkpoint_v1", None
        )
        if not callable(restore):
            raise UnsupportedStepError(
                "selected backend does not implement the HC-workforce "
                "Route-B checkpoint restore"
            )
        result = restore(
            checkpoint_path=checkpoint_path,
            expected_checkpoint_bytes=expected_checkpoint_bytes,
            expected_checkpoint_sha256=expected_checkpoint_sha256,
            expected_save_lineage_id=expected_save_lineage_id,
            expected_event_definition_key=expected_event_definition_key,
            expected_owner_character_id=expected_owner_character_id,
            expected_player_character_id=expected_player_character_id,
            expected_date_raw=expected_date_raw,
        )
        expected_sha256 = (
            expected_checkpoint_sha256.upper()
            if isinstance(expected_checkpoint_sha256, str)
            else None
        )
        lifecycle = result.get("lifecycle") if isinstance(result, dict) else None
        if not (
            isinstance(result, dict)
            and result.get("result") == "GREEN"
            and result.get("provider_observed") is True
            and result.get("restore_materialized") is True
            and result.get("checkpoint_sha256") == expected_sha256
            and result.get("checkpoint_bytes") == expected_checkpoint_bytes
            and result.get("save_lineage_id") == expected_save_lineage_id
            and result.get("event_definition_key") == "zg361we.360"
            and result.get("owner_character_id")
            == expected_owner_character_id
            and result.get("player_character_id")
            == expected_player_character_id
            and result.get("date_raw") == expected_date_raw
            and result.get("fixture_used") is True
            and result.get("console_used") is False
            and result.get("generic_character_rebind_used") is False
            and isinstance(lifecycle, dict)
            and lifecycle.get("lifecycle_intent") == "restore"
            and isinstance(lifecycle.get("previous_pid"), int)
            and not isinstance(lifecycle.get("previous_pid"), bool)
            and lifecycle.get("previous_pid") > 0
            and isinstance(lifecycle.get("pid"), int)
            and not isinstance(lifecycle.get("pid"), bool)
            and lifecycle.get("pid") > 0
            and lifecycle.get("pid") != lifecycle.get("previous_pid")
            and isinstance(
                lifecycle.get("previous_connection_generation"), int
            )
            and not isinstance(
                lifecycle.get("previous_connection_generation"), bool
            )
            and lifecycle.get("previous_connection_generation") > 0
            and isinstance(lifecycle.get("connection_generation"), int)
            and not isinstance(lifecycle.get("connection_generation"), bool)
            and lifecycle.get("connection_generation") > 0
        ):
            raise BridgeUnavailableError(
                "HC-workforce Route-B restore returned an incomplete typed ACK"
            )
        return result

    def hc_workforce_route_b_checkpoint_restore_available_v1(self) -> bool:
        """Report whether the managed backend owns the fixture-bound restore."""

        return callable(
            getattr(
                self.driver,
                "restore_hc_workforce_route_b_checkpoint_v1",
                None,
            )
        )

    def start_next_episode(
        self, *, expected_revision: int | None = None
    ) -> dict[str, object]:
        """Start a fresh one-life run from the immutable native seed."""
        if "start-next-episode" not in action_step_set(self.capabilities()):
            raise UnsupportedStepError(
                "selected backend cannot start the next pure-native episode"
            )
        result = self.execute_step(
            "start-next-episode", expected_revision=expected_revision
        )
        if (
            result.get("status") != "started"
            or result.get("lifecycle_intent") != "new_episode"
            or not isinstance(result.get("episode_run_id"), str)
            or not isinstance(result.get("cross_run_plan_used"), dict)
        ):
            raise BridgeUnavailableError(
                "start-next-episode result lacks new-run lifecycle data"
            )
        return result

    def reply_pending_character_interaction(
        self,
        *,
        accept: bool,
        interaction_instance_id: int | None = None,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Accept or reject the exact pending native character interaction."""
        if not isinstance(accept, bool):
            raise ValueError("accept must be a boolean")
        if interaction_instance_id is not None:
            interaction_instance_id = normalize_pending_interaction_id(
                interaction_instance_id, "interaction_instance_id"
            )
        snapshot = self.snapshot()
        pending = snapshot.get("pending_character_interaction")
        if not isinstance(pending, dict):
            raise BridgeUnavailableError(
                "CK3 has no pending character interaction"
            )
        actual_instance_id = pending.get("instance_id")
        if (
            interaction_instance_id is not None
            and actual_instance_id != interaction_instance_id
        ):
            raise BridgeUnavailableError(
                "pending character interaction instance mismatch: "
                f"expected {interaction_instance_id}, current {actual_instance_id}"
            )
        step = (
            "accept-pending-character-interaction"
            if accept
            else "reject-pending-character-interaction"
        )
        if step not in action_step_set(self.capabilities()):
            raise UnsupportedStepError(
                f"selected backend does not implement gameplay step {step}"
            )
        result = self.execute_step(
            step,
            expected_revision=(
                expected_revision
                if expected_revision is not None
                else int(snapshot["revision"])
            ),
        )
        return {
            **result,
            "interaction_instance_id": actual_instance_id,
            "sender_character_id": pending.get("sender_character_id"),
            "accepted": accept,
        }

    def acknowledge_pending_character_interaction(
        self,
        *,
        interaction_instance_id: int,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Acknowledge one exact generation-bearing auto-accept notification."""
        interaction_instance_id = normalize_pending_interaction_id(
            interaction_instance_id, "interaction_instance_id"
        )
        snapshot = self.snapshot()
        pending = snapshot.get("pending_character_interaction")
        if not isinstance(pending, dict):
            raise BridgeUnavailableError(
                "CK3 has no pending character interaction"
            )
        actual_instance_id = pending.get("instance_id")
        if actual_instance_id != interaction_instance_id:
            raise BridgeUnavailableError(
                "pending character interaction instance mismatch: "
                f"expected {interaction_instance_id}, current "
                f"{actual_instance_id}"
            )
        if pending.get("auto_accept_notification") is not True:
            raise BridgeUnavailableError(
                "pending character interaction is not an ACK notification"
            )
        if (
            ACKNOWLEDGE_PENDING_CHARACTER_INTERACTION_STEP
            not in action_step_set(self.capabilities())
        ):
            raise UnsupportedStepError(
                "selected backend does not implement gameplay step "
                f"{ACKNOWLEDGE_PENDING_CHARACTER_INTERACTION_STEP}"
            )
        result = self.execute_step(
            ACKNOWLEDGE_PENDING_CHARACTER_INTERACTION_STEP,
            expected_revision=(
                expected_revision
                if expected_revision is not None
                else int(snapshot["revision"])
            ),
        )
        interaction_result = result.get("interaction_result")
        if (
            not isinstance(interaction_result, dict)
            or interaction_result.get("status") != "acknowledged"
            or interaction_result.get("instance_id")
            != interaction_instance_id
        ):
            raise BridgeUnavailableError(
                "native ACK did not prove pending interaction advancement"
            )
        return {
            **result,
            "interaction_instance_id": interaction_instance_id,
            "sender_character_id": pending.get("sender_character_id"),
            "acknowledged": True,
        }

    def war_state(self) -> dict[str, object]:
        """Return the canonical native war/army slice without visual reads."""
        snapshot = self.snapshot()
        active_wars = normalize_active_wars(snapshot.get("active_wars"))
        player_armies = player_armies_from_state(
            active_wars, snapshot.get("player_armies")
        )
        return {
            "status": (
                "active"
                if active_wars
                else "postwar_armies"
                if player_armies
                else "idle"
            ),
            "active_wars": active_wars,
            "player_armies": player_armies,
            "war_termination_options": (
                snapshot.get("war_termination_options")
                if isinstance(snapshot.get("war_termination_options"), list)
                else []
            ),
            "war_termination_terms": (
                snapshot.get("war_termination_terms")
                if isinstance(snapshot.get("war_termination_terms"), list)
                else []
            ),
            "war_termination_exit_terms": (
                snapshot.get("war_termination_exit_terms")
                if isinstance(
                    snapshot.get("war_termination_exit_terms"), list
                )
                else []
            ),
            "army_strengths": (
                snapshot.get("army_strengths")
                if isinstance(snapshot.get("army_strengths"), list)
                else []
            ),
            "army_strengths_status": snapshot.get("army_strengths_status"),
            "army_strengths_query_sequence": snapshot.get(
                "army_strengths_query_sequence"
            ),
            "snapshot_id": snapshot["snapshot_id"],
            "revision": snapshot["revision"],
            "backend_id": snapshot.get("backend_id"),
        }

    def query_arrange_marriage_choices(
        self, *, expected_revision: int | None = None
    ) -> dict[str, object]:
        """Enumerate exact native marriage choices for the played character."""
        if QUERY_ARRANGE_MARRIAGE_CHOICES_STEP not in action_step_set(
            self.capabilities()
        ):
            raise UnsupportedStepError(
                "selected backend cannot query native marriage choices"
            )
        snapshot = self.snapshot()
        result = self.execute_step(
            QUERY_ARRANGE_MARRIAGE_CHOICES_STEP,
            expected_revision=(
                expected_revision
                if expected_revision is not None
                else int(snapshot["revision"])
            ),
        )
        if not isinstance(result.get("arrange_marriage_choices"), list):
            raise BridgeUnavailableError(
                "native marriage query lacks arrange_marriage_choices"
            )
        return result

    def query_observed_first_heir_marriage_legality_v1(
        self, *, expected_native_revision: int,
    ) -> dict[str, object]:
        """Candidate read-only API; not registered as MCP/capability yet."""
        route = getattr(
            self.driver, "query_observed_first_heir_marriage_legality_v1", None
        )
        if not callable(route):
            raise UnsupportedStepError(
                "selected backend lacks observed-first-heir legality query"
            )
        return route(expected_native_revision=expected_native_revision)

    def arrange_marriage(
        self,
        choice_id: str,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Submit one exact choice returned by the latest marriage query."""
        step = arrange_marriage_step(choice_id)
        snapshot = self.snapshot()
        if step not in action_step_set(self.capabilities()):
            raise UnsupportedStepError(
                f"selected backend cannot execute native marriage {choice_id}"
            )
        return self.execute_step(
            step,
            expected_revision=(
                expected_revision
                if expected_revision is not None
                else int(snapshot["revision"])
            ),
        )

    def query_declarable_wars(
        self, *, expected_revision: int | None = None
    ) -> dict[str, object]:
        """Run CK3's native declaration evaluator on demand."""
        if QUERY_DECLARABLE_WARS_STEP not in action_step_set(self.capabilities()):
            raise UnsupportedStepError(
                "selected backend cannot query native war declarations"
            )
        snapshot = self.snapshot()
        result = self.execute_step(
            QUERY_DECLARABLE_WARS_STEP,
            expected_revision=(
                expected_revision
                if expected_revision is not None
                else int(snapshot["revision"])
            ),
        )
        if not isinstance(result.get("declarable_wars"), list):
            raise BridgeUnavailableError(
                "native declaration query lacks declarable_wars"
            )
        return result

    def collect_declarable_wars_result_v1(
        self, request_id: str, *, expected_revision: int
    ) -> dict[str, object]:
        """Collect the same driver's pending response without a native query."""
        collect = getattr(self.driver, "collect_declarable_wars_result_v1", None)
        if not callable(collect):
            raise UnsupportedStepError(
                "selected backend cannot collect pending declarable-war results"
            )
        return collect(request_id, expected_revision=expected_revision)

    def declare_war(
        self,
        declaration_id: str,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Submit one exact choice returned by the latest native query."""
        step = declare_war_step(declaration_id)
        snapshot = self.snapshot()
        if step not in action_step_set(self.capabilities()):
            raise UnsupportedStepError(
                f"selected backend cannot execute native declaration {declaration_id}"
            )
        return self.execute_step(
            step,
            expected_revision=(
                expected_revision
                if expected_revision is not None
                else int(snapshot["revision"])
            ),
        )

    def raise_troops_default(
        self, *, expected_revision: int | None = None
    ) -> dict[str, object]:
        """Raise troops for the current war at CK3's native default point."""
        return self._execute_typed_war_step(
            RAISE_TROOPS_STEP, expected_revision=expected_revision
        )

    def move_army(
        self,
        army_id: int,
        target_province_id: int,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Move one exact native army to one exact CK3 province."""
        step = move_army_step(army_id, target_province_id)
        typed_move = getattr(self.driver, "move_army", None)
        result = (
            typed_move(army_id, target_province_id, expected_revision=expected_revision)
            if callable(typed_move)
            else self._execute_typed_war_step(step, expected_revision=expected_revision)
        )
        return {
            **result,
            "army_id": army_id,
            "target_province_id": target_province_id,
        }

    def start_assault(
        self,
        siege_id: int,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Start Assault on one exact full-generation native SiegeID."""
        step = start_assault_step(siege_id)
        return {
            **self._execute_typed_war_step(
                step, expected_revision=expected_revision
            ),
            "siege_id": siege_id,
        }

    def stop_assault(
        self,
        siege_id: int,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Stop Assault on one exact full-generation native SiegeID."""
        step = stop_assault_step(siege_id)
        return {
            **self._execute_typed_war_step(
                step, expected_revision=expected_revision
            ),
            "siege_id": siege_id,
        }

    def disband_army(
        self,
        army_id: int,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Disband one exact native player army."""
        step = disband_army_step(army_id)
        return {
            **self._execute_typed_war_step(
                step, expected_revision=expected_revision
            ),
            "army_id": army_id,
        }

    def enforce_demands(
        self,
        war_id: int,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Enforce victory in one exact native war at 100% war score."""
        step = enforce_demands_step(war_id)
        return {
            **self._execute_typed_war_step(
                step, expected_revision=expected_revision
            ),
            "war_id": war_id,
        }

    def query_title_holder_v1(
        self, title_id: int, *, expected_revision: int,
    ) -> dict[str, object]:
        """Read one current native holder without restricting the title to this player."""
        step = query_title_holder_v1_step(title_id)
        if type(expected_revision) is not int or expected_revision < 0:
            raise ValueError("expected_revision must be a non-negative integer")
        snapshot = self.snapshot()
        try:
            actor_id = title_holder_query_actor(snapshot)
        except ValueError as error:
            raise BridgeUnavailableError(str(error)) from error
        revision = snapshot.get("revision")
        if type(revision) is not int or revision < 0:
            raise BridgeUnavailableError("title holder query lacks a public revision")
        if expected_revision != revision:
            raise PreSubmissionRevisionMismatchError(
                f"title holder revision mismatch: expected {expected_revision}, current {revision}"
            )
        capabilities = self.capabilities().get("bridge_capabilities")
        if not isinstance(capabilities, list) or QUERY_TITLE_HOLDER_V1_CAPABILITY not in capabilities:
            raise UnsupportedStepError("selected backend cannot query a native title holder")
        result = self.execute_step(step, expected_revision=revision)
        if (
            not isinstance(result, dict)
            or result.get("step") != step
            or result.get("accepted") is not True
            or result.get("status") not in {"available", "unavailable"}
            or type(result.get("query_sequence")) is not int
            or not 1 <= result["query_sequence"] <= 2**64 - 1
        ):
            raise BridgeUnavailableError("title holder query returned a malformed envelope")
        try:
            value = normalize_title_holder_v1(
                result.get("title_holder"),
                expected_title_id=title_id,
                expected_actor_character_id=actor_id,
                expected_snapshot_revision=snapshot.get("native_revision"),
                expected_date_raw=snapshot.get("date_raw"),
            )
        except ValueError as error:
            raise BridgeUnavailableError(f"native title holder query is malformed: {error}") from error
        if (result["status"] == "available") != value["available"]:
            raise BridgeUnavailableError("title holder query status disagrees with availability")
        return {
            **result,
            "title_id": title_id,
            "title_holder": value,
            "read_only": True,
            "queried_snapshot_id": snapshot.get("snapshot_id"),
            "queried_revision": revision,
            "queried_native_revision": snapshot.get("native_revision"),
        }

    def query_war_occupation_targets_v1(
        self, war_id: int, *, expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Read actual native eligible holdings and occupation sides for a war."""
        step = query_war_occupation_targets_v1_step(war_id)
        snapshot = self.snapshot()
        try:
            actor_id, player_side = war_occupation_query_scope(snapshot, war_id)
        except ValueError as error:
            raise BridgeUnavailableError(str(error)) from error
        revision = snapshot.get("revision")
        if type(revision) is not int or revision < 0:
            raise BridgeUnavailableError("occupation targets lack a public revision")
        if expected_revision is not None:
            if type(expected_revision) is not int or expected_revision < 0:
                raise ValueError("expected_revision must be a non-negative integer")
            if expected_revision != revision:
                raise PreSubmissionRevisionMismatchError(
                    f"occupation revision mismatch: expected {expected_revision}, current {revision}"
                )
        capabilities = self.capabilities().get("bridge_capabilities")
        if not isinstance(capabilities, list) or QUERY_WAR_OCCUPATION_TARGETS_V1_CAPABILITY not in capabilities:
            raise UnsupportedStepError("selected backend cannot query native war occupation targets")
        result = self.execute_step(step, expected_revision=revision)
        if (
            not isinstance(result, dict)
            or result.get("step") != step
            or result.get("accepted") is not True
            or result.get("status") not in {"available", "unavailable"}
            or type(result.get("query_sequence")) is not int
            or not 1 <= result["query_sequence"] <= 2**64 - 1
        ):
            raise BridgeUnavailableError("occupation targets returned a malformed query envelope")
        try:
            value = normalize_war_occupation_targets_v1(
                result.get("war_occupation_targets_v1"),
                expected_war_id=war_id,
                expected_actor_character_id=actor_id,
                expected_snapshot_revision=snapshot.get("native_revision"),
                expected_date_raw=snapshot.get("date_raw"),
                expected_player_side=player_side,
            )
        except ValueError as error:
            raise BridgeUnavailableError(f"native occupation targets are malformed: {error}") from error
        if (result["status"] == "available") != value["available"]:
            raise BridgeUnavailableError("occupation query status disagrees with collection availability")
        return {
            **result,
            "war_id": war_id,
            "war_occupation_targets_v1": value,
            "read_only": True,
            "queried_snapshot_id": snapshot.get("snapshot_id"),
            "queried_revision": revision,
            "queried_native_revision": snapshot.get("native_revision"),
        }

    def query_war_termination_options(
        self,
        war_id: int,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Read CK3's exact termination contexts for one active WarID."""
        step = query_war_termination_options_step(war_id)
        result = self._execute_typed_war_step(
            step, expected_revision=expected_revision
        )
        options = result.get("war_termination_options")
        if not isinstance(options, dict) or options.get("war_id") != war_id:
            raise BridgeUnavailableError(
                "native termination query lacks matching war_termination_options"
            )
        return {**result, "war_id": war_id}

    def query_outbound_war_white_peace_status(
        self,
        war_id: int,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Read whether this player's white-peace proposal is still pending."""
        step = query_outbound_war_white_peace_status_step(war_id)
        result = self._execute_typed_war_step(
            step, expected_revision=expected_revision
        )
        status = result.get("outbound_war_white_peace_status")
        if not isinstance(status, dict) or status.get("war_id") != war_id:
            raise BridgeUnavailableError(
                "native outbound white-peace query lacks matching status"
            )
        return {**result, "war_id": war_id}

    def query_war_termination_terms(
        self,
        war_id: int,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Read the complete claim-CB disposition slice for one WarID."""
        step = query_war_termination_terms_step(war_id)
        result = self._execute_typed_war_step(
            step, expected_revision=expected_revision
        )
        terms = result.get("war_termination_terms")
        if not isinstance(terms, dict) or terms.get("war_id") != war_id:
            raise BridgeUnavailableError(
                "native terms query lacks matching war_termination_terms"
            )
        return {**result, "war_id": war_id}

    def query_war_termination_exit_terms(
        self,
        war_id: int,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Read the complete dry-preview claim-CB exit slice for one WarID."""
        if not WAR_TERMINATION_EXIT_TERMS_PRODUCTION_ENABLED:
            raise BridgeUnavailableError(
                "war-termination exit-terms v2 is disabled after a "
                "reproducible native loaded-effect preview crash"
            )
        step = query_war_termination_exit_terms_step(war_id)
        result = self._execute_typed_war_step(
            step, expected_revision=expected_revision
        )
        terms = result.get("war_termination_exit_terms")
        if not isinstance(terms, dict) or terms.get("war_id") != war_id:
            raise BridgeUnavailableError(
                "native exit-terms query lacks matching "
                "war_termination_exit_terms"
            )
        return {**result, "war_id": war_id}

    def query_player_default_raise_v1(
        self, *, expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Read native default raise legality for the current living player."""
        from .player_default_raise import (
            CAPABILITY, STEP, normalize_player_default_raise_v1,
            player_default_raise_frame_binding,
        )
        snapshot = self.snapshot()
        player = snapshot.get("played_character")
        if (snapshot.get("paused") is not True or snapshot.get("map_ready") is not True
                or not isinstance(player, dict) or player.get("alive") is not True):
            raise BridgeUnavailableError("default raise query requires a living paused player")
        revision = snapshot.get("revision")
        if type(revision) is not int or revision < 0:
            raise BridgeUnavailableError("default raise query lacks public revision")
        if expected_revision is not None:
            if type(expected_revision) is not int or expected_revision < 0:
                raise ValueError("expected_revision must be a non-negative integer")
            if expected_revision != revision:
                raise PreSubmissionRevisionMismatchError("default raise query revision is stale")
        capabilities = self.capabilities().get("bridge_capabilities")
        if not isinstance(capabilities, list) or CAPABILITY not in capabilities:
            raise UnsupportedStepError("selected backend cannot query native default raise legality")
        result = self.execute_step(STEP, expected_revision=revision)
        if (not isinstance(result, dict) or result.get("step") != STEP
                or result.get("accepted") is not True or result.get("status") != "completed"
                or result.get("read_only") is not True or type(result.get("query_sequence")) is not int
                or result["query_sequence"] <= 0
                or result.get("snapshot_revision") != snapshot.get("native_revision")
                or result.get("date_raw") != snapshot.get("date_raw")):
            raise BridgeUnavailableError("native default raise returned malformed envelope")
        try:
            normalized = normalize_player_default_raise_v1(result.get("player_default_raise"), snapshot=snapshot)
        except ValueError as error:
            raise BridgeUnavailableError(str(error)) from error
        if player_default_raise_frame_binding(self.snapshot()) != player_default_raise_frame_binding(snapshot):
            raise BridgeUnavailableError("default raise query crossed its paused frame or episode")
        return {**result, "player_default_raise": normalized,
                "queried_snapshot_id": snapshot.get("snapshot_id"),
                "queried_revision": revision,
                "queried_native_revision": snapshot.get("native_revision")}

    def hire_mercenary_v1(
        self, *, company_id: int, expected_revision: int,
    ) -> dict[str, object]:
        """Submit a normal native hire; observe employer, armies and payment separately."""
        from .hire_mercenary import validate_hire_mercenary_request_v1
        validate_hire_mercenary_request_v1(company_id, expected_revision)
        callback = getattr(self.driver, "hire_mercenary_v1", None)
        if not callable(callback):
            raise UnsupportedStepError("selected backend cannot submit native mercenary hire")
        return callback(company_id=company_id, expected_revision=expected_revision)

    def query_player_mercenary_context_v1(
        self, *, expected_revision: int,
    ) -> dict[str, object]:
        """Read native mercenary candidates, hire terms and arrival location for the current player."""
        from .player_mercenary_context import (
            CAPABILITY, STEP, normalize_player_mercenary_context_v1,
            player_mercenary_context_frame_binding,
        )
        snapshot = self.snapshot()
        player = snapshot.get("played_character")
        if (snapshot.get("paused") is not True or snapshot.get("map_ready") is not True
                or not isinstance(player, dict) or player.get("alive") is not True):
            raise BridgeUnavailableError("mercenary context query requires a living paused player")
        revision = snapshot.get("revision")
        if type(revision) is not int or revision < 0:
            raise BridgeUnavailableError("mercenary context query lacks public revision")
        if expected_revision is not None:
            if type(expected_revision) is not int or expected_revision < 0:
                raise ValueError("expected_revision must be a non-negative integer")
            if expected_revision != revision:
                raise PreSubmissionRevisionMismatchError("mercenary context query revision is stale")
        capabilities = self.capabilities().get("bridge_capabilities")
        if not isinstance(capabilities, list) or CAPABILITY not in capabilities:
            raise UnsupportedStepError("selected backend cannot query native mercenary context legality")
        result = self.execute_step(STEP, expected_revision=revision)
        if (not isinstance(result, dict) or result.get("step") != STEP
                or result.get("accepted") is not True or result.get("status") != "completed"
                or result.get("read_only") is not True or type(result.get("query_sequence")) is not int
                or result["query_sequence"] <= 0
                or result.get("snapshot_revision") != snapshot.get("native_revision")
                or result.get("date_raw") != snapshot.get("date_raw")):
            raise BridgeUnavailableError("native mercenary context returned malformed envelope")
        try:
            normalized = normalize_player_mercenary_context_v1(result.get("player_mercenary_context"), snapshot=snapshot)
        except ValueError as error:
            raise BridgeUnavailableError(str(error)) from error
        if player_mercenary_context_frame_binding(self.snapshot()) != player_mercenary_context_frame_binding(snapshot):
            raise BridgeUnavailableError("mercenary context query crossed its paused frame or episode")
        return {**result, "player_mercenary_context": normalized,
                "queried_snapshot_id": snapshot.get("snapshot_id"),
                "queried_revision": revision,
                "queried_native_revision": snapshot.get("native_revision")}

    def query_army_commander_candidates_v1(
        self,
        army_id: int,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Read the current player army's native manual commander candidates."""
        step = query_army_commander_candidates_v1_step(army_id)
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError("commander queries require a paused CK3 snapshot")
        try:
            commander_query_army_scope(snapshot, army_id)
        except ValueError as error:
            raise BridgeUnavailableError(str(error)) from error
        revision = snapshot.get("revision")
        if type(revision) is not int or revision < 0:
            raise BridgeUnavailableError("commander query lacks a valid public revision")
        if expected_revision is not None:
            if type(expected_revision) is not int or expected_revision < 0:
                raise ValueError("expected_revision must be a non-negative integer")
            if expected_revision != revision:
                raise PreSubmissionRevisionMismatchError(
                    f"commander revision mismatch: expected {expected_revision}, current {revision}"
                )
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        if type(native_revision) is not int or native_revision <= 0 or type(date_raw) is not int:
            raise BridgeUnavailableError("commander query lacks native revision/date")
        capabilities = self.capabilities().get("bridge_capabilities")
        if not isinstance(capabilities, list) or QUERY_ARMY_COMMANDER_CANDIDATES_V1_CAPABILITY not in capabilities:
            raise UnsupportedStepError("selected backend cannot query native commander candidates")
        result = self.execute_step(step, expected_revision=revision)
        if (
            not isinstance(result, dict)
            or result.get("step") != step
            or result.get("accepted") is not True
            or result.get("status") != "completed"
            or result.get("read_only") is not True
            or type(result.get("query_sequence")) is not int
            or result.get("query_sequence") <= 0
            or result.get("snapshot_revision") != native_revision
            or result.get("date_raw") != date_raw
        ):
            raise BridgeUnavailableError("native commander query returned a malformed envelope")
        try:
            normalized = normalize_army_commander_candidates_v1(
                result.get("army_commander_candidates"),
                expected_army_id=army_id,
                expected_snapshot_revision=native_revision,
                expected_date_raw=date_raw,
            )
        except ValueError as error:
            raise BridgeUnavailableError(f"native commander result is malformed: {error}") from error
        current = self.snapshot()
        if current.get("paused") is not True or any(
            current.get(key) != snapshot.get(key)
            for key in ("snapshot_id", "revision", "native_revision", "date_raw")
        ):
            raise BridgeUnavailableError("commander query crossed a paused frame")
        return {
            **result,
            "army_commander_candidates": normalized,
            "queried_snapshot_id": snapshot.get("snapshot_id"),
            "queried_revision": revision,
            "queried_native_revision": native_revision,
        }

    def assign_army_commander_v1(
        self,
        army_id: int,
        commander_character_id: int,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Submit one native assignment, then query the actual commander independently."""
        step = assign_army_commander_v1_step(army_id, commander_character_id)
        if type(expected_revision) is not int or expected_revision < 0:
            raise ValueError("expected_revision must be a non-negative integer")
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError("commander assignment requires a paused CK3 snapshot")
        if snapshot.get("revision") != expected_revision:
            raise PreSubmissionRevisionMismatchError("commander assignment source revision is stale")
        try:
            commander_query_army_scope(snapshot, army_id)
        except ValueError as error:
            raise BridgeUnavailableError(str(error)) from error
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        if type(native_revision) is not int or native_revision <= 0 or type(date_raw) is not int:
            raise BridgeUnavailableError("commander assignment lacks native revision/date")
        capabilities = self.capabilities().get("bridge_capabilities")
        if not isinstance(capabilities, list) or ASSIGN_ARMY_COMMANDER_V1_CAPABILITY not in capabilities:
            raise UnsupportedStepError("selected backend cannot assign a native army commander")
        result = self.execute_step(step, expected_revision=expected_revision)
        try:
            assignment = normalize_army_commander_assignment_v1(
                result,
                expected_army_id=army_id,
                expected_commander_character_id=commander_character_id,
                expected_snapshot_revision=native_revision,
                expected_date_raw=date_raw,
            )
        except ValueError as error:
            raise BridgeUnavailableError(f"native commander assignment result is malformed: {error}") from error
        receipt = {
            **result,
            "army_commander_assignment": assignment,
            "submitted_revision": expected_revision,
            "submitted_native_revision": native_revision,
            "submitted_snapshot_id": snapshot.get("snapshot_id"),
        }
        if assignment["status"] not in {"submitted", "already_assigned"}:
            return receipt
        fresh = self.snapshot()
        if fresh.get("paused") is not True or any(
            fresh.get(key) != snapshot.get(key)
            for key in ("date_raw", "episode_id", "episode_character_id", "player_character_id")
        ):
            return {
                **receipt,
                "status": "submitted_verification_pending",
                "commander_assignment_verification": {
                    "status": "verification_pending", "verified": False,
                    "unavailable_reason": "commander readback crossed the paused player/date context",
                },
            }
        try:
            readback = self.query_army_commander_candidates_v1(
                army_id, expected_revision=fresh["revision"]
            )
        except (BridgeUnavailableError, UnsupportedStepError) as error:
            return {
                **receipt,
                "status": "submitted_verification_pending",
                "commander_assignment_verification": {
                    "status": "verification_pending", "verified": False,
                    "unavailable_reason": str(error),
                },
            }
        verification = commander_assignment_readback_v1(
            assignment, readback["army_commander_candidates"],
            expected_date_raw=date_raw,
        )
        return {
            **receipt,
            "status": "commander_assigned_verified" if verification["verified"] else "submitted_verification_pending",
            "native_submission_status": result.get("status"),
            "commander_assignment_verification": verification,
            "commander_readback": readback,
        }

    def query_army_strengths(
        self,
        army_ids: list[int],
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Read a requested subset of native base aggregates atomically.

        This is deliberately not a combat prediction: soldier totals and the
        AI regiment base-power lane omit terrain, commanders, counters, and
        other encounter context.
        """
        requested_ids = normalize_army_strength_request_ids(army_ids)
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "army-strength queries require a paused CK3 snapshot"
            )
        try:
            scope = army_strength_scope(snapshot)
        except ValueError as error:
            raise BridgeUnavailableError(
                f"army-strength scope is malformed: {error}"
            ) from error
        scope_ids = [int(row["army_id"]) for row in scope]
        outside_scope = [
            army_id for army_id in requested_ids if army_id not in scope_ids
        ]
        if outside_scope:
            raise BridgeUnavailableError(
                "army_ids are outside the current published player/war "
                f"scope: {outside_scope}"
            )
        if QUERY_ARMY_STRENGTHS_STEP not in action_step_set(
            self.capabilities()
        ):
            raise UnsupportedStepError(
                "selected backend cannot query native army strengths"
            )
        selected_revision = (
            expected_revision
            if expected_revision is not None
            else int(snapshot["revision"])
        )
        result = self.execute_step(
            QUERY_ARMY_STRENGTHS_STEP,
            expected_revision=selected_revision,
        )
        try:
            rows = normalize_army_strengths(
                result.get("army_strengths"), expected_scope=scope
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"native army-strength result is malformed: {error}"
            ) from error
        scope_status = army_strength_query_status(rows)
        if result.get("status") != scope_status:
            raise BridgeUnavailableError(
                "native army-strength status disagrees with its full scope"
            )
        by_id = {int(row["army_id"]): row for row in rows}
        selected_rows = [by_id[army_id] for army_id in requested_ids]
        status = army_strength_query_status(selected_rows)
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello")
            if isinstance(diagnostics, dict)
            else None
        )
        return {
            **result,
            "schema_version": 1,
            "status": status,
            "scope_status": scope_status,
            "scope": "player-and-active-war-participants",
            "source": {
                "game_version": (
                    hello.get("game_version")
                    if isinstance(hello, dict)
                    else None
                ),
                "executable_sha256": (
                    hello.get("executable_sha256")
                    if isinstance(hello, dict)
                    else None
                ),
                "snapshot_id": snapshot.get("snapshot_id"),
                "revision": snapshot.get("revision"),
                "native_revision": snapshot.get("native_revision"),
                "date_raw": snapshot.get("date_raw"),
                "paused": True,
                "backend_id": snapshot.get("backend_id"),
            },
            "army_ids": requested_ids,
            "scope_army_ids": scope_ids,
            "army_strengths": selected_rows,
        }

    def query_campaign_root_context_v1(
        self,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read the exact-build local-player campaign root while paused."""
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "campaign-root queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or revision < 0
        ):
            raise BridgeUnavailableError(
                "campaign-root query lacks a valid snapshot revision"
            )
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or expected_revision < 0
        ):
            raise ValueError(
                "expected_revision must be a non-negative integer"
            )
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "campaign-root revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "campaign-root query lacks a positive native revision"
            )
        date_raw = snapshot.get("date_raw")
        if (
            isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "campaign-root query lacks a signed int32 date"
            )
        snapshot_id = snapshot.get("snapshot_id")
        if not isinstance(snapshot_id, str) or not snapshot_id:
            raise BridgeUnavailableError(
                "campaign-root query lacks a snapshot identity"
            )
        snapshot_backend_id = snapshot.get("backend_id")
        if not isinstance(snapshot_backend_id, str) or not snapshot_backend_id:
            raise BridgeUnavailableError(
                "campaign-root query lacks a source backend identity"
            )
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_CAMPAIGN_ROOT_CONTEXT_V1_CAPABILITY
            in bridge_capabilities
            and QUERY_CAMPAIGN_ROOT_CONTEXT_V1_STEP
            in action_step_set(capabilities)
        ):
            raise UnsupportedStepError(
                "selected backend cannot query the campaign root context"
            )
        result = self.execute_step(
            QUERY_CAMPAIGN_ROOT_CONTEXT_V1_STEP,
            expected_revision=expected_revision,
        )
        mirror_keys = {
            "schema_version",
            "date_raw",
            "local_player_id",
            "player_character_id",
            "player_character_alive",
            "player_monthly_gold_income",
            "player_health",
            "player_domain_size",
            "player_domain_limit",
            "player_targeting_faction_count",
            "council",
            "primary_title",
            "primary_title_succession_character_ids",
            "held_title_partition",
            "capital_province_id",
            "immediate_liege_character_id",
            "top_liege_character_id",
            "independent",
            "direct_landed_vassal_character_ids",
            "adjacent_external_province_holder_character_ids",
            "related_character_contexts",
            "government",
            "selected_game_rule_tokens",
            "native_selected_game_rule_token_count",
            "readiness",
            "unavailable_reason",
            "provenance",
        }
        if isinstance(result, dict) and is_baseline_campaign_root_context_12002(
            result.get("campaign_root_context")
        ):
            mirror_keys &= set(result["campaign_root_context"])
        required_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "campaign_root_context",
            "backend_id",
            "campaign_root_context_ready",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            *mirror_keys,
        }
        if (
            not isinstance(result, dict)
            or set(result) != required_result_keys
            or result.get("step") != QUERY_CAMPAIGN_ROOT_CONTEXT_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "campaign-root backend returned a malformed result"
            )
        query_sequence = result.get("query_sequence")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "campaign-root result lacks query_sequence"
            )
        backend_id = result.get("backend_id")
        if not isinstance(backend_id, str) or not backend_id:
            raise BridgeUnavailableError(
                "campaign-root result lacks backend_id"
            )
        try:
            normalized = normalize_campaign_root_context_v1(
                result.get("campaign_root_context"),
                expected_date_raw=date_raw,
                expected_snapshot_revision=native_revision,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"campaign-root result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "campaign-root envelope status disagrees with its frame"
            )
        expected_mirrors = {
            key: copy.deepcopy(normalized[key]) for key in mirror_keys
        }
        if any(
            result.get(key) != expected
            for key, expected in expected_mirrors.items()
        ) or result.get("campaign_root_context_ready") is not normalized[
            "readiness"
        ]["ready"]:
            raise BridgeUnavailableError(
                "campaign-root result mirrors disagree with its frame"
            )
        if (
            result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "campaign-root result is bound to another snapshot"
            )
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello")
            if isinstance(diagnostics, dict)
            else None
        )
        provenance = normalized["provenance"]
        assert isinstance(provenance, dict)
        observed_version = (
            hello.get("expected_ck3_version", hello.get("game_version"))
            if isinstance(hello, dict)
            else None
        )
        observed_sha256 = (
            hello.get(
                "expected_ck3_sha256", hello.get("executable_sha256")
            )
            if isinstance(hello, dict)
            else None
        )
        if (
            observed_version != provenance["game_version"]
            or not isinstance(observed_sha256, str)
            or observed_sha256.upper()
            != str(provenance["executable_sha256"]).upper()
        ):
            raise BridgeUnavailableError(
                "campaign-root build mirror disagrees with bridge hello"
            )
        current = self.snapshot()
        if not (
            current.get("paused") is True
            and current.get("revision") == revision
            and current.get("snapshot_id") == snapshot_id
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id")
            == snapshot.get("episode_run_id")
        ):
            raise BridgeUnavailableError(
                "campaign-root query crossed a snapshot revision"
            )
        build = {
            "version": provenance["game_version"],
            "exe_sha256": provenance["executable_sha256"],
        }
        source = {
            "game_version": observed_version,
            "executable_sha256": observed_sha256.upper(),
            "snapshot_id": snapshot_id,
            "revision": revision,
            "native_revision": native_revision,
            "date_raw": date_raw,
            "paused": True,
            "backend_id": snapshot_backend_id,
        }
        binding = {
            "snapshot_id": snapshot_id,
            "revision": revision,
            "native_revision": native_revision,
            "date_raw": date_raw,
            "expected_revision": expected_revision,
        }
        return {
            **result,
            "schema_version": 1,
            "status": normalized["status"],
            "scope": "exact-campaign-root-context",
            "build": build,
            "source": source,
            "binding": binding,
            **expected_mirrors,
            "campaign_root_context_ready": normalized["readiness"][
                "ready"
            ],
            "campaign_root_context": normalized,
        }

    def query_council_composition_candidates_v1(
        self,
        *,
        expected_snapshot_id: str,
        public_revision: int,
        native_revision: int,
        date_raw: int,
        owner_character_id: int,
        position_key: str = STEWARD_POSITION_KEY,
    ) -> dict[str, object]:
        """Read the frozen Council19 steward candidates for one paused frame."""

        request = build_council_composition_candidates_request_v1(
            expected_snapshot_id=expected_snapshot_id,
            public_revision=public_revision,
            native_revision=native_revision,
            date_raw=date_raw,
            owner_character_id=owner_character_id,
            position_key=position_key,
        )
        snapshot = self.snapshot()
        played = snapshot.get("played_character")
        actual_owner = (
            played.get("character_id") if isinstance(played, dict) else None
        )
        expected_frame = {
            "snapshot_id": request["expected_snapshot_id"],
            "revision": request["public_revision"],
            "native_revision": request["native_revision"],
            "date_raw": request["date_raw"],
            "paused": True,
            "owner_character_id": request["owner_character_id"],
        }
        actual_frame = {
            "snapshot_id": snapshot.get("snapshot_id"),
            "revision": snapshot.get("revision"),
            "native_revision": snapshot.get("native_revision"),
            "date_raw": snapshot.get("date_raw"),
            "paused": snapshot.get("paused"),
            "owner_character_id": actual_owner,
        }
        if actual_frame != expected_frame:
            raise BridgeUnavailableError(
                "council composition request does not match the current "
                "paused frame"
            )
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_COUNCIL_COMPOSITION_CANDIDATES_V1_CAPABILITY
            in bridge_capabilities
            and QUERY_COUNCIL_COMPOSITION_CANDIDATES_V1_STEP
            in action_step_set(capabilities)
        ):
            raise UnsupportedStepError(
                "selected backend cannot query council composition candidates"
            )
        result = self.execute_step(
            QUERY_COUNCIL_COMPOSITION_CANDIDATES_V1_STEP,
            expected_revision=int(request["public_revision"]),
        )
        expected_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "council_composition_candidates",
            "council_composition_candidates_ready",
            "backend_id",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_keys
            or result.get("step")
            != QUERY_COUNCIL_COMPOSITION_CANDIDATES_V1_STEP
            or result.get("accepted") is not True
            or result.get("status") != "available"
            or result.get("snapshot_revision")
            != request["native_revision"]
            or result.get("queried_snapshot_id")
            != request["expected_snapshot_id"]
            or result.get("queried_revision")
            != request["public_revision"]
            or result.get("queried_native_revision")
            != request["native_revision"]
            or result.get("council_composition_candidates_ready") is not True
            or not isinstance(result.get("backend_id"), str)
            or not result.get("backend_id")
        ):
            raise BridgeUnavailableError(
                "council composition backend returned a malformed result"
            )
        try:
            normalized = normalize_council_composition_candidates_v1(
                result.get("council_composition_candidates"),
                expected_snapshot_id=request["expected_snapshot_id"],
                expected_public_revision=request["public_revision"],
                expected_native_revision=request["native_revision"],
                expected_date_raw=request["date_raw"],
                expected_owner_character_id=request["owner_character_id"],
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"council composition result is malformed: {error}"
            ) from error
        current = self.snapshot()
        current_played = current.get("played_character")
        current_owner = (
            current_played.get("character_id")
            if isinstance(current_played, dict)
            else None
        )
        if {
            "snapshot_id": current.get("snapshot_id"),
            "revision": current.get("revision"),
            "native_revision": current.get("native_revision"),
            "date_raw": current.get("date_raw"),
            "paused": current.get("paused"),
            "owner_character_id": current_owner,
        } != expected_frame:
            raise BridgeUnavailableError(
                "council composition query crossed the requested frame"
            )
        return {
            **result,
            "schema_version": 1,
            "schema": COUNCIL_COMPOSITION_CANDIDATES_V1_SCHEMA,
            "scope": "exact-council-composition-candidates",
            "request": request,
            "council_composition_candidates": copy.deepcopy(normalized),
        }

    def query_steward_develop_county_candidates_v1(
        self,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read native Develop County legality and candidate observations."""
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "steward development queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or revision < 0
        ):
            raise BridgeUnavailableError(
                "steward development query lacks a valid snapshot revision"
            )
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or expected_revision < 0
        ):
            raise ValueError("expected_revision must be a non-negative integer")
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "steward development revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "steward development query lacks a positive native revision"
            )
        date_raw = snapshot.get("date_raw")
        if (
            isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "steward development query lacks a signed int32 date"
            )
        snapshot_id = snapshot.get("snapshot_id")
        if not isinstance(snapshot_id, str) or not snapshot_id:
            raise BridgeUnavailableError(
                "steward development query lacks a snapshot identity"
            )
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_STEWARD_DEVELOP_COUNTY_CANDIDATES_V1_CAPABILITY
            in bridge_capabilities
            and QUERY_STEWARD_DEVELOP_COUNTY_CANDIDATES_V1_STEP
            in action_step_set(capabilities)
        ):
            raise UnsupportedStepError(
                "selected backend cannot query steward development candidates"
            )
        result = self.execute_step(
            QUERY_STEWARD_DEVELOP_COUNTY_CANDIDATES_V1_STEP,
            expected_revision=expected_revision,
        )
        required_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "steward_develop_county_candidates",
            "backend_id",
            "steward_develop_county_candidates_ready",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
        }
        if (
            not isinstance(result, dict)
            or set(result) != required_keys
            or result.get("step")
            != QUERY_STEWARD_DEVELOP_COUNTY_CANDIDATES_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "steward development backend returned a malformed result"
            )
        sequence = result.get("query_sequence")
        if (
            isinstance(sequence, bool)
            or not isinstance(sequence, int)
            or not 1 <= sequence <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "steward development result lacks query_sequence"
            )
        try:
            normalized = normalize_steward_develop_county_candidates_v1(
                result.get("steward_develop_county_candidates"),
                expected_observed_date_raw=date_raw,
                expected_snapshot_revision=native_revision,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"steward development result is malformed: {error}"
            ) from error
        if (
            result.get("status") != normalized["status"]
            or not isinstance(result.get("backend_id"), str)
            or not result.get("backend_id")
            or result.get("steward_develop_county_candidates_ready")
            is not normalized["readiness"]
            or result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "steward development result mirrors disagree with its frame"
            )
        current = self.snapshot()
        if not (
            current.get("paused") is True
            and current.get("revision") == revision
            and current.get("snapshot_id") == snapshot_id
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id") == snapshot.get("episode_run_id")
        ):
            raise BridgeUnavailableError(
                "steward development query crossed a snapshot revision"
            )
        return {
            **result,
            "schema_version": 1,
            "scope": "exact-steward-develop-county-candidates",
            "build": {
                "version": normalized["provenance"]["game_version"],
                "exe_sha256": normalized["provenance"]["executable_sha256"],
            },
            "source": {
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "backend_id": snapshot.get("backend_id"),
            },
            "binding": {
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "expected_revision": expected_revision,
            },
            "steward_develop_county_candidates": copy.deepcopy(normalized),
        }

    def change_steward_develop_county_task_v1(
        self,
        councillor_character_id: int,
        task_key: str,
        target_county_title_id: int,
        *,
        expected_revision: int,
        replace_existing_task: bool,
    ) -> dict[str, object]:
        """Submit one fixed Develop County task and return only its ACK.

        The candidate query and source snapshot are rebound immediately before
        dispatch.  A submitted ACK remains verification-pending; this method
        never fabricates a receipt from request values.
        """

        request = build_change_steward_develop_county_request_v1(
            request_id=f"steward-dev-{uuid.uuid4().hex}",
            councillor_character_id=councillor_character_id,
            task_key=task_key,
            target_county_title_id=target_county_title_id,
            expected_revision=expected_revision,
            replace_existing_task=replace_existing_task,
        )
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "steward develop-county actions require a paused CK3 snapshot"
            )
        if snapshot.get("revision") != expected_revision:
            raise PreSubmissionRevisionMismatchError(
                "steward develop-county action source revision is stale"
            )
        candidates_result = self.query_steward_develop_county_candidates_v1(
            expected_revision=expected_revision
        )
        candidates = candidates_result.get(
            "steward_develop_county_candidates"
        )
        candidate_rows = (
            candidates.get("candidates")
            if isinstance(candidates, dict)
            else None
        )
        if (
            not isinstance(candidates, dict)
            or candidates.get("status") != "available"
            or candidates.get("readiness") is not True
            or candidates.get("task_key") != request.task_key
            or candidates.get("steward_character_id")
            != request.councillor_character_id
            or not isinstance(candidate_rows, list)
            or not any(
                isinstance(row, dict)
                and row.get("county_title_id")
                == request.target_county_title_id
                and row.get("native_legal") is True
                for row in candidate_rows
            )
        ):
            raise BridgeUnavailableError(
                "steward develop-county request is not bound to an available "
                "same-frame native candidate"
            )
        bridge_capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and CHANGE_STEWARD_DEVELOP_COUNTY_TASK_V1_TRANSPORT_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend lacks the fail-closed steward "
                "develop-county action transport"
            )
        executor = getattr(
            self.driver, "change_steward_develop_county_task_v1", None
        )
        if not callable(executor):
            raise UnsupportedStepError(
                "selected backend has no typed steward develop-county executor"
            )
        raw = executor(request, expected_revision=expected_revision)
        try:
            ack = normalize_change_steward_develop_county_ack_v1(
                raw, expected_request=request
            )
        except (TypeError, ValueError) as error:
            raise BridgeUnavailableError(
                f"steward develop-county action ACK is malformed: {error}"
            ) from error
        production_advertised = (
            CHANGE_STEWARD_DEVELOP_COUNTY_TASK_V1_CAPABILITY
            in bridge_capabilities
        )
        if (
            ack["status"] == "submitted_verification_pending"
            and not production_advertised
        ):
            raise BridgeUnavailableError(
                "steward develop-county action returned a submitted ACK while "
                "its production capability is unadvertised"
            )
        return ack

    def query_player_faction_alerts_v1(
        self,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read exact-build targeting-faction and county alert components."""
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "player faction alert queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or revision < 0
        ):
            raise BridgeUnavailableError(
                "player faction alert query lacks a valid snapshot revision"
            )
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or expected_revision < 0
        ):
            raise ValueError("expected_revision must be a non-negative integer")
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "player faction alert revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "player faction alert query lacks a positive native revision"
            )
        date_raw = snapshot.get("date_raw")
        if (
            isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "player faction alert query lacks a signed int32 date"
            )
        snapshot_id = snapshot.get("snapshot_id")
        if not isinstance(snapshot_id, str) or not snapshot_id:
            raise BridgeUnavailableError(
                "player faction alert query lacks a snapshot identity"
            )
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_PLAYER_FACTION_ALERTS_V1_CAPABILITY in bridge_capabilities
            and QUERY_PLAYER_FACTION_ALERTS_V1_STEP in action_step_set(capabilities)
        ):
            raise UnsupportedStepError(
                "selected backend cannot query player faction alerts"
            )
        result = self.execute_step(
            QUERY_PLAYER_FACTION_ALERTS_V1_STEP,
            expected_revision=expected_revision,
        )
        required_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "player_faction_alerts",
            "backend_id",
            "player_faction_alerts_ready",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
        }
        if (
            not isinstance(result, dict)
            or set(result) != required_keys
            or result.get("step") != QUERY_PLAYER_FACTION_ALERTS_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "player faction alert backend returned a malformed result"
            )
        sequence = result.get("query_sequence")
        if (
            isinstance(sequence, bool)
            or not isinstance(sequence, int)
            or not 1 <= sequence <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "player faction alert result lacks query_sequence"
            )
        try:
            from .nonwar_private_build import private_native_build_identity

            source_build = private_native_build_identity(snapshot)
            normalized = normalize_player_faction_alerts_v1(
                result.get("player_faction_alerts"),
                expected_date_raw=date_raw,
                expected_snapshot_revision=native_revision,
                expected_game_version=source_build.game_version,
                expected_executable_sha256=source_build.executable_sha256,
            )
            validate_player_faction_war_handoffs_v1(
                normalized, snapshot.get("active_wars")
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"player faction alert result is malformed: {error}"
            ) from error
        if (
            result.get("status") != normalized["status"]
            or not isinstance(result.get("backend_id"), str)
            or not result.get("backend_id")
            or result.get("player_faction_alerts_ready")
            is not normalized["readiness"]["alert_ready"]
            or result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "player faction alert result mirrors disagree with its frame"
            )
        current = self.snapshot()
        if not (
            current.get("paused") is True
            and current.get("revision") == revision
            and current.get("snapshot_id") == snapshot_id
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id") == snapshot.get("episode_run_id")
        ):
            raise BridgeUnavailableError(
                "player faction alert query crossed a snapshot revision"
            )
        return {
            **result,
            "schema_version": 1,
            "scope": "exact-player-faction-alerts",
            "build": {
                "version": normalized["provenance"]["game_version"],
                "exe_sha256": normalized["provenance"]["executable_sha256"],
            },
            "source": {
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "backend_id": snapshot.get("backend_id"),
            },
            "binding": {
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "expected_revision": expected_revision,
            },
            "player_faction_alerts": copy.deepcopy(normalized),
        }

    def search_entities_v1(
        self,
        *,
        expected_revision: int,
        relation_filter: str = "any",
        after_character_id: int | None = None,
        limit: int = 50,
    ) -> dict[str, object]:
        """Search stable relationship identities from one campaign-root read."""

        root = self.query_campaign_root_context_v1(
            expected_revision=expected_revision
        )
        return build_entity_directory_v1(
            root,
            relation_filter=relation_filter,
            after_character_id=after_character_id,
            limit=limit,
        )

    def query_turn_bundle_v1(
        self,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Aggregate root, player vitals, alerts, pending and war state."""

        snapshot = self.snapshot()
        root = self.query_campaign_root_context_v1(
            expected_revision=expected_revision
        )
        try:
            return build_turn_bundle_v1(snapshot, root)
        except ValueError as error:
            raise BridgeUnavailableError(
                f"turn-bundle inputs are malformed: {error}"
            ) from error

    def query_zhongguo_b1_cycle_snapshot_v1(
        self,
        request_nonce: str,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read the paused played character's manager-owned B1 cycle."""
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "ZhongGuo B1-cycle queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if revision != expected_revision:
            raise BridgeUnavailableError(
                f"ZhongGuo B1-cycle revision mismatch: expected {expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        played = snapshot.get("played_character")
        player_id = played.get("character_id") if isinstance(played, dict) else None
        diagnostics = snapshot.get("diagnostics")
        generation = diagnostics.get("connection_generation") if isinstance(diagnostics, dict) else None
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or native_revision <= 0
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not isinstance(snapshot_id, str)
            or not snapshot_id
            or isinstance(player_id, bool)
            or not isinstance(player_id, int)
            or player_id <= 0
            or isinstance(generation, bool)
            or not isinstance(generation, int)
            or generation <= 0
        ):
            raise BridgeUnavailableError(
                "ZhongGuo B1-cycle query lacks stable portable bindings"
            )
        capabilities = self.capabilities().get("bridge_capabilities")
        if not isinstance(capabilities, list) or (
            QUERY_ZHONGGUO_B1_CYCLE_SNAPSHOT_V1_CAPABILITY not in capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query the ZhongGuo B1 cycle"
            )
        step = query_zhongguo_b1_cycle_snapshot_v1_step(request_nonce)
        query = parse_query_zhongguo_b1_cycle_snapshot_v1_step(step)
        assert query is not None
        result = self.execute_step(step, expected_revision=expected_revision)
        expected_keys = {
            "step", "accepted", "status", "query_sequence",
            "snapshot_revision", "zhongguo_b1_cycle_snapshot", "backend_id",
            "queried_snapshot_id", "queried_revision", "queried_native_revision",
            "queried_connection_generation",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_keys
            or result.get("step") != QUERY_ZHONGGUO_B1_CYCLE_SNAPSHOT_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
            or result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
            or result.get("queried_connection_generation") != generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo B1-cycle backend returned a malformed binding"
            )
        try:
            normalized = normalize_native_zhongguo_b1_cycle_snapshot_v1(
                result.get("zhongguo_b1_cycle_snapshot"),
                expected_query=query,
                expected_snapshot_revision=native_revision,
                expected_date_raw=date_raw,
                expected_player_character_id=player_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"ZhongGuo B1-cycle result is malformed: {error}"
            ) from error
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("played_character") == played
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation") == generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo B1-cycle query crossed its paused snapshot binding"
            )
        return {
            **normalized,
            "query_sequence": result["query_sequence"],
            "build": {
                "version": normalized["provenance"]["game_version"],
                "exe_sha256": normalized["provenance"]["executable_sha256"],
            },
            "bridge_source": {
                "backend_id": result["backend_id"],
                "connection_generation": generation,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_id,
            },
            "binding": {
                "request_nonce": query.request_nonce,
                "expected_revision": expected_revision,
                "manager_character_id": player_id,
            },
        }

    def query_zhongguo_case_snapshot_v1(
        self,
        case_kind: str,
        request_nonce: str,
        *,
        expected_revision: int,
        subject_character_id: int | None = None,
        owner_character_id: int | None = None,
    ) -> dict[str, object]:
        """Read one allowlisted ZhongGuo case from one paused exact frame."""
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError(
                "expected_revision must be a non-negative uint64"
            )
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "ZhongGuo case queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or not 0 <= revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo case query lacks a valid public revision"
            )
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "ZhongGuo case revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
            or not isinstance(snapshot_id, str)
            or not snapshot_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo case query lacks a stable native snapshot binding"
            )
        played_character = snapshot.get("played_character")
        player_character_id = (
            played_character.get("character_id")
            if isinstance(played_character, dict)
            else None
        )
        if (
            isinstance(player_character_id, bool)
            or not isinstance(player_character_id, int)
            or not 1 <= player_character_id <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo case query lacks the played character identity"
            )
        selected_subject_character_id = (
            player_character_id
            if subject_character_id is None
            else subject_character_id
        )
        step = query_zhongguo_case_snapshot_v1_step(
            case_kind,
            selected_subject_character_id,
            owner_character_id,
            request_nonce,
        )
        query = parse_query_zhongguo_case_snapshot_v1_step(step)
        assert query is not None
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello")
            if isinstance(diagnostics, dict)
            else None
        )
        connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        bridge_version = (
            diagnostics.get("bridge_version")
            if isinstance(diagnostics, dict)
            else None
        )
        if not isinstance(bridge_version, str) or not bridge_version:
            bridge_version = (
                hello.get("bridge_version")
                if isinstance(hello, dict)
                else None
            )
        game_adapter_id = (
            hello.get("game_adapter_id")
            if isinstance(hello, dict)
            else None
        )
        if (
            isinstance(connection_generation, bool)
            or not isinstance(connection_generation, int)
            or not 1 <= connection_generation <= 2**64 - 1
            or not isinstance(bridge_version, str)
            or not bridge_version
            or not isinstance(game_adapter_id, str)
            or not game_adapter_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo case query lacks its bridge connection binding"
            )
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_ZHONGGUO_CASE_SNAPSHOT_V1_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query allowlisted ZhongGuo cases"
            )
        result = self.execute_step(
            step,
            expected_revision=expected_revision,
        )
        expected_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "zhongguo_case_snapshot",
            "backend_id",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            "queried_connection_generation",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_result_keys
            or result.get("step")
            != QUERY_ZHONGGUO_CASE_SNAPSHOT_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "ZhongGuo case backend returned a malformed result"
            )
        query_sequence = result.get("query_sequence")
        backend_id = result.get("backend_id")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
            or not isinstance(backend_id, str)
            or not backend_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo case result lacks its native query identity"
            )
        try:
            normalized = normalize_native_zhongguo_case_snapshot_v1(
                result.get("zhongguo_case_snapshot"),
                expected_query=query,
                expected_snapshot_revision=native_revision,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"ZhongGuo case result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "ZhongGuo case envelope status disagrees with its frame"
            )
        if (
            result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
            or result.get("queried_connection_generation")
            != connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo case result is bound to another snapshot"
            )
        provenance = normalized["provenance"]
        assert isinstance(provenance, dict)
        observed_version = (
            hello.get("expected_ck3_version", hello.get("game_version"))
            if isinstance(hello, dict)
            else None
        )
        observed_sha256 = (
            hello.get(
                "expected_ck3_sha256", hello.get("executable_sha256")
            )
            if isinstance(hello, dict)
            else None
        )
        if (
            observed_version != provenance["game_version"]
            or not isinstance(observed_sha256, str)
            or observed_sha256.upper()
            != str(provenance["executable_sha256"]).upper()
            or provenance.get("consumer_id")
            != ZHONGGUO_CASE_SNAPSHOT_V1_CONSUMER_ID
        ):
            raise BridgeUnavailableError(
                "ZhongGuo case build mirror disagrees with bridge hello"
            )
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        current_played_character = current.get("played_character")
        current_player_character_id = (
            current_played_character.get("character_id")
            if isinstance(current_played_character, dict)
            else None
        )
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id")
            == snapshot.get("episode_run_id")
            and current_player_character_id == player_character_id
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation")
            == connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo case query crossed its paused snapshot binding"
            )
        actual_owner_character_id: int | None = None
        if normalized["status"] == "available":
            case = normalized["case"]
            assert isinstance(case, dict)
            owner = case["owner_character_id"]
            assert isinstance(owner, dict)
            if owner.get("status") != "available":
                raise BridgeUnavailableError(
                    "available ZhongGuo case lacks its owner identity"
                )
            owner_value = owner.get("value")
            if (
                isinstance(owner_value, bool)
                or not isinstance(owner_value, int)
                or not 1 <= owner_value <= 2**31 - 1
            ):
                raise BridgeUnavailableError(
                    "available ZhongGuo case has an invalid owner identity"
                )
            actual_owner_character_id = owner_value
        response = {
            **normalized,
            "build": {
                "version": provenance["game_version"],
                "exe_sha256": provenance["executable_sha256"],
            },
            "source": {
                "bridge_version": bridge_version,
                "game_adapter_id": game_adapter_id,
                "backend_id": backend_id,
                "consumer_id": provenance["consumer_id"],
                "connection_generation": connection_generation,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
            },
            "binding": {
                "request_nonce": query.request_nonce,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "connection_generation": connection_generation,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
                "subject_character_id": query.subject_character_id,
                "owner_character_id": actual_owner_character_id,
                "expected_revision": expected_revision,
            },
        }
        try:
            return normalize_zhongguo_case_snapshot_v1_response(
                response,
                expected_query=query,
                expected_snapshot_id=snapshot_id,
                expected_revision=revision,
                expected_native_revision=native_revision,
                expected_connection_generation=connection_generation,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"ZhongGuo case response projection is malformed: {error}"
            ) from error

    def query_zhongguo_ai_owned_case_snapshot_v1(
        self,
        owner_character_id: int,
        subject_character_id: int,
        request_nonce: str,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Read one AI manager's B1 case from one paused exact frame."""
        if expected_revision is not None and (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError(
                "expected_revision must be None or a non-negative uint64"
            )
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "ZhongGuo AI-owned case queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or not 0 <= revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo AI-owned case query lacks a valid public revision"
            )
        selected_revision = (
            revision if expected_revision is None else expected_revision
        )
        if selected_revision != revision:
            raise BridgeUnavailableError(
                "ZhongGuo AI-owned case revision mismatch: expected "
                f"{selected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
            or not isinstance(snapshot_id, str)
            or not snapshot_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo AI-owned case query lacks a stable native snapshot "
                "binding"
            )
        played_character = snapshot.get("played_character")
        player_character_id = (
            played_character.get("character_id")
            if isinstance(played_character, dict)
            else None
        )
        if (
            isinstance(player_character_id, bool)
            or not isinstance(player_character_id, int)
            or not 1 <= player_character_id <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo AI-owned case query lacks the played character "
                "identity"
            )
        step = query_zhongguo_ai_owned_case_snapshot_v1_step(
            owner_character_id,
            subject_character_id,
            request_nonce,
        )
        query = parse_query_zhongguo_ai_owned_case_snapshot_v1_step(step)
        if query is None:  # pragma: no cover - builder/parser invariant
            raise AssertionError("AI-owned case query builder violated v1")
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello")
            if isinstance(diagnostics, dict)
            else None
        )
        connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        bridge_version = (
            diagnostics.get("bridge_version")
            if isinstance(diagnostics, dict)
            else None
        )
        if not isinstance(bridge_version, str) or not bridge_version:
            bridge_version = (
                hello.get("bridge_version")
                if isinstance(hello, dict)
                else None
            )
        game_adapter_id = (
            hello.get("game_adapter_id")
            if isinstance(hello, dict)
            else None
        )
        if (
            isinstance(connection_generation, bool)
            or not isinstance(connection_generation, int)
            or not 1 <= connection_generation <= 2**64 - 1
            or not isinstance(bridge_version, str)
            or not bridge_version
            or not isinstance(game_adapter_id, str)
            or not game_adapter_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo AI-owned case query lacks its bridge connection "
                "binding"
            )
        bridge_capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_ZHONGGUO_AI_OWNED_CASE_SNAPSHOT_V1_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query AI-owned ZhongGuo cases"
            )
        result = self.execute_step(
            step,
            expected_revision=selected_revision,
        )
        expected_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "zhongguo_ai_owned_case_snapshot",
            "backend_id",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            "queried_connection_generation",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_result_keys
            or result.get("step")
            != QUERY_ZHONGGUO_AI_OWNED_CASE_SNAPSHOT_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "ZhongGuo AI-owned case backend returned a malformed result"
            )
        query_sequence = result.get("query_sequence")
        backend_id = result.get("backend_id")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
            or not isinstance(backend_id, str)
            or not backend_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo AI-owned case result lacks its native query identity"
            )
        try:
            normalized = normalize_native_zhongguo_ai_owned_case_snapshot_v1(
                result.get("zhongguo_ai_owned_case_snapshot"),
                expected_query=query,
                expected_snapshot_revision=native_revision,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"ZhongGuo AI-owned case result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "ZhongGuo AI-owned case envelope status disagrees with its "
                "frame"
            )
        if (
            result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
            or result.get("queried_connection_generation")
            != connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo AI-owned case result is bound to another snapshot"
            )
        provenance = normalized.get("provenance")
        if not isinstance(provenance, dict):
            raise BridgeUnavailableError(
                "ZhongGuo AI-owned case lacks exact-build provenance"
            )
        observed_version = (
            hello.get("expected_ck3_version", hello.get("game_version"))
            if isinstance(hello, dict)
            else None
        )
        observed_sha256 = (
            hello.get("expected_ck3_sha256", hello.get("executable_sha256"))
            if isinstance(hello, dict)
            else None
        )
        if (
            observed_version != provenance["game_version"]
            or not isinstance(observed_sha256, str)
            or observed_sha256.upper()
            != str(provenance["executable_sha256"]).upper()
            or provenance.get("consumer_id")
            != ZHONGGUO_AI_OWNED_CASE_SNAPSHOT_V1_CONSUMER_ID
        ):
            raise BridgeUnavailableError(
                "ZhongGuo AI-owned case build mirror disagrees with bridge "
                "hello"
            )
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        current_played_character = current.get("played_character")
        current_player_character_id = (
            current_played_character.get("character_id")
            if isinstance(current_played_character, dict)
            else None
        )
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id")
            == snapshot.get("episode_run_id")
            and current_player_character_id == player_character_id
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation")
            == connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo AI-owned case query crossed its paused snapshot "
                "binding"
            )
        response = {
            **normalized,
            "build": {
                "version": provenance["game_version"],
                "exe_sha256": provenance["executable_sha256"],
            },
            "source": {
                "bridge_version": bridge_version,
                "game_adapter_id": game_adapter_id,
                "backend_id": backend_id,
                "consumer_id": provenance["consumer_id"],
                "connection_generation": connection_generation,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
            },
            "binding": {
                "request_nonce": query.request_nonce,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "connection_generation": connection_generation,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
                "owner_character_id": query.owner_character_id,
                "subject_character_id": query.subject_character_id,
                "expected_revision": selected_revision,
            },
        }
        try:
            return normalize_zhongguo_ai_owned_case_snapshot_v1_response(
                response,
                expected_query=query,
                expected_snapshot_id=snapshot_id,
                expected_revision=revision,
                expected_native_revision=native_revision,
                expected_connection_generation=connection_generation,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                "ZhongGuo AI-owned case response projection is malformed: "
                f"{error}"
            ) from error

    def query_zhongguo_result_case_snapshot_v1(
        self,
        request_nonce: str,
        *,
        expected_revision: int,
        owner_character_id: int,
    ) -> dict[str, object]:
        """Read the paused player's received result from one expected owner."""
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError(
                "expected_revision must be a non-negative uint64"
            )
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "ZhongGuo result-case queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or not 0 <= revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo result-case query lacks a valid public revision"
            )
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "ZhongGuo result-case revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
            or not isinstance(snapshot_id, str)
            or not snapshot_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo result-case query lacks a stable native snapshot "
                "binding"
            )
        played_character = snapshot.get("played_character")
        player_character_id = (
            played_character.get("character_id")
            if isinstance(played_character, dict)
            else None
        )
        if (
            isinstance(player_character_id, bool)
            or not isinstance(player_character_id, int)
            or not 1 <= player_character_id <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo result-case query lacks the played character "
                "identity"
            )
        step = query_zhongguo_result_case_snapshot_v1_step(
            owner_character_id,
            request_nonce,
        )
        query = parse_query_zhongguo_result_case_snapshot_v1_step(step)
        if query is None:  # pragma: no cover - builder/parser invariant
            raise AssertionError("result-case query builder violated v1")
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello")
            if isinstance(diagnostics, dict)
            else None
        )
        connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        bridge_version = (
            diagnostics.get("bridge_version")
            if isinstance(diagnostics, dict)
            else None
        )
        if not isinstance(bridge_version, str) or not bridge_version:
            bridge_version = (
                hello.get("bridge_version")
                if isinstance(hello, dict)
                else None
            )
        game_adapter_id = (
            hello.get("game_adapter_id")
            if isinstance(hello, dict)
            else None
        )
        if (
            isinstance(connection_generation, bool)
            or not isinstance(connection_generation, int)
            or not 1 <= connection_generation <= 2**64 - 1
            or not isinstance(bridge_version, str)
            or not bridge_version
            or not isinstance(game_adapter_id, str)
            or not game_adapter_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo result-case query lacks its bridge connection "
                "binding"
            )
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_ZHONGGUO_RESULT_CASE_SNAPSHOT_V1_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query received-self ZhongGuo "
                "result cases"
            )
        result = self.execute_step(
            step,
            expected_revision=expected_revision,
        )
        expected_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "zhongguo_result_case_snapshot",
            "backend_id",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            "queried_connection_generation",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_result_keys
            or result.get("step")
            != QUERY_ZHONGGUO_RESULT_CASE_SNAPSHOT_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "ZhongGuo result-case backend returned a malformed result"
            )
        query_sequence = result.get("query_sequence")
        backend_id = result.get("backend_id")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
            or not isinstance(backend_id, str)
            or not backend_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo result-case result lacks its native query identity"
            )
        try:
            normalized = normalize_native_zhongguo_result_case_snapshot_v1(
                result.get("zhongguo_result_case_snapshot"),
                expected_query=query,
                expected_snapshot_revision=native_revision,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"ZhongGuo result-case result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "ZhongGuo result-case envelope status disagrees with its "
                "frame"
            )
        if (
            result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
            or result.get("queried_connection_generation")
            != connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo result-case result is bound to another snapshot"
            )
        provenance = normalized["provenance"]
        assert isinstance(provenance, dict)
        observed_version = (
            hello.get("expected_ck3_version", hello.get("game_version"))
            if isinstance(hello, dict)
            else None
        )
        observed_sha256 = (
            hello.get(
                "expected_ck3_sha256", hello.get("executable_sha256")
            )
            if isinstance(hello, dict)
            else None
        )
        if (
            observed_version != provenance["game_version"]
            or not isinstance(observed_sha256, str)
            or observed_sha256.upper()
            != str(provenance["executable_sha256"]).upper()
            or provenance.get("consumer_id")
            != ZHONGGUO_RESULT_CASE_SNAPSHOT_V1_CONSUMER_ID
        ):
            raise BridgeUnavailableError(
                "ZhongGuo result-case build mirror disagrees with bridge hello"
            )
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        current_played_character = current.get("played_character")
        current_player_character_id = (
            current_played_character.get("character_id")
            if isinstance(current_played_character, dict)
            else None
        )
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id")
            == snapshot.get("episode_run_id")
            and current_player_character_id == player_character_id
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation")
            == connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo result-case query crossed its paused snapshot "
                "binding"
            )
        actual_owner_character_id: int | None = None
        if normalized["status"] == "available":
            case = normalized["case"]
            assert isinstance(case, dict)
            owner = case["owner_character_id"]
            assert isinstance(owner, dict)
            owner_value = owner.get("value")
            if (
                owner.get("status") != "available"
                or isinstance(owner_value, bool)
                or not isinstance(owner_value, int)
                or not 1 <= owner_value <= 2**31 - 1
            ):
                raise BridgeUnavailableError(
                    "available ZhongGuo result-case lacks its owner identity"
                )
            actual_owner_character_id = owner_value
        response = {
            **normalized,
            "build": {
                "version": provenance["game_version"],
                "exe_sha256": provenance["executable_sha256"],
            },
            "source": {
                "bridge_version": bridge_version,
                "game_adapter_id": game_adapter_id,
                "backend_id": backend_id,
                "consumer_id": provenance["consumer_id"],
                "connection_generation": connection_generation,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
            },
            "binding": {
                "request_nonce": query.request_nonce,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "connection_generation": connection_generation,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
                "subject_character_id": player_character_id,
                "owner_character_id": actual_owner_character_id,
                "expected_revision": expected_revision,
            },
        }
        try:
            return normalize_zhongguo_result_case_snapshot_v1_response(
                response,
                expected_query=query,
                expected_snapshot_id=snapshot_id,
                expected_revision=revision,
                expected_native_revision=native_revision,
                expected_connection_generation=connection_generation,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                "ZhongGuo result-case response projection is malformed: "
                f"{error}"
            ) from error

    def query_zhongguo_b2_pip_snapshot_v1(
        self,
        request_nonce: str,
        *,
        expected_revision: int,
        owner_character_id: int,
    ) -> dict[str, object]:
        """Read the paused player's strict received-self B2 PIP projection."""
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "ZhongGuo B2 PIP queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or not 0 <= revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo B2 PIP query lacks a valid public revision"
            )
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "ZhongGuo B2 PIP revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
            or not isinstance(snapshot_id, str)
            or not snapshot_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo B2 PIP query lacks a stable native snapshot binding"
            )
        played_character = snapshot.get("played_character")
        player_character_id = (
            played_character.get("character_id")
            if isinstance(played_character, dict)
            else None
        )
        if (
            isinstance(player_character_id, bool)
            or not isinstance(player_character_id, int)
            or not 1 <= player_character_id <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo B2 PIP query lacks the played character identity"
            )
        step = query_zhongguo_b2_pip_snapshot_v1_step(
            owner_character_id, request_nonce
        )
        query = parse_query_zhongguo_b2_pip_snapshot_v1_step(step)
        if query is None:  # pragma: no cover - builder/parser invariant
            raise AssertionError("B2 PIP query builder violated v1")
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello") if isinstance(diagnostics, dict) else None
        )
        connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        bridge_version = (
            diagnostics.get("bridge_version")
            if isinstance(diagnostics, dict)
            else None
        )
        if not isinstance(bridge_version, str) or not bridge_version:
            bridge_version = (
                hello.get("bridge_version") if isinstance(hello, dict) else None
            )
        game_adapter_id = (
            hello.get("game_adapter_id") if isinstance(hello, dict) else None
        )
        if (
            isinstance(connection_generation, bool)
            or not isinstance(connection_generation, int)
            or not 1 <= connection_generation <= 2**64 - 1
            or not isinstance(bridge_version, str)
            or not bridge_version
            or not isinstance(game_adapter_id, str)
            or not game_adapter_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo B2 PIP query lacks its bridge connection binding"
            )
        bridge_capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_ZHONGGUO_B2_PIP_SNAPSHOT_V1_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query received-self ZhongGuo B2 PIP"
            )
        result = self.execute_step(step, expected_revision=expected_revision)
        expected_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "zhongguo_b2_pip_snapshot",
            "backend_id",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            "queried_connection_generation",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_result_keys
            or result.get("step") != QUERY_ZHONGGUO_B2_PIP_SNAPSHOT_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "ZhongGuo B2 PIP backend returned a malformed result"
            )
        query_sequence = result.get("query_sequence")
        backend_id = result.get("backend_id")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
            or not isinstance(backend_id, str)
            or not backend_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo B2 PIP result lacks its native query identity"
            )
        try:
            normalized = normalize_native_zhongguo_b2_pip_snapshot_v1(
                result.get("zhongguo_b2_pip_snapshot"),
                expected_query=query,
                expected_snapshot_revision=native_revision,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"ZhongGuo B2 PIP result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "ZhongGuo B2 PIP envelope status disagrees with its frame"
            )
        if (
            result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
            or result.get("queried_connection_generation")
            != connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo B2 PIP result is bound to another snapshot"
            )
        provenance = normalized["provenance"]
        assert isinstance(provenance, dict)
        observed_version = (
            hello.get("expected_ck3_version", hello.get("game_version"))
            if isinstance(hello, dict)
            else None
        )
        observed_sha256 = (
            hello.get("expected_ck3_sha256", hello.get("executable_sha256"))
            if isinstance(hello, dict)
            else None
        )
        if (
            observed_version != provenance["game_version"]
            or not isinstance(observed_sha256, str)
            or observed_sha256.upper()
            != str(provenance["executable_sha256"]).upper()
            or provenance.get("consumer_id")
            != ZHONGGUO_B2_PIP_SNAPSHOT_V1_CONSUMER_ID
        ):
            raise BridgeUnavailableError(
                "ZhongGuo B2 PIP build mirror disagrees with bridge hello"
            )
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        current_played_character = current.get("played_character")
        current_player_character_id = (
            current_played_character.get("character_id")
            if isinstance(current_played_character, dict)
            else None
        )
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id") == snapshot.get("episode_run_id")
            and current_player_character_id == player_character_id
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation")
            == connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo B2 PIP query crossed its paused snapshot binding"
            )
        actual_owner_character_id: int | None = None
        if normalized["status"] == "available":
            gate = normalized["gate"]
            assert isinstance(gate, dict)
            owner = gate["owner_character_id"]
            assert isinstance(owner, dict)
            owner_value = owner.get("value")
            if (
                owner.get("status") != "available"
                or isinstance(owner_value, bool)
                or not isinstance(owner_value, int)
                or not 1 <= owner_value <= 2**31 - 1
            ):
                raise BridgeUnavailableError(
                    "available ZhongGuo B2 PIP lacks its owner identity"
                )
            actual_owner_character_id = owner_value
        response = {
            **normalized,
            "build": {
                "version": provenance["game_version"],
                "exe_sha256": provenance["executable_sha256"],
            },
            "source": {
                "bridge_version": bridge_version,
                "game_adapter_id": game_adapter_id,
                "backend_id": backend_id,
                "consumer_id": provenance["consumer_id"],
                "connection_generation": connection_generation,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
            },
            "binding": {
                "request_nonce": query.request_nonce,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "connection_generation": connection_generation,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
                "subject_character_id": player_character_id,
                "owner_character_id": actual_owner_character_id,
                "expected_revision": expected_revision,
            },
        }
        try:
            return normalize_zhongguo_b2_pip_snapshot_v1_response(
                response,
                expected_query=query,
                expected_snapshot_id=snapshot_id,
                expected_revision=revision,
                expected_native_revision=native_revision,
                expected_connection_generation=connection_generation,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                "ZhongGuo B2 PIP response projection is malformed: "
                f"{error}"
            ) from error

    def query_zhongguo_promotion_compensation_postcondition_v1(
        self,
        request_nonce: str,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read the paused player's correlated promotion/compensation receipt."""
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        snapshot = self.snapshot()
        revision = snapshot.get("revision")
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        played = snapshot.get("played_character")
        player_character_id = (
            played.get("character_id") if isinstance(played, dict) else None
        )
        diagnostics = snapshot.get("diagnostics")
        connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        hello = (
            diagnostics.get("hello") if isinstance(diagnostics, dict) else None
        )
        if (
            snapshot.get("paused") is not True
            or revision != expected_revision
            or isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
            or not isinstance(snapshot_id, str)
            or not snapshot_id
            or isinstance(player_character_id, bool)
            or not isinstance(player_character_id, int)
            or isinstance(connection_generation, bool)
            or not isinstance(connection_generation, int)
            or not 1 <= connection_generation <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo promotion/compensation query lacks one stable "
                "paused player binding"
            )
        step = query_zhongguo_promotion_compensation_v1_step(
            player_character_id, request_nonce
        )
        query = parse_query_zhongguo_promotion_compensation_v1_step(step)
        if query is None:  # pragma: no cover - builder/parser invariant
            raise AssertionError(
                "promotion/compensation query builder violated v1"
            )
        capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(capabilities, list)
            and QUERY_ZHONGGUO_PROMOTION_COMPENSATION_V1_CAPABILITY
            in capabilities
        ):
            raise UnsupportedStepError(
                "selected backend does not advertise the ZhongGuo "
                "promotion/compensation postcondition query"
            )
        result = self.execute_step(step, expected_revision=expected_revision)
        expected_keys = {
            "step", "accepted", "status", "query_sequence",
            "snapshot_revision", "zhongguo_promotion_compensation_postcondition",
            "backend_id", "queried_snapshot_id", "queried_revision",
            "queried_native_revision", "queried_connection_generation",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_keys
            or result.get("step")
            != QUERY_ZHONGGUO_PROMOTION_COMPENSATION_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
            or result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
            or result.get("queried_connection_generation")
            != connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo promotion/compensation backend result is not bound "
                "to the requested paused frame"
            )
        try:
            normalized = normalize_native_zhongguo_promotion_compensation_v1(
                result.get(
                    "zhongguo_promotion_compensation_postcondition"
                ),
                expected_query=query,
                expected_snapshot_revision=native_revision,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                "ZhongGuo promotion/compensation result is malformed: "
                f"{error}"
            ) from error
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        current_played = current.get("played_character")
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and isinstance(current_played, dict)
            and current_played.get("character_id") == player_character_id
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation")
            == connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo promotion/compensation query crossed its paused "
                "snapshot binding"
            )
        bridge_version = (
            diagnostics.get("bridge_version")
            if isinstance(diagnostics, dict)
            else None
        )
        if not isinstance(bridge_version, str) or not bridge_version:
            bridge_version = (
                hello.get("bridge_version") if isinstance(hello, dict) else None
            )
        game_adapter_id = (
            hello.get("game_adapter_id") if isinstance(hello, dict) else None
        )
        return {
            **normalized,
            "source_backend_id": "native-headless",
            "build": {
                "version": "1.19.0.6",
                "exe_sha256": (
                    "2D00FF3101EF70B566F2FCBAE292F09263199C80E9DC8F139B82D7D96F83DB86"
                ),
            },
            "source": {
                "bridge_version": bridge_version,
                "game_adapter_id": game_adapter_id,
                "backend_id": result.get("backend_id"),
                "connection_generation": connection_generation,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
            },
            "binding": {
                "request_nonce": query.request_nonce,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "connection_generation": connection_generation,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
                "subject_character_id": normalized["subject_character_id"],
                "owner_character_id": player_character_id,
                "expected_revision": expected_revision,
            },
        }

    def query_zhongguo_compensation_af5_snapshot_v1(
        self,
        request_nonce: str,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read the paused player's correlated compensation AF5 receipt."""
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        snapshot = self.snapshot()
        revision = snapshot.get("revision")
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        played = snapshot.get("played_character")
        player_character_id = (
            played.get("character_id") if isinstance(played, dict) else None
        )
        diagnostics = snapshot.get("diagnostics")
        connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        hello = (
            diagnostics.get("hello") if isinstance(diagnostics, dict) else None
        )
        if (
            snapshot.get("paused") is not True
            or revision != expected_revision
            or isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
            or not isinstance(snapshot_id, str)
            or not snapshot_id
            or isinstance(player_character_id, bool)
            or not isinstance(player_character_id, int)
            or isinstance(connection_generation, bool)
            or not isinstance(connection_generation, int)
            or not 1 <= connection_generation <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo compensation AF5 query lacks one stable "
                "paused player binding"
            )
        step = query_zhongguo_compensation_af5_snapshot_v1_step(
            player_character_id, request_nonce
        )
        query = parse_query_zhongguo_compensation_af5_snapshot_v1_step(step)
        if query is None:  # pragma: no cover - builder/parser invariant
            raise AssertionError(
                "compensation AF5 query builder violated v1"
            )
        capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(capabilities, list)
            and QUERY_ZHONGGUO_COMPENSATION_AF5_SNAPSHOT_V1_CAPABILITY
            in capabilities
        ):
            raise UnsupportedStepError(
                "selected backend does not advertise the ZhongGuo "
                "compensation AF5 postcondition query"
            )
        result = self.execute_step(step, expected_revision=expected_revision)
        expected_keys = {
            "step", "accepted", "status", "query_sequence",
            "snapshot_revision", "zhongguo_compensation_af5_snapshot",
            "backend_id", "queried_snapshot_id", "queried_revision",
            "queried_native_revision", "queried_connection_generation",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_keys
            or result.get("step")
            != QUERY_ZHONGGUO_COMPENSATION_AF5_SNAPSHOT_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
            or result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
            or result.get("queried_connection_generation")
            != connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo compensation AF5 backend result is not bound "
                "to the requested paused frame"
            )
        try:
            normalized = normalize_native_zhongguo_compensation_af5_snapshot_v1(
                result.get(
                    "zhongguo_compensation_af5_snapshot"
                ),
                expected_query=query,
                expected_snapshot_revision=native_revision,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                "ZhongGuo compensation AF5 result is malformed: "
                f"{error}"
            ) from error
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        current_played = current.get("played_character")
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and isinstance(current_played, dict)
            and current_played.get("character_id") == player_character_id
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation")
            == connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo compensation AF5 query crossed its paused "
                "snapshot binding"
            )
        bridge_version = (
            diagnostics.get("bridge_version")
            if isinstance(diagnostics, dict)
            else None
        )
        if not isinstance(bridge_version, str) or not bridge_version:
            bridge_version = (
                hello.get("bridge_version") if isinstance(hello, dict) else None
            )
        game_adapter_id = (
            hello.get("game_adapter_id") if isinstance(hello, dict) else None
        )
        return {
            **normalized,
            "source_backend_id": "native-headless",
            "build": {
                "version": "1.19.0.6",
                "exe_sha256": (
                    "2D00FF3101EF70B566F2FCBAE292F09263199C80E9DC8F139B82D7D96F83DB86"
                ),
            },
            "source": {
                "bridge_version": bridge_version,
                "game_adapter_id": game_adapter_id,
                "backend_id": result.get("backend_id"),
                "connection_generation": connection_generation,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
            },
            "binding": {
                "request_nonce": query.request_nonce,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "connection_generation": connection_generation,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
                "subject_character_id": normalized["subject_character_id"],
                "owner_character_id": player_character_id,
                "expected_revision": expected_revision,
            },
        }

    def query_zhongguo_workforce_owner_snapshot_v1(
        self,
        request_nonce: str,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read the paused player's correlated Workforce owner receipt."""
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        snapshot = self.snapshot()
        revision = snapshot.get("revision")
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        played = snapshot.get("played_character")
        player_character_id = (
            played.get("character_id") if isinstance(played, dict) else None
        )
        diagnostics = snapshot.get("diagnostics")
        connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        hello = (
            diagnostics.get("hello") if isinstance(diagnostics, dict) else None
        )
        if (
            snapshot.get("paused") is not True
            or revision != expected_revision
            or isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
            or not isinstance(snapshot_id, str)
            or not snapshot_id
            or isinstance(player_character_id, bool)
            or not isinstance(player_character_id, int)
            or isinstance(connection_generation, bool)
            or not isinstance(connection_generation, int)
            or not 1 <= connection_generation <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce owner query lacks one stable "
                "paused player binding"
            )
        step = query_zhongguo_workforce_owner_snapshot_v1_step(
            player_character_id, request_nonce
        )
        query = parse_query_zhongguo_workforce_owner_snapshot_v1_step(step)
        if query is None:  # pragma: no cover - builder/parser invariant
            raise AssertionError(
                "Workforce owner query builder violated v1"
            )
        capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(capabilities, list)
            and QUERY_ZHONGGUO_WORKFORCE_OWNER_SNAPSHOT_V1_CAPABILITY
            in capabilities
        ):
            raise UnsupportedStepError(
                "selected backend does not advertise the ZhongGuo "
                "Workforce owner postcondition query"
            )
        result = self.execute_step(step, expected_revision=expected_revision)
        expected_keys = {
            "step", "accepted", "status", "query_sequence",
            "snapshot_revision", "zhongguo_workforce_owner_snapshot",
            "backend_id", "queried_snapshot_id", "queried_revision",
            "queried_native_revision", "queried_connection_generation",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_keys
            or result.get("step")
            != QUERY_ZHONGGUO_WORKFORCE_OWNER_SNAPSHOT_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
            or result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
            or result.get("queried_connection_generation")
            != connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce owner backend result is not bound "
                "to the requested paused frame"
            )
        try:
            normalized = normalize_native_zhongguo_workforce_owner_snapshot_v1(
                result.get(
                    "zhongguo_workforce_owner_snapshot"
                ),
                expected_query=query,
                expected_snapshot_revision=native_revision,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                "ZhongGuo Workforce owner result is malformed: "
                f"{error}"
            ) from error
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        current_played = current.get("played_character")
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and isinstance(current_played, dict)
            and current_played.get("character_id") == player_character_id
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation")
            == connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce owner query crossed its paused "
                "snapshot binding"
            )
        bridge_version = (
            diagnostics.get("bridge_version")
            if isinstance(diagnostics, dict)
            else None
        )
        if not isinstance(bridge_version, str) or not bridge_version:
            bridge_version = (
                hello.get("bridge_version") if isinstance(hello, dict) else None
            )
        game_adapter_id = (
            hello.get("game_adapter_id") if isinstance(hello, dict) else None
        )
        return {
            **normalized,
            "source_backend_id": "native-headless",
            "build": {
                "version": "1.19.0.6",
                "exe_sha256": (
                    "2D00FF3101EF70B566F2FCBAE292F09263199C80E9DC8F139B82D7D96F83DB86"
                ),
            },
            "source": {
                "bridge_version": bridge_version,
                "game_adapter_id": game_adapter_id,
                "backend_id": result.get("backend_id"),
                "connection_generation": connection_generation,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
            },
            "binding": {
                "request_nonce": query.request_nonce,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "connection_generation": connection_generation,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
                "subject_character_id": normalized["subject_character_id"],
                "owner_character_id": player_character_id,
                "expected_revision": expected_revision,
            },
        }

    def query_zhongguo_projects_metrics_postcondition_v1(
        self,
        request_nonce: str,
        *,
        expected_revision: int,
        owner_character_id: int,
        subject_character_id: int | None = None,
    ) -> dict[str, object]:
        """Read one explicit subject's correlated projects/metrics receipt."""
        if (
            isinstance(owner_character_id, bool)
            or not isinstance(owner_character_id, int)
            or not 1 <= owner_character_id <= 2**31 - 1
        ):
            raise ValueError("owner_character_id must be a positive int32")
        if subject_character_id is not None and (
            isinstance(subject_character_id, bool)
            or not isinstance(subject_character_id, int)
            or not 1 <= subject_character_id <= 2**31 - 1
        ):
            raise ValueError("subject_character_id must be a positive int32")
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        snapshot = self.snapshot()
        revision = snapshot.get("revision")
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        played = snapshot.get("played_character")
        player_character_id = (
            played.get("character_id") if isinstance(played, dict) else None
        )
        diagnostics = snapshot.get("diagnostics")
        connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        hello = (
            diagnostics.get("hello") if isinstance(diagnostics, dict) else None
        )
        if (
            snapshot.get("paused") is not True
            or revision != expected_revision
            or isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
            or not isinstance(snapshot_id, str)
            or not snapshot_id
            or isinstance(player_character_id, bool)
            or not isinstance(player_character_id, int)
            or isinstance(connection_generation, bool)
            or not isinstance(connection_generation, int)
            or not 1 <= connection_generation <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo projects/metrics query lacks one stable "
                "paused player binding"
            )
        selected_subject_character_id = (
            player_character_id
            if subject_character_id is None
            else subject_character_id
        )
        if (
            selected_subject_character_id == owner_character_id
            or player_character_id not in {
                owner_character_id, selected_subject_character_id
            }
        ):
            raise BridgeUnavailableError(
                "ZhongGuo projects/metrics query requires the paused player "
                "to be either its explicit owner or subject"
            )
        step = query_zhongguo_projects_metrics_v1_step(
            owner_character_id, selected_subject_character_id, request_nonce
        )
        query = parse_query_zhongguo_projects_metrics_v1_step(step)
        if query is None:  # pragma: no cover - builder/parser invariant
            raise AssertionError(
                "projects/metrics query builder violated v1"
            )
        capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(capabilities, list)
            and QUERY_ZHONGGUO_PROJECTS_METRICS_V1_CAPABILITY
            in capabilities
        ):
            raise UnsupportedStepError(
                "selected backend does not advertise the ZhongGuo "
                "projects/metrics postcondition query"
            )
        result = self.execute_step(step, expected_revision=expected_revision)
        expected_keys = {
            "step", "accepted", "status", "query_sequence",
            "snapshot_revision", "zhongguo_projects_metrics_postcondition",
            "backend_id", "queried_snapshot_id", "queried_revision",
            "queried_native_revision", "queried_connection_generation",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_keys
            or result.get("step")
            != QUERY_ZHONGGUO_PROJECTS_METRICS_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
            or result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
            or result.get("queried_connection_generation")
            != connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo projects/metrics backend result is not bound "
                "to the requested paused frame"
            )
        try:
            normalized = normalize_native_zhongguo_projects_metrics_v1(
                result.get(
                    "zhongguo_projects_metrics_postcondition"
                ),
                expected_query=query,
                expected_snapshot_revision=native_revision,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                "ZhongGuo projects/metrics result is malformed: "
                f"{error}"
            ) from error
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        current_played = current.get("played_character")
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and isinstance(current_played, dict)
            and current_played.get("character_id") == player_character_id
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation")
            == connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo projects/metrics query crossed its paused "
                "snapshot binding"
            )
        bridge_version = (
            diagnostics.get("bridge_version")
            if isinstance(diagnostics, dict)
            else None
        )
        if not isinstance(bridge_version, str) or not bridge_version:
            bridge_version = (
                hello.get("bridge_version") if isinstance(hello, dict) else None
            )
        game_adapter_id = (
            hello.get("game_adapter_id") if isinstance(hello, dict) else None
        )
        return {
            **normalized,
            "source_backend_id": "native-headless",
            "build": {
                "version": "1.19.0.6",
                "exe_sha256": (
                    "2D00FF3101EF70B566F2FCBAE292F09263199C80E9DC8F139B82D7D96F83DB86"
                ),
            },
            "source": {
                "bridge_version": bridge_version,
                "game_adapter_id": game_adapter_id,
                "backend_id": result.get("backend_id"),
                "connection_generation": connection_generation,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
            },
            "binding": {
                "request_nonce": query.request_nonce,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "connection_generation": connection_generation,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
                "subject_character_id": selected_subject_character_id,
                "owner_character_id": owner_character_id,
                "expected_revision": expected_revision,
            },
        }

    def query_zhongguo_career_hc_workforce_postcondition_v1(
        self,
        request_nonce: str,
        *,
        expected_revision: int,
        owner_character_id: int,
    ) -> dict[str, object]:
        """Read the paused player's correlated career-HC/workforce receipt."""
        if (
            isinstance(owner_character_id, bool)
            or not isinstance(owner_character_id, int)
            or not 1 <= owner_character_id <= 2**31 - 1
        ):
            raise ValueError("owner_character_id must be a positive int32")
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        snapshot = self.snapshot()
        revision = snapshot.get("revision")
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        played = snapshot.get("played_character")
        player_character_id = (
            played.get("character_id") if isinstance(played, dict) else None
        )
        diagnostics = snapshot.get("diagnostics")
        connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        hello = (
            diagnostics.get("hello") if isinstance(diagnostics, dict) else None
        )
        if (
            snapshot.get("paused") is not True
            or revision != expected_revision
            or isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
            or not isinstance(snapshot_id, str)
            or not snapshot_id
            or isinstance(player_character_id, bool)
            or not isinstance(player_character_id, int)
            or isinstance(connection_generation, bool)
            or not isinstance(connection_generation, int)
            or not 1 <= connection_generation <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo career-HC/workforce query lacks one stable "
                "paused player binding"
            )
        step = query_zhongguo_career_hc_workforce_v1_step(
            owner_character_id, request_nonce
        )
        query = parse_query_zhongguo_career_hc_workforce_v1_step(step)
        if query is None:  # pragma: no cover - builder/parser invariant
            raise AssertionError(
                "career-HC/workforce query builder violated v1"
            )
        capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(capabilities, list)
            and QUERY_ZHONGGUO_CAREER_HC_WORKFORCE_V1_CAPABILITY
            in capabilities
        ):
            raise UnsupportedStepError(
                "selected backend does not advertise the ZhongGuo "
                "career-HC/workforce postcondition query"
            )
        result = self.execute_step(step, expected_revision=expected_revision)
        expected_keys = {
            "step", "accepted", "status", "query_sequence",
            "snapshot_revision", "zhongguo_career_hc_workforce_postcondition",
            "backend_id", "queried_snapshot_id", "queried_revision",
            "queried_native_revision", "queried_connection_generation",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_keys
            or result.get("step")
            != QUERY_ZHONGGUO_CAREER_HC_WORKFORCE_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
            or result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
            or result.get("queried_connection_generation")
            != connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo career-HC/workforce backend result is not bound "
                "to the requested paused frame"
            )
        try:
            normalized = normalize_native_zhongguo_career_hc_workforce_v1(
                result.get(
                    "zhongguo_career_hc_workforce_postcondition"
                ),
                expected_query=query,
                expected_snapshot_revision=native_revision,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                "ZhongGuo career-HC/workforce result is malformed: "
                f"{error}"
            ) from error
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        current_played = current.get("played_character")
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and isinstance(current_played, dict)
            and current_played.get("character_id") == player_character_id
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation")
            == connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo career-HC/workforce query crossed its paused "
                "snapshot binding"
            )
        bridge_version = (
            diagnostics.get("bridge_version")
            if isinstance(diagnostics, dict)
            else None
        )
        if not isinstance(bridge_version, str) or not bridge_version:
            bridge_version = (
                hello.get("bridge_version") if isinstance(hello, dict) else None
            )
        game_adapter_id = (
            hello.get("game_adapter_id") if isinstance(hello, dict) else None
        )
        return {
            **normalized,
            "source_backend_id": "native-headless",
            "build": {
                "version": "1.19.0.6",
                "exe_sha256": (
                    "2D00FF3101EF70B566F2FCBAE292F09263199C80E9DC8F139B82D7D96F83DB86"
                ),
            },
            "source": {
                "bridge_version": bridge_version,
                "game_adapter_id": game_adapter_id,
                "backend_id": result.get("backend_id"),
                "connection_generation": connection_generation,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
            },
            "binding": {
                "request_nonce": query.request_nonce,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "connection_generation": connection_generation,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
                "subject_character_id": player_character_id,
                "owner_character_id": owner_character_id,
                "expected_revision": expected_revision,
            },
        }



    def query_zhongguo_workforce_collective_snapshot_v1(
        self,
        request_nonce: str,
        *,
        expected_revision: int,
        owner_character_id: int,
    ) -> dict[str, object]:
        """Read the player's received Workforce collective and owner ledger."""
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "ZhongGuo Workforce collective queries require a paused CK3 "
                "snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or not 0 <= revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce collective query lacks a valid public "
                "revision"
            )
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "ZhongGuo Workforce collective revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
            or not isinstance(snapshot_id, str)
            or not snapshot_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce collective query lacks a stable native "
                "snapshot binding"
            )
        played_character = snapshot.get("played_character")
        player_character_id = (
            played_character.get("character_id")
            if isinstance(played_character, dict)
            else None
        )
        if (
            isinstance(player_character_id, bool)
            or not isinstance(player_character_id, int)
            or not 1 <= player_character_id <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce collective query lacks the played "
                "character identity"
            )
        step = query_zhongguo_workforce_collective_snapshot_v1_step(
            owner_character_id, request_nonce
        )
        query = parse_query_zhongguo_workforce_collective_snapshot_v1_step(
            step
        )
        if query is None:  # pragma: no cover - builder/parser invariant
            raise AssertionError("Workforce collective query builder violated v1")
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello") if isinstance(diagnostics, dict) else None
        )
        connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        bridge_version = (
            diagnostics.get("bridge_version")
            if isinstance(diagnostics, dict)
            else None
        )
        if not isinstance(bridge_version, str) or not bridge_version:
            bridge_version = (
                hello.get("bridge_version") if isinstance(hello, dict) else None
            )
        game_adapter_id = (
            hello.get("game_adapter_id") if isinstance(hello, dict) else None
        )
        if (
            isinstance(connection_generation, bool)
            or not isinstance(connection_generation, int)
            or not 1 <= connection_generation <= 2**64 - 1
            or not isinstance(bridge_version, str)
            or not bridge_version
            or not isinstance(game_adapter_id, str)
            or not game_adapter_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce collective query lacks its bridge "
                "connection binding"
            )
        bridge_capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_ZHONGGUO_WORKFORCE_COLLECTIVE_SNAPSHOT_V1_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query received-self ZhongGuo "
                "Workforce collective state"
            )
        result = self.execute_step(step, expected_revision=expected_revision)
        expected_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "zhongguo_workforce_collective_snapshot",
            "backend_id",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            "queried_connection_generation",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_result_keys
            or result.get("step")
            != QUERY_ZHONGGUO_WORKFORCE_COLLECTIVE_SNAPSHOT_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce collective backend returned a malformed "
                "result"
            )
        query_sequence = result.get("query_sequence")
        backend_id = result.get("backend_id")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
            or not isinstance(backend_id, str)
            or not backend_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce collective result lacks its native query "
                "identity"
            )
        try:
            normalized = (
                normalize_native_zhongguo_workforce_collective_snapshot_v1(
                    result.get("zhongguo_workforce_collective_snapshot"),
                    expected_query=query,
                    expected_snapshot_revision=native_revision,
                    expected_date_raw=date_raw,
                    expected_player_character_id=player_character_id,
                )
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"ZhongGuo Workforce collective result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "ZhongGuo Workforce collective envelope status disagrees "
                "with its frame"
            )
        if (
            result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
            or result.get("queried_connection_generation")
            != connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce collective result is bound to another "
                "snapshot"
            )
        provenance = normalized["provenance"]
        assert isinstance(provenance, dict)
        observed_version = (
            hello.get("expected_ck3_version", hello.get("game_version"))
            if isinstance(hello, dict)
            else None
        )
        observed_sha256 = (
            hello.get("expected_ck3_sha256", hello.get("executable_sha256"))
            if isinstance(hello, dict)
            else None
        )
        if (
            observed_version != provenance["game_version"]
            or not isinstance(observed_sha256, str)
            or observed_sha256.upper()
            != str(provenance["executable_sha256"]).upper()
            or provenance.get("consumer_id")
            != ZHONGGUO_WORKFORCE_COLLECTIVE_SNAPSHOT_V1_CONSUMER_ID
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce collective build mirror disagrees with "
                "bridge hello"
            )
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        current_played_character = current.get("played_character")
        current_player_character_id = (
            current_played_character.get("character_id")
            if isinstance(current_played_character, dict)
            else None
        )
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id") == snapshot.get("episode_run_id")
            and current_player_character_id == player_character_id
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation")
            == connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce collective query crossed its paused "
                "snapshot binding"
            )
        actual_owner_character_id = (
            query.owner_character_id
            if normalized["status"] == "available"
            else None
        )
        response = {
            **normalized,
            "build": {
                "version": provenance["game_version"],
                "exe_sha256": provenance["executable_sha256"],
            },
            "source": {
                "bridge_version": bridge_version,
                "game_adapter_id": game_adapter_id,
                "backend_id": backend_id,
                "consumer_id": provenance["consumer_id"],
                "connection_generation": connection_generation,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
            },
            "binding": {
                "request_nonce": query.request_nonce,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "connection_generation": connection_generation,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
                "subject_character_id": player_character_id,
                "owner_character_id": actual_owner_character_id,
                "expected_revision": expected_revision,
            },
        }
        try:
            return normalize_zhongguo_workforce_collective_snapshot_v1_response(
                response,
                expected_query=query,
                expected_snapshot_id=snapshot_id,
                expected_revision=revision,
                expected_native_revision=native_revision,
                expected_connection_generation=connection_generation,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                "ZhongGuo Workforce collective response projection is "
                f"malformed: {error}"
            ) from error

    def query_zhongguo_workforce_normal_exit_snapshot_v1(
        self,
        request_nonce: str,
        *,
        expected_revision: int,
        owner_character_id: int,
    ) -> dict[str, object]:
        """Read the player's received Workforce normal-exit/HC lifecycle."""
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "ZhongGuo Workforce normal-exit queries require a paused "
                "CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or not 0 <= revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce normal-exit query lacks a valid public "
                "revision"
            )
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "ZhongGuo Workforce normal-exit revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
            or not isinstance(snapshot_id, str)
            or not snapshot_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce normal-exit query lacks a stable native "
                "snapshot binding"
            )
        played_character = snapshot.get("played_character")
        player_character_id = (
            played_character.get("character_id")
            if isinstance(played_character, dict)
            else None
        )
        if (
            isinstance(player_character_id, bool)
            or not isinstance(player_character_id, int)
            or not 1 <= player_character_id <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce normal-exit query lacks the played "
                "character identity"
            )
        step = query_zhongguo_workforce_normal_exit_snapshot_v1_step(
            owner_character_id, request_nonce
        )
        query = parse_query_zhongguo_workforce_normal_exit_snapshot_v1_step(
            step
        )
        if query is None:  # pragma: no cover - builder/parser invariant
            raise AssertionError("Workforce normal-exit query builder violated v1")
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello") if isinstance(diagnostics, dict) else None
        )
        connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        bridge_version = (
            diagnostics.get("bridge_version")
            if isinstance(diagnostics, dict)
            else None
        )
        if not isinstance(bridge_version, str) or not bridge_version:
            bridge_version = (
                hello.get("bridge_version") if isinstance(hello, dict) else None
            )
        game_adapter_id = (
            hello.get("game_adapter_id") if isinstance(hello, dict) else None
        )
        if (
            isinstance(connection_generation, bool)
            or not isinstance(connection_generation, int)
            or not 1 <= connection_generation <= 2**64 - 1
            or not isinstance(bridge_version, str)
            or not bridge_version
            or not isinstance(game_adapter_id, str)
            or not game_adapter_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce normal-exit query lacks its bridge "
                "connection binding"
            )
        bridge_capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_ZHONGGUO_WORKFORCE_NORMAL_EXIT_SNAPSHOT_V1_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query received-self ZhongGuo "
                "Workforce normal-exit state"
            )
        result = self.execute_step(step, expected_revision=expected_revision)
        expected_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "zhongguo_workforce_normal_exit_snapshot",
            "backend_id",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            "queried_connection_generation",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_result_keys
            or result.get("step")
            != QUERY_ZHONGGUO_WORKFORCE_NORMAL_EXIT_SNAPSHOT_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce normal-exit backend returned a malformed "
                "result"
            )
        query_sequence = result.get("query_sequence")
        backend_id = result.get("backend_id")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
            or not isinstance(backend_id, str)
            or not backend_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce normal-exit result lacks its native "
                "query identity"
            )
        try:
            normalized = (
                normalize_native_zhongguo_workforce_normal_exit_snapshot_v1(
                    result.get("zhongguo_workforce_normal_exit_snapshot"),
                    expected_query=query,
                    expected_snapshot_revision=native_revision,
                    expected_date_raw=date_raw,
                    expected_player_character_id=player_character_id,
                )
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"ZhongGuo Workforce normal-exit result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "ZhongGuo Workforce normal-exit envelope status disagrees "
                "with its frame"
            )
        if (
            result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
            or result.get("queried_connection_generation")
            != connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce normal-exit result is bound to another "
                "snapshot"
            )
        provenance = normalized.get("provenance")
        if not isinstance(provenance, dict):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce normal-exit result lacks provenance"
            )
        observed_version = (
            hello.get("expected_ck3_version", hello.get("game_version"))
            if isinstance(hello, dict)
            else None
        )
        observed_sha256 = (
            hello.get("expected_ck3_sha256", hello.get("executable_sha256"))
            if isinstance(hello, dict)
            else None
        )
        if (
            observed_version != provenance.get("game_version")
            or not isinstance(observed_sha256, str)
            or observed_sha256.upper()
            != str(provenance.get("executable_sha256")).upper()
            or provenance.get("consumer_id")
            != ZHONGGUO_WORKFORCE_NORMAL_EXIT_CONSUMER_ID_V1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce normal-exit build mirror disagrees with "
                "bridge hello"
            )
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        current_played_character = current.get("played_character")
        current_player_character_id = (
            current_played_character.get("character_id")
            if isinstance(current_played_character, dict)
            else None
        )
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id") == snapshot.get("episode_run_id")
            and current_player_character_id == player_character_id
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation")
            == connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo Workforce normal-exit query crossed its paused "
                "snapshot binding"
            )
        response = {
            **normalized,
            "build": {
                "version": provenance["game_version"],
                "exe_sha256": provenance["executable_sha256"],
            },
            "bridge_source": {
                "bridge_version": bridge_version,
                "game_adapter_id": game_adapter_id,
                "backend_id": backend_id,
                "consumer_id": provenance["consumer_id"],
                "connection_generation": connection_generation,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
            },
            "binding": {
                "request_nonce": query.request_nonce,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "connection_generation": connection_generation,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
                "subject_character_id": player_character_id,
                "owner_character_id": query.owner_character_id,
                "expected_revision": expected_revision,
            },
        }
        try:
            return normalize_zhongguo_workforce_normal_exit_snapshot_v1_response(
                response,
                expected_query=query,
                expected_snapshot_id=snapshot_id,
                expected_revision=revision,
                expected_native_revision=native_revision,
                expected_connection_generation=connection_generation,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                "ZhongGuo Workforce normal-exit response projection is "
                f"malformed: {error}"
            ) from error

    def query_zhongguo_incident_snapshot_v1(
        self,
        request_nonce: str,
        *,
        expected_revision: int,
        owner_character_id: int,
        profile: str,
    ) -> dict[str, object]:
        """Read one paused fixed-profile incident projection for the player."""
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "ZhongGuo incident queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or not 0 <= revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo incident query lacks a valid public revision"
            )
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "ZhongGuo incident revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
            or not isinstance(snapshot_id, str)
            or not snapshot_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo incident query lacks a stable native snapshot binding"
            )
        played_character = snapshot.get("played_character")
        player_character_id = (
            played_character.get("character_id")
            if isinstance(played_character, dict)
            else None
        )
        if (
            isinstance(player_character_id, bool)
            or not isinstance(player_character_id, int)
            or not 1 <= player_character_id <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo incident query lacks the played character identity"
            )
        step = query_zhongguo_incident_snapshot_v1_step(
            owner_character_id, profile, request_nonce
        )
        query = parse_query_zhongguo_incident_snapshot_v1_step(step)
        if query is None:  # pragma: no cover - builder/parser invariant
            raise AssertionError("incident query builder violated v1")
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello") if isinstance(diagnostics, dict) else None
        )
        connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        bridge_version = (
            diagnostics.get("bridge_version")
            if isinstance(diagnostics, dict)
            else None
        )
        if not isinstance(bridge_version, str) or not bridge_version:
            bridge_version = (
                hello.get("bridge_version") if isinstance(hello, dict) else None
            )
        game_adapter_id = (
            hello.get("game_adapter_id") if isinstance(hello, dict) else None
        )
        if (
            isinstance(connection_generation, bool)
            or not isinstance(connection_generation, int)
            or not 1 <= connection_generation <= 2**64 - 1
            or not isinstance(bridge_version, str)
            or not bridge_version
            or not isinstance(game_adapter_id, str)
            or not game_adapter_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo incident query lacks its bridge connection binding"
            )
        bridge_capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_ZHONGGUO_INCIDENT_SNAPSHOT_V1_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query received-self ZhongGuo incidents"
            )
        result = self.execute_step(step, expected_revision=expected_revision)
        expected_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "zhongguo_incident_snapshot",
            "backend_id",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            "queried_connection_generation",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_result_keys
            or result.get("step")
            != QUERY_ZHONGGUO_INCIDENT_SNAPSHOT_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "ZhongGuo incident backend returned a malformed result"
            )
        query_sequence = result.get("query_sequence")
        backend_id = result.get("backend_id")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
            or not isinstance(backend_id, str)
            or not backend_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo incident result lacks its native query identity"
            )
        try:
            normalized = normalize_native_zhongguo_incident_snapshot_v1(
                result.get("zhongguo_incident_snapshot"),
                expected_query=query,
                expected_snapshot_revision=native_revision,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"ZhongGuo incident result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "ZhongGuo incident envelope status disagrees with its frame"
            )
        if (
            result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
            or result.get("queried_connection_generation")
            != connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo incident result is bound to another snapshot"
            )
        provenance = normalized["provenance"]
        assert isinstance(provenance, dict)
        observed_version = (
            hello.get("expected_ck3_version", hello.get("game_version"))
            if isinstance(hello, dict)
            else None
        )
        observed_sha256 = (
            hello.get("expected_ck3_sha256", hello.get("executable_sha256"))
            if isinstance(hello, dict)
            else None
        )
        if (
            observed_version != provenance["game_version"]
            or not isinstance(observed_sha256, str)
            or observed_sha256.upper()
            != str(provenance["executable_sha256"]).upper()
            or provenance.get("consumer_id")
            != ZHONGGUO_INCIDENT_SNAPSHOT_V1_CONSUMER_ID
        ):
            raise BridgeUnavailableError(
                "ZhongGuo incident build mirror disagrees with bridge hello"
            )
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        current_played_character = current.get("played_character")
        current_player_character_id = (
            current_played_character.get("character_id")
            if isinstance(current_played_character, dict)
            else None
        )
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id") == snapshot.get("episode_run_id")
            and current_player_character_id == player_character_id
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation")
            == connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo incident query crossed its paused snapshot binding"
            )
        actual_owner_character_id: int | None = None
        if normalized["status"] == "available":
            probe = normalized["probe"]
            assert isinstance(probe, dict)
            owner = probe["owner_character_id"]
            assert isinstance(owner, dict)
            owner_value = owner.get("value")
            if (
                owner.get("status") != "available"
                or isinstance(owner_value, bool)
                or not isinstance(owner_value, int)
                or not 1 <= owner_value <= 2**31 - 1
            ):
                raise BridgeUnavailableError(
                    "available ZhongGuo incident lacks its owner identity"
                )
            actual_owner_character_id = owner_value
        response = {
            **normalized,
            "build": {
                "version": provenance["game_version"],
                "exe_sha256": provenance["executable_sha256"],
            },
            "source": {
                "bridge_version": bridge_version,
                "game_adapter_id": game_adapter_id,
                "backend_id": backend_id,
                "consumer_id": provenance["consumer_id"],
                "connection_generation": connection_generation,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
            },
            "binding": {
                "request_nonce": query.request_nonce,
                "profile": query.profile,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "connection_generation": connection_generation,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
                "subject_character_id": player_character_id,
                "owner_character_id": actual_owner_character_id,
                "expected_revision": expected_revision,
            },
        }
        try:
            return normalize_zhongguo_incident_snapshot_v1_response(
                response,
                expected_query=query,
                expected_snapshot_id=snapshot_id,
                expected_revision=revision,
                expected_native_revision=native_revision,
                expected_connection_generation=connection_generation,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                "ZhongGuo incident response projection is malformed: "
                f"{error}"
            ) from error

    def query_zhongguo_manager_subordinate_selector_v1(
        self,
        request_nonce: str,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Select one observed bounded AI manager and direct subordinate."""
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        snapshot = self.snapshot()
        revision = snapshot.get("revision")
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        played = snapshot.get("played_character")
        player_character_id = (
            played.get("character_id") if isinstance(played, dict) else None
        )
        if not (
            snapshot.get("paused") is True
            and snapshot.get("map_ready") is True
            and revision == expected_revision
            and not isinstance(native_revision, bool)
            and isinstance(native_revision, int)
            and 1 <= native_revision <= 2**64 - 1
            and not isinstance(date_raw, bool)
            and isinstance(date_raw, int)
            and -(2**31) <= date_raw <= 2**31 - 1
            and isinstance(snapshot_id, str)
            and bool(snapshot_id)
            and not isinstance(player_character_id, bool)
            and isinstance(player_character_id, int)
            and 1 <= player_character_id <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo manager/subordinate selector lacks its paused "
                "snapshot binding"
            )
        step = query_zhongguo_manager_subordinate_selector_v1_step(
            request_nonce
        )
        query = parse_query_zhongguo_manager_subordinate_selector_v1_step(step)
        if query is None:  # pragma: no cover - builder/parser invariant
            raise AssertionError("manager/subordinate selector builder violated v1")
        bridge_capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_ZHONGGUO_MANAGER_SUBORDINATE_SELECTOR_V1_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query the ZhongGuo "
                "manager/subordinate selector"
            )
        result = self.execute_step(step, expected_revision=expected_revision)
        selector = (
            result.get("zhongguo_manager_subordinate_selector")
            if isinstance(result, dict)
            else None
        )
        try:
            normalized = normalize_native_zhongguo_manager_subordinate_selector_v1(
                selector,
                expected_query=query,
                expected_snapshot_revision=native_revision,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                "ZhongGuo manager/subordinate selector is malformed: "
                f"{error}"
            ) from error
        if not (
            isinstance(result, dict)
            and result.get("step")
            == QUERY_ZHONGGUO_MANAGER_SUBORDINATE_SELECTOR_V1_STEP
            and result.get("accepted") is True
            and result.get("status") == normalized["status"]
            and result.get("snapshot_revision") == native_revision
            and result.get("queried_snapshot_id") == snapshot_id
            and result.get("queried_revision") == revision
            and result.get("queried_native_revision") == native_revision
        ):
            raise BridgeUnavailableError(
                "ZhongGuo manager/subordinate selector envelope crossed its "
                "snapshot binding"
            )
        current = self.snapshot()
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("played_character") == played
        ):
            raise BridgeUnavailableError(
                "ZhongGuo manager/subordinate selector crossed its paused "
                "snapshot binding"
            )
        selection = normalized.get("selection")
        return {
            **normalized,
            "manager_character_id": (
                selection.get("manager_character_id")
                if isinstance(selection, dict)
                else None
            ),
            "subordinate_character_id": (
                selection.get("subordinate_character_id")
                if isinstance(selection, dict)
                else None
            ),
            "binding": {
                "request_nonce": query.request_nonce,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
            },
            "query_sequence": result.get("query_sequence"),
            "backend_id": result.get("backend_id"),
        }

    def query_zhongguo_manager_governance_snapshot_v1(
        self,
        request_nonce: str,
        *,
        expected_revision: int,
        subject_character_id: int,
        owner_character_id: int,
    ) -> dict[str, object]:
        """Read one paused fixed-allowlist manager-governance lifecycle."""
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "ZhongGuo manager-governance queries require a paused CK3 "
                "snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or not 0 <= revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo manager-governance query lacks a valid public "
                "revision"
            )
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "ZhongGuo manager-governance revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
            or not isinstance(snapshot_id, str)
            or not snapshot_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo manager-governance query lacks a stable native "
                "snapshot binding"
            )
        played_character = snapshot.get("played_character")
        player_character_id = (
            played_character.get("character_id")
            if isinstance(played_character, dict)
            else None
        )
        if (
            isinstance(player_character_id, bool)
            or not isinstance(player_character_id, int)
            or not 1 <= player_character_id <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo manager-governance query lacks the played character "
                "identity"
            )
        step = query_zhongguo_manager_governance_snapshot_v1_step(
            subject_character_id, owner_character_id, request_nonce
        )
        query = parse_query_zhongguo_manager_governance_snapshot_v1_step(step)
        if query is None:  # pragma: no cover - builder/parser invariant
            raise AssertionError("manager-governance query builder violated v1")
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello") if isinstance(diagnostics, dict) else None
        )
        connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        bridge_version = (
            diagnostics.get("bridge_version")
            if isinstance(diagnostics, dict)
            else None
        )
        if not isinstance(bridge_version, str) or not bridge_version:
            bridge_version = (
                hello.get("bridge_version") if isinstance(hello, dict) else None
            )
        game_adapter_id = (
            hello.get("game_adapter_id") if isinstance(hello, dict) else None
        )
        if (
            isinstance(connection_generation, bool)
            or not isinstance(connection_generation, int)
            or not 1 <= connection_generation <= 2**64 - 1
            or not isinstance(bridge_version, str)
            or not bridge_version
            or not isinstance(game_adapter_id, str)
            or not game_adapter_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo manager-governance query lacks its bridge connection "
                "binding"
            )
        bridge_capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_ZHONGGUO_MANAGER_GOVERNANCE_SNAPSHOT_V1_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query ZhongGuo manager governance"
            )
        result = self.execute_step(step, expected_revision=expected_revision)
        expected_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "zhongguo_manager_governance_snapshot",
            "backend_id",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            "queried_connection_generation",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_result_keys
            or result.get("step")
            != QUERY_ZHONGGUO_MANAGER_GOVERNANCE_SNAPSHOT_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "ZhongGuo manager-governance backend returned a malformed "
                "result"
            )
        query_sequence = result.get("query_sequence")
        backend_id = result.get("backend_id")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
            or not isinstance(backend_id, str)
            or not backend_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo manager-governance result lacks its native query "
                "identity"
            )
        try:
            normalized = (
                normalize_native_zhongguo_manager_governance_snapshot_v1(
                    result.get("zhongguo_manager_governance_snapshot"),
                    expected_query=query,
                    expected_snapshot_revision=native_revision,
                    expected_date_raw=date_raw,
                    expected_player_character_id=player_character_id,
                )
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"ZhongGuo manager-governance result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "ZhongGuo manager-governance envelope status disagrees with "
                "its frame"
            )
        if (
            result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
            or result.get("queried_connection_generation")
            != connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo manager-governance result is bound to another "
                "snapshot"
            )
        provenance = normalized["provenance"]
        assert isinstance(provenance, dict)
        observed_version = (
            hello.get("expected_ck3_version", hello.get("game_version"))
            if isinstance(hello, dict)
            else None
        )
        observed_sha256 = (
            hello.get("expected_ck3_sha256", hello.get("executable_sha256"))
            if isinstance(hello, dict)
            else None
        )
        if (
            observed_version != provenance["game_version"]
            or not isinstance(observed_sha256, str)
            or observed_sha256.upper()
            != str(provenance["executable_sha256"]).upper()
            or provenance.get("consumer_id")
            != ZHONGGUO_MANAGER_GOVERNANCE_SNAPSHOT_V1_CONSUMER_ID
        ):
            raise BridgeUnavailableError(
                "ZhongGuo manager-governance build mirror disagrees with "
                "bridge hello"
            )
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        current_played_character = current.get("played_character")
        current_player_character_id = (
            current_played_character.get("character_id")
            if isinstance(current_played_character, dict)
            else None
        )
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id") == snapshot.get("episode_run_id")
            and current_player_character_id == player_character_id
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation")
            == connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo manager-governance query crossed its paused snapshot "
                "binding"
            )
        subject_binding = normalized["subject_binding"]
        assert isinstance(subject_binding, dict)
        dependency_field = subject_binding["bounded_ai_manager_dependency"]
        assert isinstance(dependency_field, dict)
        dependency = (
            dependency_field["value"]
            if dependency_field["status"] == "available"
            else None
        )
        response = {
            **normalized,
            "build": {
                "version": provenance["game_version"],
                "exe_sha256": provenance["executable_sha256"],
            },
            "source": {
                "bridge_version": bridge_version,
                "game_adapter_id": game_adapter_id,
                "backend_id": backend_id,
                "consumer_id": provenance["consumer_id"],
                "connection_generation": connection_generation,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
            },
            "binding": {
                "request_nonce": query.request_nonce,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "connection_generation": connection_generation,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
                "subject_character_id": query.subject_character_id,
                "owner_character_id": query.owner_character_id,
                "subject_binding_kind": subject_binding["kind"],
                "bounded_ai_manager_dependency": dependency,
                "expected_revision": expected_revision,
            },
        }
        try:
            return normalize_zhongguo_manager_governance_snapshot_v1_response(
                response,
                expected_query=query,
                expected_snapshot_id=snapshot_id,
                expected_revision=revision,
                expected_native_revision=native_revision,
                expected_connection_generation=connection_generation,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                "ZhongGuo manager-governance response projection is "
                f"malformed: {error}"
            ) from error

    def query_zhongguo_scoreboard_state_v1(
        self,
        request_nonce: str,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read fixed scoreboard instances and current-player frozen ACL."""
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "ZhongGuo scoreboard queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or revision != expected_revision
        ):
            raise BridgeUnavailableError(
                "ZhongGuo scoreboard revision mismatch"
            )
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
            or not isinstance(snapshot_id, str)
            or not snapshot_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo scoreboard query lacks a stable native binding"
            )
        played_character = snapshot.get("played_character")
        player_character_id = (
            played_character.get("character_id")
            if isinstance(played_character, dict)
            else None
        )
        if (
            isinstance(player_character_id, bool)
            or not isinstance(player_character_id, int)
            or not 1 <= player_character_id <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "ZhongGuo scoreboard query lacks the played character"
            )
        step = query_zhongguo_scoreboard_state_v1_step(request_nonce)
        query = parse_query_zhongguo_scoreboard_state_v1_step(step)
        if query is None:  # pragma: no cover - builder/parser invariant
            raise AssertionError("scoreboard query builder violated v1")
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello") if isinstance(diagnostics, dict) else None
        )
        connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        bridge_version = (
            diagnostics.get("bridge_version")
            if isinstance(diagnostics, dict)
            else None
        )
        if not isinstance(bridge_version, str) or not bridge_version:
            bridge_version = (
                hello.get("bridge_version")
                if isinstance(hello, dict)
                else None
            )
        game_adapter_id = (
            hello.get("game_adapter_id") if isinstance(hello, dict) else None
        )
        if (
            isinstance(connection_generation, bool)
            or not isinstance(connection_generation, int)
            or not 1 <= connection_generation <= 2**64 - 1
            or not isinstance(bridge_version, str)
            or not bridge_version
            or not isinstance(game_adapter_id, str)
            or not game_adapter_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo scoreboard query lacks its bridge binding"
            )
        bridge_capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_ZHONGGUO_SCOREBOARD_STATE_V1_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query ZhongGuo scoreboard state"
            )
        result = self.execute_step(step, expected_revision=expected_revision)
        expected_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "zhongguo_scoreboard_state",
            "backend_id",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            "queried_connection_generation",
        }
        if (
            not isinstance(result, dict)
            or set(result) != expected_result_keys
            or result.get("step")
            != QUERY_ZHONGGUO_SCOREBOARD_STATE_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "ZhongGuo scoreboard backend returned a malformed result"
            )
        query_sequence = result.get("query_sequence")
        backend_id = result.get("backend_id")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
            or not isinstance(backend_id, str)
            or not backend_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo scoreboard result lacks its native query identity"
            )
        try:
            normalized = normalize_native_zhongguo_scoreboard_state_v1(
                result.get("zhongguo_scoreboard_state"),
                expected_query=query,
                expected_snapshot_revision=native_revision,
                expected_date_raw=date_raw,
                expected_player_character_id=player_character_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"ZhongGuo scoreboard result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "ZhongGuo scoreboard envelope status disagrees with frame"
            )
        provenance = normalized["provenance"]
        assert isinstance(provenance, dict)
        observed_version = (
            hello.get("expected_ck3_version", hello.get("game_version"))
            if isinstance(hello, dict)
            else None
        )
        observed_sha256 = (
            hello.get("expected_ck3_sha256", hello.get("executable_sha256"))
            if isinstance(hello, dict)
            else None
        )
        if (
            observed_version != provenance["game_version"]
            or not isinstance(observed_sha256, str)
            or observed_sha256.upper()
            != str(provenance["executable_sha256"]).upper()
            or provenance.get("consumer_id")
            != ZHONGGUO_SCOREBOARD_STATE_V1_CONSUMER_ID
        ):
            raise BridgeUnavailableError(
                "ZhongGuo scoreboard build mirror disagrees with hello"
            )
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        current_played_character = current.get("played_character")
        current_player_character_id = (
            current_played_character.get("character_id")
            if isinstance(current_played_character, dict)
            else None
        )
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current_player_character_id == player_character_id
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation")
            == connection_generation
        ):
            raise BridgeUnavailableError(
                "ZhongGuo scoreboard query crossed its paused binding"
            )
        return {
            **normalized,
            "build": {
                "version": provenance["game_version"],
                "exe_sha256": provenance["executable_sha256"],
            },
            "source": {
                "bridge_version": bridge_version,
                "game_adapter_id": game_adapter_id,
                "backend_id": backend_id,
                "consumer_id": provenance["consumer_id"],
                "connection_generation": connection_generation,
                "query_sequence": query_sequence,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
            },
            "binding": {
                "request_nonce": query.request_nonce,
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "connection_generation": connection_generation,
                "date_raw": date_raw,
                "paused": True,
                "player_character_id": player_character_id,
                "expected_revision": expected_revision,
            },
        }

    def query_zhongguo_promotion_source_progress_v1(
        self,
        request_nonce: str,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read fixed review/B1/central/PP witnesses on a paused frame."""
        snapshot = self.snapshot()
        diagnostics = snapshot.get("diagnostics")
        played = snapshot.get("played_character")
        player_character_id = (
            played.get("character_id") if isinstance(played, dict) else None
        )
        connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        native_revision = snapshot.get("native_revision")
        if (
            snapshot.get("paused") is not True
            or snapshot.get("revision") != expected_revision
            or isinstance(player_character_id, bool)
            or not isinstance(player_character_id, int)
            or player_character_id <= 0
            or isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or native_revision <= 0
            or isinstance(connection_generation, bool)
            or not isinstance(connection_generation, int)
            or connection_generation <= 0
        ):
            raise BridgeUnavailableError(
                "promotion source progress lacks a stable paused player binding"
            )
        step = query_promotion_source_progress_v1_step(
            player_character_id, request_nonce
        )
        query = parse_query_promotion_source_progress_v1_step(step)
        if query is None:  # pragma: no cover - builder/parser invariant
            raise AssertionError("promotion source progress query builder drifted")
        capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(capabilities, list)
            and QUERY_PROMOTION_SOURCE_PROGRESS_V1_TRANSPORT_CAPABILITY
            in capabilities
        ):
            raise UnsupportedStepError(
                "selected backend lacks the fail-closed promotion source observer"
            )
        executor = getattr(
            self.driver, "query_zhongguo_promotion_source_progress_v1", None
        )
        if not callable(executor):
            raise UnsupportedStepError(
                "selected backend has no typed promotion source observer"
            )
        result = executor(query, expected_revision=expected_revision)
        if (
            not isinstance(result, dict)
            or result.get("queried_snapshot_id") != snapshot.get("snapshot_id")
            or result.get("queried_revision") != expected_revision
            or result.get("queried_native_revision") != native_revision
            or result.get("queried_connection_generation")
            != connection_generation
        ):
            raise BridgeUnavailableError(
                "promotion source progress is not bound to the requested frame"
            )
        progress = result.get("zhongguo_promotion_source_progress")
        if not isinstance(progress, dict):
            raise BridgeUnavailableError(
                "promotion source progress payload is missing"
            )
        return {
            **result,
            "binding": {
                "request_nonce": request_nonce,
                "query_sequence": result.get("query_sequence"),
                "snapshot_id": snapshot.get("snapshot_id"),
                "revision": expected_revision,
                "native_revision": native_revision,
                "connection_generation": connection_generation,
                "date_raw": snapshot.get("date_raw"),
                "paused": True,
                "player_character_id": player_character_id,
            },
        }

    def activate_zhongguo_review_now_v1(
        self,
        request_nonce: str,
        source_progress: dict[str, object],
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Dispatch exact review-now and keep success verification pending."""
        binding = source_progress.get("binding")
        progress = source_progress.get("zhongguo_promotion_source_progress")
        if not isinstance(binding, dict) or not isinstance(progress, dict):
            raise ValueError("source_progress must be a bound progress response")
        if (
            source_progress.get("status") != "available"
            or not widget_visible(progress, 1)
            or widget_visible(progress, 2)
            or widget_visible(progress, 3)
            or widget_visible(progress, 4)
        ):
            raise BridgeUnavailableError(
                "review-now product action is not presently eligible"
            )
        request = build_review_now_action_v1_request(
            request_nonce=request_nonce,
            expected_revision=binding.get("query_sequence"),
            expected_native_revision=binding.get("native_revision"),
            expected_connection_generation=binding.get("connection_generation"),
            expected_player_character_id=binding.get("player_character_id"),
        )
        snapshot = self.snapshot()
        diagnostics = snapshot.get("diagnostics")
        played = snapshot.get("played_character")
        if (
            snapshot.get("paused") is not True
            or snapshot.get("revision") != expected_revision
            or snapshot.get("snapshot_id") != binding.get("snapshot_id")
            or snapshot.get("native_revision")
            != request.expected_native_revision
            or not isinstance(diagnostics, dict)
            or diagnostics.get("connection_generation")
            != request.expected_connection_generation
            or not isinstance(played, dict)
            or played.get("character_id")
            != request.expected_player_character_id
        ):
            raise PreSubmissionRevisionMismatchError(
                "review-now action source binding is stale"
            )
        capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(capabilities, list)
            and ACTIVATE_REVIEW_NOW_V1_TRANSPORT_CAPABILITY in capabilities
        ):
            raise UnsupportedStepError(
                "selected backend lacks the fail-closed review-now transport"
            )
        executor = getattr(self.driver, "activate_zhongguo_review_now_v1", None)
        if not callable(executor):
            raise UnsupportedStepError(
                "selected backend has no typed review-now executor"
            )
        return executor(request, expected_revision=expected_revision)

    def activate_zhongguo_scoreboard_v1(
        self,
        request_nonce: str,
        action: str,
        *,
        expected_revision: int,
        expected_native_revision: int,
        expected_connection_generation: int,
        expected_player_character_id: int,
        expected_provider_session_id: str,
        expected_observation_sequence: int,
        expected_observed_state_revision: int,
        expected_tree_fingerprint_v1: str,
        expected_semantic_fingerprint_v1: str,
        expected_window_instance_pointer: str,
        expected_target_instance_pointer: str,
        expected_target_vtable_pointer: str,
    ) -> dict[str, object]:
        """Cross the typed scoreboard action transport without promotion.

        The exact dispatcher returns an ACK only. Production capability stays
        unadvertised until a paused live run proves the independent
        provider-owned observation transition and explicit postcondition.
        """

        request = build_zhongguo_scoreboard_action_v1_request(
            request_nonce=request_nonce,
            action=action,
            expected_revision=expected_revision,
            expected_native_revision=expected_native_revision,
            expected_connection_generation=expected_connection_generation,
            expected_player_character_id=expected_player_character_id,
            expected_provider_session_id=expected_provider_session_id,
            expected_observation_sequence=expected_observation_sequence,
            expected_observed_state_revision=(
                expected_observed_state_revision
            ),
            expected_tree_fingerprint_v1=expected_tree_fingerprint_v1,
            expected_semantic_fingerprint_v1=(
                expected_semantic_fingerprint_v1
            ),
            expected_window_instance_pointer=expected_window_instance_pointer,
            expected_target_instance_pointer=expected_target_instance_pointer,
            expected_target_vtable_pointer=expected_target_vtable_pointer,
        )
        snapshot = self.snapshot()
        diagnostics = snapshot.get("diagnostics")
        played_character = snapshot.get("played_character")
        actual_player_character_id = (
            played_character.get("character_id")
            if isinstance(played_character, dict)
            else None
        )
        actual_connection_generation = (
            diagnostics.get("connection_generation")
            if isinstance(diagnostics, dict)
            else None
        )
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "ZhongGuo scoreboard actions require a paused snapshot"
            )
        if not (
            snapshot.get("revision") == expected_revision
            and snapshot.get("native_revision") == expected_native_revision
            and actual_connection_generation
            == expected_connection_generation
            and actual_player_character_id == expected_player_character_id
        ):
            raise PreSubmissionRevisionMismatchError(
                "ZhongGuo scoreboard action source binding is stale"
            )
        bridge_capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and ZHONGGUO_SCOREBOARD_ACTION_V1_TRANSPORT_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend lacks the fail-closed ZhongGuo scoreboard "
                "action transport"
            )
        executor = getattr(
            self.driver, "activate_zhongguo_scoreboard_v1", None
        )
        if not callable(executor):
            raise UnsupportedStepError(
                "selected backend has no typed ZhongGuo scoreboard action "
                "executor"
            )
        result = executor(request, expected_revision=expected_revision)
        expected_result_keys = {
            "step",
            "accepted",
            "status",
            "request_nonce",
            "action",
            "action_sequence",
            "snapshot_revision",
            "rejection_reason",
            "action_ack",
            "production_capability_advertised",
            "backend_id",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            "queried_connection_generation",
        }
        if not isinstance(result, dict) or set(result) != expected_result_keys:
            raise BridgeUnavailableError(
                "ZhongGuo scoreboard action backend returned unexpected fields"
            )
        try:
            normalized = normalize_native_zhongguo_scoreboard_action_v1_result(
                {
                    key: result[key]
                    for key in (
                        "step",
                        "accepted",
                        "status",
                        "request_nonce",
                        "action",
                        "action_sequence",
                        "snapshot_revision",
                        "rejection_reason",
                        "action_ack",
                        "production_capability_advertised",
                        "backend_id",
                    )
                },
                expected_request=request,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"ZhongGuo scoreboard action result is malformed: {error}"
            ) from error
        if not (
            normalized["step"] == ACTIVATE_ZHONGGUO_SCOREBOARD_V1_STEP
            and result["queried_snapshot_id"] == snapshot.get("snapshot_id")
            and result["queried_revision"] == expected_revision
            and result["queried_native_revision"]
            == expected_native_revision
            and result["queried_connection_generation"]
            == expected_connection_generation
            and normalized["snapshot_revision"]
            == expected_native_revision
        ):
            raise BridgeUnavailableError(
                "ZhongGuo scoreboard action result crossed its source binding"
            )
        advertised_by_capability = (
            isinstance(bridge_capabilities, list)
            and ACTIVATE_ZHONGGUO_SCOREBOARD_V1_CAPABILITY
            in bridge_capabilities
        )
        if (
            normalized["production_capability_advertised"]
            is not advertised_by_capability
        ):
            raise BridgeUnavailableError(
                "ZhongGuo scoreboard production capability mirror drifted"
            )
        current = self.snapshot()
        current_diagnostics = current.get("diagnostics")
        current_played_character = current.get("played_character")
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot.get("snapshot_id")
            and current.get("revision") == expected_revision
            and current.get("native_revision") == expected_native_revision
            and isinstance(current_diagnostics, dict)
            and current_diagnostics.get("connection_generation")
            == expected_connection_generation
            and isinstance(current_played_character, dict)
            and current_played_character.get("character_id")
            == expected_player_character_id
        ):
            raise BridgeUnavailableError(
                "ZhongGuo scoreboard action crossed its paused binding"
            )
        return {
            **normalized,
            "queried_snapshot_id": result["queried_snapshot_id"],
            "queried_revision": result["queried_revision"],
            "queried_native_revision": result["queried_native_revision"],
            "queried_connection_generation": result[
                "queried_connection_generation"
            ],
        }

    def _typed_ingame_ui_v1(self, operation: str, kind: str, subject_id: int, expected_revision: int,
            *, army_tooltip_kind: str | None = None, army_tooltip_receipt: str | None = None) -> dict[str, object]:
        from .ingame_ui_contract import (QUERY_CAPABILITY, NAVIGATE_CAPABILITY, validate_ui_request,
            ingame_ui_build_binding, validate_ui_build_scope)
        validate_ui_request(operation, kind, subject_id, expected_revision,
            army_tooltip_kind=army_tooltip_kind, army_tooltip_receipt=army_tooltip_receipt)
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True or snapshot.get("map_ready") is not True:
            raise BridgeUnavailableError("typed UI requires a paused map-ready snapshot")
        if snapshot.get("revision") != expected_revision:
            raise PreSubmissionRevisionMismatchError("typed UI public revision differs")
        capability = QUERY_CAPABILITY if operation == "query" else NAVIGATE_CAPABILITY
        capabilities = self.capabilities()
        if capability not in capabilities.get("bridge_capabilities", []):
            raise UnsupportedStepError("capability_not_available: typed UI has no desktop fallback")
        if army_tooltip_kind is not None:
            if capabilities.get("backend_id") != "native-headless":
                raise UnsupportedStepError("capability_not_available: Army tooltip requires the exact native backend")
            validate_ui_build_scope(ingame_ui_build_binding(snapshot)[0], operation, kind,
                army_tooltip_kind=army_tooltip_kind)
            method_name = {"hover_army_tooltip": "hover_army_tooltip_v1",
                "leave_army_tooltip": "leave_army_tooltip_v1", "query": "query_army_tooltip_v1"}[operation]
            method = getattr(self.driver, method_name, None)
            if not callable(method):
                raise UnsupportedStepError("selected backend lacks this typed UI method")
            if operation == "hover_army_tooltip":
                return method(subject_id, army_tooltip_kind, expected_revision=expected_revision)
            return method(subject_id, army_tooltip_kind, army_tooltip_receipt, expected_revision=expected_revision)
        method_name = {"query": "query_ingame_ui_window_v1", "open_character": "open_character_window_v1",
            "select_army": "select_army_ui_v1", "open_combat": "open_combat_window_v1", "open_knights": "open_knights_window_v1",
            "hover_left_knights":"hover_combat_knights_v1", "hover_right_knights":"hover_combat_knights_v1",
            "fit_combat_window":"fit_combat_window_v1"}[operation]
        method = getattr(self.driver, method_name, None)
        if not callable(method):
            raise UnsupportedStepError("selected backend lacks this typed UI method")
        if operation == "open_knights":
            return method(expected_revision=expected_revision)
        if operation in {"hover_left_knights", "hover_right_knights"}:
            return method(subject_id, ui_side=operation.split("_")[1], expected_revision=expected_revision)
        return method(kind if operation == "query" else subject_id, expected_revision=expected_revision)

    def open_character_window_v1(self, character_id: int, *, expected_revision: int) -> dict[str, object]:
        return self._typed_ingame_ui_v1("open_character", "character", character_id, expected_revision)

    def select_army_ui_v1(self, subject_army_id: int, *, expected_revision: int) -> dict[str, object]:
        return self._typed_ingame_ui_v1("select_army", "army", subject_army_id, expected_revision)

    def hover_army_tooltip_v1(self, subject_army_id: int, tooltip_kind: str, *, expected_revision: int) -> dict[str, object]:
        return self._typed_ingame_ui_v1("hover_army_tooltip", "army", subject_army_id, expected_revision,
            army_tooltip_kind=tooltip_kind)

    def leave_army_tooltip_v1(self, subject_army_id: int, tooltip_kind: str, action_receipt: str, *, expected_revision: int) -> dict[str, object]:
        return self._typed_ingame_ui_v1("leave_army_tooltip", "army", subject_army_id, expected_revision,
            army_tooltip_kind=tooltip_kind, army_tooltip_receipt=action_receipt)

    def query_army_tooltip_v1(self, subject_army_id: int, tooltip_kind: str, action_receipt: str, *, expected_revision: int) -> dict[str, object]:
        return self._typed_ingame_ui_v1("query", "army", subject_army_id, expected_revision,
            army_tooltip_kind=tooltip_kind, army_tooltip_receipt=action_receipt)

    def open_combat_window_v1(self, combat_id: int, *, expected_revision: int) -> dict[str, object]:
        return self._typed_ingame_ui_v1("open_combat", "combat", combat_id, expected_revision)

    def fit_combat_window_v1(self, combat_id: int, *, expected_revision: int) -> dict[str, object]:
        return self._typed_ingame_ui_v1("fit_combat_window", "combat", combat_id, expected_revision)

    def open_knights_window_v1(self, *, expected_revision: int) -> dict[str, object]:
        return self._typed_ingame_ui_v1("open_knights", "knights", 0, expected_revision)

    def query_ingame_ui_window_v1(self, window_kind: str, *, expected_revision: int) -> dict[str, object]:
        return self._typed_ingame_ui_v1("query", window_kind, 0, expected_revision)

    def hover_combat_knights_v1(self, combat_id: int, ui_side: str, *, expected_revision: int) -> dict[str, object]:
        if ui_side not in {"left", "right"}:
            raise ValueError("ui_side must be left or right in the original CombatWindow")
        return self._typed_ingame_ui_v1(f"hover_{ui_side}_knights", "combat", combat_id, expected_revision)

    def center_map_on_landed_title_v1(
        self,
        title_key: str,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Center the native map without exposing the step to the planner."""
        key = validate_landed_title_key(title_key)
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or expected_revision < 0
            or expected_revision > 2**64 - 1
        ):
            raise ValueError(
                "expected_revision must be a non-negative uint64"
            )
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        typed_command = getattr(
            self.driver, "center_map_on_landed_title_v1", None
        )
        if not (
            isinstance(bridge_capabilities, list)
            and CENTER_MAP_ON_LANDED_TITLE_V1_CAPABILITY
            in bridge_capabilities
            and callable(typed_command)
        ):
            raise UnsupportedStepError(
                "capability_not_available: selected backend cannot center "
                "the map on a landed title"
            )
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "title-map navigation requires a paused CK3 snapshot"
            )
        if snapshot.get("map_ready") is not True:
            raise BridgeUnavailableError(
                "title-map navigation requires a map-ready CK3 snapshot"
            )
        try:
            binding = _title_map_navigation_binding(snapshot)
        except ValueError as error:
            raise BridgeUnavailableError(
                f"title-map navigation lacks a complete binding: {error}"
            ) from error
        if binding["revision"] != expected_revision:
            raise BridgeUnavailableError(
                "title-map navigation revision mismatch: expected "
                f"{expected_revision}, current {binding['revision']}"
            )
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello")
            if isinstance(diagnostics, dict)
            else None
        )
        observed_version = (
            hello.get("expected_ck3_version", hello.get("game_version"))
            if isinstance(hello, dict)
            else None
        )
        observed_sha256 = (
            hello.get(
                "expected_ck3_sha256", hello.get("executable_sha256")
            )
            if isinstance(hello, dict)
            else None
        )
        try:
            source_build = require_exact_native_build(
                observed_version, observed_sha256
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                "title-map navigation build mirror disagrees with bridge hello"
            ) from error
        result = typed_command(key, expected_revision=expected_revision)
        try:
            normalized = normalize_title_map_navigation_v1_result(
                result,
                expected_title_key=key,
                expected_binding=binding,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"title-map navigation result is malformed: {error}"
            ) from error
        result_source = normalized["source"]
        if (
            result_source["game_version"] != source_build.game_version
            or result_source["executable_sha256"]
            != source_build.executable_sha256
        ):
            raise BridgeUnavailableError(
                "title-map navigation build mirror disagrees with bridge hello"
            )
        current = self.snapshot()
        try:
            current_binding = _title_map_navigation_binding(current)
        except ValueError as error:
            raise BridgeUnavailableError(
                f"title-map navigation lost its session binding: {error}"
            ) from error
        if not (
            current.get("paused") is True
            and current.get("map_ready") is True
            and current_binding == binding
            and current.get("played_character")
            == snapshot.get("played_character")
        ):
            raise BridgeUnavailableError(
                "title-map navigation crossed its paused session binding"
            )
        return normalized

    def set_player_character_v1(
        self,
        character_id: int,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Explicitly rebind the local player through the pure-native MCP."""
        target = validate_character_id(character_id)
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or expected_revision < 0
            or expected_revision > 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        typed_command = getattr(self.driver, "set_player_character_v1", None)
        if not (
            isinstance(bridge_capabilities, list)
            and SET_PLAYED_CHARACTER_V1_CAPABILITY in bridge_capabilities
            and callable(typed_command)
        ):
            raise UnsupportedStepError(
                "capability_not_available: selected backend cannot rebind "
                "the played character"
            )
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True or snapshot.get("map_ready") is not True:
            raise BridgeUnavailableError(
                "played-character rebind requires a paused map-ready snapshot"
            )
        if snapshot.get("revision") != expected_revision:
            raise PreSubmissionRevisionMismatchError(
                "played-character rebind revision mismatch: expected "
                f"{expected_revision}, current {snapshot.get('revision')}"
            )
        result = typed_command(target, expected_revision=expected_revision)
        if not (
            isinstance(result, dict)
            and result.get("accepted") is True
            and result.get("status") in {"switched", "already_played"}
            and result.get("to_character_id") == target
            and result.get("postcondition_verified") is True
        ):
            raise BridgeUnavailableError(
                "played-character rebind returned a malformed postcondition"
            )
        return copy.deepcopy(result)

    def _coat_of_arms_source_binding_for_revision(
        self,
        expected_revision: int,
        *,
        capabilities: dict[str, object] | None = None,
    ) -> dict[str, object]:
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        if expected_revision == 0:
            try:
                return coat_of_arms_source_frontend_binding_from_capabilities(
                    capabilities or self.capabilities()
                )
            except ValueError as error:
                raise BridgeUnavailableError(
                    "frontend coat-of-arms operation lacks an exact native "
                    f"binding: {error}"
                ) from error
        snapshot = self.snapshot()
        try:
            binding = _coat_of_arms_source_probe_binding(snapshot)
        except ValueError as error:
            raise BridgeUnavailableError(
                "coat-of-arms operation lacks a complete binding: "
                f"{error}"
            ) from error
        if binding["revision"] != expected_revision:
            raise PreSubmissionRevisionMismatchError(
                "coat-of-arms operation revision mismatch: expected "
                f"{expected_revision}, current {binding['revision']}"
            )
        return binding

    def begin_coat_of_arms_source_upload_v2(
        self,
        *,
        total_bytes: int,
        source_sha256: str,
        chunk_count: int,
        chunk_encoding: str,
        expected_revision: int,
        apply: bool,
        expected_game_version: str,
        expected_executable_sha256: str,
    ) -> dict[str, object]:
        """Reserve one bounded, exact-build large-source upload session."""

        if expected_game_version != COAT_OF_ARMS_SOURCE_V1_GAME_VERSION:
            raise ValueError("expected_game_version is not the supported build")
        if (
            not isinstance(expected_executable_sha256, str)
            or expected_executable_sha256.upper()
            != COAT_OF_ARMS_SOURCE_V1_EXECUTABLE_SHA256
        ):
            raise ValueError(
                "expected_executable_sha256 is not the supported build"
            )
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        typed_probe = getattr(
            self.driver, "probe_coat_of_arms_source_transport_v2", None
        )
        if not (
            isinstance(bridge_capabilities, list)
            and PROBE_COAT_OF_ARMS_SOURCE_V1_CAPABILITY
            in bridge_capabilities
            and callable(typed_probe)
        ):
            raise UnsupportedStepError(
                "capability_not_available: selected backend cannot accept "
                "assembled coat-of-arms source uploads"
            )
        binding = self._coat_of_arms_source_binding_for_revision(
            expected_revision,
            capabilities=capabilities,
        )
        return self._coat_of_arms_source_uploads_v2.begin(
            total_bytes=total_bytes,
            source_sha256=source_sha256,
            chunk_count=chunk_count,
            chunk_encoding=chunk_encoding,
            expected_revision=expected_revision,
            apply=apply,
            expected_game_version=expected_game_version,
            expected_executable_sha256=expected_executable_sha256,
            binding=binding,
        )

    def append_coat_of_arms_source_chunk_v2(
        self,
        *,
        upload_id: str,
        generation: int,
        chunk_index: int,
        chunk_count: int,
        chunk_encoding: str,
        chunk_bytes: int,
        chunk_sha256: str,
        chunk_base64: str,
        source_sha256: str,
        expected_revision: int,
        apply: bool,
        expected_game_version: str,
        expected_executable_sha256: str,
    ) -> dict[str, object]:
        """Append one strictly ordered and independently hashed source chunk."""

        return self._coat_of_arms_source_uploads_v2.append(
            upload_id=upload_id,
            generation=generation,
            chunk_index=chunk_index,
            chunk_count=chunk_count,
            chunk_encoding=chunk_encoding,
            chunk_bytes=chunk_bytes,
            chunk_sha256=chunk_sha256,
            chunk_base64=chunk_base64,
            source_sha256=source_sha256,
            expected_revision=expected_revision,
            apply=apply,
            expected_game_version=expected_game_version,
            expected_executable_sha256=expected_executable_sha256,
        )

    def commit_coat_of_arms_source_upload_v2(
        self,
        *,
        upload_id: str,
        generation: int,
        chunk_count: int,
        source_sha256: str,
        expected_revision: int,
        apply: bool,
        expected_game_version: str,
        expected_executable_sha256: str,
    ) -> dict[str, object]:
        """Validate the complete upload, then perform exactly one native call."""

        source, upload, binding = (
            self._coat_of_arms_source_uploads_v2.finalize(
                upload_id=upload_id,
                generation=generation,
                chunk_count=chunk_count,
                source_sha256=source_sha256,
                expected_revision=expected_revision,
                apply=apply,
                expected_game_version=expected_game_version,
                expected_executable_sha256=expected_executable_sha256,
            )
        )
        current_binding = self._coat_of_arms_source_binding_for_revision(
            expected_revision
        )
        if current_binding != binding:
            raise BridgeUnavailableError(
                "coat-of-arms upload crossed its revision binding"
            )
        typed_probe = getattr(
            self.driver, "probe_coat_of_arms_source_transport_v2", None
        )
        if not callable(typed_probe):
            raise UnsupportedStepError(
                "capability_not_available: assembled coat-of-arms source "
                "transport disappeared"
            )
        encoded = encode_coat_of_arms_source_transport_v2(source)
        result = typed_probe(
            encoded.source,
            expected_revision=expected_revision,
            apply=apply,
        )
        try:
            normalized = normalize_coat_of_arms_source_v1_result(
                result,
                expected_source=encoded,
                expected_binding=binding,
                expected_apply=apply,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                "assembled coat-of-arms source result is malformed: "
                f"{error}"
            ) from error
        if (
            self._coat_of_arms_source_binding_for_revision(expected_revision)
            != binding
        ):
            raise BridgeUnavailableError(
                "coat-of-arms upload crossed its revision binding during apply"
            )
        return {
            "schema": "coat-of-arms-source-upload-commit-v2",
            "schema_version": 2,
            "status": "committed",
            "upload": upload,
            "result": normalized,
        }

    def abort_coat_of_arms_source_upload_v2(
        self,
        *,
        upload_id: str,
        generation: int,
    ) -> dict[str, object]:
        """Destroy one upload without invoking CK3."""

        return self._coat_of_arms_source_uploads_v2.abort(
            upload_id=upload_id,
            generation=generation,
        )

    def probe_coat_of_arms_source_v1(
        self,
        source: str,
        *,
        expected_revision: int,
        apply: bool,
    ) -> dict[str, object]:
        """Probe source through CK3's typed engine path without planner use."""

        encoded = encode_coat_of_arms_source_v1(source)
        apply = validate_coat_of_arms_source_probe_apply(apply)
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        typed_probe = getattr(
            self.driver, "probe_coat_of_arms_source_v1", None
        )
        if not (
            isinstance(bridge_capabilities, list)
            and PROBE_COAT_OF_ARMS_SOURCE_V1_CAPABILITY
            in bridge_capabilities
            and callable(typed_probe)
        ):
            raise UnsupportedStepError(
                "capability_not_available: selected backend cannot probe "
                "coat-of-arms source"
            )
        frontend = expected_revision == 0
        if frontend:
            try:
                binding = (
                    coat_of_arms_source_frontend_binding_from_capabilities(
                        capabilities
                    )
                )
            except ValueError as error:
                raise BridgeUnavailableError(
                    "frontend coat-of-arms probe lacks an exact native "
                    f"binding: {error}"
                ) from error
        else:
            snapshot = self.snapshot()
            try:
                binding = _coat_of_arms_source_probe_binding(snapshot)
            except ValueError as error:
                raise BridgeUnavailableError(
                    f"coat-of-arms probe lacks a complete binding: {error}"
                ) from error
            if binding["revision"] != expected_revision:
                raise PreSubmissionRevisionMismatchError(
                    "coat-of-arms probe revision mismatch: expected "
                    f"{expected_revision}, current {binding['revision']}"
                )
        result = typed_probe(
            encoded.source,
            expected_revision=expected_revision,
            apply=apply,
        )
        try:
            normalized = normalize_coat_of_arms_source_v1_result(
                result,
                expected_source=encoded,
                expected_binding=binding,
                expected_apply=apply,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"coat-of-arms probe result is malformed: {error}"
            ) from error
        try:
            current_binding = (
                coat_of_arms_source_frontend_binding_from_capabilities(
                    self.capabilities()
                )
                if frontend
                else _coat_of_arms_source_probe_binding(self.snapshot())
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"coat-of-arms probe lost its session binding: {error}"
            ) from error
        if current_binding != binding:
            raise BridgeUnavailableError(
                "coat-of-arms probe crossed its revision binding"
            )
        return normalized

    def export_coat_of_arms_source_v1(
        self,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Export current designer source through CK3's typed Copy path."""

        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 0 <= expected_revision <= 2**64 - 1
        ):
            raise ValueError("expected_revision must be a non-negative uint64")
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        typed_export = getattr(
            self.driver, "export_coat_of_arms_source_v1", None
        )
        if not (
            isinstance(bridge_capabilities, list)
            and EXPORT_COAT_OF_ARMS_SOURCE_V1_CAPABILITY
            in bridge_capabilities
            and callable(typed_export)
        ):
            raise UnsupportedStepError(
                "capability_not_available: selected backend cannot export "
                "coat-of-arms source"
            )
        frontend = expected_revision == 0
        if frontend:
            try:
                binding = coat_of_arms_source_frontend_binding_from_capabilities(
                    capabilities
                )
            except ValueError as error:
                raise BridgeUnavailableError(
                    "frontend coat-of-arms export lacks an exact native "
                    f"binding: {error}"
                ) from error
        else:
            snapshot = self.snapshot()
            try:
                binding = _coat_of_arms_source_probe_binding(snapshot)
            except ValueError as error:
                raise BridgeUnavailableError(
                    f"coat-of-arms export lacks a complete binding: {error}"
                ) from error
            if binding["revision"] != expected_revision:
                raise PreSubmissionRevisionMismatchError(
                    "coat-of-arms export revision mismatch: expected "
                    f"{expected_revision}, current {binding['revision']}"
                )
        result = typed_export(expected_revision=expected_revision)
        try:
            normalized = normalize_coat_of_arms_source_export_v1_result(
                result,
                expected_binding=binding,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"coat-of-arms export result is malformed: {error}"
            ) from error
        try:
            current_binding = (
                coat_of_arms_source_frontend_binding_from_capabilities(
                    self.capabilities()
                )
                if frontend
                else _coat_of_arms_source_probe_binding(self.snapshot())
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"coat-of-arms export lost its session binding: {error}"
            ) from error
        if current_binding != binding:
            raise BridgeUnavailableError(
                "coat-of-arms export crossed its revision binding"
            )
        return normalized

    def query_loaded_feature_manifest_v1(
        self,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read exact-build effective flags and script DLC keys while paused."""
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "loaded-feature queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or revision < 0
        ):
            raise BridgeUnavailableError(
                "loaded-feature query lacks a valid snapshot revision"
            )
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or expected_revision < 0
        ):
            raise ValueError(
                "expected_revision must be a non-negative integer"
            )
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "loaded-feature revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "loaded-feature query lacks a positive native revision"
            )
        date_raw = snapshot.get("date_raw")
        if (
            isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "loaded-feature query lacks a signed int32 date"
            )
        snapshot_id = snapshot.get("snapshot_id")
        if not isinstance(snapshot_id, str) or not snapshot_id:
            raise BridgeUnavailableError(
                "loaded-feature query lacks a snapshot identity"
            )
        snapshot_backend_id = snapshot.get("backend_id")
        if not isinstance(snapshot_backend_id, str) or not snapshot_backend_id:
            raise BridgeUnavailableError(
                "loaded-feature query lacks a source backend identity"
            )
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_LOADED_FEATURE_MANIFEST_V1_CAPABILITY
            in bridge_capabilities
            and QUERY_LOADED_FEATURE_MANIFEST_V1_STEP
            in action_step_set(capabilities)
        ):
            raise UnsupportedStepError(
                "selected backend cannot query the loaded feature manifest"
            )
        result = self.execute_step(
            QUERY_LOADED_FEATURE_MANIFEST_V1_STEP,
            expected_revision=expected_revision,
        )
        mirror_keys = {
            "schema",
            "schema_version",
            "date_raw",
            "unavailable_reason",
            "build",
            "effective_feature_flags",
            "script_dlc_keys",
            "entitlements",
            "readiness",
            "provenance",
        }
        required_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "loaded_feature_manifest",
            "backend_id",
            "loaded_feature_manifest_ready",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            *mirror_keys,
        }
        if (
            not isinstance(result, dict)
            or set(result) != required_result_keys
            or result.get("step") != QUERY_LOADED_FEATURE_MANIFEST_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "loaded-feature backend returned a malformed result"
            )
        query_sequence = result.get("query_sequence")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "loaded-feature result lacks query_sequence"
            )
        backend_id = result.get("backend_id")
        if not isinstance(backend_id, str) or not backend_id:
            raise BridgeUnavailableError(
                "loaded-feature result lacks backend_id"
            )
        try:
            normalized = normalize_loaded_feature_manifest_v1(
                result.get("loaded_feature_manifest"),
                expected_date_raw=date_raw,
                expected_snapshot_revision=native_revision,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"loaded-feature result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "loaded-feature envelope status disagrees with its frame"
            )
        expected_mirrors = {
            key: copy.deepcopy(normalized[key]) for key in mirror_keys
        }
        if any(
            result.get(key) != expected
            for key, expected in expected_mirrors.items()
        ) or result.get("loaded_feature_manifest_ready") is not normalized[
            "readiness"
        ]["actionable_ready"]:
            raise BridgeUnavailableError(
                "loaded-feature result mirrors disagree with its frame"
            )
        if (
            result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "loaded-feature result is bound to another snapshot"
            )
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello")
            if isinstance(diagnostics, dict)
            else None
        )
        build = normalized["build"]
        assert isinstance(build, dict)
        observed_version = (
            hello.get("expected_ck3_version", hello.get("game_version"))
            if isinstance(hello, dict)
            else None
        )
        observed_sha256 = (
            hello.get(
                "expected_ck3_sha256", hello.get("executable_sha256")
            )
            if isinstance(hello, dict)
            else None
        )
        if (
            observed_version != build["version"]
            or not isinstance(observed_sha256, str)
            or observed_sha256.upper()
            != str(build["exe_sha256"]).upper()
        ):
            raise BridgeUnavailableError(
                "loaded-feature build mirror disagrees with bridge hello"
            )
        current = self.snapshot()
        if not (
            current.get("paused") is True
            and current.get("revision") == revision
            and current.get("snapshot_id") == snapshot_id
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id")
            == snapshot.get("episode_run_id")
        ):
            raise BridgeUnavailableError(
                "loaded-feature query crossed a snapshot revision"
            )
        source = {
            "game_version": observed_version,
            "executable_sha256": observed_sha256.upper(),
            "snapshot_id": snapshot_id,
            "revision": revision,
            "native_revision": native_revision,
            "date_raw": date_raw,
            "paused": True,
            "backend_id": snapshot_backend_id,
        }
        binding = {
            "snapshot_id": snapshot_id,
            "revision": revision,
            "native_revision": native_revision,
            "date_raw": date_raw,
            "expected_revision": expected_revision,
        }
        return {
            **result,
            "schema_version": 1,
            "status": normalized["status"],
            "scope": "exact-loaded-feature-manifest",
            "source": source,
            "binding": binding,
            **expected_mirrors,
            "loaded_feature_manifest_ready": normalized["readiness"][
                "actionable_ready"
            ],
            "loaded_feature_manifest": normalized,
        }

    def query_frontend_applied_game_rules_v1(self) -> dict[str, object]:
        method = getattr(self.driver, "query_frontend_applied_game_rules_v1", None)
        if not callable(method):
            raise UnsupportedStepError("selected backend has no native actual-rule-instance observer")
        try:
            return normalize_frontend_applied_game_rules_v1(method())
        except ValueError as error:
            raise BridgeUnavailableError(f"native applied rules are malformed: {error}") from error

    def query_frontend_game_rules_window_v1(self) -> dict[str, object]:
        method = getattr(self.driver, "query_frontend_game_rules_window_v1", None)
        if not callable(method):
            raise BridgeUnavailableError("native game rules window query is unavailable")
        try:
            return normalize_frontend_game_rules_window_v1(method())
        except ValueError as error:
            raise BridgeUnavailableError(f"native game rules window is malformed: {error}") from error

    def select_frontend_game_rule_v1(self, rule_key: str,
            expected_current_setting_key: str, desired_setting_key: str) -> dict[str, object]:
        method = getattr(self.driver, "select_frontend_game_rule_v1", None)
        if not callable(method):
            raise BridgeUnavailableError("native game rule selection is unavailable")
        rule_key = require_game_rule_script_key(rule_key)
        expected_current_setting_key = require_game_rule_script_key(expected_current_setting_key)
        desired_setting_key = require_game_rule_script_key(desired_setting_key)
        result = method(rule_key, expected_current_setting_key, desired_setting_key)
        if not isinstance(result, dict) or result.get("status") != "observed" or result.get("applied_settings_proven") is not False:
            raise BridgeUnavailableError("native rule selection lacks an observed result")
        try:
            ack = normalize_frontend_game_rules_mutation_v1(result.get("acknowledgement"), "select")
            before = normalize_frontend_game_rule_selections_v1(result.get("before"))
            after = normalize_frontend_game_rule_selections_v1(result.get("observation"))
        except ValueError as error:
            raise BridgeUnavailableError(f"native rule selection is malformed: {error}") from error
        before_values = {p["rule_key"]: p["selected_setting_key"] for p in before["selections"]}
        after_values = {p["rule_key"]: p["selected_setting_key"] for p in after["selections"]}
        if not ack["ready"] or not before["ready"] or not after["ready"] or before_values.get(rule_key) != expected_current_setting_key or after_values != {**before_values, rule_key: desired_setting_key} or before.get("binding") != after.get("binding"):
            raise BridgeUnavailableError("native rule selection target or binding was not observed")
        return {**result, "acknowledgement": ack, "before": before, "observation": after}

    def apply_and_hide_frontend_game_rules_v1(self) -> dict[str, object]:
        method = getattr(self.driver, "apply_and_hide_frontend_game_rules_v1", None)
        if not callable(method):
            raise BridgeUnavailableError("native game rules apply is unavailable")
        return self._validate_frontend_game_rules_closure_v1(method(), "apply_and_hide")

    def hide_frontend_game_rules_v1(self) -> dict[str, object]:
        method = getattr(self.driver, "hide_frontend_game_rules_v1", None)
        if not callable(method):
            raise BridgeUnavailableError("native game rules hide is unavailable")
        return self._validate_frontend_game_rules_closure_v1(method(), "hide")

    def _validate_frontend_game_rules_closure_v1(self, result: object,
            action: str) -> dict[str, object]:
        if not isinstance(result, dict) or result.get("status") != "observed" or result.get("window_closed_proven") is not True or result.get("applied_settings_proven") is not False:
            raise BridgeUnavailableError("native rules closure lacks an observed result")
        try:
            ack = normalize_frontend_game_rules_mutation_v1(result.get("acknowledgement"), action)
            before = normalize_frontend_game_rule_selections_v1(result.get("before"))
            window = normalize_frontend_game_rules_window_v1(result.get("window_observation"))
        except ValueError as error:
            raise BridgeUnavailableError(f"native rules closure is malformed: {error}") from error
        if not ack["ready"] or not before["ready"] or not window["ready"] or not window["window_closed_proven"] or before.get("binding") != window.get("binding"):
            raise BridgeUnavailableError("native rules closure or binding was not independently observed")
        return {**result, "acknowledgement": ack, "before": before, "window_observation": window}

    def query_frontend_game_rule_selections_v1(self) -> dict[str, object]:
        query = getattr(self.driver, "query_frontend_game_rule_selections_v1", None)
        if not callable(query):
            raise UnsupportedStepError("selected backend has no native game rules observer")
        try:
            return normalize_frontend_game_rule_selections_v1(query())
        except ValueError as error:
            raise BridgeUnavailableError(f"native game rules observation is malformed: {error}") from error

    def activate_frontend_game_rules_v1(self) -> dict[str, object]:
        activate = getattr(self.driver, "activate_frontend_game_rules_v1", None)
        if not callable(activate):
            raise UnsupportedStepError("selected backend has no native game rules opener")
        result = activate()
        if not isinstance(result, dict) or result.get("status") != "observed":
            raise BridgeUnavailableError("native game rules opener was not observed")
        try:
            observed = normalize_frontend_game_rule_selections_v1(result.get("observation"))
        except ValueError as error:
            raise BridgeUnavailableError(f"native game rules opener observation is malformed: {error}") from error
        if observed["ready"] is not True:
            raise BridgeUnavailableError("native game rules opener returned unavailable selections")
        return {**result, "observation": observed}

    def query_frontend_gui_route_v1(self) -> dict[str, object]:
        """Read CK3's current frontend page through the native GUI tree."""

        query = getattr(self.driver, "query_frontend_gui_route_v1", None)
        if not callable(query):
            raise UnsupportedStepError(
                "selected backend has no native frontend GUI route observer"
            )
        result = query()
        if (
            not isinstance(result, dict)
            or result.get("schema") != "ck3-frontend-gui-route-v1"
            or result.get("schema_version") != 1
        ):
            raise BridgeUnavailableError(
                "native frontend GUI route observer returned malformed data"
            )
        return result

    def select_ingame_decision_item_v1(self, decision_key: str, *, expected_revision: int | None = None) -> dict[str, object]:
        method = getattr(self.driver, "select_ingame_decision_item_v1", None)
        if not callable(method):
            raise UnsupportedStepError("selected backend lacks the typed actual-row OnSelect")
        result = method(decision_key, expected_revision=expected_revision)
        if not isinstance(result, dict) or result.get("schema") != "ck3-ingame-decision-item-action-v1" or result.get("postcondition_verified") is not True or result.get("action") != "select":
            raise BridgeUnavailableError("typed OnSelect lacks later actual selected detail proof")
        return result

    def confirm_ingame_decision_item_v1(self, decision_key: str, expected_window_kind: str, *, expected_revision: int | None = None) -> dict[str, object]:
        method = getattr(self.driver, "confirm_ingame_decision_item_v1", None)
        if not callable(method):
            raise UnsupportedStepError("selected backend lacks the typed fixed detail Confirm")
        result = method(decision_key, expected_window_kind, expected_revision=expected_revision)
        if not isinstance(result, dict) or result.get("schema") != "ck3-ingame-decision-item-action-v1" or result.get("postcondition_verified") is not True or result.get("action") != "confirm":
            raise BridgeUnavailableError("typed Confirm lacks later actual inner modal proof")
        return result

    def query_aub_business_state_v1(self, *, expected_revision: int | None = None) -> dict[str, object]:
        return self.driver.query_aub_business_state_v1(expected_revision=expected_revision)

    def confirm_aub_policy_v1(self, expected_selected_key: str, *, expected_revision: int | None = None) -> dict[str, object]:
        return self.driver.confirm_aub_policy_v1(expected_selected_key,expected_revision=expected_revision)

    def query_aub_policy_options_v1(self, *, expected_revision: int | None = None) -> dict[str, object]:
        method=getattr(self.driver,"query_aub_policy_options_v1",None)
        if not callable(method):raise UnsupportedStepError("selected backend lacks exact .3 AUB policies")
        result=method(expected_revision=expected_revision)
        if not isinstance(result,dict) or result.get("schema")!="ck3-aub-policy-options-v1" or result.get("read_only") is not True or result.get("full_product_acceptance_credit") is not False:
            raise BridgeUnavailableError("AUB policy backend returned malformed or product-credit data")
        return result

    def select_aub_policy_option_v1(self, expected_selected_key: str, desired_key: str, *, expected_revision: int | None = None) -> dict[str, object]:
        from .aub_policy_options_contract import validate_policy_key
        validate_policy_key(expected_selected_key);validate_policy_key(desired_key)
        method=getattr(self.driver,"select_aub_policy_option_v1",None)
        if not callable(method):raise UnsupportedStepError("selected backend lacks exact .3 AUB source selection")
        result=method(expected_selected_key,desired_key,expected_revision=expected_revision)
        if (not isinstance(result,dict) or result.get("schema")!="ck3-aub-policy-options-v1" or result.get("read_only") is not False
                or result.get("postcondition_verified") is not True or not isinstance(result.get("later_actual_observation"),dict)
                or result["later_actual_observation"].get("policy",{}).get("selected_key")!=desired_key
                or result.get("production_confirmed") is not False or result.get("full_product_acceptance_credit") is not False):
            raise BridgeUnavailableError("AUB selection backend lacks independent actual selected-state proof")
        return result

    def click_white_numeric_control_v1(self, control: str, expected_before_value: int, expected_before_price_text: str, intent_id: str, *, expected_revision: int | None = None) -> dict[str, object]:
        from .white_numeric_control_action_contract import validate_numeric_action
        validate_numeric_action(control, expected_before_value, expected_before_price_text, intent_id)
        method = getattr(self.driver, "click_white_numeric_control_v1", None)
        if not callable(method):
            raise UnsupportedStepError("selected backend lacks fixed six White skill+1 controls")
        result = method(control, expected_before_value, expected_before_price_text, intent_id, expected_revision=expected_revision)
        if (not isinstance(result, dict) or result.get("control") != control or result.get("intent_id") != intent_id
                or result.get("postcondition_verified") is not True
                or result.get("independent_business_after_verified") is not True
                or result.get("independent_rendered_text_after_verified") is not True
                or result.get("actual_price_before_after_bound") is not True
                or result.get("price_formula_verified") is not False
                or result.get("selected_down_available") is not False or result.get("full_gui_acceptance_credit") is not False):
            raise BridgeUnavailableError("White skill action lacks actual business/text/price-bound after proof")
        return result

    def click_white_control_v1(self, control: str, expected_before_age: int, intent_id: str, *, expected_revision: int | None = None) -> dict[str, object]:
        """One fixed actual White callback with independent actual rendered/business after."""
        from .white_control_action_contract import SCHEMA, STEP, validate_action
        validate_action(control, expected_before_age, intent_id)
        method = getattr(self.driver, "click_white_control_v1", None)
        if not callable(method):
            raise UnsupportedStepError("selected backend lacks fixed White age+1 action")
        result = method(control, expected_before_age, intent_id, expected_revision=expected_revision)
        if (not isinstance(result, dict) or result.get("schema") != SCHEMA or result.get("step") != STEP
                or result.get("control") != control or result.get("intent_id") != intent_id
                or result.get("postcondition_verified") is not True
                or result.get("independent_business_after_verified") is not True
                or result.get("independent_rendered_text_after_verified") is not True
                or result.get("selected_down_available") is not False
                or result.get("full_gui_acceptance_credit") is not False):
            raise BridgeUnavailableError("White action lacks separate actual business/text after proof")
        return result

    def query_white_rendered_text_v1(self, *, expected_revision: int | None = None) -> dict[str, object]:
        """Read nine actual fixed visible TextBox values; no selected/down credit."""
        from .white_rendered_text_contract import SCHEMA, STEP
        method = getattr(self.driver, "query_white_rendered_text_v1", None)
        if not callable(method):
            raise UnsupportedStepError("selected backend lacks fixed actual White text query")
        result = method(expected_revision=expected_revision)
        if (not isinstance(result, dict) or result.get("schema") != SCHEMA or result.get("step") != STEP
                or result.get("read_only") is not True or result.get("selected_down_available") is not False
                or result.get("full_gui_acceptance_credit") is not False):
            raise BridgeUnavailableError("White text backend returned malformed data or unsupported down credit")
        return result

    def query_white_player_business_variables_v1(self, *, expected_revision: int | None = None) -> dict[str, object]:
        """Observe actual player variable presence/type/value independently of panel rendering."""
        from .white_player_business_variables_contract import SCHEMA, STEP
        method = getattr(self.driver, "query_white_player_business_variables_v1", None)
        if not callable(method):
            raise UnsupportedStepError("selected backend lacks fixed native White business variable query")
        result = method(expected_revision=expected_revision)
        if (not isinstance(result, dict) or result.get("schema") != SCHEMA or result.get("step") != STEP
                or result.get("read_only") is not True or result.get("gui_acceptance_credit") is not False
                or any(result.get(name) is not False for name in
                       ("rendered_text_available", "selected_down_available", "scriptvalue_price_available"))):
            raise BridgeUnavailableError("White variable backend returned malformed data or unsupported GUI credit")
        return result

    def query_ingame_decision_item_v1(self, decision_key: str, *, expected_revision: int | None = None) -> dict[str, object]:
        """Observe one actual decision model identity; this does not qualify a widget action."""
        method = getattr(self.driver, "query_ingame_decision_item_v1", None)
        if not callable(method):
            raise UnsupportedStepError("selected backend lacks the typed decision model observer")
        result = method(decision_key, expected_revision=expected_revision)
        if not isinstance(result, dict) or result.get("schema") != "ck3-ingame-decision-item-v1" or result.get("read_only") is not True:
            raise BridgeUnavailableError("typed decision model observer returned malformed data")
        return result

    def open_ingame_decisions_v1(self, *, expected_revision: int | None = None) -> dict[str, object]:
        """Open only the exact .3 HUD Decisions entry and verify actual visibility."""
        method = getattr(self.driver, "open_ingame_decisions_v1", None)
        if not callable(method):
            raise UnsupportedStepError("selected backend lacks the typed Decisions opener")
        result = method(expected_revision=expected_revision)
        if not isinstance(result, dict) or result.get("schema") != "ck3-ingame-decisions-open-v1" or result.get("postcondition_verified") is not True:
            raise BridgeUnavailableError("typed Decisions opener lacks later visibility proof")
        return result

    def inspect_gui_window_tree_v1(self, window_kind: str) -> dict[str, object]:
        """Read a native window census; a hidden root is not an open modal."""
        inspect = getattr(self.driver, "inspect_gui_window_tree_v1", None)
        if not callable(inspect):
            raise UnsupportedStepError("selected backend has no native GUI window census")
        result = inspect(window_kind)
        if not isinstance(result, dict) or result.get("schema") != "ck3-native-gui-window-tree-inspection-v1" or result.get("window_kind") != window_kind or result.get("read_only") is not True:
            raise BridgeUnavailableError("native GUI window census returned malformed data")
        return result

    def inspect_frontend_gui_tree_v1(self) -> dict[str, object]:
        """Inspect bounded native GUI names without screen interpretation."""

        inspect = getattr(self.driver, "inspect_frontend_gui_tree_v1", None)
        if not callable(inspect):
            raise UnsupportedStepError(
                "selected backend has no native frontend GUI tree inspector"
            )
        result = inspect()
        if (
            not isinstance(result, dict)
            or result.get("schema")
            != "ck3-frontend-gui-tree-inspection-v1"
            or result.get("schema_version") != 1
            or result.get("read_only") is not True
            or result.get("uses_ocr") is not False
            or result.get("uses_keyboard") is not False
            or result.get("uses_mouse") is not False
        ):
            raise BridgeUnavailableError(
                "native frontend GUI tree inspector returned malformed data"
            )
        return result

    def query_frontend_selected_1066_feudal_candidate_v1(
        self,
    ) -> dict[str, object]:
        """Require exact native bookmark model identity before StartGame."""
        query = getattr(
            self.driver,
            "query_frontend_selected_1066_feudal_candidate_v1",
            None,
        )
        if not callable(query):
            raise UnsupportedStepError(
                "selected backend has no native 1066 feudal candidate observer"
            )
        result = query()
        if (
            not isinstance(result, dict)
            or result.get("schema")
            != "ck3-frontend-selected-1066-feudal-candidate-v1"
            or result.get("schema_version") != 1
            or result.get("status") != "ready"
            or result.get("read_only") is not True
        ):
            raise BridgeUnavailableError(
                "native 1066 feudal candidate observer returned malformed data"
            )
        return result

    def inspect_frontend_coat_of_arms_tree_v1(self) -> dict[str, object]:
        """Inspect only the active native CoA page without screen input."""

        inspect = getattr(
            self.driver, "inspect_frontend_coat_of_arms_tree_v1", None
        )
        if not callable(inspect):
            raise UnsupportedStepError(
                "selected backend has no native coat-of-arms tree inspector"
            )
        result = inspect()
        if (
            not isinstance(result, dict)
            or result.get("schema")
            != "ck3-frontend-gui-tree-inspection-v1"
            or result.get("schema_version") != 1
            or result.get("step")
            != "inspect-frontend-coat-of-arms-tree-v1"
            or result.get("scope_root_name") != "coat_of_arms_page"
            or result.get("read_only") is not True
            or result.get("uses_ocr") is not False
            or result.get("uses_keyboard") is not False
            or result.get("uses_mouse") is not False
        ):
            raise BridgeUnavailableError(
                "native coat-of-arms tree inspector returned malformed data"
            )
        return result

    def inspect_frontend_coat_of_arms_pattern_grid_v1(
        self,
    ) -> dict[str, object]:
        """Inspect the fixed native CoA pattern grid without screen input."""

        inspect = getattr(
            self.driver,
            "inspect_frontend_coat_of_arms_pattern_grid_v1",
            None,
        )
        if not callable(inspect):
            raise UnsupportedStepError(
                "selected backend has no native coat-of-arms pattern-grid inspector"
            )
        result = inspect()
        if (
            not isinstance(result, dict)
            or result.get("schema")
            != "ck3-frontend-gui-tree-inspection-v1"
            or result.get("schema_version") != 1
            or result.get("step")
            != "inspect-frontend-coat-of-arms-pattern-grid-v1"
            or result.get("scope_root_name")
            != "coat_of_arms_pattern_grid"
            or result.get("direct_children_complete") is not True
            or result.get("read_only") is not True
            or result.get("uses_ocr") is not False
            or result.get("uses_keyboard") is not False
            or result.get("uses_mouse") is not False
        ):
            raise BridgeUnavailableError(
                "native coat-of-arms pattern-grid inspector returned malformed data"
            )
        return result

    def compare_frontend_coat_of_arms_framebuffer_v1(
        self,
        reference_png_base64: str,
        reference_png_sha256: str,
    ) -> dict[str, object]:
        """Compare one canonical preview to the route-bound CK3 framebuffer."""

        before_route = self.query_frontend_gui_route_v1()
        if before_route.get("route") != "coat_of_arms_designer":
            raise BridgeUnavailableError(
                "coat-of-arms framebuffer comparison requires the native designer route"
            )
        before_tree = self.inspect_frontend_coat_of_arms_tree_v1()
        if not (
            before_tree.get("status") == "available"
            and before_tree.get("root_available") is True
            and before_tree.get("scope_root_name") == "coat_of_arms_page"
        ):
            raise BridgeUnavailableError(
                "coat-of-arms framebuffer comparison requires a visible native page root"
            )
        try:
            before_binding = frontend_gui_route_binding_from_capabilities(
                self.capabilities()
            )
            comparison = capture_and_compare_coat_of_arms_framebuffer_v1(
                before_binding["bridge_pid"],
                reference_png_base64,
                reference_png_sha256,
            )
            after_binding = frontend_gui_route_binding_from_capabilities(
                self.capabilities()
            )
        except (ValueError, CoatOfArmsFramebufferError) as error:
            raise BridgeUnavailableError(
                f"coat-of-arms framebuffer comparison failed closed: {error}"
            ) from error
        after_route = self.query_frontend_gui_route_v1()
        after_tree = self.inspect_frontend_coat_of_arms_tree_v1()
        if not (
            before_binding == after_binding
            and before_route == after_route
            and after_route.get("route") == "coat_of_arms_designer"
            and after_tree.get("status") == "available"
            and after_tree.get("root_available") is True
            and after_tree.get("scope_root_name") == "coat_of_arms_page"
            and comparison.get("bridgePid") == before_binding["bridge_pid"]
        ):
            raise BridgeUnavailableError(
                "coat-of-arms route or native bridge binding changed during capture"
            )
        return {
            **comparison,
            "route": "coat_of_arms_designer",
            "routeStable": True,
            "nativePageRootAvailableBefore": True,
            "nativePageRootAvailableAfter": True,
            "connectionGeneration": before_binding["connection_generation"],
        }

    def calibrate_frontend_coat_of_arms_framebuffer_v2(
        self,
        calibration_id: str,
        phase: str,
    ) -> dict[str, object]:
        """Capture one of two reference-independent solid-state calibration frames."""

        if phase not in {"begin", "complete"}:
            raise ValueError("calibration phase must be begin or complete")
        before_route = self.query_frontend_gui_route_v1()
        if before_route.get("route") != "coat_of_arms_designer":
            raise BridgeUnavailableError(
                "coat-of-arms framebuffer calibration requires the native designer route"
            )
        before_tree = self.inspect_frontend_coat_of_arms_tree_v1()
        if not (
            before_tree.get("status") == "available"
            and before_tree.get("root_available") is True
            and before_tree.get("scope_root_name") == "coat_of_arms_page"
        ):
            raise BridgeUnavailableError(
                "coat-of-arms framebuffer calibration requires a visible native page root"
            )
        try:
            before_binding = frontend_gui_route_binding_from_capabilities(
                self.capabilities()
            )
            operation = getattr(
                self._coat_of_arms_framebuffer_calibrations_v2, phase
            )
            calibration = operation(
                before_binding["bridge_pid"], calibration_id
            )
            after_binding = frontend_gui_route_binding_from_capabilities(
                self.capabilities()
            )
        except (ValueError, CoatOfArmsFramebufferError) as error:
            raise BridgeUnavailableError(
                f"coat-of-arms framebuffer calibration failed closed: {error}"
            ) from error
        after_route = self.query_frontend_gui_route_v1()
        after_tree = self.inspect_frontend_coat_of_arms_tree_v1()
        if not (
            before_binding == after_binding
            and before_route == after_route
            and after_route.get("route") == "coat_of_arms_designer"
            and after_tree.get("status") == "available"
            and after_tree.get("root_available") is True
            and after_tree.get("scope_root_name") == "coat_of_arms_page"
            and calibration.get("bridgePid") == before_binding["bridge_pid"]
            and calibration.get("usesOcr") is False
            and calibration.get("usesKeyboard") is False
            and calibration.get("usesMouse") is False
        ):
            raise BridgeUnavailableError(
                "coat-of-arms route or native bridge binding changed during calibration"
            )
        return {
            **calibration,
            "route": "coat_of_arms_designer",
            "routeStable": True,
            "nativePageRootAvailableBefore": True,
            "nativePageRootAvailableAfter": True,
            "connectionGeneration": before_binding["connection_generation"],
        }

    def compare_frontend_coat_of_arms_framebuffer_v2(
        self,
        calibration_id: str,
        reference_png_base64: str,
        reference_png_sha256: str,
    ) -> dict[str, object]:
        """Compare against one fixed, reference-independent calibrated surface."""

        before_route = self.query_frontend_gui_route_v1()
        if before_route.get("route") != "coat_of_arms_designer":
            raise BridgeUnavailableError(
                "coat-of-arms framebuffer comparison requires the native designer route"
            )
        before_tree = self.inspect_frontend_coat_of_arms_tree_v1()
        if not (
            before_tree.get("status") == "available"
            and before_tree.get("root_available") is True
            and before_tree.get("scope_root_name") == "coat_of_arms_page"
        ):
            raise BridgeUnavailableError(
                "coat-of-arms framebuffer comparison requires a visible native page root"
            )
        try:
            before_binding = frontend_gui_route_binding_from_capabilities(
                self.capabilities()
            )
            comparison = self._coat_of_arms_framebuffer_calibrations_v2.compare(
                before_binding["bridge_pid"],
                calibration_id,
                reference_png_base64,
                reference_png_sha256,
            )
            after_binding = frontend_gui_route_binding_from_capabilities(
                self.capabilities()
            )
        except (ValueError, CoatOfArmsFramebufferError) as error:
            raise BridgeUnavailableError(
                f"coat-of-arms framebuffer comparison failed closed: {error}"
            ) from error
        after_route = self.query_frontend_gui_route_v1()
        after_tree = self.inspect_frontend_coat_of_arms_tree_v1()
        if not (
            before_binding == after_binding
            and before_route == after_route
            and after_route.get("route") == "coat_of_arms_designer"
            and after_tree.get("status") == "available"
            and after_tree.get("root_available") is True
            and after_tree.get("scope_root_name") == "coat_of_arms_page"
            and comparison.get("bridgePid") == before_binding["bridge_pid"]
        ):
            raise BridgeUnavailableError(
                "coat-of-arms route or native bridge binding changed during capture"
            )
        return {
            **comparison,
            "route": "coat_of_arms_designer",
            "routeStable": True,
            "nativePageRootAvailableBefore": True,
            "nativePageRootAvailableAfter": True,
            "connectionGeneration": before_binding["connection_generation"],
        }

    def calibrate_frontend_coat_of_arms_framebuffer_v3(
        self,
        calibration_id: str,
        phase: str,
    ) -> dict[str, object]:
        """Capture bounded surface and marker frames for native UV registration."""

        if phase not in {
            "begin",
            "surface_complete",
            "anchor_base",
            "anchors_complete",
        }:
            raise ValueError(
                "calibration phase must be begin, surface_complete, "
                "anchor_base, or anchors_complete"
            )
        before_route = self.query_frontend_gui_route_v1()
        if before_route.get("route") != "coat_of_arms_designer":
            raise BridgeUnavailableError(
                "coat-of-arms framebuffer calibration requires the native designer route"
            )
        before_tree = self.inspect_frontend_coat_of_arms_tree_v1()
        if not (
            before_tree.get("status") == "available"
            and before_tree.get("root_available") is True
            and before_tree.get("scope_root_name") == "coat_of_arms_page"
        ):
            raise BridgeUnavailableError(
                "coat-of-arms framebuffer calibration requires a visible native page root"
            )
        try:
            before_binding = frontend_gui_route_binding_from_capabilities(
                self.capabilities()
            )
            operation = getattr(
                self._coat_of_arms_framebuffer_calibrations_v3, phase
            )
            calibration = operation(
                before_binding["bridge_pid"], calibration_id
            )
            after_binding = frontend_gui_route_binding_from_capabilities(
                self.capabilities()
            )
        except (ValueError, CoatOfArmsFramebufferError) as error:
            raise BridgeUnavailableError(
                f"coat-of-arms framebuffer calibration failed closed: {error}"
            ) from error
        after_route = self.query_frontend_gui_route_v1()
        after_tree = self.inspect_frontend_coat_of_arms_tree_v1()
        if not (
            before_binding == after_binding
            and before_route == after_route
            and after_route.get("route") == "coat_of_arms_designer"
            and after_tree.get("status") == "available"
            and after_tree.get("root_available") is True
            and after_tree.get("scope_root_name") == "coat_of_arms_page"
            and calibration.get("bridgePid") == before_binding["bridge_pid"]
            and calibration.get("usesOcr") is False
            and calibration.get("usesKeyboard") is False
            and calibration.get("usesMouse") is False
        ):
            raise BridgeUnavailableError(
                "coat-of-arms route or native bridge binding changed during calibration"
            )
        return {
            **calibration,
            "route": "coat_of_arms_designer",
            "routeStable": True,
            "nativePageRootAvailableBefore": True,
            "nativePageRootAvailableAfter": True,
            "connectionGeneration": before_binding["connection_generation"],
        }

    def compare_frontend_coat_of_arms_framebuffer_v3(
        self,
        calibration_id: str,
        reference_png_base64: str,
        reference_png_sha256: str,
    ) -> dict[str, object]:
        """Compare against a reference-independent, native-UV-registered surface."""

        before_route = self.query_frontend_gui_route_v1()
        if before_route.get("route") != "coat_of_arms_designer":
            raise BridgeUnavailableError(
                "coat-of-arms framebuffer comparison requires the native designer route"
            )
        before_tree = self.inspect_frontend_coat_of_arms_tree_v1()
        if not (
            before_tree.get("status") == "available"
            and before_tree.get("root_available") is True
            and before_tree.get("scope_root_name") == "coat_of_arms_page"
        ):
            raise BridgeUnavailableError(
                "coat-of-arms framebuffer comparison requires a visible native page root"
            )
        try:
            before_binding = frontend_gui_route_binding_from_capabilities(
                self.capabilities()
            )
            comparison = self._coat_of_arms_framebuffer_calibrations_v3.compare(
                before_binding["bridge_pid"],
                calibration_id,
                reference_png_base64,
                reference_png_sha256,
            )
            after_binding = frontend_gui_route_binding_from_capabilities(
                self.capabilities()
            )
        except (ValueError, CoatOfArmsFramebufferError) as error:
            raise BridgeUnavailableError(
                f"coat-of-arms framebuffer comparison failed closed: {error}"
            ) from error
        after_route = self.query_frontend_gui_route_v1()
        after_tree = self.inspect_frontend_coat_of_arms_tree_v1()
        if not (
            before_binding == after_binding
            and before_route == after_route
            and after_route.get("route") == "coat_of_arms_designer"
            and after_tree.get("status") == "available"
            and after_tree.get("root_available") is True
            and after_tree.get("scope_root_name") == "coat_of_arms_page"
            and comparison.get("bridgePid") == before_binding["bridge_pid"]
        ):
            raise BridgeUnavailableError(
                "coat-of-arms route or native bridge binding changed during capture"
            )
        return {
            **comparison,
            "route": "coat_of_arms_designer",
            "routeStable": True,
            "nativePageRootAvailableBefore": True,
            "nativePageRootAvailableAfter": True,
            "connectionGeneration": before_binding["connection_generation"],
        }

    def capture_frontend_coat_of_arms_framebuffer_v1(
        self,
        calibration_id: str,
        side: int = 230,
    ) -> dict[str, object]:
        """Capture the native-UV-registered CoA surface without a reference."""

        before_route = self.query_frontend_gui_route_v1()
        if before_route.get("route") != "coat_of_arms_designer":
            raise BridgeUnavailableError(
                "coat-of-arms framebuffer capture requires the native designer route"
            )
        before_tree = self.inspect_frontend_coat_of_arms_tree_v1()
        if not (
            before_tree.get("status") == "available"
            and before_tree.get("root_available") is True
            and before_tree.get("scope_root_name") == "coat_of_arms_page"
        ):
            raise BridgeUnavailableError(
                "coat-of-arms framebuffer capture requires a visible native page root"
            )
        try:
            before_binding = frontend_gui_route_binding_from_capabilities(
                self.capabilities()
            )
            capture = self._coat_of_arms_framebuffer_calibrations_v3.capture(
                before_binding["bridge_pid"], calibration_id, side
            )
            after_binding = frontend_gui_route_binding_from_capabilities(
                self.capabilities()
            )
        except (ValueError, CoatOfArmsFramebufferError) as error:
            raise BridgeUnavailableError(
                f"coat-of-arms framebuffer capture failed closed: {error}"
            ) from error
        after_route = self.query_frontend_gui_route_v1()
        after_tree = self.inspect_frontend_coat_of_arms_tree_v1()
        if not (
            before_binding == after_binding
            and before_route == after_route
            and after_route.get("route") == "coat_of_arms_designer"
            and after_tree.get("status") == "available"
            and after_tree.get("root_available") is True
            and after_tree.get("scope_root_name") == "coat_of_arms_page"
            and capture.get("bridgePid") == before_binding["bridge_pid"]
            and capture.get("readOnly") is True
            and capture.get("usesOcr") is False
            and capture.get("usesKeyboard") is False
            and capture.get("usesMouse") is False
        ):
            raise BridgeUnavailableError(
                "coat-of-arms route or native bridge binding changed during capture"
            )
        return {
            **capture,
            "route": "coat_of_arms_designer",
            "routeStable": True,
            "nativePageRootAvailableBefore": True,
            "nativePageRootAvailableAfter": True,
            "connectionGeneration": before_binding["connection_generation"],
        }

    def prepare_frontend_coat_of_arms_framebuffer_v1(self) -> dict[str, object]:
        """Request foreground for the exact route-bound CK3 client."""

        before_route = self.query_frontend_gui_route_v1()
        if before_route.get("route") != "coat_of_arms_designer":
            raise BridgeUnavailableError(
                "coat-of-arms framebuffer preparation requires the native designer route"
            )
        before_tree = self.inspect_frontend_coat_of_arms_tree_v1()
        if not (
            before_tree.get("status") == "available"
            and before_tree.get("root_available") is True
            and before_tree.get("scope_root_name") == "coat_of_arms_page"
        ):
            raise BridgeUnavailableError(
                "coat-of-arms framebuffer preparation requires a visible native page root"
            )
        try:
            before_binding = frontend_gui_route_binding_from_capabilities(
                self.capabilities()
            )
            preparation = prepare_ck3_framebuffer_capture_v1(
                before_binding["bridge_pid"]
            )
            after_binding = frontend_gui_route_binding_from_capabilities(
                self.capabilities()
            )
        except (ValueError, CoatOfArmsFramebufferError) as error:
            raise BridgeUnavailableError(
                f"coat-of-arms framebuffer preparation failed closed: {error}"
            ) from error
        after_route = self.query_frontend_gui_route_v1()
        after_tree = self.inspect_frontend_coat_of_arms_tree_v1()
        if not (
            before_binding == after_binding
            and before_route == after_route
            and after_route.get("route") == "coat_of_arms_designer"
            and after_tree.get("status") == "available"
            and after_tree.get("root_available") is True
            and after_tree.get("scope_root_name") == "coat_of_arms_page"
            and preparation.get("bridgePid") == before_binding["bridge_pid"]
            and preparation.get("presentationOnly") is True
            and preparation.get("usesOcr") is False
            and preparation.get("usesKeyboard") is False
            and preparation.get("usesMouse") is False
        ):
            raise BridgeUnavailableError(
                "coat-of-arms route or native bridge binding changed during preparation"
            )
        return {
            **preparation,
            "route": "coat_of_arms_designer",
            "routeStable": True,
            "nativePageRootAvailableBefore": True,
            "nativePageRootAvailableAfter": True,
            "connectionGeneration": before_binding["connection_generation"],
        }

    def activate_frontend_new_game_v1(self) -> dict[str, object]:
        """Open New Game semantically; the driver must prove Bookmarks."""

        activate = getattr(self.driver, "activate_frontend_new_game_v1", None)
        if not callable(activate):
            raise UnsupportedStepError(
                "selected backend has no native frontend new-game action"
            )
        result = activate()
        if (
            not isinstance(result, dict)
            or result.get("schema") != "ck3-frontend-gui-action-v1"
            or result.get("schema_version") != 1
            or result.get("postcondition_verified") is not True
            or result.get("uses_ocr") is not False
            or result.get("uses_keyboard") is not False
            or result.get("uses_mouse") is not False
        ):
            raise BridgeUnavailableError(
                "native frontend new-game action lacks its postcondition"
            )
        return result

    def activate_frontend_pick_any_character_v1(self) -> dict[str, object]:
        """Open the ruler-selection lobby; the driver proves the route."""

        activate = getattr(
            self.driver, "activate_frontend_pick_any_character_v1", None
        )
        if not callable(activate):
            raise UnsupportedStepError(
                "selected backend has no native frontend pick-any-character action"
            )
        result = activate()
        if (
            not isinstance(result, dict)
            or result.get("schema") != "ck3-frontend-gui-action-v1"
            or result.get("schema_version") != 1
            or result.get("postcondition_verified") is not True
            or result.get("uses_ocr") is not False
            or result.get("uses_keyboard") is not False
            or result.get("uses_mouse") is not False
        ):
            raise BridgeUnavailableError(
                "native frontend pick-any-character action lacks its postcondition"
            )
        return result

    def activate_frontend_start_selected_bookmark_v1(
        self,
    ) -> dict[str, object]:
        """Require a new paused feudal map after native StartGame."""
        activate = getattr(
            self.driver, "activate_frontend_start_selected_bookmark_v1",
            None,
        )
        if not callable(activate):
            raise UnsupportedStepError(
                "selected backend has no native selected-bookmark StartGame"
            )
        result = activate()
        if (
            not isinstance(result, dict)
            or result.get("schema")
            != "ck3-frontend-selected-bookmark-start-v1"
            or result.get("schema_version") != 1
            or result.get("postcondition_verified") is not True
            or result.get("uses_ocr") is not False
            or result.get("uses_keyboard") is not False
            or result.get("uses_mouse") is not False
        ):
            raise BridgeUnavailableError(
                "native selected-bookmark StartGame lacks an independent "
                "paused feudal map postcondition"
            )
        return result

    def submit_frontend_fixture_robert_start_v1(self) -> dict[str, object]:
        """Submit the separately admitted fixture Start and retain verification pending."""
        from .frontend_fixture_start_contract import require_fixture_start_submission
        submit = getattr(self.driver, "submit_frontend_fixture_robert_start_v1", None)
        if not callable(submit):
            raise UnsupportedStepError("selected backend has no typed fixture Start submission")
        return require_fixture_start_submission(submit())

    def activate_frontend_start_1066_bookmark_character_v1(
        self,
        character_name_key: str,
    ) -> dict[str, object]:
        """Select one exact-build 1066 bookmark character and start its map."""
        activate = getattr(
            self.driver,
            "activate_frontend_start_1066_bookmark_character_v1",
            None,
        )
        if not callable(activate):
            raise UnsupportedStepError(
                "selected backend has no native 1066 bookmark-character start"
            )
        result = activate(character_name_key)
        if (
            not isinstance(result, dict)
            or result.get("schema")
            != "ck3-frontend-1066-bookmark-character-start-v1"
            or result.get("schema_version") != 1
            or result.get("postcondition_verified") is not True
            or result.get("requested_character_name_key")
            != character_name_key
            or result.get("uses_ocr") is not False
            or result.get("uses_keyboard") is not False
            or result.get("uses_mouse") is not False
        ):
            raise BridgeUnavailableError(
                "native 1066 bookmark-character start lacks its independent "
                "paused-map postcondition"
            )
        return result

    def activate_frontend_prepare_custom_ruler_v1(self) -> dict[str, object]:
        """Select a featured ruler and prove the custom-ruler lobby is ready."""

        activate = getattr(
            self.driver, "activate_frontend_prepare_custom_ruler_v1", None
        )
        if not callable(activate):
            raise UnsupportedStepError(
                "selected backend has no native custom-ruler preparation action"
            )
        result = activate()
        if (
            not isinstance(result, dict)
            or result.get("schema") != "ck3-frontend-gui-action-v1"
            or result.get("schema_version") != 1
            or result.get("action") != "prepare_custom_ruler"
            or result.get("postcondition_verified") is not True
            or result.get("uses_ocr") is not False
            or result.get("uses_keyboard") is not False
            or result.get("uses_mouse") is not False
        ):
            raise BridgeUnavailableError(
                "native custom-ruler preparation lacks its postcondition"
            )
        return result

    def activate_frontend_ruler_designer_v1(self) -> dict[str, object]:
        """Open Ruler Designer; the driver must prove the route transition."""

        activate = getattr(
            self.driver, "activate_frontend_ruler_designer_v1", None
        )
        if not callable(activate):
            raise UnsupportedStepError(
                "selected backend has no native ruler-designer action"
            )
        result = activate()
        if (
            not isinstance(result, dict)
            or result.get("schema") != "ck3-frontend-gui-action-v1"
            or result.get("schema_version") != 1
            or result.get("action") != "open_ruler_designer"
            or result.get("postcondition_verified") is not True
            or result.get("uses_ocr") is not False
            or result.get("uses_keyboard") is not False
            or result.get("uses_mouse") is not False
        ):
            raise BridgeUnavailableError(
                "native ruler-designer action lacks its postcondition"
            )
        return result

    def activate_frontend_coat_of_arms_designer_v1(self) -> dict[str, object]:
        """Open the dynasty CoA page; the driver proves the route transition."""

        activate = getattr(
            self.driver, "activate_frontend_coat_of_arms_designer_v1", None
        )
        if not callable(activate):
            raise UnsupportedStepError(
                "selected backend has no native coat-of-arms designer action"
            )
        result = activate()
        if (
            not isinstance(result, dict)
            or result.get("schema") != "ck3-frontend-gui-action-v1"
            or result.get("schema_version") != 1
            or result.get("action") != "open_coat_of_arms_designer"
            or result.get("postcondition_verified") is not True
            or result.get("uses_ocr") is not False
            or result.get("uses_keyboard") is not False
            or result.get("uses_mouse") is not False
        ):
            raise BridgeUnavailableError(
                "native coat-of-arms designer action lacks its postcondition"
            )
        return result

    def commit_frontend_dynasty_coat_of_arms_v1(self) -> dict[str, object]:
        """Commit the current dynasty CoA through the exact native Finish."""

        commit = getattr(
            self.driver, "commit_frontend_dynasty_coat_of_arms_v1", None
        )
        if not callable(commit):
            raise UnsupportedStepError(
                "selected backend has no native dynasty coat-of-arms commit"
            )
        result = commit()
        if (
            not isinstance(result, dict)
            or result.get("schema") != "ck3-frontend-gui-action-v1"
            or result.get("schema_version") != 1
            or result.get("action") != "commit_dynasty_coat_of_arms"
            or result.get("postcondition_verified") is not True
            or result.get("uses_ocr") is not False
            or result.get("uses_keyboard") is not False
            or result.get("uses_mouse") is not False
        ):
            raise BridgeUnavailableError(
                "native dynasty coat-of-arms commit lacks its postcondition"
            )
        return result

    def activate_frontend_coat_of_arms_custom_mode_v1(
        self,
    ) -> dict[str, object]:
        """Enter native custom mode and prove the background grid is ready."""

        activate = getattr(
            self.driver,
            "activate_frontend_coat_of_arms_custom_mode_v1",
            None,
        )
        if not callable(activate):
            raise UnsupportedStepError(
                "selected backend has no native coat-of-arms custom-mode action"
            )
        result = activate()
        if (
            not isinstance(result, dict)
            or result.get("schema") != "ck3-frontend-gui-action-v1"
            or result.get("schema_version") != 1
            or result.get("action") != "enter_coat_of_arms_custom_mode"
            or result.get("postcondition_verified") is not True
            or result.get("uses_ocr") is not False
            or result.get("uses_keyboard") is not False
            or result.get("uses_mouse") is not False
        ):
            raise BridgeUnavailableError(
                "native coat-of-arms custom-mode action lacks its postcondition"
            )
        return result

    def query_current_event_window_context_v1(
        self,
        event_instance_id: int,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read exact identity, presentation, and lossy effect indicators."""
        if (
            isinstance(event_instance_id, bool)
            or not isinstance(event_instance_id, int)
            or not 1 <= event_instance_id <= 2**31 - 1
        ):
            raise ValueError("event_instance_id must be a positive full int32")
        snapshot = self.snapshot()
        revision = snapshot.get("revision")
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        active_event = snapshot.get("active_event")
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "event-window queries require a paused CK3 snapshot"
            )
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or revision < 0
            or isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or expected_revision < 0
        ):
            raise ValueError("expected_revision must be a non-negative integer")
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "event-window revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
            or not isinstance(snapshot_id, str)
            or not snapshot_id
        ):
            raise BridgeUnavailableError(
                "event-window query lacks a stable native snapshot binding"
            )
        if (
            not isinstance(active_event, dict)
            or active_event.get("instance_id") != event_instance_id
        ):
            raise BridgeUnavailableError(
                "event instance ID does not match the active event"
            )
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_CURRENT_EVENT_WINDOW_CONTEXT_V1_CAPABILITY
            in bridge_capabilities
            and QUERY_CURRENT_EVENT_WINDOW_CONTEXT_V1_STEP
            in action_step_set(capabilities)
        ):
            raise UnsupportedStepError(
                "selected backend cannot query the current event window"
            )
        result = self.execute_step(
            QUERY_CURRENT_EVENT_WINDOW_CONTEXT_V1_STEP,
            expected_revision=expected_revision,
        )
        mirror_keys = {
            "schema",
            "schema_version",
            "date_raw",
            "current_event_instance_id",
            "window_match_count",
            "unavailable_reason",
            "event_definition_key",
            "calculated_event_id",
            "runtime_stats_ordinal",
            "root_scope",
            "saved_scopes",
            "options",
            "readiness",
            "provenance",
        }
        required_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "current_event_window_context",
            "backend_id",
            "current_event_window_context_ready",
            "current_event_effect_indicators_ready",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            *mirror_keys,
        }
        if (
            not isinstance(result, dict)
            or set(result) != required_keys
            or result.get("step")
            != QUERY_CURRENT_EVENT_WINDOW_CONTEXT_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "event-window backend returned a malformed result"
            )
        try:
            normalized = normalize_current_event_window_context_v1(
                result.get("current_event_window_context"),
                expected_event_instance_id=event_instance_id,
                expected_date_raw=date_raw,
                expected_snapshot_revision=native_revision,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"event-window result is malformed: {error}"
            ) from error
        expected_mirrors = {
            key: copy.deepcopy(normalized[key]) for key in mirror_keys
        }
        if (
            result.get("status") != normalized["status"]
            or any(
                result.get(key) != expected
                for key, expected in expected_mirrors.items()
            )
            or result.get("current_event_window_context_ready")
            is not normalized["readiness"]["option_presentation_ready"]
            or result.get("current_event_effect_indicators_ready")
            is not normalized["readiness"]["effect_indicators_ready"]
            or result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "event-window result mirrors disagree with its snapshot"
            )
        current = self.snapshot()
        current_event = current.get("active_event")
        if not (
            current.get("paused") is True
            and current.get("revision") == revision
            and current.get("snapshot_id") == snapshot_id
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and isinstance(current_event, dict)
            and current_event.get("instance_id") == event_instance_id
        ):
            raise BridgeUnavailableError(
                "event-window query crossed a snapshot revision"
            )
        return {
            **result,
            "schema_version": 1,
            "status": normalized["status"],
            "scope": "exact-current-event-window",
            "source": {
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "backend_id": snapshot.get("backend_id"),
            },
            "binding": {
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "expected_revision": expected_revision,
                "event_instance_id": event_instance_id,
            },
            **expected_mirrors,
            "current_event_window_context_ready": normalized["readiness"][
                "option_presentation_ready"
            ],
            "current_event_effect_indicators_ready": normalized["readiness"][
                "effect_indicators_ready"
            ],
            "current_event_window_context": normalized,
        }

    def query_current_timeline_blocker_context_v1(
        self,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read the fixed death/succession timeline surface while paused."""
        snapshot = self.snapshot()
        revision = snapshot.get("revision")
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        snapshot_id = snapshot.get("snapshot_id")
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or expected_revision < 0
        ):
            raise ValueError("expected_revision must be a non-negative integer")
        if (
            expected_revision != revision
            or snapshot.get("paused") is not True
            or snapshot.get("map_ready") is not True
            or isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or native_revision <= 0
            or isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not isinstance(snapshot_id, str)
            or not snapshot_id
        ):
            raise BridgeUnavailableError(
                "timeline-blocker query lacks a stable paused snapshot binding"
            )
        reader = getattr(
            self.driver, "query_current_timeline_blocker_context_v1", None
        )
        if not callable(reader):
            raise UnsupportedStepError(
                "selected backend has no private timeline-blocker query"
            )
        result = reader(expected_revision=expected_revision)
        required_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "observation_revision",
            "snapshot_revision",
            "current_timeline_blocker_context",
            "private_build",
            "read_only",
            "advertised",
            "backend_id",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            "date_raw",
        }
        if (
            not isinstance(result, dict)
            or set(result) != required_keys
            or result.get("step")
            != QUERY_CURRENT_TIMELINE_BLOCKER_CONTEXT_V1_STEP
            or result.get("accepted") is not True
            or result.get("private_build") is not True
            or result.get("read_only") is not True
            or result.get("advertised") is not False
            or result.get("snapshot_revision") != native_revision
            or result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
            or result.get("date_raw") != date_raw
        ):
            raise BridgeUnavailableError(
                "timeline-blocker backend returned a malformed result"
            )
        try:
            normalized = normalize_current_timeline_blocker_context_v1(
                result.get("current_timeline_blocker_context"),
                expected_date_raw=date_raw,
                expected_snapshot_revision=native_revision,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"timeline-blocker result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "timeline-blocker result status disagrees with its payload"
            )
        current = self.snapshot()
        if not (
            current.get("snapshot_id") == snapshot_id
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("paused") is True
            and current.get("map_ready") is True
        ):
            raise BridgeUnavailableError(
                "timeline-blocker service query crossed its paused frame"
            )
        return {
            **result,
            "schema_version": 1,
            "scope": "exact-current-timeline-blocker",
            "source": {
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "backend_id": snapshot.get("backend_id"),
            },
            "binding": {
                "snapshot_id": snapshot_id,
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "expected_revision": expected_revision,
            },
            "current_timeline_blocker_context": normalized,
        }

    def continue_death_succession_modal_private_v1(
        self,
        *,
        expected_revision: int,
        expected_played_character_id: int,
        expected_episode_run_id: str,
    ) -> dict[str, object]:
        """Private typed Close plus independent predicates and date proof."""
        action = getattr(
            self.driver, "continue_death_succession_modal_private_v1", None
        )
        if not callable(action):
            raise UnsupportedStepError(
                "selected backend has no private death-succession Close"
            )
        return action(
            expected_revision=expected_revision,
            expected_played_character_id=expected_played_character_id,
            expected_episode_run_id=expected_episode_run_id,
        )

    def query_pending_character_interaction_context_v1(
        self,
        pending_interaction_id: int,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read one exact pending interaction with costs and war binding."""
        pending_interaction_id = normalize_pending_interaction_id(
            pending_interaction_id
        )
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "pending-interaction queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or revision < 0
        ):
            raise BridgeUnavailableError(
                "pending-interaction query lacks a valid snapshot revision"
            )
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or expected_revision < 0
        ):
            raise ValueError(
                "expected_revision must be a non-negative integer"
            )
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "pending-interaction revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        pending = snapshot.get("pending_character_interaction")
        if (
            not isinstance(pending, dict)
            or pending.get("instance_id") != pending_interaction_id
        ):
            raise BridgeUnavailableError(
                "pending interaction ID does not match the current snapshot"
            )
        native_revision = snapshot.get("native_revision")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "pending-interaction query lacks a positive native revision"
            )
        date_raw = snapshot.get("date_raw")
        if (
            isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "pending-interaction query lacks a signed int32 date"
            )
        snapshot_id = snapshot.get("snapshot_id")
        if not isinstance(snapshot_id, str) or not snapshot_id:
            raise BridgeUnavailableError(
                "pending-interaction query lacks a snapshot identity"
            )
        snapshot_backend_id = snapshot.get("backend_id")
        if not isinstance(snapshot_backend_id, str) or not snapshot_backend_id:
            raise BridgeUnavailableError(
                "pending-interaction query lacks a source backend identity"
            )
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_PENDING_CHARACTER_INTERACTION_CONTEXT_V1_CAPABILITY
            in bridge_capabilities
            and QUERY_PENDING_CHARACTER_INTERACTION_CONTEXT_V1_STEP
            in action_step_set(capabilities)
        ):
            raise UnsupportedStepError(
                "selected backend cannot query pending interaction context"
            )
        # The planner consumes successful semantic queries from command history.
        # Route the public typed MCP query through the same recorded step that
        # the planner selects, after binding its explicit ID to this frame.
        result = self.driver.execute_step(
            QUERY_PENDING_CHARACTER_INTERACTION_CONTEXT_V1_STEP,
            expected_revision=expected_revision,
        )
        mirror_keys = {
            "schema",
            "schema_version",
            "date_raw",
            "pending_interaction_id",
            "reason",
            "build",
            "definition",
            "roles",
            "target",
            "send_options",
            "routing",
            "deadline",
            "auto_accept",
            "legality",
            "terms",
            "readiness",
            "provenance",
        }
        required_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "pending_character_interaction_context",
            "backend_id",
            "pending_character_interaction_context_ready",
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            *mirror_keys,
        }
        if (
            not isinstance(result, dict)
            or set(result) != required_result_keys
            or result.get("step")
            != QUERY_PENDING_CHARACTER_INTERACTION_CONTEXT_V1_STEP
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "pending-interaction backend returned a malformed result"
            )
        query_sequence = result.get("query_sequence")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "pending-interaction result lacks query_sequence"
            )
        backend_id = result.get("backend_id")
        if not isinstance(backend_id, str) or not backend_id:
            raise BridgeUnavailableError(
                "pending-interaction result lacks backend_id"
            )
        try:
            normalized = normalize_pending_character_interaction_context_v1(
                result.get("pending_character_interaction_context"),
                expected_pending_interaction_id=pending_interaction_id,
                expected_date_raw=date_raw,
                expected_snapshot_revision=native_revision,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"pending-interaction result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "pending-interaction envelope status disagrees with its frame"
            )
        expected_mirrors = {
            key: copy.deepcopy(normalized[key]) for key in mirror_keys
        }
        readiness = normalized["readiness"]
        assert isinstance(readiness, dict)
        if any(
            result.get(key) != expected
            for key, expected in expected_mirrors.items()
        ) or result.get(
            "pending_character_interaction_context_ready"
        ) is not readiness["interaction_semantic_decision_ready"]:
            raise BridgeUnavailableError(
                "pending-interaction result mirrors disagree with its frame"
            )
        if (
            result.get("queried_snapshot_id") != snapshot_id
            or result.get("queried_revision") != revision
            or result.get("queried_native_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "pending-interaction result is bound to another snapshot"
            )
        if normalized["status"] == "available":
            routing = normalized["routing"]
            roles = normalized["roles"]
            assert isinstance(routing, dict)
            assert isinstance(roles, dict)
            if (
                routing.get("auto_accept_notification")
                is not pending.get("auto_accept_notification")
                or roles.get("actor_character_id")
                != pending.get("sender_character_id")
            ):
                raise BridgeUnavailableError(
                    "pending-interaction frame disagrees with snapshot mirror"
                )
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello")
            if isinstance(diagnostics, dict)
            else None
        )
        build = normalized["build"]
        assert isinstance(build, dict)
        observed_version = (
            hello.get("expected_ck3_version", hello.get("game_version"))
            if isinstance(hello, dict)
            else None
        )
        observed_sha256 = (
            hello.get(
                "expected_ck3_sha256", hello.get("executable_sha256")
            )
            if isinstance(hello, dict)
            else None
        )
        if (
            observed_version != build["version"]
            or not isinstance(observed_sha256, str)
            or observed_sha256.upper()
            != str(build["exe_sha256"]).upper()
        ):
            raise BridgeUnavailableError(
                "pending-interaction build mirror disagrees with bridge hello"
            )
        current = self.snapshot()
        if not (
            current.get("paused") is True
            and current.get("revision") == revision
            and current.get("snapshot_id") == snapshot_id
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id")
            == snapshot.get("episode_run_id")
            and current.get("pending_character_interaction") == pending
        ):
            raise BridgeUnavailableError(
                "pending-interaction query crossed a snapshot revision"
            )
        source = {
            "game_version": observed_version,
            "executable_sha256": observed_sha256.upper(),
            "snapshot_id": snapshot_id,
            "revision": revision,
            "native_revision": native_revision,
            "date_raw": date_raw,
            "paused": True,
            "backend_id": snapshot_backend_id,
        }
        binding = {
            "snapshot_id": snapshot_id,
            "revision": revision,
            "native_revision": native_revision,
            "date_raw": date_raw,
            "pending_interaction_id": pending_interaction_id,
            "expected_revision": expected_revision,
        }
        return {
            **result,
            "schema_version": 1,
            "status": normalized["status"],
            "scope": "exact-pending-character-interaction-context",
            "source": source,
            "binding": binding,
            **expected_mirrors,
            "pending_character_interaction_context_ready": readiness[
                "interaction_semantic_decision_ready"
            ],
            "pending_character_interaction_context": normalized,
        }

    def query_projected_contact_scope_v1(
        self, subject_army_id: int, target_province_id: int,
        incoming_entry_province_id: int, *, expected_revision: int,
    ) -> dict[str, object]:
        """Project arrival against current target state without a move or odds claim."""
        step = query_projected_contact_scope_v1_step(
            subject_army_id, target_province_id, incoming_entry_province_id,
        )
        if type(expected_revision) is not int or not 0 <= expected_revision <= 2**64 - 1:
            raise ValueError("expected_revision must be a non-negative uint64")
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError("projected-contact queries require a paused snapshot")
        if snapshot.get("revision") != expected_revision:
            raise PreSubmissionRevisionMismatchError("projected-contact source revision is stale")
        try:
            subject = projected_contact_subject_scope(snapshot, subject_army_id)
        except ValueError as error:
            raise BridgeUnavailableError(str(error)) from error
        native_revision = snapshot.get("native_revision")
        date_raw = snapshot.get("date_raw")
        if (type(native_revision) is not int or not 1 <= native_revision <= 2**64 - 1
                or type(date_raw) is not int or not -(2**31) <= date_raw <= 2**31 - 1):
            raise BridgeUnavailableError("projected-contact query lacks native revision/date")
        bridge_capabilities = self.capabilities().get("bridge_capabilities")
        if (not isinstance(bridge_capabilities, list)
                or QUERY_PROJECTED_CONTACT_SCOPE_V1_CAPABILITY not in bridge_capabilities):
            raise UnsupportedStepError("selected backend cannot query projected contact scope v1")
        result = self.execute_step(step, expected_revision=expected_revision)
        if (not isinstance(result, dict) or result.get("step") != step
                or result.get("accepted") is not True or result.get("status") != "available"
                or type(result.get("query_sequence")) is not int
                or not 1 <= result["query_sequence"] <= 2**64 - 1
                or result.get("snapshot_revision") != native_revision
                or result.get("queried_revision") != expected_revision
                or result.get("queried_native_revision") != native_revision):
            raise BridgeUnavailableError("native projected-contact query returned a malformed envelope")
        try:
            scope = normalize_projected_contact_scope(
                result.get("projected_contact_scope"), expected_subject_army_id=subject_army_id,
                expected_target_province_id=target_province_id,
                expected_incoming_entry_province_id=incoming_entry_province_id,
                expected_date_raw=date_raw, expected_snapshot_revision=native_revision,
                expected_subject_current_province_id=subject["current_province_id"],
                expected_subject_owner_character_id=subject["owner_character_id"],
            )
        except ValueError as error:
            raise BridgeUnavailableError(str(error)) from error
        # Complete none is a legitimate observation; v2 composition is separate.
        return {**result, "projected_contact_scope": scope}

    def query_actual_contact_scope(
        self,
        subject_army_id: int,
        target_province_id: int,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Predict contact or read its actual CombatID and ordered sides."""
        step = query_actual_contact_scope_step(
            subject_army_id, target_province_id
        )
        result = self._execute_typed_war_step(
            step, expected_revision=expected_revision
        )
        scope = result.get("actual_contact_scope")
        if not (
            isinstance(scope, dict)
            and scope.get("subject_army_id") == subject_army_id
            and scope.get("target_province_id") == target_province_id
            and scope.get("scope_kind")
            in {"pre_contact_prediction", "post_contact_observation"}
            and scope.get("actual_contact_scope_ready") is True
        ):
            raise BridgeUnavailableError(
                "native actual-contact query lacks its exact ordered scope"
            )
        return result

    def query_player_epidemic_recovery_private_v1(
        self, *, expected_revision: int, requested_title_id: int = 0,
        expected_event_instance_id: int | None = None,
    ) -> dict[str, object]:
        """Private paused CE1 county readback; absent from public capabilities."""
        reader = getattr(
            self.driver, "query_player_epidemic_recovery_private_v1", None
        )
        if not callable(reader):
            raise UnsupportedStepError(
                "selected backend has no private epidemic recovery query"
            )
        return reader(
            expected_revision=expected_revision,
            requested_title_id=requested_title_id,
            expected_event_instance_id=expected_event_instance_id,
        )

    def query_battle_control_snapshot_v1(
        self,
        subject_public_cunit_id: int,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read one selected full public CUnitID's battle frame while paused."""
        step = query_battle_control_snapshot_v1_step(
            subject_public_cunit_id
        )
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "battle-control queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or revision < 0
        ):
            raise BridgeUnavailableError(
                "battle-control query lacks a valid snapshot revision"
            )
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or expected_revision < 0
        ):
            raise ValueError(
                "expected_revision must be a non-negative integer"
            )
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "battle-control revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "battle-control query lacks a positive native revision"
            )
        date_raw = snapshot.get("date_raw")
        if (
            isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**63) <= date_raw <= 2**63 - 1
        ):
            raise BridgeUnavailableError(
                "battle-control query lacks a signed int64 date"
            )
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_BATTLE_CONTROL_SNAPSHOT_V1_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query ongoing battle control frames"
            )
        result = self.execute_step(
            step,
            expected_revision=expected_revision,
        )
        if not isinstance(result, dict):
            raise BridgeUnavailableError(
                "battle-control backend returned a non-object result"
            )
        required_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "battle_control_snapshot",
            "selected_public_cunit_id",
            "selected_native_carmy_id",
            "selected_owner_character_id",
            "combat_province_id",
            "side_index",
            "side_scope",
            "affected_public_cunit_ids_in_stored_order",
            "unaffected_same_side_public_cunit_ids_in_stored_order",
            "side_flags",
            "legality",
            "backend_id",
        }
        optional_result_keys = {
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            "active_combat_resume_inputs_v1",
        }
        if (
            not required_result_keys <= set(result)
            or set(result) - required_result_keys - optional_result_keys
            or result.get("step") != step
            or result.get("accepted") is not True
            or result.get("status") != "available"
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "battle-control backend returned a malformed result"
            )
        query_sequence = result.get("query_sequence")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "battle-control result lacks query_sequence"
            )
        try:
            normalized = normalize_battle_control_snapshot_v1(
                result.get("battle_control_snapshot"),
                expected_subject_public_cunit_id=(
                    subject_public_cunit_id
                ),
                expected_observed_date_raw=date_raw,
                expected_snapshot_revision=native_revision,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"battle-control result is malformed: {error}"
            ) from error
        try:
            resume_inputs = (
                normalize_active_combat_resume_inputs_v1(
                    result["active_combat_resume_inputs_v1"],
                    parent=normalized,
                )
                if "active_combat_resume_inputs_v1" in result
                else None
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"battle-control resume inputs are malformed: {error}"
            ) from error
        retreat_mirrors = {
            "selected_public_cunit_id": normalized[
                "selected_public_cunit_id"
            ],
            "selected_native_carmy_id": normalized[
                "selected_native_carmy_id"
            ],
            "selected_owner_character_id": normalized[
                "selected_owner_character_id"
            ],
            "combat_province_id": normalized["combat_province_id"],
            "side_index": normalized["side_index"],
            "side_scope": normalized["side_scope"],
            "affected_public_cunit_ids_in_stored_order": normalized[
                "affected_public_cunit_ids_in_stored_order"
            ],
            "unaffected_same_side_public_cunit_ids_in_stored_order": (
                normalized[
                    "unaffected_same_side_public_cunit_ids_in_stored_order"
                ]
            ),
            "side_flags": normalized["side_flags"],
            "legality": normalized["legality"],
        }
        if any(
            result.get(key) != expected
            for key, expected in retreat_mirrors.items()
        ):
            raise BridgeUnavailableError(
                "battle-control active-retreat mirror disagrees with its frame"
            )
        if (
            "queried_snapshot_id" in result
            and result.get("queried_snapshot_id")
            != snapshot.get("snapshot_id")
        ) or (
            "queried_revision" in result
            and result.get("queried_revision") != revision
        ) or (
            "queried_native_revision" in result
            and result.get("queried_native_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "battle-control result is bound to another snapshot"
            )
        current = self.snapshot()
        if not (
            current.get("paused") is True
            and current.get("revision") == revision
            and current.get("snapshot_id") == snapshot.get("snapshot_id")
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id")
            == snapshot.get("episode_run_id")
        ):
            raise BridgeUnavailableError(
                "battle-control query crossed a snapshot revision"
            )
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello")
            if isinstance(diagnostics, dict)
            else None
        )
        return {
            **result,
            "schema_version": 1,
            "status": "available",
            "scope": "exact-ongoing-battle",
            "source": {
                "game_version": (
                    hello.get("game_version")
                    if isinstance(hello, dict)
                    else None
                ),
                "executable_sha256": (
                    hello.get("executable_sha256")
                    if isinstance(hello, dict)
                    else None
                ),
                "snapshot_id": snapshot.get("snapshot_id"),
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "backend_id": snapshot.get("backend_id"),
            },
            "subject_army_id": subject_public_cunit_id,
            **copy.deepcopy(retreat_mirrors),
            "battle_control_ready": True,
            "battle_control_snapshot": normalized,
            **(
                {"active_combat_resume_inputs_v1": resume_inputs}
                if resume_inputs is not None
                else {}
            ),
        }

    def query_battle_transition_v1(
        self,
        combat_id: int,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read one full CombatID's lifecycle without an army-state gate."""
        step = query_battle_transition_v1_step(combat_id)
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "battle-transition queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or revision < 0
        ):
            raise BridgeUnavailableError(
                "battle-transition query lacks a valid snapshot revision"
            )
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or expected_revision < 0
        ):
            raise ValueError(
                "expected_revision must be a non-negative integer"
            )
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "battle-transition revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "battle-transition query lacks a positive native revision"
            )
        date_raw = snapshot.get("date_raw")
        if (
            isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**63) <= date_raw <= 2**63 - 1
        ):
            raise BridgeUnavailableError(
                "battle-transition query lacks a signed int64 date"
            )
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_BATTLE_TRANSITION_V1_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query exact combat lifecycle"
            )
        result = self.execute_step(
            step,
            expected_revision=expected_revision,
        )
        if not isinstance(result, dict):
            raise BridgeUnavailableError(
                "battle-transition backend returned a non-object result"
            )
        mirror_keys = {
            "combat_id",
            "province_id",
            "phase",
            "phase_raw",
            "phase_day",
            "winner_side",
            "winner_raw",
            "forced_winner_side",
            "forced_winner_raw",
            "finalized",
            "battle_result_id",
            "attacker_public_cunit_ids_in_stored_order",
            "defender_public_cunit_ids_in_stored_order",
            "battle_transition_ready",
        }
        required_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "battle_transition_snapshot",
            "backend_id",
            *mirror_keys,
        }
        optional_result_keys = {
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
            "current_observation",
        }
        if (
            not required_result_keys <= set(result)
            or set(result) - required_result_keys - optional_result_keys
            or result.get("step") != step
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "battle-transition backend returned a malformed result"
            )
        query_sequence = result.get("query_sequence")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "battle-transition result lacks query_sequence"
            )
        try:
            normalized = normalize_battle_transition_v1(
                result.get("battle_transition_snapshot"),
                expected_combat_id=combat_id,
                expected_observed_date_raw=date_raw,
                expected_snapshot_revision=native_revision,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"battle-transition result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "battle-transition envelope status disagrees with its frame"
            )
        if ("current_observation" in result) != ("current_observation" in normalized):
            raise BridgeUnavailableError(
                "battle-transition current observation mirror disagrees with its frame"
            )
        if "current_observation" in normalized:
            mirror_keys.add("current_observation")
        lifecycle_mirrors = {
            key: copy.deepcopy(normalized[key]) for key in mirror_keys
        }
        if any(
            result.get(key) != expected
            for key, expected in lifecycle_mirrors.items()
        ):
            raise BridgeUnavailableError(
                "battle-transition lifecycle mirror disagrees with its frame"
            )
        if (
            "queried_snapshot_id" in result
            and result.get("queried_snapshot_id")
            != snapshot.get("snapshot_id")
        ) or (
            "queried_revision" in result
            and result.get("queried_revision") != revision
        ) or (
            "queried_native_revision" in result
            and result.get("queried_native_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "battle-transition result is bound to another snapshot"
            )
        current = self.snapshot()
        if not (
            current.get("paused") is True
            and current.get("revision") == revision
            and current.get("snapshot_id") == snapshot.get("snapshot_id")
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id")
            == snapshot.get("episode_run_id")
        ):
            raise BridgeUnavailableError(
                "battle-transition query crossed a snapshot revision"
            )
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello")
            if isinstance(diagnostics, dict)
            else None
        )
        return {
            **result,
            "schema_version": 1,
            "status": normalized["status"],
            "scope": "exact-combat-lifecycle",
            "source": {
                "game_version": (
                    hello.get("game_version")
                    if isinstance(hello, dict)
                    else None
                ),
                "executable_sha256": (
                    hello.get("executable_sha256")
                    if isinstance(hello, dict)
                    else None
                ),
                "snapshot_id": snapshot.get("snapshot_id"),
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "backend_id": snapshot.get("backend_id"),
            },
            **lifecycle_mirrors,
            "battle_transition_snapshot": normalized,
        }

    def query_battle_terminal_transition_v1(
        self,
        prior_combat_id: int | None,
        subject_public_cunit_id: int | None,
        *,
        expected_revision: int,
        after_terminal_sequence: int | None = None,
        character_ids: list[int] | None = None,
    ) -> dict[str, object]:
        """Read terminal history and the subject's same-frame successor state."""
        step = query_battle_terminal_transition_v1_step(
            prior_combat_id,
            subject_public_cunit_id,
            after_terminal_sequence,
            character_ids,
        )
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "battle-terminal transition queries require a paused CK3 "
                "snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or revision < 0
        ):
            raise BridgeUnavailableError(
                "battle-terminal transition query lacks a valid snapshot "
                "revision"
            )
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or expected_revision < 0
        ):
            raise ValueError("expected_revision must be a non-negative integer")
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "battle-terminal transition revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "battle-terminal transition query lacks a positive native "
                "revision"
            )
        date_raw = snapshot.get("date_raw")
        if (
            isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**31) <= date_raw <= 2**31 - 1
        ):
            raise BridgeUnavailableError(
                "battle-terminal transition query lacks a signed int32 date"
            )
        bridge_capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_BATTLE_TERMINAL_TRANSITION_V1_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query journal-backed battle "
                "transitions"
            )
        result = self.execute_step(step, expected_revision=expected_revision)
        if not isinstance(result, dict):
            raise BridgeUnavailableError(
                "battle-terminal transition backend returned a non-object "
                "result"
            )
        mirror_keys = {
            "prior_combat_id",
            "subject_public_cunit_id",
            "terminal_journal",
            "prior",
            "removal",
            "subject",
            "successor",
            "battle_terminal_transition_ready",
            "unavailable_reason",
        }
        frame = result.get("battle_terminal_transition")
        if isinstance(frame, dict) and "character_observations" in frame:
            mirror_keys.add("character_observations")
        required_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "battle_terminal_transition",
            "backend_id",
            *mirror_keys,
        }
        optional_result_keys = {
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
        }
        if (
            not required_result_keys <= set(result)
            or set(result) - required_result_keys - optional_result_keys
            or result.get("step") != step
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "battle-terminal transition backend returned a malformed "
                "result"
            )
        query_sequence = result.get("query_sequence")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "battle-terminal transition result lacks query_sequence"
            )
        try:
            normalized = normalize_battle_terminal_transition_v1(
                result.get("battle_terminal_transition"),
                expected_prior_combat_id=prior_combat_id,
                expected_subject_public_cunit_id=subject_public_cunit_id,
                expected_after_terminal_sequence=after_terminal_sequence,
                expected_observed_date_raw=date_raw,
                expected_snapshot_revision=native_revision,
                expected_character_ids=character_ids if character_ids is not None else [],
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"battle-terminal transition result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "battle-terminal transition envelope status disagrees with "
                "its frame"
            )
        mirrors = {
            key: copy.deepcopy(normalized[key]) for key in mirror_keys
        }
        if any(
            result.get(key) != expected
            for key, expected in mirrors.items()
        ):
            raise BridgeUnavailableError(
                "battle-terminal transition mirror disagrees with its frame"
            )
        if (
            "queried_snapshot_id" in result
            and result.get("queried_snapshot_id")
            != snapshot.get("snapshot_id")
        ) or (
            "queried_revision" in result
            and result.get("queried_revision") != revision
        ) or (
            "queried_native_revision" in result
            and result.get("queried_native_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "battle-terminal transition result is bound to another "
                "snapshot"
            )
        current = self.snapshot()
        if not (
            current.get("paused") is True
            and current.get("revision") == revision
            and current.get("snapshot_id") == snapshot.get("snapshot_id")
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id")
            == snapshot.get("episode_run_id")
        ):
            raise BridgeUnavailableError(
                "battle-terminal transition query crossed a snapshot revision"
            )
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello")
            if isinstance(diagnostics, dict)
            else None
        )
        return {
            **result,
            "schema_version": 1,
            "status": normalized["status"],
            "scope": "journal-backed-battle-terminal-transition",
            "source": {
                "game_version": (
                    hello.get("game_version")
                    if isinstance(hello, dict)
                    else None
                ),
                "executable_sha256": (
                    hello.get("executable_sha256")
                    if isinstance(hello, dict)
                    else None
                ),
                "snapshot_id": snapshot.get("snapshot_id"),
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "backend_id": snapshot.get("backend_id"),
            },
            **mirrors,
            "battle_terminal_transition": normalized,
        }

    def query_battle_reinforcement_assignment_v1(
        self,
        selected_public_cunit_id: int,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Read one native AI help signal, assignment, route and contact view."""
        step = query_battle_reinforcement_assignment_v1_step(
            selected_public_cunit_id
        )
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "battle-reinforcement queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if (
            isinstance(revision, bool)
            or not isinstance(revision, int)
            or revision < 0
        ):
            raise BridgeUnavailableError(
                "battle-reinforcement query lacks a valid snapshot revision"
            )
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or expected_revision < 0
        ):
            raise ValueError(
                "expected_revision must be a non-negative integer"
            )
        if expected_revision != revision:
            raise BridgeUnavailableError(
                "battle-reinforcement revision mismatch: expected "
                f"{expected_revision}, current {revision}"
            )
        native_revision = snapshot.get("native_revision")
        if (
            isinstance(native_revision, bool)
            or not isinstance(native_revision, int)
            or not 1 <= native_revision <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "battle-reinforcement query lacks a positive native revision"
            )
        date_raw = snapshot.get("date_raw")
        if (
            isinstance(date_raw, bool)
            or not isinstance(date_raw, int)
            or not -(2**63) <= date_raw <= 2**63 - 1
        ):
            raise BridgeUnavailableError(
                "battle-reinforcement query lacks a signed int64 date"
            )
        bridge_capabilities = self.capabilities().get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_BATTLE_REINFORCEMENT_ASSIGNMENT_V1_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query native AI reinforcement state"
            )
        result = self.execute_step(
            step,
            expected_revision=expected_revision,
        )
        if not isinstance(result, dict):
            raise BridgeUnavailableError(
                "battle-reinforcement backend returned a non-object result"
            )
        mirror_keys = {
            "selected_public_cunit_id",
            "selected_native_carmy_id",
            "coordinator_id",
            "unit_stack_stored_index",
            "subunit_stored_index",
            "signal",
            "assignment",
            "route",
            "native_order",
            "contact_projection",
            "battle_reinforcement_assignment_ready",
            "unavailable_reason",
        }
        required_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "snapshot_revision",
            "battle_reinforcement_assignment",
            "backend_id",
            *mirror_keys,
        }
        optional_result_keys = {
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
        }
        if (
            not required_result_keys <= set(result)
            or set(result) - required_result_keys - optional_result_keys
            or result.get("step") != step
            or result.get("accepted") is not True
            or result.get("snapshot_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "battle-reinforcement backend returned a malformed result"
            )
        query_sequence = result.get("query_sequence")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "battle-reinforcement result lacks query_sequence"
            )
        try:
            normalized = normalize_battle_reinforcement_assignment_v1(
                result.get("battle_reinforcement_assignment"),
                expected_selected_public_cunit_id=selected_public_cunit_id,
                expected_observed_date_raw=date_raw,
                expected_snapshot_revision=native_revision,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"battle-reinforcement result is malformed: {error}"
            ) from error
        if result.get("status") != normalized["status"]:
            raise BridgeUnavailableError(
                "battle-reinforcement envelope status disagrees with frame"
            )
        mirrors = {
            key: copy.deepcopy(normalized[key]) for key in mirror_keys
        }
        if any(
            result.get(key) != expected
            for key, expected in mirrors.items()
        ):
            raise BridgeUnavailableError(
                "battle-reinforcement mirror disagrees with its frame"
            )
        if (
            "queried_snapshot_id" in result
            and result.get("queried_snapshot_id")
            != snapshot.get("snapshot_id")
        ) or (
            "queried_revision" in result
            and result.get("queried_revision") != revision
        ) or (
            "queried_native_revision" in result
            and result.get("queried_native_revision") != native_revision
        ):
            raise BridgeUnavailableError(
                "battle-reinforcement result is bound to another snapshot"
            )
        current = self.snapshot()
        if not (
            current.get("paused") is True
            and current.get("revision") == revision
            and current.get("snapshot_id") == snapshot.get("snapshot_id")
            and current.get("native_revision") == native_revision
            and current.get("date_raw") == date_raw
            and current.get("episode_run_id")
            == snapshot.get("episode_run_id")
        ):
            raise BridgeUnavailableError(
                "battle-reinforcement query crossed a snapshot revision"
            )
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello")
            if isinstance(diagnostics, dict)
            else None
        )
        return {
            **result,
            "schema_version": 1,
            "status": normalized["status"],
            "scope": "native-ai-reinforcement-assignment",
            "source": {
                "game_version": (
                    hello.get("game_version")
                    if isinstance(hello, dict)
                    else None
                ),
                "executable_sha256": (
                    hello.get("executable_sha256")
                    if isinstance(hello, dict)
                    else None
                ),
                "snapshot_id": snapshot.get("snapshot_id"),
                "revision": revision,
                "native_revision": native_revision,
                "date_raw": date_raw,
                "paused": True,
                "backend_id": snapshot.get("backend_id"),
            },
            **mirrors,
            "battle_reinforcement_assignment": normalized,
        }

    def preview_active_combat_retreat_v1(
        self,
        selected_public_cunit_id: int,
        target_province_id: int,
        *,
        expected_revision: int,
    ) -> dict[str, object]:
        """Prove one legal same-frame retreat route and issue a short token."""
        step = preview_active_combat_retreat_v1_step(
            selected_public_cunit_id, target_province_id
        )
        capabilities = self.capabilities()
        if not (
            capabilities.get(
                "active_combat_retreat_v1_composition_supported"
            )
            is True
            or step in action_step_set(capabilities)
        ):
            raise UnsupportedStepError(
                "selected backend cannot compose active-combat retreat"
            )
        result = self.execute_step(
            step, expected_revision=expected_revision
        )
        try:
            return normalize_active_combat_retreat_v1_preview(
                result,
                expected_selected_public_cunit_id=(
                    selected_public_cunit_id
                ),
                expected_target_province_id=target_province_id,
                expected_snapshot_revision=expected_revision,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"active-combat retreat preview is malformed: {error}"
            ) from error

    def order_active_combat_retreat_v1(
        self,
        selected_public_cunit_id: int,
        *,
        expected_revision: int,
        expected_combat_id: int,
        expected_side_index: int,
        expected_scope: str,
        target_province_id: int,
        candidate_token: str,
    ) -> dict[str, object]:
        """Consume one preview token and submit the existing player move."""
        step = order_active_combat_retreat_v1_step(
            selected_public_cunit_id,
            expected_snapshot_revision=expected_revision,
            expected_combat_id=expected_combat_id,
            expected_side_index=expected_side_index,
            expected_scope=expected_scope,
            target_province_id=target_province_id,
            candidate_token=candidate_token,
        )
        capabilities = self.capabilities()
        if capabilities.get(
            "active_combat_retreat_v1_composition_supported"
        ) is not True:
            raise UnsupportedStepError(
                "selected backend cannot compose active-combat retreat"
            )
        result = self.execute_step(
            step, expected_revision=expected_revision
        )
        try:
            return normalize_active_combat_retreat_v1_order_ack(
                result,
                expected_selected_public_cunit_id=(
                    selected_public_cunit_id
                ),
                expected_snapshot_revision=expected_revision,
                expected_combat_id=expected_combat_id,
                expected_side_index=expected_side_index,
                expected_scope=expected_scope,
                expected_target_province_id=target_province_id,
                expected_candidate_token=candidate_token,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"active-combat retreat order ACK is malformed: {error}"
            ) from error

    def query_combat_simulation_inputs(
        self,
        target_province_id: int,
        attacker_entry_province_id: int | None,
        attacker_army_ids: list[int],
        defender_army_ids: list[int],
        *,
        expected_revision: int | None = None,
        constructor_adjacency_kind_raw: int | None = None,
    ) -> dict[str, object]:
        """Read exact-build inputs for one hypothetical contact scenario.

        ``available`` means only that all native observation domains needed by
        the documented combat model are present.  It never means that Monte
        Carlo simulation is ready.
        """
        target, entry, attackers, defenders = normalize_combat_simulation_request(
            target_province_id,
            attacker_entry_province_id,
            attacker_army_ids,
            defender_army_ids,
            constructor_adjacency_kind_raw=constructor_adjacency_kind_raw,
        )
        step = query_combat_simulation_inputs_step(
            target, entry, attackers, defenders,
            constructor_adjacency_kind_raw=constructor_adjacency_kind_raw,
        )
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "combat simulation input queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if isinstance(revision, bool) or not isinstance(revision, int):
            raise BridgeUnavailableError(
                "combat simulation input query lacks a valid snapshot revision"
            )
        if expected_revision is not None:
            if (
                isinstance(expected_revision, bool)
                or not isinstance(expected_revision, int)
                or expected_revision < 0
            ):
                raise ValueError(
                    "expected_revision must be a non-negative integer"
                )
            if expected_revision != revision:
                raise BridgeUnavailableError(
                    "combat simulation input revision mismatch: expected "
                    f"{expected_revision}, current {revision}"
                )
        try:
            encounter_scope = combat_simulation_encounter_scope(
                snapshot, attackers, defenders
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"combat simulation encounter scope is malformed: {error}"
            ) from error
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_COMBAT_SIMULATION_INPUTS_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query combat simulation inputs"
            )
        result = self.execute_step(
            step,
            expected_revision=(
                expected_revision
                if expected_revision is not None
                else revision
            ),
        )
        if not isinstance(result, dict):
            raise BridgeUnavailableError(
                "combat simulation input backend returned a non-object result"
            )
        required_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "combat_simulation_inputs",
            "backend_id",
        }
        optional_result_keys = {
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
        }
        if (
            not required_result_keys <= set(result)
            or set(result) - required_result_keys - optional_result_keys
            or result.get("step") != step
            or result.get("accepted") is not True
            or result.get("status") not in {"available", "partial"}
        ):
            raise BridgeUnavailableError(
                "combat simulation input backend returned a malformed result"
            )
        query_sequence = result.get("query_sequence")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "combat simulation input result lacks query_sequence"
            )
        try:
            normalized = normalize_combat_simulation_inputs(
                result.get("combat_simulation_inputs"),
                expected_target_province_id=target,
                expected_attacker_entry_province_id=entry,
                expected_constructor_adjacency_kind_raw=constructor_adjacency_kind_raw,
                expected_encounter_scope=encounter_scope,
            )
            status = combat_simulation_inputs_status(normalized)
        except ValueError as error:
            raise BridgeUnavailableError(
                f"combat simulation input result is malformed: {error}"
            ) from error
        if result.get("status") != status:
            raise BridgeUnavailableError(
                "combat simulation input status disagrees with "
                "input_observation_ready"
            )
        if (
            "queried_snapshot_id" in result
            and result.get("queried_snapshot_id")
            != snapshot.get("snapshot_id")
        ) or (
            "queried_revision" in result
            and result.get("queried_revision") != revision
        ) or (
            "queried_native_revision" in result
            and result.get("queried_native_revision")
            != snapshot.get("native_revision")
        ):
            raise BridgeUnavailableError(
                "combat simulation input result is bound to another snapshot"
            )
        current = self.snapshot()
        if not (
            current.get("paused") is True
            and current.get("revision") == revision
            and current.get("snapshot_id") == snapshot.get("snapshot_id")
            and current.get("native_revision")
            == snapshot.get("native_revision")
        ):
            raise BridgeUnavailableError(
                "combat simulation input query crossed a snapshot revision"
            )
        try:
            if combat_simulation_encounter_scope(
                current, attackers, defenders
            ) != encounter_scope:
                raise BridgeUnavailableError(
                    "combat simulation encounter scope changed during query"
                )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"combat simulation encounter scope became malformed: {error}"
            ) from error
        completeness = normalized["completeness"]
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello")
            if isinstance(diagnostics, dict)
            else None
        )
        return {
            **result,
            "schema_version": 2,
            "status": status,
            "scope": "explicit-hypothetical-active-war-contact",
            "source": {
                "game_version": (
                    hello.get("game_version")
                    if isinstance(hello, dict)
                    else None
                ),
                "executable_sha256": (
                    hello.get("executable_sha256")
                    if isinstance(hello, dict)
                    else None
                ),
                "snapshot_id": snapshot.get("snapshot_id"),
                "revision": revision,
                "native_revision": snapshot.get("native_revision"),
                "date_raw": snapshot.get("date_raw"),
                "paused": True,
                "backend_id": snapshot.get("backend_id"),
            },
            "target_province_id": target,
            "attacker_entry_province_id": entry,
            "attacker_army_ids": attackers,
            "defender_army_ids": defenders,
            "attacker_side": encounter_scope["attacker_side"],
            "defender_side": encounter_scope["defender_side"],
            "common_war_ids": encounter_scope["common_war_ids"],
            "input_observation_ready": completeness[
                "input_observation_ready"
            ],
            "monte_carlo_ready": completeness["monte_carlo_ready"],
            "missing_required_domains": copy.deepcopy(
                completeness["missing_required_domains"]
            ),
            "combat_simulation_inputs": normalized,
        }

    def query_combat_phase_event_trace_v1(
        self, combat_id: int, *, expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Read one live CombatID evaluator; never infer event occurrence or odds."""
        step = query_combat_phase_event_trace_v1_step(combat_id)
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError("combat phase-event trace requires paused map")
        revision = snapshot.get("revision")
        if isinstance(revision, bool) or not isinstance(revision, int) or revision <= 0:
            raise BridgeUnavailableError("combat phase-event trace lacks revision")
        if expected_revision is not None and expected_revision != revision:
            raise BridgeUnavailableError("combat phase-event expected revision differs")
        capabilities = self.capabilities().get("bridge_capabilities")
        if not isinstance(capabilities, list) or QUERY_COMBAT_PHASE_EVENT_TRACE_V1_CAPABILITY not in capabilities:
            raise UnsupportedStepError("backend cannot query native combat phase-event evaluator")
        result = self.execute_step(step, expected_revision=revision)
        if not isinstance(result, dict) or result.get("step") != step or result.get("accepted") is not True:
            raise BridgeUnavailableError("combat phase-event backend result is malformed")
        try:
            trace = normalize_combat_phase_event_trace_v1(
                result.get("combat_phase_event_trace"), combat_id=combat_id,
            )
        except ValueError as error:
            raise BridgeUnavailableError(f"combat phase-event result is malformed: {error}") from error
        if result.get("status") != (
            "evaluator_probe_available" if trace["evaluator_probe_ready"]
            else "unavailable"
        ):
            raise BridgeUnavailableError("combat phase-event status disagrees with trace")
        after = self.snapshot()
        if after.get("snapshot_id") != snapshot.get("snapshot_id") or after.get("revision") != revision or after.get("date_raw") != snapshot.get("date_raw"):
            raise BridgeUnavailableError("combat phase-event query crossed paused frame")
        return {
            **result,
            "combat_phase_event_trace": trace,
            "production_trace_ready": False,
            "qualified_win_probability_available": False,
        }

    def query_combat_simulation_inputs_v3(
        self,
        target_province_id: int,
        attacker_entry_province_id: int | None,
        attacker_army_ids: list[int],
        defender_army_ids: list[int],
        *,
        expected_revision: int | None = None,
        constructor_adjacency_kind_raw: int | None = None,
    ) -> dict[str, object]:
        """Read and offline-normalize the exact 132-ref phase-event slice."""
        target, entry, attackers, defenders = normalize_combat_simulation_request(
            target_province_id,
            attacker_entry_province_id,
            attacker_army_ids,
            defender_army_ids,
            constructor_adjacency_kind_raw=constructor_adjacency_kind_raw,
        )
        step = query_combat_simulation_inputs_v3_step(
            target, entry, attackers, defenders,
            constructor_adjacency_kind_raw=constructor_adjacency_kind_raw,
        )
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "production combat phase queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if isinstance(revision, bool) or not isinstance(revision, int):
            raise BridgeUnavailableError(
                "production combat phase query lacks a valid snapshot revision"
            )
        if expected_revision is not None:
            if (
                isinstance(expected_revision, bool)
                or not isinstance(expected_revision, int)
                or expected_revision < 0
            ):
                raise ValueError(
                    "expected_revision must be a non-negative integer"
                )
            if expected_revision != revision:
                raise BridgeUnavailableError(
                    "production combat phase revision mismatch: expected "
                    f"{expected_revision}, current {revision}"
                )
        try:
            encounter_scope = combat_simulation_encounter_scope(
                snapshot, attackers, defenders
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"production combat phase encounter scope is malformed: {error}"
            ) from error
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_COMBAT_SIMULATION_INPUTS_V3_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query production combat phase inputs"
            )
        result = self.execute_step(
            step,
            expected_revision=(
                expected_revision
                if expected_revision is not None
                else revision
            ),
        )
        if not isinstance(result, dict):
            raise BridgeUnavailableError(
                "production combat phase backend returned a non-object result"
            )
        required_result_keys = {
            "step",
            "accepted",
            "status",
            "query_sequence",
            "combat_simulation_inputs",
            "backend_id",
        }
        optional_result_keys = {
            "queried_snapshot_id",
            "queried_revision",
            "queried_native_revision",
        }
        if (
            not required_result_keys <= set(result)
            or set(result) - required_result_keys - optional_result_keys
            or result.get("step") != step
            or result.get("accepted") is not True
            or result.get("status") not in {"available", "unavailable"}
        ):
            raise BridgeUnavailableError(
                "production combat phase backend returned a malformed result"
            )
        query_sequence = result.get("query_sequence")
        if (
            isinstance(query_sequence, bool)
            or not isinstance(query_sequence, int)
            or not 1 <= query_sequence <= 2**64 - 1
        ):
            raise BridgeUnavailableError(
                "production combat phase result lacks query_sequence"
            )
        try:
            normalized = normalize_combat_simulation_inputs_v3(
                result.get("combat_simulation_inputs"),
                expected_target_province_id=target,
                expected_attacker_entry_province_id=entry,
                expected_constructor_adjacency_kind_raw=constructor_adjacency_kind_raw,
                expected_encounter_scope=encounter_scope,
            )
            status = combat_simulation_inputs_v3_status(normalized)
        except ValueError as error:
            raise BridgeUnavailableError(
                f"production combat phase result is malformed: {error}"
            ) from error
        if result.get("status") != status:
            raise BridgeUnavailableError(
                "production combat phase status disagrees with "
                "phase_event_inputs_ready"
            )
        if (
            "queried_snapshot_id" in result
            and result.get("queried_snapshot_id")
            != snapshot.get("snapshot_id")
        ) or (
            "queried_revision" in result
            and result.get("queried_revision") != revision
        ) or (
            "queried_native_revision" in result
            and result.get("queried_native_revision")
            != snapshot.get("native_revision")
        ):
            raise BridgeUnavailableError(
                "production combat phase result is bound to another snapshot"
            )
        current = self.snapshot()
        if not (
            current.get("paused") is True
            and current.get("revision") == revision
            and current.get("snapshot_id") == snapshot.get("snapshot_id")
            and current.get("native_revision")
            == snapshot.get("native_revision")
            and current.get("episode_run_id")
            == snapshot.get("episode_run_id")
        ):
            raise BridgeUnavailableError(
                "production combat phase query crossed a snapshot revision"
            )
        try:
            if combat_simulation_encounter_scope(
                current, attackers, defenders
            ) != encounter_scope:
                raise BridgeUnavailableError(
                    "production combat phase encounter scope changed during query"
                )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"production combat phase scope became malformed: {error}"
            ) from error
        completeness = normalized["completeness"]
        loaded_playset_proof = self._loaded_playset_proof_for_snapshot(
            current
        )
        loaded_playset_verified = (
            loaded_playset_proof.get("status") == "verified"
            and isinstance(loaded_playset_proof.get("claims"), dict)
            and loaded_playset_proof["claims"].get(
                "loaded_playset_verified"
            )
            is True
        )
        phase_event_manifest_fidelity = copy.deepcopy(
            completeness["phase_event_manifest_fidelity"]
        )
        phase_event_manifest_fidelity["loaded_playset_verified"] = (
            loaded_playset_verified
        )
        phase_event_manifest_fidelity["fidelity_gate"] = all(
            phase_event_manifest_fidelity.get(key) is True
            for key in (
                "loaded_playset_verified",
                "ast_evaluator_ready",
                "original_trace_ready",
            )
        )
        missing_fidelity_gates = [
            key
            for key in completeness["missing_fidelity_gates"]
            if key != "loaded_playset_verified" or not loaded_playset_verified
        ]
        diagnostics = snapshot.get("diagnostics")
        hello = (
            diagnostics.get("hello")
            if isinstance(diagnostics, dict)
            else None
        )
        return {
            **result,
            "schema_version": 3,
            "status": status,
            "scope": "explicit-hypothetical-active-war-contact",
            "source": {
                "game_version": (
                    hello.get("game_version")
                    if isinstance(hello, dict)
                    else None
                ),
                "executable_sha256": (
                    hello.get("executable_sha256")
                    if isinstance(hello, dict)
                    else None
                ),
                "snapshot_id": snapshot.get("snapshot_id"),
                "revision": revision,
                "native_revision": snapshot.get("native_revision"),
                "date_raw": snapshot.get("date_raw"),
                "paused": True,
                "backend_id": snapshot.get("backend_id"),
            },
            "target_province_id": target,
            "attacker_entry_province_id": entry,
            "attacker_army_ids": attackers,
            "defender_army_ids": defenders,
            "attacker_side": encounter_scope["attacker_side"],
            "defender_side": encounter_scope["defender_side"],
            "common_war_ids": encounter_scope["common_war_ids"],
            "base_input_observation_ready": completeness[
                "base_input_observation_ready"
            ],
            "phase_raw_observation_ready": completeness[
                "phase_raw_observation_ready"
            ],
            "offline_exact_state_refs_ready": completeness[
                "offline_exact_state_refs_ready"
            ],
            "phase_event_inputs_ready": completeness[
                "phase_event_inputs_ready"
            ],
            "input_observation_ready": completeness[
                "input_observation_ready"
            ],
            "monte_carlo_ready": completeness["monte_carlo_ready"],
            "transition_fidelity_gate": completeness[
                "transition_fidelity_gate"
            ],
            "planner_usable": completeness["planner_usable"],
            "active_attack_allowed": completeness[
                "active_attack_allowed"
            ],
            "phase_event_manifest_fidelity": phase_event_manifest_fidelity,
            "loaded_playset_proof": loaded_playset_proof,
            "missing_observation_domains": copy.deepcopy(
                completeness["missing_observation_domains"]
            ),
            "missing_fidelity_gates": missing_fidelity_gates,
            "missing_required_domains": copy.deepcopy(
                completeness["missing_required_domains"]
            ),
            "combat_simulation_inputs": normalized,
        }

    def query_war_entry_assessments(
        self,
        target_character_ids: list[int],
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Read native strategic power for one current war-related target."""
        # Reject an over-broad public request before reading a snapshot or
        # entering any driver/pipe path. The first production contract is
        # one-target end to end.
        targets = normalize_war_entry_target_ids(target_character_ids)
        snapshot = self.snapshot()
        if snapshot.get("paused") is not True:
            raise BridgeUnavailableError(
                "war-entry assessment queries require a paused CK3 snapshot"
            )
        revision = snapshot.get("revision")
        if isinstance(revision, bool) or not isinstance(revision, int):
            raise BridgeUnavailableError(
                "war-entry assessment query lacks a valid snapshot revision"
            )
        if expected_revision is not None:
            if (
                isinstance(expected_revision, bool)
                or not isinstance(expected_revision, int)
                or expected_revision < 0
            ):
                raise ValueError(
                    "expected_revision must be a non-negative integer"
                )
            if expected_revision != revision:
                raise BridgeUnavailableError(
                    "war-entry assessment revision mismatch: expected "
                    f"{expected_revision}, current {revision}"
                )
        try:
            targets = require_war_entry_assessment_targets(
                snapshot, targets
            )
            target_scopes = war_entry_assessment_target_scopes(
                snapshot, targets
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"war-entry assessment target scope is malformed: {error}"
            ) from error
        capabilities = self.capabilities()
        bridge_capabilities = capabilities.get("bridge_capabilities")
        if not (
            isinstance(bridge_capabilities, list)
            and QUERY_WAR_ENTRY_ASSESSMENTS_CAPABILITY
            in bridge_capabilities
        ):
            raise UnsupportedStepError(
                "selected backend cannot query native war-entry assessments"
            )
        step = query_war_entry_assessments_step(targets)
        result = self.execute_step(
            step,
            expected_revision=(
                expected_revision
                if expected_revision is not None
                else revision
            ),
        )
        played_character = snapshot.get("played_character")
        actor_id = (
            played_character.get("character_id")
            if isinstance(played_character, dict)
            else None
        )
        native_revision = snapshot.get("native_revision")
        try:
            normalized = normalize_war_entry_assessments(
                result.get("war_entry_assessments"),
                expected_target_character_ids=targets,
                expected_actor_character_id=actor_id,
                expected_snapshot_revision=native_revision,
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"native war-entry assessment result is malformed: {error}"
            ) from error
        current = self.snapshot()
        if not (
            current.get("paused") is True
            and current.get("snapshot_id") == snapshot.get("snapshot_id")
            and current.get("revision") == revision
            and current.get("native_revision") == native_revision
            and current.get("episode_run_id")
            == snapshot.get("episode_run_id")
        ):
            raise BridgeUnavailableError(
                "war-entry assessment query crossed a snapshot revision"
            )
        try:
            current_scopes = war_entry_assessment_target_scopes(
                current, targets
            )
        except ValueError as error:
            raise BridgeUnavailableError(
                f"war-entry target scope changed during query: {error}"
            ) from error
        if current_scopes != target_scopes:
            raise BridgeUnavailableError(
                "war-entry target scope changed during query"
            )
        return {
            **result,
            "schema_version": 1,
            "status": "available",
            "target_character_ids": targets,
            "target_scopes": target_scopes,
            "war_entry_assessments": normalized,
            "queried_snapshot_id": snapshot.get("snapshot_id"),
            "queried_revision": revision,
            "queried_native_revision": native_revision,
        }

    def surrender_war(
        self,
        war_id: int,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Submit a query-proven surrender; never infer it from war score."""
        step = surrender_war_step(war_id)
        return {
            **self._execute_typed_war_step(
                step, expected_revision=expected_revision
            ),
            "war_id": war_id,
        }

    def offer_white_peace(
        self,
        war_id: int,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, object]:
        """Submit white peace only when native support and query both prove it."""
        step = offer_white_peace_step(war_id)
        return {
            **self._execute_typed_war_step(
                step, expected_revision=expected_revision
            ),
            "war_id": war_id,
        }

    def _execute_typed_war_step(
        self, step: str, *, expected_revision: int | None
    ) -> dict[str, object]:
        if step not in action_step_set(self.capabilities()):
            raise UnsupportedStepError(
                f"selected backend does not implement native war step {step}"
            )
        snapshot = self.snapshot()
        selected_revision = (
            expected_revision
            if expected_revision is not None
            else int(snapshot["revision"])
        )
        return self.execute_step(step, expected_revision=selected_revision)

    def wait_for_change(
        self, after_revision: int, *, timeout_seconds: float
    ) -> dict[str, object]:
        return self.driver.wait_for_change(
            after_revision, timeout_seconds=timeout_seconds
        )


    def query_current_battle_knight_v1(
        self,
        *,
        subject_public_cunit_id: int,
        character_id: int,
        regiment_id: int,
        expected_played_character_id: int,
        expected_war_id: int,
        expected_native_carmy_id: int,
        expected_combat_id: int,
        expected_province_id: int,
        expected_date_raw: int,
        expected_revision: int,
        expected_native_revision: int,
        expected_snapshot_id: str,
    ) -> dict[str, object]:
        """Read one paired current knight/regiment on a pinned paused frame."""
        reader = getattr(self.driver, "query_current_battle_knight_v1", None)
        if not callable(reader):
            raise UnsupportedStepError(
                "selected backend has no current-battle-knight native reader"
            )
        return reader(
            subject_public_cunit_id=subject_public_cunit_id,
            character_id=character_id,
            regiment_id=regiment_id,
            expected_played_character_id=expected_played_character_id,
            expected_war_id=expected_war_id,
            expected_native_carmy_id=expected_native_carmy_id,
            expected_combat_id=expected_combat_id,
            expected_province_id=expected_province_id,
            expected_date_raw=expected_date_raw,
            expected_revision=expected_revision,
            expected_native_revision=expected_native_revision,
            expected_snapshot_id=expected_snapshot_id,
        )


def _title_map_navigation_binding(
    snapshot: object,
) -> dict[str, object]:
    if not isinstance(snapshot, dict):
        raise ValueError("snapshot must be an object")
    diagnostics = snapshot.get("diagnostics")
    connection_generation = (
        diagnostics.get("connection_generation")
        if isinstance(diagnostics, dict)
        else None
    )
    return normalize_title_map_navigation_v1_binding(
        {
            "snapshot_id": snapshot.get("snapshot_id"),
            "revision": snapshot.get("revision"),
            "native_revision": snapshot.get("native_revision"),
            "date_raw": snapshot.get("date_raw"),
            "episode_run_id": snapshot.get("episode_run_id"),
            "connection_generation": connection_generation,
        }
    )


def _coat_of_arms_source_probe_binding(
    snapshot: object,
) -> dict[str, object]:
    if not isinstance(snapshot, dict):
        raise ValueError("snapshot must be an object")
    diagnostics = snapshot.get("diagnostics")
    connection_generation = (
        diagnostics.get("connection_generation")
        if isinstance(diagnostics, dict)
        else None
    )
    bridge_pid = (
        diagnostics.get("bridge_pid")
        if isinstance(diagnostics, dict)
        else None
    )
    common = {
        "snapshot_id": snapshot.get("snapshot_id"),
        "revision": snapshot.get("revision"),
        "native_revision": snapshot.get("native_revision"),
        "date_raw": snapshot.get("date_raw"),
        "connection_generation": connection_generation,
        "bridge_pid": bridge_pid,
    }
    if (
        snapshot.get("played_character") is None
        and snapshot.get("episode_run_id") is None
    ):
        return normalize_coat_of_arms_source_v1_binding(
            {"mode": "frontend_snapshot", **common}
        )
    return normalize_coat_of_arms_source_v1_binding(
        {
            "mode": "gameplay",
            **common,
            "episode_run_id": snapshot.get("episode_run_id"),
        }
    )


def _route_plan_to_available_step(
    plan: dict[str, object], available_steps: set[str]
) -> dict[str, object]:
    """Keep a partial native backend playing instead of dispatching unsupported work."""
    selected = plan.get("selected_step")
    if not isinstance(selected, str) or selected in available_steps:
        return plan
    fail_closed_prefixes = (
        "declare-war-",
        "war-declare-",
        "offer-white-peace-",
        "surrender-war-",
        "query-war-termination-options-",
        "query-war-termination-terms-v1-",
        "query-war-termination-exit-terms-v2-",
        "query-combat-simulation-inputs-v2-",
        "query-combat-simulation-inputs-v3-",
        "query-war-entry-assessments-v1-",
        "enforce-demands-",
    )
    if (
        selected
        in {"death-terminal", "strategy-review", "resolve-current-event"}
        or selected.startswith(fail_closed_prefixes)
    ):
        return {
            **plan,
            "selected_step": None,
            "required_step": selected,
            "reason": f"selected backend does not implement required step {selected}",
        }
    if "life-advance" in available_steps:
        return {
            **plan,
            "phase": "capability_progress",
            "deferred_phase": plan.get("phase"),
            "selected_step": "life-advance",
            "required_step": selected,
            "reason": (
                f"selected backend does not yet implement {selected}; "
                "continue the current life through native events"
            ),
        }
    return {
        **plan,
        "selected_step": None,
        "required_step": selected,
        "reason": f"selected backend does not implement gameplay step {selected}",
    }
