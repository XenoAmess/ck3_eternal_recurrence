from pathlib import Path
import json, hashlib

OUT=Path(__file__).resolve().parent
BEFORE=OUT/'before'
CANDIDATE=OUT/'candidate'
BRIDGE='ck3_autonomous_player/src/xar_autoplayer/bridge/'

def original(rel):return (BEFORE/rel).read_text(encoding='utf-8')
def replace_once(text,old,new):
 if text.count(old)!=1:raise AssertionError((old[:180],text.count(old)))
 return text.replace(old,new,1)
def put(rel,text):
 p=CANDIDATE/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding='utf-8',newline='')

# Keep the old fixed vivhite Confirm intact. The generic route has its own
# native capability and independently verified UI-outcome contract.
rel=BRIDGE+'native_driver.py';text=original(rel)
text=replace_once(text,'        claim_dir = self._native_driver_state_path().parent / "ingame-decision-item-actions"\n        identity = ',
 '        claim_dir = self._native_driver_state_path().parent / "ingame-decision-item-actions"\n'
 '        from .ingame_decision_outcome_contract import reject_unresolved_claims, preserve_verified_claim\n        identity = ')
text=replace_once(text,'"episode_run_id": binding["episode_run_id"], "decision_key": decision_key, "action": action}\n        key = ',
 '"episode_run_id": binding["episode_run_id"], "decision_key": decision_key, "action": action}\n'
 '        if action == "select":\n'
 '            identity["public_revision"] = revision\n'
 '        try:\n'
 '            reject_unresolved_claims(claim_dir, identity)\n'
 '        except ValueError as error:\n'
 '            raise BridgeUnavailableError(str(error)) from error\n        key = ')
text=replace_once(text,'"binding": binding, "decision_key": decision_key, "action": action,\n',
 '"binding": binding, "action_identity": identity, "decision_key": decision_key, "action": action,\n')
needle='                           "queried_revision": revision, "uses_mouse": False, "uses_keyboard": False, "uses_ocr": False})\n        except Exception as error:'
if text.count(needle)!=2:raise AssertionError('two distinct selection/opener tails required')
text=text.replace(needle,needle.replace('\n        except','\n            preserve_verified_claim(claim, request_id, result)\n        except'),1)
text=replace_once(text,'        claim_dir = self._native_driver_state_path().parent / "ingame-decisions-opener-actions"\n        claim_dir.mkdir(parents=True, exist_ok=True)\n        identity = {"game_pid": binding["game_pid"], "actor_id": binding["played_character_id"],\n                    "episode_run_id": binding["episode_run_id"]}\n',
 '        claim_dir = self._native_driver_state_path().parent / "ingame-decisions-opener-actions"\n'
 '        from .ingame_decision_outcome_contract import reject_unresolved_claims, preserve_verified_claim\n'
 '        claim_dir.mkdir(parents=True, exist_ok=True)\n'
 '        identity = {"game_pid": binding["game_pid"], "actor_id": binding["played_character_id"],\n'
 '                    "episode_run_id": binding["episode_run_id"], "decision_key": "",\n'
 '                    "action": "open", "public_revision": revision}\n'
 '        try:\n'
 '            reject_unresolved_claims(claim_dir, identity)\n'
 '        except ValueError as error:\n'
 '            raise BridgeUnavailableError(str(error)) from error\n')
text=replace_once(text,'                      "binding": binding, "status": "claimed_result_unknown_no_retry"}',
 '                      "binding": binding, "action_identity": identity, "status": "claimed_result_unknown_no_retry"}')
text=replace_once(text,needle,needle.replace('\n        except','\n            preserve_verified_claim(claim, request_id, result)\n        except'))
text=replace_once(text,'    def _decision_item_action_v1(',
 (OUT/'authored/driver_method.pyfrag').read_text(encoding='utf-8')+'    def _decision_item_action_v1(')
put(rel,text)

rel=BRIDGE+'service.py';text=original(rel)
method='''    def confirm_ingame_decision_outcome_v1(self, decision_key: str, expected_outcome: str, *,
                                          expected_event_definition_key: str | None = None,
                                          expected_revision: int) -> dict[str, object]:
        from .ingame_decision_item_contract import validate_decision_key
        from .ingame_decisions_open_contract import opening_binding
        from .ingame_decision_outcome_contract import (
            SCHEMA, validate_expected_outcome, normalize_outcome_ack, outcome_frame_matches,
            actual_expected_event, actual_closed_decision_detail,
        )
        validate_decision_key(decision_key)
        event_key = validate_expected_outcome(expected_outcome, expected_event_definition_key)
        if type(expected_revision) is not int or expected_revision < 0:
            raise ValueError("expected_revision must be a nonnegative integer")
        method = getattr(self.driver, "confirm_ingame_decision_outcome_v1", None)
        if not callable(method):
            raise UnsupportedStepError("selected backend lacks the typed generic decision Confirm")
        before = self.driver.take_snapshot()
        try:
            binding = opening_binding(before)
        except ValueError as error:
            raise BridgeUnavailableError(str(error)) from error
        if before.get("revision") != expected_revision:
            raise BridgeUnavailableError("generic Confirm expected public revision is stale")
        result = method(decision_key, expected_outcome,
                        expected_event_definition_key=expected_event_definition_key,
                        expected_revision=expected_revision)
        if (not isinstance(result, dict) or result.get("schema") != SCHEMA
                or result.get("decision_key") != decision_key
                or result.get("expected_outcome") != expected_outcome
                or result.get("expected_event_definition_key") != event_key
                or result.get("postcondition_verified") is not True
                or result.get("verification_pending") is not False
                or result.get("business_effects_verified") is not False
                or result.get("full_product_acceptance_credit") is not False
                or result.get("front_event_verified") is not False
                or result.get("event_option_selection_authorized") is not False):
            raise BridgeUnavailableError("generic Confirm lacks independent UI-outcome proof")
        try:
            normalize_outcome_ack(result.get("native_ack"), binding, decision_key, expected_outcome, event_key)
        except ValueError as error:
            raise BridgeUnavailableError(str(error)) from error
        after = result.get("snapshot_after")
        if not isinstance(after, dict) or not outcome_frame_matches(before, after, binding):
            raise BridgeUnavailableError("generic Confirm later owner/date/connection binding changed")
        observation = result.get("later_actual_observation")
        verified = (actual_expected_event(observation, after, binding, event_key)
                    if expected_outcome == "event_window" else
                    after.get("active_event") is None and actual_closed_decision_detail(observation))
        if not verified:
            raise BridgeUnavailableError("generic Confirm later observation does not prove the requested outcome")
        return result

'''
text=replace_once(text,'    def query_aub_business_state_v1(',method+'    def query_aub_business_state_v1(')
put(rel,text)

rel=BRIDGE+'mcp_server.py';text=original(rel)
method='''    @server.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=False))
    def ck3_confirm_ingame_decision_outcome_v1(
        decision_key: str, expected_outcome: Literal["event_window", "decision_closed"],
        expected_revision: int, expected_event_definition_key: str | None = None,
    ) -> dict[str, object]:
        """Confirm the actual selected player decision once and read its declared UI outcome; business acceptance remains separate."""
        return service.confirm_ingame_decision_outcome_v1(
            decision_key, expected_outcome, expected_revision=expected_revision,
            expected_event_definition_key=expected_event_definition_key)

'''
text=replace_once(text,'    @server.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=False))\n    def ck3_click_white_numeric_control_v1(',method+'    @server.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=False))\n    def ck3_click_white_numeric_control_v1(')
text=replace_once(text,'    _forbid_unknown_tool_arguments_v1(server, "ck3_confirm_ingame_decision_item_v1")',
 '    _forbid_unknown_tool_arguments_v1(server, "ck3_confirm_ingame_decision_item_v1")\n'
 '    _forbid_unknown_tool_arguments_v1(server, "ck3_confirm_ingame_decision_outcome_v1")')
put(rel,text)

rel='tools/ck3_native_profile_mcp.py';text=original(rel)
methods='''    def query_decision(self, decision_key: str, expected_revision: int) -> dict:
        with self._lock:
            self._bound_frame(expected_revision, paused=True)
            result = self._gameplay_service().query_ingame_decision_item_v1(
                decision_key, expected_revision=expected_revision)
            self._bound_frame(expected_revision, paused=True)
            return self._receipt("decision-query", {"status": "native_decision_query_observed", "result": result,
                "business_effects_verified": False, "full_product_acceptance_credit": False})

    def decision_action(self, action: str, expected_revision: int, *, decision_key: str | None = None,
                        expected_outcome: str | None = None,
                        expected_event_definition_key: str | None = None) -> dict:
        from xar_autoplayer.bridge.ingame_decision_item_contract import validate_decision_key
        from xar_autoplayer.bridge.ingame_decision_outcome_contract import (
            SCHEMA, validate_expected_outcome, actual_expected_event, actual_closed_decision_detail,
        )
        if action not in {"open", "select", "confirm_outcome"}:
            raise ValueError("unsupported typed profile decision action")
        if action != "open":
            validate_decision_key(decision_key)
        if action == "confirm_outcome":
            validate_expected_outcome(expected_outcome, expected_event_definition_key)
        def invoke(gameplay):
            if action == "open":
                return gameplay.open_ingame_decisions_v1(expected_revision=expected_revision)
            if action == "select":
                return gameplay.select_ingame_decision_item_v1(decision_key, expected_revision=expected_revision)
            return gameplay.confirm_ingame_decision_outcome_v1(
                decision_key, expected_outcome, expected_event_definition_key=expected_event_definition_key,
                expected_revision=expected_revision)
        def verify(result, before, after):
            if (not isinstance(result, dict) or result.get("postcondition_verified") is not True
                    or result.get("verification_pending") is not False):
                raise _PostconditionPending("profile decision dispatch lacks an independently observed UI outcome")
            actor = before.get("played_character", {}).get("character_id")
            if (type(actor) is not int or actor <= 0
                    or before.get("played_character", {}).get("alive") is not True
                    or after.get("paused") is not True or before.get("date_raw") != after.get("date_raw")
                    or before.get("speed") != after.get("speed")
                    or before.get("played_character", {}).get("character_id") != after.get("played_character", {}).get("character_id")):
                raise RuntimeError("profile decision outcome changed its actor/date/paused frame")
            if action != "open" and result.get("decision_key") != decision_key:
                raise RuntimeError("profile decision outcome changed its actual definition")
            if action == "confirm_outcome":
                expected_key = expected_event_definition_key if expected_outcome == "event_window" else ""
                if (result.get("schema") != SCHEMA or result.get("action") != "confirm_outcome"
                        or result.get("expected_outcome") != expected_outcome
                        or result.get("expected_event_definition_key") != expected_key
                        or result.get("business_effects_verified") is not False
                        or result.get("full_product_acceptance_credit") is not False
                        or result.get("front_event_verified") is not False
                        or result.get("event_option_selection_authorized") is not False):
                    raise RuntimeError("profile generic Confirm returned a mismatched or overcredited outcome")
                proved = result.get("snapshot_after")
                if (not isinstance(proved, dict) or proved.get("active_event") != after.get("active_event")
                        or proved.get("native_revision") != after.get("native_revision")
                        or proved.get("revision") != after.get("revision")):
                    raise RuntimeError("profile generic Confirm actual readback no longer matches the current event frame")
                binding = {"date_raw": before["date_raw"], "played_character_id": actor}
                observation = result.get("later_actual_observation")
                verified = (actual_expected_event(observation, after, binding, expected_key)
                            if expected_outcome == "event_window" else
                            after.get("active_event") is None and actual_closed_decision_detail(observation))
                if not verified:
                    raise RuntimeError("profile generic Confirm lacks its actual declared outcome observation")
        return self._ordinary_action("decision-" + action, expected_revision, invoke, verify, paused=True)

'''
text=replace_once(text,'    def query_pending_interaction(',methods+'    def query_pending_interaction(')
tools='''    @server.tool(annotations=ToolAnnotations(readOnlyHint=True))
    def ck3_query_profile_decision_item_v1(decision_key: str, expected_revision: int) -> dict[str, object]:
        return service.query_decision(decision_key, expected_revision)
    @server.tool(annotations=ToolAnnotations(readOnlyHint=False, idempotentHint=False))
    def ck3_open_profile_decisions_v1(expected_revision: int) -> dict[str, object]:
        return service.decision_action("open", expected_revision)
    @server.tool(annotations=ToolAnnotations(readOnlyHint=False, idempotentHint=False))
    def ck3_select_profile_decision_item_v1(decision_key: str, expected_revision: int) -> dict[str, object]:
        return service.decision_action("select", expected_revision, decision_key=decision_key)
    @server.tool(annotations=ToolAnnotations(readOnlyHint=False, idempotentHint=False))
    def ck3_confirm_profile_decision_outcome_v1(
        decision_key: str, expected_outcome: Literal["event_window", "decision_closed"],
        expected_revision: int, expected_event_definition_key: str | None = None,
    ) -> dict[str, object]:
        return service.decision_action("confirm_outcome", expected_revision, decision_key=decision_key,
            expected_outcome=expected_outcome, expected_event_definition_key=expected_event_definition_key)
'''
text=replace_once(text,'    for name in ("ck3_query_native_profile_v1"',tools+'    for name in ("ck3_query_profile_decision_item_v1", "ck3_open_profile_decisions_v1",\n                 "ck3_select_profile_decision_item_v1", "ck3_confirm_profile_decision_outcome_v1",\n                 "ck3_query_native_profile_v1"')
put(rel,text)

rel='tools/test_ck3_native_profile_mcp.py';text=original(rel)
text=replace_once(text,'                    "ck3_select_profile_event_option_v1", "ck3_save_profile_checkpoint_v1"})',
 '                    "ck3_select_profile_event_option_v1", "ck3_save_profile_checkpoint_v1",\n'
 '                    "ck3_query_profile_decision_item_v1", "ck3_open_profile_decisions_v1",\n'
 '                    "ck3_select_profile_decision_item_v1", "ck3_confirm_profile_decision_outcome_v1"})')
put(rel,text)

items=[]
for p in sorted(CANDIDATE.rglob('*')):
 if p.is_file():
  rel=p.relative_to(CANDIDATE).as_posix();before=BEFORE/rel
  items.append({'target':rel,'before_sha256':hashlib.sha256(before.read_bytes()).hexdigest() if before.is_file() else None,
                'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size})
(OUT/'DELTA.json').write_text(json.dumps(items,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'candidate_files':len(items),'delta':'DELTA.json'},indent=2))
