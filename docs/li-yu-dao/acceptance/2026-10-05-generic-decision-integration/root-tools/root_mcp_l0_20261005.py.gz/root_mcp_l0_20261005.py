from pathlib import Path
import os,sys,unittest,importlib,json,subprocess,hashlib
sys.stdout.reconfigure(encoding='utf-8')
root=Path(r'C:/workspace/ck3_eternal_recurrence')
out=Path(r'C:/workspace/ck3_lyd_runtime_20261004/root-mcp-integration-l0-20261005-001')
out.mkdir(exist_ok=False)
sys.dont_write_bytecode=True
sys.path[:0]=[str(root/'ck3_autonomous_player/src'),str(root/'ck3_autonomous_player/tests/unit'),str(root/'tools')]
for key,name in [('XAR_DECISION_OUTCOME_TEST_ARTIFACTS','claims'),('XAR_WHITE_DECISION_ACTION_TEST_ARTIFACTS','legacy-claims'),('XAR_WHITE_DECISIONS_TEST_ARTIFACTS','opener-claims')]:os.environ[key]='\\\\?\\'+str((out/name).resolve())
names=['test_ingame_decision_outcomes','test_ingame_decision_item_actions','test_ingame_decisions_open_contract']
suite=unittest.TestSuite()
for name in names:suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(importlib.import_module(name)))
with (out/'tests.log').open('w',encoding='utf-8') as f:result=unittest.TextTestRunner(stream=f,verbosity=2).run(suite)
report={'schema':'root-mcp-integrated-source-l0-v1','status':'PASS' if result.wasSuccessful() else 'RED','scope':'synthetic SDK/driver/claims, no DLL injection and no game','source_head_before_uncommitted_import':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'tests_run_this_runner':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'actual_modules':{n:sys.modules[n].__file__ for n in names},'previous_direct_profile_test':{'command':[sys.executable,'tools/test_ck3_native_profile_mcp.py'],'test_count':18,'exit_code':0,'evidence_type':'actual preceding tool call, direct stdout transcript'},'initial_direct_new_test_environment_error':{'command':[sys.executable,'ck3_autonomous_player/tests/unit/test_ingame_decision_outcomes.py'],'exit_code':1,'reason':'source package missing from direct sys.path; corrected via explicit checked-in source path, not a product failure'},'native_game':'NOT_RUN'}
(out/'REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
if not result.wasSuccessful():print((out/'tests.log').read_text(encoding='utf-8'))
raise SystemExit(0 if result.wasSuccessful() else 1)
