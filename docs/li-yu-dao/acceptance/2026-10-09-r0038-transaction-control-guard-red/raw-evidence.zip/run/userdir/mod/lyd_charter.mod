﻿name="Li Yu Dao R7 native charter primitive fixture"
version="0.0.1-external"
supported_version="1.20.*"
tags={ "Utilities" }
path="C:/workspace/ck3_lyd_runtime_20261004/live-attempt-038/content/charter"
