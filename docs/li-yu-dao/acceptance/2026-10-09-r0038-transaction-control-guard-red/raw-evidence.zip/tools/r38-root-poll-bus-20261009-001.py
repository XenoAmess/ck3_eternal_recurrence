from pathlib import Path
import json
import subprocess
import sys

run=Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-038')
task='lyd-r0038-transaction-only-diagnostic-live-root'
out=run/'PRELAUNCH-POLL.actual.json'
assert not out.exists()
r=subprocess.run([sys.executable,'-B','-X','utf8','C:/workspace/ck3_eternal_recurrence/tools/codex_task_bus.py','--bus-dir','C:/workspace/.codex-task-bus','--expected-cli-sha256','B3C44B42F7BDF401B593D863E3210106A46412DCD7D89F8596C74F4C27392DEE','poll','--task',task,'--ack','--limit','100'],capture_output=True,check=True,timeout=15)
obj=json.loads(r.stdout)
with out.open('xb') as f:f.write(r.stdout)
events=obj.get('events',obj.get('notifications',[]))
print(json.dumps({'keys':list(obj),'event_count':len(events),'events':[{'sequence':e.get('sequence'),'task_id':e.get('task_id'),'kind':e.get('kind'),'summary':e.get('summary'),'next_step':e.get('next_step')} for e in events]},ensure_ascii=False))
