from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,win32api,win32con,pyautogui
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
folder=B/'r38-root-steam-offline-final-20261009-001'
p=folder/'probe-1/steam-moved.png'
def put(p,obj):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n')
put(folder/'OFFLINE-REVIEW.actual.json',{'utc':datetime.now(timezone.utc).isoformat(),'image':'probe-1/steam-moved.png','image_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'steam_offline_confirmed':True,'review_method':'root directly viewed original 1920x1080 screenshot; bottom centre reads 离线模式'})
original=json.loads((B/'r38-root-display-fit-20261009-001.json').read_bytes())['before']
def describe(mode):return {'width':mode.PelsWidth,'height':mode.PelsHeight,'bits':mode.BitsPerPel,'frequency':mode.DisplayFrequency}
before=describe(win32api.EnumDisplaySettings(None,win32con.ENUM_CURRENT_SETTINGS))
chosen=None
for index in range(1000):
 try:mode=win32api.EnumDisplaySettings(None,index)
 except Exception:break
 if describe(mode)==original:chosen=mode;break
if chosen is None:raise RuntimeError('Original display mode not enumerated')
if win32api.ChangeDisplaySettingsEx(None,chosen,win32con.CDS_TEST)!=0:raise RuntimeError('Original display mode test failed')
rc=win32api.ChangeDisplaySettingsEx(None,chosen,0)
after=describe(win32api.EnumDisplaySettings(None,win32con.ENUM_CURRENT_SETTINGS))
size=list(pyautogui.size())
put(B/'r38-root-display-restore-20261009-001.json',{'utc':datetime.now(timezone.utc).isoformat(),'before':before,'original':original,'change_result':rc,'after':after,'pyautogui_size':size,'registry_persistence_requested':False})
if rc!=0 or after!=original or size!=[original['width'],original['height']]:raise RuntimeError('Display actual readback mismatch')
put(B/'r38-root-screen-keeper-20261009-001/STOP.request',{'reason':'R38 diagnostic incomplete; game normal exit0, client closed, offline reviewed, original display restored'})
print(json.dumps({'display_restored':after,'keeper_stop_requested':True}))
