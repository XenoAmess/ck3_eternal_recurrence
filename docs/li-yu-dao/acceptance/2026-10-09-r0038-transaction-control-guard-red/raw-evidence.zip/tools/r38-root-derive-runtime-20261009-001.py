"""Derive new R38 inputs; keep R37 interrupted evidence and candidate immutable."""
from pathlib import Path
import hashlib
import json

B=Path('C:/workspace/ck3_lyd_runtime_20261004')
identity={'schema':'xar.ck3-live-run-identity.v1','run_id':'bf-202609141645-5434332d4d--li-yu-dao--R0038','execution_id':'91bfbf2b-cf59-49a1-830a-085fa49f5504','machine_id':'bf-202609141645-5434332d4d','mod_key':'li-yu-dao','sequence':38,'allocated_at_utc':'2026-10-09T12:22:37.584433+00:00','allocator_pid':15016,'legacy_alias':'R38'}
rows=[]
def write(source,target,value):
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(value)
    rows.append({'source':source.as_posix(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'target':target.as_posix(),'target_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
source=B/'r37-root-materialize-transaction-only-cold-20261009-001.py'
value=source.read_text(encoding='utf-8')
lines=value.splitlines(keepends=True)
assert sum(x.startswith('RUN_ID = ') for x in lines)==1
lines=[('RUN_ID = '+repr(identity)+'\n') if x.startswith('RUN_ID = ') else x for x in lines]
value=''.join(lines).replace("RUN = B / 'live-attempt-037'","RUN = B / 'live-attempt-038'").replace('lyd_r37_D2a_transaction_only_diagnostic','lyd_r38_D2a_transaction_only_diagnostic').replace("b'live-attempt-037'","b'live-attempt-038'").replace('lyd.r37.transaction-only-d2a-cold-materialized','lyd.r38.transaction-only-d2a-cold-materialized')
write(source,B/'r38-root-materialize-transaction-only-cold-20261009-001.py',value)
for name in ('launch-diagnostic','prepare-native-profile','capture-load-state','capture-load-state-repeat','focus-game','normal-exit-inventory','bind-normal-exit-profile'):
    source=B/f'r37-root-{name}-20261009-001.py'
    value=source.read_text(encoding='utf-8').replace('live-attempt-037','live-attempt-038').replace('R0037','R0038').replace('R37','R38').replace('r37','r38').replace('native-profile-freeze-002','native-profile-freeze-001')
    assert 'live-attempt-037' not in value
    write(source,B/f'r38-root-{name}-20261009-001.py',value)
out=B/'r38-root-runtime-derivation-20261009-001.json'
with out.open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'schema':'lyd.r38.runtime-derivation.v1','run_id':identity,'rows':rows,'source_overlay':'immutable R37 transaction-only candidate; no D2b result yet'},f,indent=2);f.write('\n')
print(json.dumps({'output':out.as_posix(),'derived':len(rows)}))
