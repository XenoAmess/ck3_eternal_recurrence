"""Archive R38 observations without granting a causal or product verdict."""
from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
REPO=Path('C:/workspace/ck3_eternal_recurrence')
B=Path('C:/workspace/ck3_lyd_runtime_20261004');RUN=B/'live-attempt-038'
OUT=REPO/'docs/li-yu-dao/acceptance/2026-10-09-r0038-transaction-control-guard-red'
def require(ok,why):
 if not ok:raise RuntimeError(why)
def read(p):return json.loads(p.read_bytes())
def pin(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block);n+=len(block)
 return {'path':p.as_posix(),'bytes':n,'sha256':h.hexdigest()}
def put(p,obj):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n')
client=RUN/'diagnostic-mcp-client-001'
def sdk(name):
 obj=read(next(client.glob('*-'+name+'.sdk-result.json')))
 require(obj['isError'] is False,name+' SDK failed')
 return obj['structuredContent']
ids=[]
for request in ['r38-D2a-cache-before-001','r38-D2b-cache-before-save-001','r38-no-event-cache-after-save-001']:
 ids.append(sdk(request)['result']['native_result']['actor_cached_succession']['complete_cached_successor_ids'])
require(len(ids[0])==45 and ids[0]==ids[1]==ids[2],'cache observations differ')
sel=sdk('r38-D2b-select-001')
require(sel['snapshot_after']['revision']==3 and sel['snapshot_after']['active_event'] is None,'unexpected post-selection snapshot')
state=read(RUN/'NO-EVENT-STATE.actual.json')
require(state['causal_conclusion'] is None,'must not grant causal credit')
checkpoint=Path(state['checkpoint']['path'])
require(pin(checkpoint)['sha256']==state['checkpoint']['sha256'],'checkpoint mismatch')
ex=sdk('r38-exit-observe-002')['result']
require(ex['typed_normal_exit_observed'] and ex['exit_code']==0 and not ex['autosave_verified'],'normal exit unverified')
require(read(RUN/'game-original-handle-final.json')['returncode']==0,'original handle nonzero')
require(read(client/'final.json')['status']=='CLOSED','client not closed')
keeper=B/'r38-root-screen-keeper-20261009-001'
final=read(keeper/'FINAL.json')
require(final['failure'] is None and final['thread_exited'],'keeper failed')
require(read(B/'r38-root-display-restore-20261009-001.json')['after']=={'width':1024,'height':768,'bits':32,'frequency':60},'display not restored')
for name in ['r38-root-steam-offline-recovery-20261009-004','r38-root-steam-offline-final-20261009-001']:
 review=read(B/name/'OFFLINE-REVIEW.actual.json')
 require(review['steam_offline_confirmed'] and pin(B/name/review['image'])['sha256']==review['image_sha256'],'offline evidence mismatch')
bus=[sys.executable,'-B','-X','utf8',str(REPO/'tools/codex_task_bus.py'),'--bus-dir','C:/workspace/.codex-task-bus','--expected-cli-sha256','B3C44B42F7BDF401B593D863E3210106A46412DCD7D89F8596C74F4C27392DEE']
tasks=json.loads(subprocess.run(bus+['list','--stale-after','600'],capture_output=True,check=True).stdout)['tasks']
task=next(t for t in tasks if t['task_id']=='lyd-r0038-transaction-only-diagnostic-live-root')
require(task['state']=='done' and task['resources']==[],'task not released')
put(RUN/'R38-CLOSEOUT-TASK.actual.json',task)
files={}
def add(root,pattern,prefix):
 for p in root.glob(pattern):
  if p.is_file() and p.suffix.lower() not in ['.ck3','.pyc']:
   arc=prefix+'/'+p.relative_to(root).as_posix()
   require(arc not in files and p.stat().st_size<=20000000,'invalid archive entry '+arc)
   files[arc]=p
add(B,'r38-root-*.py','tools');add(B,'r38-root-*.json','preparation')
add(B/'r37-transaction-only-overlay-sourceonly-20261009-001','**/*','candidate')
add(B,'r37-transaction-only-overlay-static-*.json','preparation')
for pattern in ['*.json','*.png','*.txt']:add(RUN,pattern,'run')
for folder in ['content','diagnostic-mcp-client-001','diagnostic-mcp-queue-001','native-profile-freeze-001','native-evidence','native-state','checkpoints']:
 add(RUN/folder,'**/*','run/'+folder)
for name in ['pdx_settings.txt','dlc_load.json','tutorial.txt','normal-exit-source-inventory-v1.json']:
 p=RUN/'userdir'/name;require(p.is_file(),str(p));files['run/userdir/'+name]=p
add(RUN/'userdir/mod','*.mod','run/userdir/mod');add(RUN/'userdir/logs','*','run/userdir/logs')
for root in B.glob('r38-root-steam-offline-*'):
 if root.is_dir():add(root,'**/*','steam/'+root.name)
add(B/'r38-root-steam-window-restore-20261009-001','**/*','steam/window-restore')
add(keeper,'**/*','screen-lease')
entries=[{'archive_path':arc,'source':pin(p)} for arc,p in sorted(files.items())]
seed=B/'live-attempt-034/checkpoints/D2a/checkpoint.ck3'
copy=RUN/'userdir/save games/lyd_r38_D2a_transaction_only_diagnostic.ck3'
require(pin(seed)['sha256']==pin(copy)['sha256']=='a6db85e38ba0648eca4b7e835c79d867b96ca26099698f4d4ee5269b818d822c','seed mismatch')
OUT.mkdir()
put(OUT/'INDEX.json',{'schema':'lyd.r38.transaction-control-guard-red-archive.v1','status':'DIAGNOSTIC_GUARD_RED_CAUSALITY_UNQUALIFIED','live_run_id':'bf-202609141645-5434332d4d--li-yu-dao--R0038','source_production_head':'06159b964d859d30f2f07f4b183284df7d6dac47','checkout_head_at_launch':'33c7b0b02f2607bd73bdda7aa91af5876a37bc6a','formal_acceptance_credit':False,'normal_exit_verified':True,'cache_counts':[len(x) for x in ids],'ordered_cache_ids_equal':True,'causal_conclusion':None,'external_save_bodies':[{'role':role,**pin(p),'tracked_zip_included':False} for role,p in [('original_D2a',seed),('R38_seed_copy',copy),('R38_after_selection',checkpoint)]],'evidence_entries':entries})
report='''# R0038 transaction-only control — diagnostic guard RED

R38 repeated R37's unconsumed control on CK3 1.20.0.4 after the reboot. The exact R34 D2a seed (`a6db85e38ba0648eca4b7e835c79d867b96ca26099698f4d4ee5269b818d822c`) was cold loaded. The development overlay omits only D2b `change_title_holder`, retaining transaction creation and resolution in the same event; the 71 production files were unchanged. This historical run used the frozen diagnostic entry rather than the subsequently required common acceptance entry. It grants no common-runtime qualification.

The official session independently identified event `lyd_factory_diag.20`, instance 121, root 31254 and saved new_title 18373. Its single option selection at revision 2 was acknowledged and the next snapshot was revision 3 with no active event. The successor cache was 45 before selection, 45 immediately afterwards and 45 after one successful save; all ordered IDs were equal. The immutable after-selection checkpoint is 91,710,743 bytes, SHA-256 `d96003e938c131385227b43bd9cd43cf3069fdc869fca3b5a43cc4893f859474`.

The expected next event did not open. Inspection found event .2 and its hidden limit still require `lyd_factory_diag_title_trigger`, which requires holder=root. This conflicts with this control's intentional omission of title assignment. There is no independent persisted completion marker for the empty transaction. Consequently the observations do **not** qualify a completed transaction-only causal control. No conclusion about which transaction sub-operation causes R34's 45-to-40 loss is granted. The next diagnostic must admit an unheld title, persist a marker after resolve, and stop at a read-only terminal event rather than continuing to the religious-head mutation.

The first state-preservation helper read a partially written SDK file after issuing the save. Its derived resume consumed that same completed response without resubmitting the save. Both source versions and the receipts are preserved. The first normal-exit observation was too early and returned dispatch_pending; a later read-only observation confirmed process_exit_observed_zero, typed_normal_exit_observed=true, exit_code=0, autosave_verified=false. The original retained CK3 handle independently returned 0. Exit confirmation was submitted once, and the MCP client closed.

After reboot Steam was absent and the 1024×768 desktop could not fit its minimum window plus the freshness displacement. Failed recovery/window attempts are preserved. A supported 1920×1080 mode was used without registry persistence. Fresh prelaunch and post-exit images were directly reviewed as Steam “离线模式”. The original 1024×768×32@60 mode was restored with actual readback. The keeper ended without failure; the task is done with no resources.

Formal I3b, the new religious-title cold reload, C3, I4 and the whole mod remain **NOT_GREEN**. `INDEX.json` pins external save bodies; `raw-evidence.zip` preserves small source, overlays, requests, SDK/native evidence, logs, failed helpers, Steam frames and closeout. Every extracted entry was checked against its source size and SHA-256.
'''
with (OUT/'REPORT.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
zp=OUT/'raw-evidence.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for arc,p in sorted(files.items()):z.write(p,arc)
with zipfile.ZipFile(zp) as z:
 require(sorted(z.namelist())==sorted(files),'archive inventory differs')
 for e in entries:
  data=z.read(e['archive_path']);require(len(data)==e['source']['bytes'] and hashlib.sha256(data).hexdigest()==e['source']['sha256'],'archive entry differs')
validation={'schema':'lyd.r38.archive-validation.v1','result':'PASS','entry_count':len(entries),'zip':pin(zp),'index':pin(OUT/'INDEX.json'),'report':pin(OUT/'REPORT.md')}
put(OUT/'ARCHIVE-VALIDATION.actual.json',validation);print(json.dumps(validation))
