"""Materialize R37 from R34 D2a save with only the D2b holder call removed."""
from pathlib import Path
import hashlib
import json
import shutil

B = Path('C:/workspace/ck3_lyd_runtime_20261004')
PRIOR = B / 'live-attempt-036'
ORIGIN = B / 'live-attempt-031'
R34 = B / 'live-attempt-034'
RUN = B / 'live-attempt-038'
CANDIDATE = B / 'r37-transaction-only-overlay-sourceonly-20261009-001'
STATIC = B / 'r37-transaction-only-overlay-static-20261009-001.json'
SEED = R34 / 'checkpoints/D2a/checkpoint.ck3'
SEED_SHA = 'a6db85e38ba0648eca4b7e835c79d867b96ca26099698f4d4ee5269b818d822c'
SOURCE_HEAD = '06159b964d859d30f2f07f4b183284df7d6dac47'
RUN_ID = {'schema': 'xar.ck3-live-run-identity.v1', 'run_id': 'bf-202609141645-5434332d4d--li-yu-dao--R0038', 'execution_id': '91bfbf2b-cf59-49a1-830a-085fa49f5504', 'machine_id': 'bf-202609141645-5434332d4d', 'mod_key': 'li-yu-dao', 'sequence': 38, 'allocated_at_utc': '2026-10-09T12:22:37.584433+00:00', 'allocator_pid': 15016, 'legacy_alias': 'R38'}

def pin(path):
    h = hashlib.sha256()
    n = 0
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
            n += len(chunk)
    return {'path': path.as_posix(), 'bytes': n, 'sha256': h.hexdigest()}

def put(path, data):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

assert not RUN.exists()
old = json.loads((PRIOR / 'COLD-MATERIALIZED.json').read_bytes())
cache = json.loads((R34 / 'R34-CACHE-COMPARISON.actual.json').read_bytes())
copy_receipt = json.loads((SEED.parent / 'COPY.actual.json').read_bytes())
static = json.loads(STATIC.read_bytes())
assert old['source_production_head'] == SOURCE_HEAD
assert copy_receipt['stage'] == 'D2a' and copy_receipt['sha256'] == SEED_SHA
assert pin(SEED)['sha256'] == SEED_SHA and pin(SEED)['bytes'] == 91711686
assert cache['stage_caches']['D2a_after']['count'] == 45
assert static['status'] == 'PASS_SOURCE_ONLY_RUNTIME_NOT_RUN' and static['changed_file_count'] == 1
assert static['manifest_sha256'] == pin(CANDIDATE / 'CANDIDATE-MANIFEST.json')['sha256']
for item in old['content']:
    actual = pin(Path(item['copy']['path']))
    assert actual['bytes'] == item['copy']['bytes'] and actual['sha256'] == item['copy']['sha256']
for item in old['settings']:
    actual = pin(Path(item['source']['path']))
    assert actual['sha256'] == item['source']['sha256']
for item in old['registrations']:
    actual = pin(Path(item['copy']['path']))
    assert actual['sha256'] == item['copy']['sha256']

RUN.mkdir()
(RUN / 'content').mkdir()
content = []
for name in ('production', 'entry', 'observer', 'i4_single_event', 'charter', 'diagnostic_stage'):
    source = CANDIDATE if name == 'diagnostic_stage' else PRIOR / 'content' / name
    dest = RUN / 'content' / name
    shutil.copytree(source, dest, ignore=shutil.ignore_patterns('CANDIDATE-MANIFEST.json'))
    for original in sorted(x for x in source.rglob('*') if x.is_file() and x.name != 'CANDIDATE-MANIFEST.json'):
        copied = dest / original.relative_to(source)
        a, b = pin(original), pin(copied)
        assert a['bytes'] == b['bytes'] and a['sha256'] == b['sha256']
        content.append({'role': name, 'source': a, 'copy': b})
assert len(content) == len(old['content']) == 129
userdir = RUN / 'userdir'
(userdir / 'mod').mkdir(parents=True)
(userdir / 'save games').mkdir()
settings = []
for name in ('pdx_settings.txt', 'dlc_load.json', 'tutorial.txt'):
    source = ORIGIN / 'userdir' / name
    copied = userdir / name
    shutil.copy2(source, copied)
    assert pin(source)['sha256'] == pin(copied)['sha256']
    settings.append({'source': pin(source), 'copy': pin(copied)})
registrations = []
for source in sorted((PRIOR / 'userdir/mod').glob('*.mod')):
    raw = source.read_bytes()
    assert raw.count(b'live-attempt-036') == 1
    copied = userdir / 'mod' / source.name
    copied.write_bytes(raw.replace(b'live-attempt-036', b'live-attempt-038'))
    registrations.append({'source': pin(source), 'copy': pin(copied)})
assert len(registrations) == 6
save = userdir / 'save games/lyd_r38_D2a_transaction_only_diagnostic.ck3'
shutil.copy2(SEED, save)
assert pin(save)['sha256'] == SEED_SHA
put(RUN / 'live-run-id.json', RUN_ID)
receipt = {'schema': 'lyd.r38.transaction-only-d2a-cold-materialized.v1', 'status': 'FILE_ONLY_NOT_LAUNCHED', 'run_id': RUN_ID, 'source_production_head': SOURCE_HEAD, 'source_R34_D2a_checkpoint': pin(SEED), 'R34_D2a_cache_before_cold': cache['stage_caches']['D2a_after'], 'copied_seed': pin(save), 'R36_receipt': pin(PRIOR / 'COLD-MATERIALIZED.json'), 'R37_candidate_manifest': pin(CANDIDATE / 'CANDIDATE-MANIFEST.json'), 'R37_candidate_static': pin(STATIC), 'content': content, 'content_file_count': len(content), 'settings': settings, 'registrations': registrations, 'game_launched': False, 'formal_I3b_credit': None, 'whole_mod': 'NOT_GREEN'}
put(RUN / 'COLD-MATERIALIZED.json', receipt)
print(json.dumps({'run': RUN.as_posix(), 'run_id': RUN_ID['run_id'], 'seed': pin(save), 'content_file_count': len(content), 'receipt': pin(RUN / 'COLD-MATERIALIZED.json')}, ensure_ascii=False))
