"""One R38 official MCP session; execute only fresh explicit request files."""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import uuid

import psutil

from mcp import Client
from mcp.client.stdio import StdioServerParameters, stdio_client

RUN = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-038")
PROFILE = RUN / "native-profile-with-exit-inventory.json"
SERVER = Path("C:/lr31s1/tools/ck3_native_profile_mcp.py")
SERVER_SHA = "c107a1000c89ac3a6f14bf5a3645a05bacc547ed54e1d7788e3617cb889f058e"
PROFILE_SHA = "48dd5b32b3bb1d81dd4f723ae614912beee6845e9dff4586fa959d1e46e2e07f"
SESSION_SUFFIX = sys.argv[1] if len(sys.argv) == 2 else "001"
assert SESSION_SUFFIX in {"001", "002"}
QUEUE = RUN / ("diagnostic-mcp-queue-" + SESSION_SUFFIX)
OUT = RUN / ("diagnostic-mcp-client-" + SESSION_SUFFIX)
TOOLS = {
    "ck3_query_native_profile_v1", "ck3_attach_profile_bridge_v1", "ck3_query_profile_actor_cached_succession_v1",
    "ck3_take_profile_native_snapshot_v1", "ck3_query_profile_event_window_v1",
    "ck3_select_profile_event_option_v1", "ck3_save_profile_checkpoint_v1",
    "ck3_query_normal_exit_context_v1", "ck3_request_normal_exit_v1", "ck3_observe_profile_normal_exit_v1",
}


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write(path: Path, value: dict) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as target:
        json.dump(value, target, ensure_ascii=False, indent=2)
        target.write("\n")


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def preserve_receipts(value: object, prefix: str, native_evidence: Path) -> list[dict]:
    found: set[str] = set()

    def walk(node: object) -> None:
        if isinstance(node, dict):
            if isinstance(node.get("receipt_path"), str):
                found.add(node["receipt_path"])
            for child in node.values():
                walk(child)
        elif isinstance(node, list):
            for child in node:
                walk(child)
        elif isinstance(node, str):
            try:
                child = json.loads(node)
            except ValueError:
                return
            if isinstance(child, (dict, list)):
                walk(child)

    walk(value)
    copied = []
    for index, name in enumerate(sorted(found), 1):
        path = Path(name).resolve()
        row = {"original": str(path)}
        if native_evidence in path.parents and path.is_file():
            dest = OUT / f"{prefix}.native-{index:02d}.json"
            with dest.open("xb") as target:
                target.write(path.read_bytes())
            row.update(copy=str(dest), bytes=dest.stat().st_size, sha256=sha(dest))
        else:
            row["status"] = "NOT_COPIED_OUTSIDE_NATIVE_EVIDENCE_OR_MISSING"
        copied.append(row)
    return copied


async def main() -> None:
    assert sha(PROFILE) == PROFILE_SHA and sha(SERVER) == SERVER_SHA
    profile = json.loads(PROFILE.read_text(encoding="utf-8"))
    guard = json.loads(Path(profile["guard_profile"]).read_text(encoding="utf-8"))
    target = guard["target"]
    assert psutil.Process(target["pid"]).create_time() == target["process_create_time"]
    assert not OUT.exists() and not QUEUE.exists()
    OUT.mkdir()
    QUEUE.mkdir()
    session = {"schema": "lyd.r38.diagnostic-mcp-session.v1", "uuid": uuid.uuid4().hex,
               "profile": str(PROFILE), "profile_sha256": PROFILE_SHA, "server": str(SERVER), "server_sha256": SERVER_SHA,
               "target": {"pid": target["pid"], "create_time": target["process_create_time"]},
               "created_at_utc": now(), "cache": None, "automatic_attach": False, "automatic_retry": False}
    write(OUT / "session.json", session)
    params = StdioServerParameters(command=sys.executable, args=["-X", "utf8", str(SERVER), "--profile", str(PROFILE),
                                   "--confucian-challenger-tools", "--grant-title-picker-tools", "--actor-cached-succession-tools"],
                                   cwd=str(SERVER.parent.parent), env={**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"})
    seen: set[str] = set()
    inventory: set[str] | None = None
    attached = False
    sequence = 0
    terminal = False
    with (OUT / "server.stderr.log").open("x", encoding="utf-8") as errors:
        async with Client(stdio_client(params, errlog=errors), cache=None) as client:
            write(OUT / "ready.json", {**session, "status": "CLIENT_CONNECTED_BRIDGE_NOT_ATTACHED", "ready_at_utc": now()})
            print(json.dumps({"status": "READY", "queue": str(QUEUE)}), flush=True)
            while True:
                pending = [p for p in sorted(QUEUE.glob("*.request.json")) if p.name not in seen]
                if not pending:
                    await asyncio.sleep(0.2)
                    continue
                for path in pending:
                    seen.add(path.name)
                    sequence += 1
                    prefix = f"{sequence:04d}-{path.name.removesuffix('.request.json')}"
                    raw = path.read_bytes()
                    with (OUT / f"{prefix}.request.json").open("xb") as target_file:
                        target_file.write(raw)
                    record = {"schema": "lyd.r38.diagnostic-mcp-dispatch.v1", "request": str(path), "request_sha256": hashlib.sha256(raw).hexdigest(), "started_at_utc": now()}
                    try:
                        request = json.loads(raw)
                        assert set(request) == {"request_id", "operation", "name", "arguments"} and request["request_id"] == path.name.removesuffix(".request.json")
                        assert re.fullmatch(r"r38-[A-Za-z0-9_.-]+", request["request_id"])
                        op, name, args = request["operation"], request["name"], request["arguments"]
                        assert isinstance(args, dict)
                        if op == "close":
                            assert name == "" and args == {}
                            record["status"] = "CLIENT_CLOSE_REQUESTED"
                            write(OUT / f"{prefix}.response.json", record)
                            write(OUT / "final.json", {"status": "CLOSED", "at_utc": now(), "sequence": sequence, "terminal_exit_requested": terminal})
                            return
                        if op == "list_tools":
                            assert name == "" and args == {} and inventory is None
                            result = await client.list_tools()
                            payload = result.model_dump(mode="json", by_alias=True, exclude_none=False)
                            names = {r["name"] for r in payload["tools"]}
                            assert TOOLS <= names and len(payload["tools"]) == 29, "actual official tool inventory changed"
                            inventory = names
                        else:
                            assert op == "call_tool" and inventory is not None and name in TOOLS and name in inventory
                            assert not terminal or name == "ck3_observe_profile_normal_exit_v1"
                            if name == "ck3_attach_profile_bridge_v1":
                                assert not attached and args == {}
                                attached = True
                            else:
                                assert attached
                            if name == "ck3_request_normal_exit_v1" and args.get("action") == "confirm_desktop":
                                terminal = True
                            result = await client.call_tool(name, args, read_timeout_seconds=60)
                            payload = result.model_dump(mode="json", by_alias=True, exclude_none=False)
                        write(OUT / f"{prefix}.sdk-result.json", payload)
                        record.update(status="MCP_RESULT_RECORDED", name=name, is_error=getattr(result, "isError", None),
                                      sdk_sha256=sha(OUT / f"{prefix}.sdk-result.json"),
                                      native_receipts=preserve_receipts(payload, prefix, Path(profile["evidence_directory"]).resolve()))
                    except Exception as error:
                        record.update(status="ERROR_NO_RETRY", reason=f"{type(error).__name__}: {error}")
                    record["finished_at_utc"] = now()
                    write(OUT / f"{prefix}.response.json", record)
                    print(json.dumps({"request": path.name, "status": record["status"], "is_error": record.get("is_error")}), flush=True)


if __name__ == "__main__":
    asyncio.run(main())
