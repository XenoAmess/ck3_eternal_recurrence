from pathlib import Path
import hashlib
import json
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
src=B/'r38-root-preserve-no-event-state-20261009-001.py'
out=B/'r38-root-preserve-no-event-state-20261009-002.py'
value=src.read_text(encoding='utf-8')
old="results=list(CLIENT.glob('*-'+rid+'.sdk-result.json'))"
assert value.count(old)==1
value=value.replace(old,"responses=list(CLIENT.glob('*-'+rid+'.response.json'))\n        results=list(CLIENT.glob('*-'+rid+'.sdk-result.json')) if responses else []")
old="save,source=call('no-event-save-001','ck3_save_profile_checkpoint_v1',3)"
assert value.count(old)==1
value=value.replace(old,"source=CLIENT/'0008-r38-no-event-save-001.sdk-result.json'\nassert json.loads((CLIENT/'0008-r38-no-event-save-001.response.json').read_bytes())['status']=='MCP_RESULT_RECORDED'\nsave=json.loads(source.read_bytes());assert save['isError'] is False")
with out.open('x',encoding='utf-8',newline='\n') as f:f.write(value)
print(json.dumps({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'target':str(out),'target_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'save_resubmitted':False}))
