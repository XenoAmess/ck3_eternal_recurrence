"""Print small native SDK evidence fields from one retained R38 response."""
from pathlib import Path
import json
import sys

path = Path(sys.argv[1]).resolve()
run = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-038").resolve()
assert path.is_relative_to(run) and path.name.endswith(".sdk-result.json")
outer = json.loads(path.read_text(encoding="utf-8"))
s = outer.get("structuredContent") or {}
r = s.get("result") or {}
n = r.get("native_result") or {}
succ = n.get("actor_cached_succession") or {}
out = {"file": str(path), "isError": outer.get("isError"), "status": s.get("status"),
       "snapshot_keys": list(s.get("snapshot", {})) if isinstance(s.get("snapshot"), dict) else None,
       "snapshot_revision_actual": (s.get("snapshot") or {}).get("revision"),
       "snapshot_active_event": (s.get("snapshot") or {}).get("active_event"),
       "snapshot_history_tail": (s.get("snapshot") or {}).get("history", [])[-3:],
       "result_status": r.get("status"), "native_status": n.get("status"),
       "queried_revision": r.get("queried_revision"), "snapshot_revision": n.get("snapshot_revision"),
       "cache_count": len(succ.get("complete_cached_successor_ids", [])) if succ else None,
       "cache_ids": succ.get("complete_cached_successor_ids") if succ else None,
       "event": {k: v for k, v in s.items() if "event" in k or "option" in k},
       "event_definition_key": r.get("event_definition_key"), "current_event_instance_id": r.get("current_event_instance_id"),
       "option_numbers": [x.get("option_number") for x in r.get("options", [])] if isinstance(r.get("options"), list) else None,
       "checkpoint": r.get("checkpoint"),
       "active_event": r.get("active_event"), "revision": r.get("revision"),
       "exit_context_signature": r.get("exit_context_signature"), "exit_public_revision": r.get("public_revision"),
       "process_exit_observed": r.get("process_exit_observed"), "exit_code": r.get("exit_code"),
       "typed_normal_exit_observed": r.get("typed_normal_exit_observed"), "autosave_verified": r.get("autosave_verified"),
       "structured_keys": list(s), "result_keys": list(r), "native_keys": list(n)}
print(json.dumps(out, ensure_ascii=False))
