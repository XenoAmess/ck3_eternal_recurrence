from pathlib import Path
import json
import hashlib

B=Path('C:/workspace/ck3_lyd_runtime_20261004')
run=B/'live-attempt-038'
profile_sha=hashlib.sha256((run/'native-profile-with-exit-inventory.json').read_bytes()).hexdigest()
assert profile_sha=='48dd5b32b3bb1d81dd4f723ae614912beee6845e9dff4586fa959d1e46e2e07f'
rows=[]
for name in ('diagnostic-mcp-client','queue-request','read-sdk','focus-and-enqueue-attach'):
    src=B/f'r37-root-{name}-20261009-001.py'
    value=src.read_text(encoding='utf-8').replace('live-attempt-037','live-attempt-038').replace('R37','R38').replace('r37','r38')
    if name=='diagnostic-mcp-client':
        old='b46a7a1a1a30d6e74f98e0bb280ef08a20c44bd455613bf362bbad29dbd9aad1'
        assert value.count(old)==1
        value=value.replace(old,profile_sha)
    out=B/f'r38-root-{name}-20261009-001.py'
    with out.open('x',encoding='utf-8',newline='\n') as f:f.write(value)
    rows.append({'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'target':str(out),'target_sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
for name in ('inventory-002','attach-002'):
    src=B/'live-attempt-037'/f'r37-{name}.source.json'
    obj=json.loads(src.read_bytes());obj['request_id']=f'r38-{name}'
    out=run/f'r38-{name}.source.json'
    with out.open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,separators=(',',':'));f.write('\n')
with (B/'r38-root-native-client-derivation-20261009-001.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'profile_sha256':profile_sha,'rows':rows},f,indent=2);f.write('\n')
print(json.dumps({'derived':len(rows),'profile_sha256':profile_sha}))
