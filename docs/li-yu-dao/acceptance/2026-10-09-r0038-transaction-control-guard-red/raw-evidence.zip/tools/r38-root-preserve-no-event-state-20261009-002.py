"""Preserve the R38 missing-event state without assigning causal credit."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import os
import shutil
import time

RUN=Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-038')
CLIENT=RUN/'diagnostic-mcp-client-001'
def pin(p):
    h=hashlib.sha256();n=0
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b);n+=len(b)
    return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
def put(p,o):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(o,f,ensure_ascii=False,indent=2);f.write('\n')
def call(short,name,revision):
    rid='r38-'+short;source=RUN/(rid+'.source.json');target=RUN/'diagnostic-mcp-queue-001'/(rid+'.request.json')
    put(source,{'request_id':rid,'operation':'call_tool','name':name,'arguments':{'expected_revision':revision}})
    os.link(source,target)
    deadline=time.monotonic()+65
    while time.monotonic()<deadline:
        responses=list(CLIENT.glob('*-'+rid+'.response.json'))
        results=list(CLIENT.glob('*-'+rid+'.sdk-result.json')) if responses else []
        if results:
            obj=json.loads(results[0].read_bytes());assert obj['isError'] is False,obj
            return obj,results[0]
        time.sleep(.2)
    raise TimeoutError(rid+' no retry')
selection=json.loads((CLIENT/'0005-r38-D2b-select-001.sdk-result.json').read_bytes())['structuredContent']
assert selection['snapshot_after']['revision']==3 and selection['snapshot_after']['active_event'] is None
source=CLIENT/'0008-r38-no-event-save-001.sdk-result.json'
assert json.loads((CLIENT/'0008-r38-no-event-save-001.response.json').read_bytes())['status']=='MCP_RESULT_RECORDED'
save=json.loads(source.read_bytes());assert save['isError'] is False
p=RUN/'userdir/save games/xar_checkpoint.ck3'
original=pin(p)
assert original['sha256'] in source.read_text(encoding='utf-8')
dest=RUN/'checkpoints/D2b-no-event'
assert not dest.exists();dest.mkdir(parents=True)
copied=dest/'checkpoint.ck3'
with copied.open('xb') as f,p.open('rb') as src:shutil.copyfileobj(src,f,1024*1024)
assert pin(p)['sha256']==pin(copied)['sha256']==original['sha256']
put(dest/'COPY.actual.json',{'schema':'lyd.r38.no-event-checkpoint.v1','utc':datetime.now(timezone.utc).isoformat(),'source':original,'copy':pin(copied),'SDK':pin(source),'formal_acceptance_credit':False})
cache,cache_source=call('no-event-cache-after-save-001','ck3_query_profile_actor_cached_succession_v1',4)
ids=cache['structuredContent']['result']['native_result']['actor_cached_succession']['complete_cached_successor_ids']
report={'schema':'lyd.r38.no-event-state-capture.v1','checkpoint':pin(copied),'cache_count_after_save':len(ids),'cache_ids_after_save':ids,'cache_source':pin(cache_source),'public_revision':4,'diagnostic_event_guard_requires_holder':True,'causal_conclusion':None,'formal_acceptance_credit':False}
put(RUN/'NO-EVENT-STATE.actual.json',report)
print(json.dumps(report))
