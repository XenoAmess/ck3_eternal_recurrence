"""Open the official Steam library only when its saved offline preference is set."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import subprocess
import psutil

B=Path('C:/workspace/ck3_lyd_runtime_20261004')
exe=Path('C:/Program Files (x86)/Steam/steam.exe')
config=exe.parent/'config/loginusers.vdf'
out=B/'r38-root-steam-open-library-20261009-001.json'
assert not out.exists()
assert not any((p.info.get('name') or '').lower()=='ck3.exe' for p in psutil.process_iter(['name']))
raw=config.read_bytes()
flags=re.findall(r'"WantsOfflineMode"\s+"([^"]*)"',raw.decode('utf-8-sig'))
assert flags and set(flags)=={'1'}, 'Saved offline preference is not uniformly enabled'
argv=[str(exe),'-cef-disable-gpu','steam://open/library']
proc=subprocess.Popen(argv,cwd=exe.parent)
obj={'schema':'lyd.r38.steam-library-open.v1','utc':datetime.now(timezone.utc).isoformat(),'argv':argv,'pid':proc.pid,'saved_offline_flags':flags,'loginusers_sha256':hashlib.sha256(raw).hexdigest(),'steam_exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'mode_change_requested':False,'game_launch_requested':False,'offline_visual_confirmation':None}
with out.open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,indent=2);f.write('\n')
print(json.dumps(obj))
