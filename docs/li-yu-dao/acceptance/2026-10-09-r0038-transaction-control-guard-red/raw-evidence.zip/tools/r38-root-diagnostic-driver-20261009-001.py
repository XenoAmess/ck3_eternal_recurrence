"""Explicit, append-only official MCP phases for R38; never retry a game mutation."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import os
import subprocess
import sys
import time

B=Path('C:/workspace/ck3_lyd_runtime_20261004')
RUN=B/'live-attempt-038'
QUEUE=RUN/'diagnostic-mcp-queue-001'
CLIENT=RUN/'diagnostic-mcp-client-001'
PHASE=sys.argv[1]
assert PHASE in ('preflight','experiment','exit')
history=[]

def pin(path):
    raw=path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def put(path,obj):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n')

def wait_result(request_id):
    deadline=time.monotonic()+65
    while time.monotonic()<deadline:
        matches=list(CLIENT.glob('*-'+request_id+'.response.json'))
        if matches:
            assert len(matches)==1
            response=json.loads(matches[0].read_bytes())
            assert response['status']=='MCP_RESULT_RECORDED',response
            sdk=matches[0].with_name(matches[0].name.replace('.response.json','.sdk-result.json'))
            payload=json.loads(sdk.read_bytes())
            assert payload['isError'] is False,payload
            s=payload['structuredContent'];r=s.get('result') or {};snap=s.get('snapshot') or {};n=r.get('native_result') or {}
            succ=n.get('actor_cached_succession') or {}
            row={'request_id':request_id,'sdk':pin(sdk),'status':s.get('status'),'result_status':r.get('status'),'snapshot_revision':snap.get('revision'),'active_event':snap.get('active_event'),'queried_revision':r.get('queried_revision'),'event_key':r.get('event_definition_key'),'event_instance':r.get('current_event_instance_id'),'cache_count':len(succ['complete_cached_successor_ids']) if succ else None,'result_keys':list(r),'structured_keys':list(s)}
            history.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
            return s
        time.sleep(.2)
    raise TimeoutError(request_id+' has no completed response; no retry')

def dispatch(short,name,args,operation='call_tool'):
    request_id='r38-'+short
    source=RUN/(request_id+'.source.json')
    obj={'request_id':request_id,'operation':operation,'name':name,'arguments':args}
    if source.exists():assert json.loads(source.read_bytes())==obj
    else:put(source,obj)
    target=QUEUE/(request_id+'.request.json')
    assert not target.exists()
    os.link(source,target)
    return wait_result(request_id)

report=RUN/('DRIVER-'+PHASE.upper()+'.actual.json')
assert not report.exists()
obj={'schema':'lyd.r38.diagnostic-driver.v1','phase':PHASE,'started_at_utc':datetime.now(timezone.utc).isoformat(),'formal_acceptance_credit':False,'history':history}
try:
    if PHASE=='preflight':
        request_id='r38-inventory-002'
        source=RUN/(request_id+'.source.json');target=QUEUE/(request_id+'.request.json')
        assert not target.exists();os.link(source,target)
        deadline=time.monotonic()+65
        while not list(CLIENT.glob('*-'+request_id+'.response.json')) and time.monotonic()<deadline:time.sleep(.2)
        response=json.loads(next(CLIENT.glob('*-'+request_id+'.response.json')).read_bytes())
        assert response['status']=='MCP_RESULT_RECORDED'
        subprocess.run([sys.executable,'-B','-X','utf8',str(B/'r38-root-focus-and-enqueue-attach-20261009-001.py')],check=True)
        attached=wait_result('r38-attach-002')
        assert attached['status']=='attached_snapshot_verified' and attached['snapshot']['revision']==2
        cache=dispatch('D2a-cache-before-001','ck3_query_profile_actor_cached_succession_v1',{'expected_revision':2})
        ids=cache['result']['native_result']['actor_cached_succession']['complete_cached_successor_ids']
        old=json.loads((B/'live-attempt-034/R34-CACHE-COMPARISON.actual.json').read_bytes())['stage_caches']['D2a_after']['ids']
        assert ids==old and len(ids)==45
        window=dispatch('D2a-window-001','ck3_query_profile_event_window_v1',{'event_instance_id':121,'expected_revision':2})
        w=window['result'];assert w['event_definition_key']=='lyd_factory_diag.20'
        ctx=w['current_event_window_context']
        assert ctx['root_scope']['typed_identity']['character_id']==31254
        title=next(x for x in ctx['saved_scopes'] if x['name']=='new_title')
        assert title['scope']['typed_identity']['title_id']==18373
        obj.update(status='PREFLIGHT_PASS',cache_ids=ids,event_instance=121,revision=2,new_title_id=18373)
    elif PHASE=='experiment':
        before=json.loads((RUN/'DRIVER-PREFLIGHT.actual.json').read_bytes())
        assert before['status']=='PREFLIGHT_PASS' and before['revision']==2 and len(before['cache_ids'])==45
        dispatch('D2b-select-001','ck3_select_profile_event_option_v1',{'option_number':1,'event_instance_id':121,'expected_revision':2})
        cache=dispatch('D2b-cache-before-save-001','ck3_query_profile_actor_cached_succession_v1',{'expected_revision':3})
        ids=cache['result']['native_result']['actor_cached_succession']['complete_cached_successor_ids']
        obj.update(before_ids=before['cache_ids'],after_ids=ids,ordered_ids_equal=ids==before['cache_ids'])
        window=dispatch('D2b-window-001','ck3_query_profile_event_window_v1',{'event_instance_id':122,'expected_revision':3})
        assert window['result']['event_definition_key']=='lyd_factory_diag.2'
        save=dispatch('D2b-save-001','ck3_save_profile_checkpoint_v1',{'expected_revision':3})
        obj['save_structured']=save
        cache_after=dispatch('D2b-cache-after-save-001','ck3_query_profile_actor_cached_succession_v1',{'expected_revision':4})
        obj.update(status='EXPERIMENT_OBSERVED',revision=4,after_save_ids=cache_after['result']['native_result']['actor_cached_succession']['complete_cached_successor_ids'])
    else:
        revision=int(sys.argv[2]);assert revision in (2,3,4)
        for i,action in enumerate(('prepare_confirmation','continue_preparation','confirm_desktop'),1):
            context=dispatch(f'exit-context-{i:03d}','ck3_query_normal_exit_context_v1',{'expected_revision':revision})
            signature=context['result']['exit_context_signature']
            assert len(signature)==64 and context['result']['public_revision']==revision
            dispatch(f'exit-action-{i:03d}','ck3_request_normal_exit_v1',{'action':action,'expected_revision':revision,'expected_exit_context_signature':signature})
        exit_result=dispatch('exit-observe-001','ck3_observe_profile_normal_exit_v1',{})
        r=exit_result['result'];assert r['status']=='process_exit_observed_zero' and r['typed_normal_exit_observed'] is True and r['exit_code']==0
        request_id='r38-client-close-001';source=RUN/(request_id+'.source.json');target=QUEUE/(request_id+'.request.json')
        put(source,{'request_id':request_id,'operation':'close','name':'','arguments':{}});os.link(source,target)
        obj.update(status='NORMAL_EXIT_OBSERVED_ZERO',exit_result=r)
except Exception as e:
    obj.update(status='RED_NO_RETRY',error=type(e).__name__+': '+str(e))
    raise
finally:
    obj['finished_at_utc']=datetime.now(timezone.utc).isoformat();put(report,obj)
    print(json.dumps({'phase':PHASE,'status':obj['status'],'report':pin(report)},ensure_ascii=False),flush=True)
