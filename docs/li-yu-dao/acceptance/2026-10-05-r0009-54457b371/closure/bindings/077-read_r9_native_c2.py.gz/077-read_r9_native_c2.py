"""External actual-save C2 increment reader. No game, bridge, host-release or UI calls."""
from pathlib import Path
from decimal import Decimal
from datetime import datetime,timezone
import json,hashlib,re,sys,stat,argparse
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
EXT=Path("C:/workspace/ck3_lyd_runtime_20261004")
sys.path.insert(0,str(ROOT/"dependencies"))
from bounded_save_parser import extract_exact_indented_block,parse_block,block_body,one
from save_fields import stored,unquote
SCHEMA="lyd.r9.c2.actual-increment-readback.v2"
LEGACY_READER_SHA="cfee520abacd426b7b73b1e91da3fa1abe2ad44d67d3e50af758a1dcdeb7b2e4"
LEGACY_BINDINGS_SHA="3475ca7a09c1fcc6b33295ccee020a9773ec1d71a9b5bb6fd6e5e0cf41f11e73"
ACTOR=31254
RECIPIENT=65866
WATCH=(65865,65866)
MOVING="169"
KEY="lyd_c2_propose_join_interaction"
PHASES=("baseline","proposal-opened","ballots","source-signed","join-result","detach-result","reset","cancel")
def need(ok,msg):
 if not ok:raise ValueError(msg)
def closed(d,keys,label):
 need(type(d) is dict and set(d)==set(keys),label+" has missing/extra fields")
 return d
def sha(raw):return hashlib.sha256(raw).hexdigest()
def jload(raw):
 def unique(rows):
  out={}
  for k,v in rows:
   need(k not in out,"duplicate JSON field "+k);out[k]=v
  return out
 return json.loads(raw.decode("utf-8-sig"),object_pairs_hook=unique,
  parse_constant=lambda x:(_ for _ in ()).throw(ValueError("nonfinite JSON "+x)))
def bytesref(ref,cache,saved=False):
 closed(ref,("path","bytes","sha256"),"immutable artifact ref")
 p=Path(ref["path"]).resolve()
 need(p.is_absolute() and EXT in p.parents and p.is_file(),"input is not a preserved external artifact")
 need(type(ref["bytes"]) is int and ref["bytes"]>=0 and re.fullmatch("[0-9a-f]{64}",ref["sha256"] or ""),"invalid actual size/SHA")
 raw=p.read_bytes()
 need(len(raw)==ref["bytes"] and sha(raw)==ref["sha256"],"actual artifact byte mismatch "+str(p))
 if saved:
  need(p.suffix.lower()==".ck3" and "userdir" not in [x.lower() for x in p.parts],"provide preserved checkpoint, not mutable live save")
  need(getattr(p.stat(),"st_file_attributes",0)&stat.FILE_ATTRIBUTE_READONLY,"checkpoint is not read-only")
 cache[str(p)]=ref["sha256"]
 return raw
def ref(p):
 raw=p.read_bytes()
 return {"path":str(p.resolve()),"bytes":len(raw),"sha256":sha(raw)}
def emit(p,obj):
 with p.open("x",encoding="utf-8",newline="\n") as f:json.dump(obj,f,ensure_ascii=False,indent=2);f.write("\n")
def parse(raw):return parse_block(block_body(raw))
def scalar(rows,key,required=False):return unquote(one(rows,key,required=required))
def section(text,key,after):
 a=list(re.finditer("(?m)^"+re.escape(key)+"=\\{\\n",text))
 b=list(re.finditer("(?m)^"+re.escape(after)+"=\\{\\n",text))
 need(len(a)==len(b)==1 and a[0].start()<b[0].start(),"missing unique bounded section "+key)
 return text[a[0].start():b[0].start()]
def asthash(rows):return sha(json.dumps(rows,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode())
def compactvars(vs):
 return {k:{f:v.get(f) for f in ("present","type","identity","number","boolean","tick","entries")} for k,v in vs.items()}
def project(raw):
 text=raw.decode("utf-8-sig").replace("\r\n","\n")
 meta=parse(extract_exact_indented_block(text,"meta_data",0))
 need(scalar(meta,"version",True)=="1.20.0.3" and scalar(meta,"save_game_version",True)=="17","actual save format/version differs")
 played=parse(extract_exact_indented_block(text,"played_character",0))
 need(scalar(played,"character",True)==str(ACTOR),"actual saved full actor differs")
 date=re.findall("(?m)^date=([^\\n]+)",text)
 current=re.findall("(?m)^currently_played_characters=\\{([^}]*)\\}",text)
 need(len(date)==1 and scalar(meta,"meta_date",True)==date[0].strip(),"actual save calendar differs")
 need(len(current)==1 and str(ACTOR) in current[0].split(),"actual current player missing")
 graphs={}
 for name in ("faiths","rites"):
  rows=parse(extract_exact_indented_block(text,name,0))
  data=one(rows,"database",required=True)
  need(isinstance(data,list),"missing actual "+name+" database")
  graph={}
  for row in data:
   if isinstance(row["key"],str) and row["key"].isdigit():
    need(row["key"] not in graph and isinstance(row["value"],list),"duplicate/invalid typed graph record")
    graph[row["key"]]=row["value"]
  graphs[name]=graph
 parents={rid:scalar(rows,"faith",True) for rid,rows in graphs["rites"].items()}
 mains={fid:scalar(rows,"main_rite") for fid,rows in graphs["faiths"].items()}
 living=section(text,"living","dead_unprunable")
 chars={}
 pending={ACTOR,*WATCH}
 while pending-set(chars):
  need(len(pending)<=256,"actual role scope exceeds256")
  cid=min(pending-set(chars))
  fields=parse(extract_exact_indented_block(living,str(cid),0))
  alive=one(fields,"alive_data",required=True)
  need(isinstance(alive,list),"actual watched role is not living")
  vs,ls,_=stored(alive)
  rite=scalar(fields,"rite",True)
  need(rite in parents and parents[rite] in graphs["faiths"],"character actual Rite/Faith is missing")
  def money(key,leaf):
   obj=one(alive,key);v=scalar(obj or [],leaf)
   return str(Decimal(v)) if isinstance(v,str) else None
  guards={k:one(fields,k) for k in ("first_name","birth","culture","traits","dynasty_house")}
  guards.update({k:one(alive,k) for k in ("family_data","court_data","domain","primary_title")})
  c={"id":cid,"alive":True,"rite":rite,"faith":parents[rite],"variables":compactvars(vs),
   "lists":{k:{"items":[{f:i.get(f) for f in ("type","identity","number","boolean")} for i in group["items"]]} for k,group in ls.items()},
   "wallet":{"gold":money("gold","value"),"piety":money("piety","currency"),"prestige":money("prestige","currency")},
   "stress_raw":one(alive,"stress"),"lifestyle_xp":one(alive,"lifestyle_xp"),"guard_fields":guards,
   "raw_character_AST_sha256":asthash(fields)}
  chars[cid]=c
  if cid==ACTOR:
   for name in ("lyd_c2_source_electors","lyd_c2_target_electors","lyd_c2_players"):
    for item in c["lists"].get(name,{}).get("items",[]):
     need(item.get("type")=="char" and isinstance(item.get("identity"),str) and item["identity"].isdigit() and 0<int(item["identity"])<=4294967294,
      "invalid full saved electorate role")
     pending.add(int(item["identity"]))
 selected_faiths={c["faith"] for c in chars.values()}
 selected_rites={c["rite"] for c in chars.values()}
 av=chars[ACTOR]["variables"]
 for row in av.values():
  if row["type"]=="faith" and row["identity"] is not None:selected_faiths.add(row["identity"])
  if row["type"]=="rite" and row["identity"] is not None:selected_rites.add(row["identity"])
 for fid in selected_faiths:
  need(fid in graphs["faiths"] and mains[fid] in graphs["rites"] and parents[mains[fid]]==fid,"selected Faith has missing/foreign main")
  selected_rites.add(mains[fid])
 for rid in selected_rites:need(rid in graphs["rites"],"selected typed Rite missing")
 def record(rows):
  vs,ls,_=stored(rows)
  return {"entries":rows,"variables":compactvars(vs),"AST_sha256":asthash(rows)}
 result={"calendar":date[0].strip(),"played_character_id":ACTOR,"current_played_ids":current[0].split(),
  "characters":{str(k):v for k,v in chars.items()},"faiths":{k:record(graphs["faiths"][k]) for k in selected_faiths},
  "rites":{k:record(graphs["rites"][k]) for k in selected_rites},"all_faith_mains":mains,"all_rite_parents":parents,
  "selected_character_count":len(chars),"whole_world_characters_scanned":False,"whole_world_political_titles_scanned":False,
  "raw_NULL_policy":"Missing identity stays null; only exact pinned initialized counter type=value can have explicit zero semantics"}
 for key,value in chars[str(ACTOR) if str(ACTOR) in chars else ACTOR]["wallet"].items():need(value is not None,"actor wallet sourcefield missing "+key)
 return result
def sdk(raw):
 d=jload(raw)
 if "sdk_result" in d:d=d["sdk_result"]
 need(type(d) is dict and type(d.get("isError")) is bool and d["isError"] is False and type(d.get("structuredContent")) is dict,"explicit successful SDK wrapper required; raw native receipt is a separate input kind")
 d=d["structuredContent"]
 need(d.get("schema")=="ck3.native-profile-receipt.v1","actual native profile receipt missing")
 return d
def frame(d,binding):
 f=d.get("snapshot_after",d.get("snapshot"))
 need(isinstance(f,dict) and f.get("paused") is True and f.get("map_ready") is True,"actual paused ready frame missing")
 need(d.get("profile_sha256")==binding["profile_sha256"] and d.get("session_id") and
  d.get("pipe_name")==chr(92)*2+"."+chr(92)+"pipe"+chr(92)+"xar_profile_"+d["session_id"],"actual profile/session/pipe differs")
 need(f.get("played_character",{}).get("character_id")==ACTOR and f["played_character"].get("alive") is True,"actual full actor differs")
 diag=f.get("diagnostics",{});hello=diag.get("hello",{})
 need(diag.get("bridge_pid")==binding["pid"] and hello.get("pid")==binding["pid"],"actual guarded PID differs")
 need(type(diag.get("connection_generation")) is int and hello.get("connection_generation")==diag["connection_generation"],"actual connection generation missing")
 need(hello.get("ck3_build_match") is True and hello.get("expected_ck3_version")=="1.20.0.3" and
  str(hello.get("expected_ck3_sha256","")).lower()==binding["exe_sha256"],"actual build pin differs")
 for k in ("revision","native_revision","date_raw"):need(type(f.get(k)) is int and f[k]>=0,"actual frame field missing "+k)
 return f
def native_gate(d,artifact,binding):
 closed(d,("schema","session_id","profile_sha256","pipe_name","recorded_at_utc","status","result","snapshot_before","snapshot_after","observation_after","uses_ocr","uses_desktop_input","receipt_path"),"direct native save receipt")
 need(d["schema"]=="ck3.native-profile-receipt.v1" and d["status"]=="native_gameplay_postcondition_verified","exact genuine native save receipt status required")
 need(d["uses_ocr"] is False and d["uses_desktop_input"] is False,"native save evidence cannot use desktop/OCR credit")
 need(Path(d["receipt_path"]).resolve()==Path(artifact["path"]).resolve(),"native receipt self-path differs")
 need(Path(artifact["path"]).parent.name==d["session_id"],"actual receipt directory/session differs")
 f=frame(d,binding)
 o=d["observation_after"]
 need(type(o) is dict and o.get("pid")==binding["pid"] and o.get("window_pid")==binding["pid"] and
  o.get("process_create_time")==binding["process_create_time"] and str(o.get("executable_sha256","")).lower()==binding["exe_sha256"],"native observation guarded process identity differs")
 prior=d["snapshot_before"]
 need(type(prior) is dict and type(prior.get("native_revision")) is int and prior["native_revision"]<=f["native_revision"] and
  prior.get("diagnostics",{}).get("bridge_pid")==binding["pid"] and prior.get("diagnostics",{}).get("connection_generation")==f["diagnostics"]["connection_generation"],"native save prior frame identity/order differs")
 return f

def save_gate(d,f,save_ref):
 c=d.get("result",{});saved=c.get("checkpoint",{})
 need(c.get("step")=="save-checkpoint" and c.get("accepted") is True and saved.get("status")=="saved" and
  saved.get("strategy")=="native-autosave-command-v1" and saved.get("sha256")==save_ref["sha256"] and
  saved.get("size")==save_ref["bytes"] and saved.get("date_raw")==f["date_raw"] and
  c.get("submission",{}).get("date_raw")==f["date_raw"] and c.get("materialization",{}).get("available") is True,
  "actual saved metadata does not match preserved save")
 return saved

def preservation_gate(d,f,env,evidence,cache):
 p=jload(bytesref(evidence["preservation"],cache))
 failure=jload(bytesref(evidence["sdk_failure"],cache))
 saved=d["result"]["checkpoint"]
 need(p.get("sdk_status")=="ERROR_NO_RETRY" and p.get("sdk_result") is None and p.get("sdk_success_credit") is False and
  failure.get("schema")=="ck3.lyd.mcp-dispatch.v1" and failure.get("status")=="ERROR_NO_RETRY" and
  failure.get("request_id")==p.get("request_id"),"native evidence must preserve actual SDK failure without success credit")
 need(p.get("sha256")==env["save"]["sha256"] and p.get("bytes")==env["save"]["bytes"] and
  Path(p.get("preserved","")).resolve()==Path(env["save"]["path"]).resolve() and
  Path(p.get("source","")).resolve()==Path(saved.get("path","")).resolve(),"preservation source/save bytes differ")
 need(Path(p.get("native_receipt","")).resolve()==Path(evidence["artifact"]["path"]).resolve() and
  p.get("native_receipt_sha256")==evidence["artifact"]["sha256"] and p.get("native_receipt_status")==d["status"] and
  p.get("recorded_at_utc")==d["recorded_at_utc"] and p.get("actual_actor_id")==ACTOR and
  all(p.get(k)==f[k] for k in ("revision","native_revision","date_raw","paused")),"preservation receipt/frame binding differs")

def observation(env,binding,cache,reader_sha,bindings_sha):
 closed(env,("save","checkpoint_evidence","cached_readback"),"actual observation")
 evidence=closed(env["checkpoint_evidence"],("kind","artifact","preservation","sdk_failure"),"explicit checkpoint evidence")
 raw=bytesref(env["save"],cache,saved=True)
 evidence_raw=bytesref(evidence["artifact"],cache)
 if evidence["kind"]=="SDK_SAVE_RECEIPT":
  need(evidence["preservation"] is None and evidence["sdk_failure"] is None,"successful SDK evidence cannot carry native fallback fields")
  d=sdk(evidence_raw);f=frame(d,binding)
 elif evidence["kind"]=="NATIVE_PROFILE_SAVE_RECEIPT":
  need(evidence["preservation"] is not None and evidence["sdk_failure"] is not None,"actual native preservation and failed SDK refs required")
  d=jload(evidence_raw);f=native_gate(d,evidence["artifact"],binding)
  preservation_gate(d,f,env,evidence,cache)
 else:raise ValueError("unknown explicit save evidence kind")
 save_gate(d,f,env["save"])
 if env["cached_readback"] is not None:
  old=jload(bytesref(env["cached_readback"],cache))
  exact_new=(old.get("schema")==SCHEMA and old.get("reader_sha256")==reader_sha and
   old.get("bindings_sha256")==bindings_sha and old.get("after_evidence")==evidence)
  exact_legacy=(evidence["kind"]=="SDK_SAVE_RECEIPT" and old.get("schema")=="lyd.r8.c2.actual-increment-readback.v1" and
   old.get("reader_sha256")==LEGACY_READER_SHA and old.get("bindings_sha256")==LEGACY_BINDINGS_SHA==bindings_sha and
   old.get("after_sdk")==evidence["artifact"])
  need((exact_new or exact_legacy) and old.get("after_artifact")==env["save"] and
   old.get("native_profile_sha256")==binding["profile_sha256"] and old.get("source_head")=="54457b371e947edb86903c2ebd578034f02695db",
   "cached projection cannot be reinterpreted as current parser/input")
  projection=old["after_state"];used=True
 else:projection=project(raw);used=False
 return projection,{"session_id":d["session_id"],"profile_sha256":d["profile_sha256"],"pipe_name":d["pipe_name"],
  "revision":f["revision"],"native_revision":f["native_revision"],"date_raw":f["date_raw"],"generation":f["diagnostics"]["connection_generation"],
  "active_event":f.get("active_event"),"paused":True,"PID":binding["pid"],"process_create_time":binding["process_create_time"],
  "evidence_kind":evidence["kind"],"sdk_success_credit":evidence["kind"]=="SDK_SAVE_RECEIPT"},used

def counter(c,name,zero=False):
 row=c["variables"].get(name)
 need(row is not None and row.get("type")=="value","missing numeric sourcefield "+name)
 number=row.get("number")
 if number is None:
  need(zero and row.get("identity") is None and row.get("entries")==[{"key":"type","value":"value"}],
   "omitted identity is not proved zero "+name)
  return Decimal(0)
 value=Decimal(number);need(value==value.to_integral_value(),"nonintegral C2 counter")
 return value
def typed(c,name,kind):
 row=c["variables"].get(name)
 need(row is not None and row.get("type")==kind and isinstance(row.get("identity"),str) and
  row["identity"].isdigit() and 0<int(row["identity"])<=4294967294,"missing typed sourcefield "+name)
 return row["identity"]
def details(before,after,bf,af,phase):
 checks=[]
 def check(name,ok,detail=None):
  checks.append({"name":name,"matches":bool(ok),"actual":detail})
 b=before["characters"][str(ACTOR)];a=after["characters"][str(ACTOR)]
 bv,av=b["variables"],a["variables"]
 delta={k:str(Decimal(a["wallet"][k])-Decimal(b["wallet"][k])) for k in ("gold","piety","prestige")}
 source=before["all_rite_parents"][MOVING];destination=after["all_rite_parents"][MOVING]
 target=after["characters"][str(RECIPIENT)]["faith"]
 serial=[counter(x,"lyd_c2_serial") for x in (b,a)]
 nonce=[counter(x,"lyd_c2_callback_nonce") for x in (b,a)]
 joins=[counter(x,"lyd_c2_completed_joins",True) for x in (b,a)]
 detaches=[counter(x,"lyd_c2_completed_detaches",True) for x in (b,a)]
 reset=[counter(x,"lyd_r4_reset_count",True) for x in (b,a)]
 moving=after["rites"][MOVING]["variables"];oldmoving=before["rites"][MOVING]["variables"]
 same_date=bf["date_raw"]==af["date_raw"] and before["calendar"]==after["calendar"]
 check("same actual profile/session and ordered native revision",bf["profile_sha256"]==af["profile_sha256"] and
  bf["session_id"]==af["session_id"] and bf["native_revision"]<=af["native_revision"])
 check("actor and full recipient Rites retained",b["rite"]==a["rite"]==MOVING and
  before["characters"][str(RECIPIENT)]["rite"]==after["characters"][str(RECIPIENT)]["rite"]=="159")
 for rid in (MOVING,"159"):
  old=before["rites"][rid]["entries"];new=after["rites"][rid]["entries"]
  check("Rite "+rid+" individual doctrines and tenets retained",
   [e for e in old if e["key"] not in ("faith","variables")]==[e for e in new if e["key"] not in ("faith","variables")])
 if phase in ("join-result","detach-result"):
  within=(serial[1]==serial[0] and nonce[1]==nonce[0] and bv.get("lyd_c2_active",{}).get("number")=="1")
  fresh=(serial[1]==serial[0]+1 and nonce[1]==nonce[0]+1 and "lyd_c2_active" not in bv)
  check("fresh proposal or current captured precommit round",within or fresh,
   {"serial":[str(x) for x in serial],"nonce":[str(x) for x in nonce],"within_round":within,"new_round":fresh})
  check("actual successful result and completed kind",counter(a,"lyd_c2_result")==1 and
   counter(a,"lyd_c2_kind")==Decimal(1 if phase=="join-result" else 2))
  check("captured actual source/moving fields",typed(a,"lyd_c2_source_faith","faith")==source and
   typed(a,"lyd_c2_moving_rite","rite")==MOVING)
  check("exact immediate fee attribution has same paused date",same_date)
  cost=("300","1500") if phase=="join-result" else ("200","1000")
  check("actual exact transition fee",delta["gold"]=="-"+cost[0] and delta["piety"]=="-"+cost[1] and delta["prestige"]=="0",delta)
  check("new transition cooldown1825",moving.get("lyd_c2_transition_cooldown",{}).get("number")=="1" and
   moving.get("lyd_c2_transition_cooldown",{}).get("tick")=="1825" and "lyd_c2_transition_cooldown" not in oldmoving)
  check("actor active released","lyd_c2_active" not in av)
  for rid,obj in after["rites"].items():
   owner=obj["variables"].get("lyd_c2_proposal_owner")
   check("released actual actor owner on Rite "+rid,not owner or owner.get("identity")!=str(ACTOR))
  if phase=="join-result":
   check("exact completed join growth",joins[1]==joins[0]+1 and detaches[1]==detaches[0],
    {"joins":[str(x) for x in joins],"detaches":[str(x) for x in detaches]})
   check("captured target Faith/main/full recipient",typed(a,"lyd_c2_target_faith","faith")==target and
    typed(a,"lyd_c2_target_main","rite")==after["all_faith_mains"][target] and
    typed(a,"lyd_c2_target_rep","char")==str(RECIPIENT))
   check("actual moving parent joined receiving Faith",source!=destination==target)
   check("receiving main unchanged",before["all_faith_mains"][target]==after["all_faith_mains"][target]=="159")
   backup=after["all_faith_mains"][source]
   check("actual valid source main after migration",backup!=MOVING and after["all_rite_parents"].get(backup)==source,backup)
   if sum(v==source for v in before["all_rite_parents"].values())==1:
    check("singleton source backup main has actual new ID",backup not in before["all_rite_parents"],backup)
  else:
   check("exact completed detach growth",detaches[1]==detaches[0]+1 and joins[1]==joins[0],
    {"joins":[str(x) for x in joins],"detaches":[str(x) for x in detaches]})
   check("actual newly created Faith identity",destination!=source and destination not in before["all_faith_mains"],destination)
   check("detached Faith has actual moving main",after["all_faith_mains"][destination]==MOVING)
   check("source common Faith main retained",after["all_faith_mains"][source]==before["all_faith_mains"][source])
   f=after["faiths"][destination]["entries"]
   check("actual new Faith founder/origin",scalar(f,"founder")==str(ACTOR) and scalar(f,"origin")==source,
    {"founder":scalar(f,"founder"),"origin":scalar(f,"origin")})
  check("fixture reset counter unchanged by formal business",reset[0]==reset[1])
 elif phase=="reset":
  check("explicit fixture reset counter increment",reset[1]==reset[0]+1,[str(x) for x in reset])
  check("both cooldown fields absent after reset",all(k not in moving for k in ("lyd_c2_transition_cooldown","lyd_c2_retry_cooldown")),
   {k:{"before":oldmoving.get(k),"after":moving.get(k)} for k in ("lyd_c2_transition_cooldown","lyd_c2_retry_cooldown")})
  check("reset charged zero resources",all(x=="0" for x in delta.values()),delta)
  check("reset preserves serial/nonce/completed history",serial[0]==serial[1] and nonce[0]==nonce[1] and joins[0]==joins[1] and detaches[0]==detaches[1])
  check("reset preserves complete parent/main graph",before["all_rite_parents"]==after["all_rite_parents"] and before["all_faith_mains"]==after["all_faith_mains"])
  check("reset preserves all C2 actor tickets",{k:v for k,v in bv.items() if k.startswith("lyd_c2_")}==
   {k:v for k,v in av.items() if k.startswith("lyd_c2_")})
 elif phase=="cancel":
  check("actual cancellation result3",counter(a,"lyd_c2_result")==3)
  check("cancel released actor/owner","lyd_c2_active" not in av and
   all(o["variables"].get("lyd_c2_proposal_owner",{}).get("identity")!=str(ACTOR) for o in after["rites"].values()))
  check("cancel charged zero resources",all(x=="0" for x in delta.values()),delta)
  check("cancel preserves serial/nonce/completed history",serial[0]==serial[1] and nonce[0]==nonce[1] and joins[0]==joins[1] and detaches[0]==detaches[1])
  check("cancel preserves parent/main graph",before["all_rite_parents"]==after["all_rite_parents"] and before["all_faith_mains"]==after["all_faith_mains"])
 elif phase=="proposal-opened":
  check("actual fresh one-round serial/nonce",serial[1]==serial[0]+1 and nonce[1]==nonce[0]+1)
  check("actual active join and source fields",counter(a,"lyd_c2_active")==1 and counter(a,"lyd_c2_kind")==1 and
   counter(a,"lyd_c2_terms_revision")==1 and typed(a,"lyd_c2_source_faith","faith")==source and
   typed(a,"lyd_c2_source_main","rite")==before["all_faith_mains"][source] and typed(a,"lyd_c2_moving_rite","rite")==MOVING)
  check("actual receiving fields and full recipient",typed(a,"lyd_c2_target_faith","faith")==target and
   typed(a,"lyd_c2_target_main","rite")==after["all_faith_mains"][target]=="159" and
   typed(a,"lyd_c2_target_rep","char")==str(RECIPIENT))
  for name,total,prefix in (("lyd_c2_source_electors","lyd_c2_source_total","lyd_c2_elector_"),
    ("lyd_c2_target_electors","lyd_c2_target_total","lyd_c2_elector_"),
    ("lyd_c2_players","lyd_c2_player_total","lyd_c2_affected_")):
   rows=a["lists"].get(name,{}).get("items",[])
   check("actual positive list/count "+name,len(rows)>0 and counter(a,total)==len(rows),
    [i.get("identity") for i in rows])
   for row in rows:
    c=after["characters"][row["identity"]]
    check("fresh actual role stamps "+name+"/"+row["identity"],typed(c,prefix+"owner","char")==str(ACTOR) and
     counter(c,prefix+"serial")==serial[1] and typed(c,prefix+"rite","rite")==c["rite"])
  for rid in (MOVING,"159"):
   v=after["rites"][rid]["variables"]
   check("fresh actual owner lock Rite "+rid,typed({"variables":v},"lyd_c2_proposal_owner","char")==str(ACTOR) and
    counter({"variables":v},"lyd_c2_lock_serial")==serial[1])
  check("opening changed no completed history or wallets",joins[0]==joins[1] and detaches[0]==detaches[1] and all(x=="0" for x in delta.values()))
  check("opening preserves existing graph",before["all_rite_parents"]==after["all_rite_parents"] and before["all_faith_mains"]==after["all_faith_mains"])
 elif phase=="source-signed":
  check("actual source signed with valid captured snapshot",counter(a,"lyd_c2_source_signed")==1 and
   counter(a,"lyd_c2_snapshot_valid")==1 and counter(a,"lyd_c2_active")==1)
  check("signing preserves serial/nonce and completed history",serial[0]==serial[1] and nonce[0]==nonce[1] and joins[0]==joins[1] and detaches[0]==detaches[1])
  check("signing charges no resources",all(x=="0" for x in delta.values()),delta)
 # Ballots/source-signing remain observations; never infer NPC YES from NULL.
 votes={}
 for cid,c in after["characters"].items():
  v=c["variables"]
  votes[cid]={k:v.get(k) for k in ("lyd_c2_vote_owner","lyd_c2_vote_serial","lyd_c2_vote_nonce","lyd_c2_vote_yes",
   "lyd_c2_elector_owner","lyd_c2_elector_serial","lyd_c2_elector_rite","lyd_c2_player_yes")}
 guarded={cid:before["characters"][cid]["guard_fields"]==after["characters"][cid]["guard_fields"] for cid in set(before["characters"])&set(after["characters"])}
 return {"checks":checks,"unmatched":[x for x in checks if not x["matches"]],"wallet_delta":delta,
  "actual_serial":[str(x) for x in serial],"actual_nonce":[str(x) for x in nonce],
  "actual_completed_joins":[str(x) for x in joins],"actual_completed_detaches":[str(x) for x in detaches],
  "actual_reset_count":[str(x) for x in reset],"moving_parent":[source,destination],
  "actual_source_main_after":after["all_faith_mains"][source],"actual_receiving_full_recipient_id":RECIPIENT,
  "actual_saved_votes":votes,"actual_saved_quorum":{side:{"total_raw":av.get("lyd_c2_"+side+"_total"),
   "yes_raw":av.get("lyd_c2_"+side+"_yes"),"threshold_arithmetic":str(Decimal(av["lyd_c2_"+side+"_yes"]["number"])*3-Decimal(av["lyd_c2_"+side+"_total"]["number"])*2)
   if av.get("lyd_c2_"+side+"_yes",{}).get("number") is not None and av.get("lyd_c2_"+side+"_total",{}).get("number") is not None else None}
   for side in ("source","target","player")},"selected_character_guard_fields_equal":guarded,
  "NPC_yes_expected":None,"native_ACK_business_credit":False,"full_cycle_credit":False}
def main(request_path):
 request_raw=Path(request_path).read_bytes();r=jload(request_raw)
 closed(r,("schema","phase","label","native_profile","before","after","ordinary_query_sdk","output"),"ROOT increment request")
 need(r["schema"]=="lyd.r9.c2.increment-request.v2" and r["phase"] in PHASES,"explicit supported phase required")
 out=Path(r["output"]).resolve();need(EXT in out.parents and not out.exists(),"new external output required")
 cache={};binding_raw=(ROOT/"BINDINGS.json").read_bytes();pins=jload(binding_raw)
 for row in pins["dependencies"]:
  need(sha((ROOT/"dependencies"/row["path"]).read_bytes())==row["sha256"],"parser dependency changed")
 cold=jload(bytesref(pins["cold_request"],cache))
 need(cold["source"]["head"]==pins["source_head"] and
  cold["production"]["manifest"]["sha256"]==pins["production_manifest_sha256"],"actual cold source binding differs")
 profile=jload(bytesref(r["native_profile"],cache))
 need(profile.get("schema_version")==1 and profile.get("game_version")=="1.20.0.3","actual profile version missing")
 gp=Path(profile["guard_profile"]).resolve();guardraw=gp.read_bytes()
 need(EXT in gp.parents and sha(guardraw)==profile["guard_profile_sha256"],"actual guard profile SHA differs")
 cache[str(gp)]=sha(guardraw);g=jload(guardraw)["target"]
 need(type(g.get("pid")) is int and g["pid"]>0 and type(g.get("process_create_time")) in (int,float) and g["process_create_time"]>0,"actual guarded process identity missing")
 need(str(g.get("executable_sha256","")).lower()==cold["game"]["executable"]["sha256"],"actual guard full64 EXE differs")
 for name in ("dll","injector"):
  need(profile[name]["sha256"]==cold["native_build"][name]["sha256"],"actual profile native build differs")
 binding={"profile_sha256":r["native_profile"]["sha256"],"pid":g["pid"],
  "process_create_time":g["process_create_time"],"exe_sha256":cold["game"]["executable"]["sha256"]}
 own=sha(Path(__file__).read_bytes());bp=sha(binding_raw)
 out.mkdir(parents=True)
 emit(out/"REQUEST.frozen.json",r)
 try:
  before=bf=None;before_cached=False
  if r["before"] is not None:before,bf,before_cached=observation(r["before"],binding,cache,own,bp)
  after,af,after_cached=observation(r["after"],binding,cache,own,bp)
  roles=None;query_frame_source=None
  if r["ordinary_query_sdk"] is not None:
   d=sdk(bytesref(r["ordinary_query_sdk"],cache))
   q=d.get("result",{}).get("character_interaction_ordinary_context",{})
   if d.get("snapshot_after",d.get("snapshot")) is not None:
    f=frame(d,binding);query_frame_source="ACTUAL_QUERY_SNAPSHOT"
   else:
    candidates=[("BEFORE_CHECKPOINT",bf),("AFTER_CHECKPOINT",af)]
    matched=[(label,x) for label,x in candidates if x is not None and
     x["profile_sha256"]==d.get("profile_sha256") and x["session_id"]==d.get("session_id") and
     x["pipe_name"]==d.get("pipe_name") and x["native_revision"]==q.get("snapshot_revision") and
     x["date_raw"]==q.get("date_raw") and x["PID"]==q.get("game_pid") and
     x["generation"]==q.get("connection_generation") and
     x["revision"]==d.get("result",{}).get("queried_revision")]
    need(bool(matched),"ordinary query needs actual exact same-frame checkpoint SDK; no snapshot invented")
    query_frame_source=matched[0][0]
    x=matched[0][1]
    f={"native_revision":x["native_revision"],"diagnostics":{"connection_generation":x["generation"]}}

   need(q.get("schema")=="ck3-character-interaction-ordinary-context-v1" and q.get("status")=="available" and
    q.get("player_character_id")==ACTOR and q.get("recipient_id")==RECIPIENT and q.get("interaction_key")==KEY and
    q.get("game_pid")==binding["pid"] and q.get("connection_generation")==f["diagnostics"]["connection_generation"] and
    q.get("snapshot_revision")==f["native_revision"] and q.get("exact_build")=="1.20.0.3" and
    str(q.get("executable_sha256","")).lower()==binding["exe_sha256"],"actual ordinary full identity differs")
   roles=closed(q.get("effective_roles"),("actor_id","recipient_id","secondary_actor_id","secondary_recipient_id","intermediary_id","sixth_role_id"),"actual final six roles")
   need(roles["actor_id"]==ACTOR and roles["recipient_id"]==RECIPIENT and all(v is None or
    (type(v) is int and 0<=v<=4294967294) for v in roles.values()),"invalid/redirected C2 primary final role")
   need(q.get("read_only") is True and q.get("business_postcondition_verified") is False,"query cannot grant business credit")
   for flag in ("source_code_pins_verified","actor_binding_verified","recipient_binding_verified","owner_thread_verified","tls_verified","frame_verified"):
    need(q.get(flag) is True,"ordinary query source proof missing "+flag)
  conditions=None
  if before is not None:conditions=details(before,after,bf,af,r["phase"])
  elif r["phase"]!="baseline":raise ValueError("actual before input required for a transition")
  for p,h in cache.items():need(sha(Path(p).read_bytes())==h,"input changed during readback")
  report={"schema":SCHEMA,"utc":datetime.now(timezone.utc).isoformat(),
   "status":"ACTUAL_NARROW_EXPECTATIONS_MATCH" if conditions is not None and not conditions["unmatched"] else
    ("ACTUAL_NARROW_EXPECTATIONS_NOT_MET" if conditions is not None else "ACTUAL_BASELINE_OBSERVED_ONLY"),
   "phase":r["phase"],"label":r["label"],"source_head":pins["source_head"],"bindings_sha256":bp,
   "reader_sha256":own,"native_profile_sha256":binding["profile_sha256"],"actual_root_cold_request":pins["cold_request"],
   "before_artifact":None if r["before"] is None else r["before"]["save"],"after_artifact":r["after"]["save"],
   "after_evidence":r["after"]["checkpoint_evidence"],"after_sdk":r["after"]["checkpoint_evidence"]["artifact"] if r["after"]["checkpoint_evidence"]["kind"]=="SDK_SAVE_RECEIPT" else None,
   "after_native_save_receipt":r["after"]["checkpoint_evidence"]["artifact"] if r["after"]["checkpoint_evidence"]["kind"]=="NATIVE_PROFILE_SAVE_RECEIPT" else None,
   "sdk_success_credit":af["sdk_success_credit"],"before_native":bf,"after_native":af,
   "before_projection_reused_without_parse":before_cached,"after_projection_reused_without_parse":after_cached,
   "before_state":before,"after_state":after,"conditions":conditions,"actual_final_six_roles":roles,
   "query_frame_source":query_frame_source,"query_missing_boundary":"null means no ordinary-query credit; exact same-frame checkpoint SDK is explicitly named when a query has no snapshot",
   "native_ACK_business_credit":False,"full_cycle_credit":False,"game_called":False,"host_release_called":False,
   "legacy_guard_fields_boundary":"NULL equality is not protection proof; separately read actual top-level character branches and positive domain titles"}
  emit(out/"REPORT.json",report)
 except Exception as e:
  emit(out/"FAILURE.json",{"schema":"lyd.r8.c2.increment-input-refusal.v1","status":"ACTUAL_READBACK_REFUSED",
   "error_type":type(e).__name__,"error":str(e),"request_sha256":sha(request_raw),"game_called":False})
  emit(out/"INDEX.json",{"schema":"lyd.r8.c2.increment-index.v1","files":[{**ref(p),"path":p.relative_to(out).as_posix()} for p in sorted(out.rglob("*")) if p.is_file()]})
  raise
 emit(out/"INDEX.json",{"schema":"lyd.r8.c2.increment-index.v1","files":[{**ref(p),"path":p.relative_to(out).as_posix()} for p in sorted(out.rglob("*")) if p.is_file()]})
 print(json.dumps({"status":report["status"],"report":str(out/"REPORT.json"),"report_sha256":sha((out/"REPORT.json").read_bytes()),
  "index_sha256":sha((out/"INDEX.json").read_bytes()),"full_cycle_credit":False}))
if __name__=="__main__":
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("--request",required=True,type=Path)
 main(parser.parse_args().request)
