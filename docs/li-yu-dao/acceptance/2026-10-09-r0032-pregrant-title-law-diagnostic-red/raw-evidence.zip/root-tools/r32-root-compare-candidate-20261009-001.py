"""Read-only R32 native cache and exact saved political/dynamic Title ASTs."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, "C:/lr31s1/tools/lyd_i3b_checkpoint_readback/reader")
from i3b_checkpoint_reader import title_database_records, title_row

RUN = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-032")
CLIENT = RUN / "diagnostic-mcp-client-002"
POLITICAL = {2230, 2231, 2232, 2235, 2262, 2263, 2264}
STAGES = {
    "D1": ("9e8f090d72f88cd3756f74dcfe9d25853320cc39d0a60fdcf72d1ee9f8e5df4b", RUN / "checkpoints/D1/checkpoint.ck3"),
    "D2a": ("76470da3f04754a392d1a033da3927fded84473c75a41c12a1f0e578343c38f6", RUN / "checkpoints/D2a/checkpoint.ck3"),
    "D2b": ("08e8c720e0c6028e12ef427a3842864700ac7fa451edef677360f7c473ae16b8", RUN / "checkpoints/D2b/checkpoint.ck3"),
}
SDK = {
    "D0_before": "0003-r32-D0-cache-before-001.sdk-result.json",
    "D0_after": "0006-r32-D0-cache-after-001.sdk-result.json",
    "D1_before": "0009-r32-D1-cache-before-001.sdk-result.json",
    "D1_after": "0012-r32-D1-cache-after-001.sdk-result.json",
    "D2a_before": "0014-r32-D2a-cache-before-001.sdk-result.json",
    "D2a_after": "0017-r32-D2a-cache-after-001.sdk-result.json",
    "D2b_before": "0019-r32-D2b-cache-before-001.sdk-result.json",
    "D2b_after": "0021-r32-D2b-cache-after-001.sdk-result.json",
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write(path: Path, value: dict) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as target:
        json.dump(value, target, ensure_ascii=False, indent=2)
        target.write("\n")


caches = {}
for stage, name in SDK.items():
    path = CLIENT / name
    raw = path.read_bytes()
    sdk = json.loads(raw)
    assert sdk["isError"] is False
    receipt = sdk["structuredContent"]
    assert receipt["status"] == "native_actor_cached_succession_observed"
    node = receipt["result"]["native_result"]["actor_cached_succession"]
    assert node["available"] is True and node["roster_complete"] is True and node["played_character_id"] == 31254
    ids = node["complete_cached_successor_ids"]
    assert len(ids) == node["native_count"] == len(set(ids))
    caches[stage] = {"sdk": {"path": str(path), "bytes": len(raw), "sha256": sha(raw)},
                     "count": len(ids), "ids": ids, "capture_epoch": node["capture_epoch"],
                     "queried_revision": receipt["result"]["queried_revision"]}

before = caches["D2a_after"]["ids"]
after = caches["D2b_before"]["ids"]
cache_result = {"schema": "lyd.r32.pregrant-law-cache-comparison.v1", "stage_caches": caches,
                "D2a_to_D2b": {"before_count": len(before), "after_count": len(after),
                               "lost_ids": sorted(set(before)-set(after)), "gained_ids": sorted(set(after)-set(before)),
                               "post_save_equal": after == caches["D2b_after"]["ids"]},
                "candidate_fixes_cache": False, "formal_I3b_credit": None}
assert [caches[n]["count"] for n in ("D0_before","D0_after","D1_before","D1_after","D2a_before","D2a_after","D2b_before","D2b_after")] == [45,45,45,45,45,45,40,40]
assert cache_result["D2a_to_D2b"]["post_save_equal"]
write(RUN / "R32-CACHE-COMPARISON.actual.json", cache_result)

saved = {}
for stage, (expected, path) in STAGES.items():
    raw = path.read_bytes()
    assert sha(raw) == expected
    text = raw.decode("utf-8-sig", errors="strict")
    titles = {}
    for tid, entries in title_database_records(text):
        if tid in POLITICAL or tid == 18373:
            titles[str(tid)] = title_row(tid, entries)
    assert POLITICAL <= {int(n) for n in titles}
    if stage == "D1":
        assert "18373" not in titles
    else:
        assert "18373" in titles
    saved[stage] = {"save": {"path": str(path), "bytes": len(raw), "sha256": expected}, "titles": titles}

political = {}
for n in sorted(POLITICAL):
    k = str(n)
    political[k] = {"D1": saved["D1"]["titles"][k]["AST_sha256"],
                    "D2a": saved["D2a"]["titles"][k]["AST_sha256"],
                    "D2b": saved["D2b"]["titles"][k]["AST_sha256"],
                    "D1_equals_D2a": saved["D1"]["titles"][k]["AST_sha256"] == saved["D2a"]["titles"][k]["AST_sha256"],
                    "D2a_equals_D2b": saved["D2a"]["titles"][k]["AST_sha256"] == saved["D2b"]["titles"][k]["AST_sha256"],
                    "holders": {s: saved[s]["titles"][k]["holder"] for s in STAGES}}
dynamic = {s: None if s == "D1" else {"AST_sha256": saved[s]["titles"]["18373"]["AST_sha256"],
                                       "holder": saved[s]["titles"]["18373"]["holder"],
                                       "top_level_keys": [e["key"] for e in saved[s]["titles"]["18373"]["entries"]],
                                       "law_like_entries": [e for e in saved[s]["titles"]["18373"]["entries"] if isinstance(e["key"], str) and "law" in e["key"]]}
           for s in STAGES}
saved_result = {"schema": "lyd.r32.pregrant-law-saved-title-comparison.v1", "stages": saved,
                "political_title_AST_hashes": political, "dynamic_title_18373": dynamic,
                "native_law_serialization_mapping_qualified": False, "formal_I3b_credit": None}
write(RUN / "R32-SAVED-TITLE-COMPARISON.actual.json", saved_result)
print(json.dumps({"cache_counts": {k:v["count"] for k,v in caches.items()},
                  "lost_ids": cache_result["D2a_to_D2b"]["lost_ids"], "gained_ids": cache_result["D2a_to_D2b"]["gained_ids"],
                  "political_changed_D1_D2a": [k for k,v in political.items() if not v["D1_equals_D2a"]],
                  "political_changed_D2a_D2b": [k for k,v in political.items() if not v["D2a_equals_D2b"]],
                  "dynamic": dynamic}, ensure_ascii=False))
