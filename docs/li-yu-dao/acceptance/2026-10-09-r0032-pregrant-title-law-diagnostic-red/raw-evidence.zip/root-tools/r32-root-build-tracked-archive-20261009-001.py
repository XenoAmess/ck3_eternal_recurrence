"""Create and verify the R32 diagnostic evidence archive; leave CK3 saves external."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

BASE = Path("C:/workspace/ck3_lyd_runtime_20261004")
RUN = BASE / "live-attempt-032"
OUT = Path("C:/workspace/ck3_eternal_recurrence/docs/li-yu-dao/acceptance/2026-10-09-r0032-pregrant-title-law-diagnostic-red")
PRE = BASE / "r32-root-steam-offline-recovery-20261009-002"
POST = BASE / "r32-root-steam-offline-final-20261009-001"
KEEP = BASE / "r32-root-screen-keeper-20261009-003"
CAND = BASE / "r32-pregrant-law-overlay-sourceonly-20261009-001"


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def file_ref(path: Path) -> dict:
    return {"path": path.as_posix(), "bytes": path.stat().st_size, "sha256": digest(path)}


selected: dict[str, Path] = {}


def add(name: str, path: Path) -> None:
    assert path.is_file() and name not in selected and not name.startswith("/") and ".." not in Path(name).parts
    selected[name] = path


for path in RUN.iterdir():
    if path.is_file() and path.suffix in {".json", ".py"}:
        add("run/" + path.name, path)
for dirname in ("diagnostic-mcp-client-001", "diagnostic-mcp-client-002", "diagnostic-mcp-queue-001", "diagnostic-mcp-queue-002", "native-evidence", "native-state", "native-profile-freeze-001", "native-profile-freeze-002"):
    root = RUN / dirname
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.suffix in {".json", ".log", ".input"}:
            add("run/" + dirname + "/" + path.relative_to(root).as_posix(), path)
for dirname in ("D1", "D2a", "D2b"):
    root = RUN / "checkpoints" / dirname
    for path in sorted(root.iterdir()):
        if path.is_file() and path.suffix == ".json":
            add("run/checkpoints/" + dirname + "/" + path.name, path)
for root, label in ((PRE, "steam-pre"), (POST, "steam-post")):
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.suffix in {".json", ".jsonl", ".png"}:
            add(label + "/" + path.relative_to(root).as_posix(), path)
for path in sorted(CAND.rglob("*")):
    if path.is_file():
        add("candidate/" + path.relative_to(CAND).as_posix(), path)
for path in (BASE / "r32-pregrant-law-overlay-static-20261009-001.json", BASE / "r32-build-pregrant-law-overlay-20261009-001.py", BASE / "r32-validate-pregrant-law-overlay-20261009-001.py"):
    add("candidate-tools/" + path.name, path)
for path in (KEEP / "INPUTS.json", KEEP / "ADMITTED.json", KEEP / "READY.json", KEEP / "FINAL.json", KEEP / "screen-lease.jsonl", KEEP / "STOP.request"):
    add("screen/" + path.name, path)
for path in sorted(BASE.glob("r32-root-*.py")):
    add("root-tools/" + path.name, path)

assert not OUT.exists()
OUT.mkdir(parents=True)
zip_path = OUT / "raw-evidence.zip"
with zipfile.ZipFile(zip_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(selected.items()):
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
archive_ref = file_ref(zip_path)

entries = []
with zipfile.ZipFile(zip_path) as archive:
    assert archive.namelist() == sorted(selected)
    for name in archive.namelist():
        original = selected[name]
        data = archive.read(name)
        expected = digest(original)
        assert len(data) == original.stat().st_size and hashlib.sha256(data).hexdigest() == expected
        entries.append({"name": name, "original": original.as_posix(), "bytes": len(data), "sha256": expected})

saves = {stage: file_ref(RUN / "checkpoints" / stage / "checkpoint.ck3") for stage in ("D1", "D2a", "D2b")}
saves["signed_B3_input"] = file_ref(RUN / "userdir/save games/lyd_r32_i3b_signed_B3_pregrant_diagnostic.ck3")
index = {"schema": "lyd.r32.diagnostic-archive-index.v1", "created_at_utc": datetime.now(timezone.utc).isoformat(),
         "run_id": "bf-202609141645-5434332d4d--li-yu-dao--R0032", "status": "DIAGNOSTIC_RED_NOT_FORMAL_I3B",
         "archive": {"name": zip_path.name, "bytes": archive_ref["bytes"], "sha256": archive_ref["sha256"]},
         "entry_count": len(entries), "entries": entries, "external_preserved_ck3_saves": saves,
         "old_failed_attempts_preserved": True, "source_production_modified": False,
         "archive_excludes_original_ck3_save_bodies_due_size": True}
with (OUT / "INDEX.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(index, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
validation = {"schema": "lyd.r32.diagnostic-archive-validation.v1", "validated_at_utc": datetime.now(timezone.utc).isoformat(),
              "zip_sha256": archive_ref["sha256"], "zip_bytes": archive_ref["bytes"],
              "entries_extracted_and_sha_verified": len(entries), "external_save_refs_verified": len(saves),
              "status": "PASS_ARCHIVE_BYTES_ONLY", "formal_I3b_credit": None}
with (OUT / "ARCHIVE-VALIDATION.actual.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(validation, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(json.dumps({"archive": archive_ref, "entries_verified": len(entries), "external_ck3_saves": saves, "status": validation["status"]}, ensure_ascii=False))
