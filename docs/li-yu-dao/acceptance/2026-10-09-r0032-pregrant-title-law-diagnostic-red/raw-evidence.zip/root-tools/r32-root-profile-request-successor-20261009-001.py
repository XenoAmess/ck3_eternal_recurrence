import json
from pathlib import Path

run = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-032")
original = json.loads((run / "native-profile-request-001.json").read_text(encoding="utf-8"))
assert original["output"] == str(run / "native-profile-freeze-001")
assert (run / "native-profile-freeze-001/profile-build-receipt.json").exists()
new = dict(original)
new["output"] = str(run / "native-profile-freeze-002")
with (run / "native-profile-request-002.json").open("x", encoding="utf-8", newline="\n") as target:
    json.dump(new, target, ensure_ascii=False, indent=2)
    target.write("\n")
print(new["output"])
