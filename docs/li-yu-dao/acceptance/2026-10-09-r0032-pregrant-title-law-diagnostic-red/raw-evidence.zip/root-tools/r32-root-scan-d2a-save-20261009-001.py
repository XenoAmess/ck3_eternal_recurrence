import hashlib
import json
import mmap
from pathlib import Path

path = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-032/checkpoints/D2a/checkpoint.ck3")
with path.open("rb") as source, mmap.mmap(source.fileno(), 0, access=mmap.ACCESS_READ) as body:
    probes = {}
    for key in (b"temporal_head_of_faith_succession_law", b"18373", b"title_laws", b"law", b"gamestate", b"meta_data"):
        hits = []
        pos = 0
        while len(hits) < 5:
            pos = body.find(key, pos)
            if pos < 0:
                break
            hits.append(pos)
            pos += 1
        probes[key.decode()] = hits
    result = {"schema": "lyd.r32.raw-checkpoint-byte-scan.v1", "path": str(path), "sha256": hashlib.sha256(body).hexdigest(),
              "bytes": len(body), "first128_repr": repr(body[:128]), "probes": probes,
              "interpretation": "byte-presence only; not saved title law validation"}
out = path.parent / "RAW-BYTE-SCAN.actual.json"
with out.open("x", encoding="utf-8", newline="\n") as target:
    json.dump(result, target, ensure_ascii=False, indent=2)
    target.write("\n")
print(json.dumps(result, ensure_ascii=False))
