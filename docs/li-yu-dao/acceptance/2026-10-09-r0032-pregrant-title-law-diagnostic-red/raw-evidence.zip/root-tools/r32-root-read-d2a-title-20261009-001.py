"""Read only the preserved R32 D2a save and retain exact Title 18373 AST."""
import hashlib
import json
from pathlib import Path
import sys

reader_dir = Path("C:/lr31s1/tools/lyd_i3b_checkpoint_readback/reader")
sys.path.insert(0, str(reader_dir))
from i3b_checkpoint_reader import title_database_records, title_row

run = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-032")
path = run / "checkpoints/D2a/checkpoint.ck3"
expected = "76470da3f04754a392d1a033da3927fded84473c75a41c12a1f0e578343c38f6"
data = path.read_bytes()
assert hashlib.sha256(data).hexdigest() == expected
text = data.decode("utf-8-sig", errors="strict")
found = []
for tid, entries in title_database_records(text):
    if tid == 18373:
        found.append(title_row(tid, entries))
assert len(found) == 1
row = found[0]
out = run / "checkpoints/D2a/TITLE-18373.actual.json"
with out.open("x", encoding="utf-8", newline="\n") as target:
    json.dump({"schema": "lyd.r32.saved-title-ast-readonly.v1", "save": path.as_posix(), "save_sha256": expected,
               "title": row, "native_law_mapping_qualified": False}, target, ensure_ascii=False, indent=2)
    target.write("\n")
print(json.dumps({"title_id": row["title_id"], "holder": row["holder"], "AST_sha256": row["AST_sha256"],
                  "top_level_keys": [e["key"] for e in row["entries"]],
                  "law_like_entries": [e for e in row["entries"] if isinstance(e["key"], str) and "law" in e["key"]],
                  "out": str(out)}, ensure_ascii=False))
