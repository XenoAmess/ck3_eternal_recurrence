import json
import psutil
rows = []
for process in psutil.process_iter(["pid", "name", "exe", "create_time"]):
    info = process.info
    name = (info.get("name") or "").lower()
    if name in {"steam.exe", "steamwebhelper.exe", "ck3.exe", "todesk.exe", "todesk_service.exe"}:
        rows.append({k: info.get(k) for k in ("pid", "name", "exe", "create_time")})
print(json.dumps(rows, ensure_ascii=False))
