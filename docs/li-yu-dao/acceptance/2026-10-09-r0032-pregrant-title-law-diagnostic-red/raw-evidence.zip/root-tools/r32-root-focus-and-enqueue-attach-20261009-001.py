"""Bind R32 CK3 UIA focus and one explicit MCP attach request in one step."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import time

import psutil
import win32gui
import win32process
from pywinauto import Desktop

run = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-032")
launch = json.loads((run / "launch.json").read_text(encoding="utf-8"))
observed = json.loads((run / "native-profile-process-observation-001.json").read_text(encoding="utf-8"))
pid = launch["pid"]
hwnd = observed["windows"][0]["hwnd"]
source = run / "r32-attach-002.source.json"
target = run / "diagnostic-mcp-queue-002/r32-attach-002.request.json"
assert not target.exists()
assert (run / "diagnostic-mcp-client-002/0001-r32-inventory-002.response.json").exists()
assert psutil.Process(pid).create_time() == launch["process_create_time"]
assert win32gui.IsWindowVisible(hwnd) and win32process.GetWindowThreadProcessId(hwnd)[1] == pid
before = win32gui.GetForegroundWindow()
element = Desktop(backend="uia").window(handle=hwnd).wrapper_object().element_info.element
assert int(element.CurrentProcessId) == pid and int(element.CurrentNativeWindowHandle) == hwnd
assert win32gui.IsWindowVisible(hwnd) and win32process.GetWindowThreadProcessId(hwnd)[1] == pid
element.SetFocus()
deadline = time.monotonic() + 2.0
while win32gui.GetForegroundWindow() != hwnd and time.monotonic() < deadline:
    time.sleep(0.05)
actual = win32gui.GetForegroundWindow()
assert actual == hwnd
raw = source.read_bytes()
assert json.loads(raw) == {"request_id": "r32-attach-002", "operation": "call_tool", "name": "ck3_attach_profile_bridge_v1", "arguments": {}}
with (run / "native-attach-focus-002.json").open("x", encoding="utf-8", newline="\n") as receipt:
    json.dump({"utc": datetime.now(timezone.utc).isoformat(), "method": "IUIAutomationElement.SetFocus", "before": before, "after": actual,
               "target_pid": pid, "target_hwnd": hwnd, "request_sha256": hashlib.sha256(raw).hexdigest(),
               "keyboard_or_mouse_input_sent": False}, receipt, indent=2)
    receipt.write("\n")
os.link(source, target)
print(json.dumps({"status": "FOCUSED_AND_EXPLICIT_ATTACH_QUEUED", "hwnd": actual, "queue": str(target)}))
