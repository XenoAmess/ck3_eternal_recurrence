import json
from pathlib import Path
import sys
import zipfile

path = Path(sys.argv[1])
with path.open("rb") as source:
    head = source.read(32)
print(json.dumps({"path": str(path), "bytes": path.stat().st_size, "first32hex": head.hex(), "is_zip": zipfile.is_zipfile(path)}))
if zipfile.is_zipfile(path):
    with zipfile.ZipFile(path) as archive:
        print(json.dumps({"entries": [{"name": info.filename, "size": info.file_size, "compressed": info.compress_size} for info in archive.infolist()]}))
