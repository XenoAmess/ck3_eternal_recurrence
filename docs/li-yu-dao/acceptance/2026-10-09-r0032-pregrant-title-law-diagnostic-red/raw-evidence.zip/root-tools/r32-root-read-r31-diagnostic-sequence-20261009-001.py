import json
from pathlib import Path

old = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-031")
for phase in ("D0", "D1", "D2a", "D2b"):
    rows = []
    for path in sorted(old.glob(f"r31-root-{phase}-*.SPEC.actual.json")):
        row = json.loads(path.read_text(encoding="utf-8"))
        rows.append({"request_id": row["request_id"], "name": row.get("name"), "arguments": row.get("arguments")})
    print(json.dumps({"phase": phase, "requests": rows}, ensure_ascii=False))
