"""Atomically publish one explicit R32 request without contacting CK3."""
import hashlib
import json
import os
from pathlib import Path
import sys

run = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-032")
suffix = sys.argv[2] if len(sys.argv) == 3 else "001"
assert suffix in {"001", "002"}
queue = run / ("diagnostic-mcp-queue-" + suffix)
source = Path(sys.argv[1]).resolve()
assert source.is_relative_to(run) and source.parent == run and queue.is_dir()
raw = source.read_bytes()
request = json.loads(raw)
assert set(request) == {"request_id", "operation", "name", "arguments"}
assert source.name == request["request_id"] + ".source.json"
target = queue / (request["request_id"] + ".request.json")
assert not target.exists()
os.link(source, target)
print(json.dumps({"queued": str(target), "sha256": hashlib.sha256(raw).hexdigest(), "contacted_game": False}))
