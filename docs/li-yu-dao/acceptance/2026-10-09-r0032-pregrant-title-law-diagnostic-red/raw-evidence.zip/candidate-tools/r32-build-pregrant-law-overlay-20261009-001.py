"""Create an immutable R32 diagnostic overlay with one pre-grant title law."""
from pathlib import Path
import hashlib
import json
import shutil
import sys

B = Path("C:/workspace/ck3_lyd_runtime_20261004")
SOURCE = B / "live-attempt-031/content/diagnostic_stage"
OUTPUT = B / "r32-pregrant-law-overlay-sourceonly-20261009-001"
TARGET = Path("common/scripted_effects/lyd_i3b_commit_effects.txt")
EXPECTED = "1bc34f14d245d2e8f17c05b2dffd4a60242387e44a8ad81d299727d8e59716a3"
OLD = "        set_always_follows_primary_heir = yes\n    }\n    save_scope_value_as = { name = lyd_factory_diag_stage value = 20 }"
NEW = "        set_always_follows_primary_heir = yes\n    }\n    scope:new_title = { add_title_law = temporal_head_of_faith_succession_law }\n    save_scope_value_as = { name = lyd_factory_diag_stage value = 20 }"

def ref(path):
    raw = path.read_bytes()
    return {"path": path.as_posix(), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}

def write(path, obj):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(obj, stream, ensure_ascii=False, indent=2)
        stream.write("\n")

assert SOURCE.is_dir() and not OUTPUT.exists()
raw = (SOURCE / TARGET).read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED
text = raw.decode("utf-8-sig")
assert text.count(OLD) == 1 and text.count(NEW) == 0
shutil.copytree(SOURCE, OUTPUT)
result = text.replace(OLD, NEW).encode("utf-8-sig")
(OUTPUT / TARGET).write_bytes(result)
assert (OUTPUT / TARGET).read_bytes() == result
files = []
for path in sorted(OUTPUT.rglob("*")):
    if not path.is_file():
        continue
    rel = path.relative_to(OUTPUT)
    before = SOURCE / rel
    if rel == TARGET:
        assert before.read_bytes() != path.read_bytes()
    else:
        assert before.read_bytes() == path.read_bytes()
    files.append({"relative_path": rel.as_posix(), "original": ref(before), "candidate": ref(path)})
assert len(files) == 6
manifest = {
    "schema": "lyd.r32.pregrant-law-diagnostic-overlay.v1",
    "status": "SOURCE_ONLY_NOT_RUN",
    "loaded_production_head": "06159b964d859d30f2f07f4b183284df7d6dac47",
    "precise_change": "One add_title_law on unheld T after D2a properties and before D2b holder/resolve",
    "stage": "D2a",
    "source_overlay": SOURCE.as_posix(),
    "output_overlay": OUTPUT.as_posix(),
    "files": files,
    "production71_modified": False,
    "formal_acceptance": None,
    "whole_mod": "NOT_GREEN",
}
write(OUTPUT / "CANDIDATE-MANIFEST.json", manifest)
print(json.dumps({"manifest": ref(OUTPUT / "CANDIDATE-MANIFEST.json"), "candidate_source": ref(OUTPUT / TARGET), "file_count": len(files)}, ensure_ascii=False))
