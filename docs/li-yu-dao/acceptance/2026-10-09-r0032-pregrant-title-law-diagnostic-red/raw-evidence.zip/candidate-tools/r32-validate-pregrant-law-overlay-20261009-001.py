"""Validate exact one-operation R32 overlay delta and Clausewitz parse."""
from pathlib import Path
import hashlib
import json
import sys

B = Path("C:/workspace/ck3_lyd_runtime_20261004")
BASE = B / "live-attempt-031/content/diagnostic_stage"
CANDIDATE = B / "r32-pregrant-law-overlay-sourceonly-20261009-001"
SOURCE = Path("C:/workspace/ck3_eternal_recurrence")
OUT = B / "r32-pregrant-law-overlay-static-20261009-001.json"
sys.path.insert(0, str(SOURCE / "tools"))
from extract_auto_upgrade_buildings import parse_clausewitz, Block

def ref(path):
    raw = path.read_bytes()
    return {"path": path.as_posix(), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
def one(block, key):
    rows = [e.value for e in block.entries if e.key == key]
    assert len(rows) == 1, (key, len(rows))
    return rows[0]
manifest = json.loads((CANDIDATE / "CANDIDATE-MANIFEST.json").read_bytes())
assert manifest["status"] == "SOURCE_ONLY_NOT_RUN" and len(manifest["files"]) == 6
for row in manifest["files"]:
    base = BASE / row["relative_path"]
    variant = CANDIDATE / row["relative_path"]
    assert ref(base) == row["original"] and ref(variant) == row["candidate"]
    if row["relative_path"] != "common/scripted_effects/lyd_i3b_commit_effects.txt":
        assert base.read_bytes() == variant.read_bytes()
for path in sorted(CANDIDATE.rglob("*")):
    if path.is_file() and path.suffix in {".txt", ".mod"}:
        parse_clausewitz(path.read_text(encoding="utf-8-sig"))
base_text = (BASE / "common/scripted_effects/lyd_i3b_commit_effects.txt").read_text(encoding="utf-8-sig")
candidate_text = (CANDIDATE / "common/scripted_effects/lyd_i3b_commit_effects.txt").read_text(encoding="utf-8-sig")
law_line = "    scope:new_title = { add_title_law = temporal_head_of_faith_succession_law }\n"
assert candidate_text.count(law_line) == base_text.count(law_line) + 1
assert candidate_text.replace(law_line, "", 1) == base_text
root = parse_clausewitz(candidate_text)
d2a = one(root, "lyd_factory_diag_d20_effect")
d2b = one(root, "lyd_factory_diag_d2_effect")
keys = [e.key for e in d2a.entries]
assert keys == ["create_dynamic_title", "scope:new_title", "scope:new_title", "save_scope_value_as", "trigger_event"]
assert one(d2a.entries[2].value, "add_title_law") == "temporal_head_of_faith_succession_law"
assert [e.key for e in d2b.entries] == ["create_title_and_vassal_change", "scope:new_title", "resolve_title_and_vassal_change", "save_scope_value_as", "trigger_event"]
result = {"schema":"lyd.r32.pregrant-law-overlay-static.v1","status":"PASS_SOURCE_ONLY_RUNTIME_NOT_RUN","base":ref(BASE / "common/scripted_effects/lyd_i3b_commit_effects.txt"),"candidate":ref(CANDIDATE / "common/scripted_effects/lyd_i3b_commit_effects.txt"),"delta":"exactly one pregrant add_title_law in D2a; D2b atomic unchanged","syntax":"all candidate txt and descriptor parsed","production71_modified":False,"formal_acceptance":None,"whole_mod":"NOT_GREEN"}
with OUT.open("x", encoding="utf-8", newline="\n") as f:
    json.dump(result,f,ensure_ascii=False,indent=2)
    f.write("\n")
print(json.dumps({"result":ref(OUT),"status":result["status"]},ensure_ascii=False))
