﻿version="0.0.1"
name="LYD Factory Operation Diagnostic - DEVELOPMENT ONLY"
supported_version="1.20.*"
dependencies={ "礼与道：儒家礼仪与学统 / Rites and the Way" }
path="C:/workspace/ck3_lyd_runtime_20261004/live-attempt-036/content/diagnostic_stage"
