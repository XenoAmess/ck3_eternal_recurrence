import hashlib
import json
from pathlib import Path

run = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-036")
source = run / "native-profile-freeze-001/native-profile.json"
inventory = run / "userdir/normal-exit-source-inventory-v1.json"
out = run / "native-profile-with-exit-inventory.json"
profile = json.loads(source.read_text(encoding="utf-8"))
assert "normal_exit_source_inventory" not in profile and inventory.is_file()
profile["normal_exit_source_inventory"] = {"path": inventory.as_posix(), "sha256": hashlib.sha256(inventory.read_bytes()).hexdigest()}
with out.open("x", encoding="utf-8", newline="\n") as target:
    json.dump(profile, target, ensure_ascii=False, indent=2)
    target.write("\n")
print(json.dumps({"profile": out.as_posix(), "sha256": hashlib.sha256(out.read_bytes()).hexdigest()}))
