"""Bind the reviewed R35 official MCP queue to R36's exact frozen profile."""
from pathlib import Path
import hashlib
import json

B=Path('C:/workspace/ck3_lyd_runtime_20261004')
RUN=B/'live-attempt-036'
OLD_SHA='9e4bc045b877d74d46a726d151ace9c0011638616fe3b1b98bffd08a0596990b'
PROFILE=RUN/'native-profile-with-exit-inventory.json'
NEW_SHA=hashlib.sha256(PROFILE.read_bytes()).hexdigest()
names=['r35-root-diagnostic-mcp-client-20261009-001.py','r35-root-queue-request-20261009-001.py','r35-root-read-sdk-20261009-001.py','r35-root-focus-and-enqueue-attach-20261009-001.py']
rows=[]
for name in names:
    src=B/name
    raw=src.read_bytes(); value=raw.decode('utf-8')
    assert 'live-attempt-035' in value
    value=value.replace('live-attempt-035','live-attempt-036').replace('R35','R36').replace('r35','r36')
    if name==names[0]:
        assert OLD_SHA in value
        value=value.replace(OLD_SHA,NEW_SHA)
    target=B/name.replace('r35-','r36-')
    with target.open('x',encoding='utf-8',newline='\n') as stream:stream.write(value)
    rows.append({'source':src.as_posix(),'source_sha256':hashlib.sha256(raw).hexdigest(),'target':target.as_posix(),'target_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
for oldname in ('r35-inventory-002.source.json','r35-attach-002.source.json'):
    src=B/'live-attempt-035'/oldname
    raw=src.read_bytes(); obj=json.loads(raw)
    assert obj['request_id']==oldname.removesuffix('.source.json')
    obj['request_id']=obj['request_id'].replace('r35','r36')
    target=RUN/oldname.replace('r35','r36')
    with target.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(obj,stream,separators=(',',':'));stream.write('\n')
    rows.append({'source':src.as_posix(),'source_sha256':hashlib.sha256(raw).hexdigest(),'target':target.as_posix(),'target_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
out=B/'r36-root-native-client-derivation-20261009-001.json'
with out.open('x',encoding='utf-8',newline='\n') as stream:
    json.dump({'schema':'lyd.r36.derived-official-mcp-client.v1','profile_sha256':NEW_SHA,'rows':rows},stream,indent=2);stream.write('\n')
print(json.dumps({'report':out.as_posix(),'derived':len(rows),'profile_sha256':NEW_SHA}))
