"""Read-only successive R36 desktop capture; requires the exact game HWND foreground."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import psutil
import pyautogui
import sys
import win32gui
import win32process

number = int(sys.argv[1])
assert 3 <= number <= 20
run = Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-036')
launch = json.loads((run / 'launch.json').read_bytes())
pid = launch['pid']
windows = []
def collect(hwnd, unused):
    if win32gui.IsWindowVisible(hwnd) and win32process.GetWindowThreadProcessId(hwnd)[1] == pid:
        windows.append(hwnd)
win32gui.EnumWindows(collect, None)
assert len(windows) == 1 and psutil.Process(pid).create_time() == launch['process_create_time']
hwnd = windows[0]
assert win32gui.GetForegroundWindow() == hwnd
image = run / f'R36-LOAD-STATE-{number:03d}.png'
receipt = run / f'R36-LOAD-STATE-{number:03d}.json'
assert not image.exists() and not receipt.exists()
pyautogui.screenshot().save(image)
raw = image.read_bytes()
with receipt.open('x', encoding='utf-8', newline='\n') as target:
    json.dump({'utc':datetime.now(timezone.utc).isoformat(),'pid':pid,'hwnd':hwnd,'foreground_hwnd':hwnd,'image':image.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'screen_size':list(pyautogui.size()),'input_sent':False},target,indent=2)
    target.write('\n')
print(json.dumps({'image':image.as_posix(),'sha256':hashlib.sha256(raw).hexdigest()}))
