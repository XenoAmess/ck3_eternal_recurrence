from pathlib import Path
import json

p=Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-036/diagnostic-mcp-client-001/0004-r36-cold-D2a-window-001.sdk-result.json')
j=json.loads(p.read_bytes())['structuredContent']['result']
w=j['current_event_window_context']
print(json.dumps({'event':w['event_definition_key'],'instance_id':w['current_event_instance_id'],'root':w['root_scope'].get('typed_identity'),'saved_scopes':[{'name':x['name'],'type':x['scope'].get('type_key'),'identity':x['scope'].get('typed_identity')} for x in w['saved_scopes']]},ensure_ascii=False))
