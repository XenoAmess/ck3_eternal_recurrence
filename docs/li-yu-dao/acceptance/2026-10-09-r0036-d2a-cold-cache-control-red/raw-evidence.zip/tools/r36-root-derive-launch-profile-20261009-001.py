"""Clone reviewed R35 launch/profile helpers with exact R36 diagnostic bindings."""
from pathlib import Path
import hashlib
import json

B=Path('C:/workspace/ck3_lyd_runtime_20261004')
sources=[
 'r35-root-launch-diagnostic-20261009-001.py',
 'r35-root-prepare-native-profile-20261009-001.py',
 'r35-root-capture-load-state-20261009-001.py',
 'r35-root-focus-game-20261009-001.py',
 'r35-root-normal-exit-inventory-20261009-001.py',
 'r35-root-bind-normal-exit-profile-20261009-001.py',
 'r35-root-capture-load-state-repeat-20261009-001.py',
]
replacements=[
 ('live-attempt-035','live-attempt-036'),
 ('r35-root-steam-offline-recovery-20261009-001','r36-root-steam-offline-recovery-20261009-001'),
 ('lyd-r0035-d1-cold-diagnostic-live-root','lyd-r0036-d2a-cold-diagnostic-live-root'),
 ('lyd_r35_D1_cold_diagnostic','lyd_r36_D2a_cold_diagnostic'),
 ('c02bdd05be9935de4152fdf3d880788b05ed56e0d8eecc24c36ff17a2e8cdd2d','a6db85e38ba0648eca4b7e835c79d867b96ca26099698f4d4ee5269b818d822c'),
 ('R0035','R0036'),('R35','R36'),('r35','r36'),('D1 checkpoint seed changed','D2a checkpoint seed changed'),
]
rows=[]
for name in sources:
    source=B/name
    raw=source.read_bytes(); value=raw.decode('utf-8')
    counts={}
    for before,after in replacements:
        counts[before]=value.count(before); value=value.replace(before,after)
    assert counts['live-attempt-035']>=1
    if name in sources[:2]:
        assert counts['lyd-r0035-d1-cold-diagnostic-live-root']>=1
        assert counts['r35-root-steam-offline-recovery-20261009-001']>=1
    target=B/name.replace('r35-','r36-')
    with target.open('x',encoding='utf-8',newline='\n') as stream:stream.write(value)
    rows.append({'source':source.as_posix(),'source_sha256':hashlib.sha256(raw).hexdigest(),'target':target.as_posix(),'target_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'replacement_counts':counts})
out=B/'r36-root-launch-profile-derivation-20261009-001.json'
with out.open('x',encoding='utf-8',newline='\n') as stream:
    json.dump({'schema':'lyd.r36.derived-launch-profile.v1','rows':rows},stream,indent=2)
    stream.write('\n')
print(json.dumps({'output':out.as_posix(),'derived':len(rows)}))
