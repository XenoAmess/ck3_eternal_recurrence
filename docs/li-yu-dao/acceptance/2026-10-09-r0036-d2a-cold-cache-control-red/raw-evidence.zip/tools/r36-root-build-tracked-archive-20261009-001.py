"""Archive R36 D2a cold-reload control and verify extracted evidence bytes."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

REPO = Path('C:/workspace/ck3_eternal_recurrence')
B = Path('C:/workspace/ck3_lyd_runtime_20261004')
RUN = B / 'live-attempt-036'
PRIOR = B / 'live-attempt-034'
OUT = REPO / 'docs/li-yu-dao/acceptance/2026-10-09-r0036-d2a-cold-cache-control-red'
if OUT.exists():
    assert OUT.is_dir() and not any(OUT.iterdir())
else:
    OUT.mkdir(parents=True)

def pin(path: Path) -> dict:
    h = hashlib.sha256()
    n = 0
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
            n += len(chunk)
    return {'path': path.as_posix(), 'bytes': n, 'sha256': h.hexdigest()}

def put(path: Path, value: dict) -> None:
    if path.exists():
        assert path.is_file() and path.stat().st_size > 0
        return
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

seed = PRIOR / 'checkpoints/D2a/checkpoint.ck3'
copy = RUN / 'userdir/save games/lyd_r36_D2a_cold_diagnostic.ck3'
assert pin(seed)['bytes'] == pin(copy)['bytes'] == 91711686
assert pin(seed)['sha256'] == pin(copy)['sha256'] == 'a6db85e38ba0648eca4b7e835c79d867b96ca26099698f4d4ee5269b818d822c'
old_source = PRIOR / 'R34-CACHE-COMPARISON.actual.json'
old = json.loads(old_source.read_bytes())
new_sdk = RUN / 'diagnostic-mcp-client-001/0003-r36-cold-D2a-cache-001.sdk-result.json'
window_sdk = RUN / 'diagnostic-mcp-client-001/0004-r36-cold-D2a-window-001.sdk-result.json'
new = json.loads(new_sdk.read_bytes())
window = json.loads(window_sdk.read_bytes())
result = new['structuredContent']['result']
native = result['native_result']
ids = native['actor_cached_succession']['complete_cached_successor_ids']
old_ids = old['stage_caches']['D2a_after']['ids']
assert new['isError'] is False and native['read_only'] is True
assert result['queried_revision'] == 2 and native['snapshot_revision'] == 1
assert ids == old_ids and len(ids) == 45
assert all(x in ids for x in [38561, 39045, 39171, 39352, 39527])
assert old['D2a_to_D2b']['after_count'] == 40
w = window['structuredContent']['result']
assert window['isError'] is False and w['event_definition_key'] == 'lyd_factory_diag.20'
assert w['current_event_instance_id'] == 121 and w['queried_revision'] == 2
wc = w['current_event_window_context']
assert wc['root_scope']['typed_identity']['character_id'] == 31254
scope = next(x for x in wc['saved_scopes'] if x['name'] == 'new_title')
assert scope['scope']['typed_identity']['title_id'] == 18373
assert json.loads((RUN / 'game-original-handle-final.json').read_bytes())['returncode'] == 0
exit_sdk = json.loads((RUN / 'diagnostic-mcp-client-001/0011-r36-exit-observe-001.sdk-result.json').read_bytes())
ex = exit_sdk['structuredContent']['result']
assert exit_sdk['isError'] is False and ex['status'] == 'process_exit_observed_zero'
assert ex['typed_normal_exit_observed'] is True and ex['exit_code'] == 0 and ex['autosave_verified'] is False
assert json.loads((RUN / 'diagnostic-mcp-client-001/final.json').read_bytes())['status'] == 'CLOSED'
keeper = json.loads((B / 'r36-root-screen-keeper-20261009-001/FINAL.json').read_bytes())
assert keeper['failure'] is None and keeper['thread_exited'] is True and keeper['last_sequence'] == 4126
for folder in ('r36-root-steam-offline-recovery-20261009-001', 'r36-root-steam-offline-final-20261009-001'):
    review = json.loads((B / folder / 'OFFLINE-REVIEW.actual.json').read_bytes())
    assert review['steam_offline_confirmed'] is True
    assert pin(B / folder / review['image'])['sha256'] == review['image_sha256']
bus = subprocess.run([sys.executable, '-B', '-X', 'utf8', str(REPO / 'tools/codex_task_bus.py'), '--bus-dir', 'C:/workspace/.codex-task-bus', '--expected-cli-sha256', 'B3C44B42F7BDF401B593D863E3210106A46412DCD7D89F8596C74F4C27392DEE', 'list', '--stale-after', '600'], capture_output=True, check=True, timeout=15)
tasks = json.loads(bus.stdout)['tasks']
task = next(x for x in tasks if x['task_id'] == 'lyd-r0036-d2a-cold-diagnostic-live-root')
assert task['state'] == 'done' and task['resources'] == [] and task['last_sequence'] == 4127
put(RUN / 'R36-CLOSEOUT-TASK.actual.json', task)
comparison = {
    'schema': 'lyd.r36.d2a-cold-cache-control.v1',
    'source_R34_D2a_checkpoint': pin(seed), 'R36_copied_seed': pin(copy),
    'R34_hot_D2a_cache_source': pin(old_source), 'R36_cold_D2a_cache_source': pin(new_sdk),
    'R36_event_window_source': pin(window_sdk),
    'hot_count': len(old_ids), 'cold_count': len(ids), 'ordered_ids_exactly_equal': True,
    'still_present_ids': [38561, 39045, 39171, 39352, 39527],
    'saved_new_title_id_after_cold_reload': 18373,
    'R34_D2b_hot_count': 40,
    'inference': 'D2a cold reload alone did not reproduce the D2b 45-to-40 loss; new_title scope survived; R36 does not isolate a sub-operation inside D2b.',
    'formal_I3b_credit': None, 'whole_mod': 'NOT_GREEN',
}
put(RUN / 'R36-D2A-COLD-COMPARISON.actual.json', comparison)

files = {}
def add(root: Path, pattern: str, prefix: str) -> None:
    for path in root.glob(pattern):
        if path.is_file() and path.suffix.lower() != '.ck3':
            arc = prefix + '/' + path.relative_to(root).as_posix()
            assert arc not in files
            files[arc] = path

add(B, 'r36-root-*.py', 'tools')
for name in ('r36-root-launch-profile-derivation-20261009-001.json', 'r36-root-native-client-derivation-20261009-001.json'):
    path = B / name
    assert path.is_file(), path
    files['preparation/' + name] = path
for pattern in ('*.json', '*.png', '*.txt'):
    add(RUN, pattern, 'run')
for folder in ('diagnostic-mcp-client-001', 'native-profile-freeze-001', 'native-evidence'):
    add(RUN / folder, '**/*', 'run/' + folder)
for name in ('pdx_settings.txt', 'dlc_load.json', 'tutorial.txt', 'normal-exit-source-inventory-v1.json'):
    path = RUN / 'userdir' / name
    assert path.is_file(), path
    files['run/userdir/' + name] = path
add(RUN / 'userdir/mod', '*.mod', 'run/userdir/mod')
for name in ('debug.log', 'error.log', 'game.log', 'profile.log'):
    path = RUN / 'userdir/logs' / name
    assert path.is_file(), path
    files['run/userdir/logs/' + name] = path
for phase, folder in (('prelaunch', 'r36-root-steam-offline-recovery-20261009-001'), ('final', 'r36-root-steam-offline-final-20261009-001')):
    root = B / folder
    for name in ('OFFLINE-REVIEW.actual.json', 'events.jsonl'):
        path = root / name
        assert path.is_file(), path
        files[f'steam/{phase}/{name}'] = path
    add(root / 'probe-1', '*', f'steam/{phase}/probe-1')
for name in ('FINAL.json', 'READY.json', 'screen-lease.jsonl', 'STOP.request'):
    path = B / 'r36-root-screen-keeper-20261009-001' / name
    assert path.is_file(), path
    files['screen-lease/' + name] = path
for arc, path in files.items():
    assert path.stat().st_size <= 20_000_000, (arc, path.stat().st_size)
entries = [{'archive_path': arc, 'source': pin(path)} for arc, path in sorted(files.items())]
index = {
    'schema': 'lyd.r36.d2a-cold-cache-control-archive.v1',
    'status': 'DIAGNOSTIC_CONTROL_PASS_FORMAL_I3B_RED',
    'live_run_id': 'bf-202609141645-5434332d4d--li-yu-dao--R0036',
    'source_production_head': '06159b964d859d30f2f07f4b183284df7d6dac47',
    'checkout_head_at_launch': '5f1921821962cc7cc5cb27e4ca9530b46bef6150',
    'external_save_bodies': [{'role': 'R34_D2a_original', **pin(seed), 'tracked_zip_included': False}, {'role': 'R36_cold_copy', **pin(copy), 'tracked_zip_included': False}],
    'evidence_entries': entries, 'formal_acceptance_credit': False,
}
put(OUT / 'INDEX.json', index)
report = '''# R0036 D2a cold-reload succession-cache control — diagnostic only

R36 loaded the exact R34 D2a checkpoint (`a6db85e38ba0648eca4b7e835c79d867b96ca26099698f4d4ee5269b818d822c`, 91,711,686 bytes) into a new isolated userdir on CK3 1.20.0.4. The six mod trees were copied byte-for-byte from R34, including its development-only overlay; 129 content files were verified. No product source changed. This run issued no event option, title grant, or checkpoint save after loading.

The paused cold-loaded event was independently read as `lyd_factory_diag.20`, instance `121`, at public revision `2`. Its saved `new_title` scope still resolved to landed title `18373`; the root actor was `31254`. The official native cached-succession query at that revision returned **45 ordered IDs**, exactly equal to R34 D2a after-save, including `38561, 39045, 39171, 39352, 39527`. R34's later atomic D2b operation returned 40. This control excludes **D2a cold reload alone** as the cause of the five-ID loss in this seed and build. Together with R35, both D1 and D2a cold reload controls preserve all 45. The causal operation inside atomic D2b remains unidentified.

The original CK3 process handle and official normal-exit observer both returned exit code `0`; the observer recorded `typed_normal_exit_observed=true` and `autosave_verified=false`. Fresh original prelaunch and post-exit desktop screenshots were visually reviewed as Steam “离线模式”. The screen keeper ended without failure and the exclusive task was released with no resources. The MCP client was closed.

Formal I3b, a newly created religious Title cold reload, C3, I4 and whole-mod GREEN remain **NOT_GREEN**. The next useful experiment must isolate a sub-operation inside D2b without silently changing the intended political transaction, or derive a production fix with direct evidence. `INDEX.json` pins the two external 91 MB save bodies; the ZIP contains small source, request, SDK, native, log, offline and lease evidence. `ARCHIVE-VALIDATION.actual.json` verifies every ZIP entry's extracted bytes.
'''
with (OUT / 'REPORT.md').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(report)
zip_path = OUT / 'raw-evidence.zip'
with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for entry in entries:
        archive.write(files[entry['archive_path']], entry['archive_path'])
with zipfile.ZipFile(zip_path, 'r') as archive:
    assert sorted(archive.namelist()) == sorted(files)
    for entry in entries:
        raw = archive.read(entry['archive_path'])
        assert len(raw) == entry['source']['bytes'] and hashlib.sha256(raw).hexdigest() == entry['source']['sha256']
validation = {'schema': 'lyd.r36.archive-extracted-byte-validation.v1', 'result': 'PASS', 'entry_count': len(entries), 'zip': pin(zip_path), 'index': pin(OUT / 'INDEX.json'), 'report': pin(OUT / 'REPORT.md'), 'external_save_bodies': 2}
put(OUT / 'ARCHIVE-VALIDATION.actual.json', validation)
print(json.dumps(validation, ensure_ascii=False))
