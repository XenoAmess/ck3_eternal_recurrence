from pathlib import Path
r=Path(__file__).resolve().parent/'candidate-003/mod_li_yu_dao'
for rel,a,b in [('tools/test_institution_candidate.py',305,340),('common/scripted_triggers/lyd_c3_leadership_triggers.txt',1,45),('tools/gen_institution.py',285,316)]:
    print('\n',rel)
    for n,t in enumerate((r/rel).read_text(encoding='utf-8-sig').splitlines(),1):
        if a<=n<=b:print(n,t)
src=Path('C:/Program Files (x86)/Steam/steamapps/common/Crusader Kings III/game/common/activities/activity_types/ecumenical_council.txt')
data=src.read_bytes();import hashlib,json
lines=data.decode('utf-8-sig').splitlines()
target=Path(__file__).resolve().parent/'native-source-freeze/ecumenical_council.txt';target.parent.mkdir(exist_ok=True);assert not target.exists();target.write_bytes(data)
print('EXACT TITLE SOURCE',hashlib.sha256(data).hexdigest(),[(i+1,t)for i,t in enumerate(lines[:58]) if i>=16])
