from pathlib import Path
import json,hashlib,subprocess,sys,shutil,zipfile
R=Path(__file__).resolve().parent;C=R/'candidate-003/mod_li_yu_dao';B=R/'before544/mod_li_yu_dao';P=Path('C:/workspace/ck3_lyd_runtime_20261004/c3-i3b-production-implementation-20261005-001');PREP=Path('C:/workspace/ck3_lyd_runtime_20261004/c3-i3b-head54457-preparation-20261005-001')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):
    p=R/name;assert not p.exists();p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
a=R/'generation-build-attempt-002';shutil.copyfile(R/'package_candidate003.py',a/'package_candidate003.py')
write('generation-build-attempt-002/FAILURE.json',{'result':'PACKAGING_HARNESS_FAILED','reason':'Old C3 contract compared protected C2 generator to b099 instead of current544. Both already completed reproducible builds are preserved and verified separately. Corrected contract baseline must be before544.','product_modified':False,'native':'NOT_RUN'})
new=R/'generation-build-attempt-003';assert not new.exists();new.mkdir()
cmds=[]
for file in ['gen_leadership.py','gen_institution.py','gen_school_consent.py']:
    argv=['C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe','-B','-X','utf8',str(C/'tools'/file),'--check']
    p=subprocess.run(argv,cwd=C,capture_output=True,timeout=90)
    (new/(file+'.stdout')).write_bytes(p.stdout);(new/(file+'.stderr')).write_bytes(p.stderr)
    cmds.append({'argv':argv,'exit_code':p.returncode,'stdout_sha256':sha(new/(file+'.stdout')),'stderr_sha256':sha(new/(file+'.stderr'))})
    assert p.returncode==0
sys.path.insert(0,str(C.parent/'tools'));sys.path.insert(0,str(C/'tools'))
import gen_runtime
outputs=gen_runtime.build_outputs();assert all((C/p).read_bytes()==payload for p,payload in outputs.items())
assert (C/'tools/gen_runtime.py').read_bytes()==(B/'tools/gen_runtime.py').read_bytes()
from build_release import verify_manifest,collect_runtime_files
runtime=collect_runtime_files(C);builds=[]
for v in ['A','B']:
    staging=R/f'production-build-{v}/mod_li_yu_dao';manifest=staging.with_name(staging.name+'.manifest.json');archive=staging.with_name(staging.name+'.zip')
    assert verify_manifest(staging,manifest)==70
    assert all((staging/p).read_bytes()==(C/p).read_bytes() for p in runtime)
    with zipfile.ZipFile(archive)as z:
        assert sorted(z.namelist())==sorted('mod_li_yu_dao/'+p for p in runtime)
        assert all(z.read('mod_li_yu_dao/'+p)==(C/p).read_bytes()for p in runtime)
    builds.append({'staging':str(staging),'manifest':str(manifest),'archive':str(archive),'file_count':70,'manifest_sha256':sha(manifest),'zip_sha256':sha(archive),'verified_staging_and_archive_exact':True})
assert builds[0]['manifest_sha256']==builds[1]['manifest_sha256'];assert builds[0]['zip_sha256']==builds[1]['zip_sha256']
sys.path.insert(0,str(P));import check_c3_contract
check_c3_contract.BASE=B
contracts=check_c3_contract.check({p:(C/p).read_text(encoding='utf-8-sig')for p in (check_c3_contract.TRIG,check_c3_contract.EFFECT,check_c3_contract.DECISION,check_c3_contract.LIFE,check_c3_contract.EVENT)+check_c3_contract.PROTECTED})
prepared=json.loads((R/'PREPARED.json').read_text(encoding='utf-8'));main=Path(prepared['main']);readback=[]
for row in prepared['main_source_files']:
    h=sha(main/row['path']);assert h==row['sha256'];readback.append({**row,'after_readonly_work_sha256':h,'unchanged':True})
preserve=[]
for row in prepared['preserved_C2_four']:
    h=sha(C/row['path']);assert h==row['current_sha256'];preserve.append({**row,'candidate003_sha256':h,'preserved':True})
final=json.loads((R/'TARGETBEFORE-SHA-003.json').read_text(encoding='utf-8'))['files'];narrow=json.loads((R/'DELTA-002-TO-003.json').read_text(encoding='utf-8'))['files']
for row in final:assert sha(C/row['path'])==row['after_sha256'] and sha(R/'delta-files/mod_li_yu_dao'/row['path'])==row['after_sha256']
checks=[]
for folder,names in [('semantic-attempt-003',['institution-focused']),('semantic-attempt-005',['static','test_content_leadership.py']),('semantic-attempt-006',['detached'])]:
    for row in json.loads((R/folder/'COMMANDS.json').read_text(encoding='utf-8')):
        if row['name']in names:assert row['exit_code']==0;checks.append({'attempt':folder,**row})
for p in ['OFFICIAL-MCP21-SCHEMA.json','UNBOUND-REQUEST-TEMPLATES.json','checkpoint_scope_readback.py','R8-HISTORICAL-SCOPED-PROJECTION.json','CURRENT70-PLANNED70-READBACK.json']:
    shutil.copyfile(PREP/p,R/('reuse-'+p))
shutil.copyfile(P/'FROZEN-FIXTURE-REUSE.json',R/'FROZEN-FIXTURE-REUSE.json')
write('SOURCE-L0-CHECKS-003.json',{'schema':'lyd.c3-i3b.candidate003.sourcechecks.v1','result':'SOURCE_L0_PASS','checks':checks,'generation_checks':cmds,'full_generator_outputs':len(outputs),'full_generator_byte_equality':True,'shared_gen_runtime_unchanged':True,'C3_source_contracts':contracts,'C3_contract_baseline':'actual frozen before544','runtime_files':list(runtime),'runtime_file_count':70,'events':70,'policy_cases':44,'actual_trigger_mutants_rejected':18,'old_I3b_checks':24,'C3_checks':11,'production_builds':builds,'main_readback':readback,'preserve_C2_four':preserve,'workflow_check':'NOT_RUN','native_positive':'NOT_RUN','UI':'NOT_RUN','native_scope':'NOT_RUN','native_head_creation':'NOT_RUN','actual_AI_consent':'NOT_RUN','cold_reload':'NOT_RUN','death':'NOT_RUN','git_game_pipe_bus_desktop':'NOT_RUN'})
print(json.dumps({'status':'SOURCE_L0_PASS','target_count':len(final),'narrow003_files':len(narrow),'authored':sum(r['kind']=='authored'for r in final),'generated':sum(r['kind']=='generated'for r in final),'C2_preserved':len(preserve),'main_files_unchanged':len(readback),'runtime70':len(runtime),'manifest_sha256':builds[0]['manifest_sha256'],'zip_sha256':builds[0]['zip_sha256'],'native':'NOT_RUN'},indent=2))
