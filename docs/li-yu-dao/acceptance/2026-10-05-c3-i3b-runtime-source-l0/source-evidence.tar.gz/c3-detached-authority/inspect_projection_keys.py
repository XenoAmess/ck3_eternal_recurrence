from pathlib import Path
import json
r=Path(__file__).resolve().parent
d=json.loads((r/'reuse-R8-HISTORICAL-SCOPED-PROJECTION.json').read_text(encoding='utf-8'))
def inspect(x,p='',level=0):
    if isinstance(x,dict):
        print(p,'keys',list(x)[:32])
        if level<2:
            for k,v in x.items():
                if isinstance(v,(list,dict)):inspect(v,p+'/'+k,level+1)
    elif isinstance(x,list):
        print(p,'list',len(x))
        for i,v in enumerate(x[:2]):
            if level<2:inspect(v,p+'/'+str(i),level+1)
inspect(d)
