from pathlib import Path
r=Path(__file__).resolve().parent/'candidate-003/mod_li_yu_dao'
for rel,a,b in [('tools/test_content_leadership.py',1,135),('tools/test_institution_candidate.py',110,255),('tools/gen_institution.py',625,690)]:
    print('\nFILE',rel)
    for n,t in enumerate((r/rel).read_text(encoding='utf-8-sig').splitlines(),1):
        if a<=n<=b:print(n,t)
print('\nSUPPORT',[(p.name,p.stat().st_size)for p in (r.parent/'tools').iterdir() if p.is_file()])
