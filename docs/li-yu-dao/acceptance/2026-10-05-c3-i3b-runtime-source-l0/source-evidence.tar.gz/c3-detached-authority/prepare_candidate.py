from pathlib import Path
import hashlib,json,shutil,subprocess,re
ROOT=Path(__file__).resolve().parent
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
PREP=BASE/'c3-i3b-head54457-preparation-20261005-001'
PREV=BASE/'c3-i3b-production-implementation-20261005-001'
MAIN=Path('C:/workspace/ck3_eternal_recurrence/mod_li_yu_dao')
CAND=ROOT/'candidate-003/mod_li_yu_dao'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
inventory=json.loads((PREP/'CURRENT-MOD144-READBACK.json').read_text(encoding='utf-8'))
for row in inventory['files']:assert sha(MAIN/row['path'])==row['sha256'],row['path']
assert not CAND.exists();shutil.copytree(MAIN,CAND,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
assert not (ROOT/'before544/mod_li_yu_dao').exists();shutil.copytree(MAIN,ROOT/'before544/mod_li_yu_dao',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
delta=json.loads((PREP/'DELTA-APPLICABILITY.json').read_text(encoding='utf-8'))
for row in delta['target_files']:
 assert sha(CAND/row['path'])==row['before_sha256']
 src=PREP/'delta-files/mod_li_yu_dao'/row['path'];assert sha(src)==row['after_sha256'];shutil.copyfile(src,CAND/row['path'])
for row in delta['preserve_current_C2_files']:assert sha(CAND/row['path'])==row['current_sha256']
shutil.copytree(CAND,ROOT/'merged002/mod_li_yu_dao',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
support=[]
for group in ('docs','tools'):
 p=PREV/'candidate-002'/group
 if p.exists():
  shutil.copytree(p,ROOT/'candidate-003'/group,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
  support.extend({'path':str(f),'sha256':sha(f)} for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts)
report={'schema':'lyd.c3-i3b.candidate003.exact-preparation.v1','declared_source_head':'54457b371e947edb86903c2ebd578034f02695db','main':str(MAIN),'candidate':str(CAND),'main_source_files':inventory['files'],'candidate002_delta_applied':delta['target_files'],'preserved_C2_four':delta['preserve_current_C2_files'],'support_copied_from_sealed_candidate002':support,'native_game_Git_desktop_pipe_bus':'NOT_RUN'}
with (ROOT/'PREPARED.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
source=Path('C:/Program Files (x86)/Steam/steamapps/common/Crusader Kings III/game/common')
argv=['rg','-n','--glob','*.txt','is_religious_head_title|is_religious_head_challenger',str(source)]
r=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8',errors='replace')
with (ROOT/'NATIVE-OFFICE-PREDICATE-SOURCE-SEARCH.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'argv':argv,'returncode':r.returncode,'hits':r.stdout.splitlines(),'native':'NOT_RUN'},f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'candidate_prepared':str(CAND),'main_files_exact':len(inventory['files']),'candidate002_targets_merged':21,'C2_fix_preserved':4,'support_file_count':len(support),'native_office_predicate_hits':r.stdout.splitlines()[:12]},ensure_ascii=False))
for p in sorted(PREV.glob('*.py')):
 if any(v in p.name for v in ('combined','focused','contract','package')):print('OLD_HARNESS '+str(p))
