from pathlib import Path
import shutil,json,hashlib
r=Path(__file__).resolve().parent;p=r/'package_candidate003.py';a=r/'generation-build-attempt-001'
shutil.copyfile(p,a/'package_candidate003.py')
(a/'FAILURE.json').write_text(json.dumps({'result':'FAILED','stage':'full generator composition assertion','reason':'Legacy check_c3_contract import prepended old candidate module directories before generator imports. Corrected harness import order; product bytes were not changed.','script_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'main_changed':False,'native':'NOT_RUN'},indent=2)+'\n',encoding='utf-8')
