from pathlib import Path
ROOT=Path(__file__).resolve().parent
CAND=ROOT/'candidate-003/mod_li_yu_dao'
for p,ranges in [(CAND/'tools/gen_institution.py',[(335,462),(555,600)]),(CAND/'tools/test_institution_candidate.py',[(1,110)]),(CAND/'tools/institution_oracle.py',[(1,175)]),(CAND/'tools/build_release.py',[(1,120)]),(Path('C:/workspace/ck3_lyd_runtime_20261004/c3-i3b-production-implementation-20261005-001/package_candidate.py'),[(1,165)])]:
 lines=p.read_text(encoding='utf-8-sig').splitlines();print(str(p))
 for a,b in ranges:
  print('\n'.join(f'{i+1}: {lines[i]}' for i in range(a-1,min(b,len(lines)))))
