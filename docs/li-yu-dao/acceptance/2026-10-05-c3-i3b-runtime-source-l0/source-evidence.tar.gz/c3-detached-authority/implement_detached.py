from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
p=root/'candidate-003/mod_li_yu_dao/tools/gen_institution.py'
raw=p.read_bytes(); text=raw.decode('utf-8-sig').replace('\r\n','\n')
def replace(old,new,count=1):
    global text
    actual=text.count(old)
    assert actual==count,(old[:100],actual,count)
    text=text.replace(old,new)
replace('lyd_i3b_actor_trigger = {\n    lyd_c3_player_actor_trigger = yes\n    faith = faith:lyd_common_faith', '''# Faith ROOT. All its actual rites must belong to the fixed 36-rite catalogue;
# a detached Faith need not contain every catalogue rite.
lyd_i3b_only_owned_rites_faith_trigger = {
    religion = religion:confucianism_religion
    exists = main_rite
    main_rite = { lyd_i3b_owned_rite_trigger = yes }
    NOT = { any_faith_rite = { NOT = { lyd_i3b_owned_rite_trigger = yes } } }
}
# Character ROOT. No title office or existing challenger can supply a mandate.
# is_head_of_faith is a native Title trigger, used only inside any_held_title.
lyd_i3b_no_other_office_trigger = {
    NOT = { any_held_title = { is_head_of_faith = yes } }
    pam_is_antipope_trigger = no
    pam_is_antipope_sponsor_trigger = no
    NOT = { has_variable = lyd_c3_claim_title }
}
# Faith ROOT. Include native challengers with no LYD metadata.
lyd_i3b_headless_faith_trigger = {
    lyd_i3b_only_owned_rites_faith_trigger = yes
    has_doctrine = doctrine_no_head
    NOT = { exists = religious_head_title }
    NOT = { exists = religious_head }
    NOT = { any_religious_head_challenger = { always = yes } }
}
# Character ROOT. Detached admission comes from the actual current main HoR,
# never an owned variable, political sponsor, or a rite of the same script type.
lyd_i3b_detached_authority_trigger = {
    NOT = { faith = faith:lyd_common_faith }
    faith = { lyd_i3b_only_owned_rites_faith_trigger = yes }
    rite = faith.main_rite
    exists = rite.head_of_rite
    this = rite.head_of_rite
}
lyd_i3b_actor_trigger = {
    lyd_c3_player_actor_trigger = yes
    lyd_i3b_no_other_office_trigger = yes
    OR = {
        faith = faith:lyd_common_faith
        lyd_i3b_detached_authority_trigger = yes
    }''')
replace('# Withdrawal is available to the living human initiator after identity drift.', '''# Revalidate the captured authority mode at every nomination/ballot callback.
# The existing common-Faith scholar route remains separate from detached HoR.
lyd_i3b_captured_authority_trigger = {
    OR = {
        AND = { var:lyd_i3b_authority_mode = 0 faith = faith:lyd_common_faith }
        AND = {
            var:lyd_i3b_authority_mode = 1
            lyd_i3b_detached_authority_trigger = yes
            exists = var:lyd_i3b_required_native_hor
            this = var:lyd_i3b_required_native_hor
            var:lyd_i3b_main.head_of_rite = var:lyd_i3b_required_native_hor
        }
    }
}
# Receipt variables survive cleanup; only detached enactment requires the actual
# same native HoR afterward. This does not call an invented HoR setter.
lyd_i3b_native_authority_postcondition_trigger = {
    OR = {
        var:lyd_i3b_result_authority_mode = 0
        AND = {
            var:lyd_i3b_result_authority_mode = 1
            exists = var:lyd_i3b_result_native_hor
            this = var:lyd_i3b_result_native_hor
            var:lyd_i3b_main.head_of_rite = var:lyd_i3b_result_native_hor
        }
    }
}
# Withdrawal is available to the living human initiator after identity drift.''')
replace('        NOT = { exists = religious_head_title }\n        NOT = { exists = religious_head }','        lyd_i3b_headless_faith_trigger = yes',2)
replace('lyd_i3b_current_trigger = {\n    lyd_i3b_actor_trigger = yes', 'lyd_i3b_current_trigger = {\n    lyd_i3b_actor_trigger = yes\n    lyd_i3b_captured_authority_trigger = yes')
replace('set_variable = { name = lyd_i3b_main value = faith.main_rite }','''set_variable = { name = lyd_i3b_main value = faith.main_rite }
        remove_variable = lyd_i3b_required_native_hor
        if = { limit = { faith = faith:lyd_common_faith }
            set_variable = { name = lyd_i3b_authority_mode value = 0 }
        }
        else = {
            set_variable = { name = lyd_i3b_authority_mode value = 1 }
            set_variable = { name = lyd_i3b_required_native_hor value = rite.head_of_rite }
        }''')
replace('    remove_variable = lyd_i3b_active remove_variable = lyd_i3b_phase', '    remove_variable = lyd_i3b_active remove_variable = lyd_i3b_phase\n    remove_variable = lyd_i3b_authority_mode remove_variable = lyd_i3b_required_native_hor')
replace('        remove_variable = lyd_i3b_result_head_title','''        remove_variable = lyd_i3b_result_head_title
        set_variable = { name = lyd_i3b_result_authority_mode value = var:lyd_i3b_authority_mode }
        remove_variable = lyd_i3b_result_native_hor
        if = { limit = { var:lyd_i3b_authority_mode = 1 }
            set_variable = { name = lyd_i3b_result_native_hor value = var:lyd_i3b_required_native_hor }
        }''')
replace('            faith.religious_head = this faith = { lyd_c3_owned_current_head_trigger = yes }\n            NOT', '            faith.religious_head = this faith = { lyd_c3_owned_current_head_trigger = yes }\n            lyd_i3b_native_authority_postcondition_trigger = yes\n            NOT')
replace('            else = { set_variable = { name = lyd_i3b_result_code value = 6 } }','''            else_if = { limit = { NOT = { lyd_i3b_native_authority_postcondition_trigger = yes } }
                set_variable = { name = lyd_i3b_result_code value = 7 }
            }
            else = { set_variable = { name = lyd_i3b_result_code value = 6 } }''')
replace('        if = {{ limit = {{ var:lyd_i3b_result_code = 6 }} custom_tooltip = lyd_i3b_result_unclassified_tt }}','''        if = {{ limit = {{ var:lyd_i3b_result_code = 6 }} custom_tooltip = lyd_i3b_result_unclassified_tt }}
        if = {{ limit = {{ var:lyd_i3b_result_code = 7 }} custom_tooltip = lyd_i3b_result_native_hor_failed_tt }}''')
replace("'lyd_i3b_terms_desc':('","'lyd_i3b_terms_desc':('共同体原始共宗可由合格主礼仪学者发起；独立共同体须由仍在任的实际原生主礼仪领袖本人发起，且全部礼仪属于本模组。现有宗主头衔或争议宗主会阻止本轮。")
replace('These terms replace no-head with temporal-head', 'For the original Communion an eligible main-rite scholar may initiate; a detached Communion requires its actual current native main-rite head to initiate, and every rite must belong to this mod. Existing head titles or challengers block the round. These terms replace no-head with temporal-head')
replace("'lyd_i3b_begin_valid_tt':('须为合格的主礼仪玩家发起者；共同体与全部礼仪均无宗主且教士制度兼容，没有其他议案占用。','Requires an eligible main-rite player initiator, compatible headless Communion and rites, and no competing proposal locks.')", "'lyd_i3b_begin_valid_tt':('须为合格主礼仪玩家；独立共同体还须本人为实际在任主礼仪领袖。全部礼仪须属本模组、无宗主且教士制度兼容；本人不得持其他宗主或争议头衔，共同体不得已有争议宗主，且无其他议案占用。','Requires an eligible main-rite player; a detached Communion also requires its actual current native main-rite head. All rites must belong to this mod and remain headless with compatible clergy; no other held headship or challenger title, native Communion challenger, or competing proposal is allowed.')")
anchor="        'lyd_i3b_result_unclassified_tt':"
assert text.count(anchor)==1
text=text.replace(anchor,"        'lyd_i3b_result_native_hor_failed_tt':('实施后独立共同体的实际主礼仪领袖与本轮授权人不一致；保留真实原生状态，不补写领袖或宣告成功。','The detached Communion’s actual native main-rite head no longer matches this round’s authorized initiator after enactment. The real native state is retained without assigning a replacement or claiming success.'),\n"+anchor)
out=text.encode('utf-8')
p.write_bytes(out)
(root/'AUTHOR-EDIT-003.json').write_text(json.dumps({'path':str(p),'before_sha256':hashlib.sha256(raw).hexdigest(),'after_sha256':hashlib.sha256(out).hexdigest(),'scope':'external candidate only','native':'NOT_RUN'},indent=2)+'\n',encoding='utf-8')
print('External gen_institution author updated; native NOT_RUN')
