from pathlib import Path
import json,hashlib,difflib,subprocess,sys,shutil
ROOT=Path(__file__).resolve().parent
CAND=ROOT/'candidate-003/mod_li_yu_dao';BEFORE=ROOT/'before544/mod_li_yu_dao';MERGED=ROOT/'merged002/mod_li_yu_dao'
PREP=Path('C:/workspace/ck3_lyd_runtime_20261004/c3-i3b-head54457-preparation-20261005-001')
PREV=Path('C:/workspace/ck3_lyd_runtime_20261004/c3-i3b-production-implementation-20261005-001')
MAIN=Path('C:/workspace/ck3_eternal_recurrence/mod_li_yu_dao')
PY='C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
HEAD='54457b371e947edb86903c2ebd578034f02695db'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,value):
    p=ROOT/name;assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def delta(baseline):
    rows=[]
    for p in sorted(CAND.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts:continue
        rel=p.relative_to(CAND).as_posix();bp=baseline/rel;old=bp.read_bytes() if bp.exists() else None;new=p.read_bytes()
        if old==new:continue
        rows.append({'path':rel,'kind':'authored' if rel.startswith('tools/') else 'generated','before_sha256':sha(old) if old is not None else None,'before_state':'PRESENT' if old is not None else 'ABSENT','after_sha256':sha(new),'before_bytes':len(old) if old is not None else 0,'after_bytes':len(new)})
    return rows
def patch(rows,baseline,name):
    parts=[]
    for row in rows:
        rel=row['path'];p=baseline/rel
        old=p.read_text(encoding='utf-8-sig').splitlines(keepends=True) if p.exists() else []
        new=(CAND/rel).read_text(encoding='utf-8-sig').splitlines(keepends=True)
        parts.extend(difflib.unified_diff(old,new,fromfile='before/mod_li_yu_dao/'+rel if p.exists() else '/dev/null',tofile='candidate/mod_li_yu_dao/'+rel))
    p=ROOT/name;assert not p.exists();p.write_text(''.join(parts),encoding='utf-8',newline='\n')

attempt=ROOT/'generation-build-attempt-001';assert not attempt.exists();attempt.mkdir()
commands=[]
for name in ['gen_leadership.py','gen_institution.py','gen_school_consent.py']:
    argv=[PY,'-B','-X','utf8',str(CAND/'tools'/name),'--check']
    r=subprocess.run(argv,cwd=CAND,capture_output=True,timeout=90)
    (attempt/(name+'.stdout')).write_bytes(r.stdout);(attempt/(name+'.stderr')).write_bytes(r.stderr)
    commands.append({'name':name,'argv':argv,'exit_code':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)})
    assert r.returncode==0,(name,(r.stdout+r.stderr).decode('utf-8',errors='replace')[-1500:])
sys.path.insert(0,str(CAND/'tools'));sys.path.insert(0,str(CAND.parent/'tools'));sys.path.insert(0,str(PREV))
import gen_runtime,check_c3_contract
outputs=gen_runtime.build_outputs();assert all((CAND/p).read_bytes()==b for p,b in outputs.items())
assert (CAND/'tools/gen_runtime.py').read_bytes()==(BEFORE/'tools/gen_runtime.py').read_bytes()
from build_release import build_release,collect_runtime_files
builds=[build_release(CAND,ROOT/f'production-build-{v}/mod_li_yu_dao',revision=HEAD+'+external-candidate-003')for v in ('A','B')]
assert builds[0]['manifest_sha256']==builds[1]['manifest_sha256']
assert builds[0]['zip_sha256']==builds[1]['zip_sha256']
runtime=collect_runtime_files(CAND);assert len(runtime)==70
prepared=json.loads((ROOT/'PREPARED.json').read_text(encoding='utf-8'))
main_readback=[]
for row in prepared['main_source_files']:
    actual=sha((MAIN/row['path']).read_bytes())
    main_readback.append({'path':row['path'],'expected_sha256':row['sha256'],'actual_sha256':actual,'unchanged':actual==row['sha256']})
assert all(r['unchanged'] for r in main_readback)
preserve=[]
for row in prepared['preserved_C2_four']:
    actual=sha((CAND/row['path']).read_bytes());assert actual==row['current_sha256'],row['path'];preserve.append({**row,'candidate003_sha256':actual,'preserved':True})
final=delta(BEFORE);narrow=delta(MERGED)
assert not {r['path'] for r in final}&{r['path']for r in preserve}
write('TARGETBEFORE-SHA-003.json',{'schema':'lyd.c3-i3b.candidate003.target-before-sha.v1','declared_baseline':HEAD,'main_is_read_only':True,'native':'NOT_RUN','files':final,'preserve_C2_four':preserve})
write('DELTA-002-TO-003.json',{'schema':'lyd.i3b.detached.delta.v1','baseline':'HEAD544 plus exact21 sealed candidate002 targets','files':narrow,'native':'NOT_RUN'})
patch(final,BEFORE,'candidate-003.patch');patch([r for r in final if r['kind']=='authored'],BEFORE,'authored-003.patch');patch([r for r in final if r['kind']=='generated'],BEFORE,'generated-003.patch');patch(narrow,MERGED,'narrow-002-to-003.patch')
dest=ROOT/'delta-files/mod_li_yu_dao';assert not dest.exists()
for row in final:
    p=dest/row['path'];p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(CAND/row['path'],p)
contracts=check_c3_contract.check({p:(CAND/p).read_text(encoding='utf-8-sig') for p in (check_c3_contract.TRIG,check_c3_contract.EFFECT,check_c3_contract.DECISION,check_c3_contract.LIFE,check_c3_contract.EVENT)+check_c3_contract.PROTECTED})
checks=[]
for folder,names in [('semantic-attempt-003',['institution-focused']),('semantic-attempt-005',['static','test_content_leadership.py']),('semantic-attempt-006',['detached'])]:
    rs=json.loads((ROOT/folder/'COMMANDS.json').read_text(encoding='utf-8'))
    for row in rs:
        if row['name']in names:assert row['exit_code']==0;checks.append({'attempt':folder,**row})
for p in ['OFFICIAL-MCP21-SCHEMA.json','UNBOUND-REQUEST-TEMPLATES.json','checkpoint_scope_readback.py','R8-HISTORICAL-SCOPED-PROJECTION.json','CURRENT70-PLANNED70-READBACK.json']:
    shutil.copyfile(PREP/p,ROOT/('reuse-'+p))
shutil.copyfile(PREV/'FROZEN-FIXTURE-REUSE.json',ROOT/'FROZEN-FIXTURE-REUSE.json')
write('SOURCE-L0-CHECKS-003.json',{'schema':'lyd.c3-i3b.candidate003.sourcechecks.v1','result':'SOURCE_L0_PASS','checks':checks,'generation_checks':commands,'full_generator_outputs':len(outputs),'full_generator_byte_equality':True,'shared_gen_runtime_unchanged':True,'C3_source_contracts':contracts,'runtime_files':list(runtime),'runtime_file_count':len(runtime),'events':70,'policy_cases':44,'actual_trigger_mutants_rejected':18,'old_I3b_checks':24,'C3_checks':11,'production_builds':builds,'main_readback':main_readback,'preserve_C2_four':preserve,'workflow_check':'NOT_RUN','native_positive':'NOT_RUN','UI':'NOT_RUN','native_scope':'NOT_RUN','native_head_creation':'NOT_RUN','actual_AI_consent':'NOT_RUN','cold_reload':'NOT_RUN','death':'NOT_RUN','git_game_pipe_bus_desktop':'NOT_RUN'})
print(json.dumps({'status':'SOURCE_L0_PASS','target_count':len(final),'narrow003_files':len(narrow),'authored':sum(r['kind']=='authored'for r in final),'generated':sum(r['kind']=='generated'for r in final),'C2_preserved':len(preserve),'main_files_unchanged':len(main_readback),'runtime70':len(runtime),'manifest_sha256':builds[0]['manifest_sha256'],'zip_sha256':builds[0]['zip_sha256'],'native':'NOT_RUN'},ensure_ascii=False,indent=2))
