from pathlib import Path
import json,subprocess
R=Path(__file__).resolve().parent;f=json.loads((R/'FROZEN-FIXTURE-REUSE.json').read_text(encoding='utf-8'))
print('PLAN ROOT',f['plan_root'],'FIRST',f['files'][0])
r=subprocess.run(['rg','--files','--glob','*lyd_cp_decisions*',f['plan_root']],capture_output=True,text=True,encoding='utf-8');print(r.stdout)
p=Path('C:/workspace/ck3_lyd_runtime_20261004/c3-i3b-head54457-preparation-20261005-001/VERIFY-002.json');d=json.loads(p.read_text(encoding='utf-8'));print('PREVIOUS VERIFY KEYS',list(d))
for k,v in d.items():
    if isinstance(v,list)and v:print(k,len(v),str(v[0])[:750])
raw=(R/'verify_final_package.py').read_bytes();(R/'VERIFY-ATTEMPT-001-FAILURE.json').write_text(json.dumps({'result':'FAILED_BEFORE_FINAL_VERIFY_WRITE','stage':'fixture resolution','reason':'Original fixture manifest paths are relative beneath the plan frozen-fixtures snapshot, not directly beneath plan_root. Main144/target26 checks completed before this path failure; no files changed.','script_sha256':__import__('hashlib').sha256(raw).hexdigest()},indent=2)+'\n',encoding='utf-8')
(R/'verify_final_package-attempt-001.py').write_bytes(raw)
