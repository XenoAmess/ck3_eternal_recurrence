from pathlib import Path
import json
p=Path(__file__).resolve().parent/'reuse-OFFICIAL-MCP21-SCHEMA.json';d=json.loads(p.read_text(encoding='utf-8'))
for t in d['tools']:
    print(t.get('name'),list(t))
