from pathlib import Path
import sys
r=Path(__file__).resolve().parent/'candidate-003/mod_li_yu_dao'
sys.path.insert(0,str(r/'tools'))
from test_institution_detached import *
c=Corpus();w=world();a,n,f,rite,g,e=w;ev=PolicyAST(c.triggers,a,g,e)
for k in ['lyd_c3_player_actor_trigger','lyd_member_rite_trigger','lyd_i3b_no_other_office_trigger','lyd_i3b_detached_authority_trigger','lyd_i3b_actor_trigger','lyd_i3b_current_trigger']:
    print(k,ev.run(k))
    for entry in c.triggers[k].entries:
        try:print(' ',entry.key,ev.entry(entry,a))
        except Exception as ex:print(type(ex).__name__,str(ex))
cur=c.triggers['lyd_i3b_current_trigger']
for entry in cur.entries:
    if entry.key=='NOT' and any(x.key=='any_in_list' for x in entry.value.entries):
        it=one(entry.value,'any_in_list');print('LIST',scalar(it,'variable'))
        for s in a.lists[scalar(it,'variable')]:
            print('SCOPE',s.name)
            for x in it.entries:
                if x.key=='save_temporary_scope_as':ev.entry(x,s)
                if x.key=='NOT':
                    for y in x.value.entries:
                        print(' ',y.key,ev.entry(y,s) if y.key not in {'trigger_if','trigger_else'} else 'branch')
