from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SHA = 'c40e28a157447f8ab67889a2355e7cbd0fe3a43f'


def sha256(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()


def raw(path: Path, body: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(body)


def dump(path: Path, value: object) -> None:
    raw(path, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


def extract_json(log: str) -> list[dict]:
    lines = [re.sub(r'^\d{4}-\d{2}-\d{2}T[\d:.]+Z ', '', line) for line in log.splitlines()]
    reports = []
    i = 0
    while i < len(lines):
        if lines[i] != '{':
            i += 1
            continue
        for j in range(i, min(i + 251, len(lines))):
            try:
                report = json.loads('\n'.join(lines[i:j + 1]))
            except json.JSONDecodeError:
                continue
            assert isinstance(report, dict)
            reports.append(report)
            i = j
            break
        i += 1
    return reports


def main() -> None:
    observations = {}
    for path in sorted(ROOT.glob('incoming-observations-*.json')):
        incoming = json.loads(path.read_text(encoding='utf-8'))
        assert incoming['commit'] == SHA
        for item in incoming['observations']:
            key = item['key']
            assert key not in observations or observations[key] == item
            observations[key] = item

    def decoded(key: str) -> object:
        return json.loads(observations[key]['result']['structuredContent']['content'])

    runs_key = sorted(k for k in observations if re.fullmatch(r'c40-runs-\d+', k))[-1]
    runs = decoded(runs_key)
    assert runs['total_count'] == 2 and len(runs['workflow_runs']) == 2
    expected_paths = {'.github/workflows/static-ci.yml', '.github/workflows/li-yu-dao-static.yml'}
    assert {run['path'] for run in runs['workflow_runs']} == expected_paths
    assert all(run['head_sha'] == SHA and run['event'] == 'push' and run['status'] == 'completed'
               for run in runs['workflow_runs'])

    observation_index = []
    for key, item in observations.items():
        response_rel = f'responses/{key}.json'
        dump(ROOT / response_rel, item)
        body = item['result'].get('structuredContent', {}).get('content')
        entry = {'key': key, 'observed_at': item['observed_at'], 'request': item['request'],
                 'response_path': response_rel, 'is_error': item['result'].get('isError', False)}
        if isinstance(body, str):
            extension = '.yml' if '-definition-' in key else '.py' if '-source-' in key else '.log' if '-logs-' in key else '.json'
            encoded = body.encode('utf-8')
            body_rel = f'bodies/{key}{extension}'
            raw(ROOT / body_rel, encoded)
            entry.update(body_path=body_rel, body_bytes=len(encoded), body_sha256=sha256(encoded))
        observation_index.append(entry)
    dump(ROOT / 'observations.json', observation_index)

    file_proofs = []
    for item in decoded('c40-workflow-directory'):
        body = observations['c40-definition-' + item['name']]['result']['structuredContent']['content'].encode('utf-8')
        assert len(body) == item['size']
        git_sha = hashlib.sha1(b'blob ' + str(len(body)).encode('ascii') + b'\0' + body).hexdigest()
        assert git_sha == item['sha']
        file_proofs.append({'path': item['path'], 'bytes': len(body), 'sha256': sha256(body),
                            'git_blob_sha1': git_sha, 'verified_against_github_blob': True})
    commit = decoded('c40-commit')
    assert commit['sha'] == SHA
    source_proofs = []
    for key in sorted(k for k in observations if k.startswith('c40-source-') and k != 'c40-source-validate_python_only.py'):
        filename = 'mod_li_yu_dao/tools/' + key.removeprefix('c40-source-')
        entry = next(item for item in commit['files'] if item['filename'] == filename)
        body = observations[key]['result']['structuredContent']['content'].encode('utf-8')
        git_sha = hashlib.sha1(b'blob ' + str(len(body)).encode('ascii') + b'\0' + body).hexdigest()
        assert git_sha == entry['sha']
        source_proofs.append({'path': filename, 'bytes': len(body), 'sha256': sha256(body),
                              'git_blob_sha1': git_sha, 'verified_against_commit_blob': True})

    diagnostic_sources = []
    diagnostic_prefix = 'docs/li-yu-dao/acceptance/2026-10-05-I3b-content-integration-l0/'
    for key in sorted(k for k in observations if k.startswith('c40-offending-')):
        filename = diagnostic_prefix + key.removeprefix('c40-offending-')
        entry = next(item for item in commit['files'] if item['filename'] == filename)
        text = observations[key]['result']['structuredContent']['content']
        body = text.encode('utf-8')
        git_sha = hashlib.sha1(b'blob ' + str(len(body)).encode('ascii') + b'\0' + body).hexdigest()
        assert git_sha == entry['sha']
        matched = [{'line': i + 1, 'text': line} for i, line in enumerate(text.splitlines())
                   if 'powershell' in line.lower()]
        assert len(matched) == 1
        diagnostic_sources.append({'path': filename, 'bytes': len(body), 'sha256': sha256(body),
                                   'git_blob_sha1': git_sha, 'verified_against_commit_blob': True,
                                   'forbidden_reference_line': matched[0]})

    outcomes = []
    lyd_reports = []
    for run in runs['workflow_runs']:
        jobs_key = sorted(k for k in observations if k.startswith(f"c40-jobs-{run['id']}-"))[-1]
        jobs = decoded(jobs_key)
        assert jobs['total_count'] == len(jobs['jobs']) == 1
        job = jobs['jobs'][0]
        assert job['status'] == 'completed'
        assert job['conclusion'] == run['conclusion']
        log_keys = sorted(k for k in observations if k.startswith(f"c40-logs-{job['id']}")
                          and not observations[k]['result'].get('isError', False))
        assert log_keys
        log_key = log_keys[-1]
        log = observations[log_key]['result']['structuredContent']['content']
        assert SHA in log
        steps = job['steps']
        assert all(step['status'] == 'completed' for step in steps)
        counts = dict(Counter(step['conclusion'] for step in steps))
        artifact_key = sorted(k for k in observations if k.startswith(f"c40-artifacts-{run['id']}-"))[-1]
        artifacts = decoded(artifact_key)
        assert artifacts['total_count'] == len(artifacts['artifacts'])
        for artifact in artifacts['artifacts']:
            assert artifact['workflow_run']['head_sha'] == SHA
        outcome = {'run_id': run['id'], 'run_url': run['html_url'], 'workflow': run['path'],
                   'name': run['name'], 'event': run['event'], 'head_sha': run['head_sha'],
                   'status': run['status'], 'conclusion': run['conclusion'], 'run_attempt': run['run_attempt'],
                   'created_at': run['created_at'], 'updated_at': run['updated_at'],
                   'job_id': job['id'], 'job_conclusion': job['conclusion'], 'step_conclusions': counts,
                   'step_details': steps, 'log_observation_key': log_key,
                   'log_utf8_sha256': sha256(log.encode('utf-8')), 'artifact_metadata': artifacts,
                   'artifact_payload_downloaded': False}
        if run['path'] == '.github/workflows/li-yu-dao-static.yml':
            assert counts == {'success': 9}
            definition = observations['c40-definition-li-yu-dao-static.yml']['result']['structuredContent']['content']
            assert 'python mod_li_yu_dao/tools/test_institution_candidate.py' in definition
            counts_from_log = [int(value) for value in re.findall(r'Ran (\d+) tests in ', log)]
            assert counts_from_log == [11, 6, 102, 11, 25]
            assert len(re.findall(r'(?m)^\d{4}[^\n]*Z OK$', log)) == 5
            reports = extract_json(log)
            static = next(value for value in reports if value.get('layer') == 'L0-static')
            packaging = next(value for value in reports if value.get('layer') == 'L0-packaging')
            assert static['result'] == packaging['result'] == 'GREEN'
            assert static['errors'] == []
            assert static['runtime_file_count'] == packaging['file_count'] == 70
            assert static['localization_key_count'] == 889 and static['event_count'] == 68
            assert len(static['runtime_sha256']) == 70
            dump(ROOT / 'derived/lyd-static-report-from-job-log.json', static)
            dump(ROOT / 'derived/lyd-packaging-report-from-job-log.json', packaging)
            outcome['unittest_counts_from_actual_log'] = counts_from_log
            outcome['unittest_total_from_actual_log'] = sum(counts_from_log)
            outcome['static_counts_from_actual_log'] = {'runtime_files': 70, 'localization_keys': 889, 'events': 68}
            outcome['packaging_manifest_sha256_from_actual_log'] = packaging['manifest_sha256']
            outcome['packaging_zip_sha256_from_actual_log'] = packaging['zip_sha256']
            lyd_reports = reports
        elif run['path'] == '.github/workflows/static-ci.yml':
            assert counts == {'success': 41, 'skipped': 38, 'failure': 1}
            failed = [step for step in steps if step['conclusion'] == 'failure']
            assert len(failed) == 1 and failed[0]['name'] == 'Enforce Python-only Windows automation'
            assert 'PYTHON-ONLY RED: 3 violation(s)' in log
            assert '##[error]Process completed with exit code 1.' in log
            for diagnostic in diagnostic_sources:
                assert diagnostic['path'] + ": forbidden shell reference 'powershell'" in log
            outcome['actual_failure_diagnosis'] = {
                'failed_step': failed[0], 'exit_code_from_actual_log': 1,
                'reported_violation_count': 3, 'diagnostic_source_files': diagnostic_sources,
                'scope': 'Report prose contains the prohibited shell name; exact log reports references, not execution of that shell.',
                'later_static_and_packaging_checks': 'SKIPPED_AFTER_FAILURE',
                'expected_negative_test_RED_lines_are_failure_cause': False}
        outcomes.append(outcome)

    report = {'schema': 'lyd-ci-evidence/v1', 'repository': 'XenoAmess/ck3_eternal_recurrence', 'commit': SHA,
              'generated_at_utc': datetime.now(timezone.utc).isoformat(), 'read_only': True,
              'workflow_dispatch_rerun_or_publication': False,
              'query_used_pr_filtered_wrapper': False, 'final_runs_observation': runs_key,
              'workflow_outcomes': outcomes, 'workflow_definitions': file_proofs,
              'selected_source_file_bindings': source_proofs,
              'overall': 'PASS_EXACT_COMMIT_L0_CI' if all(x['conclusion'] == 'success' for x in outcomes) else 'RED_EXACT_COMMIT_CI',
              'known_capability_limits': [
                  'These are exact c40e28a15 commit CI observations. Prior 3d3305e or bfe051465 CI is not substituted.',
                  'L0 CI does not prove CK3 runtime, native consent, repeated union/split, leaders, native charter, save/reload, or workshop acceptance.',
                  'GitHub exposes merged job logs without separable stdout/stderr streams. Complete exposed merged logs are preserved; stream attribution is not fabricated.',
                  'The connector exposes UTF-8 body strings, not HTTP wire bytes or response headers. Exact exposed body UTF-8 bytes and complete serialized tool responses are preserved.',
                  'Artifact metadata and server digest are preserved. Artifact ZIP payload was not downloaded or locally hash-verified; derived reports are extracted from the actual job log, not falsely called downloaded artifacts.',
                  'The failed first LYD job-log request included an extra argument and was rejected during argument binding. That failure is preserved; the corrected request succeeded.',
                  'General CI has 38 skipped steps: optional release/manual steps plus downstream checks skipped after the actual Python-only gate failure. None is counted as passed.',
                  'No Git mutation, workflow dispatch/rerun, game, MCP, Steam or main-tree write was performed by this agent.'
              ]}
    dump(ROOT / 'REPORT.json', report)
    lyd = next(item for item in outcomes if item['workflow'].endswith('li-yu-dao-static.yml'))
    general = next(item for item in outcomes if item['workflow'].endswith('static-ci.yml'))
    text = f'''目标提交：{SHA}。本包只读读取 GitHub，所有新文件仅写入外置目录。

儒家专题实际 CI：run {lyd['run_id']}，job {lyd['job_id']}，completed/{lyd['conclusion']}，9 步全部 success。完整真实 job 日志给出 155 个单测通过（11 + 6 + 102 + 11 + 25），静态检查为 GREEN：70 runtime 文件、889 个双语 key、68 个 event。打包复现为 GREEN、70 文件。workflow 在该提交确实运行新增 test_institution_candidate.py。

通用 Official Runner CI：run {general['run_id']}，job {general['job_id']}，completed/{general['conclusion']}，41 步 success、38 步 skipped、1 步 failure。实际失败为 Enforce Python-only Windows automation：3 份新报告中的禁用 shell 名称被判 forbidden shell reference，exit 1；原文均为说明没有使用该 shell，日志未证明实际执行它。下游静态和构建步骤因此跳过，38 个 skipped 不能都叫可选发布。所有实际步骤与完整合并日志保留。

5 份 workflow 定义按该 SHA 获取，并核验实际字节长度、Git blob SHA-1 和 SHA-256；额外 3 份源文件以提交文件 blob SHA-1 绑定。GitHub 提供合并日志，无法真实拆分 stdout/stderr，未制造分流文件。专题报告的 artifact metadata 与服务器 digest 已保存；未下载 ZIP，derived 下两份报告来自真实 job 日志中的 JSON。

第一次专题日志请求因多传一个参数被工具在参数绑定阶段拒绝，原始失败回执保留，正确参数的第二次请求成功。未重试已知不可用的 registry endpoint。

这些结论仅证明此精确提交的 L0 CI，不能提升为 CK3 实机、反复合流/分裂、领袖、章程、重载或工坊验收通过。不使用旧 3d/bfe 证据代替本次。无 workflow_dispatch、rerun、主树/Git/game 写操作。

实际专题 run：{lyd['run_url']}
实际通用 run：{general['run_url']}
'''
    raw(ROOT / 'REPORT.md', text.encode('utf-8'))
    index = {'schema': 'lyd-external-evidence-index/v1', 'index_excludes_self': True,
             'created_at_utc': datetime.now(timezone.utc).isoformat(), 'files': []}
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and path.name != 'INDEX.json':
            body = path.read_bytes()
            index['files'].append({'path': path.relative_to(ROOT).as_posix(), 'bytes': len(body), 'sha256': sha256(body)})
    dump(ROOT / 'INDEX.json', index)
    print(json.dumps({'file_count': len(index['files']), 'report_sha256': sha256((ROOT / 'REPORT.json').read_bytes()),
                      'index_sha256': sha256((ROOT / 'INDEX.json').read_bytes()), 'overall': report['overall']}))


if __name__ == '__main__':
    main()
