目标提交：c40e28a157447f8ab67889a2355e7cbd0fe3a43f。本包只读读取 GitHub，所有新文件仅写入外置目录。

儒家专题实际 CI：run 37230134838，job 111517885981，completed/success，9 步全部 success。完整真实 job 日志给出 155 个单测通过（11 + 6 + 102 + 11 + 25），静态检查为 GREEN：70 runtime 文件、889 个双语 key、68 个 event。打包复现为 GREEN、70 文件。workflow 在该提交确实运行新增 test_institution_candidate.py。

通用 Official Runner CI：run 37230134883，job 111517886366，completed/failure，41 步 success、38 步 skipped、1 步 failure。实际失败为 Enforce Python-only Windows automation：3 份新报告中的禁用 shell 名称被判 forbidden shell reference，exit 1；原文均为说明没有使用该 shell，日志未证明实际执行它。下游静态和构建步骤因此跳过，38 个 skipped 不能都叫可选发布。所有实际步骤与完整合并日志保留。

5 份 workflow 定义按该 SHA 获取，并核验实际字节长度、Git blob SHA-1 和 SHA-256；额外 3 份源文件以提交文件 blob SHA-1 绑定。GitHub 提供合并日志，无法真实拆分 stdout/stderr，未制造分流文件。专题报告的 artifact metadata 与服务器 digest 已保存；未下载 ZIP，derived 下两份报告来自真实 job 日志中的 JSON。

第一次专题日志请求因多传一个参数被工具在参数绑定阶段拒绝，原始失败回执保留，正确参数的第二次请求成功。未重试已知不可用的 registry endpoint。

这些结论仅证明此精确提交的 L0 CI，不能提升为 CK3 实机、反复合流/分裂、领袖、章程、重载或工坊验收通过。不使用旧 3d/bfe 证据代替本次。无 workflow_dispatch、rerun、主树/Git/game 写操作。

实际专题 run：https://github.com/XenoAmess/ck3_eternal_recurrence/actions/runs/37230134838
实际通用 run：https://github.com/XenoAmess/ck3_eternal_recurrence/actions/runs/37230134883
