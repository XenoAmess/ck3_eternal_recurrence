﻿name="礼与道 R3 普通玩家入口夹具（仅验收）"
version="0.0.1"
supported_version="1.20.*"
tags={"Testing"}
path="C:/workspace/ck3_lyd_runtime_20261004/live-attempt-035/content/entry"
