"""Observe the actual R35 game/Steam/window and freeze only profile inputs."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import psutil
import win32gui
import win32process

BASE = Path("C:/workspace/ck3_lyd_runtime_20261004")
RUN = BASE / "live-attempt-035"
OLD = BASE / "live-attempt-031"
REVIEW = BASE / "r35-root-steam-offline-recovery-20261009-001/OFFLINE-REVIEW.actual.json"
BUS = Path("C:/workspace/.codex-task-bus/bin/codex_task_bus.py")
REPO_BUS = Path("C:/workspace/ck3_eternal_recurrence/tools/codex_task_bus.py")
TASK = "lyd-r0035-d1-cold-diagnostic-live-root"
EXE = Path("C:/Program Files (x86)/Steam/steamapps/common/Crusader Kings III/binaries/ck3.exe")


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write(path: Path, data: dict) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as target:
        json.dump(data, target, ensure_ascii=False, indent=2)
        target.write("\n")


def require(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def main() -> int:
    launch = json.loads((RUN / "launch.json").read_text(encoding="utf-8"))
    game = psutil.Process(launch["pid"])
    require(game.create_time() == launch["process_create_time"] and Path(game.exe()).resolve() == EXE.resolve(), "R35 original game PID changed")
    windows: list[dict] = []

    def collect(hwnd: int, _unused: object) -> None:
        if win32gui.IsWindowVisible(hwnd):
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            if pid == game.pid:
                windows.append({"hwnd": hwnd, "pid": pid, "title": win32gui.GetWindowText(hwnd), "class": win32gui.GetClassName(hwnd), "rect": list(win32gui.GetWindowRect(hwnd))})

    win32gui.EnumWindows(collect, None)
    require(len(windows) == 1 and windows[0]["class"] == "SDL_app", "expected one visible CK3 SDL_app window")
    review = json.loads(REVIEW.read_text(encoding="utf-8"))
    frame = json.loads((REVIEW.parent / review["fresh_frame_receipt"]).read_text(encoding="utf-8"))
    steam_ui = psutil.Process(frame["steam_pid"])
    clients = [p for p in psutil.process_iter(["name", "exe", "create_time"]) if (p.info["name"] or "").lower() == "steam.exe" and p.pid != steam_ui.pid]
    require(len(clients) >= 1, "Steam client process absent")
    client = min(clients, key=lambda p: p.create_time())
    raw = subprocess.run([sys.executable, "-B", "-X", "utf8", str(BUS), "list", "--stale-after", "600"], capture_output=True, check=True, timeout=15).stdout
    packet = json.loads(raw)
    owners = [r for r in packet["tasks"] if r.get("state") == "running" and "ck3-screen:acquired" in r.get("resources", []) and not r.get("stale")]
    require(len(owners) == 1 and owners[0]["task_id"] == TASK, "fresh exclusive screen owner changed")
    packet["task"] = owners[0]
    write(RUN / "native-profile-lease-readback-001.json", packet)
    old_profile = json.loads((OLD / "native-profile.UNBOUND.template.json").read_text(encoding="utf-8"))
    template = dict(old_profile)
    template["userdir"] = (RUN / "userdir").as_posix()
    template["state_directory"] = (RUN / "native-state").as_posix()
    template["evidence_directory"] = (RUN / "native-evidence").as_posix()
    write(RUN / "native-profile.UNBOUND.template.json", template)
    actions = json.loads((OLD / "root-profile-request-001/native-profile-fresh-002/guard-profile.json").read_text(encoding="utf-8"))["actions"]
    write(RUN / "native-actions-reference-only.json", actions)
    request = {"schema": "ck3.lyd.fresh-profile-request.v1", "pid": game.pid, "hwnd": windows[0]["hwnd"],
               "steam_ui_pid": steam_ui.pid, "steam_client_pid": client.pid, "offline_review": str(REVIEW),
               "offline_image_sha256": review["image_sha256"], "lease_receipt": str(RUN / "native-profile-lease-readback-001.json"),
               "screen_task_id": TASK, "task_bus_script": str(REPO_BUS), "task_bus_sha256": sha(REPO_BUS),
               "native_template": str(RUN / "native-profile.UNBOUND.template.json"),
               "actions_file": str(RUN / "native-actions-reference-only.json"),
               "output": str(RUN / "native-profile-freeze-001")}
    write(RUN / "native-profile-request-001.json", request)
    write(RUN / "native-profile-process-observation-001.json", {"utc": datetime.now(timezone.utc).isoformat(), "game_pid": game.pid,
          "game_create_time": game.create_time(), "game_cmdline": game.cmdline(), "windows": windows,
          "steam_ui_pid": steam_ui.pid, "steam_ui_create_time": steam_ui.create_time(),
          "steam_client_pid": client.pid, "steam_client_create_time": client.create_time(),
          "screen_sequence": owners[0]["last_sequence"], "business_state": "DIAGNOSTIC_LOAD_UNVERIFIED"})
    print(json.dumps({"status": "PROFILE_INPUTS_FROZEN_NO_ATTACH", "pid": game.pid, "hwnd": windows[0]["hwnd"], "request": str(RUN / "native-profile-request-001.json")}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
