"""Bind the reviewed R34 official MCP queue to R35's exact frozen profile."""
from pathlib import Path
import hashlib
import json

B=Path('C:/workspace/ck3_lyd_runtime_20261004')
RUN=B/'live-attempt-035'
OLD_SHA='17f25ee86ed0acadb8255604521107c728cc9101c471776c41a69b69363f3577'
NEW_SHA='9e4bc045b877d74d46a726d151ace9c0011638616fe3b1b98bffd08a0596990b'
PROFILE=RUN/'native-profile-with-exit-inventory.json'
assert hashlib.sha256(PROFILE.read_bytes()).hexdigest()==NEW_SHA
names=[
 'r34-root-diagnostic-mcp-client-20261009-001.py',
 'r34-root-queue-request-20261009-001.py',
 'r34-root-read-sdk-20261009-001.py',
 'r34-root-focus-and-enqueue-attach-20261009-001.py',
]
rows=[]
for name in names:
    src=B/name
    raw=src.read_bytes()
    value=raw.decode('utf-8')
    assert 'live-attempt-034' in value
    value=value.replace('live-attempt-034','live-attempt-035').replace('R34','R35').replace('r34','r35')
    if name==names[0]:
        assert OLD_SHA in value
        value=value.replace(OLD_SHA,NEW_SHA)
    target=B/name.replace('r34-', 'r35-')
    with target.open('x',encoding='utf-8',newline='\n') as stream: stream.write(value)
    rows.append({'source':src.as_posix(),'source_sha256':hashlib.sha256(raw).hexdigest(),'target':target.as_posix(),'target_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
for oldname in ('r34-inventory-002.source.json','r34-attach-002.source.json'):
    src=B/'live-attempt-034'/oldname
    raw=src.read_bytes()
    obj=json.loads(raw)
    assert obj['request_id']==oldname.removesuffix('.source.json')
    obj['request_id']=obj['request_id'].replace('r34','r35')
    target=RUN/oldname.replace('r34','r35')
    with target.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(obj,stream,separators=(',',':'))
        stream.write('\n')
    rows.append({'source':src.as_posix(),'source_sha256':hashlib.sha256(raw).hexdigest(),'target':target.as_posix(),'target_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
report=B/'r35-root-native-client-derivation-20261009-001.json'
with report.open('x',encoding='utf-8',newline='\n') as stream:
    json.dump({'schema':'lyd.r35.derived-official-mcp-client.v1','profile_sha256':NEW_SHA,'rows':rows},stream,indent=2)
    stream.write('\n')
print(json.dumps({'report':report.as_posix(),'derived':len(rows)}))
