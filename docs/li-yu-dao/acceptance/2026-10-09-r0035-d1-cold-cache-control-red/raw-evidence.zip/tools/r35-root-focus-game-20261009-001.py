"""Focus only the already observed R35 CK3 HWND using UI Automation."""
from datetime import datetime, timezone
import json
from pathlib import Path
import time

import psutil
import win32gui
import win32process
from pywinauto import Desktop

run = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-035")
launch = json.loads((run / "launch.json").read_text(encoding="utf-8"))
observed = json.loads((run / "native-profile-process-observation-001.json").read_text(encoding="utf-8"))
pid = launch["pid"]
hwnd = observed["windows"][0]["hwnd"]
assert psutil.Process(pid).create_time() == launch["process_create_time"]
assert len(observed["windows"]) == 1 and observed["windows"][0]["pid"] == pid
assert win32gui.IsWindowVisible(hwnd) and win32process.GetWindowThreadProcessId(hwnd)[1] == pid
before = win32gui.GetForegroundWindow()
element = Desktop(backend="uia").window(handle=hwnd).wrapper_object().element_info.element
assert int(element.CurrentProcessId) == pid and int(element.CurrentNativeWindowHandle) == hwnd
assert win32gui.IsWindowVisible(hwnd) and win32process.GetWindowThreadProcessId(hwnd)[1] == pid
element.SetFocus()
deadline = time.monotonic() + 2.0
while win32gui.GetForegroundWindow() != hwnd and time.monotonic() < deadline:
    time.sleep(0.05)
actual = win32gui.GetForegroundWindow()
assert actual == hwnd
with (run / "native-profile-focus-001.json").open("x", encoding="utf-8", newline="\n") as target:
    json.dump({"utc": datetime.now(timezone.utc).isoformat(), "method": "IUIAutomationElement.SetFocus",
               "before": before, "after": actual, "target_pid": pid, "target_hwnd": hwnd,
               "keyboard_or_mouse_input_sent": False}, target, indent=2)
    target.write("\n")
print(json.dumps({"status": "FOCUSED_ACTUAL_GAME_WINDOW", "hwnd": actual}))
