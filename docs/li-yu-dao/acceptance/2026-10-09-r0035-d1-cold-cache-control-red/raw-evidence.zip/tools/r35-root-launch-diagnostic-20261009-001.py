"""R32 source-only diagnostic cold launch; retain the original CK3 process handle."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import psutil

BASE = Path("C:/workspace/ck3_lyd_runtime_20261004")
RUN = BASE / "live-attempt-035"
REVIEW = BASE / "r35-root-steam-offline-recovery-20261009-001/OFFLINE-REVIEW.actual.json"
BUS = Path("C:/workspace/.codex-task-bus/bin/codex_task_bus.py")
TASK = "lyd-r0035-d1-cold-diagnostic-live-root"
EXE = Path("C:/Program Files (x86)/Steam/steamapps/common/Crusader Kings III/binaries/ck3.exe")
EXE_SHA = "98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518"
BASELINE_SHA = "c02bdd05be9935de4152fdf3d880788b05ed56e0d8eecc24c36ff17a2e8cdd2d"
SAVE = "lyd_r35_D1_cold_diagnostic"


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write(path: Path, payload: dict) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as target:
        json.dump(payload, target, ensure_ascii=False, indent=2)
        target.write("\n")


def require(value: bool, message: str) -> None:
    if not value:
        raise RuntimeError(message)


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def main() -> int:
    require(not (RUN / "launch.json").exists(), "R35 launch already recorded")
    require(not (RUN / "launch-attempt.json").exists(), "R35 launch already attempted")
    cold = json.loads((RUN / "COLD-MATERIALIZED.json").read_text(encoding="utf-8"))
    require(cold["run_id"]["run_id"].endswith("--R0035") and cold["game_launched"] is False, "wrong cold run")
    require(sha(EXE) == EXE_SHA, "installed CK3 EXE changed")
    baseline = RUN / "userdir/save games" / (SAVE + ".ck3")
    require(sha(baseline) == BASELINE_SHA, "D1 checkpoint seed changed")
    review = json.loads(REVIEW.read_text(encoding="utf-8"))
    image = REVIEW.parent / review["image"]
    frame = json.loads((REVIEW.parent / review["fresh_frame_receipt"]).read_text(encoding="utf-8"))
    require(review["steam_offline_confirmed"] is True and review["screen_task"] == TASK, "offline review missing")
    require(sha(image) == review["image_sha256"] == frame["moved_sha256"].lower(), "offline image binding changed")
    require(frame["moving_edge_changed"] is True and Path(frame["moved_path"]).resolve() == image.resolve(), "fresh frame changed")
    captured = datetime.fromisoformat(frame["captured_at_utc"].replace("Z", "+00:00"))
    age = (datetime.now(timezone.utc) - captured).total_seconds()
    require(0 <= age <= 600, "offline frame older than ten minutes")
    require(psutil.pid_exists(frame["steam_pid"]), "Steam UI process absent")
    require(not any((p.info["name"] or "").lower() == "ck3.exe" for p in psutil.process_iter(["name"])), "CK3 already running")
    bus = subprocess.run([sys.executable, "-B", "-X", "utf8", str(BUS), "list", "--stale-after", "600"], capture_output=True, timeout=15, check=True)
    packet = json.loads(bus.stdout)
    owners = [r for r in packet["tasks"] if r.get("state") == "running" and "ck3-screen:acquired" in r.get("resources", []) and not r.get("stale")]
    require(len(owners) == 1 and owners[0]["task_id"] == TASK, "exclusive fresh screen owner changed")
    argv = [str(EXE), "-debug_mode", "-gdpr-compliant", "-userdir=" + (RUN / "userdir").as_posix(), "-loadsave=" + SAVE]
    attempt = {"schema": "lyd.r35.diagnostic-launch-attempt.v1", "utc": utc(), "run_id": cold["run_id"]["run_id"], "execution_id": cold["run_id"]["execution_id"], "argv": argv,
               "source_head": "06159b964d859d30f2f07f4b183284df7d6dac47", "current_checkout_head": owners[0]["git"]["head"],
               "task": TASK, "screen_sequence": owners[0]["last_sequence"], "offline_image_sha256": sha(image),
               "offline_review_sha256": sha(REVIEW), "fresh_frame_sha256": sha(REVIEW.parent / review["fresh_frame_receipt"]),
               "baseline_sha256": sha(baseline), "exe_sha256": sha(EXE), "frame_age_seconds": age}
    write(RUN / "launch-attempt.json", attempt)
    stdout = (RUN / "ck3-stdout.txt").open("xb")
    stderr = (RUN / "ck3-stderr.txt").open("xb")
    proc = subprocess.Popen(argv, cwd=EXE.parent, stdout=stdout, stderr=stderr)
    ps = psutil.Process(proc.pid)
    receipt = {**attempt, "schema": "lyd.r35.diagnostic-launch.v1", "launched_at_utc": utc(), "game_started": True,
               "pid": proc.pid, "process_create_time": ps.create_time(), "original_handle_holder_pid": psutil.Process().pid,
               "business_state": "DIAGNOSTIC_NATIVE_LOAD_NOT_YET_VERIFIED"}
    write(RUN / "launch.json", receipt)
    print(json.dumps({"status": "GAME_CREATED_ORIGINAL_HANDLE_RETAINED", "pid": proc.pid, "holder_pid": psutil.Process().pid}, ensure_ascii=False), flush=True)
    rc = proc.wait()
    write(RUN / "game-original-handle-final.json", {"schema": "lyd.r35.original-game-handle-final.v1", "utc": utc(), "pid": proc.pid, "returncode": rc})
    stdout.close()
    stderr.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
