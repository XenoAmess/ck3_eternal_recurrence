"""Clone reviewed R34 launch/profile helpers with exact R35 diagnostic bindings."""
from pathlib import Path
import hashlib
import json

B = Path('C:/workspace/ck3_lyd_runtime_20261004')
sources = [
    'r34-root-launch-diagnostic-20261009-001.py',
    'r34-root-prepare-native-profile-20261009-001.py',
    'r34-root-capture-load-state-20261009-001.py',
    'r34-root-focus-game-20261009-001.py',
    'r34-root-normal-exit-inventory-20261009-001.py',
    'r34-root-bind-normal-exit-profile-20261009-001.py',
]
replacements = [
    ('live-attempt-034', 'live-attempt-035'),
    ('r34-root-steam-offline-recovery-20261009-001', 'r35-root-steam-offline-recovery-20261009-001'),
    ('lyd-r0034-no-follow-primary-heir-live-root', 'lyd-r0035-d1-cold-diagnostic-live-root'),
    ('lyd_r34_i3b_signed_B3_no_follow_flag_diagnostic', 'lyd_r35_D1_cold_diagnostic'),
    ('c8601e7ba08406a551dcddd2a19e454423db2be6b559fad9985c6d1121b537c9', 'c02bdd05be9935de4152fdf3d880788b05ed56e0d8eecc24c36ff17a2e8cdd2d'),
    ('R0034', 'R0035'),
    ('R34', 'R35'),
    ('r34', 'r35'),
    ('signed B3 baseline changed', 'D1 checkpoint seed changed'),
]


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


result = []
for name in sources:
    source = B / name
    raw = source.read_bytes()
    text = raw.decode('utf-8')
    counts = {}
    for before, after in replacements:
        counts[before] = text.count(before)
        text = text.replace(before, after)
    assert counts['live-attempt-034'] >= 1
    if name in sources[:2]:
        assert counts['lyd-r0034-no-follow-primary-heir-live-root'] >= 1
        assert counts['r34-root-steam-offline-recovery-20261009-001'] >= 1
    target = B / name.replace('r34-', 'r35-')
    if target.exists():
        assert target.read_text(encoding='utf-8') == text
    else:
        with target.open('x', encoding='utf-8', newline='\n') as stream:
            stream.write(text)
    result.append({'source': source.as_posix(), 'source_sha256': sha(raw), 'target': target.as_posix(), 'target_sha256': sha(target.read_bytes()), 'replacements': counts})
output = B / 'r35-root-launch-profile-derivation-20261009-002.json'
with output.open('x', encoding='utf-8', newline='\n') as stream:
    json.dump({'schema': 'lyd.r35.derived-helper-sources.v1', 'rows': result}, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({'output': output.as_posix(), 'targets': [row['target'] for row in result]}, ensure_ascii=False))
