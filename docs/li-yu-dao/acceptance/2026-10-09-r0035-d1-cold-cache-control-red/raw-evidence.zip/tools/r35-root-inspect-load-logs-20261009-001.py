"""Read only current log timestamps and final lines for R35 loading diagnosis."""
from pathlib import Path
from datetime import datetime, timezone
import json

root = Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-035/userdir/logs')
out = []
for name in ('debug.log','game.log','error.log','system.log','setup.log'):
    p = root / name
    data = p.read_bytes() if p.exists() else b''
    lines = data.decode('utf-8', errors='replace').splitlines()
    out.append({'name':name,'bytes':len(data),'modified_utc':datetime.fromtimestamp(p.stat().st_mtime,timezone.utc).isoformat() if p.exists() else None,'tail':lines[-8:]})
print(json.dumps(out, ensure_ascii=False))
