"""Archive R35 D1 cold-reload control with extracted-byte verification."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

REPO=Path('C:/workspace/ck3_eternal_recurrence')
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
RUN=B/'live-attempt-035'
PRIOR=B/'live-attempt-034'
OUT=REPO/'docs/li-yu-dao/acceptance/2026-10-09-r0035-d1-cold-cache-control-red'
assert not OUT.exists()
OUT.mkdir(parents=True)


def pin(path: Path) -> dict:
    h=hashlib.sha256(); n=0
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):
            h.update(chunk); n+=len(chunk)
    return {'path':path.as_posix(),'bytes':n,'sha256':h.hexdigest()}


def put(path:Path,value:dict) -> None:
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2)
        stream.write('\n')


seed=PRIOR/'checkpoints/D1/checkpoint.ck3'
copy=RUN/'userdir/save games/lyd_r35_D1_cold_diagnostic.ck3'
assert pin(seed)['bytes']==pin(copy)['bytes']==91711107
assert pin(seed)['sha256']==pin(copy)['sha256']=='c02bdd05be9935de4152fdf3d880788b05ed56e0d8eecc24c36ff17a2e8cdd2d'
old=json.loads((PRIOR/'R34-CACHE-COMPARISON.actual.json').read_bytes())
new_sdk=RUN/'diagnostic-mcp-client-001/0003-r35-cold-D1-cache-001.sdk-result.json'
window_sdk=RUN/'diagnostic-mcp-client-001/0004-r35-cold-D1-window-001.sdk-result.json'
new=json.loads(new_sdk.read_bytes())
window=json.loads(window_sdk.read_bytes())
result=new['structuredContent']['result']
native=result['native_result']
ids=native['actor_cached_succession']['complete_cached_successor_ids']
old_ids=old['stage_caches']['D1_after']['ids']
assert new['isError'] is False and native['read_only'] is True
assert result['queried_revision']==2 and native['snapshot_revision']==1
assert ids==old_ids and len(ids)==45
assert all(x in ids for x in [38561,39045,39171,39352,39527])
assert old['D2a_to_D2b']['after_count']==40
w=window['structuredContent']['result']
assert window['isError'] is False and w['event_definition_key']=='lyd_factory_diag.1'
assert w['current_event_instance_id']==120 and w['queried_revision']==2
assert json.loads((RUN/'game-original-handle-final.json').read_bytes())['returncode']==0
exit_sdk=json.loads((RUN/'diagnostic-mcp-client-001/0011-r35-exit-observe-001.sdk-result.json').read_bytes())
ex=exit_sdk['structuredContent']['result']
assert exit_sdk['isError'] is False and ex['status']=='process_exit_observed_zero'
assert ex['typed_normal_exit_observed'] is True and ex['exit_code']==0 and ex['autosave_verified'] is False
assert json.loads((RUN/'diagnostic-mcp-client-001/final.json').read_bytes())['status']=='CLOSED'
final=json.loads((B/'r35-root-screen-keeper-20261009-001/FINAL.json').read_bytes())
assert final['failure'] is None and final['thread_exited'] is True and final['last_sequence']==4102
for folder in ('r35-root-steam-offline-recovery-20261009-001','r35-root-steam-offline-final-20261009-001'):
    review=json.loads((B/folder/'OFFLINE-REVIEW.actual.json').read_bytes())
    assert review['steam_offline_confirmed'] is True
    assert pin(B/folder/review['image'])['sha256']==review['image_sha256']
bus=subprocess.run([sys.executable,'-B','-X','utf8',str(REPO/'tools/codex_task_bus.py'),'--bus-dir','C:/workspace/.codex-task-bus','--expected-cli-sha256','B3C44B42F7BDF401B593D863E3210106A46412DCD7D89F8596C74F4C27392DEE','list','--stale-after','600'],capture_output=True,check=True,timeout=15)
tasks=json.loads(bus.stdout)['tasks']
task=next(x for x in tasks if x['task_id']=='lyd-r0035-d1-cold-diagnostic-live-root')
assert task['state']=='done' and task['resources']==[] and task['last_sequence']==4103
put(RUN/'R35-CLOSEOUT-TASK.actual.json',task)

comparison={
 'schema':'lyd.r35.d1-cold-cache-control.v1',
 'source_R34_D1_checkpoint':pin(seed),
 'R35_copied_seed':pin(copy),
 'R34_hot_D1_cache_source':pin(PRIOR/'R34-CACHE-COMPARISON.actual.json'),
 'R35_cold_D1_cache_source':pin(new_sdk),
 'R35_event_window_source':pin(window_sdk),
 'hot_count':len(old_ids),'cold_count':len(ids),'ordered_ids_exactly_equal':True,
 'still_present_ids':[38561,39045,39171,39352,39527],
 'R34_D2b_hot_count':40,
 'inference':'D1 cold reload alone did not reproduce the D2b 45-to-40 loss; R35 does not isolate the sub-operation inside D2b.',
 'formal_I3b_credit':None,'whole_mod':'NOT_GREEN',
}
put(RUN/'R35-D1-COLD-COMPARISON.actual.json',comparison)

files={}
def add(root:Path,pattern:str,prefix:str) -> None:
    for path in root.glob(pattern):
        if path.is_file() and path.suffix.lower()!='.ck3':
            arc=prefix+'/'+path.relative_to(root).as_posix()
            assert arc not in files
            files[arc]=path

add(B,'r35-root-*.py','tools')
for name in ('r35-root-launch-profile-derivation-20261009-001.json','r35-root-launch-profile-derivation-20261009-002.json','r35-root-native-client-derivation-20261009-001.json'):
    path=B/name
    assert path.is_file()
    files['preparation/'+name]=path
for pattern in ('*.json','*.png','*.txt'):
    add(RUN,pattern,'run')
for folder in ('diagnostic-mcp-client-001','native-profile-freeze-001','native-evidence'):
    add(RUN/folder,'**/*','run/'+folder)
for name in ('pdx_settings.txt','dlc_load.json','tutorial.txt','normal-exit-source-inventory-v1.json'):
    path=RUN/'userdir'/name
    assert path.is_file()
    files['run/userdir/'+name]=path
add(RUN/'userdir/mod','*.mod','run/userdir/mod')
for name in ('debug.log','error.log','game.log','profile.log'):
    path=RUN/'userdir/logs'/name
    assert path.is_file()
    files['run/userdir/logs/'+name]=path
for phase,folder in (('prelaunch','r35-root-steam-offline-recovery-20261009-001'),('final','r35-root-steam-offline-final-20261009-001')):
    root=B/folder
    for name in ('OFFLINE-REVIEW.actual.json','events.jsonl'):
        path=root/name
        assert path.is_file()
        files[f'steam/{phase}/{name}']=path
    add(root/'probe-1','*',f'steam/{phase}/probe-1')
for name in ('FINAL.json','READY.json','screen-lease.jsonl','STOP.request'):
    path=B/'r35-root-screen-keeper-20261009-001'/name
    assert path.is_file()
    files['screen-lease/'+name]=path
for arc,path in files.items():
    assert path.stat().st_size<=20_000_000,(arc,path.stat().st_size)
entries=[{'archive_path':arc,'source':pin(path)} for arc,path in sorted(files.items())]
index={
 'schema':'lyd.r35.d1-cold-cache-control-archive.v1',
 'status':'DIAGNOSTIC_CONTROL_PASS_FORMAL_I3B_RED',
 'live_run_id':'bf-202609141645-5434332d4d--li-yu-dao--R0035',
 'source_production_head':'06159b964d859d30f2f07f4b183284df7d6dac47',
 'checkout_head_at_launch':'5d6fbbdb92216aa841b9651b8a9a8bb0ccbe4e31',
 'external_save_bodies':[{'role':'R34_D1_original',**pin(seed),'tracked_zip_included':False},{'role':'R35_cold_copy',**pin(copy),'tracked_zip_included':False}],
 'evidence_entries':entries,
 'formal_acceptance_credit':False,
}
put(OUT/'INDEX.json',index)
report='''# R0035 D1 cold-reload succession-cache control — diagnostic only

R35 loaded the exact R34 D1 checkpoint (`c02bdd05be9935de4152fdf3d880788b05ed56e0d8eecc24c36ff17a2e8cdd2d`, 91,711,107 bytes) into a new isolated userdir on CK3 1.20.0.4. The six mod trees were copied byte-for-byte from R34, including its development-only overlay; 129 content files were verified. No product source changed. This run issued no event option, title grant, or checkpoint save after loading.

The paused cold-loaded event was independently read as `lyd_factory_diag.1`, instance `120`, at public revision `2`. The official native cached-succession query at that revision returned **45 ordered IDs**, exactly equal to R34 D1 after-save, including `38561, 39045, 39171, 39352, 39527`. R34's later atomic D2b operation returned 40. This control excludes **D1 cold reload alone** as the cause of the five-ID loss in this seed and build. It does not identify which operation inside atomic D2b causes the change, and it does not prove that any production fix works.

The original CK3 process handle and official normal-exit observer both returned exit code `0`; the observer recorded `typed_normal_exit_observed=true` and `autosave_verified=false`. Fresh original prelaunch and post-exit desktop screenshots were visually reviewed as Steam “离线模式”. The screen keeper ended without failure and the exclusive task was released with no resources. An attempted extra screenshot after native confirm refused because the original game window had already exited; no game input was sent. The client was closed.

Formal I3b, a newly created religious Title cold reload, C3, I4 and whole-mod GREEN remain **NOT_GREEN**. The next useful control is to cold-load an immutable D2a checkpoint and read cache before any D2b grant, or to instrument the atomic D2b block without crossing its transaction scope. `INDEX.json` pins the two external 91 MB save bodies; the ZIP contains all small source, request, SDK, native, log, offline and lease evidence. `ARCHIVE-VALIDATION.actual.json` verifies every ZIP entry's extracted bytes.
'''
with (OUT/'REPORT.md').open('x',encoding='utf-8',newline='\n') as stream: stream.write(report)
zip_path=OUT/'raw-evidence.zip'
with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for entry in entries:
        archive.write(files[entry['archive_path']],entry['archive_path'])
with zipfile.ZipFile(zip_path,'r') as archive:
    assert sorted(archive.namelist())==sorted(files)
    for entry in entries:
        raw=archive.read(entry['archive_path'])
        assert len(raw)==entry['source']['bytes'] and hashlib.sha256(raw).hexdigest()==entry['source']['sha256']
validation={'schema':'lyd.r35.archive-extracted-byte-validation.v1','result':'PASS','entry_count':len(entries),'zip':pin(zip_path),'index':pin(OUT/'INDEX.json'),'report':pin(OUT/'REPORT.md'),'external_save_bodies':2}
put(OUT/'ARCHIVE-VALIDATION.actual.json',validation)
print(json.dumps(validation,ensure_ascii=False))
