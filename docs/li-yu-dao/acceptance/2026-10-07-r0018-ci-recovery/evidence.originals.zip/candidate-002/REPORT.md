External documentation candidate for exact HEAD `dbaf5f8db2067419838b814e278d962f428dc33c` and failed Official Runner run `37556702039`, attempt 1.

Only four existing documentation paragraphs change. Three references to the unexecuted injector recovery script use its descriptive name. The fourth paragraph still states that the historical helpers actually invoked the prohibited Windows shell and .NET, points to the unchanged exact execution provenance, and retains the no-recapture statement. No historical executor is relabeled as Python and no original evidence is rewritten.

Patch SHA-256: `8a82f34f3d7d1e4772a8d19927a28c0b55465031f693effb33b1a3afdc25e56a`.

The exact-HEAD validator accepted only the four edited external documents; git apply --check passed against their frozen before copies. No old tests, whole-repository scan, CI rerun, main checkout write, native compilation, SDK, bus, or game ran. This candidate has not been committed; the original dbaf CI conclusion remains failure.
