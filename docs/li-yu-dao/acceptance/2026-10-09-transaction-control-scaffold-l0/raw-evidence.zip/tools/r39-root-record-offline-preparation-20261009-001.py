from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
R=Path('C:/workspace/ck3_eternal_recurrence');B=Path('C:/workspace/ck3_lyd_runtime_20261004')
O=B/'r39-offline-preparation-20261009-001';O.mkdir()
def pin(p):
 raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def put(p,obj):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n')
commands=[('regression',[sys.executable,'-B','-X','utf8','mod_li_yu_dao/tools/test_factory_diagnostic.py']),('build',[sys.executable,'-B','-X','utf8','mod_li_yu_dao/tools/build_factory_diagnostic.py','--source-root','C:/lr31s1','--source-head','06159b964d859d30f2f07f4b183284df7d6dac47','--export-report',str(B/'r31-root-clean-export-20261008-001/REPORT.json'),'--export-report-sha256','ba6a5fd88967c41909043f68d377e2e22d8c03fa21b3332e383d9a992ccdfc14','--output',str(B/'r39-transaction-control-overlay-sourceonly-20261009-002'),'--control','transaction-only']),('validate',[sys.executable,'-B','-X','utf8','mod_li_yu_dao/tools/validate_factory_diagnostic.py','--source-root','C:/lr31s1','--overlay',str(B/'r39-transaction-control-overlay-sourceonly-20261009-002'),'--output',str(O/'structural-result.json'),'--control','transaction-only']),('common-entry-plan',[sys.executable,'-B','-X','utf8','tools/ck3_mod_acceptance.py','plan','--runtime','C:/workspace/ck3-upgrade-20261008/ck3-mod-acceptance-unified-entry-01/runtime.local-entry-bound11.json','--products','tools/ck3_mod_acceptance_products.json','--product','li-yu-dao','--case','static-and-basicload'])]
results=[]
for name,argv in commands:
 start=datetime.now(timezone.utc);r=subprocess.run(argv,cwd=R,capture_output=True)
 (O/(name+'.stdout')).write_bytes(r.stdout);(O/(name+'.stderr')).write_bytes(r.stderr)
 row={'name':name,'argv':argv,'started_at_utc':start.isoformat(),'finished_at_utc':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode,'stdout':pin(O/(name+'.stdout')),'stderr':pin(O/(name+'.stderr'))}
 results.append(row);print(json.dumps(row))
 if name!='common-entry-plan' and r.returncode:raise RuntimeError(name+' failed')
 if name=='common-entry-plan' and r.returncode!=2:raise RuntimeError('Common runtime state changed: inspect actual response')
put(O/'CHECKS.actual.json',{'schema':'lyd.r39.offline-preparation-checks.v1','commands':results,'game_launches':0,'actual_live_run_id':None,'live_status':'NOT_ALLOCATED_NOT_RUN','formal_acceptance_credit':False,'source_files':[pin(R/p) for p in ['mod_li_yu_dao/tools/build_factory_diagnostic.py','mod_li_yu_dao/tools/validate_factory_diagnostic.py','mod_li_yu_dao/tools/test_factory_diagnostic.py','.github/workflows/li-yu-dao-static.yml']]})
