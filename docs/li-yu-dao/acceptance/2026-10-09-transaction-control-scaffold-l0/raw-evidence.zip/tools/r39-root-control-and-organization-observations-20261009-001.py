from pathlib import Path
import hashlib,json,sys
R=Path('C:/workspace/ck3_eternal_recurrence');B=Path('C:/workspace/ck3_lyd_runtime_20261004')
sys.path.insert(0,str(R/'tools'));from extract_auto_upgrade_buildings import Block,parse_clausewitz
sys.path.insert(0,str(R/'tools/lyd_i3b_checkpoint_readback/reader'))
from i3b_checkpoint_reader import exact_root_block
from dependencies.bounded_save_parser import one
O=B/'r39-offline-preparation-20261009-001'
def require(ok,reason):
 if not ok:raise RuntimeError(reason)
def pin(p):
 raw=p.read_bytes();return {'path':p.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def put(p,obj):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n')
def ast(v):return tuple((e.key,e.operator,ast(e.value)) for e in v.entries) if isinstance(v,Block) else v
def parse(p):return parse_clausewitz(p.read_text(encoding='utf-8-sig'))
def single(block,key):
 values=[e.value for e in block.entries if e.key==key];require(len(values)==1,key);return values[0]
old=B/'r37-transaction-only-overlay-sourceonly-20261009-001'
new=B/'r39-transaction-control-overlay-sourceonly-20261009-002'
rel='common/scripted_effects/lyd_i3b_commit_effects.txt'
a=parse(old/rel);b=parse(new/rel)
same=[]
for e in a.entries:
 if e.key!='lyd_factory_diag_d2_effect':
  require(ast(e.value)==ast(single(b,e.key)),e.key+' changed');same.append(e.key)
da=single(a,'lyd_factory_diag_d2_effect');db=single(b,'lyd_factory_diag_d2_effect')
require(ast(da)==ast(Block(tuple(e for e in db.entries if e.key!='set_variable'))),'control transaction or transition changed')
event_rel='events/lyd_factory_operation_diagnostic.txt';ea=parse(old/event_rel);eb=parse(new/event_rel)
unchanged_events=[]
for e in ea.entries:
 if e.key!='lyd_factory_diag.2':
  require(ast(e.value)==ast(single(eb,e.key)),e.key+' changed');unchanged_events.append(e.key)
for rel in ['descriptor.mod','common/scripted_triggers/lyd_factory_operation_diagnostic.txt']:
 require((old/rel).read_bytes()==(new/rel).read_bytes(),rel+' bytes changed')
put(O/'CONTROL-R37-COMPARISON.actual.json',{'schema':'lyd.transaction-control-scaffold-comparison.v1','all_other_effect_AST_equal':same,'all_other_event_AST_equal':unchanged_events,'D2b_create_resolve_and_transition_AST_equal_after_removing_only_marker':True,'descriptor_and_triggers_byte_equal':True,'declared_changes':['persistent marker after resolve','event2 unheld plus marker guard and no mutator','two-language diagnostic labels'],'source_candidate':str(old),'new_candidate':str(new),'runtime_verified':False})
stage_dir=B/'r38-offline-cache-candidates-20261009-001';stages={name:json.loads((stage_dir/(name+'.json')).read_bytes()) for name in ['R34_D2a','R34_D2b','R38_after_selection']}
rows={}
lost={38561,39045,39171,39352,39527}
for name,stage in stages.items():
 save=Path(stage['save']['path']);require(pin(save)['sha256']==stage['save']['sha256'],'save changed')
 entries=exact_root_block(save.read_text(encoding='utf-8-sig'),'organization_manager')
 database=one(entries,'database',required=True)
 organization=one(database,'107',required=True)
 require(one(organization,'faith',required=True)=='107','organization-faith join mismatch')
 members=[int(cid) for cid,row in stage['characters'].items() if one(row['entries'],'organization')=='107']
 require(set(members)==lost,'organization membership correlation differs')
 rows[name]={'save':stage['save'],'organization_107_entries':organization,'selected_candidate_organization_107_ids':sorted(members),'selected_candidate_count':len(stage['characters']),'organization_107_links_saved_faith_107':True,'same_ids_as_cache_loss':True}
require(rows['R34_D2a']['organization_107_entries']==rows['R34_D2b']['organization_107_entries']==rows['R38_after_selection']['organization_107_entries'],'organization row changed')
result={'schema':'lyd.saved-organization-cache-loss-join.v1','stages':rows,'observation':'All five lost candidates, and none of the other selected candidates, store organization107; actual organization_manager.database107 links Faith107 and is unchanged across these saves.','organization_role_and_inheritance_eligibility_qualified':False,'causal_conclusion':None,'formal_acceptance_credit':False}
put(O/'SAVED-ORGANIZATION-JOIN.actual.json',result)
print(json.dumps({'control_AST_checks':'PASS','selected_organization_members':sorted(lost),'organization_faith_link':107,'causal_conclusion':None}))
