"""Read actual preserved saves, retaining selected character and title ASTs."""
from pathlib import Path
import hashlib,json,sys
REPO=Path('C:/workspace/ck3_eternal_recurrence')
sys.path.insert(0,str(REPO/'tools/lyd_i3b_checkpoint_readback/reader'))
from i3b_checkpoint_reader import records,section,raw_character,saved_character_is_alive,title_database_records,title_row,graph
from dependencies.bounded_save_parser import one
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
out=B/'r38-offline-cache-candidates-20261009-001'
out.mkdir()
cache=json.loads((B/'live-attempt-034/R34-CACHE-COMPARISON.actual.json').read_bytes())
ids=set(cache['stage_caches']['D2a_after']['ids'])|{31254}
lost=set(cache['D2a_to_D2b']['lost_ids'])
titles={2230,2231,2232,2235,2262,2263,2264,18373}
inputs=[('R34_D2a',B/'live-attempt-034/checkpoints/D2a/checkpoint.ck3','a6db85e38ba0648eca4b7e835c79d867b96ca26099698f4d4ee5269b818d822c'),('R34_D2b',B/'live-attempt-034/checkpoints/D2b/checkpoint.ck3','1e7367e00473119e057a852343ccb4362bf175dd7ec4965ff02bed8e202ee307'),('R38_after_selection',B/'live-attempt-038/checkpoints/D2b-no-event/checkpoint.ck3','d96003e938c131385227b43bd9cd43cf3069fdc869fca3b5a43cc4893f859474')]
stages={}
for name,path,expected in inputs:
 raw=path.read_bytes()
 if hashlib.sha256(raw).hexdigest()!=expected:raise RuntimeError('Save hash changed')
 text=raw.decode('utf-8-sig')
 # Use the same qualified framing as the existing checkpoint reader.
 chars={}
 for cid,entries in records(section(text,'living','dead_unprunable'),'character'):
  if cid in ids:
   alive=saved_character_is_alive(cid,entries)
   row=raw_character(cid,entries) if alive else {'character_id':cid,'entries':entries,'alive':False}
   chars[str(cid)]=row
 if set(map(int,chars))!=ids:raise RuntimeError('Candidate character missing')
 rites=graph(text,'rites','faith')
 selected_titles={str(tid):title_row(tid,entries) for tid,entries in title_database_records(text) if tid in titles}
 stages[name]={'save':{'path':str(path),'bytes':len(raw),'sha256':expected},'characters':chars,'titles':selected_titles,'rites':{str(rid):{'faith':row['faith'],'AST_sha256':row['AST_sha256']} for rid,row in rites.items()}}
 summary=[]
 for cid,row in chars.items():
  rid=row.get('rite_id');faith=rites[rid]['faith'] if rid is not None else None
  summary.append({'id':int(cid),'lost_at_R34_D2b':int(cid) in lost,'rite':rid,'faith':faith,'sex':one(row['entries'],'female'),'culture':one(row['entries'],'culture'),'birth':one(row['entries'],'birth'),'name':one(row['entries'],'first_name'),'keys':[e['key'] for e in row['entries']]})
 stages[name]['character_summary']=summary
 print(name,json.dumps({'lost':[r for r in summary if r['lost_at_R34_D2b']],'actor':next(r for r in summary if r['id']==31254)}))
 with (out/(name+'.json')).open('x',encoding='utf-8',newline='\n') as f:json.dump(stages[name],f,ensure_ascii=False,indent=2);f.write('\n')
 print('saved',out/(name+'.json'))
comparisons={}
baseline=stages['R34_D2a']
for name in ['R34_D2b','R38_after_selection']:
 current=stages[name]
 comparisons[name]={'changed_character_ids':[int(cid) for cid,row in baseline['characters'].items() if row['AST_sha256']!=current['characters'][cid]['AST_sha256']],'changed_political_title_ids':[int(tid) for tid,row in baseline['titles'].items() if tid!='18373' and row['AST_sha256']!=current['titles'][tid]['AST_sha256']],'dynamic_title_holders':{'before':baseline['titles']['18373']['holder'],'after':current['titles']['18373']['holder']},'dynamic_title_AST_equal':baseline['titles']['18373']['AST_sha256']==current['titles']['18373']['AST_sha256']}
report={'schema':'lyd.r38.offline-cache-candidate-observations.v1','lost_ids':sorted(lost),'comparisons':comparisons,'causal_conclusion':None,'formal_acceptance_credit':False}
with (out/'COMPARISON.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(report))
