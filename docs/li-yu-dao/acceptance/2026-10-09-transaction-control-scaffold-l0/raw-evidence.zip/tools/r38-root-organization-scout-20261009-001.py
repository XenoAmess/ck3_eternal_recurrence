from pathlib import Path
import re,json,subprocess
path=Path('C:/workspace/ck3_lyd_runtime_20261004/live-attempt-034/checkpoints/D2a/checkpoint.ck3')
text=path.read_text(encoding='utf-8-sig')
roots=list(re.finditer(r'^([A-Za-z_][A-Za-z0-9_]*)=\{',text,re.M))
print('ROOTS',[m.group(1) for m in roots])
for i,m in enumerate(roots):
 if any(s in m.group(1) for s in ['organization','order','mercenar']):
  span=text[m.start():roots[i+1].start() if i+1<len(roots) else len(text)]
  print('SECTION',m.group(1),'bytes',len(span),'preview',span[:1500])
  for found in re.finditer(r'^\t{0,3}107=\{',span,re.M):print('ID107',span[found.start():found.start()+2000])
for p in [Path('ck3_autonomous_player/native_bridge/src'),Path('ck3_autonomous_player/native_bridge/research')]:
 r=subprocess.run(['rg','-l','organization|holy_order|mercenary',str(p),'-g','*succession*'],capture_output=True,text=True,encoding='utf-8')
 print('NATIVE_SEARCH',r.stdout)
