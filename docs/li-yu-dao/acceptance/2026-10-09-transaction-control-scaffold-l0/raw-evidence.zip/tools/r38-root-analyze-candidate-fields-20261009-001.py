from pathlib import Path
import json
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
root=B/'r38-offline-cache-candidates-20261009-001'
a=json.loads((root/'R34_D2a.json').read_bytes());b=json.loads((root/'R34_D2b.json').read_bytes())
lost={38561,39045,39171,39352,39527}
def value(entries,key):return [e['value'] for e in entries if e['key']==key]
for cid,row in a['characters'].items():
 e=row['entries']
 print('CHAR',cid,'LOST' if int(cid) in lost else '',json.dumps({key:value(e,key) for key in ['first_name','birth','dynasty_house','organization','traits','family_data']},ensure_ascii=False))
for tid in ['2230','2231','2232','2235','2262','2263','2264','18373']:
 x=a['titles'][tid]['entries'];y=b['titles'][tid]['entries']
 print('TITLE',tid,json.dumps({'before_heirs':value(x,'heir'),'after_heirs':value(y,'heir'),'before_keys':[e['key'] for e in x],'before_laws':value(x,'laws'),'after_laws':value(y,'laws')},ensure_ascii=False))
for stage,row in [('R34_D2a',a),('R34_D2b',b)]:
 p=Path(row['save']['path'])
 with p.open(encoding='utf-8-sig') as f:
  for i,line in enumerate(f):
   if line.startswith('date=') or line.startswith('meta_date='):print(stage,'DATE',line.strip())
   if i>1000:break
