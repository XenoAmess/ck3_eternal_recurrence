from pathlib import Path
import subprocess
import sys

run = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-034")
profile = run / "native-profile-freeze-001/native-profile.json"
stock = Path("C:/Program Files (x86)/Steam/steamapps/common/Crusader Kings III/game")
assert profile.is_file() and stock.is_dir()
argv = [sys.executable, "-B", "-X", "utf8", "C:/workspace/ck3_eternal_recurrence/tools/build_normal_exit_source_inventory_v1.py",
        "--profile", str(profile), "--stock-game-root", str(stock)]
raise SystemExit(subprocess.run(argv, cwd="C:/workspace/ck3_eternal_recurrence").returncode)
