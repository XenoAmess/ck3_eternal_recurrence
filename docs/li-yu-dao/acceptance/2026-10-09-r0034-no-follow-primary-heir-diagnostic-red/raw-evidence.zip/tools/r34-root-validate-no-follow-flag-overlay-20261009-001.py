"""Parse and compare R34's exact one-property diagnostic overlay without launching CK3."""
from pathlib import Path
import hashlib
import json
import sys

repo = Path("C:/workspace/ck3_eternal_recurrence")
sys.path.insert(0, str(repo / "tools"))
from extract_auto_upgrade_buildings import Block, parse_clausewitz
sys.path.insert(0, str(repo / "mod_li_yu_dao/tools"))
import validate_static

B = Path("C:/workspace/ck3_lyd_runtime_20261004")
OLD = B / "live-attempt-031/content/diagnostic_stage"
NEW = B / "r34-no-follow-primary-heir-overlay-sourceonly-20261009-001"
OUT = B / "r34-no-follow-primary-heir-overlay-static-20261009-001.json"
assert not OUT.exists()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def parse(path):
    raw = path.read_bytes()
    assert raw.startswith(b"\xef\xbb\xbf")
    return parse_clausewitz(raw.decode("utf-8-sig"))

def only(block, key):
    values = [e.value for e in block.entries if e.key == key]
    assert len(values) == 1, key
    return values[0]

def node(value):
    if isinstance(value, Block):
        return tuple((e.key, e.operator, node(e.value)) for e in value.entries)
    return value

manifest = json.loads((NEW / "CANDIDATE-MANIFEST.json").read_text(encoding="utf-8"))
assert manifest["source_production_head"] == "06159b964d859d30f2f07f4b183284df7d6dac47"
assert manifest["production71_modified"] is False and len(manifest["files"]) == 6
assert sum(row["changed"] for row in manifest["files"]) == 1
for row in manifest["files"]:
    relative = row["relative_path"]
    assert digest(OLD / relative) == row["source_sha256"]
    assert digest(NEW / relative) == row["candidate_sha256"]
    assert (OLD / relative).read_bytes() == (NEW / relative).read_bytes() if not row["changed"] else True

old_effects = parse(OLD / "common/scripted_effects/lyd_i3b_commit_effects.txt")
new_effects = parse(NEW / "common/scripted_effects/lyd_i3b_commit_effects.txt")
assert [e.key for e in old_effects.entries] == [e.key for e in new_effects.entries]
for entry in old_effects.entries:
    if entry.key != "lyd_factory_diag_d20_effect":
        assert node(only(new_effects, entry.key)) == node(entry.value), entry.key
old20 = only(old_effects, "lyd_factory_diag_d20_effect")
new20 = only(new_effects, "lyd_factory_diag_d20_effect")
assert [e.key for e in old20.entries] == [e.key for e in new20.entries]
old_title = only(old20, "scope:new_title")
new_title = only(new20, "scope:new_title")
assert [e.key for e in old_title.entries].count("set_always_follows_primary_heir") == 1
assert all(e.key != "set_always_follows_primary_heir" for e in new_title.entries)
assert node(new_title) == tuple((e.key, e.operator, node(e.value)) for e in old_title.entries if e.key != "set_always_follows_primary_heir")
for entry in old20.entries:
    if entry.key != "scope:new_title":
        assert node(only(new20, entry.key)) == node(entry.value)
assert node(only(old_effects, "lyd_factory_diag_d2_effect")) == node(only(new_effects, "lyd_factory_diag_d2_effect"))
for relative in ("common/scripted_triggers/lyd_factory_operation_diagnostic.txt", "events/lyd_factory_operation_diagnostic.txt", "descriptor.mod"):
    assert node(parse(OLD / relative)) == node(parse(NEW / relative))
for path in NEW.rglob("*.txt"):
    parse(path)
parse(NEW / "descriptor.mod")
for path in NEW.rglob("*.yml"):
    raw = path.read_bytes()
    assert raw.startswith(b"\xef\xbb\xbf")
    for line in raw.decode("utf-8-sig").splitlines()[1:]:
        assert validate_static.LOC_ROW.fullmatch(line), (path, line)
result = {"schema": "lyd.r34.no-follow-primary-heir-static-validation.v1",
          "status": "PASS_SOURCE_ONLY_RUNTIME_NOT_RUN", "manifest_sha256": digest(NEW / "CANDIDATE-MANIFEST.json"),
          "source_six_files_verified": True, "changed_file_count": 1,
          "removed_only": "D2a set_always_follows_primary_heir = yes", "atomic_D2b_AST_unchanged": True,
          "all_other_effect_event_trigger_AST_unchanged": True, "game_or_SDK_calls": 0, "formal_I3b_credit": None}
with OUT.open("x", encoding="utf-8", newline="\n") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
    f.write("\n")
print(json.dumps(result, ensure_ascii=False))
