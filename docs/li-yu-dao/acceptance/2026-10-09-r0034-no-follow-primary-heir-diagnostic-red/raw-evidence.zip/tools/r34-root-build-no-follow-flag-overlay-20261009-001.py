"""Build a source-only single-variable R34 diagnostic from the pinned R31 overlay."""
from pathlib import Path
import hashlib
import json
import shutil

B = Path("C:/workspace/ck3_lyd_runtime_20261004")
SOURCE = B / "live-attempt-031/content/diagnostic_stage"
OUT = B / "r34-no-follow-primary-heir-overlay-sourceonly-20261009-001"
assert SOURCE.is_dir() and not OUT.exists()
OUT.mkdir()
paths = (
    "common/scripted_effects/lyd_i3b_commit_effects.txt",
    "common/scripted_triggers/lyd_factory_operation_diagnostic.txt",
    "descriptor.mod",
    "events/lyd_factory_operation_diagnostic.txt",
    "localization/english/lyd_factory_operation_diagnostic_l_english.yml",
    "localization/simp_chinese/lyd_factory_operation_diagnostic_l_simp_chinese.yml",
)
rows = []
for relative in paths:
    src = SOURCE / relative
    dst = OUT / relative
    dst.parent.mkdir(parents=True, exist_ok=True)
    original = src.read_bytes()
    candidate = original
    if relative.endswith("lyd_i3b_commit_effects.txt"):
        target = b"        set_always_follows_primary_heir = yes\r\n"
        if target not in original:
            target = b"        set_always_follows_primary_heir = yes\n"
        assert original.count(target) == 1
        candidate = original.replace(target, b"", 1)
    with dst.open("xb") as f:
        f.write(candidate)
    rows.append({"relative_path": relative, "source_sha256": hashlib.sha256(original).hexdigest(),
                 "candidate_sha256": hashlib.sha256(candidate).hexdigest(), "changed": original != candidate,
                 "bytes": len(candidate)})
manifest = {"schema": "lyd.r34.no-follow-primary-heir-overlay-candidate.v1",
            "status": "SOURCE_ONLY_RUNTIME_NOT_RUN", "source_production_head": "06159b964d859d30f2f07f4b183284df7d6dac47",
            "source_diagnostic_run": "R0031", "candidate_purpose": "test one dynamic-title flag with original atomic D2b unchanged",
            "removed_only": "D2a set_always_follows_primary_heir = yes", "production71_modified": False,
            "formal_I3b_credit": None, "files": rows}
with (OUT / "CANDIDATE-MANIFEST.json").open("x", encoding="utf-8", newline="\n") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
    f.write("\n")
print(json.dumps({"candidate": OUT.as_posix(), "changed_file_count": sum(x["changed"] for x in rows),
                  "manifest_sha256": hashlib.sha256((OUT / "CANDIDATE-MANIFEST.json").read_bytes()).hexdigest()}))
