from pathlib import Path
import hashlib
import json

B = Path("C:/workspace/ck3_lyd_runtime_20261004")
source = B / "r32-root-compare-candidate-20261009-001.py"
dest = B / "r34-root-compare-candidate-20261009-001.py"
raw = source.read_text(encoding="utf-8")
replacements = {
    "live-attempt-032": "live-attempt-034",
    "diagnostic-mcp-client-002": "diagnostic-mcp-client-001",
    "9e8f090d72f88cd3756f74dcfe9d25853320cc39d0a60fdcf72d1ee9f8e5df4b": "c02bdd05be9935de4152fdf3d880788b05ed56e0d8eecc24c36ff17a2e8cdd2d",
    "76470da3f04754a392d1a033da3927fded84473c75a41c12a1f0e578343c38f6": "a6db85e38ba0648eca4b7e835c79d867b96ca26099698f4d4ee5269b818d822c",
    "08e8c720e0c6028e12ef427a3842864700ac7fa451edef677360f7c473ae16b8": "1e7367e00473119e057a852343ccb4362bf175dd7ec4965ff02bed8e202ee307",
    "0003-r32-D0": "0003-r34-D0", "0006-r32-D0": "0005-r34-D0",
    "0009-r32-D1": "0008-r34-D1", "0012-r32-D1": "0011-r34-D1",
    "0014-r32-D2a": "0013-r34-D2a", "0017-r32-D2a": "0016-r34-D2a",
    "0019-r32-D2b": "0018-r34-D2b", "0021-r32-D2b": "0020-r34-D2b",
    "lyd.r32.pregrant-law": "lyd.r34.no-follow-primary-heir",
    "R32-CACHE": "R34-CACHE", "R32-SAVED": "R34-SAVED",
}
for old, new in replacements.items():
    assert old in raw, old
    raw = raw.replace(old, new)
needle = 'write(RUN / "R34-SAVED-TITLE-COMPARISON.actual.json", saved_result)'
assert needle in raw
raw = raw.replace(needle, 'assert "always_follows_primary_heir" not in dynamic["D2a"]["top_level_keys"] and "always_follows_primary_heir" not in dynamic["D2b"]["top_level_keys"]\n' + needle)
compile(raw, str(dest), "exec")
with dest.open("x", encoding="utf-8", newline="\n") as f:
    f.write(raw)
print(json.dumps({"dest": dest.as_posix(), "sha256": hashlib.sha256(dest.read_bytes()).hexdigest()}))
