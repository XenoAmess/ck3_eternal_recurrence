"""Freeze R34 one-flag diagnostic RED with extracted-byte-verified evidence."""
from pathlib import Path
import hashlib
import json
import zipfile

REPO = Path("C:/workspace/ck3_eternal_recurrence")
B = Path("C:/workspace/ck3_lyd_runtime_20261004")
RUN = B / "live-attempt-034"
OUT = REPO / "docs/li-yu-dao/acceptance/2026-10-09-r0034-no-follow-primary-heir-diagnostic-red"
assert not OUT.exists()
OUT.mkdir(parents=True)

def sha(path):
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
            size += len(block)
    return {"bytes": size, "sha256": h.hexdigest()}

files = {}
def add(root, glob, prefix):
    for path in root.glob(glob):
        if path.is_file() and path.suffix.lower() != ".ck3":
            arc = f"{prefix}/{path.relative_to(root).as_posix()}"
            assert arc not in files
            files[arc] = path

add(B / "r34-no-follow-primary-heir-overlay-sourceonly-20261009-001", "**/*", "overlay")
add(B, "r34-root-*.py", "tools")
for path in (B / "r34-no-follow-primary-heir-overlay-static-20261009-001.json",
             B / "r34-stock-follow-flag-occurrences-20261009-001.json",
             B / "r34-root-cold-materializer-derivation-20261009-001.json",
             B / "r34-root-launch-derivation-20261009-001.json",
             B / "r34-root-derived-native-tools-20261009-001.json"):
    assert path.is_file()
    files["preparation/" + path.name] = path
for pattern in ("*.json", "*.png", "*.txt"):
    add(RUN, pattern, "run")
for directory in ("diagnostic-mcp-client-001", "native-profile-freeze-001", "native-evidence", "checkpoints"):
    add(RUN / directory, "**/*", "run/" + directory)
for name in ("pdx_settings.txt", "dlc_load.json", "tutorial.txt", "normal-exit-source-inventory-v1.json"):
    path = RUN / "userdir" / name
    assert path.is_file()
    files["run/userdir/" + name] = path
add(RUN / "userdir/mod", "*.mod", "run/userdir/mod")
for name in ("debug.log", "error.log", "game.log", "profile.log"):
    path = RUN / "userdir/logs" / name
    assert path.is_file()
    files["run/userdir/logs/" + name] = path
for phase, dirname in (("prelaunch", "r34-root-steam-offline-recovery-20261009-001"),
                       ("final", "r34-root-steam-offline-final-20261009-001")):
    folder = B / dirname
    for name in ("OFFLINE-REVIEW.actual.json", "events.jsonl"):
        assert (folder / name).is_file()
        files[f"steam/{phase}/{name}"] = folder / name
    add(folder / "probe-1", "*", f"steam/{phase}/probe-1")
for name in ("FINAL.json", "screen-lease.jsonl", "STOP.request"):
    path = B / "r34-root-screen-keeper-20261009-001" / name
    assert path.is_file()
    files["screen-lease/" + name] = path
for arc, path in files.items():
    assert path.is_file() and path.stat().st_size <= 20_000_000, (arc, path.stat().st_size)
entries = [{"archive_path": arc, "source_path": path.as_posix(), **sha(path)} for arc, path in sorted(files.items())]
external = []
for name, path in (
    ("signed_B3_original", B / "live-attempt-031/userdir/save games/lyd_r31_i3b_signed_B3_diagnostic.ck3"),
    ("signed_B3_R34_copy", RUN / "userdir/save games/lyd_r34_i3b_signed_B3_no_follow_flag_diagnostic.ck3"),
    ("D1_checkpoint", RUN / "checkpoints/D1/checkpoint.ck3"),
    ("D2a_checkpoint", RUN / "checkpoints/D2a/checkpoint.ck3"),
    ("D2b_checkpoint", RUN / "checkpoints/D2b/checkpoint.ck3"),
):
    assert path.is_file()
    external.append({"role": name, "path": path.as_posix(), **sha(path), "tracked_zip_included": False})
assert external[0]["sha256"] == external[1]["sha256"] == "c8601e7ba08406a551dcddd2a19e454423db2be6b559fad9985c6d1121b537c9"
assert external[2]["sha256"] == "c02bdd05be9935de4152fdf3d880788b05ed56e0d8eecc24c36ff17a2e8cdd2d"
assert external[3]["sha256"] == "a6db85e38ba0648eca4b7e835c79d867b96ca26099698f4d4ee5269b818d822c"
assert external[4]["sha256"] == "1e7367e00473119e057a852343ccb4362bf175dd7ec4965ff02bed8e202ee307"

cache = json.loads((RUN / "R34-CACHE-COMPARISON.actual.json").read_text(encoding="utf-8"))
assert cache["D2a_to_D2b"]["before_count"] == 45 and cache["D2a_to_D2b"]["after_count"] == 40
assert cache["D2a_to_D2b"]["lost_ids"] == [38561, 39045, 39171, 39352, 39527]
saved = json.loads((RUN / "R34-SAVED-TITLE-COMPARISON.actual.json").read_text(encoding="utf-8"))
assert all("always_follows_primary_heir" not in saved["dynamic_title_18373"][stage]["top_level_keys"] for stage in ("D2a", "D2b"))
assert [n for n, row in saved["political_title_AST_hashes"].items() if not row["D2a_equals_D2b"]] == ["2230", "2231", "2235", "2262", "2264"]
exit_sdk = json.loads((RUN / "diagnostic-mcp-client-001/0027-r34-exit-observe-001.sdk-result.json").read_text(encoding="utf-8"))
assert exit_sdk["isError"] is False and exit_sdk["structuredContent"]["result"]["typed_normal_exit_observed"] is True
assert exit_sdk["structuredContent"]["result"]["exit_code"] == 0
assert json.loads((RUN / "game-original-handle-final.json").read_text(encoding="utf-8"))["returncode"] == 0
assert json.loads((RUN / "diagnostic-mcp-client-001/final.json").read_text(encoding="utf-8"))["status"] == "CLOSED"

index = {"schema": "lyd.r34.diagnostic-red-archive-index.v1", "status": "RED_NO_FOLLOW_FLAG_DID_NOT_FIX_CACHE",
         "live_run_id": "bf-202609141645-5434332d4d--li-yu-dao--R0034", "source_production_head": "06159b964d859d30f2f07f4b183284df7d6dac47",
         "checkout_head_at_launch": "a2ffce6225f401857bfd6bc7a47138a201193bec", "evidence_entries": entries,
         "external_save_bodies": external, "production71_modified": False, "formal_acceptance_credit": False}
with (OUT / "INDEX.json").open("x", encoding="utf-8", newline="\n") as f:
    json.dump(index, f, ensure_ascii=False, indent=2)
    f.write("\n")
report = """# R0034 no-follow-primary-heir native diagnostic — RED

R34 tested a single development-only change against the signed R31 B3 seed on CK3 1.20.0.4: remove `set_always_follows_primary_heir = yes` while creating the new unheld faith-head title. The other five diagnostic overlay files were byte-identical to R31, and the original D2b create/change-holder/resolve block stayed atomic and AST-identical. The 71 production files were untouched. Exact source pins and static parser validation are in the ZIP and `INDEX.json`.

Native cached successor counts were **45, 45, 45, 45, 45, 45, 40, 40** at D0 before/after save, D1 before/after save, D2a before/after save, and D2b before/after save. The five lost IDs were `38561, 39045, 39171, 39352, 39527`, with no gained IDs. The D2b change was observed before its checkpoint save. D1 and D2a saved political title ASTs match; after D2b, titles `2230, 2231, 2235, 2262, 2264` changed while their holders remained `31254`. The new dynamic title `18373` was unheld at D2a and held by `31254` at D2b. Its saved AST lacks `always_follows_primary_heir` at both stages, confirming that the one-field candidate applied. Its remaining law serialization is not qualified by these save fields. The hypothesis that this flag alone causes the five-ID loss is falsified for this exact native run.

R34 waited until the paused campaign and original `lyd.430` event were visible before freezing its profile and exit-source inventory. The first native attach succeeded. The official normal-exit context, prepare, continue, confirm, and observer sequence returned `process_exit_observed_zero`, `typed_normal_exit_observed=true`, and exit code `0`; the original game process handle independently returned `0`. The native observer reported `autosave_verified=false`, so no autosave claim is made. A fresh post-exit desktop image was visually reviewed as Steam “离线模式”, and the exclusive screen task was released.

This is **diagnostic RED**. It does not earn Phase I I3b, successful T cold reload, C3, I4, or whole-mod GREEN credit. The stock game also uses this title flag in religious head workflows, so removal is not a production fix. The next diagnostic must observe the atomic D2b operation more closely without pretending its title-change transaction scope can survive an event split. Save bodies stay in the outside runtime under the exact size/SHA-256 refs in `INDEX.json`; the tracked ZIP contains requests, SDK results, screenshots, source, logs, and lease/offline receipts. `ARCHIVE-VALIDATION.actual.json` verifies every ZIP entry's extracted bytes.
"""
with (OUT / "REPORT.md").open("x", encoding="utf-8", newline="\n") as f:
    f.write(report)

zip_path = OUT / "raw-evidence.zip"
with zipfile.ZipFile(zip_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for entry in entries:
        archive.write(files[entry["archive_path"]], entry["archive_path"])
with zipfile.ZipFile(zip_path, "r") as archive:
    assert sorted(archive.namelist()) == sorted(files)
    for entry in entries:
        data = archive.read(entry["archive_path"])
        assert len(data) == entry["bytes"] and hashlib.sha256(data).hexdigest() == entry["sha256"]
validation = {"schema": "lyd.r34.archive-extracted-byte-validation.v1", "result": "PASS",
              "entry_count": len(entries), "zip": {"path": zip_path.as_posix(), **sha(zip_path)},
              "index": {"path": (OUT / "INDEX.json").as_posix(), **sha(OUT / "INDEX.json")},
              "report": {"path": (OUT / "REPORT.md").as_posix(), **sha(OUT / "REPORT.md")},
              "save_bodies_retained_external": len(external)}
with (OUT / "ARCHIVE-VALIDATION.actual.json").open("x", encoding="utf-8", newline="\n") as f:
    json.dump(validation, f, ensure_ascii=False, indent=2)
    f.write("\n")
print(json.dumps(validation, ensure_ascii=False))
