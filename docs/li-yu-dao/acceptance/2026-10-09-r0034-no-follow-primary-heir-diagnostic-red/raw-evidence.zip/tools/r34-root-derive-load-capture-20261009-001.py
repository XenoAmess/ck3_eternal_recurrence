from pathlib import Path
source = Path("C:/workspace/ck3_lyd_runtime_20261004/r33-root-capture-load-state-20261009-003.py")
dest = Path("C:/workspace/ck3_lyd_runtime_20261004/r34-root-capture-load-state-20261009-001.py")
raw = source.read_text(encoding="utf-8")
assert "live-attempt-033" in raw and "R33-LOAD-STATE-003" in raw
raw = raw.replace("live-attempt-033", "live-attempt-034").replace("R33-LOAD-STATE-003", "R34-LOAD-STATE-001")
compile(raw, str(dest), "exec")
with dest.open("x", encoding="utf-8", newline="\n") as f:
    f.write(raw)
print(dest)
