from pathlib import Path
import hashlib
import json

B = Path("C:/workspace/ck3_lyd_runtime_20261004")
source = B / "r33-root-materialize-cold-candidate-20261009-001.py"
dest = B / "r34-root-materialize-cold-candidate-20261009-001.py"
raw = source.read_text(encoding="utf-8")
replacements = {
    "live-attempt-033": "live-attempt-034",
    "r33-split-d2b-overlay-sourceonly-20261009-001": "r34-no-follow-primary-heir-overlay-sourceonly-20261009-001",
    "lyd_r33_i3b_signed_B3_split_d2b_diagnostic": "lyd_r34_i3b_signed_B3_no_follow_flag_diagnostic",
    "bf-202609141645-5434332d4d--li-yu-dao--R0033": "bf-202609141645-5434332d4d--li-yu-dao--R0034",
    "8a946755-febf-44dc-a09a-749bdbbe3f9a": "51545453-f5a0-4492-88bd-c4597471e957",
    '"sequence": 33': '"sequence": 34',
    "2026-10-09T00:02:54.419332+00:00": "2026-10-09T00:53:00.596142+00:00",
    '"allocator_pid": 8140': '"allocator_pid": 27356',
    '"legacy_alias": "R33"': '"legacy_alias": "R34"',
    "lyd.r33.": "lyd.r34.",
    "R33 cold": "R34 cold",
}
for old, new in replacements.items():
    assert old in raw, old
    raw = raw.replace(old, new)
compile(raw, str(dest), "exec")
with dest.open("x", encoding="utf-8", newline="\n") as f:
    f.write(raw)
with (B / "r34-root-cold-materializer-derivation-20261009-001.json").open("x", encoding="utf-8") as f:
    json.dump({"source": source.as_posix(), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
               "dest": dest.as_posix(), "dest_sha256": hashlib.sha256(dest.read_bytes()).hexdigest(),
               "replacements": replacements}, f, ensure_ascii=False, indent=2)
    f.write("\n")
print(json.dumps({"dest": dest.as_posix(), "sha256": hashlib.sha256(dest.read_bytes()).hexdigest()}))
