"""Run the frozen R34 D0/D1/D2a request sequence, stopping on any mismatch."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import time

run = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-034")
queue = run / "diagnostic-mcp-queue-001"
client = run / "diagnostic-mcp-client-001"
journal = run / "R34-D0-D2A-DRIVER.actual.jsonl"
assert queue.is_dir() and client.is_dir() and not journal.exists()

def digest(path):
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
            size += len(chunk)
    return {"bytes": size, "sha256": h.hexdigest()}

def append(row):
    with journal.open("a", encoding="utf-8", newline="\n") as f:
        json.dump(row, f, ensure_ascii=False)
        f.write("\n")
    print(json.dumps(row, ensure_ascii=False), flush=True)

def preserve(stage, checkpoint):
    source = Path(checkpoint["path"])
    assert source == run / "userdir/save games/xar_checkpoint.ck3"
    assert digest(source) == {"bytes": checkpoint["size"], "sha256": checkpoint["sha256"]}
    target_dir = run / "checkpoints" / stage
    assert not target_dir.exists()
    target_dir.mkdir(parents=True)
    target = target_dir / "checkpoint.ck3"
    with source.open("rb") as src, target.open("xb") as dst:
        shutil.copyfileobj(src, dst, 1024 * 1024)
    assert digest(target) == digest(source) == {"bytes": checkpoint["size"], "sha256": checkpoint["sha256"]}
    with (target_dir / "COPY.actual.json").open("x", encoding="utf-8", newline="\n") as f:
        json.dump({"stage": stage, "source": source.as_posix(), "copy": target.as_posix(), **digest(target)}, f, indent=2)
        f.write("\n")
    return digest(target)

steps = (
    ("D0-cache-before-001", "cache", 2, 45),
    ("D0-save-001", "save", None, None),
    ("D0-cache-after-001", "cache", 3, 45),
    ("D1-window-001", "event", 119, "lyd.430"),
    ("D1-select-001", "select", 4, None),
    ("D1-cache-before-001", "cache", 4, 45),
    ("D1-stage-window-001", "event", 120, "lyd_factory_diag.1"),
    ("D1-save-001", "save", None, "D1"),
    ("D1-cache-after-001", "cache", 5, 45),
    ("D2a-select-001", "select", 6, None),
    ("D2a-cache-before-001", "cache", 6, 45),
    ("D2a-stage-window-001", "event", 121, "lyd_factory_diag.20"),
    ("D2a-save-001", "save", None, "D2a"),
    ("D2a-cache-after-001", "cache", 7, 45),
)
for sequence, (name, kind, expected, detail) in enumerate(steps, 3):
    request_id = "r34-" + name
    source = run / (request_id + ".source.json")
    request = json.loads(source.read_text(encoding="utf-8"))
    assert request["request_id"] == request_id
    target = queue / (request_id + ".request.json")
    assert not target.exists()
    os.link(source, target)
    response = client / f"{sequence:04d}-{request_id}.response.json"
    sdk_file = client / f"{sequence:04d}-{request_id}.sdk-result.json"
    deadline = time.monotonic() + 90
    while not response.exists() or not sdk_file.exists():
        assert time.monotonic() < deadline, name
        time.sleep(0.2)
    response_data = json.loads(response.read_text(encoding="utf-8"))
    sdk = json.loads(sdk_file.read_text(encoding="utf-8"))
    assert response_data["status"] == "MCP_RESULT_RECORDED" and sdk["isError"] is False, name
    s = sdk["structuredContent"]
    r = s.get("result", {})
    row = {"sequence": sequence, "request_id": request_id, "kind": kind, "source": digest(source),
           "response": digest(response), "sdk": digest(sdk_file), "status": s.get("status")}
    if kind == "cache":
        ids = r["native_result"]["actor_cached_succession"]["complete_cached_successor_ids"]
        assert r["queried_revision"] == expected and len(ids) == detail
        row.update(revision=expected, cache_count=len(ids), cache_ids=ids)
    elif kind == "event":
        assert r["current_event_instance_id"] == expected and r["event_definition_key"] == detail
        row.update(event_instance_id=expected, event_key=detail)
    elif kind == "select":
        assert s["status"] == "native_gameplay_postcondition_verified" and r["revision"] == expected
        row.update(revision=expected)
    else:
        checkpoint = r["checkpoint"]
        assert s["status"] == "native_gameplay_postcondition_verified" and checkpoint["status"] == "saved"
        row["checkpoint"] = {k: checkpoint[k] for k in ("path", "size", "sha256")}
        if detail:
            row["immutable_copy"] = preserve(detail, checkpoint)
    append(row)
print(json.dumps({"status": "R34_D2A_DONE_NATIVE_45", "request_count": len(steps)}, ensure_ascii=False))
