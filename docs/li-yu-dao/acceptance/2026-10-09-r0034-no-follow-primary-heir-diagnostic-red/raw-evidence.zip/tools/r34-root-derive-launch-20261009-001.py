from pathlib import Path
import hashlib
import json

B = Path("C:/workspace/ck3_lyd_runtime_20261004")
source = B / "r33-root-launch-diagnostic-20261009-001.py"
dest = B / "r34-root-launch-diagnostic-20261009-001.py"
raw = source.read_text(encoding="utf-8")
replacements = {
    "live-attempt-033": "live-attempt-034",
    "r33-root-steam-offline-recovery-20261009-001": "r34-root-steam-offline-recovery-20261009-001",
    "lyd-r0033-split-d2b-live-root": "lyd-r0034-no-follow-primary-heir-live-root",
    "lyd_r33_i3b_signed_B3_split_d2b_diagnostic": "lyd_r34_i3b_signed_B3_no_follow_flag_diagnostic",
    "--R0033": "--R0034",
    "lyd.r33.": "lyd.r34.",
    "R33 launch": "R34 launch",
}
for old, new in replacements.items():
    assert old in raw, old
    raw = raw.replace(old, new)
compile(raw, str(dest), "exec")
with dest.open("x", encoding="utf-8", newline="\n") as f:
    f.write(raw)
with (B / "r34-root-launch-derivation-20261009-001.json").open("x", encoding="utf-8") as f:
    json.dump({"source": source.as_posix(), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
               "dest": dest.as_posix(), "dest_sha256": hashlib.sha256(dest.read_bytes()).hexdigest(),
               "replacements": replacements}, f, ensure_ascii=False, indent=2)
    f.write("\n")
print(json.dumps({"dest": dest.as_posix(), "sha256": hashlib.sha256(dest.read_bytes()).hexdigest()}))
