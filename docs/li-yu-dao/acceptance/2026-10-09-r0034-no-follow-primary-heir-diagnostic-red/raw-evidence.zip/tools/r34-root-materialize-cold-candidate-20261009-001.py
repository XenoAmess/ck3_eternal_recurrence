"""Materialize immutable R34 cold inputs from retained R31 and split-D2b overlay."""
from pathlib import Path
import hashlib
import json
import shutil

B = Path("C:/workspace/ck3_lyd_runtime_20261004")
PRIOR = B / "live-attempt-031"
RUN = B / "live-attempt-034"
CANDIDATE = B / "r34-no-follow-primary-heir-overlay-sourceonly-20261009-001"
SOURCE_HEAD = "06159b964d859d30f2f07f4b183284df7d6dac47"
BASELINE_SHA = "c8601e7ba08406a551dcddd2a19e454423db2be6b559fad9985c6d1121b537c9"

def pin(path):
    h = hashlib.sha256()
    n = 0
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
            n += len(chunk)
    return {"path": path.as_posix(), "bytes": n, "sha256": h.hexdigest()}

def put(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")

assert PRIOR.is_dir() and CANDIDATE.is_dir() and not RUN.exists()
baseline = PRIOR / "userdir/save games/lyd_r31_i3b_signed_B3_diagnostic.ck3"
before = pin(baseline)
assert before["sha256"] == BASELINE_SHA and before["bytes"] == 91709349
manifest = json.loads((CANDIDATE / "CANDIDATE-MANIFEST.json").read_bytes())
assert manifest["source_production_head"] == SOURCE_HEAD and manifest["status"] == "SOURCE_ONLY_RUNTIME_NOT_RUN"
for row in manifest["files"]:
    src = PRIOR / "content/diagnostic_stage" / row["relative_path"]
    dst = CANDIDATE / row["relative_path"]
    assert pin(src)["sha256"] == row["source_sha256"]
    assert pin(dst)["sha256"] == row["candidate_sha256"] and pin(dst)["bytes"] == row["bytes"]
    assert (row["source_sha256"] != row["candidate_sha256"]) == row["changed"]

RUN.mkdir()
(RUN / "content").mkdir()
content = []
for name in ("production", "entry", "observer", "i4_single_event", "charter"):
    source = PRIOR / "content" / name
    dest = RUN / "content" / name
    shutil.copytree(source, dest)
    for src in sorted(p for p in source.rglob("*") if p.is_file()):
        dst = dest / src.relative_to(source)
        a, b = pin(src), pin(dst)
        assert a["bytes"] == b["bytes"] and a["sha256"] == b["sha256"]
        content.append({"role": name, "source": a, "copy": b})
dest = RUN / "content/diagnostic_stage"
dest.mkdir()
for row in manifest["files"]:
    src = CANDIDATE / row["relative_path"]
    dst = dest / row["relative_path"]
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    copy = pin(dst)
    assert copy["bytes"] == row["bytes"] and copy["sha256"] == row["candidate_sha256"]
    content.append({"role": "diagnostic_stage", "source": pin(src), "copy": copy})
userdir = RUN / "userdir"
(userdir / "mod").mkdir(parents=True)
(userdir / "save games").mkdir()
for name in ("pdx_settings.txt", "dlc_load.json", "tutorial.txt"):
    src = PRIOR / "userdir" / name
    dst = userdir / name
    shutil.copy2(src, dst)
    assert pin(src)["sha256"] == pin(dst)["sha256"]
registration = []
for src in sorted((PRIOR / "userdir/mod").glob("*.mod")):
    raw = src.read_bytes()
    assert raw.count(b"live-attempt-031") == 1
    dst = userdir / "mod" / src.name
    dst.write_bytes(raw.replace(b"live-attempt-031", b"live-attempt-034"))
    assert b"live-attempt-031" not in dst.read_bytes()
    registration.append(pin(dst))
save = userdir / "save games/lyd_r34_i3b_signed_B3_no_follow_flag_diagnostic.ck3"
shutil.copy2(baseline, save)
after = pin(save)
assert after["bytes"] == before["bytes"] and after["sha256"] == before["sha256"]
assert pin(baseline) == before
run_id = {
    "schema": "xar.ck3-live-run-identity.v1",
    "run_id": "bf-202609141645-5434332d4d--li-yu-dao--R0034",
    "execution_id": "51545453-f5a0-4492-88bd-c4597471e957",
    "machine_id": "bf-202609141645-5434332d4d",
    "mod_key": "li-yu-dao",
    "sequence": 34,
    "allocated_at_utc": "2026-10-09T00:53:00.596142+00:00",
    "allocator_pid": 27356,
    "legacy_alias": "R34",
}
put(RUN / "live-run-id.json", run_id)
receipt = {
    "schema": "lyd.r34.cold-candidate-materialized.v1",
    "status": "FILE_ONLY_NOT_LAUNCHED",
    "loaded_production_head": SOURCE_HEAD,
    "current_main_head_for_screen_task": None,
    "run_id": run_id,
    "original_baseline": before,
    "copied_baseline": after,
    "overlay_manifest": pin(CANDIDATE / "CANDIDATE-MANIFEST.json"),
    "content_file_count": len(content),
    "content": content,
    "registrations": registration,
    "settings": pin(userdir / "pdx_settings.txt"),
    "dlc_load": pin(userdir / "dlc_load.json"),
    "production71_modified": False,
    "game_launched": False,
    "profile_bound": False,
    "formal_acceptance": None,
    "whole_mod": "NOT_GREEN",
}
put(RUN / "COLD-MATERIALIZED.json", receipt)
print(json.dumps({"run": RUN.as_posix(), "run_id": run_id["run_id"], "content_file_count": len(content), "receipt": pin(RUN / "COLD-MATERIALIZED.json"), "game_launched": False}, ensure_ascii=False))
