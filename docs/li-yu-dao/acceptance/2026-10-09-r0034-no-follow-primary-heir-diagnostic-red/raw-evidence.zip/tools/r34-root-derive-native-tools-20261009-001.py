"""Derive R34 profile and MCP tools from archived R33 sources; no game input."""
from pathlib import Path
import hashlib
import json

B = Path("C:/workspace/ck3_lyd_runtime_20261004")
names = (
    "prepare-native-profile", "focus-game", "normal-exit-inventory", "bind-normal-exit-profile",
    "diagnostic-mcp-client", "queue-request", "focus-and-enqueue-attach", "read-sdk", "preserve-checkpoint",
)
rows = []
for name in names:
    source = B / f"r33-root-{name}-20261009-001.py"
    dest = B / f"r34-root-{name}-20261009-001.py"
    raw = source.read_text(encoding="utf-8")
    replacements = {
        "live-attempt-033": "live-attempt-034",
        "r33-root-steam-offline-recovery-20261009-001": "r34-root-steam-offline-recovery-20261009-001",
        "lyd-r0033-split-d2b-live-root": "lyd-r0034-no-follow-primary-heir-live-root",
        "r33-": "r34-",
        "lyd.r33.": "lyd.r34.",
        "R33": "R34",
    }
    for old, new in replacements.items():
        if old in raw:
            raw = raw.replace(old, new)
    compile(raw, str(dest), "exec")
    with dest.open("x", encoding="utf-8", newline="\n") as f:
        f.write(raw)
    rows.append({"source": source.as_posix(), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                 "dest": dest.as_posix(), "dest_sha256": hashlib.sha256(dest.read_bytes()).hexdigest(),
                 "replacements": replacements})
with (B / "r34-root-derived-native-tools-20261009-001.json").open("x", encoding="utf-8") as f:
    json.dump(rows, f, ensure_ascii=False, indent=2)
    f.write("\n")
print(json.dumps({"derived_count": len(rows), "destinations": [x["dest"] for x in rows]}))
