"""Read-only exact installed CK3 script occurrences for the tested flag."""
from pathlib import Path
import hashlib
import json

root = Path("C:/Program Files (x86)/Steam/steamapps/common/Crusader Kings III/game")
needle = b"set_always_follows_primary_heir"
rows = []
for path in root.rglob("*.txt"):
    if not path.is_file():
        continue
    raw = path.read_bytes()
    if needle in raw:
        lines = raw.decode("utf-8", errors="replace").splitlines()
        for i, line in enumerate(lines):
            if needle.decode() in line:
                rows.append({"path": path.relative_to(root).as_posix(), "line": i + 1,
                             "text": line.strip(), "file_sha256": hashlib.sha256(raw).hexdigest()})
out = {"schema": "lyd.r34.stock-follow-flag-occurrences.v1", "root": root.as_posix(), "occurrences": rows}
target = Path("C:/workspace/ck3_lyd_runtime_20261004/r34-stock-follow-flag-occurrences-20261009-001.json")
with target.open("x", encoding="utf-8", newline="\n") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
    f.write("\n")
print(json.dumps({"occurrence_count": len(rows), "rows": rows[:20]}, ensure_ascii=False))
