﻿name="Li Yu Dao R7 36x3 cultivation matrix fixture"
version="0.0.1-external"
supported_version="1.20.*"
tags={ "Utilities" }
path="C:/workspace/ck3_lyd_runtime_20261004/live-attempt-033/content/i4_single_event"
