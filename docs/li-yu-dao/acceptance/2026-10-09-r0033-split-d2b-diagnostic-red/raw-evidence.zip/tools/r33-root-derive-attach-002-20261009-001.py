from pathlib import Path
source = Path("C:/workspace/ck3_lyd_runtime_20261004/r33-root-focus-and-enqueue-attach-20261009-001.py")
dest = Path("C:/workspace/ck3_lyd_runtime_20261004/r33-root-focus-and-enqueue-attach-20261009-002.py")
raw = source.read_text(encoding="utf-8")
assert "diagnostic-mcp-queue-001/r33-attach-002.request.json" in raw
raw = raw.replace("diagnostic-mcp-queue-001/r33-attach-002.request.json", "diagnostic-mcp-queue-002/r33-attach-002.request.json")
raw = raw.replace("diagnostic-mcp-client-001/0001-r33-inventory-002.response.json", "diagnostic-mcp-client-002/0001-r33-inventory-002.response.json")
raw = raw.replace("native-attach-focus-001.json", "native-attach-focus-002.json")
compile(raw, str(dest), "exec")
with dest.open("x", encoding="utf-8", newline="\n") as f:
    f.write(raw)
print(dest)
