"""Derive R33 external launch/client tools from archived R32 sources with exact substitutions."""
from pathlib import Path
import hashlib
import json

B = Path("C:/workspace/ck3_lyd_runtime_20261004")
changes = {
    "r32-root-launch-diagnostic-20261009-001.py": (
        "r33-root-launch-diagnostic-20261009-001.py",
        {
            "live-attempt-032": "live-attempt-033",
            "r32-root-steam-offline-recovery-20261009-002": "r33-root-steam-offline-recovery-20261009-001",
            "lyd-r0032-pregrant-law-live-root": "lyd-r0033-split-d2b-live-root",
            "lyd_r32_i3b_signed_B3_pregrant_diagnostic": "lyd_r33_i3b_signed_B3_split_d2b_diagnostic",
            "--R0032": "--R0033",
            "lyd.r32.": "lyd.r33.",
            "R32 launch": "R33 launch",
        },
    ),
    "r32-root-diagnostic-mcp-client-20261009-001.py": (
        "r33-root-diagnostic-mcp-client-20261009-001.py",
        {
            "live-attempt-032": "live-attempt-033",
            "lyd.r32.": "lyd.r33.",
            "r32-": "r33-",
            "One R32": "One R33",
        },
    ),
}
out = []
for source_name, (dest_name, replacements) in changes.items():
    source = B / source_name
    dest = B / dest_name
    raw = source.read_text(encoding="utf-8")
    for old, new in replacements.items():
        assert old in raw, old
        raw = raw.replace(old, new)
    compile(raw, str(dest), "exec")
    with dest.open("x", encoding="utf-8", newline="\n") as f:
        f.write(raw)
    out.append({"source": str(source), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(), "dest": str(dest), "dest_sha256": hashlib.sha256(dest.read_bytes()).hexdigest(), "replacements": replacements})
with (B / "r33-root-derived-live-tools-20261009-001.json").open("x", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
    f.write("\n")
print(json.dumps(out, ensure_ascii=False))
