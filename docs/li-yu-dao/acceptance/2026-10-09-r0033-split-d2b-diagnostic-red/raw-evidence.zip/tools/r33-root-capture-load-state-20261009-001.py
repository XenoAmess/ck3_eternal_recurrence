from pathlib import Path
import hashlib
import json
from datetime import datetime, timezone
import psutil
import win32gui
import win32process
import pyautogui

run = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-033")
launch = json.loads((run / "launch.json").read_text(encoding="utf-8"))
obs = json.loads((run / "native-profile-process-observation-001.json").read_text(encoding="utf-8"))
pid, hwnd = launch["pid"], obs["windows"][0]["hwnd"]
assert psutil.Process(pid).create_time() == launch["process_create_time"]
assert win32gui.IsWindowVisible(hwnd) and win32process.GetWindowThreadProcessId(hwnd)[1] == pid
assert win32gui.GetForegroundWindow() == hwnd
image = run / "R33-LOAD-STATE-001.png"
pyautogui.screenshot().save(image)
raw = image.read_bytes()
with (run / "R33-LOAD-STATE-001.json").open("x", encoding="utf-8", newline="\n") as f:
    json.dump({"utc": datetime.now(timezone.utc).isoformat(), "pid": pid, "hwnd": hwnd, "foreground_hwnd": hwnd,
               "image": image.as_posix(), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
               "screen_size": list(pyautogui.size()), "input_sent": False}, f, indent=2)
    f.write("\n")
print(json.dumps({"image": image.as_posix(), "sha256": hashlib.sha256(raw).hexdigest()}))
