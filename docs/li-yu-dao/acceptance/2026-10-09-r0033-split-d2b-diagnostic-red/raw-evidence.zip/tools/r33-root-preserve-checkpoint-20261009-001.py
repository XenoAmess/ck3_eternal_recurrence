"""Copy an exact native checkpoint to an immutable R33 stage directory."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sys

run = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-033")
stage, expected = sys.argv[1:]
assert stage in {"D0", "D1", "D2a", "D21", "D22", "D23"} and len(expected) == 64
source = run / "userdir/save games/xar_checkpoint.ck3"
out = run / "checkpoints" / stage
assert not out.exists()
out.mkdir(parents=True)
target = out / "checkpoint.ck3"

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

before = source.stat()
assert digest(source) == expected.lower()
with target.open("xb") as receiver, source.open("rb") as sender:
    shutil.copyfileobj(sender, receiver, 1024 * 1024)
after = source.stat()
assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
assert digest(source) == digest(target) == expected.lower()
receipt = {"schema": "lyd.r33.diagnostic-stage-checkpoint-copy.v1", "utc": datetime.now(timezone.utc).isoformat(),
           "stage": stage, "source": source.as_posix(), "target": target.as_posix(),
           "bytes": target.stat().st_size, "sha256": expected.lower(), "source_stable_during_copy": True}
with (out / "COPY.actual.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(receipt, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(json.dumps(receipt, ensure_ascii=False))
