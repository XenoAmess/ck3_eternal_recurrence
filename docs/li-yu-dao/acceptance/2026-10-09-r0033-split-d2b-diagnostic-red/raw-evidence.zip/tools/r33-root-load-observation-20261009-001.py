from pathlib import Path
import json
from datetime import datetime, timezone
import psutil

run = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-033")
launch = json.loads((run / "launch.json").read_text(encoding="utf-8"))
process = psutil.Process(launch["pid"])
assert process.create_time() == launch["process_create_time"]
logs = {}
for name in ("debug.log", "error.log", "game.log", "system.log"):
    path = run / "userdir/logs" / name
    raw = path.read_bytes()
    logs[name] = {"bytes": len(raw), "modified_utc": datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat(),
                  "tail": raw.decode("utf-8", errors="replace").splitlines()[-20:]}
output = {"utc": datetime.now(timezone.utc).isoformat(), "pid": process.pid, "status": process.status(),
          "threads": process.num_threads(), "cpu_times": process.cpu_times()._asdict(), "memory": process.memory_info().rss,
          "logs": logs}
target = run / "R33-LOAD-OBSERVATION-001.json"
with target.open("x", encoding="utf-8", newline="\n") as f:
    json.dump(output, f, ensure_ascii=False, indent=2)
    f.write("\n")
print(json.dumps(output, ensure_ascii=False))
