"""Request ordinary close on the exact observed CK3 window after native exit source guard refused."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import time
import psutil
import win32gui
import win32process
from pywinauto import Desktop

run = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-033")
launch = json.loads((run / "launch.json").read_text(encoding="utf-8"))
obs = json.loads((run / "native-profile-process-observation-001.json").read_text(encoding="utf-8"))
failure = json.loads((run / "diagnostic-mcp-client-002/0022-r33-exit-context-001.sdk-result.json").read_text(encoding="utf-8"))
assert failure["isError"] is True and "pdx_settings.txt" in failure["content"][0]["text"]
pid, hwnd = launch["pid"], obs["windows"][0]["hwnd"]
p = psutil.Process(pid)
assert p.create_time() == launch["process_create_time"]
assert win32gui.IsWindowVisible(hwnd) and win32process.GetWindowThreadProcessId(hwnd)[1] == pid
element = Desktop(backend="uia").window(handle=hwnd)
assert element.wrapper_object().element_info.process_id == pid
settings = run / "userdir/pdx_settings.txt"
raw = settings.read_bytes()
record = {"schema": "lyd.r33.window-close-request.v1", "at_utc": datetime.now(timezone.utc).isoformat(),
          "pid": pid, "hwnd": hwnd, "process_create_time": p.create_time(),
          "native_exit_guard_error": failure["content"][0]["text"],
          "current_settings": {"path": settings.as_posix(), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()},
          "method": "pywinauto exact HWND close semantic", "keyboard_input_sent": False, "mouse_input_sent": False,
          "process_exit_verified": False}
with (run / "WINDOW-CLOSE-ATTEMPT-001.json").open("x", encoding="utf-8", newline="\n") as f:
    json.dump(record, f, ensure_ascii=False, indent=2)
    f.write("\n")
element.close()
time.sleep(2)
record["after_2_seconds"] = {"process_running": p.is_running(), "window_exists": win32gui.IsWindow(hwnd)}
with (run / "WINDOW-CLOSE-RESULT-001.json").open("x", encoding="utf-8", newline="\n") as f:
    json.dump(record, f, ensure_ascii=False, indent=2)
    f.write("\n")
print(json.dumps(record, ensure_ascii=False))
