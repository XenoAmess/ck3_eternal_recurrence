"""Atomically enqueue exactly one already frozen R33 native request."""
import hashlib
import json
import os
from pathlib import Path
import sys

run = Path("C:/workspace/ck3_lyd_runtime_20261004/live-attempt-033")
source = Path(sys.argv[1]).resolve()
suffix = sys.argv[2] if len(sys.argv) == 3 else "001"
assert suffix in {"001", "002"}
assert source.parent == run and source.name.startswith("r33-") and source.name.endswith(".source.json")
raw = source.read_bytes()
request = json.loads(raw)
assert set(request) == {"request_id", "operation", "name", "arguments"}
assert source.name == request["request_id"] + ".source.json"
target = run / ("diagnostic-mcp-queue-" + suffix) / (request["request_id"] + ".request.json")
assert target.parent.is_dir() and not target.exists()
os.link(source, target)
print(json.dumps({"queued": str(target), "sha256": hashlib.sha256(raw).hexdigest(), "contacted_game": False}))
