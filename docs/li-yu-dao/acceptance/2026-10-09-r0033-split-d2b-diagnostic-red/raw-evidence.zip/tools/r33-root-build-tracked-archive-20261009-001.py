"""Freeze a checked-in R33 RED report and extracted-byte-verified raw evidence ZIP."""
from pathlib import Path
import hashlib
import json
import zipfile

REPO = Path("C:/workspace/ck3_eternal_recurrence")
B = Path("C:/workspace/ck3_lyd_runtime_20261004")
RUN = B / "live-attempt-033"
OUT = REPO / "docs/li-yu-dao/acceptance/2026-10-09-r0033-split-d2b-diagnostic-red"
assert not OUT.exists() or (OUT.is_dir() and not any(OUT.iterdir()))
OUT.mkdir(parents=True, exist_ok=True)

def sha(path):
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
            size += len(block)
    return {"bytes": size, "sha256": h.hexdigest()}

def add_many(root, glob, prefix, files):
    for path in root.glob(glob):
        if path.is_file() and path.suffix.lower() != ".ck3":
            files[f"{prefix}/{path.relative_to(root).as_posix()}"] = path

files = {}
add_many(B / "r33-split-d2b-overlay-sourceonly-20261009-001", "**/*", "overlay", files)
add_many(B, "r33-root-*.py", "tools", files)
for path in (B / "r33-split-d2b-overlay-static-20261009-001.json", B / "r33-root-derived-live-tools-20261009-001.json", B / "r33-root-derived-profile-tools-20261009-001.json"):
    assert path.is_file()
    files["preparation/" + path.name] = path
for pattern in ("*.json", "*.source.json", "*.png", "*.txt"):
    add_many(RUN, pattern, "run", files)
for directory in ("diagnostic-mcp-client-001", "diagnostic-mcp-client-002", "native-profile-freeze-001", "native-evidence", "checkpoints"):
    add_many(RUN / directory, "**/*", "run/" + directory, files)
for name in ("pdx_settings.txt", "dlc_load.json", "tutorial.txt", "normal-exit-source-inventory-v1.json"):
    path = RUN / "userdir" / name
    assert path.is_file()
    files["run/userdir/" + name] = path
add_many(RUN / "userdir/mod", "*.mod", "run/userdir/mod", files)
for name in ("debug.log", "error.log", "game.log", "profile.log"):
    path = RUN / "userdir/logs" / name
    assert path.is_file()
    files["run/userdir/logs/" + name] = path
for name in ("OFFLINE-REVIEW.actual.json", "events.jsonl"):
    path = B / "r33-root-steam-offline-recovery-20261009-001" / name
    files["steam/prelaunch/" + name] = path
    path = B / "r33-root-steam-offline-final-20261009-001" / name
    files["steam/final/" + name] = path
for phase, dirname in (("prelaunch", "r33-root-steam-offline-recovery-20261009-001"), ("final", "r33-root-steam-offline-final-20261009-001")):
    add_many(B / dirname / "probe-1", "*", "steam/" + phase + "/probe-1", files)
for name in ("FINAL.json", "screen-lease.jsonl", "STOP.request"):
    path = B / "r33-root-screen-keeper-20261009-001" / name
    assert path.is_file()
    files["screen-lease/" + name] = path

assert len(files) == len(set(files))
for arc, path in files.items():
    assert path.is_file(), path
    assert not arc.endswith(".ck3")
    assert path.stat().st_size <= 20_000_000, (arc, path.stat().st_size)
entries = [{"archive_path": arc, "source_path": path.as_posix(), **sha(path)} for arc, path in sorted(files.items())]
external = []
for name, path in (
    ("signed_B3_original", B / "live-attempt-031/userdir/save games/lyd_r31_i3b_signed_B3_diagnostic.ck3"),
    ("signed_B3_R33_copy", RUN / "userdir/save games/lyd_r33_i3b_signed_B3_split_d2b_diagnostic.ck3"),
    ("D1_checkpoint", RUN / "checkpoints/D1/checkpoint.ck3"),
    ("D2a_checkpoint", RUN / "checkpoints/D2a/checkpoint.ck3"),
    ("autosave_exit", RUN / "userdir/save games/autosave_exit.ck3"),
):
    assert path.is_file(), name
    external.append({"role": name, "path": path.as_posix(), **sha(path), "tracked_zip_included": False})
assert external[0]["sha256"] == external[1]["sha256"] == "c8601e7ba08406a551dcddd2a19e454423db2be6b559fad9985c6d1121b537c9"
assert external[2]["sha256"] == "bcf63202867678f048ad3b7daacc2b9f0d8e73ffdedfd2074c0c977cdaa81492"
assert external[3]["sha256"] == "3f3272894935fdb347c5bfc8cc02c175313b3ed36c5e13fcd3a903e4e8f309b4"
game = json.loads((RUN / "game-original-handle-final.json").read_text(encoding="utf-8"))
assert game["returncode"] == 0 and game["pid"] == 17468
for suffix, seq, name, expected in (("D0", 4, "D0-cache-before-001", 45), ("D1", 12, "D1-cache-after-001", 45), ("D2a", 17, "D2a-cache-after-001", 45), ("D21", 19, "D21-cache-001", 45)):
    sdk = json.loads((RUN / "diagnostic-mcp-client-002" / f"{seq:04d}-r33-{name}.sdk-result.json").read_text(encoding="utf-8"))
    assert sdk["isError"] is False
    assert len(sdk["structuredContent"]["result"]["native_result"]["actor_cached_succession"]["complete_cached_successor_ids"]) == expected
assert json.loads((RUN / "diagnostic-mcp-client-002/0020-r33-D21-window-001.sdk-result.json").read_text(encoding="utf-8"))["isError"] is True
snap = json.loads((RUN / "diagnostic-mcp-client-002/0021-r33-D21-native-snapshot-001.sdk-result.json").read_text(encoding="utf-8"))
assert snap["isError"] is False and snap["structuredContent"]["snapshot"]["active_event"] is None
assert json.loads((RUN / "diagnostic-mcp-client-002/0022-r33-exit-context-001.sdk-result.json").read_text(encoding="utf-8"))["isError"] is True

index = {"schema": "lyd.r33.diagnostic-red-archive-index.v1", "status": "RED_DIAGNOSTIC_INCOMPLETE_SPLIT",
         "live_run_id": "bf-202609141645-5434332d4d--li-yu-dao--R0033", "source_production_head": "06159b964d859d30f2f07f4b183284df7d6dac47",
         "checkout_head_at_launch": "eeb156278331661252e3c9b7f63e6a882473f516", "evidence_entries": entries,
         "external_save_bodies": external, "production71_modified": False, "formal_acceptance_credit": False}
with (OUT / "INDEX.json").open("x", encoding="utf-8", newline="\n") as f:
    json.dump(index, f, ensure_ascii=False, indent=2)
    f.write("\n")

report = """# R0033 split-D2b native diagnostic — RED

The R33 source-only overlay split D2b into three intended event continuations: create the title/vassal transaction, change the new title holder, and resolve the transaction. Six diagnostic overlay files were pinned and statically validated; production's 71 files were not changed. The signed R31 B3 save was copied byte-for-byte into a new CK3 1.20.0.4 cold run.

Native cache observations were 45 at D0, 45 after D1 and its save, 45 after D2a and its save, and **45 immediately after the first D2b operation**, `create_title_and_vassal_change`. D1 and D2a checkpoint bodies are retained externally with exact SHA-256 in `INDEX.json`. The subsequent `lyd_factory_diag.21` event did not open: querying expected event instance 122 returned an active-event mismatch, and an independent native snapshot at revision 8 showed `active_event: null`. The overlay's intended continuation therefore failed; no R33 holder-change or resolve operation ran. This run narrows the 45→40 loss to an operation after transaction creation in the original atomic D2b path, but does not identify which later operation or prove that the transaction scope survived the event boundary.

The first bridge attach was attempted before the campaign finished loading and returned “native campaign has no bound played character”; that client was closed without retry. After the game visibly reached the paused campaign, a new client attached and verified native state. One copied R32 cache request used revision 4 before R33 had advanced past revision 3 and was rejected; a separately named request at the correct revision succeeded. Both failures and their exact request/result bytes are retained.

The frozen normal-exit source inventory was made while CK3 was loading. The game later changed `pdx_settings.txt`, so the official normal-exit context tool refused with “actual source bytes changed”. On the exact observed CK3 HWND, the OS window-close semantic opened CK3's own exit confirmation. The original 1920×1080 screenshot was reviewed, the pointer move verified the target region and foreground HWND, and `desktop_coordinate_map.py` clicked “退出到桌面” with a fresh receipt. The original CK3 process handle reported exit code 0; the SDK clients closed. A new post-exit desktop frame was visually reviewed and still showed Steam “离线模式”. The autosave_exit body is retained externally but is not treated as a valid continuation seed or as formal acceptance.

This is diagnostic RED. It grants **no** Phase I I3b, successful T cold reload, C3, I4, or whole-mod GREEN credit. Next run must determine why the event boundary loses the continuation (in particular the saved change scope and its trigger), then re-run from the signed B3 seed with a newly frozen profile and source inventory **after full campaign load**. Do not reuse this run's unfinished transaction as a baseline.

`raw-evidence.zip` preserves the exact diagnostic source, manifests, SDK requests/responses/receipts, screenshots, logs, screen lease, and offline reviews. `ARCHIVE-VALIDATION.actual.json` records extracted-byte verification. Save bodies remain in the outside runtime and are bound by size and SHA-256 in `INDEX.json`.
"""
with (OUT / "REPORT.md").open("x", encoding="utf-8", newline="\n") as f:
    f.write(report)

zip_path = OUT / "raw-evidence.zip"
with zipfile.ZipFile(zip_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for entry in entries:
        archive.write(files[entry["archive_path"]], entry["archive_path"])
with zipfile.ZipFile(zip_path, "r") as archive:
    assert sorted(archive.namelist()) == sorted(files)
    for entry in entries:
        data = archive.read(entry["archive_path"])
        assert len(data) == entry["bytes"] and hashlib.sha256(data).hexdigest() == entry["sha256"]
validation = {"schema": "lyd.r33.archive-extracted-byte-validation.v1", "result": "PASS",
              "entry_count": len(entries), "zip": {"path": zip_path.as_posix(), **sha(zip_path)},
              "index": {"path": (OUT / "INDEX.json").as_posix(), **sha(OUT / "INDEX.json")},
              "report": {"path": (OUT / "REPORT.md").as_posix(), **sha(OUT / "REPORT.md")},
              "save_bodies_retained_external": len(external)}
with (OUT / "ARCHIVE-VALIDATION.actual.json").open("x", encoding="utf-8", newline="\n") as f:
    json.dump(validation, f, ensure_ascii=False, indent=2)
    f.write("\n")
print(json.dumps(validation, ensure_ascii=False))
