from pathlib import Path
import hashlib
import json

B = Path("C:/workspace/ck3_lyd_runtime_20261004")
sources = (
    "r32-root-prepare-native-profile-20261009-001.py",
    "r32-root-focus-game-20261009-001.py",
    "r32-root-normal-exit-inventory-20261009-001.py",
    "r32-root-bind-normal-exit-profile-20261009-001.py",
)
rows = []
for name in sources:
    source = B / name
    destination = B / name.replace("r32-root-", "r33-root-")
    raw = source.read_text(encoding="utf-8")
    replacements = {
        "live-attempt-032": "live-attempt-033",
        "r32-root-steam-offline-recovery-20261009-002": "r33-root-steam-offline-recovery-20261009-001",
        "lyd-r0032-pregrant-law-live-root": "lyd-r0033-split-d2b-live-root",
        "R32": "R33",
    }
    if "normal-exit" in name or "bind-normal" in name:
        replacements["native-profile-freeze-002"] = "native-profile-freeze-001"
    for old, new in replacements.items():
        if old in raw:
            raw = raw.replace(old, new)
    compile(raw, str(destination), "exec")
    with destination.open("x", encoding="utf-8", newline="\n") as f:
        f.write(raw)
    rows.append({"source": source.as_posix(), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(), "dest": destination.as_posix(), "dest_sha256": hashlib.sha256(destination.read_bytes()).hexdigest(), "replacements": replacements})
with (B / "r33-root-derived-profile-tools-20261009-001.json").open("x", encoding="utf-8") as f:
    json.dump(rows, f, indent=2)
    f.write("\n")
print(json.dumps(rows))
