"""Source-only R33 overlay: yield after each D2b native instruction."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil

BASE = Path("C:/workspace/ck3_lyd_runtime_20261004")
SOURCE = BASE / "live-attempt-031/content/diagnostic_stage"
OUT = BASE / "r33-split-d2b-overlay-sourceonly-20261009-001"
EFFECT = Path("common/scripted_effects/lyd_i3b_commit_effects.txt")
EVENT = Path("events/lyd_factory_operation_diagnostic.txt")
TRIGGER = Path("common/scripted_triggers/lyd_factory_operation_diagnostic.txt")
LOCS = [Path("localization/english/lyd_factory_operation_diagnostic_l_english.yml"),
        Path("localization/simp_chinese/lyd_factory_operation_diagnostic_l_simp_chinese.yml")]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> str:
    raw = path.read_bytes()
    assert raw.startswith(b"\xef\xbb\xbf")
    return raw.decode("utf-8-sig").replace("\r\n", "\n")


def write(path: Path, value: str) -> None:
    path.write_bytes(b"\xef\xbb\xbf" + value.encode("utf-8"))


def replace_once(value: str, old: str, new: str) -> str:
    assert value.count(old) == 1, (old[:70], value.count(old))
    return value.replace(old, new, 1)


assert not OUT.exists()
shutil.copytree(SOURCE, OUT)
assert len([p for p in SOURCE.rglob("*") if p.is_file()]) == 6

effect = read(OUT / EFFECT)
old_d2 = """lyd_factory_diag_d2_effect = {
    create_title_and_vassal_change = { type = created save_scope_as = lyd_c3_head_change add_claim_on_loss = no }
    scope:new_title = {
        change_title_holder = { holder = root change = scope:lyd_c3_head_change }
    }
    resolve_title_and_vassal_change = scope:lyd_c3_head_change
    save_scope_value_as = { name = lyd_factory_diag_stage value = 2 }
    trigger_event = lyd_factory_diag.2
}
"""
new_d2 = """lyd_factory_diag_d21_effect = {
    create_title_and_vassal_change = { type = created save_scope_as = lyd_c3_head_change add_claim_on_loss = no }
    save_scope_value_as = { name = lyd_factory_diag_stage value = 21 }
    trigger_event = lyd_factory_diag.21
}

lyd_factory_diag_d22_effect = {
    scope:new_title = {
        change_title_holder = { holder = root change = scope:lyd_c3_head_change }
    }
    save_scope_value_as = { name = lyd_factory_diag_stage value = 22 }
    trigger_event = lyd_factory_diag.22
}

lyd_factory_diag_d23_effect = {
    resolve_title_and_vassal_change = scope:lyd_c3_head_change
    save_scope_value_as = { name = lyd_factory_diag_stage value = 2 }
    trigger_event = lyd_factory_diag.2
}
"""
effect = replace_once(effect, old_d2, new_d2)
write(OUT / EFFECT, effect)

triggers = read(OUT / TRIGGER)
triggers += """
lyd_factory_diag_open_change_trigger = {
    exists = scope:new_title
    exists = scope:lyd_c3_head_change
    scope:new_title = {
        var:lyd_c2_owned_head_title = 1
        var:lyd_c2_owner_faith = scope:lyd_c3_factory_faith
    }
}
"""
write(OUT / TRIGGER, triggers)


def event(number: int, target_effect: str) -> str:
    return f"""lyd_factory_diag.{number} = {{
    type = character_event
    theme = faith
    title = lyd_factory_diag_d{number}_title
    desc = lyd_factory_diag_d{number}_desc
    trigger = {{
        lyd_factory_diag_continue_trigger = {{ STAGE = {number} }}
        lyd_factory_diag_open_change_trigger = yes
    }}
    option = {{
        name = lyd_factory_diag_next
        trigger = {{
            lyd_factory_diag_continue_trigger = {{ STAGE = {number} }}
            lyd_factory_diag_open_change_trigger = yes
        }}
        hidden_effect = {{
            if = {{
                limit = {{
                    lyd_factory_diag_continue_trigger = {{ STAGE = {number} }}
                    lyd_factory_diag_open_change_trigger = yes
                }}
                {target_effect} = yes
            }}
        }}
    }}
}}

"""


events = read(OUT / EVENT)
events = replace_once(events, "                lyd_factory_diag_d2_effect = yes", "                lyd_factory_diag_d21_effect = yes")
events = replace_once(events, "lyd_factory_diag.2 = {", event(21, "lyd_factory_diag_d22_effect") + event(22, "lyd_factory_diag_d23_effect") + "lyd_factory_diag.2 = {")
write(OUT / EVENT, events)

en = read(OUT / LOCS[0])
en += " lyd_factory_diag_d21_title:0 \"D2b1: transaction opened, holder unchanged\"\n"
en += " lyd_factory_diag_d21_desc:0 \"DEVELOPMENT DIAGNOSTIC ONLY. Read native cache before any holder operation; transaction scope persistence is unverified.\"\n"
en += " lyd_factory_diag_d22_title:0 \"D2b2: title holder change requested, unresolved\"\n"
en += " lyd_factory_diag_d22_desc:0 \"DEVELOPMENT DIAGNOSTIC ONLY. Read native cache before resolve; transaction scope persistence is unverified.\"\n"
write(OUT / LOCS[0], en)
zh = read(OUT / LOCS[1])
zh += " lyd_factory_diag_d21_title:0 \"D2b1：仅开启 transaction，尚未授予\"\n"
zh += " lyd_factory_diag_d21_desc:0 \"仅开发诊断。授予前读取原生缓存；跨事件 transaction scope 尚未经实机证明。\"\n"
zh += " lyd_factory_diag_d22_title:0 \"D2b2：请求变更 holder，尚未 resolve\"\n"
zh += " lyd_factory_diag_d22_desc:0 \"仅开发诊断。resolve 前读取原生缓存；跨事件 transaction scope 尚未经实机证明。\"\n"
write(OUT / LOCS[1], zh)

rows = []
for path in sorted(OUT.rglob("*")):
    if path.is_file():
        src = SOURCE / path.relative_to(OUT)
        rows.append({"relative_path": path.relative_to(OUT).as_posix(), "source_sha256": sha(src),
                     "candidate_sha256": sha(path), "changed": src.read_bytes() != path.read_bytes(),
                     "bytes": path.stat().st_size})
assert [r["relative_path"] for r in rows if r["changed"]] == sorted([EFFECT.as_posix(), TRIGGER.as_posix(), EVENT.as_posix(), *(p.as_posix() for p in LOCS)])
manifest = {"schema": "lyd.r33.split-d2b-overlay-candidate.v1", "status": "SOURCE_ONLY_RUNTIME_NOT_RUN",
            "source_production_head": "06159b964d859d30f2f07f4b183284df7d6dac47",
            "source_diagnostic_run": "R0031", "candidate_purpose": "yield after create transaction, change holder, then resolve",
            "transaction_scope_persistence": "UNVERIFIED", "formal_I3b_credit": None, "files": rows}
with (OUT / "CANDIDATE-MANIFEST.json").open("x", encoding="utf-8", newline="\n") as target:
    json.dump(manifest, target, ensure_ascii=False, indent=2)
    target.write("\n")
print(json.dumps({"candidate": str(OUT), "changed_files": [r["relative_path"] for r in rows if r["changed"]],
                  "manifest_sha256": sha(OUT / "CANDIDATE-MANIFEST.json"), "game_started": False}, ensure_ascii=False))
