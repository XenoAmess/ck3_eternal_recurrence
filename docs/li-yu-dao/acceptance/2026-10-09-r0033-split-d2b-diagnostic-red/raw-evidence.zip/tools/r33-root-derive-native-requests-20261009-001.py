"""Copy exact R32 request intent to R33 for stages before split D2b."""
from pathlib import Path
import json

B = Path("C:/workspace/ck3_lyd_runtime_20261004")
old, run = B / "live-attempt-032", B / "live-attempt-033"
names = (
    "inventory-002", "attach-002", "D0-profile-001", "D0-cache-before-001", "D0-save-001", "D0-cache-after-001",
    "D1-window-001", "D1-cache-before-001", "D1-select-001", "D1-cache-after-001", "D1-save-001", "D1-stage-window-001",
    "D2a-cache-before-001", "D2a-select-001", "D2a-cache-after-001", "D2a-save-001", "D2a-stage-window-001",
    "D2b-select-001",
)
out=[]
for name in names:
    source = old / f"r32-{name}.source.json"
    payload = json.loads(source.read_text(encoding="utf-8"))
    assert payload["request_id"] == f"r32-{name}"
    payload["request_id"] = f"r33-{name}"
    dest = run / f"r33-{name}.source.json"
    with dest.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(payload, f, ensure_ascii=False, separators=(",", ":"))
        f.write("\n")
    out.append({"source": source.as_posix(), "dest": dest.as_posix(), "request": payload})
with (run / "R33-REQUEST-SOURCES.actual.json").open("x", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
    f.write("\n")
print(json.dumps({"request_count": len(out), "names": names}))
