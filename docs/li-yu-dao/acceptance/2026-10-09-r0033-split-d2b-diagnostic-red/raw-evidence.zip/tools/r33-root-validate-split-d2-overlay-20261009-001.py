"""Pure structural validation of the R33 experimental D2b split."""
import hashlib
import json
from pathlib import Path
import sys

repo = Path("C:/workspace/ck3_eternal_recurrence")
sys.path.insert(0, str(repo / "tools"))
from extract_auto_upgrade_buildings import Block, parse_clausewitz
sys.path.insert(0, str(repo / "mod_li_yu_dao/tools"))
import validate_static

base = Path("C:/workspace/ck3_lyd_runtime_20261004")
old = base / "live-attempt-031/content/diagnostic_stage"
new = base / "r33-split-d2b-overlay-sourceonly-20261009-001"
out = base / "r33-split-d2b-overlay-static-20261009-001.json"
assert not out.exists()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def body(path):
    data = path.read_bytes()
    assert data.startswith(b"\xef\xbb\xbf")
    return parse_clausewitz(data.decode("utf-8-sig"))


def single(block, key):
    values = [entry.value for entry in block.entries if entry.key == key]
    assert len(values) == 1, key
    return values[0]


def node(item):
    if isinstance(item, Block):
        return tuple((entry.key, entry.operator, node(entry.value)) for entry in item.entries)
    return item


old_effects = body(old / "common/scripted_effects/lyd_i3b_commit_effects.txt")
new_effects = body(new / "common/scripted_effects/lyd_i3b_commit_effects.txt")
old_d2 = single(old_effects, "lyd_factory_diag_d2_effect")
parts = []
stages = [(21, "create_title_and_vassal_change"), (22, "scope:new_title"), (23, "resolve_title_and_vassal_change")]
for number, operation in stages:
    effect = single(new_effects, f"lyd_factory_diag_d{number}_effect")
    keys = [entry.key for entry in effect.entries]
    assert keys == [operation, "save_scope_value_as", "trigger_event"]
    marker = effect.entries[1].value
    assert single(marker, "name") == "lyd_factory_diag_stage"
    assert single(marker, "value") == str(21 if number == 21 else 22 if number == 22 else 2)
    assert effect.entries[2].value == f"lyd_factory_diag.{21 if number == 21 else 22 if number == 22 else 2}"
    parts.append(effect.entries[0])
assert tuple((entry.key, entry.operator, node(entry.value)) for entry in parts) == tuple((entry.key, entry.operator, node(entry.value)) for entry in old_d2.entries[:3])
assert [entry.key for entry in old_d2.entries[3:]] == ["save_scope_value_as", "trigger_event"]
for entry in old_effects.entries:
    if entry.key != "lyd_factory_diag_d2_effect":
        assert node(single(new_effects, entry.key)) == node(entry.value), entry.key

old_triggers = body(old / "common/scripted_triggers/lyd_factory_operation_diagnostic.txt")
new_triggers = body(new / "common/scripted_triggers/lyd_factory_operation_diagnostic.txt")
for entry in old_triggers.entries:
    assert node(single(new_triggers, entry.key)) == node(entry.value)
new_guard = single(new_triggers, "lyd_factory_diag_open_change_trigger")
assert [entry.key for entry in new_guard.entries] == ["exists", "exists", "scope:new_title"]
assert new_guard.entries[0].value == "scope:new_title" and new_guard.entries[1].value == "scope:lyd_c3_head_change"

old_events = body(old / "events/lyd_factory_operation_diagnostic.txt")
new_events = body(new / "events/lyd_factory_operation_diagnostic.txt")
for entry in old_events.entries:
    if entry.key != "lyd_factory_diag.20":
        assert node(single(new_events, entry.key)) == node(entry.value), entry.key
for number, operation in ((21, "lyd_factory_diag_d22_effect"), (22, "lyd_factory_diag_d23_effect")):
    event = single(new_events, f"lyd_factory_diag.{number}")
    option = single(event, "option")
    guarded = single(single(option, "hidden_effect"), "if")
    assert node(single(event, "trigger")) == node(single(option, "trigger")) == node(single(guarded, "limit"))
    assert single(guarded, operation) == "yes"
    assert all(entry.key not in {"immediate", "after", "hidden"} for entry in event.entries)
old20 = single(old_events, "lyd_factory_diag.20")
new20 = single(new_events, "lyd_factory_diag.20")
assert node(single(old20, "trigger")) == node(single(new20, "trigger"))
assert single(single(single(single(new20, "option"), "hidden_effect"), "if"), "lyd_factory_diag_d21_effect") == "yes"

loc_keys = set()
for path in new.rglob("*.yml"):
    raw = path.read_bytes()
    assert raw.startswith(b"\xef\xbb\xbf")
    for line in raw.decode("utf-8-sig").splitlines()[1:]:
        matched = validate_static.LOC_ROW.fullmatch(line)
        assert matched is not None, (path, line)
        loc_keys.add(matched.group(1))
for number in (1, 20, 21, 22, 2, 3, 4, 5, 6):
    assert all(f"lyd_factory_diag_d{number}_{part}" in loc_keys for part in ("title", "desc"))
for path in new.rglob("*.txt"):
    body(path)
body(new / "descriptor.mod")

manifest = json.loads((new / "CANDIDATE-MANIFEST.json").read_text(encoding="utf-8"))
assert len(manifest["files"]) == 6 and sum(r["changed"] for r in manifest["files"]) == 5
for row in manifest["files"]:
    relative = row["relative_path"]
    assert digest(old / relative) == row["source_sha256"] and digest(new / relative) == row["candidate_sha256"]
result = {"schema": "lyd.r33.split-d2b-static-validation.v1", "status": "PASS_SOURCE_ONLY_RUNTIME_NOT_RUN",
          "manifest_sha256": digest(new / "CANDIDATE-MANIFEST.json"), "operation_AST_order_preserved": True,
          "source_six_files_verified": True, "changed_file_count": 5, "new_event_guard_topology_checked": True,
          "transaction_scope_persistence": "UNVERIFIED", "game_or_SDK_calls": 0, "formal_I3b_credit": None}
with out.open("x", encoding="utf-8", newline="\n") as target:
    json.dump(result, target, ensure_ascii=False, indent=2)
    target.write("\n")
print(json.dumps(result, ensure_ascii=False))
