from pathlib import Path
src = Path("C:/workspace/ck3_lyd_runtime_20261004/r33-root-capture-load-state-20261009-003.py")
dst = Path("C:/workspace/ck3_lyd_runtime_20261004/r33-root-capture-load-state-20261009-004.py")
raw = src.read_text(encoding="utf-8")
assert raw.count("R33-LOAD-STATE-003") == 2
raw = raw.replace("R33-LOAD-STATE-003", "R33-CLOSE-STATE-004")
compile(raw, str(dst), "exec")
with dst.open("x", encoding="utf-8", newline="\n") as f:
    f.write(raw)
print(dst)
