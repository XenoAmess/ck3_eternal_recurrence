import hashlib
import json
import shutil
from pathlib import Path

root = Path(__file__).resolve().parent
baseline = Path('C:/lr9s2/ck3_autonomous_player/native_bridge')
candidate = root / 'candidate/native_bridge'
candidate.mkdir(parents=True, exist_ok=False)
shutil.copytree(baseline / 'include', candidate / 'include')
targets = ['include/xar_bridge/normal_exit_map_v1.hpp', 'src/normal_exit_map_v1.cpp', 'src/normal_exit_map_request_v1.cpp', 'CMakeLists.txt']
reference = ['src/normal_exit_map_source_v1.cpp', 'include/xar_bridge/normal_exit_map_source_v1.hpp', 'src/normal_exit_map_pins_v1.inc', 'tests/normal_exit_map_contract_test.cpp']
before = root / 'before'
def record(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
manifest = []
for rel in targets + reference:
    src = baseline / rel
    dst = before / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    dst = candidate / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    manifest.append({'path': rel, **record(src), 'classification': 'target' if rel in targets else 'reference_unchanged'})
def edit(rel, old, new):
    p = candidate / rel
    raw = p.read_bytes()
    nl = '\r\n' if b'\r\n' in raw else '\n'
    text = raw.decode('utf-8').replace('\r\n', '\n')
    assert text.count(old) == 1, (rel, old[:100], text.count(old))
    p.write_bytes(text.replace(old, new).replace('\n', nl).encode('utf-8'))
hpp = targets[0]
cpp = targets[1]
request = targets[2]
edit(hpp, 'query_context = 0, prepare_confirmation = 1, confirm_desktop = 2,', 'query_context = 0, prepare_confirmation = 1, confirm_desktop = 2,\n  continue_preparation = 3,')
edit(hpp, 'std::array<NormalExitMapTargetV1, 3> targets{};', '// Actual lifetime CAS state: menu opener, confirmation opener, desktop confirmation.\n  // This is independent of this command\'s dispatches and never inferred from ACK.\n  std::array<bool, 3> stage_consumed{};\n  std::array<NormalExitMapTargetV1, 3> targets{};')
edit(hpp, 'std::array<NormalExitMapTargetV1, 3> queried_observations{};', 'std::array<NormalExitMapTargetV1, 3> queried_observations{};\n  std::array<bool, 3> queried_stage_consumed{};')
edit(hpp, '\nstruct NormalExitMapContextV1 {', '\n// Pure production gates used by the provider and portable regressions.\nstd::array<bool, 3> ReadNormalExitMapStageConsumptionV1(\n    const NormalExitMapSessionV1 &session) noexcept;\nbool NormalExitMapStageConsumptionMatchesQueryV1(\n    const NormalExitMapSessionV1 &session) noexcept;\nbool NormalExitMapContinuePreparationAdmittedV1(\n    const std::array<bool, 3> &consumed,\n    const std::array<NormalExitMapTargetV1, 3> &targets,\n    bool confirmation_visible) noexcept;\n\nstruct NormalExitMapContextV1 {')
edit(request, 'case NormalExitMapActionV1::confirm_desktop: return "confirm_desktop";', 'case NormalExitMapActionV1::confirm_desktop: return "confirm_desktop";\n  case NormalExitMapActionV1::continue_preparation: return "continue_preparation";')
edit(request, 'else if (action == "confirm_desktop") request.action = NormalExitMapActionV1::confirm_desktop;', 'else if (action == "confirm_desktop") request.action = NormalExitMapActionV1::confirm_desktop;\n    else if (action == "continue_preparation") request.action = NormalExitMapActionV1::continue_preparation;')
edit(request, 'std::string SerializeNormalExitMapObservationV1(', '''std::array<bool, 3> ReadNormalExitMapStageConsumptionV1(
    const NormalExitMapSessionV1 &session) noexcept {
  std::array<bool, 3> consumed{};
  for (std::size_t i = 0; i < consumed.size(); ++i)
    consumed[i] = session.claimed[i].load(std::memory_order_acquire);
  return consumed;
}

bool NormalExitMapStageConsumptionMatchesQueryV1(
    const NormalExitMapSessionV1 &session) noexcept {
  return ReadNormalExitMapStageConsumptionV1(session) == session.queried_stage_consumed;
}

bool NormalExitMapContinuePreparationAdmittedV1(
    const std::array<bool, 3> &consumed,
    const std::array<NormalExitMapTargetV1, 3> &targets,
    bool confirmation_visible) noexcept {
  if (consumed != std::array<bool, 3>{true, false, false} || confirmation_visible)
    return false;
  for (const auto &target : targets)
    if (!target.read_complete) return false;
  const auto &entry = targets[1];
  return entry.root_exists && entry.root_visible && entry.target_exists &&
      entry.target_visible && entry.target_enabled && entry.unique_target &&
      entry.dispatch_admitted && entry.target_vtable_rva != 0 &&
      !targets[2].root_visible;
}

std::string SerializeNormalExitMapObservationV1(''')
edit(request, 'json += ",\\\"targets\\\":[";', '''json += ",\\\"stage_consumed\\\":[";
  for (std::size_t i = 0; i < v.stage_consumed.size(); ++i) {
    if (i) json += ',';
    json += v.stage_consumed[i] ? "true" : "false";
  }
  json += "],\\\"targets\\\":[";''')
edit(cpp, 'add(session.claimed[i].load(std::memory_order_acquire));', 'session.queried_stage_consumed[i]=session.claimed[i].load(std::memory_order_acquire);\n    add(session.queried_stage_consumed[i]);')
edit(cpp, 's.queried_observations==census.observations;', 's.queried_observations==census.observations && NormalExitMapStageConsumptionMatchesQueryV1(s);')
edit(cpp, 'd.claim_latched=true; out.status=NormalExitMapStatusV1::dispatch_unknown_claimed;', 'd.claim_latched=true; out.stage_consumed=ReadNormalExitMapStageConsumptionV1(*ctx.session);\n  out.status=NormalExitMapStatusV1::dispatch_unknown_claimed;')
edit(cpp, 'out.targets=initial.observations; out.confirmation_visible=initial.observations[2].root_visible;', 'out.targets=initial.observations; out.confirmation_visible=initial.observations[2].root_visible;\n    out.stage_consumed=ReadNormalExitMapStageConsumptionV1(session);')
edit(cpp, 'if(initial.observations[2].dispatch_admitted) {', '''if(ctx.request.action==NormalExitMapActionV1::continue_preparation) {
      // Only the unsubmitted confirmation-opening stage can be continued.
      // A fresh signed query binds lifetime CAS bits and this exact census;
      // stage zero and the previous prepare claim are never replayed or cleared.
      if(!NormalExitMapContinuePreparationAdmittedV1(out.stage_consumed,
          initial.observations,out.confirmation_visible))
        return reject("fresh_consumed_menu_unsubmitted_entry_not_admitted");
      Census confirmation{};
      if(!DispatchStage(1,ctx,mailbox,stamp,env,dispatch,initial,confirmation)) return true;
      out.status=NormalExitMapStatusV1::confirmation_observed;
      out.confirmation_visible=true; out.reason="continued_official_resign_confirmation_freshly_observed";
      return true;
    }
    if(initial.observations[2].dispatch_admitted) {''')
(root / 'BASELINE.json').write_bytes((json.dumps({'source_head': '54457b371e947edb86903c2ebd578034f02695db', 'source_root': str(baseline), 'files': manifest}, indent=2) + '\n').encode())
for d in manifest:
    assert record(baseline / d['path']) == {k: d[k] for k in ['bytes', 'sha256']}
print(json.dumps({'candidate': str(candidate), 'baseline': str(root / 'BASELINE.json'), 'source_v1_unchanged': record(candidate / reference[0])}, indent=2))
