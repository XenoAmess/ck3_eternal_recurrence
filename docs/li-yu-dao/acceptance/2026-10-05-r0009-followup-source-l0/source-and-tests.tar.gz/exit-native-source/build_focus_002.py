from pathlib import Path
import hashlib
import json
import shutil
task_root = Path(__file__).resolve().parent
candidate = task_root / 'candidate/native_bridge'
focused = Path('C:/nec2')
focused.mkdir(exist_ok=False)
shutil.copytree(Path('C:/nec1/include'), focused / 'include')
shutil.copyfile(Path('C:/nec1/CMakeLists.txt'), focused / 'CMakeLists.txt')
for rel in ['src/normal_exit_map_request_v1.cpp', 'src/normal_exit_map_v1.cpp', 'src/normal_exit_map_pins_v1.inc', 'tests/normal_exit_map_continuation_v1_test.cpp']:
    target = focused / rel; target.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(candidate / rel, target)
inputs = {p.relative_to(focused).as_posix(): {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in focused.rglob('*') if p.is_file()}
(task_root / 'FOCUSED-INPUTS-002.json').write_bytes((json.dumps({'source_root': str(focused), 'inputs': inputs, 'scope': 'Pure request/stage gates and provider compilation only; serializer fixtures explicitly offline'}, indent=2) + '\n').encode())
source = (task_root / 'build_focus.py').read_text(encoding='utf-8')
source = source.replace("root / 'focused-build-001'", "root / 'focused-build-002'")
source = source.replace('C:/nec1b1', 'C:/nec2b2').replace("'C:/nec1'", "'C:/nec2'").replace("'FOCUSED-INPUTS.json'", "'FOCUSED-INPUTS-002.json'")
source = source.replace("run('ctest',", "run('serializer-query', [build / 'xar_ck3_normal_exit_map_continuation_v1_test.exe', '--serialize-query'])\nrun('serializer-continued-unknown', [build / 'xar_ck3_normal_exit_map_continuation_v1_test.exe', '--serialize-continued-unknown'])\nrun('ctest',")
exec(compile(source, str(task_root / 'executed-build-focus-002.py'), 'exec'))
