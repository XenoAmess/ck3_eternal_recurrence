#pragma once

#include "xar_bridge/game_contract.hpp"
#include "xar_bridge/raiktor_actual_truce_expiry_v1.hpp"
#if defined(XAR_CK3_ENABLE_H2743_PREACTION_EXISTING_TRUCE_CANDIDATE_V1)
#include "xar_bridge/h2743_preaction_existing_truce_v1.hpp"
#endif
#if defined(XAR_CK3_ENABLE_G2_M5_ALLIANCE_PROJECTION_PRIVATE_QUERY_V1)
#include "xar_bridge/marriage_candidate_alliance_projection_v1.hpp"
#include "xar_bridge/marriage_native_outcome_classifier_v1.hpp"
#include "xar_bridge/marriage_character_fertility_v1.hpp"
#endif
#if defined(XAR_CK3_WAR_EXIT_TERMS_OFFLINE_RE_TEST)
#include "xar_bridge/raiktor_surrender_truce_v1.hpp"
#endif

#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <vector>

namespace xar::ck3_11906 {

inline constexpr char kExecutableSha256[] =
    "2D00FF3101EF70B566F2FCBAE292F09263199C80E9DC8F139B82D7D96F83DB86";
inline constexpr char kCheckpointSaveName[] = "xar_checkpoint";

using SubmitCommand = bool (*)(void *manager, void *command,
                               std::uint32_t channel_flags);
using GetLocalPlayer = void *(*)(void *jomini_state);
using HandleSetPlayedCharacterEvent = void (*)(void *event);
using GetCurrentEvent = void *(*)(void *event_manager);
using IsPendingCharacterInteractionForCharacter = bool (*)(
    void *pending_interaction, void *character);
using ValidateReplyCharacterInteractionCommand = bool (*)(void *command);
using ContainsWarParticipant = bool (*)(void *participant_container,
                                        std::int32_t character_id);
using GetWarScore = std::int32_t (*)(void *war, void *war_score_context);
using GetWarScoreComponent = std::int32_t (*)(void *war,
                                              void *war_score_context);
using GetWarScoreSideComponent = std::int32_t (*)(
    void *war, bool side, void *war_score_context);
using GetWarScoreOccupationComponent = std::uint64_t (*)(
    void *war, bool side, void *war_score_context);
using GetWarScoreTickingComponent = std::int32_t (*)(
    void *war, bool side, void *war_score_context, bool mode);
using IsNativeComponentAlive = bool (*)(void *component);
using ReadSiegeFixedPoint = std::int64_t *(*)(void *siege,
                                              std::int64_t *output);
using GetSiegeDaysLeft = std::int32_t (*)(void *siege);
using ReadAssaultDailyProgress = std::int64_t *(*)(
    void *siege, std::int64_t *output, std::int32_t eligible_besiegers);
using GetAssaultDailyCasualties = std::int32_t (*)(void *siege);
using ValidateAssaultCommand = bool (*)(
    std::int32_t command_kind, std::int32_t played_character_id,
    std::int32_t siege_id, void *error_output);
using IsProvinceOccupied = bool (*)(void *province);
using GetProvinceInt32 = std::int32_t (*)(void *province);
using ResolveDefaultRaiseProvince = void *(*)(void *character);
using GetUnitState = std::int32_t (*)(void *unit);
using GetArmyCurrentSoldiers = std::int32_t (*)(
    const void *regiment_id_array, std::uint8_t flags);
using GetArmyMaximumSoldiers = std::int32_t (*)(void *army);
using GetArmyCommander = void *(*)(void *army);
using GetCommanderAdvantage = std::int32_t (*)(void *character,
                                               std::int32_t context,
                                               bool include_roll);
using GetProvinceTerrain = void *(*)(void *province);
using EvaluateRegimentStatsAtProvince = void *(*)(
    void *regiment, void *output, void *province);
using IsSpecialCombatRegiment = bool (*)(void *regiment);
using GetCharacterModifierAggregator = void *(*)(void *character);
using ReadCharacterModifier = std::int64_t *(*)(
    void *aggregator, std::int64_t *output, std::int32_t modifier_index,
    std::int32_t context_mode);
using GetCombatRules = void *(*)();
using GetCombatSideStrength = std::int32_t (*)(void *combat_side);
using GetCombatRegimentStrength = std::int32_t (*)(void *combat_regiment);
using ReadCombatHardSideModifier = std::int64_t *(*)(
    std::int64_t *output, void *combat_side, std::uint16_t modifier_enum);
using ReadCounterCurrentChunk = std::int64_t *(*)(
    const void *side_maa_entry, std::int64_t *output);
using ResolveCounterClasses = void (*)(
    void *countered_entries, void *countering_entries,
    void *output_by_counter_class, std::int64_t context_scale);
using GetCounterContextScale = std::int64_t *(*)(
    std::int64_t *output, void *countered_modifier_aggregator,
    void *countering_modifier_aggregator);
using GetKnightEffectivenessContext = void *(*)(void *character);
using ReadKnightEffectiveness = std::int64_t *(*)(
    std::int64_t *output, void *effectiveness_context,
    std::uint64_t mode);
using IsHoldingDefender = bool (*)(void *defender_owner,
                                   void *target_province);
using ConstructRaiseTroopsCommand = void *(*)(void *command,
                                              std::int32_t character_id,
                                              const void *raise_entry);
using ValidateRaiseTroopsCommand = bool (*)(void *command,
                                            void *validation_context);
using DestroyNativeCommand = void *(*)(void *command,
                                       std::int32_t delete_flags);
using GetArmyMoveMode = std::int32_t (*)(void *army, void *province,
                                        std::int32_t direct_target);
using CanCharacterUseCommandKind = bool (*)(void *character,
                                            std::int32_t command_kind);
using CanArmyUseMoveMode = bool (*)(void *army, std::int32_t move_mode);
using CanMoveArmy = bool (*)(std::int32_t command_kind, void *army,
                             std::int32_t move_mode);
using CanOrderCombatRetreat = bool (*)(void *combat, void *selected_army,
                                       void *error_sink);
using GetCombatRetreatRuleState = void *(*)();
using ResolveMoveOrigin = void *(*)(void *origin_context);
using ConstructMovePathContext = void *(*)(void *path_context, void *army);
using ConstructArmyMovePath = void *(*)(void *path_storage);
using BuildArmyMoveRoute = bool (*)(void *path_context, void *origin_province,
                                    void *target_province,
                                    std::int32_t route_kind,
                                    void *path_storage);
using ReadRouteTravelDuration = std::int64_t *(*)(
    void *unit, std::int64_t *output, const void *path_storage,
    void *origin_province);
using ReadRouteEdgeDuration = std::int64_t *(*)(
    void *unit, std::int64_t *output, std::int32_t route_index);
using ReadUnitRouteSpeed = std::int64_t *(*)(void *unit,
                                             std::int64_t *output);
using ValidateDisbandArmyCommand = bool (*)(
    std::int32_t command_kind, std::int32_t command_target_id,
    void *error_output);
using ValidateSplitArmyHalfCommand = bool (*)(
    std::int32_t command_kind, std::int32_t source_army_id,
    std::int32_t played_character_id, void *error_output);
using CreateMergeArmiesCommand = void *(*)();
using ValidateMergeArmiesCommand = bool (*)(void *command,
                                             void *error_output);
using GetCasusBelliTypeDatabase = void *(*)();
using GetCharacterInteractionDatabase = void *(*)();
using HashStableKey = std::int32_t (*)(void *context,
                                      const char *data,
                                      std::uint32_t size);
using LookupCharacterInteraction = void *(*)(void *database,
                                              std::int32_t key_hash);
using EvaluateCharacterInteractionCost = void (*)(
    const void *compiled_cost_block, const void *event_target_scope,
    std::int64_t *output_by_resource);
using LookupSchemeType = void *(*)(void *database, std::int32_t key_hash);
using LookupHookType = void *(*)(void *database, std::int32_t key_hash);
using EvaluateCasusBelli = bool (*)(void *casus_belli_type,
                                    void *attacker_character,
                                    void *defender_character,
                                    void *output_configurations,
                                    bool include_blocked,
                                    bool unknown_flag,
                                    void *evaluation_context);
using DestroyValidCasusBelliConfiguration = void (*)(void *configuration);
using ConstructCharacterInteractionContext = void *(*)(
    void *context, void *interaction, std::int32_t actor_character_id,
    std::int32_t recipient_character_id, void *extra_context,
    bool initialize_special_data);
using RedirectCharacterInteractionRoles = void (*)(
    void *interaction, std::int32_t *actor_character_id,
    std::int32_t *recipient_character_id,
    std::int32_t *secondary_actor_character_id,
    std::int32_t *secondary_recipient_character_id,
    std::int32_t *intermediary_character_id);
using ConstructCharacterInteractionContextAllRoles = void *(*)(
    void *context, void *interaction, std::int32_t actor_character_id,
    std::int32_t recipient_character_id,
    std::int32_t secondary_actor_character_id,
    std::int32_t secondary_recipient_character_id,
    std::int32_t intermediary_character_id, void *extra_context);
using CopyNativeIntArray = void (*)(void *destination, const void *source);
using AppendNativeIntArrayRange = void (*)(void *destination,
                                           std::int32_t insertion_index,
                                           const std::int32_t *begin,
                                           const std::int32_t *end);
using RefreshCharacterInteractionContext = void (*)(void *context,
                                                     bool refresh);
using FinalizeCharacterInteractionContext = void (*)(void *context);
using ValidateCharacterInteractionContext = bool (*)(void *context,
                                                      void *error_output);
using ReadCharacterInteractionAnswerScore = std::int64_t *(*)(
    void *context, std::int64_t *output);
using EvaluateCharacterInteractionTrigger = bool (*)(
    void *trigger, const void *event_target_scope);
using ConstructSendCharacterInteractionCommand = void *(*)(
    void *command, const void *context);
using DestroyCharacterInteractionContext = void (*)(void *context);
using DefaultConstructCharacterInteractionContext = void *(*)(void *context);
using ConstructWarResolutionInteractionContext = void (*)(void *context,
                                                           void *war,
                                                           bool attacker_victory);
using ConstructSpecialCharacterInteractionContext = void *(*)(
    void *context, std::uint8_t special_index,
    std::int32_t actor_character_id,
    std::int32_t recipient_character_id);
using ReadCharacterClaim = void *(*)(void *output, void *claimant,
                                     void *title);
using ConstructWarEffectContext = void *(*)(void *context);
using PopulateWarEffectContext = void (*)(void *context, void *war,
                                          bool unknown_flag);
using ConstructEffectPreviewCollector = void *(*)(void *collector);
using DestroyEffectPreviewCollector = void (*)(void *collector);
using TraverseLoadedEffect = void (*)(void *loaded_effect,
                                      void *effect_context,
                                      void *collector);
using DestroyEffectContextSubobject = void (*)(void *subobject);
using EvaluateTruceDurationDays = std::int32_t (*)(
    void *script_value, void *effect_context, void *evaluation_context);
using HasCharacterTruce = bool (*)(void *owner, void *toward);
using GetCharacterTruceEndDate = const void *(*)(void *owner, void *toward);
using GetCharacterPrimaryTitle = void *(*)(void *character);
using IsCharacterChildOf = bool (*)(void *child_character,
                                    void *parent_character);
using ReadMonthlyGoldIncome = std::int64_t *(*)(
    std::int64_t *output, void *character, void *optional_breakdown,
    void *evaluation_context);
using EvaluateCharacterInteractionAnswer = std::uint8_t (*)(
    void *context, std::uint8_t answer_mode, std::uint8_t flag,
    void *error_sink_a, void *error_sink_b);
using GetGlobalVariableContainer = void *(*)();
using GetScriptIdentifierTable = void *(*)();
using LookupScriptIdentifierId = std::int32_t *(*)(
    void *table, std::int32_t *output, const void *string_view);
using GetGenericValueTypeRegistry = void *(*)();
using ResolveGenericValueTypeName = const std::string *(*)(
    std::int32_t identifier);
using ResolveScriptIdentifierName = const std::string *(*)(
    void *table, std::int32_t identifier);
using IsEventTargetValid = bool (*)(const void *event_target);
using ResolveEventTargetObject = void *(*)(const void *event_target);
using IsCharacterHostile = bool (*)(void *left_character,
                                    void *right_character, bool mode);
using ArmyContactPredicate = bool (*)(void *army);
using ReadProvinceHolderCharacterId = std::int32_t *(*)(
    void *province, std::int32_t *output);
using CharacterImmediateLiege = void *(*)(void *character);
struct H2743NativeStringView64 {
  const char *data;
  std::int64_t size;
};
using H2743LookupScriptIdentifier = std::int32_t (*)(
    const H2743NativeStringView64 *);
using H2743ScriptIdentifierName = const std::string *(*)(std::int32_t);
using H2743CharacterGovernment = void *(*)(void *);
using CharacterRelationPredicate = bool (*)(void *left_character,
                                             void *right_character);
using CharacterProvincePredicate = bool (*)(void *character,
                                             void *province);

// Absolute addresses resolved only after the main executable matches the
// pinned 1.19.0.6 SHA-256. Tests may supply a small in-memory fixture instead.
struct Bindings {
  bool enabled = false;
  void **game_state_slot = nullptr;
  void **jomini_state_slot = nullptr;
  void *command_manager = nullptr;
  std::uintptr_t pause_primary_vtable = 0;
  std::uintptr_t pause_secondary_vtable = 0;
  std::uintptr_t set_speed_primary_vtable = 0;
  std::uintptr_t set_speed_secondary_vtable = 0;
  std::uintptr_t select_event_option_primary_vtable = 0;
  std::uintptr_t select_event_option_secondary_vtable = 0;
  std::uintptr_t ingame_interface_idler_vtable = 0;
  std::uintptr_t event_window_primary_vtable = 0;
  std::uintptr_t scheme_type_primary_vtable = 0;
  std::uintptr_t hook_type_primary_vtable = 0;
  std::uintptr_t auto_save_primary_vtable = 0;
  std::uintptr_t auto_save_secondary_vtable = 0;
  std::uintptr_t reply_character_interaction_primary_vtable = 0;
  std::uintptr_t reply_character_interaction_secondary_vtable = 0;
  std::uintptr_t war_white_peace_special_vtable = 0;
  std::uintptr_t raise_troops_primary_vtable = 0;
  std::uintptr_t raise_troops_secondary_vtable = 0;
  std::uintptr_t move_army_primary_vtable = 0;
  std::uintptr_t move_army_secondary_vtable = 0;
  std::uintptr_t disband_army_primary_vtable = 0;
  std::uintptr_t disband_army_secondary_vtable = 0;
  std::uintptr_t split_army_half_primary_vtable = 0;
  std::uintptr_t split_army_half_secondary_vtable = 0;
  std::uintptr_t merge_armies_primary_vtable = 0;
  std::uintptr_t merge_armies_secondary_vtable = 0;
  std::uintptr_t start_assault_primary_vtable = 0;
  std::uintptr_t start_assault_secondary_vtable = 0;
  std::uintptr_t stop_assault_primary_vtable = 0;
  std::uintptr_t stop_assault_secondary_vtable = 0;
  std::uintptr_t send_character_interaction_primary_vtable = 0;
  std::uintptr_t send_character_interaction_secondary_vtable = 0;
  std::uintptr_t war_declaration_vtable = 0;
  std::uintptr_t character_claim_vtable = 0;
  std::uintptr_t effect_preview_collector_vtable = 0;
  std::uintptr_t jomini_effect_vtable = 0;
  std::uintptr_t jomini_scripted_effect_vtable = 0;
  std::uintptr_t jomini_scripted_effect_template_vtable = 0;
  std::uintptr_t hidden_effect_vtable = 0;
  std::uintptr_t jomini_context_effect_vtable = 0;
  std::uintptr_t prestige_effect_vtable = 0;
  std::uintptr_t prestige_experience_effect_vtable = 0;
  std::uintptr_t piety_effect_vtable = 0;
  std::uintptr_t piety_experience_effect_vtable = 0;
  std::uintptr_t legitimacy_effect_vtable = 0;
  std::uintptr_t stress_impact_effect_vtable = 0;
  std::uintptr_t add_from_contribution_attackers_effect_vtable = 0;
  std::uintptr_t add_from_contribution_defenders_effect_vtable = 0;
  std::uintptr_t gold_transfer_effect_vtable = 0;
  std::uintptr_t truce_effect_vtable = 0;
  std::uintptr_t add_hook_effect_vtable = 0;
  std::uintptr_t add_hook_no_toast_effect_vtable = 0;
  std::uintptr_t add_hook_theocracy_approve_argument = 0;
  std::uintptr_t ai_unit_stack_vtable = 0;
  std::uintptr_t ai_subunit_stack_vtable = 0;
  std::uintptr_t ai_war_coordinator_vtable = 0;
  const std::int32_t *cb_prestige_factor_identifier_id = nullptr;
  void **pending_character_interaction_storage_slot = nullptr;
  void **character_storage_slot = nullptr;
  void **army_storage_slot = nullptr;
  void **army_internal_storage_slot = nullptr;
  void **regiment_storage_slot = nullptr;
  void **persistent_regiment_storage_slot = nullptr;
  void **combat_storage_slot = nullptr;
  void **battle_result_storage_slot = nullptr;
  void **battle_result_fallback_slot = nullptr;
  void **ai_war_coordinator_storage_slot = nullptr;
  void **ai_war_coordinator_fallback_slot = nullptr;
  void **siege_storage_slot = nullptr;
  void **contact_game_mode_slot = nullptr;
  void **trait_database_slot = nullptr;
  void **scheme_type_database_slot = nullptr;
  void **scheme_type_fallback_slot = nullptr;
  void **hook_type_database_slot = nullptr;
  void **hook_type_fallback_slot = nullptr;
  void *expected_generic_value_type_registry = nullptr;
  const std::string *generic_value_type_name_fallback = nullptr;
  const std::string *script_identifier_name_fallback = nullptr;
  GetGlobalVariableContainer *global_variable_container_accessor_slot =
      nullptr;
  void *valid_casus_belli_configuration_scratch = nullptr;
  std::size_t event_manager_offset = 0;
  std::size_t player_character_manager_offset = 0;
  std::size_t war_manager_offset = 0;
  std::size_t landed_title_manager_offset = 0;
  std::size_t arrange_marriage_interaction_offset = 0;
  std::size_t declare_war_interaction_offset = 0;
  SubmitCommand submit_command = nullptr;
  GetLocalPlayer get_local_player = nullptr;
  HandleSetPlayedCharacterEvent handle_set_played_character_event = nullptr;
  std::uintptr_t set_played_character_event_vtable = 0;
  GetCurrentEvent get_current_event = nullptr;
  IsPendingCharacterInteractionForCharacter
      is_pending_character_interaction_for_character = nullptr;
  ValidateReplyCharacterInteractionCommand
      validate_reply_character_interaction_command = nullptr;
  ContainsWarParticipant contains_war_participant = nullptr;
  GetWarScore get_war_score = nullptr;
  GetWarScoreComponent get_imprisonment_war_score = nullptr;
  GetWarScoreComponent get_battle_war_score_base = nullptr;
  GetWarScoreSideComponent get_battle_war_score_side = nullptr;
  GetWarScoreOccupationComponent get_occupation_war_score_side = nullptr;
  GetWarScoreTickingComponent get_ticking_war_score_side = nullptr;
  IsNativeComponentAlive is_native_component_alive = nullptr;
  ReadSiegeFixedPoint get_siege_progress = nullptr;
  ReadSiegeFixedPoint get_siege_total_work = nullptr;
  GetSiegeDaysLeft get_siege_days_left = nullptr;
  ReadAssaultDailyProgress read_assault_daily_progress = nullptr;
  GetAssaultDailyCasualties get_assault_daily_casualties = nullptr;
  ValidateAssaultCommand validate_start_assault_command = nullptr;
  ValidateAssaultCommand validate_stop_assault_command = nullptr;
  DestroyNativeCommand destroy_assault_command = nullptr;
  IsProvinceOccupied is_province_occupied = nullptr;
  GetProvinceInt32 get_province_fort_level = nullptr;
  GetProvinceInt32 get_province_garrison_size = nullptr;
  GetProvinceInt32 get_province_besieging_strength = nullptr;
  ResolveDefaultRaiseProvince resolve_default_raise_province = nullptr;
  GetUnitState get_unit_state = nullptr;
  GetArmyCurrentSoldiers get_army_current_soldiers = nullptr;
  GetArmyMaximumSoldiers get_army_maximum_soldiers = nullptr;
  GetArmyCommander get_army_commander = nullptr;
  GetCommanderAdvantage get_commander_advantage = nullptr;
  GetProvinceTerrain get_province_terrain = nullptr;
  EvaluateRegimentStatsAtProvince evaluate_regiment_stats_at_province =
      nullptr;
  IsSpecialCombatRegiment is_special_combat_regiment = nullptr;
  GetCharacterModifierAggregator get_character_modifier_aggregator = nullptr;
  ReadCharacterModifier read_character_modifier = nullptr;
  GetCombatRules get_combat_rules = nullptr;
  GetCombatSideStrength get_combat_side_strength = nullptr;
  GetCombatRegimentStrength get_combat_regiment_strength = nullptr;
  ReadCombatHardSideModifier read_combat_hard_side_modifier = nullptr;
  ReadCounterCurrentChunk read_counter_current_chunk = nullptr;
  ResolveCounterClasses resolve_counter_classes = nullptr;
  GetCounterContextScale get_counter_context_scale = nullptr;
  GetKnightEffectivenessContext get_knight_effectiveness_context = nullptr;
  ReadKnightEffectiveness read_knight_effectiveness = nullptr;
  IsHoldingDefender is_holding_defender = nullptr;
  const std::int32_t *commander_min_roll = nullptr;
  const std::int32_t *commander_max_roll = nullptr;
  const std::int32_t *knight_damage_per_prowess = nullptr;
  const std::int32_t *knight_toughness_per_prowess = nullptr;
  const std::int32_t *minimum_combat_width = nullptr;
  const std::int64_t *base_combat_width_ratio = nullptr;
  ConstructRaiseTroopsCommand construct_raise_troops_command = nullptr;
  ValidateRaiseTroopsCommand validate_raise_troops_command = nullptr;
  DestroyNativeCommand destroy_raise_troops_command = nullptr;
  GetArmyMoveMode get_army_move_mode = nullptr;
  CanCharacterUseCommandKind can_character_use_command_kind = nullptr;
  CanArmyUseMoveMode can_army_use_move_mode = nullptr;
  CanMoveArmy can_move_army = nullptr;
  CanOrderCombatRetreat can_order_combat_retreat = nullptr;
  GetCombatRetreatRuleState get_combat_retreat_rule_state = nullptr;
  const std::int32_t *minimum_days_before_manual_retreat = nullptr;
  ResolveMoveOrigin resolve_move_origin = nullptr;
  ConstructMovePathContext construct_move_path_context = nullptr;
  ConstructArmyMovePath construct_army_move_path = nullptr;
  BuildArmyMoveRoute build_army_move_route = nullptr;
  ReadUnitRouteSpeed read_unit_land_route_speed = nullptr;
  ReadUnitRouteSpeed read_unit_naval_route_speed = nullptr;
  ReadUnitRouteSpeed read_unit_current_edge_speed = nullptr;
  ReadRouteTravelDuration read_route_travel_duration = nullptr;
  ReadRouteEdgeDuration read_route_edge_duration = nullptr;
  DestroyNativeCommand destroy_move_army_command = nullptr;
  ValidateDisbandArmyCommand validate_disband_army_command = nullptr;
  ValidateSplitArmyHalfCommand validate_split_army_half_command = nullptr;
  DestroyNativeCommand destroy_split_army_half_command = nullptr;
  CreateMergeArmiesCommand create_merge_armies_command = nullptr;
  ValidateMergeArmiesCommand validate_merge_armies_command = nullptr;
  DestroyNativeCommand destroy_merge_armies_command = nullptr;
  GetCasusBelliTypeDatabase get_casus_belli_type_database = nullptr;
  GetCharacterInteractionDatabase get_character_interaction_database =
      nullptr;
  HashStableKey hash_stable_key = nullptr;
  LookupCharacterInteraction lookup_character_interaction = nullptr;
  EvaluateCharacterInteractionCost evaluate_character_interaction_cost =
      nullptr;
  LookupSchemeType lookup_scheme_type = nullptr;
  LookupHookType lookup_hook_type = nullptr;
  EvaluateCasusBelli evaluate_casus_belli = nullptr;
  DestroyValidCasusBelliConfiguration
      destroy_valid_casus_belli_configuration = nullptr;
  ConstructCharacterInteractionContext
      construct_character_interaction_context = nullptr;
  RedirectCharacterInteractionRoles redirect_character_interaction_roles =
      nullptr;
  ConstructCharacterInteractionContextAllRoles
      construct_character_interaction_context_all_roles = nullptr;
  CopyNativeIntArray copy_native_int_array = nullptr;
  AppendNativeIntArrayRange append_native_int_array_range = nullptr;
  RefreshCharacterInteractionContext
      refresh_character_interaction_context = nullptr;
  FinalizeCharacterInteractionContext
      finalize_character_interaction_context = nullptr;
  ValidateCharacterInteractionContext
      validate_character_interaction_context = nullptr;
  ReadCharacterInteractionAnswerScore
      read_character_interaction_answer_score = nullptr;
  EvaluateCharacterInteractionTrigger
      evaluate_character_interaction_trigger = nullptr;
  ConstructSendCharacterInteractionCommand
      construct_send_character_interaction_command = nullptr;
  DestroyCharacterInteractionContext
      destroy_character_interaction_context = nullptr;
  DefaultConstructCharacterInteractionContext
      default_construct_character_interaction_context = nullptr;
  ConstructWarResolutionInteractionContext
      construct_war_resolution_interaction_context = nullptr;
  ConstructSpecialCharacterInteractionContext
      construct_special_character_interaction_context = nullptr;
  ReadCharacterClaim read_character_claim = nullptr;
  ConstructWarEffectContext construct_war_effect_context = nullptr;
  PopulateWarEffectContext populate_war_effect_context = nullptr;
  ConstructEffectPreviewCollector construct_effect_preview_collector =
      nullptr;
  DestroyEffectPreviewCollector destroy_effect_preview_collector = nullptr;
  TraverseLoadedEffect traverse_loaded_effect = nullptr;
  DestroyEffectContextSubobject destroy_effect_context_118 = nullptr;
  DestroyEffectContextSubobject destroy_effect_context_array_row = nullptr;
  EvaluateTruceDurationDays evaluate_truce_duration_days = nullptr;
  HasCharacterTruce has_character_truce = nullptr;
  GetCharacterTruceEndDate get_character_truce_end_date = nullptr;
  GetCharacterPrimaryTitle get_character_primary_title = nullptr;
  IsCharacterChildOf is_character_child_of = nullptr;
  ReadMonthlyGoldIncome read_monthly_gold_income = nullptr;
  EvaluateCharacterInteractionAnswer evaluate_character_interaction_answer =
      nullptr;
  GetScriptIdentifierTable get_script_identifier_table = nullptr;
  LookupScriptIdentifierId lookup_script_identifier_id = nullptr;
  GetGenericValueTypeRegistry get_generic_value_type_registry = nullptr;
  ResolveGenericValueTypeName resolve_generic_value_type_name = nullptr;
  ResolveScriptIdentifierName resolve_script_identifier_name = nullptr;
  IsEventTargetValid is_event_target_valid = nullptr;
  ResolveEventTargetObject resolve_event_target_object = nullptr;
  IsCharacterHostile is_character_hostile = nullptr;
  ArmyContactPredicate is_army_empty_for_contact = nullptr;
  ArmyContactPredicate is_army_in_combat = nullptr;
  ReadProvinceHolderCharacterId read_province_holder_character_id = nullptr;
  CharacterImmediateLiege character_immediate_liege = nullptr;
  H2743LookupScriptIdentifier h2743_lookup_script_identifier = nullptr;
  H2743ScriptIdentifierName h2743_script_identifier_name = nullptr;
  H2743CharacterGovernment h2743_character_government = nullptr;
  CharacterRelationPredicate classify_contact_defender_by_holder = nullptr;
  CharacterProvincePredicate classify_contact_defender_fallback = nullptr;
};

using game::ActiveWarSnapshot;
using game::ArrangeMarriageChoice;
using game::ArrangeMarriageQueryDiagnostics;
using game::ArrangeMarriageValidationSample;
using game::ArmySnapshot;
using game::ArmyStrengthSnapshot;
using game::ArmyStrengthScopeRole;
using game::CombatArmyInputsSnapshot;
using game::CombatCandidateProvinceSnapshot;
using game::CombatCommanderContextSnapshot;
using game::CombatCommanderSnapshot;
using game::CombatEffectiveStatsSnapshot;
using game::CombatMaaTypeSnapshot;
using game::CombatObservationStatus;
using game::CombatRegimentSnapshot;
using game::CombatSimulationInputsRequest;
using game::CombatSimulationInputsSnapshot;
using game::OngoingCombatInputsSnapshot;
using game::DeclarableWarSnapshot;
using game::FixedPointValue;
using game::OneLifeSettlementSnapshot;
using game::PlayerWarSide;
using game::Snapshot;
using game::WarObjectiveProvinceState;
using game::WarTerminationOptionsSnapshot;
using game::WarTerminationTermsSnapshot;
using game::WarTerminationExitTermsSnapshot;
using game::DefenderDeJureExitTermsV1;
using game::PauseSubmitResult;
using game::ResumeSubmitResult;
using game::SetPlayedCharacterResult;

inline constexpr std::size_t kWarBoundRegimentCompositionRowCount = 7;

enum class WarBoundRegimentProvenance : std::uint8_t {
  unavailable = 0,
  war_bound_not_event_specific = 1,
};

struct WarBoundRegimentCurrentRow {
  std::int32_t current_army_regiment_id = -1;
  std::int32_t raised_carmy_id = -1;

  friend bool operator==(const WarBoundRegimentCurrentRow &,
                         const WarBoundRegimentCurrentRow &) = default;
};

struct WarBoundPersistentRegimentSnapshot {
  std::int32_t persistent_regiment_id = -1;
  std::int32_t bound_war_id = -1;
  bool war_keep_on_attacker_victory = false;
  std::array<WarBoundRegimentCurrentRow,
             kWarBoundRegimentCompositionRowCount>
      current_rows{};

  friend bool operator==(const WarBoundPersistentRegimentSnapshot &,
                         const WarBoundPersistentRegimentSnapshot &) =
      default;
};

struct WarBoundRegimentObservation {
  WarBoundRegimentProvenance provenance =
      WarBoundRegimentProvenance::unavailable;
  std::int32_t owner_character_id = -1;
  std::int32_t war_id = -1;
  std::vector<WarBoundPersistentRegimentSnapshot> regiments;

  friend bool operator==(const WarBoundRegimentObservation &,
                         const WarBoundRegimentObservation &) = default;
};

// Post-termination state of one full-generation ID frozen by
// WarBoundRegimentObservation. `destroyed` means that exact generation no
// longer resolves from the still-valid exact-build store; it does not mean
// merely that the WarID stopped resolving.
enum class FrozenWarBoundIdState : std::uint8_t {
  not_present = 0,
  unavailable = 1,
  destroyed = 2,
  still_alive = 3,
};

enum class FrozenWarBoundArmyRosterEvidence : std::uint8_t {
  not_present = 0,
  unavailable = 1,
  frozen_army_destroyed = 2,
  detached = 3,
  still_attached = 4,
};

enum class WarBoundRegimentCleanupStatus : std::uint8_t {
  unavailable = 0,
  destroyed = 1,
  still_alive = 2,
};

struct FrozenWarBoundCurrentCleanupSnapshot {
  std::int32_t current_army_regiment_id = -1;
  std::int32_t raised_carmy_id = -1;
  FrozenWarBoundIdState current_army_regiment_state =
      FrozenWarBoundIdState::not_present;
  FrozenWarBoundIdState raised_carmy_state =
      FrozenWarBoundIdState::not_present;
  FrozenWarBoundArmyRosterEvidence frozen_carmy_roster_evidence =
      FrozenWarBoundArmyRosterEvidence::not_present;

  friend bool operator==(const FrozenWarBoundCurrentCleanupSnapshot &,
                         const FrozenWarBoundCurrentCleanupSnapshot &) =
      default;
};

struct FrozenWarBoundPersistentCleanupSnapshot {
  std::int32_t persistent_regiment_id = -1;
  FrozenWarBoundIdState persistent_regiment_state =
      FrozenWarBoundIdState::unavailable;
  std::array<FrozenWarBoundCurrentCleanupSnapshot,
             kWarBoundRegimentCompositionRowCount>
      current_rows{};

  friend bool operator==(const FrozenWarBoundPersistentCleanupSnapshot &,
                         const FrozenWarBoundPersistentCleanupSnapshot &) =
      default;
};

struct FrozenWarBoundRegimentCleanupObservation {
  WarBoundRegimentProvenance provenance =
      WarBoundRegimentProvenance::unavailable;
  WarBoundRegimentCleanupStatus status =
      WarBoundRegimentCleanupStatus::unavailable;
  std::int32_t owner_character_id = -1;
  std::int32_t war_id = -1;
  std::vector<FrozenWarBoundPersistentCleanupSnapshot> regiments;

  friend bool operator==(const FrozenWarBoundRegimentCleanupObservation &,
                         const FrozenWarBoundRegimentCleanupObservation &) =
      default;
};

enum class ReadRaiktorSurrenderPrisonerReleasesResult : std::uint8_t {
  available = 0,
  requires_paused = 1,
  no_played_character = 2,
  war_not_found = 3,
  player_not_primary_attacker = 4,
  unsupported_casus_belli = 5,
  unavailable = 6,
};

// Exact, read-only PoW slice for raiktor_claim_cb attacker surrender.  Empty
// release_pairs is meaningful only after every participant and both primary
// title succession lists were decoded successfully.  The candidate lists are
// retained so a consumer can distinguish that proven empty set from an
// omitted or partial scan.
struct RaiktorSurrenderPrisonerReleaseObservation {
  std::int32_t war_id = -1;
  std::int32_t date_raw = 0;
  std::int32_t active_casus_belli_database_index = -1;
  std::string active_casus_belli_key;
  std::int32_t primary_attacker_character_id = -1;
  std::int32_t primary_defender_character_id = -1;
  std::int32_t claimant_character_id = -1;
  std::vector<std::int32_t> attacker_participant_ids;
  std::vector<std::int32_t> defender_participant_ids;
  std::vector<std::int32_t> attacker_release_candidate_ids;
  std::vector<std::int32_t> defender_release_candidate_ids;
  std::vector<game::WarExitPrisonerReleaseSnapshot> release_pairs;
  bool full_participant_scan = false;
  bool primary_and_first_three_successors_scanned = false;
  bool same_frame_stable = false;

  friend bool operator==(
      const RaiktorSurrenderPrisonerReleaseObservation &,
      const RaiktorSurrenderPrisonerReleaseObservation &) = default;
};

// Generic release_prisoners_of_war_effect candidate set for one active WarID.
// This is an effect-input observation, not proof that an exit was submitted or
// that any particular exit interaction is currently legal.  Empty pairs are
// meaningful only when both explicit scan flags and same_frame_stable are true.
struct WarPrisonerReleasePairsObservationV1 {
  std::int32_t war_id = -1;
  std::int32_t date_raw = 0;
  std::int32_t active_casus_belli_database_index = -1;
  std::string active_casus_belli_key;
  std::int32_t primary_attacker_character_id = -1;
  std::int32_t primary_defender_character_id = -1;
  std::vector<std::int32_t> attacker_participant_ids;
  std::vector<std::int32_t> defender_participant_ids;
  std::vector<std::int32_t> attacker_release_candidate_ids;
  std::vector<std::int32_t> defender_release_candidate_ids;
  std::vector<game::WarExitPrisonerReleaseSnapshot> release_pairs;
  bool full_participant_scan = false;
  bool primary_and_first_three_successors_scanned = false;
  bool same_frame_stable = false;

  friend bool operator==(const WarPrisonerReleasePairsObservationV1 &,
                         const WarPrisonerReleasePairsObservationV1 &) = default;
};

enum class ReadWarPrisonerReleasePairsResultV1 : std::uint8_t {
  available = 0,
  requires_paused = 1,
  no_played_character = 2,
  war_not_found = 3,
  player_not_participant = 4,
  unavailable = 5,
};

enum class ReadRaiktorSurrenderGoldResult : std::uint8_t {
  available = 0,
  requires_paused = 1,
  no_played_character = 2,
  war_not_found = 3,
  player_not_primary_attacker = 4,
  unsupported_casus_belli = 5,
  unavailable = 6,
};

// Exact, read-only primary gold slice for raiktor_claim_cb attacker
// surrender. The transfer is the unique final preview callback from the
// original visible attacker-defeat root. Current gold and the authoritative
// monthly-income evaluator are retained so a consumer cannot confuse formula
// inputs with the observed transfer.
struct RaiktorSurrenderGoldObservation {
  std::int32_t war_id = -1;
  std::int32_t date_raw = 0;
  std::int32_t active_casus_belli_database_index = -1;
  std::string active_casus_belli_key;
  std::int32_t primary_attacker_character_id = -1;
  std::int32_t primary_defender_character_id = -1;
  std::int32_t claimant_character_id = -1;
  game::WarExitCharacterFixedPointSnapshot attacker_current_gold;
  game::WarExitCharacterFixedPointSnapshot defender_current_gold;
  game::WarExitCharacterFixedPointSnapshot
      attacker_authoritative_monthly_gold_income;
  game::WarExitCharacterFixedPointSnapshot
      defender_authoritative_monthly_gold_income;
  game::WarExitGoldTransferSnapshot actual_transfer;
  bool exact_primary_transfer_observed = false;
  bool same_frame_stable = false;

  friend bool operator==(const RaiktorSurrenderGoldObservation &,
                         const RaiktorSurrenderGoldObservation &) = default;
};

enum class ReadRaiktorSurrenderPrestigeResult : std::uint8_t {
  available = 0,
  requires_paused = 1,
  no_played_character = 2,
  war_not_found = 3,
  player_not_primary_attacker = 4,
  unsupported_casus_belli = 5,
  unavailable = 6,
};

// Exact, read-only F/prestige slice for raiktor_claim_cb attacker surrender.
// cb_prestige_factor is the unique identifier-82 final row captured before
// 0x3380170 destroys its temporary variable container.  The prestige delta
// is the unique primary-attacker callback from that same visible-root
// traversal and must equal max(-10F, -1000).  Current prestige brackets each
// preview so a read-only traversal cannot silently mutate the observed state.
struct RaiktorSurrenderPrestigeObservation {
  std::int32_t war_id = -1;
  std::int32_t date_raw = 0;
  std::int32_t active_casus_belli_database_index = -1;
  std::string active_casus_belli_key;
  std::int32_t primary_attacker_character_id = -1;
  std::int32_t primary_defender_character_id = -1;
  std::int32_t claimant_character_id = -1;
  game::WarExitCharacterFixedPointSnapshot attacker_current_prestige;
  game::FixedPointValue cb_prestige_factor;
  game::WarExitCharacterFixedPointSnapshot attacker_prestige_delta;
  bool exact_factor_and_attacker_delta_observed = false;
  bool same_frame_stable = false;

  friend bool operator==(const RaiktorSurrenderPrestigeObservation &,
                         const RaiktorSurrenderPrestigeObservation &) =
      default;
};

enum class ReadRaiktorSurrenderFavorHookResult : std::uint8_t {
  available = 0,
  requires_paused = 1,
  no_played_character = 2,
  war_not_found = 3,
  player_not_primary_attacker = 4,
  unsupported_casus_belli = 5,
  unavailable = 6,
};

// Exact, read-only conditional favor-hook slice for raiktor_claim_cb
// attacker surrender.  claimant_distinct_from_attacker=false is an authored
// exact false and therefore performs no loaded-effect traversal.  The
// distinct branch traverses the original visible attacker-defeat root and
// accepts either one exact ordinary favor_hook row or a fully scanned empty
// result.  It never executes an effect or submits a command.
struct RaiktorSurrenderFavorHookObservation {
  std::int32_t war_id = -1;
  std::int32_t date_raw = 0;
  std::int32_t active_casus_belli_database_index = -1;
  std::string active_casus_belli_key;
  std::int32_t primary_attacker_character_id = -1;
  std::int32_t primary_defender_character_id = -1;
  std::int32_t claimant_character_id = -1;
  bool claimant_distinct_from_attacker = false;
  bool original_visible_root_traversed = false;
  bool conditional_favor_hook_applies = false;
  bool same_frame_stable = false;

  friend bool operator==(const RaiktorSurrenderFavorHookObservation &,
                         const RaiktorSurrenderFavorHookObservation &) =
      default;
};

// The generic registry hashes the process image once and passes an exact-match
// decision into the selected version adapter. False returns disabled bindings.
Bindings BindCurrentProcess(bool executable_matches) noexcept;

bool ReadSnapshot(const Bindings &bindings, Snapshot &output) noexcept;

// Reuses the active-war targeted-title hierarchy walker for one selected
// county claim before CWar exists. Returns its capital Province only when the
// full-generation TitleID resolves as a county; it neither builds nor sends a
// war declaration.
bool ReadClaimCountyObjectiveProvince(const Bindings &bindings,
                                      std::int32_t county_title_id,
                                      std::int32_t &province_id) noexcept;

// Reads the native default muster Province for a full-generation CharacterID.
// This does not construct or validate a raise command.
bool ReadDefaultRaiseProvince(const Bindings &bindings,
                              std::int32_t character_id,
                              std::int32_t &province_id) noexcept;

// Reuses the exact-build generation-bearing active-CWar resolver for the
// pending-interaction read-only mailbox. The caller supplies the already
// captured application-main game_state; no command or effect is executed.
bool ResolvePendingCharacterInteractionActiveWarV1(
    const Bindings &bindings, void *game_state, std::int32_t war_id,
    void *&output) noexcept;

using game::ReadArmyStrengthsResult;

// Paused, read-only aggregate for every public CUnit currently published by
// the same snapshot as a player, active-war ally or active-war enemy. The
// adapter generation-resolves CUnit -> CArmy -> every CRegiment, validates the
// public-ID identity predicate, checked-sums all fields and never queues a
// command. That predicate is not combat activity or participation eligibility.
ReadArmyStrengthsResult ReadArmyStrengths(
    const Bindings &bindings,
    std::vector<ArmyStrengthSnapshot> &output) noexcept;

// A paused, double-read local Province observation. It uses the existing
// objective-Province ABI but does not require objective membership and does
// not alter the shared objective snapshot budget or issue a game command.
game::ReadProvinceLocalSiegeResult ReadProvinceLocalSiege(
    const Bindings &bindings, std::int32_t province_id,
    game::WarObjectiveProvinceState &output) noexcept;

using game::ReadCombatSimulationInputsResult;

// Paused object-graph projection for one explicit hypothetical contact. The
// request supplies target/final-edge ProvinceIDs and two non-empty ArmyID
// partitions. The adapter revalidates one active-war coalition split in the
// same snapshot; it never depends on current routes, exports storage handles,
// applies combat transitions, advances date, or consumes CK3 RNG.
ReadCombatSimulationInputsResult ReadCombatSimulationInputs(
    const Bindings &bindings,
    const game::CombatSimulationInputsRequest &request,
    CombatSimulationInputsSnapshot &output) noexcept;

// pause-map is an idempotent action: it reports already_paused without adding
// a command, otherwise it submits the same 0x28-byte CPauseGameCommand shape
// used by CK3's own UI through the engine's locked command queue path.
PauseSubmitResult
SubmitPauseMap(const Bindings &bindings,
               Snapshot *observed_snapshot = nullptr) noexcept;

// resume-map is the inverse idempotent operation.  It is required for a
// freshly loaded headless map because changing the speed does not clear
// Jomini's paused bit.
ResumeSubmitResult
SubmitResumeMap(const Bindings &bindings,
                Snapshot *observed_snapshot = nullptr) noexcept;

// Rebinds the local player through CK3's own set_player_character event
// handler. This exact-build action is main-thread only and reports success
// only after the player-character manager resolves the requested live target.
SetPlayedCharacterResult SubmitSetPlayedCharacter(
    const Bindings &bindings, std::int32_t target_character_id) noexcept;

// Fixed public speeds 1..5 deliberately map to separate advertised gameplay
// steps.  CK3's native CSetGameSpeedCommand payload is zero based (0..4).
bool SubmitSetSpeed(const Bindings &bindings, std::int32_t speed) noexcept;

using game::SelectEventOptionResult;

// Selects a zero-based native option on the same current local-player event
// returned in Snapshot. The public select-event-option-1..N step is translated
// to this zero-based payload at the protocol boundary. CK3's executor performs
// the same 0 <= index < option_count check before dispatching the effect.
SelectEventOptionResult
SubmitSelectEventOption(const Bindings &bindings,
                        std::int32_t option_index) noexcept;

using game::SaveCheckpointResult;
using game::SaveCheckpointStatus;

// Queues CK3's own CAutoSaveCommand with the fixed short save name
// `xar_checkpoint`. The result confirms queue submission, not asynchronous
// disk completion; the caller can correlate date_raw and the save name with
// the produced save file.
SaveCheckpointResult SubmitSaveCheckpoint(const Bindings &bindings) noexcept;

using game::PendingInteractionReply;
using game::ReplyPendingInteractionResult;
using game::AcknowledgePendingInteractionResult;

// Replies to the first locally addressed and natively actionable CK3 character
// interaction exposed by Snapshot. CPendingCharacterInteraction's component ID
// is the int32 payload consumed by CReplyCharacterInteractionCommand;
// accept/reject are native enum values 0/1.
ReplyPendingInteractionResult SubmitReplyToPendingInteraction(
    const Bindings &bindings, PendingInteractionReply reply) noexcept;

// Acknowledges one exact generation-bearing auto-accept notification. This is
// deliberately a fixed enum-4 action rather than a generic reply surface. It
// fresh-reads the paused snapshot, re-resolves the complete pending ID and
// played Character, re-runs the exact local-route predicate, revalidates
// +0x5C6, and never treats the enum-4 validator's early true as legality.
AcknowledgePendingInteractionResult SubmitAcknowledgePendingInteraction(
    const Bindings &bindings, std::int32_t pending_interaction_id) noexcept;

using game::RaiseTroopsResult;

// Raises the played character's troops at CK3's own default rally province.
// The native constructor owns an internal allocation, so the bridge validates,
// queues (which clones synchronously), and destroys the stack command in the
// same order as the original UI path.
RaiseTroopsResult SubmitRaiseTroopsDefault(const Bindings &bindings) noexcept;

using game::MoveArmyResult;

MoveArmyResult SubmitMoveArmy(const Bindings &bindings,
                              std::int32_t army_id,
                              std::int32_t province_id) noexcept;

using game::PreviewMoveArmyResult;
using game::PreviewMoveArmyStatus;
using game::RouteContactHorizonRequest;
using game::RouteContactHorizonSnapshot;
using game::RouteContactHorizonStatus;

// Candidate only: this reader has no bridge command or policy consumer.  Its
// result must never grant a date or movement step by itself.
enum class PhysicalArmyInventoryStatusV1 {
  unavailable,
  requires_paused,
  partial,
  complete,
};

enum class PhysicalArmyWarSideV1 { allied, hostile, neutral };

// Observation only. These samples are deliberately outside the inventory
// value so they cannot affect its existing equality/completeness fences.
struct PhysicalArmyNoncanonicalSlotV1 {
  std::int32_t slot_index = -1;
  std::int32_t public_cunit_id = -1;
  std::int32_t raw_kind = -1;
  bool carmy_resolution_attempted = false;
  std::int32_t native_carmy_id = -1;
  bool carmy_resolved = false;
  std::int32_t canonical_cunit_id = -1;
  std::string_view reason = "not_rejected";
};

inline constexpr std::size_t kPhysicalArmyNoncanonicalSampleLimitV1 = 32;

struct PhysicalArmyInventoryScanDiagnosticsV1 {
  bool performed = false;
  std::int32_t date_raw = -1;
  std::int32_t war_id = -1;
  std::int32_t subject_army_id = -1;
  std::int32_t storage_capacity = -1;
  std::int32_t noncanonical_slots = 0;
  std::size_t sample_count = 0;
  bool truncated = false;
  std::array<PhysicalArmyNoncanonicalSlotV1,
             kPhysicalArmyNoncanonicalSampleLimitV1> samples{};

  void Record(const PhysicalArmyNoncanonicalSlotV1 &sample) noexcept {
    ++noncanonical_slots;
    if (sample_count == samples.size()) {
      truncated = true;
      return;
    }
    samples[sample_count++] = sample;
  }
};

struct PhysicalArmyInventoryDiagnosticsV1 {
  PhysicalArmyInventoryScanDiagnosticsV1 first_scan{};
  PhysicalArmyInventoryScanDiagnosticsV1 second_scan{};
};

struct PhysicalArmyInventoryRowV1 {
  ArmySnapshot army{};
  PhysicalArmyWarSideV1 war_side = PhysicalArmyWarSideV1::neutral;
  friend bool operator==(const PhysicalArmyInventoryRowV1 &,
                         const PhysicalArmyInventoryRowV1 &) = default;
};

// Private application-main source fence. Never serialize process addresses.
// Equality across the route reader prevents joining two equal-value scans
// from different storage generations.
struct PhysicalArmyInventorySourceV1 {
  std::uintptr_t game_state = 0;
  std::uintptr_t jomini_state = 0;
  std::uintptr_t game_data = 0;
  std::uintptr_t unit_storage = 0;
  std::uintptr_t unit_slots = 0;
  std::int32_t unit_capacity = -1;
  std::uintptr_t carmy_storage = 0;
  std::uintptr_t carmy_slots = 0;
  std::int32_t carmy_capacity = -1;
  std::uintptr_t character_storage = 0;
  std::uintptr_t character_slots = 0;
  std::int32_t character_capacity = -1;
  std::uintptr_t province_array = 0;
  std::int32_t province_count = -1;
  std::uintptr_t war_storage = 0;
  std::uintptr_t war_slots = 0;
  std::int32_t war_capacity = -1;
  std::uintptr_t native_war = 0;
  friend bool operator==(const PhysicalArmyInventorySourceV1 &,
                         const PhysicalArmyInventorySourceV1 &) = default;
};

struct PhysicalArmyInventoryV1 {
  PhysicalArmyInventoryStatusV1 status =
      PhysicalArmyInventoryStatusV1::unavailable;
  std::int32_t date_raw = -1;
  std::int32_t war_id = -1;
  std::int32_t subject_army_id = -1;
  std::int32_t storage_capacity = -1;
  std::int32_t slots_scanned = 0;
  std::int32_t empty_slots = 0;
  std::int32_t canonical_units = 0;
  std::int32_t invalid_id_slots = 0;
  std::int32_t noncanonical_slots = 0;
  std::int32_t unresolved_slots = 0;
  std::vector<std::int32_t> player_army_ids;
  std::vector<std::int32_t> allied_army_ids;
  std::vector<std::int32_t> hostile_army_ids;
  std::vector<std::int32_t> contact_hostile_army_ids;
  std::vector<std::int32_t> retreating_hostile_army_ids;
  std::vector<PhysicalArmyInventoryRowV1> units;
  PhysicalArmyInventorySourceV1 source{};
  friend bool operator==(const PhysicalArmyInventoryV1 &,
                         const PhysicalArmyInventoryV1 &) = default;
};

// Application-main-only, exact-build paused CUnit-storage scan.  Scans every
// slot, counts skipped candidates, classifies canonical units using the live
// CWar participant relation, and compares the physical hostile set with the
// published war row.  A malformed/ambiguous slot is always partial.  Two
// physical scans, three full snapshots and frozen source pointers must agree
// before `complete`.
PhysicalArmyInventoryStatusV1 ReadPhysicalArmyInventoryV1(
    const Bindings &bindings, std::int32_t war_id,
    std::int32_t subject_army_id,
    PhysicalArmyInventoryV1 &output,
    PhysicalArmyInventoryDiagnosticsV1 *diagnostics = nullptr) noexcept;
using game::ActualContactScopeRequest;
using game::ActualContactScopeSnapshot;
using game::ActualContactScopeStatus;
using game::BattleControlRequest;
using game::BattleControlSnapshot;
using game::BattleControlSnapshotStatus;
using game::CurrentBattleKnightRequestV1;
using game::CurrentBattleKnightSnapshotV1;
using game::BattleTransitionRequest;
using game::BattleTransitionSnapshot;
using game::BattleTransitionSnapshotStatus;
using game::BattleTerminalTransitionRequestV1;
using game::BattleTerminalTransitionSnapshotV1;
using game::BattleTerminalTransitionStatusV1;
using game::BattleTerminalAiMembershipStatusV1;
using game::BattleReinforcementAssignmentRequest;
using game::BattleReinforcementAssignmentSnapshot;
using game::BattleReinforcementAssignmentStatus;

// Runs CK3's own route planner into a temporary MovePath and copies its
// resolved ProvinceIDs before destroying that path. This never applies the
// planned route and never queues a command.
PreviewMoveArmyResult PreviewMoveArmy(const Bindings &bindings,
                                      std::int32_t army_id,
                                      std::int32_t province_id) noexcept;

// Main-thread-only exact-build reader.  Production calls this exclusively
// through RouteContactHorizonMailboxContextV1; the direct entry point exists
// for the deterministic native fixture.  It builds CK3-owned MovePath state,
// copies only atomic public IDs/dates, and never queues a command.
RouteContactHorizonStatus ReadRouteContactHorizon(
    const Bindings &bindings, const RouteContactHorizonRequest &request,
    RouteContactHorizonSnapshot &output) noexcept;

// Main-thread-only mirror of 0x2208320/0x2209450.  It reads the current
// Province stored arrays twice and never calls any join/create mutator.
ActualContactScopeStatus ReadActualContactScope(
    const Bindings &bindings, const ActualContactScopeRequest &request,
    ActualContactScopeSnapshot &output) noexcept;

// Main-thread-only, paused exact-build projection of the live CCombat reached
// through one controllable public CUnit.  The implementation samples the
// complete retained-entry graph twice and calls only the two read-only native
// strength leaves; it never refreshes, advances, finalizes or mutates combat.
BattleControlSnapshotStatus ReadBattleControlSnapshot(
    const Bindings &bindings, const BattleControlRequest &request,
    BattleControlSnapshot &output) noexcept;

// Main-thread-only, paused, double-sampled read of the exact knight/regiment
// pair selected from a same-frame battle-control projection.  Returns typed
// unavailable on any identity, generation, helper, or sample drift.
bool ReadCurrentBattleKnightV1(
    const Bindings &bindings, const Snapshot &same_frame_world,
    const BattleControlSnapshot &same_frame_battle,
    const CurrentBattleKnightRequestV1 &request,
    CurrentBattleKnightSnapshotV1 &output) noexcept;

// Main-thread-only, paused lifecycle query addressed directly by one positive
// full-generation CombatID. It samples the retained CCombat projection twice,
// calls no native function, and has no selected-Army or retreat-legality gate.
BattleTransitionSnapshotStatus ReadBattleTransitionSnapshot(
    const Bindings &bindings, const BattleTransitionRequest &request,
    BattleTransitionSnapshot &output) noexcept;

// Main-thread-only, paused composition of the passive terminal journal with
// the current full-generation Combat/Province/CUnit graph. It samples the
// complete semantic frame twice and never calls a finalizer, row writer,
// contact resolver, AI lifecycle function or combat constructor.
BattleTerminalTransitionStatusV1 ReadBattleTerminalTransitionV1(
    const Bindings &bindings, const Snapshot &same_frame_world,
    const BattleTerminalTransitionRequestV1 &request,
    BattleTerminalTransitionSnapshotV1 &output) noexcept;

// Main-thread-only, paused exact-build projection of one AI-managed CUnit's
// stored help signal, assignment target, committed route/ETA and present-time
// compatible combats. It never runs an AI update, contact resolver or combat
// mutator.
BattleReinforcementAssignmentStatus ReadBattleReinforcementAssignmentV1(
    const Bindings &bindings, const Snapshot &same_frame_world,
    const BattleReinforcementAssignmentRequest &request,
    BattleReinforcementAssignmentSnapshot &output) noexcept;

using game::DisbandArmyResult;

DisbandArmyResult SubmitDisbandArmy(const Bindings &bindings,
                                    std::int32_t army_id) noexcept;

using game::SplitArmyHalfResult;

// Resolves the public generation-bearing CUnit ID to its internal CArmyID,
// passes the current played CharacterID through CK3's complete Split Half
// validator, queues the 0x30-byte player command, then destroys the stack
// object after the queue wrapper has synchronously cloned it. Submission is
// not a claim that the next snapshot already contains the sibling CUnit.
SplitArmyHalfResult SubmitSplitArmyHalf(const Bindings &bindings,
                                        std::int32_t army_id) noexcept;

using game::MergeArmiesResult;

// Uses the original heap constructor and native range-copy helper to build a
// one-source CMergeUnitsCommand. Both IDs are public generation-bearing CUnit
// IDs; CK3's complete validator owns province/combat/movement/siege gates.
// Submission preserves destination identity but is not an immediate outcome
// claim: a later paused snapshot must prove that the source disappeared.
MergeArmiesResult SubmitMergeArmies(const Bindings &bindings,
                                    std::int32_t destination_army_id,
                                    std::int32_t source_army_id) noexcept;

using game::StartAssaultResult;
using game::StopAssaultResult;

// These commands contain only player kind, full-generation played
// CharacterID and full-generation SiegeID. Queue acceptance is a typed ACK;
// applied/complete remains a later paused-snapshot postcondition.
StartAssaultResult SubmitStartAssault(const Bindings &bindings,
                                      std::int32_t siege_id) noexcept;
StopAssaultResult SubmitStopAssault(const Bindings &bindings,
                                    std::int32_t siege_id) noexcept;

using game::ReadDeclarableWarsResult;

// Runs CK3's own CB evaluator against one explicit target. This is the cheap
// path for a planner that already knows a CharacterID. The global overload is
// intentionally separate because scanning every live Character is a much
// heavier strategic query and should not run on every heartbeat snapshot.
ReadDeclarableWarsResult ReadDeclarableWarsForTarget(
    const Bindings &bindings, std::int32_t target_character_id,
    std::vector<DeclarableWarSnapshot> &output) noexcept;

bool ReadDeclarableWars(
    const Bindings &bindings,
    std::vector<DeclarableWarSnapshot> &output) noexcept;

using game::DeclareWarResult;

// Re-runs native enumeration and requires an exact match of every choice
// field before constructing CSendCharacterInteractionCommand. Queue cloning
// is synchronous; both the copied command context and the original temporary
// context are destroyed after submission in CK3's native order.
DeclareWarResult SubmitDeclareWar(
    const Bindings &bindings,
    const DeclarableWarSnapshot &declaration) noexcept;

using game::ReadArrangeMarriageChoicesResult;

// Explicit strategic query; it is intentionally not part of the heartbeat
// snapshot. Every returned candidate has passed CK3's own arrange-marriage
// context refresh/finalize/validation chain for the currently played
// Character. Minors naturally produce a betrothal through the same native
// interaction.
ReadArrangeMarriageChoicesResult ReadArrangeMarriageChoices(
    const Bindings &bindings,
    std::vector<ArrangeMarriageChoice> &output,
    ArrangeMarriageQueryDiagnostics &diagnostics) noexcept;

using game::ArrangeMarriageFamilyCandidateV1;
using game::ReadArrangeMarriageFamilyCandidatesResultV1;
// Unadvertised, read-only family query. The subject comes from an independent
// same-revision public campaign-root observation; every row passes the exact
// native five-role Can Send and final responder-answer calls.
ReadArrangeMarriageFamilyCandidatesResultV1
ReadArrangeMarriageFamilyCandidatesV1(
    const Bindings &bindings, std::int32_t subject_character_id,
    std::vector<ArrangeMarriageFamilyCandidateV1> &output,
    ArrangeMarriageQueryDiagnostics &diagnostics) noexcept;

#if defined(XAR_CK3_ENABLE_G2_M5_ALLIANCE_PROJECTION_PRIVATE_QUERY_V1)
enum class MarriageCandidateAlliancePrivateFailureV1 : std::uint8_t {
  none = 0,
  binding_unavailable,
  frame_changed,
  identity_changed,
  role_changed,
  final_legality_changed,
  projection_unavailable,
  outcome_unavailable,
  heir_relationship_unavailable,
  lineage_unavailable,
  sex_selector_unavailable,
  selected_option_unavailable,
  generic_cost_unavailable,
};

struct MarriageCharacterLineageV1 {
  std::int32_t house_id = -1;
  std::int32_t dynasty_id = -1;

  friend bool operator==(const MarriageCharacterLineageV1 &,
                         const MarriageCharacterLineageV1 &) = default;
};

struct MarriageHeirRelationshipV1 {
  std::int32_t betrothed_character_id = -1;
  std::int32_t primary_spouse_character_id = -1;
  std::vector<std::int32_t> spouse_character_ids{};

  friend bool operator==(const MarriageHeirRelationshipV1 &,
                         const MarriageHeirRelationshipV1 &) = default;
};

enum class CurrentFirstHeirRelationshipFailureV1 : std::uint8_t {
  none = 0,
  frame_changed,
  heir_unavailable,
  relationship_unavailable,
  partner_unavailable,
  bilateral_inconsistent,
};

struct CurrentFirstHeirBetrothalActionabilityReadV1 {
  bool has_betrothal = false;
  std::string_view unavailable_reason = "relationship_unavailable";
  std::int32_t actor_character_id = -1;
  std::int32_t heir_character_id = -1;
  std::int32_t partner_character_id = -1;
  std::int32_t recipient_character_id = -1;
  std::int32_t intermediary_character_id = -1;
  bool adult_readback_available = false;
  bridge::MarriageNativeOutcomeDetailsV1 adult{};
  bool final_legality_sampled = false;
  bool complete_can_send = false;
  bool recipient_acceptance_ready = false;
  std::int64_t recipient_ai_accept_raw = 0;
  std::uint8_t recipient_answer_status_raw = 3;
  bool generic_costs_available = false;
  std::array<std::int64_t, bridge::kMarriageGenericCostResourceCountV1>
      generic_cost_raw{};
  bool outcome_available = false;
  bool lineality_available = false;
  bool effective_matrilineal_if_accepted = false;
  friend bool operator==(const CurrentFirstHeirBetrothalActionabilityReadV1 &,
                         const CurrentFirstHeirBetrothalActionabilityReadV1 &) = default;
};

struct CurrentFirstHeirRelationshipReadV1 {
  CurrentFirstHeirRelationshipFailureV1 failure =
      CurrentFirstHeirRelationshipFailureV1::heir_unavailable;
  std::int32_t heir_character_id = -1;
  MarriageHeirRelationshipV1 relationship{};
  CurrentFirstHeirBetrothalActionabilityReadV1 betrothal_actionability{};
};

// Independent current relation read for the same-revision public first heir.
// Empty family data is a valid empty relation; failed identity or reciprocity
// is never reported as an empty relation.
CurrentFirstHeirRelationshipReadV1 ReadCurrentFirstHeirRelationshipV1(
    const Bindings &bindings, std::int32_t heir_character_id) noexcept;

// Application-main only. Evaluates exactly the independently observed current
// betrothed pair, including a real negative Can Send; it never scans candidates
// or creates an action proof/command.
CurrentFirstHeirBetrothalActionabilityReadV1
ReadCurrentFirstHeirBetrothalActionabilityV1(
    const Bindings &bindings, const CurrentFirstHeirRelationshipReadV1 &relationship,
    const bridge::MarriageNativeOutcomeClassifierEnvironmentV1 &outcome_environment,
    const bridge::MarriageCandidateAllianceProjectionEnvironmentV1 &option_environment) noexcept;

enum class PlayerChildMarriageSubjectFailureV1 : std::uint8_t {
  none = 0,
  frame_changed,
  subject_unavailable,
  not_player_child,
  relationship_unavailable,
  lineage_unavailable,
  employer_unavailable,
};

struct PlayerChildMarriageSubjectReadV1 {
  PlayerChildMarriageSubjectFailureV1 failure =
      PlayerChildMarriageSubjectFailureV1::subject_unavailable;
  std::int32_t played_character_id = -1;
  std::int32_t subject_character_id = -1;
  std::int16_t adult_measure_raw = 0;
  MarriageCharacterLineageV1 lineage{};
  std::int32_t employer_character_id = -1;
  MarriageHeirRelationshipV1 relationship{};
};

// Private, bounded ABI diagnostic. These offsets are observations only; no
// slot is treated as a child list or as proposal authority.
struct PlayerFamilyArrayProbeSlotV1 {
  std::uint32_t offset = 0;
  bool header_readable = false;
  bool data_pointer_present = false;
  std::int32_t capacity = -1;
  std::int32_t count = -1;
  bool native_int_array_shape = false;
  bool sample_readable = false;
  std::vector<std::int32_t> sample_ids;
  std::vector<bool> sample_generation_valid;
};

struct PlayerFamilyArrayProbeV1 {
  bool available = false;
  std::int32_t played_character_id = -1;
  bool spouse_readable = false;
  std::int32_t primary_spouse_character_id = -1;
  std::vector<PlayerFamilyArrayProbeSlotV1> slots;
};

PlayerFamilyArrayProbeV1 ReadPlayerFamilyArrayProbeV1(
    const Bindings &bindings, std::int32_t played_character_id) noexcept;

// Exact-build read for one caller-specified child of the currently played
// character. The caller still needs the native five-role Can Send/final-answer
// query to prove proposal authority for any particular match.
PlayerChildMarriageSubjectReadV1 ReadPlayerChildMarriageSubjectV1(
    const Bindings &bindings, std::int32_t subject_character_id) noexcept;

struct MarriageCandidateAlliancePrivateReadV1 {
  MarriageCandidateAlliancePrivateFailureV1 failure =
      MarriageCandidateAlliancePrivateFailureV1::binding_unavailable;
  bridge::MarriageCandidateAllianceProjectionFailureV1 projection_failure =
      bridge::MarriageCandidateAllianceProjectionFailureV1::none;
  bridge::MarriageCandidateAllianceProjectionV1 projection{};
  bridge::MarriageNativeOutcomeClassifierFailureV1 outcome_failure =
      bridge::MarriageNativeOutcomeClassifierFailureV1::none;
  bridge::MarriagePredictedOutcomeV1 predicted_outcome =
      bridge::MarriagePredictedOutcomeV1::unavailable;
    bool heir_is_adult = false;
    bool candidate_is_adult = false;
    bool grand_wedding_option_selected = false;
    std::int16_t heir_adult_measure_raw = 0;
    std::int16_t candidate_adult_measure_raw = 0;
    std::int32_t heir_adult_threshold_raw = 0;
    std::int32_t candidate_adult_threshold_raw = 0;
  MarriageHeirRelationshipV1 heir_relationship{};
  MarriageHeirRelationshipV1 candidate_relationship{};
  MarriageCharacterLineageV1 played_lineage{};
  MarriageCharacterLineageV1 heir_lineage{};
  MarriageCharacterLineageV1 candidate_lineage{};
  std::uint8_t heir_sex_selector_raw = 0xFF;
  std::uint8_t candidate_sex_selector_raw = 0xFF;
  bridge::MarriageCharacterFertilityReadV1 heir_fertility{};
  bridge::MarriageCharacterFertilityReadV1 candidate_fertility{};
  bool effective_matrilineal_if_accepted = false;
  bool requested_matrilineal_option = false;
  bool selected_option_readback = false;
  std::array<std::int64_t,
             bridge::kMarriageGenericCostResourceCountV1> generic_cost_raw{};
  bool final_legality_sampled = false;
  bool complete_can_send = false;
  bool recipient_acceptance_ready = false;
  std::int64_t recipient_ai_accept_raw = 0;
  std::uint8_t recipient_answer_status_raw = 3;
};

// Recreates and finalizes one exact five-role context on application-main.
// The earlier legal row chooses an identity only; Can Send and recipient final
// answer are repeated before the projection and before context teardown.
MarriageCandidateAlliancePrivateReadV1
ReadMarriageCandidateAlliancePrivateV1(
    const Bindings &bindings,
    const ArrangeMarriageFamilyCandidateV1 &observed_legal_row,
    const bridge::MarriageCandidateAllianceProjectionEnvironmentV1
        &projection_environment,
    const bridge::MarriageNativeOutcomeClassifierEnvironmentV1
        &outcome_environment,
    bool request_matrilineal_option = false,
    bool read_fertility = false) noexcept;
#endif

using game::ArrangeMarriageResult;

// Rebuilds the context from both exact CharacterID handles and validates it
// again before sending CSendCharacterInteractionCommand. This first slice is
// deliberately the useful direct path (played Character <-> candidate), not
// the wider four-role courtier matchmaking surface.
ArrangeMarriageResult SubmitArrangeMarriage(
    const Bindings &bindings,
    const ArrangeMarriageChoice &choice) noexcept;

using game::EnforceDemandsResult;

// Builds the same victory interaction context as WarOverviewWindow's victory
// tab for one live CWar led by the played character, then sends the common
// native character-interaction command. The visual confirmation wrapper is
// intentionally not part of the gameplay command and is not needed in
// headless mode.
EnforceDemandsResult SubmitEnforceDemands(const Bindings &bindings,
                                          std::int32_t war_id) noexcept;

using game::ReadWarTerminationOptionsResult;

// Rebuilds all currently proven WarOverview result contexts for one exact
// WarID while paused, validates them through CK3's common interaction
// validator, then destroys every temporary context without queuing a command.
ReadWarTerminationOptionsResult ReadWarTerminationOptions(
    const Bindings &bindings, std::int32_t war_id,
    WarTerminationOptionsSnapshot &output) noexcept;

using game::OutboundWarWhitePeaceStatusSnapshot;
using game::ReadOutboundWarWhitePeaceStatusResult;

// Scans the exact-build global pending-interaction store twice while the
// public paused snapshot remains unchanged.  This is the sender-side receipt
// query needed before a recovery path may decide whether re-submission is
// legal.
ReadOutboundWarWhitePeaceStatusResult ReadOutboundWarWhitePeaceStatus(
    const Bindings &bindings, std::int32_t war_id,
    OutboundWarWhitePeaceStatusSnapshot &output) noexcept;

using game::ReadWarTerminationTermsResult;

// Reads the complete claim_cb claimant/target/claim-disposition slice without
// constructing or submitting a character-interaction command. Non-claim CBs
// return a typed unsupported result with only CB identity populated.
ReadWarTerminationTermsResult ReadWarTerminationTerms(
    const Bindings &bindings, std::int32_t war_id,
    WarTerminationTermsSnapshot &output) noexcept;

using game::ReadDefenderDeJureExitTermsV1Result;

// Baseline-only, fail-closed de-jure defender read.  Never calls loaded-effect
// preview or submits a resolution; material deltas remain typed unavailable.
ReadDefenderDeJureExitTermsV1Result ReadDefenderDeJureExitTermsV1(
    const Bindings &bindings, std::int32_t war_id,
    DefenderDeJureExitTermsV1 &output) noexcept;

using game::RaiktorActualTruceExpirySnapshotV1;
using game::ReadRaiktorActualTruceExpiryResultV1;

// Reads the persisted one-way relation state after the result effect has been
// applied. The owner is always the living played character; only the exact
// generation-safe toward CharacterID is supplied by the caller.
ReadRaiktorActualTruceExpiryResultV1 ReadRaiktorActualTruceExpiry(
    const Bindings &bindings, std::int32_t toward_character_id,
    RaiktorActualTruceExpirySnapshotV1 &output) noexcept;

#if defined(XAR_CK3_ENABLE_H2743_PREACTION_EXISTING_TRUCE_CANDIDATE_V1)
// H2743's already-applied attacker->defender relation only. It cannot return
// the result of surrender, which has not yet been applied.
game::H2743ExistingTruceStatusV1 ReadH2743PreactionExistingTruceV1(
    const Bindings &bindings,
    game::H2743ExistingTruceSnapshotV1 &output) noexcept;
#endif

using game::ReadWarTerminationExitTermsResult;

// Complete claim_cb white-peace/attacker-defeat terms from the original
// loaded-effect dry-preview path. The query never queues a command or applies
// an effect and publishes only after same-frame before/after identity and
// resource checks match.
ReadWarTerminationExitTermsResult ReadWarTerminationExitTerms(
    const Bindings &bindings, std::int32_t war_id,
    WarTerminationExitTermsSnapshot &output) noexcept;

// Reads the actual PoW pairs that CK3's surrender acceptance path will release
// for the primary leaders and their first three title successors.  The query
// is limited to the exact raiktor_claim_cb / played-primary-attacker branch,
// samples the complete participant/succession/jailer graph twice in one
// paused date, and never constructs an interaction or executes an effect.
ReadRaiktorSurrenderPrisonerReleasesResult
ReadRaiktorSurrenderPrisonerReleases(
    const Bindings &bindings, std::int32_t war_id,
    RaiktorSurrenderPrisonerReleaseObservation &output) noexcept;

// Reads the generic PoW-release input graph for any active WarID on either
// player side, without loading or previewing CB effects.  A separate native
// termination query must establish which exit interaction is attainable.
ReadWarPrisonerReleasePairsResultV1 ReadWarPrisonerReleasePairsV1(
    const Bindings &bindings, std::int32_t war_id,
    WarPrisonerReleasePairsObservationV1 &output) noexcept;

// Reads only the primary attacker->defender final gold callback from
// raiktor_claim_cb's original visible attacker-defeat root. It never enters
// the disabled broad exit reader or hidden-truce projection and never
// executes an effect or submits a command.
ReadRaiktorSurrenderGoldResult ReadRaiktorSurrenderGold(
    const Bindings &bindings, std::int32_t war_id,
    RaiktorSurrenderGoldObservation &output) noexcept;

// Reads the final cb_prestige_factor accumulator and the primary attacker's
// actual prestige callback from one traversal of raiktor_claim_cb's original
// visible attacker-defeat root.  The root proxy exists only to observe the
// helper-owned temporary variable container; no effect or command executes.
ReadRaiktorSurrenderPrestigeResult ReadRaiktorSurrenderPrestige(
    const Bindings &bindings, std::int32_t war_id,
    RaiktorSurrenderPrestigeObservation &output) noexcept;

// Reads whether raiktor_claim_cb's authored conditional favor_hook will be
// applied by the original visible attacker-defeat root.  Exact War/CB/role,
// loaded-root vtable and slot11 identities are frozen across two samples in
// one paused date.  claimant==attacker is exact false without traversal.
ReadRaiktorSurrenderFavorHookResult ReadRaiktorSurrenderFavorHook(
    const Bindings &bindings, std::int32_t war_id,
    RaiktorSurrenderFavorHookObservation &output) noexcept;

// Exact-build, primary-attacker-owner observation of persistent regiments
// bound to one full-generation active WarID with keep=false. Each of the seven
// persistent composition rows is generation-resolved to its current
// CArmyRegiment and current CArmy when present, so army merges do not erase
// identity. CK3 stores no event/source provenance on these objects; successful
// output therefore says only war_bound_not_event_specific and never infers
// Raiktor identity from a display name, public ArmyID or initial soldier total.
bool ReadPrimaryAttackerWarBoundRegimentObservation(
    const Bindings &bindings, std::int32_t war_id,
    std::int32_t owner_character_id,
    WarBoundRegimentObservation &output) noexcept;

// Independent postwar observation over the full-generation IDs frozen by the
// active-war query above. The War may already be gone. The query instead
// requires a paused, stable game/Jomini pair and exact persistent/current/
// CArmy stores, then proves per-ID liveness and frozen-CArmy roster
// attachment twice. A surviving CArmy alone is not surviving special troops.
// Provenance remains war_bound_not_event_specific.
bool ReadFrozenWarBoundRegimentCleanupObservation(
    const Bindings &bindings,
    const WarBoundRegimentObservation &frozen,
    FrozenWarBoundRegimentCleanupObservation &output) noexcept;

#if defined(XAR_CK3_WAR_EXIT_TERMS_OFFLINE_RE_TEST)
// Test-only typed retention from the private Raiktor truce reader.  This is
// intentionally absent from production builds and is not serialized.
RaiktorSurrenderTruceFailureV1
LastRaiktorSurrenderTruceFailureForOfflineReFixture() noexcept;

// Offline-only entry point for the exact-build loaded-effect fixtures.  The
// production entry point remains disabled until the native visitor/scope ABI
// that crashed at CK3 RVA 0x334C668 is closed and revalidated live.
ReadWarTerminationExitTermsResult
ReadWarTerminationExitTermsForOfflineReFixture(
    const Bindings &bindings, std::int32_t war_id,
    WarTerminationExitTermsSnapshot &output) noexcept;

// Isolated exact-build primitive for the Raiktor attacker-defeat visible
// loaded root. It observes only the conditional ordinary add_hook row and
// never enters the disabled broad exit-terms reader or its hidden-truce
// projection. The caller owns a populated read-only WarEffectContext.
bool ReadRaiktorFavorHookPresenceForOfflineReFixture(
    const Bindings &bindings, void *loaded_effect, void *effect_context,
    std::int32_t attacker_character_id,
    std::int32_t claimant_character_id, bool &applies) noexcept;

using RaiktorPrisonerReleaseBetweenSamplesHook = void (*)() noexcept;

// Test seam used only to force a participant, succession, jailer or identity
// mutation between the two native samples. Production always supplies no
// hook.
ReadRaiktorSurrenderPrisonerReleasesResult
ReadRaiktorSurrenderPrisonerReleasesForOfflineReFixture(
    const Bindings &bindings, std::int32_t war_id,
    RaiktorSurrenderPrisonerReleaseObservation &output,
    RaiktorPrisonerReleaseBetweenSamplesHook between_samples) noexcept;

using RaiktorGoldBetweenSamplesHook = void (*)() noexcept;

// Offline mutation seam for the exact same production implementation. It can
// force finance, identity or final preview-row drift between the two paused
// samples; production always supplies no hook.
ReadRaiktorSurrenderGoldResult
ReadRaiktorSurrenderGoldForOfflineReFixture(
    const Bindings &bindings, std::int32_t war_id,
    RaiktorSurrenderGoldObservation &output,
    RaiktorGoldBetweenSamplesHook between_samples) noexcept;

using RaiktorPrestigeBetweenSamplesHook = void (*)() noexcept;

// Offline mutation seam for the production F/prestige implementation.  It
// can force final-row, callback, balance or identity drift between samples;
// production always supplies no hook.
ReadRaiktorSurrenderPrestigeResult
ReadRaiktorSurrenderPrestigeForOfflineReFixture(
    const Bindings &bindings, std::int32_t war_id,
    RaiktorSurrenderPrestigeObservation &output,
    RaiktorPrestigeBetweenSamplesHook between_samples) noexcept;

using RaiktorFavorHookBetweenSamplesHook = void (*)() noexcept;

// Offline mutation seam for the production favor-hook implementation.  It
// can force hook-presence, runtime hook-type or War/CB/root identity drift
// between samples; production always supplies no hook.
ReadRaiktorSurrenderFavorHookResult
ReadRaiktorSurrenderFavorHookForOfflineReFixture(
    const Bindings &bindings, std::int32_t war_id,
    RaiktorSurrenderFavorHookObservation &output,
    RaiktorFavorHookBetweenSamplesHook between_samples) noexcept;

using WarBoundCleanupBetweenSamplesHook = void (*)() noexcept;

// Test seam used only to force a mutation between the two native samples.
// Production always supplies no hook.
bool ReadFrozenWarBoundRegimentCleanupObservationForOfflineReFixture(
    const Bindings &bindings,
    const WarBoundRegimentObservation &frozen,
    FrozenWarBoundRegimentCleanupObservation &output,
    WarBoundCleanupBetweenSamplesHook between_samples) noexcept;
#endif

// Error-only stage name from the immediately preceding exit-terms read on the
// current bridge thread.  Successful reads clear it.
std::string_view LastWarTerminationExitTermsUnavailableReason() noexcept;

using game::SurrenderWarResult;
using game::OfferWhitePeaceResult;

// Sends the played war leader's defeat result for one exact WarID. The native
// boolean is the absolute outcome (`true` attacker victory, `false` attacker
// defeat), so the submitted value depends on the player's physical war side.
// Queue submission is a typed ACK, not proof that the war already ended or
// that any still-unobserved terms were applied.
SurrenderWarResult SubmitSurrenderWar(const Bindings &bindings,
                                      std::int32_t war_id) noexcept;

// Builds the native special-interaction index 3 white-peace context for the
// played primary war leader, validates it, and submits only a typed queue ACK.
OfferWhitePeaceResult SubmitOfferWhitePeace(const Bindings &bindings,
                                            std::int32_t war_id) noexcept;

} // namespace xar::ck3_11906
