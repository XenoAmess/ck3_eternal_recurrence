#pragma once

#include <windows.h>

#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>

namespace xar::bridge {

inline constexpr std::uint32_t kProtocolVersion = 1;
// Paired with native_driver.MAXIMUM_FRAME_BYTES, including both pipe buffers
// and length-header admission. The scoped daily DTO can exceed 1 MiB.
inline constexpr std::uint32_t kMaximumFrameBytes = 2U * 1024U * 1024U;
inline constexpr std::size_t kMaximumControlStringBytes = 128U;

enum class ReadStatus {
  none,
  frame,
  closed,
  invalid,
};

struct ReadResult {
  ReadStatus status = ReadStatus::none;
  std::string payload;
  DWORD windows_error = ERROR_SUCCESS;
};

// The transport is a little-endian uint32 byte count followed by one compact
// UTF-8 JSON document. It deliberately is not MCP: the external daemon owns
// MCP and translates its typed tools to this small process-local protocol.
bool WriteFrame(HANDLE pipe, std::string_view payload) noexcept;

// Reads one compact, unescaped JSON string field with a caller-supplied bound.
// Bridge control fields use kMaximumControlStringBytes; gameplay steps may use
// a larger protocol-specific bound without widening request_id or type.
bool JsonStringField(std::string_view json, std::string_view key,
                     std::string &output,
                     std::size_t maximum_bytes) noexcept;

bool JsonUnsignedField(std::string_view json, std::string_view key,
                       std::uint64_t &output) noexcept;

bool JsonBooleanField(std::string_view json, std::string_view key,
                      bool &output) noexcept;

// Non-blocking probe. A complete frame is consumed only when all of its bytes
// are already available in the pipe.
ReadResult TryReadFrame(HANDLE pipe) noexcept;

}  // namespace xar::bridge
