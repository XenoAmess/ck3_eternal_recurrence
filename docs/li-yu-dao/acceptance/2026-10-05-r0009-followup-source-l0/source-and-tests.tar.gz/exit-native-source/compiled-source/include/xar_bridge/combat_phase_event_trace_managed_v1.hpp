#pragma once

#include "xar_bridge/combat_scoped_transition_chain_v1.hpp"
#include <memory>

#include "xar_bridge/ck3_11906.hpp"
#include "xar_bridge/combat_phase_event_trace_detour_v1.hpp"
#include "xar_bridge/combat_counter_output_detour_v1.hpp"
#include "xar_bridge/combat_advantage_components_observer_v1.hpp"
#include "xar_bridge/combat_phase_event_trace_wire_v1.hpp"
#include "xar_bridge/main_thread_query_mailbox_v1.hpp"
#include "xar_bridge/protocol.hpp"

#include <cstdint>
#include <string>
#include <type_traits>

namespace xar::ck3_11906 {

// The combined ring + scoped journal has its own bounded frame budget. Keep
// the ring's original 900 KiB bound; reserve 128 KiB for command_result framing.
inline constexpr std::size_t kCombatPhaseEventTraceManagedMaximumBytesV1 =
    xar::bridge::kMaximumFrameBytes - 128U * 1024U;
static_assert(kCombatPhaseEventTraceManagedMaximumBytesV1 >
              kCombatPhaseEventTraceWireMaximumBytesV1);

// The reader, detours and bounded wire DTO are production sources.  The
// adapter remains unadvertised until bridge.cpp admits this typed pair and a
// paused same-combat live fixture records the managed checkpoint transition.
inline constexpr bool kCombatPhaseEventTraceCapturePlanBuilderV1Ready = true;
#if defined(XAR_CK3_ENABLE_EXPERIMENTAL_COMBAT_PHASE_TRACE_MANAGED_V1)
inline constexpr bool kCombatPhaseEventTraceManagedExecutorV1Wired = true;
#else
inline constexpr bool kCombatPhaseEventTraceManagedExecutorV1Wired = false;
#endif
inline constexpr std::string_view kCombatPhaseEventTraceManagedBeginStepV1 =
    "experimental-combat-phase-event-trace-begin-v1";
inline constexpr std::string_view kCombatPhaseEventTraceManagedFinishStepV1 =
    "experimental-combat-phase-event-trace-finish-v1";
inline constexpr std::string_view kCombatPhaseEventTraceManagedCapabilityV1 =
    "game.command.experimental-combat-phase-event-trace-managed-v1";

enum class BuildCombatPhaseEventTraceCapturePlanV1Result : std::uint32_t {
  built = 0,
  exact_build_rejected = 1,
  invalid_request = 2,
  combat_unavailable = 3,
  native_slot_unavailable = 4,
  roster_unavailable = 5,
  battle_result_unavailable = 6,
  accolade_unavailable = 7,
  capacity_exceeded = 8,
  memory_fault = 9,
};

// Production uses the frozen module RVAs.  Overrides are fixture-only and
// keep exact plan construction testable without mapping the CK3 image.
struct CombatPhaseEventTracePlanEnvironmentV1 {
  bool exact_build_admitted = false;
  bool offline_fixture = false;
  std::uintptr_t module_base = 0;
  std::uintptr_t phase_event_database_slot_override = 0;
  std::uintptr_t current_date_slot_override = 0;
  std::uintptr_t global_rng_wrapper_slot_override = 0;
  void **battle_result_storage_slot_override = nullptr;
  void *battle_result_fallback_override = nullptr;
  void **accolade_storage_slot_override = nullptr;
  void *accolade_fallback_override = nullptr;
  std::uintptr_t battle_event_vtable_override = 0;
  std::uintptr_t accolade_rank_threshold_data_slot_override = 0;
  std::uintptr_t accolade_rank_threshold_count_slot_override = 0;
  // Research-only: one route-proven army that is still outside this combat at
  // arm time but may join during the next native day.  Its full generation and
  // regiment/knight identities are resolved before gameplay resumes.
  std::int32_t candidate_joining_army_id = -1;
};

BuildCombatPhaseEventTraceCapturePlanV1Result
BuildCombatPhaseEventTraceCapturePlanV1(
    const Bindings &bindings,
    const CombatPhaseEventTracePlanEnvironmentV1 &environment,
    std::int32_t combat_id, std::uint64_t managed_daily_sequence_token,
    CombatPhaseEventTraceCapturePlanV1 &output) noexcept;

enum class CombatPhaseEventTraceManagedStageV1 : std::uint32_t {
  idle = 0,
  armed_waiting_for_one_day = 1,
  drained = 2,
  failed = 3,
};

enum class CombatPhaseEventTraceManagedCompletionV1 : std::uint32_t {
  not_executed = 0,
  armed = 1,
  bounded_trace_available = 2,
  trace_unavailable = 3,
  infrastructure_rejected = 4,
};

struct CombatPhaseEventTraceManagedCheckpointV1 {
  std::uint64_t managed_daily_sequence_token = 0;
  std::uint64_t pump_epoch = 0;
  std::uint32_t thread_id = 0;
  std::int32_t date_raw = 0;
  std::int32_t combat_id = -1;
  bool paused = false;

  friend bool operator==(const CombatPhaseEventTraceManagedCheckpointV1 &,
                         const CombatPhaseEventTraceManagedCheckpointV1 &) =
      default;
};

// Worker-owned storage.  It must outlive both mailbox tickets and the managed
// one-day checkpoint.  The external driver must create a recoverable save
// checkpoint before advancing; neither executor changes speed or game time.
struct CombatPhaseEventTraceManagedSessionV1 {
  std::unique_ptr<CombatScopedChainV1> scoped_chain{};
  CombatScopedDetoursV1 scoped_detours{};
  bool capture_runtime_scoped_chain = false;
  CombatPhaseEventTraceManagedStageV1 stage =
      CombatPhaseEventTraceManagedStageV1::idle;
  CombatPhaseEventTraceRingV1 ring{};
  CombatPhaseEventTraceDetourStateV1 detours{};
  CombatJoinWrapperDetourV1 join_width_detour{};
  CombatCounterOutputDetourV1 counter_output_detour{};
  AdvantageComponentObserverV1 advantage_components{};
  AdvantageComponentDetoursV1 advantage_component_detours{};
  CombatPhaseEventTraceCapturePlanV1 plan{};
  CombatPhaseEventTraceRingDrainV1 drain{};
  CombatPhaseEventTraceManagedCheckpointV1 before{};
  CombatPhaseEventTraceManagedCheckpointV1 after{};
  BuildCombatPhaseEventTraceCapturePlanV1Result plan_result =
      BuildCombatPhaseEventTraceCapturePlanV1Result::invalid_request;
  std::string serialized_drain;
  bool recoverable_checkpoint_created = false;
  bool exact_one_day_observed = false;
  bool boundary_dates_match_checkpoint = false;
  bool detours_uninstalled = false;
  bool capture_runtime_advantage_components = false;

  CombatPhaseEventTraceManagedSessionV1() = default;
  CombatPhaseEventTraceManagedSessionV1(
      const CombatPhaseEventTraceManagedSessionV1 &) = delete;
  CombatPhaseEventTraceManagedSessionV1 &operator=(
      const CombatPhaseEventTraceManagedSessionV1 &) = delete;
};

struct CombatPhaseEventTraceBeginContextV1 {
  bool capture_runtime_scoped_chain = false;
  std::int32_t scoped_character_id = -1;
  std::int32_t scoped_related_character_id = -1;
  std::int32_t scoped_event_load_index = -1;
  MainThreadQueryMailboxV1 *mailbox = nullptr;
  MainThreadQueryTicketV1 ticket{};
  CombatPhaseEventTraceManagedSessionV1 *session = nullptr;
  const Bindings *bindings = nullptr;
  CombatPhaseEventTracePlanEnvironmentV1 plan_environment{};
  CombatPhaseEventTraceDetourEnvironmentV1 detour_environment{};
  std::int32_t combat_id = -1;
  std::uint64_t managed_daily_sequence_token = 0;
  bool recoverable_checkpoint_created = false;
  bool capture_runtime_random_list_weights = false;
  bool capture_runtime_join_width = false;
  bool capture_runtime_join_full_entries = false;
  bool capture_runtime_counter_output = false;
  bool capture_runtime_advantage_components = false;
  CombatPhaseEventTraceManagedCompletionV1 completion =
      CombatPhaseEventTraceManagedCompletionV1::not_executed;
  std::uint32_t executor_invocations = 0;
};

struct CombatPhaseEventTraceFinishContextV1 {
  MainThreadQueryMailboxV1 *mailbox = nullptr;
  MainThreadQueryTicketV1 ticket{};
  CombatPhaseEventTraceManagedSessionV1 *session = nullptr;
  std::uint64_t managed_daily_sequence_token = 0;
  CombatPhaseEventTraceManagedCompletionV1 completion =
      CombatPhaseEventTraceManagedCompletionV1::not_executed;
  std::uint32_t executor_invocations = 0;
};

bool ExecuteCombatPhaseEventTraceBeginV1(
    void *opaque_context,
    const MainThreadExecutionStampV1 &stamp) noexcept;
bool ExecuteCombatPhaseEventTraceFinishV1(
    void *opaque_context,
    const MainThreadExecutionStampV1 &stamp) noexcept;

struct CombatPhaseEventTracePublishDiagnosticV1 {
  const char *failure_gate = "none";
  std::uint32_t session_stage = 0, drain_failure_flags = 0, drain_record_count = 0;
  std::uint32_t scoped_failure_flags = 0, scoped_record_count = 0;
  bool scoped_present = false, scoped_serialization_attempted = false;
  std::uint64_t ring_serialized_bytes = 0, scoped_serialized_bytes = 0;
  std::uint64_t assembled_output_bytes = 0, managed_cap_bytes = 0;
  bool exact_one_day_observed = false, boundary_dates_match_checkpoint = false;
  bool detours_uninstalled = false;
  CombatPhaseEventTraceManagedCheckpointV1 before{}, after{};
  CombatScopedWireDiagnosticV1 scoped{};
};
// Small failed-return diagnostic; it never replaces or approves a trace DTO.
std::string SerializeCombatPhaseEventTracePublishDiagnosticV1(
    const CombatPhaseEventTracePublishDiagnosticV1 &diagnostic);

// Wraps the bounded drain fragment with the two managed checkpoints.  Empty
// means the session has not reached a terminal drain or exceeded the wire cap.
std::string SerializeCombatPhaseEventTraceManagedResultV1(
    const CombatPhaseEventTraceManagedSessionV1 &session,
    CombatPhaseEventTracePublishDiagnosticV1 *diagnostic = nullptr);

static_assert(std::is_same_v<decltype(&ExecuteCombatPhaseEventTraceBeginV1),
                             MainThreadQueryExecutorV1>);
static_assert(std::is_same_v<decltype(&ExecuteCombatPhaseEventTraceFinishV1),
                             MainThreadQueryExecutorV1>);

} // namespace xar::ck3_11906
