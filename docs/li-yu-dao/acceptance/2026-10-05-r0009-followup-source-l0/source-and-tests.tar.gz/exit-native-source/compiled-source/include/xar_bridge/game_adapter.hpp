#pragma once

#include "xar_bridge/combat_v3.hpp"
#include "xar_bridge/title_holder_v1.hpp"
#include "xar_bridge/raiktor_actual_truce_expiry_v1.hpp"
#include "xar_bridge/h2743_preaction_existing_truce_v1.hpp"
#if defined(XAR_CK3_ENABLE_G2_WAR_BOUND_LOSS_CANDIDATE_V1)
#include "xar_bridge/raiktor_war_bound_loss_candidate_v1.hpp"
#endif

#include <cstdint>
#include <memory>
#include <span>
#include <string_view>
#include <vector>

namespace xar::game {

struct AdapterDescriptor {
  std::string_view adapter_id;
  std::string_view game_version;
  std::string_view executable_sha256;
  std::string_view checkpoint_save_name;
  std::span<const std::string_view> capabilities;
};

// Strict v2 hypothetical-contact literal grammar:
// query-combat-simulation-inputs-v2-<target>-<entry>-a-<Acount>-<A...>
// -d-<Dcount>-<D...>. Counts are exact, each side is non-empty, and all
// public full-generation ArmyIDs are distinct across both partitions.
bool ParseCombatSimulationInputsStep(
    std::string_view step, CombatSimulationInputsRequest &request) noexcept;

// Strict production v3 grammar. It deliberately shares the canonical request
// body with v2 while selecting the atomic phase-event observation contract.
bool ParseCombatSimulationInputsV3Step(
    std::string_view step, CombatSimulationInputsRequest &request) noexcept;

// Stable semantic API implemented by one exact-build CK3 adapter. ABI details
// are private to the implementation selected by the registry.
class GameAdapter {
public:
  virtual ~GameAdapter() = default;

  [[nodiscard]] virtual const AdapterDescriptor &descriptor() const noexcept = 0;
  [[nodiscard]] virtual bool enabled() const noexcept = 0;
  [[nodiscard]] bool supports(std::string_view capability) const noexcept;
  [[nodiscard]] bool supports_snapshot() const noexcept;
  [[nodiscard]] bool supports_step(std::string_view step) const noexcept;

  virtual bool read_snapshot(Snapshot &output) const noexcept = 0;
  // When supplied, observed_snapshot contains the observation used to decide
  // idempotence or command submission. Crozier worker timeline operations use
  // only core fields; the bridge obtains the complete published postcondition
  // separately. Older adapters return a full snapshot, usable at an automatic
  // pause boundary without racing a second read.
  virtual PauseSubmitResult
  submit_pause_map(Snapshot *observed_snapshot = nullptr) const noexcept = 0;
  virtual ResumeSubmitResult
  submit_resume_map(Snapshot *observed_snapshot = nullptr) const noexcept = 0;
  virtual bool submit_set_speed(std::int32_t speed) const noexcept = 0;
  virtual SelectEventOptionResult
  submit_select_event_option(std::int32_t option_index) const noexcept = 0;
  virtual SaveCheckpointResult submit_save_checkpoint() const noexcept = 0;
  virtual ReplyPendingInteractionResult submit_reply_to_pending_interaction(
      PendingInteractionReply reply) const noexcept = 0;
  virtual AcknowledgePendingInteractionResult
  submit_acknowledge_pending_interaction(
      std::int32_t pending_interaction_id) const noexcept {
    static_cast<void>(pending_interaction_id);
    return AcknowledgePendingInteractionResult::unavailable;
  }
  virtual RaiseTroopsResult submit_raise_troops_default() const noexcept = 0;
  virtual MoveArmyResult submit_move_army(std::int32_t army_id,
                                          std::int32_t province_id) const
      noexcept = 0;
  virtual HaltArmyResult submit_halt_army(std::int32_t army_id) const noexcept {
    static_cast<void>(army_id);
    return HaltArmyResult::unavailable;
  }
  virtual PreviewMoveArmyResult
  preview_move_army(std::int32_t army_id,
                    std::int32_t province_id) const noexcept = 0;
  virtual DisbandArmyResult submit_disband_army(std::int32_t army_id) const
      noexcept = 0;
  virtual SplitArmyHalfResult
  submit_split_army_half(std::int32_t army_id) const noexcept = 0;
  virtual MergeArmiesResult
  submit_merge_armies(std::int32_t destination_army_id,
                      std::int32_t source_army_id) const noexcept = 0;
  virtual StartAssaultResult
  submit_start_assault(std::int32_t siege_id) const noexcept = 0;
  virtual StopAssaultResult
  submit_stop_assault(std::int32_t siege_id) const noexcept = 0;
  virtual bool read_declarable_wars(
      std::vector<DeclarableWarSnapshot> &output) const noexcept = 0;
  virtual ReadDeclarableWarsResult read_declarable_wars_for_target(
      std::int32_t target_character_id,
      std::vector<DeclarableWarSnapshot> &output) const noexcept = 0;
  // Private exact-build observation; no advertised capability or generic
  // adapter obligation. A county TitleID yields its objective Province only.
  virtual bool read_claim_county_objective_province(
      std::int32_t, std::int32_t &province_id) const noexcept {
    province_id = -1;
    return false;
  }
  // Private exact-build observation of the current default muster location.
  // This does not validate a raise command or predict raised regiments/time.
  virtual bool read_default_raise_province(
      std::int32_t, std::int32_t &province_id) const noexcept {
    province_id = -1;
    return false;
  }
  virtual DeclareWarResult
  submit_declare_war(const DeclarableWarSnapshot &declaration) const
      noexcept = 0;
  virtual ReadArrangeMarriageChoicesResult read_arrange_marriage_choices(
      std::vector<ArrangeMarriageChoice> &output,
      ArrangeMarriageQueryDiagnostics &diagnostics) const noexcept = 0;
  // The default keeps non-CK3 test adapters and production capability lists
  // unchanged. Only the exact-build adapter implements this private read.
  virtual ReadArrangeMarriageFamilyCandidatesResultV1
  read_arrange_marriage_family_candidates_v1(
      std::int32_t, std::vector<ArrangeMarriageFamilyCandidateV1> &output,
      ArrangeMarriageQueryDiagnostics &diagnostics) const noexcept {
    output.clear();
    diagnostics = {};
    return ReadArrangeMarriageFamilyCandidatesResultV1::unavailable;
  }
  virtual ArrangeMarriageResult
  submit_arrange_marriage(const ArrangeMarriageChoice &choice) const
      noexcept = 0;
  virtual EnforceDemandsResult
  submit_enforce_demands(std::int32_t war_id) const noexcept = 0;
  virtual ReadArmyStrengthsResult read_army_strengths(
      std::vector<ArmyStrengthSnapshot> &output) const noexcept = 0;
  virtual ReadProvinceLocalSiegeResult read_province_local_siege(
      std::int32_t, WarObjectiveProvinceState &output) const noexcept {
    output = {};
    return ReadProvinceLocalSiegeResult::unavailable;
  }
  virtual ReadCombatSimulationInputsResult read_combat_simulation_inputs(
      const CombatSimulationInputsRequest &request,
      CombatSimulationInputsSnapshot &output) const noexcept = 0;
  virtual ReadCombatSimulationInputsV3Result
  read_combat_simulation_inputs_v3(
      const CombatSimulationInputsRequest &request,
      CombatSimulationInputsV3Snapshot &output) const noexcept = 0;
  virtual ReadTitleHolderV1Result read_title_holder_v1(
      std::int32_t, TitleHolderV1 &output) const noexcept {
    output = {};
    return ReadTitleHolderV1Result::unavailable;
  }
  virtual ReadWarOccupationTargetsV1Result read_war_occupation_targets_v1(
      std::int32_t, WarOccupationTargetsV1 &output) const noexcept {
    output = {};
    return ReadWarOccupationTargetsV1Result::unavailable;
  }
  virtual ReadWarTerminationOptionsResult read_war_termination_options(
      std::int32_t war_id,
      WarTerminationOptionsSnapshot &output) const noexcept = 0;
  virtual ReadOutboundWarWhitePeaceStatusResult
  read_outbound_war_white_peace_status(
      std::int32_t, OutboundWarWhitePeaceStatusSnapshot &output) const
      noexcept {
    output = {};
    return ReadOutboundWarWhitePeaceStatusResult::unavailable;
  }
  virtual ReadWarTerminationTermsResult read_war_termination_terms(
      std::int32_t war_id,
      WarTerminationTermsSnapshot &output) const noexcept = 0;
  virtual ReadDefenderDeJureExitTermsV1Result
  read_defender_de_jure_exit_terms_v1(
      std::int32_t, DefenderDeJureExitTermsV1 &output) const noexcept {
    output = {};
    return ReadDefenderDeJureExitTermsV1Result::unavailable;
  }
  virtual ReadRaiktorActualTruceExpiryResultV1
  read_raiktor_actual_truce_expiry(
      std::int32_t toward_character_id,
      RaiktorActualTruceExpirySnapshotV1 &output) const noexcept {
    (void)toward_character_id;
    output = {};
    return ReadRaiktorActualTruceExpiryResultV1::unavailable;
  }
  // Keep the shared adapter layout identical in the separately built 1.20
  // runtime and the optional 1.19 reader. Only the exact legacy adapter can
  // override this method or advertise its capability when the option is ON.
  virtual H2743ExistingTruceStatusV1 read_h2743_preaction_existing_truce_v1(
      H2743ExistingTruceSnapshotV1 &output) const noexcept {
    output = {};
    return H2743ExistingTruceStatusV1::unavailable;
  }
#if defined(XAR_CK3_ENABLE_G2_WAR_BOUND_LOSS_CANDIDATE_V1)
  virtual bool read_raiktor_war_bound_loss_cleanup(
      const ck3_11906::RaiktorWarBoundLossBaselineV1 &baseline,
      const ck3_11906::RaiktorWarBoundPostwarFrameV1 &first_postwar_frame,
      const ck3_11906::RaiktorWarBoundPostwarFrameV1 &second_postwar_frame,
      ck3_11906::RaiktorWarBoundLossResultV1 &output) const noexcept {
    (void)baseline;
    (void)first_postwar_frame;
    (void)second_postwar_frame;
    output = {};
    return false;
  }
#endif
  virtual ReadWarTerminationExitTermsResult
  read_war_termination_exit_terms(
      std::int32_t war_id,
      WarTerminationExitTermsSnapshot &output) const noexcept = 0;
  // Error-only diagnostic for the immediately preceding exit-terms read on
  // this bridge thread.  It never exposes a partial terms payload and is not
  // part of the versioned wire contract.
  [[nodiscard]] virtual std::string_view
  last_war_termination_exit_terms_unavailable_reason() const noexcept {
    return {};
  }
  virtual SurrenderWarResult
  submit_surrender_war(std::int32_t war_id) const noexcept = 0;
  virtual OfferWhitePeaceResult
  submit_offer_white_peace(std::int32_t war_id) const noexcept = 0;
};

using AdapterFactory = std::unique_ptr<GameAdapter> (*)(
    std::string_view executable_sha256) noexcept;

// Deterministic registry primitive: returns the first enabled adapter, or the
// first disabled adapter as the preferred diagnostic descriptor when none of
// the exact builds match. An empty factory set returns nullptr.
std::unique_ptr<GameAdapter>
SelectAdapter(std::string_view executable_sha256,
              std::span<const AdapterFactory> factories) noexcept;

// The registry tries known exact-build adapters and returns the matching one.
// With no match it returns a disabled adapter so the transport can continue to
// provide identity/heartbeat/ping without advertising gameplay capabilities.
std::unique_ptr<GameAdapter> SelectCurrentProcessAdapter() noexcept;

// Metadata for the preferred known adapter, used by the pre-session exported
// identity. It comes from the same descriptor as session hello metadata.
const AdapterDescriptor &PreferredAdapterDescriptor() noexcept;

// Compatibility wrappers keep bridge dispatch compact while all calls still
// cross the version-neutral GameAdapter boundary.
inline bool ReadSnapshot(const GameAdapter &game, Snapshot &output) noexcept {
  return game.read_snapshot(output);
}
inline PauseSubmitResult
SubmitPauseMap(const GameAdapter &game,
               Snapshot *observed_snapshot = nullptr) noexcept {
  return game.submit_pause_map(observed_snapshot);
}
inline ResumeSubmitResult
SubmitResumeMap(const GameAdapter &game,
                Snapshot *observed_snapshot = nullptr) noexcept {
  return game.submit_resume_map(observed_snapshot);
}
inline bool SubmitSetSpeed(const GameAdapter &game,
                           std::int32_t speed) noexcept {
  return game.submit_set_speed(speed);
}
inline SelectEventOptionResult
SubmitSelectEventOption(const GameAdapter &game,
                        std::int32_t option_index) noexcept {
  return game.submit_select_event_option(option_index);
}
inline SaveCheckpointResult
SubmitSaveCheckpoint(const GameAdapter &game) noexcept {
  return game.submit_save_checkpoint();
}
inline ReplyPendingInteractionResult SubmitReplyToPendingInteraction(
    const GameAdapter &game, PendingInteractionReply reply) noexcept {
  return game.submit_reply_to_pending_interaction(reply);
}
inline AcknowledgePendingInteractionResult
SubmitAcknowledgePendingInteraction(
    const GameAdapter &game, std::int32_t pending_interaction_id) noexcept {
  return game.submit_acknowledge_pending_interaction(pending_interaction_id);
}
inline RaiseTroopsResult
SubmitRaiseTroopsDefault(const GameAdapter &game) noexcept {
  return game.submit_raise_troops_default();
}
inline MoveArmyResult SubmitMoveArmy(const GameAdapter &game,
                                     std::int32_t army_id,
                                     std::int32_t province_id) noexcept {
  return game.submit_move_army(army_id, province_id);
}
inline HaltArmyResult SubmitHaltArmy(const GameAdapter &game,
                                     std::int32_t army_id) noexcept {
  return game.submit_halt_army(army_id);
}
inline PreviewMoveArmyResult
PreviewMoveArmy(const GameAdapter &game, std::int32_t army_id,
                std::int32_t province_id) noexcept {
  return game.preview_move_army(army_id, province_id);
}
inline DisbandArmyResult SubmitDisbandArmy(const GameAdapter &game,
                                           std::int32_t army_id) noexcept {
  return game.submit_disband_army(army_id);
}
inline SplitArmyHalfResult SubmitSplitArmyHalf(const GameAdapter &game,
                                               std::int32_t army_id) noexcept {
  return game.submit_split_army_half(army_id);
}
inline MergeArmiesResult SubmitMergeArmies(
    const GameAdapter &game, std::int32_t destination_army_id,
    std::int32_t source_army_id) noexcept {
  return game.submit_merge_armies(destination_army_id, source_army_id);
}
inline StartAssaultResult SubmitStartAssault(const GameAdapter &game,
                                             std::int32_t siege_id) noexcept {
  return game.submit_start_assault(siege_id);
}
inline StopAssaultResult SubmitStopAssault(const GameAdapter &game,
                                           std::int32_t siege_id) noexcept {
  return game.submit_stop_assault(siege_id);
}
inline bool ReadDeclarableWars(
    const GameAdapter &game,
    std::vector<DeclarableWarSnapshot> &output) noexcept {
  return game.read_declarable_wars(output);
}
inline ReadDeclarableWarsResult ReadDeclarableWarsForTarget(
    const GameAdapter &game, std::int32_t target_character_id,
    std::vector<DeclarableWarSnapshot> &output) noexcept {
  return game.read_declarable_wars_for_target(target_character_id, output);
}
inline bool ReadClaimCountyObjectiveProvince(
    const GameAdapter &game, std::int32_t county_title_id,
    std::int32_t &province_id) noexcept {
  return game.read_claim_county_objective_province(county_title_id,
                                                   province_id);
}
inline bool ReadDefaultRaiseProvince(
    const GameAdapter &game, std::int32_t character_id,
    std::int32_t &province_id) noexcept {
  return game.read_default_raise_province(character_id, province_id);
}
inline DeclareWarResult
SubmitDeclareWar(const GameAdapter &game,
                 const DeclarableWarSnapshot &declaration) noexcept {
  return game.submit_declare_war(declaration);
}
inline ReadArrangeMarriageChoicesResult ReadArrangeMarriageChoices(
    const GameAdapter &game,
    std::vector<ArrangeMarriageChoice> &output,
    ArrangeMarriageQueryDiagnostics &diagnostics) noexcept {
  return game.read_arrange_marriage_choices(output, diagnostics);
}
inline ReadArrangeMarriageFamilyCandidatesResultV1
ReadArrangeMarriageFamilyCandidatesV1(
    const GameAdapter &game, std::int32_t subject_character_id,
    std::vector<ArrangeMarriageFamilyCandidateV1> &output,
    ArrangeMarriageQueryDiagnostics &diagnostics) noexcept {
  return game.read_arrange_marriage_family_candidates_v1(
      subject_character_id, output, diagnostics);
}
inline ArrangeMarriageResult
SubmitArrangeMarriage(const GameAdapter &game,
                      const ArrangeMarriageChoice &choice) noexcept {
  return game.submit_arrange_marriage(choice);
}
inline EnforceDemandsResult
SubmitEnforceDemands(const GameAdapter &game, std::int32_t war_id) noexcept {
  return game.submit_enforce_demands(war_id);
}
inline ReadArmyStrengthsResult ReadArmyStrengths(
    const GameAdapter &game,
    std::vector<ArmyStrengthSnapshot> &output) noexcept {
  return game.read_army_strengths(output);
}
inline ReadProvinceLocalSiegeResult ReadProvinceLocalSiege(
    const GameAdapter &game, std::int32_t province_id,
    WarObjectiveProvinceState &output) noexcept {
  return game.read_province_local_siege(province_id, output);
}
inline ReadCombatSimulationInputsResult ReadCombatSimulationInputs(
    const GameAdapter &game, const CombatSimulationInputsRequest &request,
    CombatSimulationInputsSnapshot &output) noexcept {
  return game.read_combat_simulation_inputs(request, output);
}
inline ReadCombatSimulationInputsV3Result ReadCombatSimulationInputsV3(
    const GameAdapter &game, const CombatSimulationInputsRequest &request,
    CombatSimulationInputsV3Snapshot &output) noexcept {
  return game.read_combat_simulation_inputs_v3(request, output);
}
inline ReadTitleHolderV1Result ReadTitleHolderV1(
    const GameAdapter &game, std::int32_t title_id,
    TitleHolderV1 &output) noexcept {
  return game.read_title_holder_v1(title_id, output);
}
inline ReadWarOccupationTargetsV1Result ReadWarOccupationTargetsV1(
    const GameAdapter &game, std::int32_t war_id,
    WarOccupationTargetsV1 &output) noexcept {
  return game.read_war_occupation_targets_v1(war_id, output);
}
inline ReadWarTerminationOptionsResult ReadWarTerminationOptions(
    const GameAdapter &game, std::int32_t war_id,
    WarTerminationOptionsSnapshot &output) noexcept {
  return game.read_war_termination_options(war_id, output);
}
inline ReadOutboundWarWhitePeaceStatusResult
ReadOutboundWarWhitePeaceStatus(
    const GameAdapter &game, std::int32_t war_id,
    OutboundWarWhitePeaceStatusSnapshot &output) noexcept {
  return game.read_outbound_war_white_peace_status(war_id, output);
}
inline ReadWarTerminationTermsResult ReadWarTerminationTerms(
    const GameAdapter &game, std::int32_t war_id,
    WarTerminationTermsSnapshot &output) noexcept {
  return game.read_war_termination_terms(war_id, output);
}
inline ReadDefenderDeJureExitTermsV1Result ReadDefenderDeJureExitTermsV1(
    const GameAdapter &game, std::int32_t war_id,
    DefenderDeJureExitTermsV1 &output) noexcept {
  return game.read_defender_de_jure_exit_terms_v1(war_id, output);
}

inline ReadRaiktorActualTruceExpiryResultV1 ReadRaiktorActualTruceExpiry(
    const GameAdapter &game, std::int32_t toward_character_id,
    RaiktorActualTruceExpirySnapshotV1 &output) noexcept {
  return game.read_raiktor_actual_truce_expiry(toward_character_id, output);
}
inline H2743ExistingTruceStatusV1 ReadH2743PreactionExistingTruceV1(
    const GameAdapter &game,
    H2743ExistingTruceSnapshotV1 &output) noexcept {
  return game.read_h2743_preaction_existing_truce_v1(output);
}
#if defined(XAR_CK3_ENABLE_G2_WAR_BOUND_LOSS_CANDIDATE_V1)
inline bool ReadRaiktorWarBoundLossCleanup(
    const GameAdapter &game,
    const ck3_11906::RaiktorWarBoundLossBaselineV1 &baseline,
    const ck3_11906::RaiktorWarBoundPostwarFrameV1 &first_postwar_frame,
    const ck3_11906::RaiktorWarBoundPostwarFrameV1 &second_postwar_frame,
    ck3_11906::RaiktorWarBoundLossResultV1 &output) noexcept {
  return game.read_raiktor_war_bound_loss_cleanup(
      baseline, first_postwar_frame, second_postwar_frame, output);
}
#endif
inline ReadWarTerminationExitTermsResult ReadWarTerminationExitTerms(
    const GameAdapter &game, std::int32_t war_id,
    WarTerminationExitTermsSnapshot &output) noexcept {
  return game.read_war_termination_exit_terms(war_id, output);
}
inline std::string_view LastWarTerminationExitTermsUnavailableReason(
    const GameAdapter &game) noexcept {
  return game.last_war_termination_exit_terms_unavailable_reason();
}
inline SurrenderWarResult SubmitSurrenderWar(
    const GameAdapter &game, std::int32_t war_id) noexcept {
  return game.submit_surrender_war(war_id);
}
inline OfferWhitePeaceResult SubmitOfferWhitePeace(
    const GameAdapter &game, std::int32_t war_id) noexcept {
  return game.submit_offer_white_peace(war_id);
}

} // namespace xar::game
