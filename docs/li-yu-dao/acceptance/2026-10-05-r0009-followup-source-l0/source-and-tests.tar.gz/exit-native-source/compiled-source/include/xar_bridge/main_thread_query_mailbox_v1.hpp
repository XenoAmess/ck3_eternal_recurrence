#pragma once

#include <windows.h>

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>

namespace xar::ck3_11906 {

// This is infrastructure, not a gameplay capability.  It remains completely
// absent from the advertised command set until an exact-build paused live
// fixture has observed the pump and a concrete query has its own full reader
// contract.
inline constexpr bool kMainThreadQueryMailboxV1CapabilityAdvertised = false;
inline constexpr std::string_view kMainThreadQueryMailboxV1CandidateId =
    "application_main_thread_war_entry_v1";
inline constexpr std::string_view kMainThreadQueryMailboxV1AdapterId =
    "ck3-1.19.0.6-msvc-x64";
inline constexpr std::string_view kMainThreadQueryMailboxV1ExecutableSha256 =
    "2D00FF3101EF70B566F2FCBAE292F09263199C80E9DC8F139B82D7D96F83DB86";

// CK3 1.19.0.6 embeds SDL.  The Windows video-device constructor stores the
// exact pump at +0x238; SDL_PumpEvents reaches that slot before event dequeue.
inline constexpr std::uintptr_t kSdlWindowsVideoDevicePumpInstallRva =
    0x3CFE7AB;
inline constexpr std::uintptr_t kSdlPumpEventsRva = 0x3CD3600;
inline constexpr std::uintptr_t kSdlWindowsPumpFunctionRva = 0x3CE41E0;
inline constexpr std::uintptr_t kSdlWindowsPumpFirstPeekCallRva = 0x3CE421C;
inline constexpr std::uintptr_t kSdlWindowsPumpFirstPeekReturnRva = 0x3CE4222;
inline constexpr std::uintptr_t kPeekMessageWIatSlotRva = 0x3FD2EE8;
// HandlePdxEvents calls SDL_PollEvent through this writable process-global
// dispatch slot.  The slot begins at the resolver thunk while CK3 is still
// suspended, then becomes the exact embedded implementation below.  Hooking
// the resolved slot covers frontend frames where SDL_PollEvent intentionally
// skips the lower Windows PeekMessageW pump.
inline constexpr std::uintptr_t kSdlPollEventDispatchSlotRva = 0x4FE0A68;
inline constexpr std::uintptr_t kSdlPollEventResolverThunkRva = 0x3C9B8C0;
inline constexpr std::uintptr_t kSdlPollEventResolvedTargetRva = 0x3CD3730;
inline constexpr std::uintptr_t kHandlePdxEventsSdlPollEventReturnRva =
    0x3A2EEA9;

// The native global RNG wrapper is a generic scoped-owner diagnostic.  It is
// not an admission gate for this application-main-thread boundary: the live
// SDL observation proved the HandlePdxEvents TLS marker while a different
// subsystem owned this wrapper.  The mailbox mirrors the value and never
// draws RNG.
inline constexpr std::uintptr_t kGlobalRngWrapperSlotRva = 0x4FEB1C8;
inline constexpr std::size_t kGlobalRngWrapperStateOffset = 0x00;
inline constexpr std::size_t kGlobalRngOwnerThreadIdOffset = 0x10;
inline constexpr std::uintptr_t kNativeRngOwnerThreadCheckRva = 0x356A0A0;
inline constexpr std::uintptr_t kGetCurrentThreadIdThunkRva = 0x3D00000;
inline constexpr std::uintptr_t kGetCurrentThreadIdIatSlotRva = 0x3FD2570;

// RNG ownership alone is not a main-thread proof: 0x356B600 is a generic
// owner-acquire path.  HandlePdxEvents independently requires this initialized
// global and the current thread's native TLS marker at +0x20.
inline constexpr std::uintptr_t kMainThreadTlsInitializedFlagRva = 0x57727ED;
inline constexpr std::uintptr_t kMainThreadTlsContextGetterRva = 0x3B86430;
inline constexpr std::size_t kMainThreadTlsMarkerOffset = 0x20;
inline constexpr std::uintptr_t kMainThreadTlsStartupStoreRva = 0x7E7CDE;
inline constexpr std::uintptr_t kHandlePdxEventsRva = 0x3A2EC30;
inline constexpr std::uintptr_t kHandlePdxEventsTlsGateRva = 0x3A2EC4D;

inline constexpr std::uintptr_t kJominiStateSlotRva = 0x570F7B8;
inline constexpr std::size_t kJominiPausedOffset = 0x20;
inline constexpr std::uintptr_t kGameStateSlotRva = 0x570E068;
inline constexpr std::size_t kGameStateDateRawOffset = 0x08;

inline constexpr std::uint32_t kMainThreadQueryMaximumDrainPerPump = 1;
inline constexpr std::uint64_t
    kMainThreadQueryMinimumOwnerVerifiedPumpEpochs = 2;
inline constexpr std::uint64_t
    kMainThreadQueryMinimumPausedOwnerVerifiedPumpEpochs = 2;

using PeekMessageWFunctionV1 =
    BOOL(WINAPI *)(LPMSG, HWND, UINT, UINT, UINT);
using SdlPollEventFunctionV1 = int(__cdecl *)(void *event);

struct MainThreadExecutionStampV1 {
  std::uint64_t pump_epoch = 0;
  std::uint32_t thread_id = 0;
  std::uintptr_t rng_wrapper = 0;
  std::uintptr_t rng_state = 0;
  std::uint32_t rng_owner_thread_id = 0;
  std::uintptr_t tls_initialized_flag_address = 0;
  std::uint8_t tls_initialized = 0;
  std::uintptr_t tls_context = 0;
  std::uint8_t tls_main_thread_marker = 0;
  std::uintptr_t jomini_state = 0;
  std::uintptr_t game_state = 0;
  std::int32_t date_raw = 0;
  bool paused = false;

  friend bool operator==(const MainThreadExecutionStampV1 &,
                         const MainThreadExecutionStampV1 &) = default;
};

// Query-specific storage belongs to the bridge worker and must outlive the
// ticket until a terminal state is reclaimed.  The executor runs synchronously
// on the proven CK3 application main thread.  Returning false means only an
// infrastructure/executor failure; a valid query-specific unavailable result
// must be stored in context and return true.
using MainThreadQueryExecutorV1 = bool (*)(
    void *context, const MainThreadExecutionStampV1 &stamp) noexcept;

enum class MainThreadQueryMailboxStateV1 : std::uint32_t {
  detached = 0,
  idle = 1,
  publishing = 2,
  queued = 3,
  executing = 4,
  completed = 5,
  executor_failed = 6,
  cancelled = 7,
  infrastructure_failed = 8,
  detaching = 9,
};

enum MainThreadQueryMailboxFailureV1 : std::uint32_t {
  main_thread_query_failure_none = 0,
  main_thread_query_failure_exact_build = 1U << 0,
  main_thread_query_failure_pump_anchor = 1U << 1,
  main_thread_query_failure_iat_identity = 1U << 2,
  main_thread_query_failure_singleton = 1U << 3,
  main_thread_query_failure_runtime_identity = 1U << 4,
  main_thread_query_failure_thread_identity = 1U << 5,
  main_thread_query_failure_not_paused = 1U << 6,
  main_thread_query_failure_reentry = 1U << 7,
  main_thread_query_failure_request_identity = 1U << 8,
  main_thread_query_failure_executor_exception = 1U << 9,
  main_thread_query_failure_post_execution_drift = 1U << 10,
  main_thread_query_failure_iat_page_identity = 1U << 11,
  main_thread_query_failure_iat_page_protect = 1U << 12,
  main_thread_query_failure_uninstall = 1U << 13,
  main_thread_query_failure_tls_identity = 1U << 14,
};

enum class MainThreadQueryUninstallResultV1 : std::uint32_t {
  uninstalled = 0,
  not_installed = 1,
  request_active = 2,
  iat_restore_failed = 3,
  active_hook_calls_pending = 4,
  wrong_mailbox = 5,
};

enum class MainThreadQuerySubmitResultV1 : std::uint32_t {
  submitted = 0,
  invalid_request = 1,
  mailbox_not_installed = 2,
  paused_main_thread_not_observed = 3,
  mailbox_busy = 4,
  infrastructure_failed = 5,
  executor_submission_disabled = 6,
  application_main_not_observed = 7,
};

enum class MainThreadQueryCancelResultV1 : std::uint32_t {
  cancelled = 0,
  already_terminal = 1,
  executing = 2,
  ticket_mismatch = 3,
};

enum class MainThreadQueryReclaimResultV1 : std::uint32_t {
  reclaimed = 0,
  not_terminal = 1,
  ticket_mismatch = 2,
};

enum class MainThreadQueryWaitResultV1 : std::uint32_t {
  completed = 0,
  executor_failed = 1,
  infrastructure_failed = 2,
  cancelled = 3,
  timeout_cancelled_before_execution = 4,
  timeout_executor_already_running = 5,
  ticket_mismatch = 6,
};

struct MainThreadQueryTicketV1 {
  std::uint64_t sequence = 0;
};

using MainThreadMemoryQueryV1 = bool (*)(
    void *context, const void *address,
    MEMORY_BASIC_INFORMATION &information) noexcept;
using MainThreadMemoryProtectV1 = bool (*)(
    void *context, void *page_address, std::size_t page_size,
    DWORD new_protect, DWORD &old_protect) noexcept;
using MainThreadTlsContextGetterV1 = void *(__fastcall *)() noexcept;

// Queue ownership and IAT lifetime are version independent. Each exact-build
// adapter supplies only the executable-dependent addresses and byte verifier.
// A supplied profile uses its PeekMessageW boundary only; the legacy SDL
// dispatch fallback remains exclusive to the null 1.19.0.6 profile.
using MainThreadPumpAnchorVerifierV1 = bool (*)(
    std::uintptr_t module_base) noexcept;
struct MainThreadQueryBuildProfileV1 {
  std::uintptr_t pump_exact_return_rva = 0;
  std::uintptr_t peek_message_iat_slot_rva = 0;
  std::uintptr_t global_rng_wrapper_slot_rva = 0;
  std::uintptr_t jomini_state_slot_rva = 0;
  std::uintptr_t game_state_slot_rva = 0;
  std::uintptr_t tls_initialized_flag_rva = 0;
  std::uintptr_t tls_context_getter_rva = 0;
  MainThreadPumpAnchorVerifierV1 verify_pump_anchors = nullptr;
};

// The production binder uses module_base plus the frozen RVAs.  The explicit
// override surface exists only so the offline fixture can exercise atomic IAT
// installation and queue state transitions without mapping a 0x5C2D000-byte
// CK3 image.
struct MainThreadQueryInstallEnvironmentV1 {
  std::uintptr_t module_base = 0;
  bool exact_build_admitted = false;
  bool offline_fixture = false;
  void **peek_message_iat_slot_override = nullptr;
  PeekMessageWFunctionV1 resolved_peek_message_override = nullptr;
  std::uintptr_t global_rng_wrapper_slot_override = 0;
  std::uintptr_t jomini_state_slot_override = 0;
  std::uintptr_t game_state_slot_override = 0;
  std::uintptr_t tls_initialized_flag_override = 0;
  MainThreadTlsContextGetterV1 tls_context_getter_override = nullptr;
  void *memory_protection_context = nullptr;
  MainThreadMemoryQueryV1 memory_query_override = nullptr;
  MainThreadMemoryProtectV1 memory_protect_override = nullptr;
  std::size_t system_page_size_override = 0;
  bool executor_submission_enabled = false;
  // At least one slot is non-null in production. These exact typed callback
  // identities prevent the infrastructure from becoming a generic native-call
  // trampoline. V1 has fixed gameplay slots for the bounded war-entry,
  // route-contact, actual-contact, combat-v3, ongoing-battle, full-CombatID
  // lifecycle, campaign-root, loaded-feature, pending-interaction and
  // current-event-window read-only, explicit title-map presentation, B1
  // manager-owned case, received-self result-case, strict B2 PIP and strict
  // received-self incident, fixed ZhongGuo scoreboard-state and fixed
  // Workforce collective/rolling-three-cycle, AI-owned B1 case and Workforce
  // normal-exit/HC lifecycle snapshot and fail-closed scoreboard-action
  // transport executors, the two Phase-2 closed business postconditions, the
  // B3 manager-governance lifecycle snapshot, the fixed career-HC/workforce
  // route-B postcondition, the full B1-cycle snapshot and the private realm-law
  // submit/receipt lifecycle. A
  // separate fixed frontend slot is admitted by application-main ownership
  // without weakening the paused-gameplay admission of these slots.
  MainThreadQueryExecutorV1 permitted_executor = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_secondary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_tertiary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quaternary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quinary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_senary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_septenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_octonary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_nonary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_denary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_undenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_duodenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_thirdenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quattuordenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quindenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sexdenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_septendenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_octodenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_novemdenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_vigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_unvigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_duovigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_trivigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quattuorvigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quinquevigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sexvigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_septemvigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_octovigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_novemvigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_trigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_untrigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_duotrigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_tritrigintary = nullptr;
  // Shared private executor allocation: 34 faction, 35 construction,
  // 36 decision, 37 law, 38 marriage. Empty reserved slots remain typed and
  // cannot be populated by protocol input.
  MainThreadQueryExecutorV1 permitted_executor_quattuortrigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quintrigintary = nullptr;
  // Slot 36 belongs to the private realm-decision application-main lifecycle.
  // Realm-law owns the following fixed slot 37.
  MainThreadQueryExecutorV1 permitted_executor_sextrigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_septentrigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_octotrigintary = nullptr;
  // Fixed slot 39 remains reserved for the scheduled Scheme backend.
  MainThreadQueryExecutorV1 permitted_executor_quadragintary = nullptr;
  // The following fixed slot belongs to the shared Council runtime.
  MainThreadQueryExecutorV1 permitted_executor_unquadragintary = nullptr;
  // Private, read-only G2-M4 holding-view receipt; absent in default builds.
  MainThreadQueryExecutorV1 permitted_executor_duoquadragintary = nullptr;
  // Fixed private LIFE2/LIFE4/LIFE6/LIFE7 executor, absent when its opt-in
  // candidate is disabled. This is not an open native-call slot.
  MainThreadQueryExecutorV1 permitted_executor_trioquadragintary = nullptr;
  // Fixed private, read-only death/succession timeline surface query. Slot 44
  // is protocol-inaccessible except through its one typed executor identity.
  MainThreadQueryExecutorV1 permitted_executor_quattuorquadragintary = nullptr;
  // Fixed private typed succession Close action. Slot 45 is admitted only for
  // its compile-time executor identity and remains absent from capabilities.
  MainThreadQueryExecutorV1 permitted_executor_quinquadragintary = nullptr;
  // Fixed-key, private read-only CE1 treatment presence query (slot 46).
  MainThreadQueryExecutorV1 permitted_executor_sexquadragintary = nullptr;
  // Private exact-build CE1 county recovery list/modifier query (slot 47).
  MainThreadQueryExecutorV1 permitted_executor_septenquadragintary = nullptr;
  // Private, read-only M5 five-candidate alliance projection (slot 48).
  MainThreadQueryExecutorV1 permitted_executor_octoquadragintary = nullptr;
  // Private, read-only minor-religious-war faith defenders (slot 49).
  MainThreadQueryExecutorV1 permitted_executor_novemquadragintary = nullptr;
  // Fixed read-only paused CombatID phase-event evaluator (slot 50).
  MainThreadQueryExecutorV1 permitted_executor_quinquagintary = nullptr;
  // Default-off managed original battle-day trace begin/finish (slots 51/52).
  MainThreadQueryExecutorV1 permitted_executor_unquinquagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_duoquinquagintary = nullptr;
  // Private paused current-player prisoner collection query (slot 53).
  MainThreadQueryExecutorV1 permitted_executor_triquinquagintary = nullptr;
  // Private typed prisoner ransom submit (slot 54), absent by default.
  MainThreadQueryExecutorV1 permitted_executor_quattuorquinquagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quinquinquagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sexquinquagintary = nullptr;
  // Default-off private paused activity-planner diagnostic (slot 57).
  MainThreadQueryExecutorV1 permitted_executor_septenquinquagintary = nullptr;
  // Default-off private typed sway submit/receipt (slot 58).
  MainThreadQueryExecutorV1 permitted_executor_octoquinquagintary = nullptr;
  // Default-off private paused activity stage-1 option read (slot 59).
  MainThreadQueryExecutorV1 permitted_executor_novemquinquagintary = nullptr;
  // Default-off private paused activity stage-5 final CanStart read (slot 60).
  MainThreadQueryExecutorV1 permitted_executor_sexagintary = nullptr;
  // Default-off private paused activity stage-5 named Gold read (slot 61).
  MainThreadQueryExecutorV1 permitted_executor_unsexagintary = nullptr;
  // Default-off private paused feast stage-5 four-resource cost read (slot 62).
  MainThreadQueryExecutorV1 permitted_executor_duosexagintary = nullptr;
  // Default-off private feast stage-2 destination select (slot 63).
  MainThreadQueryExecutorV1 permitted_executor_trisexagintary = nullptr;
  // Default-off private feast Stage-5 inputs, Start and hosted post (slot 64).
  MainThreadQueryExecutorV1 permitted_executor_quattuorsexagintary = nullptr;
  // Default-off read-only feast Stage-5 native-filtered guest (slot 65).
  MainThreadQueryExecutorV1 permitted_executor_quinsexagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sexsexagintary = nullptr;
  // Default-off read-only feast guest opinion of host (slot 67).
  MainThreadQueryExecutorV1 permitted_executor_septensexagintary = nullptr;
  // Fixed current-heir pair query and existing-betrothal fulfillment.
  MainThreadQueryExecutorV1 permitted_executor_octosexagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_novemsexagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_scoped_variable_monitor_executor = nullptr;
  // The frontend route executor is the only fixed callback admitted before a
  // gameplay/Jomini frame exists. It still runs at the exact SDL/CK3
  // application-main boundary and cannot be supplied by protocol data.
  // Fixed private paused actor/army role read; absent in default builds.
  MainThreadQueryExecutorV1 permitted_actor_army_role_executor = nullptr;
  // Fixed H2743 read-only stock predicate callback; no numbered slot reuse.
  MainThreadQueryExecutorV1 permitted_h2743_stock_predicate_executor = nullptr;
  MainThreadQueryExecutorV1 permitted_frontend_executor = nullptr;
  // Optional only for the offline fixture. Production binds the frozen
  // module-relative dispatch slot and resolved function identities above.
  void **sdl_poll_event_slot_override = nullptr;
  SdlPollEventFunctionV1 resolved_sdl_poll_event_override = nullptr;
  // Null retains the complete 1.19.0.6 contract, including existing fixtures.
  const MainThreadQueryBuildProfileV1 *build_profile = nullptr;
  // The 1.20 semantic executor is separate from legacy fixed slot 14.
  MainThreadQueryExecutorV1 permitted_executor_semantic12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_factions12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_warcash12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_family_obligations12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_prewar12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_government12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_holy_order_loan12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_head_of_faith_gold12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_repentance12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_holy_order_context12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_holy_order_selected_title_terms12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_player_mercenary_context12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_player_mercenary_hire12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_regular_maa_create12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_current_actor_stress_adjustment12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_ordinary_interaction12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sway_outcome_opinion12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_ai_reform_inputs12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_draft_doctrine_choices12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_draft_tenet_choices12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_draft_resource_costs12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_draft_groups12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_personal_parameters12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sway_completion_invalidation_reason12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_conversion_outcome12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_conversion_action12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_county_conversion_task_action12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_numeric_special_parameters12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sway_completion_termination12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_conversion_reasons12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sway_completion_execution12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_reform12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_doctrine_catalogue12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sway_completion12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_rite_governance12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_clergy12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_rite_members12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_doctrines12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_hostility12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_doctrine_knowledge12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_tenets12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_conversion12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_conversion_choices12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_conversion_inputs12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_epidemic_treatment12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_epidemic_recovery12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_feast_stage2_confirm12002 = nullptr;
  // Optional read-only observer runs on every valid TLS main-thread pump,
  // including unpaused pumps. Context remains alive until uninstall succeeds.
  MainThreadQueryExecutorV1 snapshot_observer_callback = nullptr;
  void *snapshot_observer_context = nullptr;
};

// Existing executor SEH diagnostics, relative to the loaded game or bridge
// image. Raw process addresses are not published.
enum class MainThreadExecutorExceptionImageV1 : std::uint32_t {
  none,
  game,
  bridge,
  other,
};

struct MainThreadQueryMailboxDiagnosticsV1 {
  MainThreadQueryMailboxStateV1 state =
      MainThreadQueryMailboxStateV1::detached;
  std::uint32_t failure_flags = 0;
  std::uint32_t last_executor_exception_code = 0;
  MainThreadExecutorExceptionImageV1 last_executor_exception_image =
      MainThreadExecutorExceptionImageV1::none;
  std::uint64_t last_executor_exception_rva = 0;
  std::uint64_t pump_epochs = 0;
  std::uint64_t owner_verified_pump_epochs = 0;
  std::uint64_t paused_owner_verified_pump_epochs = 0;
  std::uint64_t published_sequence = 0;
  std::uint64_t executed_requests = 0;
  std::uint64_t executor_started_requests = 0;
  std::uint64_t executor_started_sequence = 0;
  std::uint64_t executor_started_pump_epoch = 0;
  std::uint64_t completed_sequence = 0;
  std::uint32_t owner_thread_id = 0;
  std::uint32_t observed_current_thread_id = 0;
  std::uint32_t observed_rng_owner_thread_id = 0;
  std::uintptr_t observed_tls_context = 0;
  std::uintptr_t observed_jomini_state = 0;
  std::uintptr_t observed_game_state = 0;
  std::int32_t observed_date_raw = 0;
  std::uint8_t observed_tls_initialized = 0;
  std::uint8_t observed_tls_main_thread_marker = 0;
  bool observed_paused = false;
  bool observed_stamp_read_success = false;
  std::uint32_t active_hook_calls = 0;
  bool iat_installed = false;
  bool sdl_poll_event_hook_installed = false;
  std::uintptr_t observed_sdl_poll_event_target = 0;
  bool stop_requested = false;
  bool executor_submission_enabled = false;
  bool application_main_observed = false;
  bool paused_main_thread_observed = false;
  bool ready = false;
};

struct MainThreadQueryMailboxV1 {
  std::atomic<MainThreadQueryMailboxStateV1> state{
      MainThreadQueryMailboxStateV1::detached};
  std::atomic<std::uint32_t> failure_flags{0};
  std::atomic<std::uint32_t> last_executor_exception_code{0};
  std::atomic<MainThreadExecutorExceptionImageV1> last_executor_exception_image{
      MainThreadExecutorExceptionImageV1::none};
  std::atomic<std::uint64_t> last_executor_exception_rva{0};
  std::atomic<std::uint64_t> next_sequence{0};
  std::atomic<std::uint64_t> published_sequence{0};
  std::atomic<std::uint64_t> completed_sequence{0};
  std::atomic<std::uint64_t> pump_epochs{0};
  std::atomic<std::uint64_t> owner_verified_pump_epochs{0};
  std::atomic<std::uint64_t> paused_owner_verified_pump_epochs{0};
  std::atomic<std::uint64_t> executor_started_requests{0};
  std::atomic<std::uint64_t> executor_started_sequence{0};
  std::atomic<std::uint64_t> executor_started_pump_epoch{0};
  std::atomic<std::uint64_t> executed_requests{0};
  std::atomic<std::uint32_t> owner_thread_id{0};
  std::atomic<std::uint32_t> observed_current_thread_id{0};
  std::atomic<std::uint32_t> observed_rng_owner_thread_id{0};
  std::atomic<std::uintptr_t> observed_tls_context{0};
  std::atomic<std::uintptr_t> observed_jomini_state{0};
  std::atomic<std::uintptr_t> observed_game_state{0};
  std::atomic<std::int32_t> observed_date_raw{0};
  std::atomic<std::uint8_t> observed_tls_initialized{0};
  std::atomic<std::uint8_t> observed_tls_main_thread_marker{0};
  std::atomic<bool> observed_paused{false};
  std::atomic<bool> observed_stamp_read_success{false};
  std::atomic<std::uint32_t> active_hook_calls{0};
  std::atomic<bool> stop_requested{false};
  std::atomic<bool> iat_hook_installed{false};
  std::atomic<bool> sdl_poll_event_hook_installed{false};
  std::atomic<std::uintptr_t> observed_sdl_poll_event_target{0};
  std::atomic<bool> proof_reset_requested{false};
  std::atomic_flag drain_guard = ATOMIC_FLAG_INIT;

  // Immutable after successful installation.
  std::uintptr_t module_base = 0;
  std::uintptr_t pump_exact_return_rva = kSdlWindowsPumpFirstPeekReturnRva;
  // Zero disables the legacy SDL boundary for an exact-build profile.
  std::uintptr_t sdl_poll_event_exact_return_rva =
      kHandlePdxEventsSdlPollEventReturnRva;
  void **peek_message_iat_slot = nullptr;
  PeekMessageWFunctionV1 original_peek_message = nullptr;
  void **sdl_poll_event_slot = nullptr;
  SdlPollEventFunctionV1 original_sdl_poll_event = nullptr;
  std::uintptr_t global_rng_wrapper_slot = 0;
  std::uintptr_t jomini_state_slot = 0;
  std::uintptr_t game_state_slot = 0;
  std::uintptr_t tls_initialized_flag = 0;
  MainThreadTlsContextGetterV1 tls_context_getter = nullptr;
  void *memory_protection_context = nullptr;
  MainThreadMemoryQueryV1 memory_query = nullptr;
  MainThreadMemoryProtectV1 memory_protect = nullptr;
  std::size_t system_page_size = 0;
  bool offline_fixture = false;
  bool executor_submission_enabled = false;
  MainThreadQueryExecutorV1 permitted_executor = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_secondary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_tertiary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quaternary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quinary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_senary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_septenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_octonary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_nonary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_denary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_undenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_duodenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_thirdenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quattuordenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quindenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sexdenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_septendenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_octodenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_novemdenary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_vigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_unvigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_duovigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_trivigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quattuorvigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quinquevigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sexvigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_septemvigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_octovigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_novemvigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_trigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_untrigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_duotrigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_tritrigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quattuortrigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quintrigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sextrigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_septentrigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_octotrigintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quadragintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_unquadragintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_duoquadragintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_trioquadragintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quattuorquadragintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quinquadragintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sexquadragintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_septenquadragintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_octoquadragintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_novemquadragintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quinquagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_unquinquagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_duoquinquagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_triquinquagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quattuorquinquagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quinquinquagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sexquinquagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_septenquinquagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_octoquinquagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_novemquinquagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sexagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_unsexagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_duosexagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_trisexagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quattuorsexagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_quinsexagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sexsexagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_septensexagintary = nullptr;
  // Fixed current-heir pair query and existing-betrothal fulfillment.
  MainThreadQueryExecutorV1 permitted_executor_octosexagintary = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_novemsexagintary = nullptr;
  // Fixed private paused actor/army role read; absent in default builds.
  MainThreadQueryExecutorV1 permitted_actor_army_role_executor = nullptr;
  MainThreadQueryExecutorV1 permitted_scoped_variable_monitor_executor = nullptr;
  MainThreadQueryExecutorV1 permitted_h2743_stock_predicate_executor = nullptr;
  MainThreadQueryExecutorV1 permitted_frontend_executor = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_semantic12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_factions12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_warcash12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_family_obligations12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_prewar12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_government12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_holy_order_loan12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_head_of_faith_gold12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_repentance12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_holy_order_context12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_holy_order_selected_title_terms12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_player_mercenary_context12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_player_mercenary_hire12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_regular_maa_create12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_current_actor_stress_adjustment12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_ordinary_interaction12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sway_outcome_opinion12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_ai_reform_inputs12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_draft_doctrine_choices12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_draft_tenet_choices12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_draft_resource_costs12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_draft_groups12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_personal_parameters12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sway_completion_invalidation_reason12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_conversion_outcome12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_conversion_action12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_county_conversion_task_action12003 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_numeric_special_parameters12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sway_completion_termination12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_conversion_reasons12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sway_completion_execution12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_reform12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_doctrine_catalogue12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_sway_completion12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_rite_governance12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_clergy12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_rite_members12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_doctrines12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_hostility12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_doctrine_knowledge12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_tenets12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_conversion12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_conversion_choices12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_religion_conversion_inputs12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_epidemic_treatment12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_epidemic_recovery12002 = nullptr;
  MainThreadQueryExecutorV1 permitted_executor_feast_stage2_confirm12002 = nullptr;
  MainThreadQueryExecutorV1 snapshot_observer_callback = nullptr;
  void *snapshot_observer_context = nullptr;

  // Written only inside the exact-return drain guard.  The worker consumes
  // only the atomic consecutive count; this stamp never crosses threads.
  MainThreadExecutionStampV1 last_verified_stamp{};
  bool last_verified_stamp_valid = false;
  MainThreadExecutionStampV1 last_owner_verified_stamp{};
  bool last_owner_verified_stamp_valid = false;

  // Single-producer/single-consumer slot.  The publishing/queued release-store
  // is the ownership boundary for these plain fields.
  MainThreadQueryExecutorV1 executor = nullptr;
  void *executor_context = nullptr;
  bool executor_succeeded = false;
  MainThreadExecutionStampV1 execution_stamp{};
};

bool InstallMainThreadQueryMailboxV1(
    MainThreadQueryMailboxV1 &mailbox,
    const MainThreadQueryInstallEnvironmentV1 &environment) noexcept;

// The exact SDL slot is still a resolver thunk while the managed launcher has
// CK3 suspended. Worker heartbeat and frontend submission retry this bounded
// CAS after the game resolves the slot; no game function is called here.
bool TryInstallMainThreadFrontendBoundaryHookV1(
    MainThreadQueryMailboxV1 &mailbox) noexcept;

// WorkerMain owns installation and must call this on every return path before
// XarCk3BridgeStop resets its worker lifecycle.  Success means the IAT contains
// the original PeekMessageW and every hook invocation already counted has
// returned.  It does NOT make FreeLibrary safe: a thread can have fetched the
// old IAT target without entering the hook yet.  V1 therefore pins this module,
// the mailbox and the original function pointer until CK3 process exit.  A
// timeout keeps the bridge lifecycle in stopping and may be retried.
MainThreadQueryUninstallResultV1 UninstallMainThreadQueryMailboxV1(
    MainThreadQueryMailboxV1 &mailbox,
    std::uint32_t active_call_drain_timeout_milliseconds) noexcept;

// PROCESS_DETACH may only signal.  It must never wait under the loader lock.
// Normal bridge shutdown still requires UninstallMainThreadQueryMailboxV1.
void SignalMainThreadQueryMailboxProcessDetachV1(
    MainThreadQueryMailboxV1 &mailbox) noexcept;

// Optional observation for queued application-main waits. A wake is the
// existing inert WM_NULL thread message; it never executes a gameplay step.
struct MainThreadQueryQueuedWakeTraceV1 {
  // Captured on the initial post; queued reposts cannot follow a new owner.
  std::uint32_t owner_thread_id = 0;
  std::uint64_t pump_epoch_at_start = 0;
  std::uint64_t pump_epoch_at_end = 0;
  std::uint32_t wake_attempts = 0;
  std::uint32_t wake_succeeded = 0;
  std::uint32_t wake_failed = 0;
  std::uint32_t last_wake_error = 0;
};

MainThreadQuerySubmitResultV1 TrySubmitMainThreadQueryV1(
    MainThreadQueryMailboxV1 &mailbox, MainThreadQueryExecutorV1 executor,
    void *context, MainThreadQueryTicketV1 &ticket,
    MainThreadQueryQueuedWakeTraceV1 *queued_wake_trace = nullptr) noexcept;

MainThreadQueryCancelResultV1 CancelMainThreadQueryV1(
    MainThreadQueryMailboxV1 &mailbox,
    const MainThreadQueryTicketV1 &ticket) noexcept;

// The timeout can atomically cancel only a still-queued request.  Once the
// main thread owns the slot, the executor must finish synchronously and the
// caller must retain context until a later terminal observation/reclaim.
MainThreadQueryWaitResultV1 WaitForMainThreadQueryV1(
    MainThreadQueryMailboxV1 &mailbox,
    const MainThreadQueryTicketV1 &ticket,
    std::uint32_t timeout_milliseconds,
    MainThreadQueryQueuedWakeTraceV1 *queued_wake_trace = nullptr,
    std::uint32_t queued_wake_interval_milliseconds = 0) noexcept;

MainThreadQueryReclaimResultV1 ReclaimMainThreadQueryV1(
    MainThreadQueryMailboxV1 &mailbox,
    const MainThreadQueryTicketV1 &ticket) noexcept;

// Exact boundary surface used by the IAT hook and deterministic fixtures.
// It drains at most one request and returns true only when an executor ran.
bool ObserveMainThreadPumpAndDrainV1(
    MainThreadQueryMailboxV1 &mailbox, std::uintptr_t return_rva,
    std::uint32_t current_thread_id) noexcept;

MainThreadQueryMailboxDiagnosticsV1 ReadMainThreadQueryMailboxDiagnosticsV1(
    const MainThreadQueryMailboxV1 &mailbox) noexcept;

// Shared by the existing typed-failure and mailbox diagnostic JSON blocks.
std::string SerializeMainThreadExecutorExceptionDiagnosticV1(
    const MainThreadQueryMailboxDiagnosticsV1 &diagnostics);

extern "C" BOOL WINAPI XarMainThreadPeekMessageWHookV1(
    LPMSG message, HWND window, UINT minimum_filter, UINT maximum_filter,
    UINT remove_message) noexcept;

extern "C" int __cdecl XarMainThreadSdlPollEventHookV1(void *event) noexcept;

} // namespace xar::ck3_11906
