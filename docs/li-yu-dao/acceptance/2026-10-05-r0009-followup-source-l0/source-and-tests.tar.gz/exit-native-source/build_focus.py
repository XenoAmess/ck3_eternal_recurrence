import hashlib
import json
import os
import subprocess
import time
from pathlib import Path
root = Path(__file__).resolve().parent
attempt = root / 'focused-build-001'
attempt.mkdir(exist_ok=False)
vcvars = Path('C:/Program Files/Microsoft Visual Studio/18/Community/VC/Auxiliary/Build/vcvarsall.bat')
cmake = Path('C:/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe')
assert vcvars.is_file() and cmake.is_file()
batch = attempt / 'environment.bat'
batch.write_bytes(('@echo off\r\ncall "' + str(vcvars) + '" x64 >nul\r\nif errorlevel 1 exit /b 1\r\nset\r\n').encode())
proc = subprocess.run(['cmd.exe', '/d', '/c', str(batch)], capture_output=True, text=True, encoding='utf-8', errors='replace')
(attempt / 'environment.stderr.txt').write_bytes(proc.stderr.encode())
assert proc.returncode == 0, proc.stderr
environment = dict(os.environ)
for line in proc.stdout.splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1); environment[key] = value
def run(label, argv):
    start = time.time()
    process = subprocess.run([str(a) for a in argv], env=environment, capture_output=True, text=True, encoding='utf-8', errors='replace')
    (attempt / (label + '.stdout.txt')).write_bytes(process.stdout.encode())
    (attempt / (label + '.stderr.txt')).write_bytes(process.stderr.encode())
    receipt = {'argv': [str(a) for a in argv], 'returncode': process.returncode, 'elapsed_seconds': time.time() - start}
    (attempt / (label + '.receipt.json')).write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
    print(label, process.returncode, process.stdout[-2000:], process.stderr[-1500:], flush=True)
    if process.returncode: raise SystemExit(process.returncode)
build = Path('C:/nec1b1')
run('configure', [cmake, '-S', 'C:/nec1', '-B', build, '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Debug', '-DBUILD_TESTING=ON'])
run('build', [cmake, '--build', build, '--parallel', '8'])
run('gates', [build / 'xar_ck3_normal_exit_map_continuation_v1_test.exe'])
run('ctest', [cmake.parent / 'ctest.exe', '--test-dir', build, '--output-on-failure'])
exe = build / 'xar_ck3_normal_exit_map_continuation_v1_test.exe'
artifact = {'path': str(exe), 'bytes': exe.stat().st_size, 'sha256': hashlib.sha256(exe.read_bytes()).hexdigest(), 'source_inputs': str(root / 'FOCUSED-INPUTS.json'), 'source_l0_only': True, 'native_provider_or_game_execution': False, 'new_DLL': False, 'Defender_settings_registered': None}
(attempt / 'ARTIFACT.json').write_bytes((json.dumps(artifact, indent=2) + '\n').encode())
print(json.dumps(artifact, indent=2))
