# 新预览与历史增长测试的 CI 接入候选

当前两个新增测试都未列入 CI。最小候选只改两份 workflow，保留原 job、触发规则、依赖版本和现有测试。主树尚未应用，本轮不运行测试，新 HEAD 为 `NULL`；`54457b371…` 的成功不计入这些未提交代码。

- 礼与道：在现有产品检查中执行 `test_c2_preview_scope.py --report /tmp/lyd-c2-preview-scope.json`；把此 JSON 加入已有 always artifact。`mod_li_yu_dao/**` 已覆盖预览测试、触发器和事件，无需扩大路径规则。
- 通用：在现有 public CUnit SDK 块之后执行 history growth 的 unittest discovery，并保留 CMD 返回码检查。该块已经安装 `mcp==2.0.0`，四项 PYTHONPATH 已包含 src/unit/tools，无需安装带 GPU/OCR 依赖的整个 autoplayer。新增一个 always artifact 保存该测试产生的 create-only 原始材料。

History growth 源码定义 4 个测试，包含 64/64 次线性增长、8 次旧实现对照和 32 次官方 SDK 内存服务调用；这些是源码 fixture 回归，不能记作游戏调用。C2 默认命令运行当前源的 guarded/eager evaluator 和 mutation 检查；没有传入 `--baseline`，因此可选的旧源码全 AST/字节等同性比较不会在此命令中获得信用。现有 106 项同意流程测试继续执行。全部预览和 tooltip 引擎行为仍需新的实机验收。

[精确改动](DELTA.json) 与 [最小补丁](MINIMAL-CI-ROUTING.patch) 绑定两份当前 workflow 的 before/after bytes/SHA。ROOT 应确认 before SHA 仍匹配后应用候选；所有原有测试和全套 war 相关步骤保留。
