"""Record ROOT's directly reviewed offline frame, installed update and Git state."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,re,subprocess,sys,psutil
base=Path(__file__).parent;out=base/'FINAL-001';out.mkdir()
repo=Path('C:/workspace/ck3_eternal_recurrence')
def ref(p):
    d=p.read_bytes();return {'path':p.as_posix(),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
def run(argv,name):
    start=datetime.now(timezone.utc).isoformat();r=subprocess.run(argv,cwd=repo,capture_output=True)
    (out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
    rec={'argv':argv,'started_at_utc':start,'completed_at_utc':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode,'stdout':ref(out/(name+'.stdout')),'stderr':ref(out/(name+'.stderr'))}
    (out/(name+'.actual.json')).write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    if r.returncode:raise ValueError(name+' failed')
    return r.stdout.decode('utf8',errors='replace').strip()
head=run(['git','rev-parse','HEAD'],'HEAD');remote=run(['git','ls-remote','origin','refs/heads/master'],'REMOTE')
status=run(['git','status','--porcelain=v1'],'STATUS')
if status:raise ValueError('Git worktree not clean')
exe=Path('C:/Program Files (x86)/Steam/steamapps/common/Crusader Kings III/binaries/ck3.exe');manifest=exe.parents[3]/'appmanifest_1158310.acf'
data=manifest.read_bytes();(out/'appmanifest_1158310.acf').write_bytes(data);text=data.decode('utf8');fields=dict(re.findall(r'"([^"\n]+)"\s+"([^"\n]*)"',text))
for k,v in {'appid':'1158310','StateFlags':'4','buildid':'25734779','TargetBuildID':'25734779','UpdateResult':'0','StagingSize':'0'}.items():
    if fields.get(k)!=v:raise ValueError('Installed Steam state mismatch: '+k)
for x,y in [('BytesDownloaded','BytesToDownload'),('BytesStaged','BytesToStage')]:
    if fields.get(x)!=fields.get(y):raise ValueError('Update incomplete')
er=ref(exe)
if er['sha256']!='98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518':raise ValueError('New EXE identity mismatch')
if any((p.info['name'] or '').lower()=='ck3.exe' for p in psutil.process_iter(['name'])):raise ValueError('Unexpected CK3 process')
frame=base/'final-offline-frame-001/probe-1/steam-moved.png'
review={'observed_at_utc':datetime.now(timezone.utc).isoformat(),'reviewer':'ROOT','method':'view_image(original), direct visual review','image':ref(frame),'steam_offline_text':'离线模式','desktop_clock_observed':'14:11 2026/10/7','steam_window_observed_shifted_right':True,'freshness_receipt':ref(base/'final-offline-frame-001/probe-1/steam-frame-freshness.json'),'offline_confirmed':True,'image_dimensions':[1920,1080]}
(out/'OFFLINE-VISUAL-REVIEW.actual.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
summary={'observed_at_utc':datetime.now(timezone.utc).isoformat(),'installed_steam_build':fields['buildid'],'new_exe':er,'manifest':ref(out/'appmanifest_1158310.acf'),'before_preserved':ref(base/'installed-before-update/BEFORE.actual.json'),'public_patch_version':'1.20.0.4','public_patch_version_basis':'exact EXE and build match checked-in 1.20.0.4 adapter; public game runtime display not yet observed','pe_file_version_caveat':'BEFORE game_file_version 1.0.0.0 is generic PE FileVersion, not CK3 public patch','main_head':head,'remote_master':remote.split()[0],'worktree_clean':not status,'steam_offline_review':ref(out/'OFFLINE-VISUAL-REVIEW.actual.json'),'ck3_process_count':0,'original_goal_status':'NOT_GREEN','new_version_native_acceptance':None}
(out/'UPDATE-AND-GIT.actual.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(summary,ensure_ascii=False))
run([sys.executable,'-B','-X','utf8','tools/codex_task_bus.py','--bus-dir','C:/workspace/.codex-task-bus','--expected-cli-sha256','B3C44B42F7BDF401B593D863E3210106A46412DCD7D89F8596C74F4C27392DEE','release-screen-cas','--task','ck3-local-update-20261007-001','--expected-sequence','3574','--summary','CK3 build25734779已安装，Steam新鲜图已离线，主树已快进更新，继续原任务'],'RELEASE-SCREEN')
print('Upgrade screen lease released.')
