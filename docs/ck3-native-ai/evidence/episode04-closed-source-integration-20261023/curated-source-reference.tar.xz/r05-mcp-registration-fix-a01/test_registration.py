"""Registration and official stdio protocol tests; no business tool is called."""
from __future__ import annotations
import asyncio
import hashlib
import inspect
import json
import os
from pathlib import Path
import sys
import unittest
from mcp import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client
from mcp.server import MCPServer
from mcp.server.mcpserver.exceptions import InvalidSignature
from mcp.types import CallToolResult, ListToolsResult, TextContent
from pydantic import ValidationError
from registration_fixture import NoNativeEndpoint, create_fixture
from progress_boundary import load_module
from progress_contract import Pin, pin
from progress_driver import ProgressDailyDriver
from progress_mcp import Service
from typing import Protocol, runtime_checkable
from xar_autoplayer.bridge.service import GameplayBridgeService
from registration_result import concrete_result
from unittest.mock import patch
from r05_runtime_public_a03 import RemotePort
from registration_host import tool_payload

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent/"r05/progress-source-a01"

class SDKFixtureClient:
    def __init__(self, output: Path) -> None:
        self.output = output
        self.result = CallToolResult(content=[])
        self.calls = 0
    def guard(self, reserve: float = 0) -> None:
        pass
    def execute_plan(self, plans: list[dict[str,object]], identifier: str, *, timeout: int) -> list[dict[str,object]]:
        self.calls += 1
        # The existing host consumer sees official SDK camelCase JSON, not a hand-transcribed payload.
        transported = json.loads(self.result.model_dump_json(by_alias=True))
        row: dict[str,object] = {"id":identifier,"ok":not self.result.is_error,"result":tool_payload(transported)}
        if self.result.is_error: row["error"] = "test-only original SDK error"
        rows = [row]
        (self.output/(identifier+".actual-results.json")).write_text(json.dumps({"rows":rows}),encoding="utf-8")
        return rows

@runtime_checkable
class OldBuilder(Protocol):
    def create_server(self, driver: ProgressDailyDriver, *, service_override: GameplayBridgeService,
                      profile_dir: Path | None = None) -> MCPServer: ...

class Registration(unittest.TestCase):
    def test_old_real_official_registration_reproduces_missing_global(self) -> None:
        endpoint = NoNativeEndpoint()
        driver = ProgressDailyDriver(endpoint.pipe_name,endpoint=endpoint,
                                     state_dir=ROOT/"negative-test-only",episode_projection="native_campaign")
        builder = load_module(pin(OLD/"progress_scoped_server.py"),"xar_autoplayer.bridge.r05_old_registration_negative")
        self.assertIsInstance(builder,OldBuilder)
        if not isinstance(builder,OldBuilder):
            raise AssertionError("Original builder interface")
        try:
            with self.assertRaises(InvalidSignature) as caught:
                builder.create_server(driver,service_override=GameplayBridgeService(driver))
            self.assertIsInstance(caught.exception.__cause__,NameError)
            self.assertIn("CallToolResult",str(caught.exception.__cause__))
            self.assertEqual(endpoint.sends,0)
        finally:
            driver.close()

    def test_complete_real_builder_all_signatures_and_strict_tool_inputs(self) -> None:
        server,endpoint,driver = create_fixture(ROOT/"positive-test-only")
        try:
            tools = server._tool_manager.list_tools()
            names = {tool.name for tool in tools}
            self.assertIn("ck3_auto_turn",names)
            self.assertIn("ck3_begin_r05_progress_v1",names)
            self.assertIn("ck3_query_r05_army_strengths_v1",names)
            self.assertGreater(len(names),100)
            for tool in tools:
                inspect.signature(tool.fn,eval_str=True)
            begin_tool = server._tool_manager.get_tool("ck3_begin_r05_progress_v1")
            if begin_tool is None: raise AssertionError("Actual registered progress tool")
            valid: dict[str,object] = {"scope_path":"test-only","scope_bytes":1,"scope_sha256":"a"*64,"expected_revision":"1"}
            begin_tool.fn_metadata.arg_model.model_validate(valid)
            for wrong in (True,1.0,None):
                with self.assertRaises(ValidationError):
                    begin_tool.fn_metadata.arg_model.model_validate({**valid,"scope_bytes":wrong})
            print("REAL_REGISTERED_TOOL_COUNT",len(names))
            self.assertEqual(endpoint.sends,0)
        finally:
            driver.close()

    def test_concrete_return_JSON_roundtrip_and_invalid_content(self) -> None:
        value = CallToolResult(content=[TextContent(type="text",text="Test-only original type")],
                               structured_content={"test_only":True,"ordinary_business_calls":0})
        encoded = value.model_dump_json(by_alias=True)
        restored = CallToolResult.model_validate_json(encoded)
        self.assertEqual(restored,value)
        self.assertEqual(json.loads(encoded)["structuredContent"]["ordinary_business_calls"],0)
        self.assertIs(concrete_result(value),value)
        error = CallToolResult(content=[],is_error=True,structured_content={"status":"unknown"})
        self.assertIs(concrete_result(error),error)
        self.assertTrue(concrete_result(error).is_error)
        original: dict[str,object] = {"status":"test-only","nested":{"missing_is_absent":True,"nullable":None},"rows":[]}
        converted = concrete_result(original)
        self.assertEqual(json.loads(converted.model_dump_json(by_alias=True))["structuredContent"],original)
        with self.assertRaises(ValueError): concrete_result({"not_json":(1,2)})
        with self.assertRaises(ValidationError):
            CallToolResult.model_validate({"content":[{"type":"text","text":None}]})

    def test_official_stdio_initialize_list_tools_no_business(self) -> None:
        async def run() -> None:
            parameters = StdioServerParameters(command=sys.executable,
                args=["-B","-X","utf8",str(ROOT/"registration_fixture.py")],
                env={"PYTHONPATH":os.environ["PYTHONPATH"],"PYTHONDONTWRITEBYTECODE":"1"},cwd=ROOT)
            stderr_path = ROOT/("stdio-server-"+os.environ["R05_REGISTRATION_STDIO_TAG"]+".stderr.txt")
            with stderr_path.open("x",encoding="utf-8") as errors:
                async with stdio_client(parameters,errlog=errors) as (read,write):
                    async with ClientSession(read,write) as session:
                        initialized = await session.initialize()
                        result = await session.list_tools()
                        names = {tool.name for tool in result.tools}
                        self.assertGreater(len(names),100)
                        self.assertIn("ck3_auto_turn",names)
                        self.assertIn("ck3_query_r05_army_strengths_v1",names)
                        encoded = result.model_dump_json(by_alias=True)
                        self.assertEqual(ListToolsResult.model_validate_json(encoded),result)
                        print("OFFICIAL_STDIO_INITIALIZE_LIST_TOOLS",initialized.protocol_version,len(names),
                              "JSON_bytes",len(encoded.encode()),"JSON_sha256",hashlib.sha256(encoded.encode()).hexdigest())
            text = stderr_path.read_text(encoding="utf-8")
            lines = [line for line in text.splitlines() if line.startswith("TEST_ONLY_NATIVE_ENDPOINT=")]
            self.assertEqual(len(lines),1)
            actual = json.loads(lines[0].split("=",1)[1])
            self.assertEqual(actual,{"test_only":True,"native_endpoint_starts":1,"native_sends":0,
                                     "endpoint_closes":1,"real_native_pipe_created":False,"Game_started":False})
            self.assertLess(len(text.encode()),65536)
        asyncio.run(run())

    def test_actual_wrapper_official_JSON_existing_host_and_RemotePort_consumer(self) -> None:
        server,endpoint,driver = create_fixture(ROOT/"wrapper-test-only")
        output = ROOT/("wrapper-output-"+os.environ["R05_REGISTRATION_STDIO_TAG"])
        output.mkdir(exist_ok=False)
        client = SDKFixtureClient(output)
        port = RemotePort({"run_id":"test-only-not-an-allocation","output":str(output)},client)
        public = server._tool_manager.get_tool("ck3_auto_turn")
        if public is None: raise AssertionError("Real registered wrapper missing")
        error = CallToolResult.model_validate({"content":[],"isError":True,"structuredContent":{"status":"unknown"},
                                              "_meta":{"test_only_preserved":True}})
        original: dict[str,object] = {"status":"test-only-known","nullable":None,"rows":[]}
        try:
            for producer in (original,error):
                # Explicit no-world operation seam; wrapper and official result/host consumers are real.
                with patch("progress_governor.run_auto_turn",return_value=producer):
                    returned: object = public.fn()
                self.assertIsInstance(returned,CallToolResult)
                if not isinstance(returned,CallToolResult): raise AssertionError("Concrete public result")
                client.result = CallToolResult.model_validate_json(returned.model_dump_json(by_alias=True))
                if producer is error:
                    self.assertIs(returned,error)
                    self.assertEqual(client.result.meta,{"test_only_preserved":True})
                    with self.assertRaises(ValueError): port.request("ck3_auto_turn",{})
                else:
                    self.assertEqual(port.request("ck3_auto_turn",{}),original)
            self.assertEqual(client.calls,2)
            self.assertEqual(endpoint.sends,0)
        finally:
            driver.close()

if __name__ == "__main__":
    unittest.main(verbosity=2)
