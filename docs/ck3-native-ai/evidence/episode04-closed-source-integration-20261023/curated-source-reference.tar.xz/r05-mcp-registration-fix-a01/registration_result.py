"""Concrete SDK return envelope; original payload and error identity retained."""
from __future__ import annotations
import json
import math
from typing import TypeAlias
from mcp.types import CallToolResult, TextContent

Json: TypeAlias = None | bool | int | float | str | list["Json"] | dict[str,"Json"]

def json_domain(value: object) -> Json:
    if value is None or isinstance(value,(bool,int,str)):
        return value
    if isinstance(value,float) and math.isfinite(value):
        return value
    if isinstance(value,list):
        return [json_domain(part) for part in value]
    if isinstance(value,dict):
        result: dict[str,Json] = {}
        for key,part in value.items():
            if not isinstance(key,str): raise ValueError("Return JSON keys must be strings")
            result[key] = json_domain(part)
        return result
    raise ValueError("Return value is outside the explicit JSON domain")

def concrete_result(value: dict[str,object] | CallToolResult) -> CallToolResult:
    if isinstance(value,CallToolResult):
        return value
    payload = json_domain(value)
    if not isinstance(payload,dict):
        raise ValueError("Original ordinary result must be an object")
    return CallToolResult(content=[TextContent(type="text",text=json.dumps(payload,ensure_ascii=False,allow_nan=False))],
                          structured_content=payload)
