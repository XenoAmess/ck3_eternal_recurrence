"""Single wire contract for the first B clip; planning is not execution admission."""
from __future__ import annotations
from dataclasses import asdict, dataclass
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re

MACHINE = 'desktop-3fevhd2-1c74096080'
TOTAL = 128 * 1024 * 1024
CONTACTS = 64 * 1024 * 1024
KEYFRAMES = 24 * 1024 * 1024
METADATA = 8 * 1024 * 1024
CONTROL = 4 * 1024 * 1024


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def integer(value: object, name: str, low: int = 0, high: int = 2**53 - 1) -> int:
    if type(value) is not int or not low <= value <= high:
        raise ValueError(name + ': strict integer outside bounds')
    return value


def text(value: object, name: str) -> str:
    if type(value) is not str or not value or '\x00' in value:
        raise ValueError(name + ': nonempty text required')
    return value


def decimal64(value: object, name: str) -> str:
    result = text(value, name)
    need(re.fullmatch(r'0|[1-9][0-9]*', result) is not None and int(result) < 2**64,
         name + ': canonical unsigned decimal64 required')
    return result


def object_map(value: object, name: str) -> dict[str, object]:
    if not isinstance(value, dict):
        raise ValueError(name + ': object required')
    result: dict[str, object] = {}
    for key, entry in value.items():
        if type(key) is not str:
            raise ValueError(name + ': text keys required')
        result[key] = entry
    return result


def load(path: Path) -> dict[str, object]:
    need(path.stat().st_size <= 65536, 'Small JSON input exceeds 64KiB')
    value: object = json.loads(path.read_bytes())
    return object_map(value, str(path))


@dataclass(frozen=True)
class Pin:
    path: str
    bytes: int
    sha256: str

    @classmethod
    def parse(cls, value: object) -> Pin:
        row = object_map(value, 'FilePin')
        path = text(row.get('path'), 'path')
        need(Path(path).is_absolute(), 'Absolute source path required')
        sha = text(row.get('sha256'), 'sha256')
        need(re.fullmatch('[0-9a-f]{64}', sha) is not None, 'Canonical SHA256 required')
        return cls(path, integer(row.get('bytes'), 'bytes'), sha)

    @classmethod
    def read(cls, path: Path) -> Pin:
        digest = hashlib.sha256()
        count = 0
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1048576), b''):
                count += len(block)
                digest.update(block)
        return cls(str(path), count, digest.hexdigest())

    def verify(self) -> None:
        need(Pin.read(Path(self.path)) == self, 'FilePin changed: ' + self.path)

    def wire(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class Binding:
    machine_id: str
    run_id: str
    episode_id: str
    game_pid: int
    process_birth_filetime: str
    player_full_id: str
    date_before: str
    date_after: str
    recorder_closed: Pin
    callback_before: Pin
    callback_after: Pin
    date_before_receipt: Pin
    date_after_receipt: Pin

    @classmethod
    def parse(cls, value: object) -> Binding:
        row = object_map(value, 'source binding')
        need(row.get('schema') == 'xar.r17.firstclip-source-binding.v1', 'Binding schema differs')
        need(row.get('machine_id') == MACHINE, 'Binding machine differs')
        refs = [Pin.parse(row.get(key)) for key in ('recorder_closed', 'callback_before',
                'callback_after', 'date_before_receipt', 'date_after_receipt')]
        return cls(MACHINE, text(row.get('run_id'), 'run_id'),
                   text(row.get('episode_id'), 'episode_id'),
                   integer(row.get('game_pid'), 'game_pid', 1, 2**32 - 1),
                   decimal64(row.get('process_birth_filetime'), 'process birth'),
                   decimal64(row.get('player_full_id'), 'player id'),
                   text(row.get('date_before'), 'date_before'), text(row.get('date_after'), 'date_after'),
                   *refs)

    def refs(self) -> tuple[Pin, ...]:
        return (self.recorder_closed, self.callback_before, self.callback_after,
                self.date_before_receipt, self.date_after_receipt)


@dataclass(frozen=True)
class Recipe:
    output_root: Path
    hard_deadline_utc: str
    raw: Pin
    source_binding: Pin
    runner: Pin
    contract: Pin
    job_helper: Pin
    ffmpeg: Pin
    ffprobe: Pin
    font: Pin
    width: int
    height: int
    expected_audio_streams: int
    expected_video_frames: int
    keyframe_indices: tuple[int, ...]

    @classmethod
    def parse(cls, value: object) -> Recipe:
        row = object_map(value, 'recipe')
        need(row.get('schema') == 'xar.r17.firstclip-qa-recipe.v1', 'Recipe schema differs')
        need(row.get('machine_id') == MACHINE, 'Recipe machine differs')
        root = Path(text(row.get('output_root'), 'output_root'))
        need(root.is_absolute(), 'Absolute output root required')
        deadline = text(row.get('hard_deadline_utc'), 'deadline')
        parsed = datetime.fromisoformat(deadline.replace('Z', '+00:00'))
        need(parsed.tzinfo is not None, 'Deadline requires timezone')
        raw = Pin.parse(row.get('raw'))
        need(0 < raw.bytes <= 28 * 1024 * 1024, 'Raw exceeds 28MiB source purpose')
        keys = row.get('keyframe_indices')
        need(isinstance(keys, list), 'Keyframes must be a JSON list')
        if not isinstance(keys, list):
            raise ValueError('Keyframe list missing')
        frames = integer(row.get('expected_video_frames'), 'recorded frame count', 2, 2700)
        indices = tuple(integer(x, 'frame index', 0, frames - 1) for x in keys)
        need(2 <= len(indices) <= 12 and tuple(sorted(set(indices))) == indices and
             indices[0] == 0 and indices[-1] == frames - 1,
             '2..12 distinct ascending keyframes including both endpoints required')
        names = ('source_binding', 'runner', 'contract', 'job_helper', 'ffmpeg', 'ffprobe', 'font')
        pins = [Pin.parse(row.get(key)) for key in names]
        need(row.get('stdout_jpeg_q') == 4 and type(row.get('stdout_jpeg_q')) is int,
             'Source JPEG q4 is fixed')
        need(row.get('contact_quality') == 60 and type(row.get('contact_quality')) is int,
             'Contact quality60 is fixed')
        need(row.get('fps') == '30/1', 'This bounded recipe requires recorder30fps')
        return cls(root, deadline, raw, pins[0], pins[1], pins[2], pins[3], pins[4], pins[5], pins[6],
                   integer(row.get('width'), 'width', 1, 3840),
                   integer(row.get('height'), 'height', 1, 2160),
                   integer(row.get('expected_audio_streams'), 'audio streams', 0, 1), frames, indices)


def check_capacity(cap: dict[str, object], recipe: Recipe, recipe_pin: Pin) -> None:
    need(cap.get('machine_id') == MACHINE, 'Capacity machine differs')
    for key in ('source_bound_QA_execution_admitted', 'FFmpeg_execution_admitted',
                'source_recording_original_wait0_and_job_closed_verified', 'no_recording_active_verified'):
        need(cap.get(key) is True, 'Execution refused: ' + key)
    need(text(cap.get('aggregate_root'), 'aggregate_root') == str(recipe.output_root), 'Exact root differs')
    need(text(cap.get('hard_deadline_utc'), 'hard_deadline') == recipe.hard_deadline_utc, 'Deadline differs')
    need(integer(cap.get('aggregate_ceiling_bytes'), 'aggregate ceiling') == TOTAL, '128MiB ceiling differs')
    for key, pin in (('recipe', recipe_pin), ('runner', recipe.runner), ('raw', recipe.raw),
                     ('source_binding', recipe.source_binding)):
        need(Pin.parse(cap.get(key)) == pin, 'Capacity source join differs: ' + key)
