"""One complete first-B-clip decode; retained raw is never copied or rendered."""
from __future__ import annotations
import argparse
import csv
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
from decimal import Decimal
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import subprocess
import threading
from types import ModuleType
from typing import Callable, Protocol
from PIL import Image, ImageDraw, ImageFont
from qa_contract import (Binding, CONTACTS, CONTROL, KEYFRAMES, MACHINE, METADATA,
                         Pin, Recipe, TOTAL, check_capacity, integer, load, need, object_map)

PTS = re.compile(rb'\bn:\s*(\d+)\s+pts:\s*(-?\d+)\s+pts_time:([^ ]+)')
JOB_SHA = '1eb95419ed818209cc6536b02365d815d821dfeff47a8ba4d9d71e138613a92d'


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def write(root: Path, name: str, value: object) -> None:
    payload = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
    need(sum(p.stat().st_size for p in root.rglob('*') if p.is_file()) + len(payload) <= TOTAL,
         'All-inclusive128MiB ceiling')
    with (root / name).open('xb') as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())


def stat_wire(path: Path) -> dict[str, object]:
    st = path.stat()
    return dict(bytes=st.st_size, st_dev=str(st.st_dev), st_ino=str(st.st_ino),
                mtime_ns=str(st.st_mtime_ns))


class Waitable(Protocol):
    def wait(self, timeout: float | None = None) -> int: ...
    def kill(self) -> None: ...


def finish_custody(proc: Waitable, *, failed: bool, terminate: Callable[[], None],
                   active: Callable[[], int], close: Callable[[], None]) -> dict[str, object]:
    """Wait the original object; abnormal kill-on-close never means proven Job empty."""
    errors: list[str] = []
    if failed:
        try:
            terminate()
        except OSError as exc:
            errors.append(repr(exc))
    try:
        code = proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        try:
            terminate()
        finally:
            proc.kill()
            code = proc.wait(timeout=10)
    count: int | None = None
    try:
        count = active()
        if count:
            terminate()
            proc.wait(timeout=10)
            count = active()
    except OSError as exc:
        errors.append(repr(exc))
    closed = False
    try:
        close()
        closed = True
    except OSError as exc:
        errors.append(repr(exc))
    return dict(original_wait=code, job_active_processes=count, job_handle_closed=closed,
                job_closed=closed and count == 0 and not errors,
                custody_errors=errors)


class Native:
    """Exact pinned legacy Job ABI; boxed native results are validated by each caller.

    callable narrowing and object boxing are confined to this verified ABI.
    No legacy receipt writer is called: all new receipts carry this machine ID.
    """
    def __init__(self, pin: Pin) -> None:
        need(pin.sha256 == JOB_SHA, 'Qualified Job helper pin differs')
        pin.verify()
        spec = importlib.util.spec_from_file_location('firstclip_job_primitives', pin.path)
        need(spec is not None and spec.loader is not None, 'Job helper loader unavailable')
        if spec is None or spec.loader is None:
            raise ValueError('Job helper loader unavailable')
        self.module: ModuleType = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.module)

    def call(self, name: str, *args: object) -> object:
        fn: object = getattr(self.module, name)
        if not callable(fn):
            raise ValueError('Pinned Job function missing: ' + name)
        result: object = fn(*args)
        return result

    def count(self, job: int) -> int:
        return integer(self.call('_active', job), 'native active processes', 0, 2**32 - 1)

    def stop(self, job: int) -> None:
        if self.count(job):
            need(bool(self.call('_terminate_job', job, 1)), 'TerminateJobObject failed')

    def close(self, job: int) -> None:
        need(bool(self.call('_close', job)), 'CloseHandle(Job) failed')


def birth(process: subprocess.Popen[bytes]) -> str:
    handle: object = getattr(process, '_handle')
    need(isinstance(handle, int) and not isinstance(handle, bool), 'Original process HANDLE missing')
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    function = kernel.GetProcessTimes
    function.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
    function.restype = wintypes.BOOL
    times = (wintypes.FILETIME * 4)()
    need(bool(function(handle, *(ctypes.byref(x) for x in times))), 'GetProcessTimes failed')
    return str((times[0].dwHighDateTime << 32) | times[0].dwLowDateTime)


class Reader(Protocol):
    def read(self, size: int = -1, /) -> bytes: ...


def jpeg_read(stream: Reader) -> bytes:
    """Marker-aware parser inherited from the qualified R03/R13 JPEG pipe."""
    def readn(count: int) -> bytes:
        data = stream.read(count)
        if len(data) != count:
            raise EOFError('Incomplete JPEG or pipe EOF')
        return data
    data = bytearray(readn(2))
    need(data == b'\xff\xd8', 'JPEG SOI differs')
    marker: int | None = None
    while True:
        need(len(data) <= 2 * 1024 * 1024, 'Single JPEG memory/keyframe bound')
        if marker is None:
            need(readn(1) == b'\xff', 'JPEG marker prefix differs')
            data.append(255)
            code = readn(1); data.extend(code)
            while code == b'\xff':
                code = readn(1); data.extend(code)
            marker = code[0]
        if marker == 217:
            return bytes(data)
        need(marker not in (0, 216), 'Invalid JPEG marker')
        if marker == 1 or 208 <= marker <= 215:
            marker = None
            continue
        length = readn(2); data.extend(length)
        count = int.from_bytes(length, 'big')
        need(count >= 2, 'JPEG segment length differs')
        data.extend(readn(count - 2))
        if marker != 218:
            marker = None
            continue
        while True:
            code = readn(1); data.extend(code)
            if code != b'\xff':
                continue
            code = readn(1); data.extend(code)
            while code == b'\xff':
                code = readn(1); data.extend(code)
            if code == b'\x00' or 208 <= code[0] <= 215:
                continue
            marker = code[0]
            break


def decode_argv(recipe: Recipe) -> list[str]:
    graph = '[0:v:0]showinfo@source=checksum=0[v]'
    if recipe.expected_audio_streams:
        graph += ';[0:a:0]ashowinfo[a]'
    argv = [recipe.ffmpeg.path, '-hide_banner', '-nostdin', '-nostats', '-v', 'info',
            '-xerror', '-err_detect', 'explode', '-threads', '1', '-filter_threads', '1',
            '-filter_complex_threads', '1', '-copyts', '-i', recipe.raw.path,
            '-filter_complex', graph, '-map', '[v]', '-an', '-sn', '-dn',
            '-fps_mode', 'passthrough', '-c:v', 'mjpeg', '-q:v', '4', '-threads:v', '1',
            '-f', 'image2pipe', 'pipe:1']
    if recipe.expected_audio_streams:
        argv += ['-map', '[a]', '-vn', '-sn', '-dn', '-f', 'null', 'NUL']
    return argv


def probe(recipe: Recipe, label: str, argv: list[str]) -> bytes:
    """Bounded read-only command, never count_frames/show_frames or another decoder."""
    root = recipe.output_root
    p: subprocess.Popen[bytes] = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                                  creationflags=subprocess.CREATE_NO_WINDOW)
    output = b''; error = b''
    try:
        output, error = p.communicate(timeout=30)
    finally:
        if p.poll() is None:
            p.kill()
        code = p.wait(timeout=10)
        write(root, label + '-ORIGINAL-WAIT.json', dict(machine_id=MACHINE, argv=argv, pid=p.pid,
              birth_filetime=birth(p), original_wait=code, stdout_bytes=len(output),
              stdout_sha256=hashlib.sha256(output).hexdigest(), stderr=error.decode('utf8', 'replace')))
    need(code == 0 and not error and len(output) <= 4 * 1024 * 1024, 'Bounded probe failed')
    return output


def verify_inputs(recipe: Recipe, recipe_pin: Pin, cap: dict[str, object]) -> Binding:
    check_capacity(cap, recipe, recipe_pin)
    for pin in (recipe.raw, recipe.source_binding, recipe.runner, recipe.contract, recipe.job_helper, recipe.font):
        pin.verify()
    for pin in (recipe.ffmpeg, recipe.ffprobe):
        need(Path(pin.path).stat().st_size == pin.bytes, 'Retained qualified tool size differs')
    need(Pin.read(Path(__file__)) == recipe.runner, 'Runner is not source-bound')
    binding = Binding.parse(load(Path(recipe.source_binding.path)))
    for pin in binding.refs():
        pin.verify()
    need(datetime.now(timezone.utc) < datetime.fromisoformat(recipe.hard_deadline_utc.replace('Z', '+00:00')),
         'Hard deadline expired')
    return binding


def execute(recipe_path: Path, recipe_sha: str, capacity_path: Path, capacity_sha: str) -> None:
    recipe_pin = Pin.read(recipe_path)
    need(recipe_pin.sha256 == recipe_sha and Pin.read(capacity_path).sha256 == capacity_sha, 'Admission pins differ')
    recipe = Recipe.parse(load(recipe_path)); cap = load(capacity_path)
    binding = verify_inputs(recipe, recipe_pin, cap)
    root = recipe.output_root
    need(root.is_dir() and not (root / 'ONCE.json').exists(), 'Unknown/existing once attempt')
    before = stat_wire(Path(recipe.raw.path))
    write(root, 'ONCE.json', dict(machine_id=MACHINE, observed_at_utc=now(), recipe=recipe_pin.wire(),
          source_binding=recipe.source_binding.wire(), source_before=before, raw_copied=False,
          human1x=False, source_window='complete EOF; no trim, fps, drop, tail or retry'))
    raw = probe(recipe, 'BOUND', [recipe.ffprobe.path, '-v', 'error', '-show_streams', '-show_format',
                                 '-of', 'json', recipe.raw.path])
    metadata = object_map(json.loads(raw), 'probe')
    streams = metadata.get('streams')
    need(isinstance(streams, list), 'Probe stream list missing')
    if not isinstance(streams, list):
        raise ValueError('Probe stream list missing')
    videos = [object_map(s, 'stream') for s in streams if object_map(s, 'stream').get('codec_type') == 'video']
    audios = [object_map(s, 'stream') for s in streams if object_map(s, 'stream').get('codec_type') == 'audio']
    need(len(videos) == 1 and len(audios) == recipe.expected_audio_streams, 'Exact AV stream set differs')
    need(integer(videos[0].get('width'), 'actual width', 1) == recipe.width and
         integer(videos[0].get('height'), 'actual height', 1) == recipe.height and
         videos[0].get('r_frame_rate') == '30/1', 'Actual video geometry/fps differs')
    form = object_map(metadata.get('format'), 'format')
    duration = form.get('duration')
    need(type(duration) is str and Decimal('0') < Decimal(str(duration)) <= Decimal('90'), 'Raw exceeds90s')
    write(root, 'BOUND-METADATA.json', dict(machine_id=MACHINE, actual=metadata))
    packets = probe(recipe, 'PACKETS', [recipe.ffprobe.path, '-v', 'error', '-show_packets', '-show_entries',
        'packet=stream_index,pts,dts,duration:packet_side_data=', '-of', 'compact=p=0:nk=0', recipe.raw.path])
    previous: dict[str, int] = {}
    for line in packets.decode('ascii').splitlines():
        row = dict(s.split('=', 1) for s in line.split('|') if '=' in s)
        stream_index = row.get('stream_index')
        if stream_index is None:
            continue
        need(row.get('dts', 'N/A') != 'N/A' and row.get('pts', 'N/A') != 'N/A', 'Missing packet timestamps')
        tick = int(row['dts'])
        need(stream_index not in previous or tick > previous[stream_index], 'Per-stream packet DTS regressed')
        previous[stream_index] = tick
    with gzip.open(root / 'packets.compact.gz', 'xb') as packet_log:
        packet_log.write(packets)
    with gzip.open(root / 'packets.compact.gz', 'rb') as packet_crc:
        need(hashlib.sha256(packet_crc.read()).digest() == hashlib.sha256(packets).digest(),
             'Compact packet gzip EOF/CRC/SHA differs')
    census = probe(recipe, 'FFMPEG-CENSUS', ['C:/Windows/System32/tasklist.exe',
        '/FI', 'IMAGENAME eq ffmpeg.exe', '/FO', 'CSV', '/NH'])
    write(root, 'FFMPEG-CENSUS.json', dict(machine_id=MACHINE, observed_at_utc=now(),
          stdout=census.decode('utf8', 'replace'), query_only=True))
    need(b'ffmpeg.exe' not in census.lower(), 'Recording/another FFmpeg still active')
    run_decode(recipe, binding, before)


def run_decode(recipe: Recipe, binding: Binding, before: dict[str, object]) -> None:
    root = recipe.output_root
    native = Native(recipe.job_helper)
    handle = integer(native.call('_new_job'), 'Job HANDLE', 1, 2**64 - 1)
    p: subprocess.Popen[bytes] | None = None
    failure: str | None = None
    custody: dict[str, object] = {}
    stop = threading.Event(); errors: list[str] = []
    trace_ready = threading.Condition()
    video: list[tuple[int, str, str]] = []; audio: list[tuple[int, str, str]] = []
    sheets: list[dict[str, object]] = []; keyframes: list[dict[str, object]] = []
    trace_hash = hashlib.sha256(); trace_bytes = 0
    workers: list[threading.Thread] = []
    argv = decode_argv(recipe)
    try:
        p = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             creationflags=4 | subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        process_handle: object = getattr(p, '_handle')
        need(isinstance(process_handle, int), 'Original process HANDLE unavailable')
        need(bool(native.call('_assign_job', handle, process_handle)), 'AssignProcessToJobObject failed')
        member = wintypes.BOOL()
        need(bool(native.call('_in_job', process_handle, handle, ctypes.byref(member))) and bool(member.value) and
             native.count(handle) == 1, 'Job membership before resume failed')
        flags = integer(native.call('_verified_limit_flags', handle), 'Job flags')
        born = birth(p)
        write(root, 'AV-START.json', dict(machine_id=MACHINE, observed_at_utc=now(), argv=argv, pid=p.pid,
              birth_filetime=born, assigned_before_resume=True, job_flags=flags))
        native.call('_resume_only_thread', p.pid)
        out = p.stdout; err = p.stderr
        if out is None or err is None:
            raise RuntimeError('Original FFmpeg pipes unavailable')

        def read_stderr() -> None:
            nonlocal trace_bytes
            try:
                with gzip.open(root / 'av.stderr.gz', 'xb') as log:
                    for line in iter(err.readline, b''):
                        log.write(line); trace_hash.update(line); trace_bytes += len(line)
                        match = PTS.search(line)
                        if match:
                            dest = audio if b'ashowinfo' in line else video
                            n = int(match[1]); ticks = int(match[2]); seconds = match[3].decode('ascii')
                            need(n == len(dest) and (not dest or ticks > int(dest[-1][1])), 'Decoded n/PTS disorder')
                            with trace_ready:
                                dest.append((n, str(ticks), seconds))
                                trace_ready.notify_all()
                        if trace_bytes > METADATA or (root / 'av.stderr.gz').stat().st_size > METADATA // 2:
                            raise ValueError('Lossless metadata limit')
            except BaseException as exc:
                errors.append(repr(exc)); native.stop(handle)

        def watchdog() -> None:
            deadline = datetime.fromisoformat(recipe.hard_deadline_utc.replace('Z', '+00:00'))
            while not stop.wait(.1):
                if datetime.now(timezone.utc) >= deadline:
                    errors.append('Hard deadline'); native.stop(handle); return

        for target in (read_stderr, watchdog):
            worker = threading.Thread(target=target); worker.start(); workers.append(worker)
        font = ImageFont.truetype(recipe.font.path, 11)
        sheet = Image.new('RGB', (1280, 792), 'black')
        for n in range(recipe.expected_video_frames):
            data = jpeg_read(out)
            with Image.open(io.BytesIO(data)) as frame:
                need(frame.size == (recipe.width, recipe.height), 'Source JPEG geometry differs')
                frame.load(); cell = frame.convert('RGB'); cell.thumbnail((320, 180), Image.Resampling.LANCZOS)
                x = (n % 16 % 4) * 320; y = (n % 16 // 4) * 198
                sheet.paste(cell, (x + (320-cell.width)//2, y + (180-cell.height)//2))
            with trace_ready:
                ready = trace_ready.wait_for(lambda: len(video) > n or bool(errors), timeout=5)
                need(ready and len(video) > n, 'Actual PTS label not available')
                pts_label = video[n][2]
            ImageDraw.Draw(sheet).text((x+3, y+182), 'k' + str(n) + ' PTS=' + pts_label,
                                      font=font, fill='white')
            if n in recipe.keyframe_indices:
                need(sum(integer(k['bytes'], 'keyframe bytes') for k in keyframes) + len(data) <= KEYFRAMES, 'Fullres keyframe ceiling')
                path = root / ('keyframe-%04d.jpg' % n)
                with path.open('xb') as stream:
                    stream.write(data)
                keyframes.append(dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), frame=n))
            if n % 16 == 15 or n == recipe.expected_video_frames-1:
                buffer = io.BytesIO(); sheet.save(buffer, format='JPEG', quality=60, subsampling=2)
                data = buffer.getvalue()
                need(sum(integer(s['bytes'], 'sheet bytes') for s in sheets) + len(data) <= CONTACTS, 'Contact ceiling')
                path = root / ('contact-%03d.jpg' % len(sheets))
                with path.open('xb') as stream:
                    stream.write(data)
                sheets.append(dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                                   first_frame=n//16*16, end_frame_exclusive=n+1, valid_cells=n%16+1,
                                   dimensions=[1280,792]))
                sheet = Image.new('RGB', (1280, 792), 'black')
            need(sum(x.stat().st_size for x in root.rglob('*') if x.is_file()) < TOTAL-CONTROL, 'Aggregate guard')
        need(out.read(1) == b'', 'Decoded output has more frames than closed recorder count')
    except BaseException as exc:
        failure = repr(exc)
    finally:
        if p is not None:
            custody = finish_custody(p, failed=failure is not None or bool(errors),
                        terminate=lambda: native.stop(handle), active=lambda: native.count(handle),
                        close=lambda: native.close(handle))
            stop.set()
            for worker in workers:
                worker.join(timeout=10)
            write(root, 'AV-ORIGINAL-WAIT.json', dict(machine_id=MACHINE, observed_at_utc=now(),
                  pid=p.pid, birth_filetime=birth(p), **custody, error=failure, reader_errors=errors,
                  workers_alive=any(w.is_alive() for w in workers), no_retry=True))
        else:
            native.close(handle)
    need(failure is None and not errors and custody.get('original_wait') == 0 and
         custody.get('job_active_processes') == 0 and custody.get('job_closed') is True,
         'Decode/custody failed; partial retained, no retry')
    need(not any(w.is_alive() for w in workers) and len(video) == recipe.expected_video_frames and
         (len(audio) > 0) == bool(recipe.expected_audio_streams), 'Incomplete decoded AV trace')
    need(sum(integer(s['valid_cells'], 'valid cells', 1, 16) for s in sheets) == len(video) and
         len(sheets) == (len(video)+15)//16 and len(keyframes) == len(recipe.keyframe_indices),
         'Contact/keyframe completeness differs')
    for name, rows in (('video-PTS.csv', video), ('audio-PTS.csv', audio)):
        with (root / name).open('x', encoding='ascii', newline='') as csv_stream:
            writer = csv.writer(csv_stream); writer.writerow(['n','actual_pts_ticks','actual_pts_time']); writer.writerows(rows)
    digest = hashlib.sha256()
    with gzip.open(root / 'av.stderr.gz', 'rb') as crc_stream:
        for block in iter(lambda: crc_stream.read(65536), b''):
            digest.update(block)
    need(digest.hexdigest() == trace_hash.hexdigest(), 'Lossless log CRC/SHA differs')
    need(stat_wire(Path(recipe.raw.path)) == before, 'Raw source changed during QA')
    write(root, 'QA.actual.json', dict(schema='xar.r17.firstclip-complete-qa.v1', machine_id=MACHINE,
          observed_at_utc=now(), status='COMPLETE_AV_CONTACTS_PENDING_VISUAL_REVIEW',
          raw=recipe.raw.wire(), runner=recipe.runner.wire(),
          source_before=before, source_after=stat_wire(Path(recipe.raw.path)),
          source_binding=recipe.source_binding.wire(), run_id=binding.run_id, episode_id=binding.episode_id,
          date_before=binding.date_before, date_after=binding.date_after,
          source_video_frames=len(video), decoded_audio_frames=len(audio), complete_AV_decode_attempts=1,
          audio_absent_expected_by_capture_an=recipe.expected_audio_streams == 0,
          video_PTS_trace=Pin.read(root / 'video-PTS.csv').wire(),
          audio_PTS_trace=Pin.read(root / 'audio-PTS.csv').wire(),
          sheets=sheets, original_resolution_keyframes=keyframes,
          lossless_stderr_uncompressed_bytes=trace_bytes, lossless_stderr_sha256=trace_hash.hexdigest(),
          all_valid_cells=len(video), all_cells_visual_review='PENDING_ACTUAL_VIEW',
          native_callback_exact_encoded_frame=None, wall_to_PTS_not_inferred=True,
          original_wait=0, job_active_processes=0, job_closed=True, second_recording_can_begin=True,
          human1x=False, signoff=False, formal_credit=0, raw_or_rich_copies=0))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--recipe', type=Path, required=True)
    parser.add_argument('--recipe-sha', required=True)
    parser.add_argument('--capacity', type=Path, required=True)
    parser.add_argument('--capacity-sha', required=True)
    args = parser.parse_args()
    if not args.execute:
        Recipe.parse(load(args.recipe))
        return
    execute(args.recipe, args.recipe_sha, args.capacity, args.capacity_sha)


if __name__ == '__main__':
    main()
