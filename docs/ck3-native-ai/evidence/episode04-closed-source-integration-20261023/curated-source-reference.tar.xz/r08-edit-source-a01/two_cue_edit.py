"""Two-cue R08 source contract. No TTS, rasterization, rendering or SDK calls.

JSON enters through json_domain(); numeric identity/size/frame fields reject bool.
New voice data is accepted only from the separately materialized actual manifest.
The selected 45 baseline cues and their media remain immutable inputs.
"""
from __future__ import annotations

import argparse
import builtins
import copy
from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING
import hashlib
import io
import json
import math
from pathlib import Path
import re
import subprocess
import tarfile
import textwrap
from typing import Literal, TypeAlias

JsonValue: TypeAlias = None | bool | int | float | str | list["JsonValue"] | dict[str, "JsonValue"]
JsonObject: TypeAlias = dict[str, JsonValue]
CueId: TypeAlias = Literal["N06-08", "N06-05"]
MACHINE = "desktop-3fevhd2-1c74096080"
CUES: tuple[CueId, CueId] = ("N06-08", "N06-05")
SOURCE_SCHEMA = "xar.e04.r08.two-cue-edit.source.v1"
VOICE_SCHEMA = "xar.e04.r08.two-cue.actual-voices.v1"


class SourceError(ValueError):
    pass


def json_domain(value: object) -> JsonValue:
    """Narrow the standard-library dynamic JSON boundary recursively."""
    if value is None or isinstance(value, (str, bool)):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value):
        return value
    if isinstance(value, list):
        return [json_domain(item) for item in value]
    if isinstance(value, dict):
        result: JsonObject = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise SourceError("JSON object key")
            result[key] = json_domain(item)
        return result
    raise SourceError("JSON domain")


def _pairs(values: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in values:
        if key in result:
            raise SourceError("duplicate JSON field")
        result[key] = value
    return result


def decode(data: bytes) -> JsonValue:
    value: object = json.loads(data.decode("utf-8-sig"), object_pairs_hook=_pairs)
    return json_domain(value)


def object_row(value: JsonValue, fields: set[str] | None = None) -> JsonObject:
    if not isinstance(value, dict) or (fields is not None and set(value) != fields):
        raise SourceError("object fields")
    return value


def rows(value: JsonValue) -> list[JsonValue]:
    if not isinstance(value, list):
        raise SourceError("JSON list")
    return value


def string(value: JsonValue) -> str:
    if not isinstance(value, str) or not value:
        raise SourceError("nonempty string")
    return value


def integer(value: JsonValue) -> int:
    if type(value) is not int or value < 0:
        raise SourceError("exact nonnegative integer")
    return value


def duration(value: JsonValue) -> Decimal:
    text = string(value)
    if re.fullmatch(r"(?:0|[1-9][0-9]*)(?:\.[0-9]+)?", text) is None:
        raise SourceError("canonical decimal duration string")
    result = Decimal(text)
    if result <= 0:
        raise SourceError("positive duration")
    return result


def digest(value: JsonValue) -> str:
    result = string(value)
    if re.fullmatch("[0-9a-f]{64}", result) is None:
        raise SourceError("lowercase SHA256")
    return result


def canonical(value: JsonValue) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


@dataclass(frozen=True)
class FilePin:
    path: str
    bytes: int
    sha256: str

    @staticmethod
    def parse(value: JsonValue) -> FilePin:
        row = object_row(value, {"path", "bytes", "sha256"})
        path = string(row["path"])
        if not Path(path).is_absolute():
            raise SourceError("absolute actual file pin")
        return FilePin(path, integer(row["bytes"]), digest(row["sha256"]))

    def wire(self) -> JsonObject:
        return {"path": self.path, "bytes": self.bytes, "sha256": self.sha256}

    def verify(self, maximum_bytes: int) -> builtins.bytes:
        if self.bytes > maximum_bytes:
            raise SourceError("finite pinned read")
        path = Path(self.path)
        info = path.stat()
        if info.st_file_attributes & 0x400 or not path.is_file() or info.st_size != self.bytes:
            raise SourceError("ordinary unchanged pinned file")
        data = path.read_bytes()
        if len(data) != self.bytes or hashlib.sha256(data).hexdigest() != self.sha256:
            raise SourceError("file pin content")
        return data


@dataclass(frozen=True)
class Baseline:
    commit: str
    tracked_archive_path: str
    archive_bytes: int
    archive_sha256: str
    project_member: str
    project_bytes: int
    project_sha256: str
    timeline_member: str
    timeline_bytes: int
    timeline_sha256: str

    @staticmethod
    def parse(value: JsonValue) -> Baseline:
        fields = {"commit", "tracked_archive_path", "archive_bytes", "archive_sha256",
                  "project_member", "project_bytes", "project_sha256",
                  "timeline_member", "timeline_bytes", "timeline_sha256"}
        r = object_row(value, fields)
        commit = string(r["commit"])
        if re.fullmatch("[0-9a-f]{40}", commit) is None:
            raise SourceError("exact Git commit")
        return Baseline(commit, string(r["tracked_archive_path"]), integer(r["archive_bytes"]),
                        digest(r["archive_sha256"]), string(r["project_member"]), integer(r["project_bytes"]),
                        digest(r["project_sha256"]), string(r["timeline_member"]), integer(r["timeline_bytes"]),
                        digest(r["timeline_sha256"]))


@dataclass(frozen=True)
class Cue:
    cue_id: CueId
    narration_zh: str
    subtitles_en: str
    visual_kind: Literal["accepted_raw", "precision_card"]
    source_frames: tuple[int, int] | None
    target_frames: int | None
    max_voice_seconds: Decimal

    @staticmethod
    def parse(value: JsonValue) -> Cue:
        r = object_row(value, {"id", "narration_zh", "subtitles_zh", "subtitles_en", "visual_kind",
                               "source_frames", "source_fps", "target_frames", "max_voice_seconds"})
        zh = string(r["narration_zh"])
        en = string(r["subtitles_en"])
        if r["subtitles_zh"] != zh:
            raise SourceError("one Chinese voice/subtitle text")
        if r["id"] == "N06-08":
            span = rows(r["source_frames"])
            if (len(span) != 2 or [integer(x) for x in span] != [180, 1051]
                    or integer(r["source_fps"]) != 30 or r["target_frames"] is not None
                    or r["visual_kind"] != "accepted_raw" or r["max_voice_seconds"] != "28.033"):
                raise SourceError("accepted 871-frame raw only; no target override")
            return Cue("N06-08", zh, en, "accepted_raw", (180, 1051), None, duration(r["max_voice_seconds"]))
        if r["id"] == "N06-05":
            if (r["source_frames"] is not None or r["source_fps"] is not None
                    or integer(r["target_frames"]) != 946 or r["visual_kind"] != "precision_card"
                    or r["max_voice_seconds"] != "30.533"):
                raise SourceError("only N06-05 typed target946")
            return Cue("N06-05", zh, en, "precision_card", None, 946, duration(r["max_voice_seconds"]))
        raise SourceError("only two selected cues")

    def project_fields(self) -> JsonObject:
        return {"id": self.cue_id, "narration": {"zh-CN": self.narration_zh},
                "subtitles": {"zh-CN": self.narration_zh, "en": self.subtitles_en}}

    def text_sha256(self) -> str:
        return hashlib.sha256(self.narration_zh.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class SourcePlan:
    baseline: Baseline
    actual_shot: FilePin
    raw: FilePin
    cues: tuple[Cue, Cue]

    @staticmethod
    def parse(value: JsonValue) -> SourcePlan:
        r = object_row(value, {"schema", "machine_id", "status", "baseline", "actual_shot", "raw", "voice_plan", "cues"})
        if (r["schema"] != SOURCE_SCHEMA or r["machine_id"] != MACHINE
                or r["status"] != "SOURCE_ONLY_NEW_VOICES_UNMATERIALIZED"):
            raise SourceError("source-only machine/status")
        voice = object_row(r["voice_plan"], {"status", "actual_manifest_parameter", "expected_schema",
                                           "provider", "voice_name", "rate", "actual_manifest_pin"})
        if voice != {"status": "planned_unmaterialized", "actual_manifest_parameter": "--actual-voices",
                     "expected_schema": VOICE_SCHEMA, "provider": "edge-tts", "voice_name": "zh-CN-XiaoxiaoNeural",
                     "rate": "-5%", "actual_manifest_pin": None}:
            raise SourceError("no old/future voice pin in planned source")
        items = [Cue.parse(item) for item in rows(r["cues"])]
        if len(items) != 2 or tuple(item.cue_id for item in items) != CUES:
            raise SourceError("exact selected cue order")
        return SourcePlan(Baseline.parse(r["baseline"]), FilePin.parse(r["actual_shot"]),
                          FilePin.parse(r["raw"]), (items[0], items[1]))


def load_baseline(plan: SourcePlan, repo: Path) -> tuple[JsonObject, JsonObject]:
    b = plan.baseline
    result = subprocess.run(["git", "--no-lazy-fetch", "-C", str(repo), "show",
                             b.commit + ":" + b.tracked_archive_path],
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if result.returncode != 0 or len(result.stdout) != b.archive_bytes or hashlib.sha256(result.stdout).hexdigest() != b.archive_sha256:
        raise SourceError("read-only fixed Git archive")
    with tarfile.open(fileobj=io.BytesIO(result.stdout), mode="r:xz") as archive:
        result_rows: list[JsonObject] = []
        for name, size, sha in [(b.project_member, b.project_bytes, b.project_sha256),
                                (b.timeline_member, b.timeline_bytes, b.timeline_sha256)]:
            member = archive.getmember(name)
            if not member.isfile() or member.size != size or size > 128 * 1024:
                raise SourceError("bounded ordinary archive member")
            stream = archive.extractfile(member)
            if stream is None:
                raise SourceError("missing member stream")
            data = stream.read()
            if hashlib.sha256(data).hexdigest() != sha:
                raise SourceError("archive member pin")
            result_rows.append(object_row(decode(data)))
    return result_rows[0], result_rows[1]


def project_cues(project: JsonObject) -> list[JsonObject]:
    result: list[JsonObject] = []
    for chapter in rows(project["chapters"]):
        for cue in rows(object_row(chapter)["cues"]):
            result.append(object_row(cue))
    ids = [string(cue["id"]) for cue in result]
    if len(ids) != 47 or len(set(ids)) != 47:
        raise SourceError("exact unique 47-cue baseline")
    return result


def apply_edits(project: JsonObject, plan: SourcePlan) -> JsonObject:
    before = project_cues(project)
    output = copy.deepcopy(project)
    after = project_cues(output)
    selected: dict[str, Cue] = {cue.cue_id: cue for cue in plan.cues}
    for old, new in zip(before, after):
        cue_id = string(old["id"])
        if cue_id in selected:
            fields = selected[cue_id].project_fields()
            if set(new) != set(fields):
                raise SourceError("selected cue source shape changed")
            new.update(fields)
        elif canonical(old) != canonical(new):
            raise SourceError("unchanged45 cue bytes")
    if [row["id"] for row in before] != [row["id"] for row in after]:
        raise SourceError("cue ordering changed")
    return output


def unchanged_fingerprints(project: JsonObject, timeline: JsonObject) -> JsonObject:
    cues = [row for row in project_cues(project) if row["id"] not in CUES]
    media = [row for row in rows(timeline["entries"]) if object_row(row)["cue_id"] not in CUES]
    if len(cues) != 45 or len(media) != 45:
        raise SourceError("unchanged45 source/media cardinality")
    return {"cue_count": 45, "cue_concat_sha256": hashlib.sha256(b"\n".join(canonical(row) for row in cues)).hexdigest(),
            "media_count": 45, "media_concat_sha256": hashlib.sha256(b"\n".join(canonical(row) for row in media)).hexdigest(),
            "media_payload_copied": False}


@dataclass(frozen=True)
class CueClock:
    frames: int
    raw_frames: int
    card_frames: int
    actual_voice_seconds: Decimal | None


def clock(cue: Cue, actual_voice_seconds: Decimal | None) -> CueClock:
    """Only 05 has a target override; 08 gets its length from the accepted span."""
    if actual_voice_seconds is not None:
        if not isinstance(actual_voice_seconds, Decimal) or not actual_voice_seconds.is_finite() or not 0 < actual_voice_seconds <= cue.max_voice_seconds:
            raise SourceError("actual voice exceeds declared source slot")
        speech = int((actual_voice_seconds * 30).to_integral_value(rounding=ROUND_CEILING))
    else:
        speech = 0
    if cue.cue_id == "N06-08" and cue.source_frames == (180, 1051) and cue.target_frames is None:
        frames = cue.source_frames[1] - cue.source_frames[0]
        if speech > frames:
            raise SourceError("voice cannot extend accepted raw")
        return CueClock(frames, frames, 0, actual_voice_seconds)
    if cue.cue_id == "N06-05" and cue.target_frames == 946 and cue.source_frames is None:
        if speech + 30 > 946:
            raise SourceError("actual voice needs one-second card tail")
        return CueClock(946, 0, 946, actual_voice_seconds)
    raise SourceError("clock override outside exact two-cue contract")


@dataclass(frozen=True)
class ActualVoice:
    cue_id: CueId
    text_sha256: str
    actual_seconds: Decimal
    original_mp3: FilePin
    native_cas: FilePin
    duration_probe: FilePin

    def wire(self) -> JsonObject:
        return {"cue_id": self.cue_id, "text_sha256": self.text_sha256,
                "actual_seconds": str(self.actual_seconds), "original_MP3": self.original_mp3.wire(),
                "native_CAS": self.native_cas.wire(), "duration_probe": self.duration_probe.wire(),
                "provider_calls": 1, "atempo_or_trim": False}


def parse_actual_voices(value: JsonValue, plan: SourcePlan) -> tuple[ActualVoice, ActualVoice]:
    r = object_row(value, {"schema", "machine_id", "status", "provider", "voice_name", "rate",
                           "producer_source_pin", "owner_closed_pin", "voices"})
    if (r["schema"] != VOICE_SCHEMA or r["machine_id"] != MACHINE or r["status"] != "ACTUAL_TWO_CUE_VOICES_MATERIALIZED"
            or r["provider"] != "edge-tts" or r["voice_name"] != "zh-CN-XiaoxiaoNeural" or r["rate"] != "-5%"):
        raise SourceError("separate actual voice manifest required")
    FilePin.parse(r["producer_source_pin"])
    FilePin.parse(r["owner_closed_pin"])
    values = rows(r["voices"])
    if len(values) != 2:
        raise SourceError("two actual voice rows")
    result: list[ActualVoice] = []
    for cue, value_row in zip(plan.cues, values):
        v = object_row(value_row, {"cue_id", "text_sha256", "actual_seconds", "original_MP3", "native_CAS",
                                   "duration_probe", "provider_calls", "atempo_or_trim"})
        if (v["cue_id"] != cue.cue_id or digest(v["text_sha256"]) != cue.text_sha256()
                or integer(v["provider_calls"]) != 1 or v["atempo_or_trim"] is not False):
            raise SourceError("new text/one actual provider/no time alteration")
        original, cas = FilePin.parse(v["original_MP3"]), FilePin.parse(v["native_CAS"])
        if (original.bytes, original.sha256) != (cas.bytes, cas.sha256):
            raise SourceError("actual original/CAS identity")
        seconds = duration(v["actual_seconds"])
        clock(cue, seconds)
        result.append(ActualVoice(cue.cue_id, cue.text_sha256(), seconds, original, cas, FilePin.parse(v["duration_probe"])))
    return result[0], result[1]


def verify_actual_voices(path: Path, plan: SourcePlan) -> tuple[ActualVoice, ActualVoice]:
    """Future stage only. Checks actual files/probes/closed producer, never generates."""
    if path.stat().st_size > 32768:
        raise SourceError("actual manifest ceiling")
    value = decode(path.read_bytes())
    result = parse_actual_voices(value, plan)
    manifest = object_row(value)
    FilePin.parse(manifest["producer_source_pin"]).verify(131072)
    owner = object_row(decode(FilePin.parse(manifest["owner_closed_pin"]).verify(16384)))
    if (owner.get("schema") != "xar.e04.r08.two-cue.voice-owner-closed.v1" or owner.get("machine_id") != MACHINE
            or owner.get("status") != "CLOSED" or owner.get("all_original_current_children_wait0") is not True
            or integer(owner.get("actual_provider_calls")) != 2
            or owner.get("producer_source_sha256") != FilePin.parse(manifest["producer_source_pin"]).sha256
            or owner.get("actual_voices") != [voice.wire() for voice in result]):
        raise SourceError("actual closed voice producer")
    for voice in result:
        voice.original_mp3.verify(524288)
        voice.native_cas.verify(524288)
        probe = object_row(decode(voice.duration_probe.verify(8192)),
                           {"schema", "machine_id", "media_pin", "actual_original_wait", "returncode", "actual_seconds"})
        if (probe["schema"] != "xar.e04.r08.audio-duration-probe.v1" or probe["machine_id"] != MACHINE
                or probe["media_pin"] != voice.original_mp3.wire() or probe["actual_original_wait"] is not True
                or integer(probe["returncode"]) != 0 or duration(probe["actual_seconds"]) != voice.actual_seconds):
            raise SourceError("actual original ffprobe wait and exact measured duration")
    return result


ASS_HEADER = """[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 2
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.709
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Chinese,Microsoft YaHei,36,&H00CFE5F0,&H000000FF,&H00131821,&H78081018,-1,0,0,0,100,100,0,0,1,2,0,2,192,192,119,1
Style: English,Microsoft YaHei,24,&H008DA9BB,&H000000FF,&H00131821,&H78081018,0,0,0,0,100,100,0,0,1,1.5,0,2,192,192,38,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""


@dataclass(frozen=True)
class Dialogue:
    layer: int
    start_cs: int
    end_cs: int
    style: Literal["Chinese", "English"]
    name: str
    text: str


@dataclass(frozen=True)
class AssDocument:
    cue_id: CueId
    timing_status: Literal["PLANNED_VOICE_UNMATERIALIZED", "ACTUAL_VOICE_BOUND_APPROXIMATE_PHRASES"]
    dialogues: tuple[Dialogue, ...]


def _stamp(value: int) -> str:
    return f"{value // 360000}:{value // 6000 % 60:02}:{value // 100 % 60:02}.{value % 100:02}"


def _unstamp(value: str) -> int:
    if re.fullmatch(r"[0-9]+:[0-5][0-9]:[0-5][0-9]\.[0-9]{2}", value) is None:
        raise SourceError("ASS centisecond timestamp")
    h, m, tail = value.split(":")
    s, cs = tail.split(".")
    return int(h) * 360000 + int(m) * 6000 + int(s) * 100 + int(cs)


def _sentences(value: str, chinese: bool) -> list[str]:
    result = ([x for x in re.findall(r"[^。！？]+[。！？]?", value) if x]
              if chinese else [x.strip() for x in re.split(r"(?<=[.!?])\s+", value) if x.strip()])
    if not result or any("{" in x or "}" in x or "\n" in x or "\\" in x for x in result):
        raise SourceError("plain sentence domain")
    return result


def _wrap(value: str, chinese: bool) -> str:
    lines = ([value[i:i + 40] for i in range(0, len(value), 40)] if chinese else
             textwrap.wrap(value, width=84, break_long_words=False, break_on_hyphens=False))
    if len(lines) > 2:
        raise SourceError("two readable lines per complete sentence")
    return r"\N".join(lines)


def make_ass(cue: Cue, actual_voice_seconds: Decimal | None = None) -> AssDocument:
    timing = clock(cue, actual_voice_seconds)
    zh, en = _sentences(cue.narration_zh, True), _sentences(cue.subtitles_en, False)
    if len(zh) != len(en):
        raise SourceError("paired complete Chinese/English sentences")
    stop = timing.frames * 100 // 30 - 10
    speech_stop = min(stop, int(actual_voice_seconds * 100)) if actual_voice_seconds is not None else stop
    weights = [len(line) for line in zh]
    cursor = 10
    dialogues: list[Dialogue] = []
    for index, (chinese, english, weight) in enumerate(zip(zh, en, weights)):
        end = stop if index == len(zh) - 1 else 10 + (speech_stop - 10) * sum(weights[:index + 1]) // sum(weights)
        if end <= cursor:
            raise SourceError("positive subtitle slot")
        dialogues.extend((Dialogue(1, cursor, end, "English", "en-" + str(index), _wrap(english, False)),
                          Dialogue(2, cursor, end, "Chinese", "zh-" + str(index), _wrap(chinese, True))))
        cursor = end
    status: Literal["PLANNED_VOICE_UNMATERIALIZED", "ACTUAL_VOICE_BOUND_APPROXIMATE_PHRASES"] = (
        "PLANNED_VOICE_UNMATERIALIZED" if actual_voice_seconds is None else "ACTUAL_VOICE_BOUND_APPROXIMATE_PHRASES")
    return AssDocument(cue.cue_id, status, tuple(dialogues))


def render_ass(document: AssDocument) -> str:
    header = ASS_HEADER.replace("[Script Info]\n", "[Script Info]\nTitle: " + document.cue_id +
                                "\n; TimingStatus: " + document.timing_status + "\n", 1)
    return header + "".join(
        f"Dialogue: {d.layer},{_stamp(d.start_cs)},{_stamp(d.end_cs)},{d.style},{d.name},0,0,0,,"
        + r"{\q2}" + d.text + "\n" for d in document.dialogues)


def parse_ass(text: str) -> AssDocument:
    title = re.search(r"^Title: (N06-08|N06-05)$", text, re.MULTILINE)
    status = re.search(r"^; TimingStatus: (PLANNED_VOICE_UNMATERIALIZED|ACTUAL_VOICE_BOUND_APPROXIMATE_PHRASES)$", text, re.MULTILINE)
    if title is None or status is None:
        raise SourceError("explicit source/actual ASS state")
    cue_id: CueId = "N06-08" if title.group(1) == "N06-08" else "N06-05"
    timing_status: Literal["PLANNED_VOICE_UNMATERIALIZED", "ACTUAL_VOICE_BOUND_APPROXIMATE_PHRASES"] = (
        "PLANNED_VOICE_UNMATERIALIZED" if status.group(1) == "PLANNED_VOICE_UNMATERIALIZED" else "ACTUAL_VOICE_BOUND_APPROXIMATE_PHRASES")
    result: list[Dialogue] = []
    for line in text.splitlines():
        if not line.startswith("Dialogue: "):
            continue
        fields = line[len("Dialogue: "):].split(",", 9)
        if (len(fields) != 10 or fields[0] not in ("1", "2") or fields[3] not in ("English", "Chinese")
                or fields[5:9] != ["0", "0", "0", ""] or not fields[9].startswith(r"{\q2}")):
            raise SourceError("exact source ASS row")
        start, end = _unstamp(fields[1]), _unstamp(fields[2])
        if end <= start:
            raise SourceError("ASS interval")
        style: Literal["Chinese", "English"] = "Chinese" if fields[3] == "Chinese" else "English"
        result.append(Dialogue(int(fields[0]), start, end, style, fields[4], fields[9][5:]))
    document = AssDocument(cue_id, timing_status, tuple(result))
    if render_ass(document) != text:
        raise SourceError("ASS exact supported-domain roundtrip")
    return document


def validate_source(plan_path: Path, repo: Path) -> JsonObject:
    plan = SourcePlan.parse(decode(plan_path.read_bytes()))
    shot = object_row(decode(plan.actual_shot.verify(8192)))
    shot_raw = FilePin.parse(shot.get("source"))
    if (shot.get("status") != "accepted_original_M_positive_source_shot" or shot.get("machine_id") != MACHINE
            or Path(shot_raw.path) != Path(plan.raw.path)
            or (shot_raw.bytes, shot_raw.sha256) != (plan.raw.bytes, plan.raw.sha256)
            or shot.get("edit_871frame_window_half_open") != [180, 1051]
            or shot.get("full_original_M_card_qualified") is not False):
        raise SourceError("actual bounded Root shot")
    project, timeline = load_baseline(plan, repo)
    candidate = apply_edits(project, plan)
    for cue in plan.cues:
        if parse_ass(render_ass(make_ass(cue))) != make_ass(cue):
            raise SourceError("source ASS roundtrip")
    return {"schema": "xar.e04.r08.two-cue-source-validation.v1", "machine_id": MACHINE,
            "status": "SOURCE_ONLY_VALIDATED_NEW_VOICES_UNMATERIALIZED", "selected_cues": list(CUES),
            "planned_frames": [clock(cue, None).frames for cue in plan.cues],
            "unchanged": unchanged_fingerprints(candidate, timeline),
            "TTS_render_raster_Game_SDK_calls": 0, "new_actual_voice_pins": None}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--actual-voices", type=Path)
    args = parser.parse_args()
    report = validate_source(args.plan, args.repo)
    if args.actual_voices is not None:
        plan = SourcePlan.parse(decode(args.plan.read_bytes()))
        verified = verify_actual_voices(args.actual_voices, plan)
        report["separately_verified_actual_voices"] = [voice.wire() for voice in verified]
    print(json.dumps(report, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
