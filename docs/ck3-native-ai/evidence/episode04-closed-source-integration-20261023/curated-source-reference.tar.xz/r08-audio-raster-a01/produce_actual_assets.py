"""Finite R08 actual audio and single Pillow raster producer.

Only this new8MiB root is writable. No Game, browser, SDK bridge or movie render.
SourcePlan and the actual-voices consumer are imported from the frozen source.
Edge's public typed streaming API is bounded by90s and512KiB per invocation.
"""
from __future__ import annotations

import argparse
import asyncio
import ctypes
from ctypes import wintypes as W
from dataclasses import dataclass
import datetime as dt
from decimal import Decimal
import hashlib
import importlib.metadata
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from typing import BinaryIO, Protocol, runtime_checkable

from edge_tts import Communicate
from PIL import Image

OLD_SOURCE = Path("C:/ck3-e04-resume-20261022-b01/r08-edit-source-a01")
sys.path.insert(0, str(OLD_SOURCE))
from two_cue_edit import (  # noqa: E402
    Cue, FilePin, JsonObject, JsonValue, MACHINE, SourceError, SourcePlan,
    canonical, clock, decode, digest, duration, integer, object_row, rows, string,
    verify_actual_voices,
)

ROOT = Path("C:/ck3-e04-resume-20261022-b01/r08-audio-raster-a01")
CARD = Path("C:/ck3-e04-resume-20261022-b01/capacity/future-control-a01/MIDX-AND-AUDIO-EXECUTION-ADMISSIONS.actual-a01.json")
CARD_SHA = "c7b887e4407a20346f88de9a1b0723b3b44fd2519e7fa60671ec020423c20b16"
PURPOSE = Path("C:/ck3-e04-resume-20261022-b01/root-phase5/ROOT-R08-ACTUAL-AUDIO-RASTER-PURPOSE.actual-a01.json")
PURPOSE_SHA = "e1cba588bd3e5238bf2dbe9f98489daf493e3e9989a01a6e9123c0eaf6d9a4c3"
FREEZE = OLD_SOURCE / "SOURCE-FREEZE.actual-a02.json"
FREEZE_SHA = "99a52a815cc407794c84e6ce3ccec73ee08d3b0d778738a7c8d5600e8931d8ba"
RASTER = FilePin("C:/ck3-e04-resume-20261015-a01/review02-composer-candidate-a01/svg_card_stills.py",
                 5815, "bd88bf8e769d78d0bc00a3297dba0b10fcb01582e0a068c19a39a07aa3626cc8")
FFPROBE = Path("C:/Users/1/AppData/Local/Microsoft/WinGet/Packages/Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe/ffmpeg-9.0.1-full_build/bin/ffprobe.exe")
REGULAR = Path("C:/Windows/Fonts/msyh.ttc")
BOLD = Path("C:/Windows/Fonts/msyhbd.ttc")
LIMIT = 8388608
MP3_MAX = 524288
PNG_MAX = 1048576
DEADLINE = dt.datetime(2026, 10, 22, 19, 30, tzinfo=dt.UTC)


def now() -> str:
    return dt.datetime.now(dt.UTC).isoformat()


def pin(path: Path) -> FilePin:
    data = path.read_bytes()
    return FilePin(str(path), len(data), hashlib.sha256(data).hexdigest())


def save_bytes(value: JsonValue) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


class Standard(ctypes.Structure):
    _fields_ = [("AllocationSize", ctypes.c_int64), ("EndOfFile", ctypes.c_int64),
                ("NumberOfLinks", W.DWORD), ("DeletePending", ctypes.c_ubyte), ("Directory", ctypes.c_ubyte)]


K = ctypes.WinDLL("kernel32", use_last_error=True)
K.CreateFileW.argtypes = [W.LPCWSTR, W.DWORD, W.DWORD, ctypes.c_void_p, W.DWORD, W.DWORD, W.HANDLE]
K.CreateFileW.restype = W.HANDLE
K.GetFileInformationByHandleEx.argtypes = [W.HANDLE, ctypes.c_int, ctypes.c_void_p, W.DWORD]
K.GetFileInformationByHandleEx.restype = W.BOOL
K.CloseHandle.argtypes = [W.HANDLE]
K.CloseHandle.restype = W.BOOL
K.GetDiskFreeSpaceW.argtypes = [W.LPCWSTR] + [ctypes.POINTER(W.DWORD)] * 4
K.GetDiskFreeSpaceW.restype = W.BOOL
K.GetProcessTimes.argtypes = [W.HANDLE] + [ctypes.c_void_p] * 4
K.GetProcessTimes.restype = W.BOOL


def allocation(path: Path) -> tuple[int, int]:
    """Concentrated Win32 ABI boundary; native integers are checked here."""
    handle = K.CreateFileW(str(path), 0x80, 7, None, 3, 0x00200000, None)
    if type(handle) is not int or handle == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        info = Standard()
        if not K.GetFileInformationByHandleEx(handle, 1, ctypes.byref(info), ctypes.sizeof(info)):
            raise ctypes.WinError(ctypes.get_last_error())
        logical, allocated = int(info.EndOfFile), int(info.AllocationSize)
        if logical < 0 or allocated < 0 or info.Directory or info.DeletePending or info.NumberOfLinks != 1:
            raise SourceError("ordinary singlelink live file")
        return logical, allocated
    finally:
        if not K.CloseHandle(handle):
            raise ctypes.WinError(ctypes.get_last_error())


def cluster_bytes() -> int:
    values = [W.DWORD() for _ in range(4)]
    if not K.GetDiskFreeSpaceW("C:/", *[ctypes.byref(value) for value in values]):
        raise ctypes.WinError(ctypes.get_last_error())
    result = int(values[0].value) * int(values[1].value)
    if result <= 0:
        raise SourceError("native cluster")
    return result


@dataclass
class Budget:
    root: Path
    deadline: dt.datetime
    limit: int = LIMIT
    peak_observed_allocated: int = 0
    guard_count: int = 0

    def snapshot(self) -> JsonObject:
        logical = allocated = count = 0
        stack = [self.root] if self.root.exists() else []
        started = time.monotonic()
        while stack:
            with os.scandir(stack.pop()) as entries:
                for entry in entries:
                    count += 1
                    if count > 2000 or time.monotonic() - started > 15:
                        raise SourceError("finite allocation census")
                    info = entry.stat(follow_symlinks=False)
                    if info.st_file_attributes & 0x400:
                        raise SourceError("reparse entry")
                    if entry.is_dir(follow_symlinks=False):
                        stack.append(Path(entry.path))
                    else:
                        size, assigned = allocation(Path(entry.path))
                        logical += size
                        allocated += assigned
        self.peak_observed_allocated = max(self.peak_observed_allocated, allocated)
        return {"logical_bytes": logical, "allocated_bytes": allocated, "entries": count,
                "payload_bytes_read_for_allocation": 0}

    def guard(self, target: Path, next_payload_bytes: int) -> None:
        if type(next_payload_bytes) is not int or next_payload_bytes < 0:
            raise SourceError("exact prospective payload")
        absolute = target.resolve()
        if not absolute.is_relative_to(self.root.resolve()):
            raise SourceError("exact new root only")
        for path in [target, *target.parents]:
            if path.exists() and path.stat().st_file_attributes & 0x400:
                raise SourceError("reparse target/ancestor")
        if dt.datetime.now(dt.UTC) >= self.deadline:
            raise SourceError("phase deadline reached")
        used = integer(self.snapshot()["allocated_bytes"])
        cluster = cluster_bytes()
        if used + ((next_payload_bytes + cluster - 1) // cluster) * cluster + 8192 > self.limit:
            raise SourceError("Nativeallocated+nextcluster+8192 exceeds8MiB")
        self.guard_count += 1

    def write(self, relative: str, data: bytes) -> FilePin:
        target = self.root / relative
        self.guard(target, len(data))
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(data)
        return pin(target)

    def json(self, relative: str, value: JsonValue) -> FilePin:
        return self.write(relative, save_bytes(value))


def authority() -> tuple[Budget, SourcePlan]:
    card_data = CARD.read_bytes()
    if hashlib.sha256(card_data).hexdigest() != CARD_SHA:
        raise SourceError("actual financial card pin")
    card = object_row(decode(card_data))
    if (card.get("schema") != "xar.capacity.MIDX-one-expire-and-R08-audio-raster-admission.v1"
            or card.get("machine_id") != MACHINE or card.get("admitted") is not True
            or card.get("budget_status") != "GREEN" or card.get("two_actual_TTS_and_one_F13_raster_admitted") is not True):
        raise SourceError("actual R08 media admission")
    selected = [object_row(value) for value in rows(card["scopes"])
                if object_row(value).get("name") == "R08-actual-audio-raster"]
    if len(selected) != 1:
        raise SourceError("one exact financial scope")
    scope = selected[0]
    if (Path(string(scope["root"])) != ROOT or scope.get("owner") != "/root/r08_causal_source"
            or integer(scope["maximum_new_C_allocated_bytes"]) != LIMIT
            or integer(scope["maximum_new_D_allocated_bytes"]) != 0
            or scope["hard_deadline_utc"] != "2026-10-22T19:30:00Z"):
        raise SourceError("scope root/cap/deadline")
    purpose_pin = FilePin.parse(scope["Root_purpose"])
    if Path(purpose_pin.path) != PURPOSE or purpose_pin.sha256 != PURPOSE_SHA:
        raise SourceError("Root specific purpose")
    purpose = object_row(decode(purpose_pin.verify(8192)))
    if (purpose.get("machine_id") != MACHINE or purpose.get("network_TTS_authorized_Steam_stays_offline") is not True
            or Path(string(purpose["exact_root"])) != ROOT
            or integer(purpose["maximum_new_C_allocated_bytes"]) != LIMIT
            or purpose["hard_deadline_utc"] != scope["hard_deadline_utc"]):
        raise SourceError("purpose bounds")
    freeze_data = FREEZE.read_bytes()
    if hashlib.sha256(freeze_data).hexdigest() != FREEZE_SHA:
        raise SourceError("frozen edited source pin")
    freeze = object_row(decode(freeze_data))
    refs = rows(freeze["source_pins"])
    if len(refs) != 8:
        raise SourceError("eight exact frozen sources")
    for value in refs:
        FilePin.parse(value).verify(131072)
    if importlib.metadata.version("edge-tts") != "7.3.1" or importlib.metadata.version("Pillow") != "12.3.0":
        raise SourceError("actual installed dependency changed")
    plan = SourcePlan.parse(decode((OLD_SOURCE / "EDIT-PLAN.source.json").read_bytes()))
    return Budget(ROOT, DEADLINE), plan


def request_payload(cue: Cue) -> JsonObject:
    return {"text": cue.narration_zh, "voice": "zh-CN-XiaoxiaoNeural", "rate": "-5%",
            "pitch": "+0Hz", "volume": "+0%", "audio_format": "mp3", "cache_salt": ""}


def fingerprint(cue: Cue) -> str:
    body: JsonObject = {"schema": "xar-promo-tts-cache-v1",
                        "provider": {"id": "edge-tts", "tool_version": "7.3.1"},
                        "request": request_payload(cue)}
    return hashlib.sha256(canonical(body)).hexdigest().upper()


@dataclass
class LimitedSink:
    budget: Budget
    target: Path
    stream: BinaryIO
    maximum: int = MP3_MAX
    written: int = 0

    def write(self, data: bytes) -> None:
        if not isinstance(data, bytes) or self.written + len(data) > self.maximum:
            raise SourceError("single MP3 byte ceiling")
        self.budget.guard(self.target, len(data))
        self.stream.write(data)
        self.written += len(data)


@dataclass
class BoundedEdgeProvider:
    budget: Budget
    cue: Cue
    calls: int = 0

    async def _receive(self, destination: Path) -> None:
        communicator = Communicate(self.cue.narration_zh, "zh-CN-XiaoxiaoNeural", rate="-5%",
                                   volume="+0%", pitch="+0Hz", connect_timeout=10, receive_timeout=30)
        self.budget.guard(destination, 0)
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("xb") as stream:
            sink = LimitedSink(self.budget, destination, stream)
            async for item in communicator.stream():
                if item["type"] == "audio":
                    data: object = item.get("data")
                    if not isinstance(data, bytes):
                        raise SourceError("validated Edge audio chunk bytes")
                    sink.write(data)
            if sink.written == 0:
                raise SourceError("no actual audio")

    def synthesize(self, destination: Path) -> None:
        self.calls += 1
        if self.calls != 1 or destination.exists():
            raise SourceError("one provider invocation; no retry/cache overwrite")
        if (self.budget.deadline - dt.datetime.now(dt.UTC)).total_seconds() < 150:
            raise SourceError("not enough original time for one bounded call and close")
        asyncio.run(asyncio.wait_for(self._receive(destination), timeout=90))


@runtime_checkable
class IntegerHandle(Protocol):
    def __int__(self) -> int: ...


def process_birth(process: subprocess.Popen[bytes]) -> str:
    handle_value: object = getattr(process, "_handle", None)
    if isinstance(handle_value, bool) or not isinstance(handle_value, IntegerHandle):
        raise SourceError("retained original Windows Popen handle")
    handle = int(handle_value)
    if type(handle) is not int or handle <= 0:
        raise SourceError("native Popen handle integer")
    times = [ctypes.c_uint64() for _ in range(4)]
    if not K.GetProcessTimes(handle, *[ctypes.byref(value) for value in times]):
        raise ctypes.WinError(ctypes.get_last_error())
    return str(times[0].value)


def child(budget: Budget, label: str, argv: list[str], timeout: int) -> tuple[bytes, FilePin]:
    if (budget.deadline - dt.datetime.now(dt.UTC)).total_seconds() < timeout + 15:
        raise SourceError("remaining child/closure wall")
    env = dict(os.environ)
    env.update(TEMP=str(ROOT / "temp"), TMP=str(ROOT / "temp"), PYTHONDONTWRITEBYTECODE="1")
    process = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               creationflags=subprocess.CREATE_NO_WINDOW)
    created: str | None = None
    timed_out = False
    stdout = stderr = b""
    unexpected: BaseException | None = None
    try:
        created = process_birth(process)
        try:
            stdout, stderr = process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            process.terminate()  # This producer's own ffprobe/raster child only.
            try:
                stdout, stderr = process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                stdout, stderr = process.communicate()
    except BaseException as error:
        unexpected = error
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                stdout, stderr = process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                stdout, stderr = process.communicate()
    code = process.wait()
    if len(stdout) + len(stderr) > 32768:
        raise SourceError("finite child output")
    receipt = budget.json("logs/" + label + ".ORIGINAL-WAIT.actual.json",
                          {"machine_id": MACHINE, "observed_at_utc": now(), "argv": [str(item) for item in argv],
                           "pid": process.pid, "process_create_time_100ns": created,
                           "actual_original_wait": True, "returncode": code, "timed_out": timed_out,
                           "unexpected_error": None if unexpected is None else repr(unexpected)[:1000],
                           "stdout": stdout.decode("utf-8", "replace"), "stderr": stderr.decode("utf-8", "replace")})
    if unexpected is not None:
        raise SourceError("original owned child failed before completion: " + label) from unexpected
    if timed_out or code != 0:
        raise SourceError("original child failed; no retry: " + label)
    return stdout, receipt


def copy_cas(budget: Budget, original: FilePin, extension: str) -> FilePin:
    data = original.verify(PNG_MAX if extension == "png" else MP3_MAX)
    relative = "native/artifacts/derived/sha256/" + original.sha256[:2].upper() + "/" + original.sha256.upper() + "." + extension
    result = budget.write(relative, data)
    if (result.bytes, result.sha256) != (original.bytes, original.sha256):
        raise SourceError("actual CAS byte identity")
    return result


def check_header(path: Path) -> None:
    with path.open("rb") as stream:
        data = stream.read(65536)
    if not (data.startswith(b"ID3") or any(data[i] == 0xFF and data[i + 1] & 0xE0 == 0xE0
                                          for i in range(max(0, len(data) - 1)))):
        raise SourceError("actual MP3 signature")


def ffprobe_duration(budget: Budget, cue: Cue, media: FilePin) -> tuple[str, FilePin]:
    argv = [str(FFPROBE), "-v", "error", "-show_entries",
            "format=duration:stream=codec_name,sample_rate,channels", "-of", "json", media.path]
    stdout, _ = child(budget, cue.cue_id + "-ffprobe", argv, 15)
    result = object_row(decode(stdout))
    streams = rows(result["streams"])
    if len(streams) != 1 or object_row(streams[0]).get("codec_name") != "mp3":
        raise SourceError("one real MP3 audio stream")
    seconds = string(object_row(result["format"])["duration"])
    duration(seconds)
    probe = budget.json("probes/" + cue.cue_id + ".actual.json",
                        {"schema": "xar.e04.r08.audio-duration-probe.v1", "machine_id": MACHINE,
                         "media_pin": media.wire(), "actual_original_wait": True,
                         "returncode": 0, "actual_seconds": seconds})
    return seconds, probe


@runtime_checkable
class RasterCallable(Protocol):
    def __call__(self, raw: bytes, regular: Path, bold: Path, *, review_label: bool) -> object: ...


def raster_once(budget: Budget) -> FilePin:
    RASTER.verify(8192)
    budget.json("RASTER-CHILD-ONCE.actual.json",
                {"machine_id": MACHINE, "observed_at_utc": now(), "source": pin(OLD_SOURCE / "F13.svg").wire()})
    spec = importlib.util.spec_from_file_location("r08_retained_series_raster", RASTER.path)
    if spec is None or spec.loader is None:
        raise SourceError("actual retained raster module")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    candidate: object = getattr(module, "raster_image", None)
    if not isinstance(candidate, RasterCallable):
        raise SourceError("narrow retained raster callable boundary")
    value = candidate((OLD_SOURCE / "F13.svg").read_bytes(), REGULAR, BOLD, review_label=False)
    if not isinstance(value, Image.Image) or value.size != (1920, 1080) or value.mode != "RGB":
        raise SourceError("actual1920x1080 RGB card")
    memory = io.BytesIO()
    value.save(memory, format="PNG")
    data = memory.getvalue()
    value.close()
    if len(data) > PNG_MAX:
        raise SourceError("single PNG ceiling")
    result = budget.write("cards/F13.png", data)
    with Image.open(result.path) as reopened:
        if reopened.size != (1920, 1080) or reopened.mode != "RGB":
            raise SourceError("saved PNG actual dimensions/mode")
        reopened.verify()
    budget.json("RASTER-RESULT.actual.json",
                {"machine_id": MACHINE, "observed_at_utc": now(), "original_PNG": result.wire(),
                 "dimensions": [1920, 1080], "mode": "RGB", "review_label": False,
                 "source_SVG": pin(OLD_SOURCE / "F13.svg").wire(), "rasterizer": RASTER.wire()})
    return result


def check_current_sources() -> None:
    p = ROOT / "SOURCE-CHECKS.actual.json"
    r = object_row(decode(p.read_bytes()))
    if (r.get("status") != "PASS" or integer(r.get("strict_original_wait")) != 0
            or integer(r.get("focused_original_wait")) != 0):
        raise SourceError("actual changed-source checks required")
    for value in rows(r["source_pins"]):
        FilePin.parse(value).verify(131072)


def retained_inputs() -> JsonObject:
    records: list[JsonValue] = []
    expected = [(FFPROBE, 222026240, "1786511668000000000", "1125899907837590"),
                (REGULAR, 19704352, "1740539592970276500", "281474977107010"),
                (BOLD, 16883552, "1740539645951922800", "281474977110204")]
    for path, size, mtime, file_id in expected:
        info = path.stat()
        if info.st_size != size or str(info.st_mtime_ns) != mtime or str(info.st_ino) != file_id:
            raise SourceError("retained ffprobe/font identity")
        records.append({"path": str(path), "bytes": size, "mtime_ns": str(info.st_mtime_ns),
                        "st_dev": str(info.st_dev), "st_ino": str(info.st_ino)})
    return {"machine_id": MACHINE, "observed_at_utc": now(), "retained_tools_fonts": records,
            "python": sys.executable, "python_version": sys.version,
            "edge_tts": importlib.metadata.version("edge-tts"),
            "Pillow": importlib.metadata.version("Pillow"),
            "rasterizer": RASTER.wire(), "no_new_dependency": True}


def execute() -> None:
    budget, plan = authority()
    check_current_sources()
    ROOT.mkdir(exist_ok=True)
    (ROOT / "temp").mkdir(exist_ok=True)
    os.environ.update(TEMP=str(ROOT / "temp"), TMP=str(ROOT / "temp"), PYTHONDONTWRITEBYTECODE="1")
    producer_pin = pin(Path(__file__))
    budget.json("ONCE.actual.json",
                {"machine_id": MACHINE, "observed_at_utc": now(), "producer": producer_pin.wire(),
                 "admission": pin(CARD).wire(), "purpose": pin(PURPOSE).wire(),
                 "source_freeze": pin(FREEZE).wire(), "provider_invocations_per_cue": 1,
                 "max_attempts": 1, "no_retry": True})
    voices: list[JsonValue] = []
    receipts: list[JsonValue] = []
    failed = False
    try:
        budget.json("RETAINED-INPUTS.actual.json", retained_inputs())
        for cue in plan.cues:
            provider = BoundedEdgeProvider(budget, cue)
            fp = fingerprint(cue)
            destination = ROOT / "audio-cache" / "edge-tts" / fp[:2] / fp / "audio.mp3"
            budget.json("ONCE-" + cue.cue_id + ".actual.json",
                        {"machine_id": MACHINE, "observed_at_utc": now(), "cue_id": cue.cue_id,
                         "text_sha256": cue.text_sha256(), "request": request_payload(cue),
                         "provider_invocations_max": 1, "max_attempts": 1, "total_timeout_seconds": 90})
            started = time.monotonic()
            try:
                provider.synthesize(destination)
            finally:
                receipt = budget.json("provider-" + cue.cue_id + ".actual.json",
                                      {"machine_id": MACHINE, "observed_at_utc": now(), "cue_id": cue.cue_id,
                                       "provider_invocations": provider.calls, "max_attempts": 1,
                                       "elapsed_seconds": time.monotonic() - started,
                                       "network_request_count": None, "SDK403_fallback": "not_observed_or_instrumented",
                                       "SDK403_fallback_may_retry_once_per_text_chunk": True,
                                       "total_timeout_seconds": 90, "sock_connect_timeout": 10, "sock_read_timeout": 30})
                receipts.append(receipt.wire())
            original = pin(destination)
            check_header(destination)
            seconds, probe = ffprobe_duration(budget, cue, original)
            clock(cue, duration(seconds))  # Real measured seconds; never changed to fit.
            cas = copy_cas(budget, original, "mp3")
            voice: JsonObject = {"cue_id": cue.cue_id, "text_sha256": cue.text_sha256(),
                                 "actual_seconds": seconds, "original_MP3": original.wire(), "native_CAS": cas.wire(),
                                 "duration_probe": probe.wire(), "provider_calls": provider.calls, "atempo_or_trim": False}
            budget.json("VOICE-" + cue.cue_id + ".actual.json", voice)
            voices.append(voice)
            print("ACTUAL VOICE", cue.cue_id, seconds, "seconds", flush=True)
        _, raster_wait = child(budget, "F13-raster", [sys.executable, "-B", "-X", "utf8", str(Path(__file__)), "--raster-worker"], 30)
        raster_result = object_row(decode((ROOT / "RASTER-RESULT.actual.json").read_bytes()))
        original_png = FilePin.parse(raster_result["original_PNG"])
        png_cas = copy_cas(budget, original_png, "png")
        image = budget.json("ACTUAL-IMAGE.actual.json",
                            {"schema": "xar.e04.r08.single-F13.actual-image.v1", "machine_id": MACHINE,
                             "observed_at_utc": now(), "status": "ACTUAL_SINGLE_F13_RASTER", "id": "F13",
                             "source_SVG": pin(OLD_SOURCE / "F13.svg").wire(), "rasterizer": RASTER.wire(),
                             "original_PNG": original_png.wire(), "native_CAS": png_cas.wire(),
                             "dimensions": [1920, 1080], "mode": "RGB", "review_label": False,
                             "raster_original_wait_pin": raster_wait.wire(), "visual_review": "pending"})
        owner = budget.json("VOICE-OWNER-CLOSED.actual.json",
                            {"schema": "xar.e04.r08.two-cue.voice-owner-closed.v1", "machine_id": MACHINE,
                             "observed_at_utc": now(), "status": "CLOSED",
                             "all_original_current_children_wait0": True, "actual_provider_calls": 2,
                             "producer_source_sha256": producer_pin.sha256, "actual_voices": voices,
                             "provider_receipts": receipts, "actual_image_pin": image.wire(),
                             "TTS_is_API": True, "all_child_original_waits_actual": True})
        manifest = budget.json("ACTUAL-VOICES.actual.json",
                               {"schema": "xar.e04.r08.two-cue.actual-voices.v1", "machine_id": MACHINE,
                                "status": "ACTUAL_TWO_CUE_VOICES_MATERIALIZED", "provider": "edge-tts",
                                "voice_name": "zh-CN-XiaoxiaoNeural", "rate": "-5%",
                                "producer_source_pin": producer_pin.wire(), "owner_closed_pin": owner.wire(), "voices": voices})
        verified = verify_actual_voices(Path(manifest.path), plan)
        budget.json("FROZEN-CONSUMER.actual.json",
                    {"machine_id": MACHINE, "observed_at_utc": now(), "actual_voices_pin": manifest.wire(),
                     "consumer_pin": pin(OLD_SOURCE / "two_cue_edit.py").wire(), "passed": True,
                     "actual_voice_rows": [voice.wire() for voice in verified]})
        budget.json("ASSETS.actual.json",
                    {"machine_id": MACHINE, "observed_at_utc": now(), "status": "ACTUAL_TWO_VOICES_AND_SINGLE_F13",
                     "actual_voices_pin": manifest.wire(), "actual_image_pin": image.wire(),
                     "new_provider_invocations": 2, "new_PNG": 1, "movie_render": False,
                     "audio_trim_stretch": False, "Game_SDK_screen_W_writes": 0})
        print("ACTUAL TWO VOICES AND F13 COMPLETE", flush=True)
    except BaseException as error:
        failed = True
        available: list[JsonValue] = []
        for path in ROOT.glob("audio-cache/edge-tts/*/*/audio.mp3"):
            available.append(pin(path).wire())
        budget.json("FAILED-PRESERVED.actual.json",
                    {"machine_id": MACHINE, "observed_at_utc": now(), "diagnostic": repr(error)[:3000],
                     "completed_voices": len(voices), "available_original_or_partial": available,
                     "automatic_retry": False, "remaining_operations_not_started": True})
        raise
    finally:
        snapshot = budget.snapshot()
        budget.json("OWNER-CLOSED.actual.json",
                    {"schema": "xar.e04.r08.audio-raster-owner-closed.v1", "machine_id": MACHINE,
                     "observed_at_utc": now(), "status": "FAILED_PRESERVED" if failed else "COMPLETE",
                     "owned_Popen_remaining": 0, "provider_retried": False, "source_W_writes": 0,
                     "allocation_snapshot": snapshot, "peak_observed_allocated_bytes": budget.peak_observed_allocated,
                     "continuous_peak_sampler": False, "per_write_guard_count": budget.guard_count,
                     "hard_ceiling_bytes": LIMIT, "TTS_source_control_old_roots_writes": 0})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--raster-worker", action="store_true")
    args = parser.parse_args()
    if args.raster_worker and not args.execute:
        budget, _ = authority()
        check_current_sources()
        if not (ROOT / "VOICE-N06-08.actual.json").exists() or not (ROOT / "VOICE-N06-05.actual.json").exists():
            raise SourceError("raster after the actual two voices only")
        raster_once(budget)
    elif args.execute and not args.raster_worker:
        execute()
    else:
        raise SourceError("explicit finite operation required")


if __name__ == "__main__":
    main()
