"""Consume the original Selection-owned readiness; never create another wait."""
from __future__ import annotations
from dataclasses import dataclass
import math
from pathlib import Path
import time
from typing import Mapping, Protocol, runtime_checkable
from progress_contract import Pin, integer, need, obj, pin, text

ROOT = Path(__file__).resolve().parent

@runtime_checkable
class ReadySelection(Protocol):
    @property
    def run_dir(self) -> Path: ...
    @property
    def manifest_path(self) -> Path: ...
    @property
    def context(self) -> Mapping[str, object]: ...

@runtime_checkable
class ReadyClient(Protocol):
    @property
    def selection(self) -> ReadySelection: ...
    @property
    def output(self) -> Path: ...
    @property
    def state(self) -> Path: ...
    @property
    def _readiness_limit(self) -> float: ...
    @property
    def _handle(self) -> object | None: ...
    def guard(self, reserve: float = 90) -> object: ...
    def retain_process(self) -> object: ...

@dataclass(frozen=True)
class ReadyHandoff:
    run_id: str
    window: Pin
    result: Pin
    retained: Pin

    def wire(self) -> dict[str, object]:
        return {"schema":"xar.r05.original-ready-handoff.v1", "run_id":self.run_id,
                "window":self.window.wire(), "result":self.result.wire(), "retained":self.retained.wire()}

def number(value: object, label: str) -> float:
    if type(value) not in (int, float) or not isinstance(value, (int, float)):
        raise ValueError(label+": finite original timing required")
    result = float(value)
    need(math.isfinite(result) and result > 0, label+": positive finite timing required")
    return result

def validate_ready_sources(context: Mapping[str, object]) -> None:
    cfg = obj(obj(context.get("case_inputs")).get("r05_ordinary_runtime"))
    index = Pin.parse(cfg.get("source_index")).read(4*1024*1024)
    rows = index.get("sources")
    if not isinstance(rows, list):
        raise ValueError("Explicit ready successor source index")
    declared = {Pin.parse(row) for row in rows}
    bound_ref = pin(ROOT/"BOUND-SOURCES.json")
    bound = bound_ref.read()
    required = bound.get("sources")
    if not isinstance(required, list):
        raise ValueError("Ready source closure rows")
    exact = {Pin.parse(row) for row in required} | {bound_ref, pin(ROOT/"ready_bootstrap.py")}
    need(exact <= declared, "Ready successor absent or changed in actual source index")
    for reference in exact:
        reference.checked()

def validate_handoff(context: Mapping[str, object], client: ReadyClient,
                     window: Mapping[str, object], result: Mapping[str, object]) -> None:
    """Original JSON contracts stay unchanged; this is a strict consumer only."""
    run = text(context.get("run_id"), "run")
    selection = client.selection
    actual_context = selection.context
    frozen_ref = Pin.parse(actual_context.get("frozen_argv"))
    frozen = frozen_ref.read(4*1024*1024)
    manifest = pin(selection.manifest_path)
    need(run == actual_context.get("run_id") == frozen.get("run_id") == selection.run_dir.name,
         "Readiness crossed the original allocated run")
    need(Path(text(context.get("output"), "output")).resolve() == client.output.resolve()
         and Path(text(context.get("state_dir"), "state")).resolve() == client.state.resolve()
         and Path(text(context.get("run_dir"), "live")).resolve() == selection.run_dir.resolve(),
         "Readiness crossed original client roots")
    need(Pin.parse(context.get("runtime_manifest")) == manifest,
         "Readiness crossed original runtime manifest")
    expected = {"run_id":run, "screen_task":text(frozen.get("screen_task"), "screen task"),
                "live":str(selection.run_dir.resolve()), "state_dir":str(client.state.resolve()),
                "frozen_argv":frozen_ref.wire(), "runtime_manifest":manifest.wire()}
    need(set(window) == {"schema","binding","budget_name","budget_seconds","requested_budget_seconds",
         "readiness_policy","started_at_utc","started_monotonic","deadline_monotonic",
         "deadline_at_utc_estimated","utc_deadline_is_estimate","new_wait_or_replay","business_pass"}
         and set(result) == {"schema","binding","status","observed_at_utc","observed_monotonic",
         "elapsed_seconds","deadline_monotonic","within_original_deadline","host_phase","host_started_at",
         "host_finished_at","restore_status","restore_finished_at","hold_until_utc_estimated","error",
         "host_exit_before_report","new_wait_or_replay","business_pass"}, "Exact original readiness fields")
    need(window.get("schema") == "ck3-mod-acceptance-readiness-window-v1"
         and result.get("schema") == "ck3-mod-acceptance-readiness-window-result-v1",
         "Original once-only readiness contracts required")
    need(obj(window.get("binding")) == expected == obj(result.get("binding")),
         "Readiness original binding differs")
    need(window.get("new_wait_or_replay") is False and result.get("new_wait_or_replay") is False,
         "Readiness must not create another wait or replay")
    need(result.get("status") == "READINESS_HOLD_OBSERVED"
         and result.get("within_original_deadline") is True
         and result.get("host_phase") == "hold" and result.get("host_finished_at") is None
         and result.get("error") is None and result.get("host_exit_before_report") is None,
         "Successful original readiness is required")
    started = number(window.get("started_monotonic"), "original start")
    deadline = number(window.get("deadline_monotonic"), "original deadline")
    observed = number(result.get("observed_monotonic"), "original observation")
    seconds = number(window.get("budget_seconds"), "original budget")
    need(deadline == number(result.get("deadline_monotonic"), "result deadline")
         == number(client._readiness_limit, "same-client readiness limit")
         and started <= observed < deadline and observed <= time.monotonic()
         and abs((deadline-started)-seconds) < 0.00001,
         "Readiness is missing, stale or extends the original clock")
    report = obj(client.guard(1185), "current original hold")
    need(report.get("phase") == "hold" and not report.get("finished_at"),
         "Original hold no longer active")
    retained = obj(client.retain_process(), "same retained process")
    original = pin(client.output/"retained-current-process-identity.json").read()
    need(client._handle is not None and retained == original
         and retained.get("retained_synchronize_query_handle_acquired") is True,
         "Original retained handle evidence missing or changed")
    integer(retained.get("pid"), "retained PID", 1, 0xffffffff)
    number(retained.get("create_time"), "original process birth observation")

def consume_ready(context: Mapping[str, object], client_object: object) -> ReadyHandoff:
    if not isinstance(client_object, ReadyClient):
        raise ValueError("Same original ready CaseClient required")
    client = client_object
    window = pin(client.output/"readiness-window.json")
    result = pin(client.output/"readiness-window-result.json")
    validate_handoff(context, client, window.read(), result.read())
    return ReadyHandoff(text(context.get("run_id"), "run"), window, result,
                        pin(client.output/"retained-current-process-identity.json"))
