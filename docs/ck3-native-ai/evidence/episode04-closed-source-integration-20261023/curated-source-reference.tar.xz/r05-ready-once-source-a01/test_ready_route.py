"""Real Selection.run/readiness/adapter; only declared external seams are finite fakes."""
from __future__ import annotations
from collections.abc import Mapping
from contextlib import ExitStack
from copy import deepcopy
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace
from typing import Protocol, runtime_checkable
import unittest
from unittest.mock import patch

BASE = Path("C:/ck3-e04-resume-20261022-b01")
ROOT = Path(__file__).resolve().parent
EPOCH = sys.argv.pop(1) if len(sys.argv)>1 else "a01"
RUNTIME = BASE/"r05-progress-registration-runtime-a01"
sys.path.insert(0, str(RUNTIME))
from registration_adoption import RegistrationAdoption
RegistrationAdoption.load().bootstrap()
from ck3_mod_acceptance import Selection
from ck3_mod_acceptance_client import CaseClient
import ck3_mod_acceptance_client as original_client
import ready_public as public
from ready_contract import consume_ready, validate_handoff
from native_gate import Gate
from capacity_port import CapacityPort
from r05_normal_save import save_once
from progress_contract import MACHINE, PROGRESS_BINDINGS, Pin, integer, obj, pin, text
from source_control import precheck, usage, write

OLD_RUN = BASE/"r05-progress-a01/driver-runs/desktop-3fevhd2-1c74096080--vanilla--R0243"
PREPARED = BASE/"r05-progress-a01/prepared-a03/prepared-case.json"
PID = 123456789
BIRTH = "134371234567890123"

@runtime_checkable
class OriginalWait(Protocol):
    def wait_hold(self) -> object: ...

@runtime_checkable
class OriginalContext(Protocol):
    def adapter_context(self, output: Path | None = None, inputs: object = None) -> object: ...

def adapter_context(selection: object, output: Path) -> dict[str, object]:
    if not isinstance(selection, OriginalContext):
        raise ValueError("Original Selection adapter_context interface missing")
    return obj(selection.adapter_context(output))

def bounded(path: Path, value: object) -> None:
    raw = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+"\n").encode()
    write(str(path.relative_to(ROOT)), raw)

def old_write_precheck(path: Path, value: object) -> None:
    raw = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+"\n").encode()
    precheck(len(raw))
    ORIGINAL_WRITE(path, value)

ORIGINAL_WRITE = original_client.write_once

class NativeFunction:
    def __init__(self, result: int) -> None:
        self.argtypes: list[object] = []
        self.restype: object = None
        self.result = result
    def __call__(self, *args: object) -> int:
        return self.result

class Kernel:
    def __init__(self) -> None:
        self.OpenProcess = NativeFunction(111)
        self.WaitForSingleObject = NativeFunction(258)
        self.GetExitCodeProcess = NativeFunction(1)
        self.CloseHandle = NativeFunction(1)

class Process:
    def __init__(self, pid: int) -> None:
        if pid != PID:
            raise ValueError("Explicit synthetic PID only; no OS process query")
    def name(self) -> str:
        return "ck3.exe"
    def create_time(self) -> float:
        return 1700000000.25

class FiniteGate:
    """Capacity library is already separately verified; this is its native boundary."""
    def __init__(self) -> None:
        self.blocked = False
        self.closing = False
        self.calls: list[tuple[str, str, str]] = []
    def check(self, kind: str, phase: str, label: str) -> None:
        self.calls.append((kind, phase, label))
    def begin_close(self) -> None:
        self.closing = True
    def observe_snapshot(self, value: object) -> None:
        pass

def current_frame(fixture: Fixture) -> dict[str, object]:
    return {"paused":True,"map_ready":True,"snapshot_id":"synthetic-native-1",
        "revision":108,"native_revision":103,"date_raw":53146896,
        "played_character":{"character_id":77,"alive":True,"source":"native"},
        "local_player_id":77,"episode_projection":"native_campaign","episode_run_id":None,
        "episode_character_id":None,"succession_lifecycle":None,
        "backend_id":"native-headless","source":"injected-dll-named-pipe",
        "diagnostics":{"bridge_pid":PID,"connection_generation":1,"connected":True,
            "pipe_name":"testonly-no-native-transport","hello":{"expected_ck3_version":"1.20.0.4",
            "expected_ck3_sha256":"98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518"}},
        "managed_campaign_run_binding":{"run_id":fixture.run_id,"state_dir":str(fixture.state),
            "bridge_pipe":"testonly-no-native-transport","host_path":"testonly-no-host",
            "frozen_argv_sha256":"a"*64}}

class Fixture:
    def __init__(self, label: str, index: Pin) -> None:
        self.root = ROOT/("fixture-"+label+"-"+EPOCH)
        self.run_id = "TESTONLY-NO-RUNID-"+label+"-"+EPOCH
        self.live = self.root/self.run_id
        self.state = self.root/"state"
        self.keeper = self.root/"keeper"
        self.gate = FiniteGate()
        self.tools: list[str] = []
        self.closes = 0
        self.native_sends = 0
        self.frame_kind = "correct"
        self.bad_report = False
        self.client: CaseClient | None = None
        self.ready_wire: dict[str, object] | None = None
        # The constructor and route are original. Admission/launcher are explicit
        # test-only seams; these synthetic files never allocate a real RunID.
        self.selection = Selection(RUNTIME/"runtime.json", RUNTIME/"products.json",
            "war-episode04-r10", "r10-common-preparation", prepared_path=PREPARED)
        selection = self.selection
        selection.run_dir = self.live
        selection.state_dir = self.state
        selection.context_path = self.root/"context.json"
        self.prepared = obj(deepcopy(selection.prepared),"Actual original prepared fixture")
        selection.prepared = self.prepared
        case_inputs = obj(self.prepared["case_inputs"])
        ordinary = obj(case_inputs["r05_ordinary_runtime"])
        ordinary["source_index"] = index.wire()
        ordinary["film_handoff"] = pin(ROOT/"film_handoff.py").wire()
        case_inputs["r05_ordinary_runtime"] = ordinary
        self.prepared["case_inputs"] = case_inputs
        selection.case = deepcopy(selection.case)
        selection.case["startup"]["state_dir"] = str(self.state)
        selection.adapter_path = ROOT/"ready_public.py"
        selection.values.update(run_id=self.run_id, run_dir=str(self.live))
        selection.argv = selection.build_argv()
        bounded(self.root/"frozen.json", {"run_id":self.run_id,"screen_task":"TESTONLY-NO-LEASE",
            "argv":selection.argv,"runtime_environment":selection.runtime_environment,
            "reviewer":"/root/testonly-no-native"})
        selection.context = {"run_id":self.run_id,"keeper_root":str(self.keeper),
            "steam_offline_receipt":"TESTONLY-NO-STEAM","reviewer":"/root/testonly-no-native",
            "frozen_argv":pin(self.root/"frozen.json").wire()}
        bounded(selection.context_path, selection.context)
        bounded(self.state/"control/ck3.json", {"ck3_pid":PID})
        write(str((self.keeper/"journal.jsonl").relative_to(ROOT)),
            (json.dumps({"result":"OWNED_CAS","lease":{"task_id":"TESTONLY-NO-LEASE"}})+"\n").encode())

    def report(self) -> dict[str, object]:
        return {"state_dir":str(self.state),"agent_source_root":"D:/workspace/ck3_eternal_recurrence",
            "phase":"hold","status":"RED" if self.bad_report else "RUNNING",
            "error":"Synthetic original host error" if self.bad_report else None,"steps":[],
            "finished_at":None,"started_at":"TESTONLY","hold_until_utc_estimated":time.time()+3000,
            "saved_campaign_restore":{"status":"ACTUAL_SAVED_CAMPAIGN_CURRENT_CONTEXT_BOUND","finished_at":"TESTONLY"}}

    def launcher(self, argv: list[str], **kwargs: object) -> subprocess.CompletedProcess[str]:
        bounded(self.live/"native-report.json", self.report())
        return subprocess.CompletedProcess(argv, 0)

    def admission(self, selection: Selection) -> dict[str, object]:
        return {"blockers":[],"testonly_admission_seam":True,"Game_admitted":False}

    def transport(self, client: CaseClient, steps: list[dict[str, object]], name: str,
                  timeout: int | None = None, reserve: int = 90) -> list[dict[str, object]]:
        self.client = client
        tool = text(steps[0].get("tool"), "fixture tool")
        self.tools.append(tool)
        if tool == "ck3_begin_r05_progress_v1":
            raise RuntimeError("TESTONLY_STOP_BEFORE_FIRST_PROGRESS_MUTATION")
        if tool == "ck3_save_checkpoint":
            raise RuntimeError("TESTONLY_UNKNOWN_SAVE_NO_NATIVE_SEND_NO_REPLAY")
        if tool != "ck3_take_snapshot":
            raise ValueError("Test transport refuses all other tools before native send")
        frame = current_frame(self)
        if self.frame_kind == "wrong-run":
            obj(frame["managed_campaign_run_binding"])["run_id"] = "OTHER-TESTONLY"
            frame["managed_campaign_run_binding"] = {"run_id":"OTHER-TESTONLY"}
        if self.frame_kind == "wrong-owner":
            frame["diagnostics"] = {**obj(frame["diagnostics"]),"bridge_pid":True}
        if self.frame_kind == "wrong-actor":
            frame["played_character"] = {"character_id":True,"alive":True,"source":"native"}
        rows: list[dict[str, object]] = [{"id":name,"ok":True,"result":frame}]
        bounded(client.output/(name+".actual-results.json"), {"rows":rows})
        return rows

    def checkpoint(self, client: CaseClient, name: str, request: dict[str, object], reserve: float = 90) -> dict[str, object]:
        owner = {"machine_id":MACHINE,"pid":PID,"created_filetime":BIRTH,"generation":"1",
                 "birth_source":"GetProcessTimes-same-retained-readonly-handle"}
        module = pin(ROOT/"ready_contract.py").wire()
        bounded(self.root/"loaded.json", {"schema":"xar.os.loaded-bridge-readonly.v1","machine_id":MACHINE,
            "pid":PID,"created":BIRTH,"module_base":"1234","file_id":["1","2"],"module":module,
            "exact_process_and_module_rechecked":True,"testonly":True})
        bounded(self.root/"os.json", {"machine_id":MACHINE,"pid":PID,"created_filetime":BIRTH,
            "read_only_OS_query":True,"testonly":True})
        index = obj(obj(self.prepared["case_inputs"])["r05_ordinary_runtime"])["source_index"]
        bindings: dict[str, object] = {"machine_id":MACHINE,"run_id":self.run_id,"state_dir":str(self.state),
            "bridge_pipe":"testonly-no-native-transport","owner":owner,"actor_id":77,
            "start_date_raw":"53146896","end_date_raw":"53147616","maximum_total_actual_days":30,
            "maximum_actual_ordinary_auto_turns":256,"maximum_actual_Film_Starts":1,
            "hard_deadline_utc":"2099-01-01T00:00:00Z","runtime":pin(self.selection.runtime_path).wire(),
            "prepared":pin(PREPARED).wire(),"source_index":index,
            "loaded_bridge":pin(self.root/"loaded.json").wire(),"OS_identity":pin(self.root/"os.json").wire()}
        bounded(self.root/"financial.json", {"schema":"xar.capacity.r05-ordinary-progress-admission.v1",
            **{key:bindings[key] for key in ("machine_id","run_id","hard_deadline_utc","runtime","prepared","source_index",
              "maximum_total_actual_days","maximum_actual_ordinary_auto_turns","maximum_actual_Film_Starts")},"admitted":True})
        bindings["capacity"] = pin(self.root/"financial.json").wire()
        if set(bindings) != PROGRESS_BINDINGS:
            raise ValueError("Test fixture uses the original exact ProgressScope producer contract")
        bounded(self.root/"root-auth.json", {"schema":"xar.root.r05-ordinary-progress-admission.v1",
            "reviewer":"/root","ordinary_progress_admitted":True,"initializer_admitted":False,**bindings,
            "testonly_not_actual_authorization":True})
        bounded(self.root/"scope.json", {"schema":"xar.r05.ordinary-progress-scope.v1",**bindings,
            "Root_authorization":pin(self.root/"root-auth.json").wire()})
        return {"run_id":self.run_id,"reviewer":client.operator_reviewer,
                "progress_scope":pin(self.root/"scope.json").wire()}

    def close(self, client: CaseClient, disposition: str) -> dict[str, object]:
        self.client = client
        self.closes += 1
        if self.run_id.startswith("TESTONLY-NO-RUNID-positive-"):
            self.ready_wire = consume_ready(adapter_context(self.selection,client.output), client).wire()
        return {"testonly_no_GUI":True,"normal_close_qualified":False}

    def run(self) -> dict[str, object]:
        old = public.library()
        def admission(selection: Selection) -> dict[str, object]:
            return self.admission(selection)
        def transport(client: CaseClient, steps: list[dict[str, object]], name: str,
                      timeout: int | None = None, reserve: int = 90) -> list[dict[str, object]]:
            return self.transport(client, steps, name, timeout, reserve)
        def checkpoint(client: CaseClient, name: str, request: dict[str, object], reserve: float = 90) -> dict[str, object]:
            return self.checkpoint(client, name, request, reserve)
        def close(client: CaseClient, disposition: str) -> dict[str, object]:
            return self.close(client, disposition)
        with ExitStack() as stack:
            stack.enter_context(patch.object(Selection,"preflight",admission))
            stack.enter_context(patch("ck3_mod_acceptance.subprocess.run",side_effect=self.launcher))
            stack.enter_context(patch("psutil.Process",Process))
            stack.enter_context(patch("ctypes.WinDLL",return_value=Kernel()))
            stack.enter_context(patch.object(original_client,"write_once",old_write_precheck))
            stack.enter_context(patch.object(CaseClient,"execute_plan",transport))
            stack.enter_context(patch.object(CaseClient,"root_checkpoint",checkpoint))
            stack.enter_context(patch.object(CaseClient,"normal_close",close))
            stack.enter_context(patch.object(Gate,"actual",return_value=self.gate))
            # The retained FILETIME query is a declared OS seam, not a new client.
            module = sys.modules[CapacityPort.__mro__[1].__module__]
            stack.enter_context(patch.object(module,"retained_birth",return_value=BIRTH))
            # These original source functions keep their actual create-only
            # implementations; the wrapper adds source-lane Native prechecks.
            original_remote_write = getattr(module,"write")
            def checked_original_write(path: Path, value: object) -> object:
                precheck(len((json.dumps(value,ensure_ascii=False)+"\n").encode()))
                return original_remote_write(path,value)
            stack.enter_context(patch.object(module,"write",checked_original_write))
            save_module = sys.modules[save_once.__module__]
            original_save_write = getattr(save_module,"write")
            def checked_save_write(path: Path, value: object) -> object:
                precheck(len((json.dumps(value,ensure_ascii=False)+"\n").encode()))
                return original_save_write(path,value)
            stack.enter_context(patch.object(save_module,"write",checked_save_write))
            result: object = self.selection.run()
        return obj(result)

def make_index() -> Pin:
    row = json.loads((RUNTIME/"source-index.json").read_bytes())
    refs = [Pin.parse(value) for value in row["sources"]]
    bound = pin(ROOT/"BOUND-SOURCES.json")
    source_values = bound.read()["sources"]
    if not isinstance(source_values, list):
        raise ValueError("Bound source rows")
    refs += [Pin.parse(value) for value in source_values]+[bound,pin(ROOT/"ready_bootstrap.py")]
    row["sources"] = [reference.wire() for reference in {reference.path:reference for reference in refs}.values()]
    row["native_DLL"] = pin(ROOT/"ready_contract.py").wire()
    bounded(ROOT/("fixture-source-index-"+EPOCH+".json"), row)
    return pin(ROOT/("fixture-source-index-"+EPOCH+".json"))

class Focused(unittest.TestCase):
    index: Pin
    positive: Fixture
    positive_result: dict[str, object]
    @classmethod
    def setUpClass(cls) -> None:
        cls.index = make_index()
        cls.positive = Fixture("positive", cls.index)
        cls.positive_result = cls.positive.run()

    def test_real_selection_wait_once_adapter_to_first_mutation_and_original_finally(self) -> None:
        fixture = self.positive
        result = self.positive_result
        self.assertNotIn("case_error", result)
        case = obj(result["case_result"])
        self.assertIn("TESTONLY_STOP_BEFORE_FIRST_PROGRESS_MUTATION", text(case.get("error"), "stop"))
        self.assertEqual(fixture.tools.count("ck3_begin_r05_progress_v1"), 1)
        self.assertEqual(fixture.tools.count("ck3_save_checkpoint"), 1)
        self.assertEqual(fixture.tools.count("ck3_auto_turn"), 0)
        self.assertEqual(fixture.closes, 1)
        self.assertEqual(fixture.native_sends, 0)
        self.assertTrue(fixture.gate.closing)
        output = fixture.live/"case-output"
        self.assertEqual(len(list(output.glob("readiness-window.json"))), 1)
        self.assertEqual(len(list(output.glob("readiness-window-result.json"))), 1)
        self.assertEqual(json.loads((output/"readiness-window-result.json").read_bytes())["status"], "READINESS_HOLD_OBSERVED")
        self.assertIsNotNone(fixture.client)
        if fixture.client is None:
            raise ValueError("Actual original CaseClient not observed")
        # The original create-only refusal remains an error, even after success.
        with self.assertRaises(FileExistsError):
            legacy: object = fixture.client
            if not isinstance(legacy, OriginalWait):
                raise ValueError("Original wait interface missing")
            legacy.wait_hold()
        self.assertEqual(obj(case["ordinary_save"])["replayed"], False)
        print("REAL_ROUTE_ONCE: Selection.run -> actual CaseClient.wait_hold/open(x) -> loaded ready_public -> actual Port/Frame -> StopMutation; Save once; original Selection finally close once; native sends0")

    def test_real_wrong_native_frame_and_original_host_error_reject_before_mutation(self) -> None:
        for label, kind in (("wrongframe","wrong-run"),("wrongowner","wrong-owner")):
            fixture = Fixture(label, self.index)
            fixture.frame_kind = kind
            result = fixture.run()
            self.assertIn("case_error", result)
            self.assertNotIn("ck3_begin_r05_progress_v1", fixture.tools)
            self.assertEqual(fixture.closes, 1)
        fixture = Fixture("hosterror", self.index)
        fixture.bad_report = True
        result = fixture.run()
        self.assertIn("case_error", result)
        self.assertEqual(fixture.tools, [])
        self.assertEqual(fixture.closes, 1)
        report = json.loads((fixture.live/"case-output/readiness-window-result.json").read_bytes())
        self.assertEqual(report["status"], "READINESS_ERROR")
        print("NEGATIVE_REAL_ROUTE: wrong run/owner Frame rejected; original RED host rejected in real wait; mutation0; finally close preserved")

    def test_handoff_wrong_missing_types_and_roundtrip_no_wait_restart(self) -> None:
        # Reuse the successful immutable producer output in memory. No new wait.
        positive = self.positive.live/"case-output"
        window = obj(json.loads((positive/"readiness-window.json").read_bytes()))
        result = obj(json.loads((positive/"readiness-window-result.json").read_bytes()))
        self.assertEqual(window, json.loads(json.dumps(window)))
        self.assertEqual(result, json.loads(json.dumps(result)))
        client = self.positive.client
        if client is None:
            raise ValueError("Actual original client required")
        context = adapter_context(self.positive.selection,client.output)
        for key, value in (("deadline_monotonic",True),("deadline_monotonic",1.0),
                           ("deadline_monotonic",None),("status","READINESS_TIMEOUT"),
                           ("within_original_deadline",1),("error","unknown")):
            wrong = deepcopy(result);wrong[key] = value
            with self.assertRaises(ValueError):
                validate_handoff(context, client, window, wrong)
        for key in ("host_finished_at","host_exit_before_report","binding"):
            wrong = deepcopy(result);del wrong[key]
            with self.assertRaises(ValueError):
                validate_handoff(context, client, window, wrong)
        wrong = deepcopy(result);binding = obj(wrong["binding"])
        binding["run_id"] = "ANOTHER-RUN";wrong["binding"] = binding
        with self.assertRaises(ValueError):
            validate_handoff(context, client, window, wrong)
        missing = object.__new__(CaseClient)
        missing.__dict__.update(client.__dict__)
        missing.output = ROOT/"never-produced-readiness"
        with self.assertRaises(FileNotFoundError):
            consume_ready(context, missing)
        self.assertIsNotNone(self.positive.ready_wire)
        self.assertEqual(self.positive.ready_wire, json.loads(json.dumps(self.positive.ready_wire)))
        self.assertNotIn("wait_hold", public.Client.__dict__)
        source = (ROOT/"ready_public.py").read_text()
        self.assertNotIn("client.wait_hold()", source)
        self.assertIn("consume_ready(context,client)", source)
        print("JSON_DOMAIN: original readiness roundtrip; Client protocol has no second wait; original direct second-wait refusal covered by real route")

if __name__ == "__main__":
    unittest.main(verbosity=2)
