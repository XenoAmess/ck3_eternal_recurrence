"""Finite actual47 executor; source checks use pure Protocol fakes, never media tools."""
from __future__ import annotations

import ctypes
from ctypes import wintypes
from dataclasses import dataclass, replace
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from typing import Protocol
from executor_contract import (
    ActualMovie, BASE, Budget, CAS_TOTAL_MAX, CUE_MAX, FINAL_FREEZE, FONT_PIN, FULL_MAX,
    FilePin, FullTimeline, JsonObject, JsonValue, MACHINE, MEDIA_ROOT, NewOutputBudget,
    Operation, ROOT_REVIEW, Resources, RetainedAsset, RuntimeAdmission, SOURCE_DEADLINE,
    SOURCE_LIMIT, SOURCE_ROOT, SourceError, canonical, concat_plan, decimal64, decode,
    integer, json_domain, link_new_output, need, now, object_row, pin, process_birth,
    rows, source_authority, string, validate_encoded_probe, SOURCE_PURPOSE, SOURCE_CARD_PATH,
    CompleteRecipe, CueProduct, CueRecipe,
)
from xar_promo.process import CommandResult, CommandSpec, PartialArtifactSnapshot
from xar_promo.render import RenderPlan, execute_render_plan

SUPPORT = Path("C:/ck3-e04-resume-20261020-a01/r17-b-firstclip-qa-a01")
for _name, _size, _sha in (
    ("qa_contract.py", 7782, "3e4767dd66b8b4a1ef537b2126b564a15bf58e8c8082dc948631b2358bb071fb"),
    ("qa_firstclip.py", 22781, "27634f311d1c2f11707fcf5128138cf13bc587b78677dd1a1a90b7a86e30f955"),
):
    FilePin(str(SUPPORT / _name), _size, _sha).verify(32768)
sys.path.insert(0, str(SUPPORT))
from qa_firstclip import Native, Waitable, finish_custody
from qa_contract import Pin as JobPin


class JobOps(Protocol):
    def count(self) -> int: ...
    def terminate(self) -> None: ...
    def close(self) -> None: ...


def custody_good(value: JsonObject) -> bool:
    return (type(value.get("original_wait")) is int and value.get("original_wait") == 0
            and type(value.get("job_active_processes")) is int and value.get("job_active_processes") == 0
            and value.get("job_closed") is True and value.get("custody_errors") == [])


def close_owned(process: Waitable, job: JobOps, *, failed: bool) -> JsonObject:
    return object_row(json_domain(finish_custody(process, failed=failed,
        terminate=job.terminate, active=job.count, close=job.close)))


@dataclass(frozen=True)
class NativeJob:
    native: Native
    handle: int

    def count(self) -> int:
        try:
            return self.native.count(self.handle)
        except (ValueError, TypeError) as error:
            raise OSError(str(error)) from error

    def terminate(self) -> None:
        try:
            self.native.stop(self.handle)
        except (ValueError, TypeError) as error:
            raise OSError(str(error)) from error

    def close(self) -> None:
        try:
            self.native.close(self.handle)
        except (ValueError, TypeError) as error:
            raise OSError(str(error)) from error


@dataclass(frozen=True)
class Request:
    operation: Operation
    cue_id: str
    timeout: int
    output_cap: int

    def validate(self) -> None:
        expected = {"cue_encode": (300, CUE_MAX), "cue_decode_probe": (120, 0),
                    "movie_concat": (180, FULL_MAX), "movie_decode_probe": (180, 0),
                    "census": (15, 0)}
        need(type(self.timeout) is type(self.output_cap) is int
             and self.operation in expected and (self.timeout, self.output_cap) == expected[self.operation],
             "Single finite operation policy")
        need(bool(self.cue_id), "Actual operation key")


def start_ready(*, suspended: bool, assigned: bool, member: bool,
                active: int, flags: int) -> None:
    need(suspended is True and assigned is True and member is True
         and type(active) is int and active == 1 and type(flags) is int and flags & 8192 != 0,
         "Assigned verified kill-on-close Job before original thread resumes")


@dataclass(frozen=True)
class OwnedResult:
    command: CommandResult
    wait_pin: FilePin
    stdout_pin: FilePin


class Owner:
    def __init__(self, admission: RuntimeAdmission, resources: Resources) -> None:
        self.budget = admission.budget
        self.resources = resources
        helper = resources.tools.job_helper
        self.native = Native(JobPin(helper.path, helper.bytes, helper.sha256))
        self.children = 0
        self.codes: list[int] = []
        self.custodies: list[JsonValue] = []
        self.last: OwnedResult | None = None
        self.current: Request | None = None

    def call(self, spec: CommandSpec, *, audit_directory: Path, request: Request) -> OwnedResult:
        request.validate()
        root = self.budget.root
        need(audit_directory.resolve().is_relative_to(root.resolve()), "Own new audit destination")
        if request.operation in ("cue_encode", "movie_concat"):
            need(Path(spec.argv[0]) == Path(self.resources.tools.ffmpeg.media.path)
                 and len(spec.partial_artifacts) == 1, "Exact installed encoder/concat")
        elif request.operation in ("cue_decode_probe", "movie_decode_probe"):
            need(Path(spec.argv[0]) == Path(self.resources.tools.ffprobe.media.path)
                 and not spec.partial_artifacts, "Exact installed decoder probe")
        else:
            need(spec.argv[0].lower() == "c:/windows/system32/tasklist.exe", "Exact occupancy tool")
        need((self.budget.deadline - dt.datetime.now(dt.UTC)).total_seconds() > request.timeout + 20,
             "Remaining finite child and closure interval")
        self.budget.guard(audit_directory / "protocol-reserve", request.output_cap + 524288)
        for partial in spec.partial_artifacts:
            need(partial.resolve().is_relative_to(root.resolve()) and not partial.exists(), "Create-only own partial")
            partial.parent.mkdir(parents=True, exist_ok=True)
        relative = audit_directory.relative_to(root)
        self.budget.json(str(relative / "argv.actual.json"),
            {"machine_id": MACHINE, "observed_at_utc": now(), "operation": request.operation,
             "cue_id": request.cue_id, "argv": list(spec.argv), "timeout_seconds": request.timeout,
             "reserved_external_output_bytes": request.output_cap, "max_attempts": 1})
        handle = self.native.call("_new_job")
        need(type(handle) is int and handle > 0, "Owned native Job handle")
        if type(handle) is not int:
            raise SourceError("Job handle narrowing")
        job = NativeJob(self.native, handle)
        process: subprocess.Popen[bytes] | None = None
        created: str | None = None
        assigned = False
        stdout = stderr = b""
        failure: str | None = None
        custody: JsonObject = {}
        env = dict(os.environ)
        env.pop("PYTHONPATH", None)
        env.pop("MYPYPATH", None)
        env.update(TEMP=str(root / "temp"), TMP=str(root / "temp"), PYTHONDONTWRITEBYTECODE="1")
        started = time.monotonic()
        try:
            process = subprocess.Popen(spec.argv, cwd=spec.cwd or root, env=env,
                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                creationflags=4 | subprocess.CREATE_NO_WINDOW | subprocess.BELOW_NORMAL_PRIORITY_CLASS)
            self.children += 1
            created = process_birth(process)
            original: object = getattr(process, "_handle")
            need(isinstance(original, int) and not isinstance(original, bool), "Retained original Popen HANDLE")
            if not isinstance(original, int):
                raise SourceError("Handle narrowing")
            assigned = bool(self.native.call("_assign_job", handle, original))
            member = wintypes.BOOL()
            in_job = bool(self.native.call("_in_job", original, handle, ctypes.byref(member)))
            flags = self.native.call("_verified_limit_flags", handle)
            need(type(flags) is int, "Exact native flags type")
            if type(flags) is not int:
                raise SourceError("Native flags narrowing")
            start_ready(suspended=True, assigned=assigned, member=in_job and bool(member.value),
                        active=job.count(), flags=flags)
            self.budget.json(str(relative / "ORIGINAL-START.actual.json"),
                {"machine_id": MACHINE, "observed_at_utc": now(), "pid": process.pid,
                 "process_create_time_100ns": created, "assigned_before_resume": True})
            self.native.call("_resume_only_thread", process.pid)
            while True:
                need(time.monotonic() - started <= request.timeout, "Actual finite timeout; no retry")
                for partial in spec.partial_artifacts:
                    if partial.exists():
                        need(partial.stat().st_size <= request.output_cap, "Actual reserved output cap")
                try:
                    stdout, stderr = process.communicate(timeout=.25)
                    break
                except subprocess.TimeoutExpired:
                    continue
        except BaseException as error:
            failure = type(error).__name__ + ": " + str(error)[:2000]
        finally:
            if process is None:
                job.close()
                custody = {"original_wait": None, "job_active_processes": 0, "job_closed": True}
            else:
                if not assigned and process.poll() is None:
                    process.kill()
                custody = close_owned(process, job, failed=failure is not None)
                stdout, stderr = process.communicate(timeout=10)
                code = process.wait(timeout=10)
                self.codes.append(code)
                self.children -= 1
            self.custodies.append(custody)
            truncated = len(stdout) > 262144 or len(stderr) > 262144
            if truncated:
                failure = (failure or "") + " bounded protocol exceeded; retained prefix only"
            stdout_pin = self.budget.write(str(relative / "stdout.txt"), stdout[:262144])
            stderr_pin = self.budget.write(str(relative / "stderr.txt"), stderr[:262144])
            wait_pin = self.budget.json(str(relative / "ORIGINAL-WAIT.actual.json"),
                {"schema": "xar.e04.final47.original-wait.v1", "machine_id": MACHINE,
                 "observed_at_utc": now(), "operation": request.operation, "cue_id": request.cue_id,
                 "argv": list(spec.argv), "pid": None if process is None else process.pid,
                 "process_create_time_100ns": created, "actual_original_Popen": process is not None,
                 "actual_original_wait": process is not None, "custody": custody,
                 "stdout": stdout_pin.wire(), "stderr": stderr_pin.wire(),
                 "protocol_prefix_only": truncated, "stdout_full_bytes": len(stdout),
                 "stderr_full_bytes": len(stderr), "stdout_full_sha256": hashlib.sha256(stdout).hexdigest(),
                 "stderr_full_sha256": hashlib.sha256(stderr).hexdigest(),
                 "owner_error": failure, "no_retry": True, "elapsed_seconds": time.monotonic() - started})
        good = failure is None and custody_good(custody)
        result = CommandResult(spec, 0 if good else -1, stdout.decode("utf-8", "replace"),
            stderr.decode("utf-8", "replace"), "succeeded" if good else "failed", audit_directory,
            tuple(PartialArtifactSnapshot(p, p.exists(), p.stat().st_size if p.exists() else None)
                  for p in spec.partial_artifacts))
        owned = OwnedResult(result, wait_pin, stdout_pin)
        self.last = owned
        need(good, "Original child failed; preserved: " + wait_pin.path)
        return owned

    def public_runner(self, spec: CommandSpec, *, audit_directory: Path) -> CommandResult:
        request = self.current
        need(request is not None, "Explicit active operation request")
        if request is None:
            raise SourceError("Request narrowing")
        return self.call(spec, audit_directory=audit_directory, request=request).command

    def render(self, plan: RenderPlan, request: Request) -> OwnedResult:
        for generated in plan.generated_files:
            need(generated.path.is_relative_to(self.budget.root), "Own generated text")
            self.budget.write(str(generated.path.relative_to(self.budget.root)),
                              generated.content.encode(generated.encoding))
        self.current = request
        self.last = None
        try:
            execute_render_plan(replace(plan, generated_files=()), command_runner=self.public_runner)
        finally:
            self.current = None
        result = self.last
        need(result is not None, "Actual original render result")
        if result is None:
            raise SourceError("Render result narrowing")
        return result

    def idle(self) -> None:
        for name in ("ck3.exe", "ffmpeg.exe"):
            spec = CommandSpec.create(("C:/Windows/System32/tasklist.exe", "/FI",
                "IMAGENAME eq " + name, "/FO", "CSV", "/NH"), label="Actual fresh media occupancy")
            result = self.call(spec, audit_directory=self.budget.root / "audit/occupancy" / name,
                               request=Request("census", name, 15, 0))
            need(name not in result.command.stdout.lower(), "Game or other FFmpeg owns the scene")


def probe(owner: Owner, media: FilePin, frames: int, key: str,
          *, movie: bool, expected_argv: tuple[str, ...]) -> FilePin:
    need(expected_argv[-1] == media.path or Path(expected_argv[-1]) == Path(media.path), "Actual probe source")
    request = Request("movie_decode_probe" if movie else "cue_decode_probe", key, 180 if movie else 120, 0)
    spec = CommandSpec.create(expected_argv, label="Actual full decode/count probe")
    result = owner.call(spec, audit_directory=owner.budget.root / "audit" / key / "probe", request=request)
    observed = object_row(decode(result.stdout_pin.verify(65536)))
    validate_encoded_probe(observed, frames)
    return owner.budget.json("probes/" + key + ".actual.json",
        {"schema": "xar.e04.final47.encode-probe.v1", "machine_id": MACHINE,
         "actual_decode_count_frames": True, "original_wait": 0, "expected_frames": frames,
         "media": media.wire(), "original_wait_pin": result.wait_pin.wire(), "observed": observed})


def execute(card: FilePin) -> FilePin:
    admission = RuntimeAdmission.parse(card)
    resources = Resources.load()
    complete = CompleteRecipe.prepare(resources, admission.r05)
    budget = admission.budget
    budget.guard(budget.root / "temp/reserved", 8192)
    (budget.root / "temp").mkdir(parents=True, exist_ok=True)
    budget.json("EXECUTOR-ONCE.actual.json", {"machine_id": MACHINE, "observed_at_utc": now(),
        "financial_card": card.wire(), "Root_purpose": admission.Root_purpose.wire(),
        "executor_source_freeze": admission.executor_freeze.wire(), "final47_source_freeze": FINAL_FREEZE.wire(),
        "Root_source_review": ROOT_REVIEW.wire(), "font": FONT_PIN.wire(),
        "actual_R05_acceptance": admission.r05.source.wire(), "Game_closed_proof": admission.game_closed.wire(),
        "max_attempts_per_command": 1, "no_automatic_retry": True})
    budget.json("COMPLETE47-RECIPE.actual.json", complete.wire())
    owner: Owner | None = None
    products: list[CueProduct] = []
    failed = False
    metadata: FilePin | None = None
    try:
        owner = Owner(admission, resources)
        owner.idle()
        for recipe in complete.cues:
            spec = recipe.spec
            key = spec.cue.cue_id
            budget.json("once/" + key + ".actual.json", {"machine_id": MACHINE,
                "observed_at_utc": now(), "input": spec.binding(), "max_attempts": 1})
            rendered = owner.render(recipe.render, Request("cue_encode", key, 300, CUE_MAX))
            work = pin(recipe.render.final_output)
            decoded = probe(owner, work, spec.slot.frames, key, movie=False,
                            expected_argv=recipe.decode_probe_argv)
            native = link_new_output(budget, work, CUE_MAX)
            product = CueProduct(spec, pin(budget.root / "subtitles" / (key + ".ass")),
                work, native, rendered.stdout_pin, rendered.wait_pin, decoded)
            product = CueProduct.parse(json_domain(product.wire()), spec)
            product.verify(resources)
            products.append(product)
            need(sum(p.native.media.bytes for p in products) <= CAS_TOTAL_MAX, "Actual aggregate cue CAS cap")
            budget.json("products/" + key + ".actual.json", product.wire())
            print("ACTUAL FINAL47 CUE", key, spec.slot.frames, flush=True)
        timeline = FullTimeline.actual(tuple(products), resources)
        timeline = FullTimeline.consume(json_domain(timeline.wire()), tuple(r.spec for r in complete.cues), resources)
        timeline_pin = budget.json("FULL47-TIMELINE.actual.json", timeline.wire())
        plan = concat_plan(resources, timeline, root=budget.root)
        joined = owner.render(plan, Request("movie_concat", "full47", 180, FULL_MAX))
        work = pin(plan.final_output)
        total_frames = sum(p.spec.slot.frames for p in products)
        full_argv = (resources.tools.ffprobe.media.path, "-v", "error", "-count_frames",
                     "-show_streams", "-show_format", "-of", "json", work.path)
        full_probe = probe(owner, work, total_frames, "full47", movie=True, expected_argv=full_argv)
        movie_cas = link_new_output(budget, work, FULL_MAX)
        movie = ActualMovie(now(), total_frames, timeline_pin, work, movie_cas,
            joined.wait_pin, joined.stdout_pin, full_probe)
        movie = ActualMovie.parse(json_domain(movie.wire(admission, resources)), admission, resources)
        movie.verify(admission, resources, timeline)
        metadata = budget.json("FINAL47-ACTUAL-METADATA.actual.json", movie.wire(admission, resources))
        return metadata
    except BaseException as error:
        failed = True
        budget.json("FAILED-PRESERVED.actual.json", {"machine_id": MACHINE, "observed_at_utc": now(),
            "diagnostic": type(error).__name__ + ": " + str(error)[:2500], "actual_completed_cues": len(products),
            "partial_outputs_retained": True, "no_retry": True, "actual_metadata": None})
        raise
    finally:
        closed_custodies: list[JsonValue] = [] if owner is None else owner.custodies
        budget.json("EXECUTOR-OWNER-CLOSED.actual.json",
            {"schema": "xar.e04.final47.executor-owner-closed.v1", "machine_id": MACHINE,
             "observed_at_utc": now(), "status": "FAILED_PRESERVED" if failed else "COMPLETE",
             "owned_Popen_remaining": 0 if owner is None else owner.children,
             "actual_original_waits": [] if owner is None else [c for c in owner.codes],
             "all_original_children_wait0_Job0": bool(closed_custodies) and all(custody_good(object_row(c)) for c in closed_custodies),
             "actual_custodies": closed_custodies,
             "actual_completed_cues": len(products), "actual_movie_metadata": None if metadata is None else metadata.wire(),
             "native_allocation_before_receipt": budget.snapshot(), "maximum_C_bytes": budget.limit,
             "actual_peak_observed_allocated_bytes": budget.peak_observed_allocated,
             "perwrite_guards": budget.guard_count, "oldsource_W_D_Game_SDK_screen_writes": 0})


CODE_NAMES = ("executor_contract.py", "produce_final47.py", "check_executor.py")


def source_child(budget: Budget, attempt: str, key: str, argv: tuple[str, ...], *, strict: bool) -> FilePin:
    budget.guard(SOURCE_ROOT / attempt / (key + ".protocol-reserve"), 65536)
    env = dict(os.environ)
    env.pop("PYTHONPATH", None)
    env.pop("MYPYPATH", None)
    env.update(TEMP=str(SOURCE_ROOT / "temp"), TMP=str(SOURCE_ROOT / "temp"), PYTHONDONTWRITEBYTECODE="1")
    if strict:
        env["PYTHONPATH"] = "C:/ck3-e04-resume-20261020-a01/r08-mypy1201-tools-2115-a01/Lib"
        env["MYPYPATH"] = os.pathsep.join((str(SOURCE_ROOT), str(BASE / "final47-source-a01"),
            str(BASE / "root/subtitles"), "C:/ck3-e04-resume-20261020-a01/r22-mechanics-render-a01",
            str(BASE / "r08-selected-render-source-a01"), str(BASE / "r08-edit-source-a01"),
            str(BASE / "r08-audio-raster-a01"), str(SUPPORT)))
    child: subprocess.Popen[bytes] = subprocess.Popen(argv, cwd=SOURCE_ROOT, env=env,
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    created: str | None = None
    out = err = b""
    failure: str | None = None
    timed_out = False
    try:
        created = process_birth(child)
        try:
            out, err = child.communicate(timeout=90)
        except subprocess.TimeoutExpired:
            timed_out = True
            child.kill()
            out, err = child.communicate(timeout=15)
    except BaseException as error:
        failure = type(error).__name__ + ": " + str(error)[:1500]
    finally:
        if child.poll() is None:
            child.kill()
        code = child.wait(timeout=15)
        if not out and not err:
            out, err = child.communicate(timeout=5)
    need(len(out) <= 65536 and len(err) <= 65536, "Small bounded pure source protocols")
    stdout = budget.write(attempt + "/" + key + ".stdout.log", out)
    stderr = budget.write(attempt + "/" + key + ".stderr.log", err)
    return budget.json(attempt + "/" + key + ".original-wait.actual.json",
        {"schema": "xar.e04.final47.executor-source-original-wait.v1", "machine_id": MACHINE,
         "observed_at_utc": now(), "argv": list(argv), "pid": child.pid,
         "process_create_time_100ns": created, "actual_original_Popen": True, "original_wait": code,
         "owner_error": failure, "timed_out": timed_out, "stdout": stdout.wire(), "stderr": stderr.wire()})


def source_checks(attempt: str) -> FilePin:
    need(re.fullmatch(r"a[0-9]{2}", attempt) is not None and not (SOURCE_ROOT / attempt).exists(),
         "Create-only source attempt")
    budget = source_authority()
    budget.guard(SOURCE_ROOT / "temp/reserve", 8192)
    (SOURCE_ROOT / "temp").mkdir(exist_ok=True)
    focused = source_child(budget, attempt, "focused",
        (sys.executable, "-B", "-X", "utf8", str(SOURCE_ROOT / "check_executor.py")), strict=False)
    strict = source_child(budget, attempt, "strict",
        (sys.executable, "-B", "-X", "utf8", "-m", "mypy", "--strict", "--follow-untyped-imports",
         "--follow-imports=normal", "--no-incremental", "--cache-dir=nul",
         *(str(SOURCE_ROOT / name) for name in CODE_NAMES)), strict=True)
    for ref in (focused, strict):
        result = object_row(decode(ref.verify(16384)))
        need(integer(result["original_wait"]) == 0 and result["timed_out"] is False
             and result["owner_error"] is None, "Source failure retained; no freeze")
    # Import after checks so dependency closure includes the actual pure test/production seam.
    from check_executor import run_checks
    report = run_checks()
    need(report["status"] == "PASS", "Actual pure focused production contract")
    dependencies: list[JsonValue] = []
    paths: set[Path] = set()
    for name, module in tuple(sys.modules.items()):
        if name.startswith(("xar_promo", "PIL", "mechanics_", "selected_", "two_cue_edit",
                            "produce_actual_assets", "qa_", "final47_")):
            path = getattr(module, "__file__", None)
            if isinstance(path, str) and Path(path).is_file():
                paths.add(Path(path))
    dependencies = [pin(p).wire() for p in sorted(paths, key=str)]
    freeze = budget.json(attempt + "/SOURCE-FREEZE.actual.json",
        {"schema": "xar.e04.final47.executor-source-freeze.v1", "machine_id": MACHINE,
         "observed_at_utc": now(), "state": "SOURCE_ONLY_READY_REAL_R05_AND_MEDIA_ADMISSION_PENDING",
         "source_pins": [pin(SOURCE_ROOT / name).wire() for name in (*CODE_NAMES, "README.md")],
         "dependency_pins": dependencies, "final47_source_freeze": FINAL_FREEZE.wire(),
         "Root_final47_source_review": ROOT_REVIEW.wire(), "font": FONT_PIN.wire(),
         "source_purpose": SOURCE_PURPOSE.wire(),
         "actual_source_card": pin(Path(SOURCE_CARD_PATH)).wire(),
         "focused_original_wait": focused.wire(), "strict_original_wait": strict.wire(),
         "pure_focused_groups": report["groups"], "media_Native_Job_Game_SDK_screen_Git_executed": False,
         "future_R05_acceptance": None, "future_media_card": None,
         "same_new_root_work_CAS_hardlinks": True, "unknown_aliases_rejected": True,
         "source_allocation_before_freeze": budget.snapshot()})
    budget.json(attempt + "/SOURCE-OWNER-CLOSED.actual.json",
        {"schema": "xar.e04.final47.executor-source-owner-closed.v1", "machine_id": MACHINE,
         "observed_at_utc": now(), "source_freeze": freeze.wire(), "source_writes_closed": True,
         "original_check_children_wait0": True, "actual_allocation_before_this_receipt": budget.snapshot(),
         "future_media_execution_inherited": False, "maximum_new_C_allocated_bytes": SOURCE_LIMIT,
         "maximum_new_D_allocated_bytes": 0})
    return freeze


def main() -> None:
    need(len(sys.argv) in (3, 4), "source-check aNN or execute actual_card_path sha256")
    if sys.argv[1] == "source-check":
        need(len(sys.argv) == 3, "Source attempt label")
        result = source_checks(sys.argv[2])
    else:
        need(sys.argv[1] == "execute" and len(sys.argv) == 4, "Only explicit actual-media entry")
        ref = pin(Path(sys.argv[2]))
        need(ref.sha256 == sys.argv[3], "Actual supplied media card SHA")
        result = execute(ref)
    print(json.dumps(result.wire(), ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()

