"""Single source/runtime admission and physical-new-output contract; no execution at import."""
from __future__ import annotations

from dataclasses import dataclass
import datetime as dt
import hashlib
import os
from pathlib import Path
import sys
import time
from typing import Literal

BASE = Path("C:/ck3-e04-resume-20261022-b01")
SOURCE_ROOT = BASE / "final47-executor-source-a01"
FINAL_SOURCE = BASE / "final47-source-a01"
for _name, _sha in (
    ("final47_base.py", "0377deb7b47b49cd66beea1797253e8082feabdd708d6727c860e686a6386731"),
    ("final47_recipe.py", "68bb5fea373b72e19641600d618d427c558c003724a36b9c3e1067330541bd3f"),
    ("final47_products.py", "4511e86f90114f61110c781102750db122559da447d5900348b3a80460859572"),
):
    if hashlib.sha256((FINAL_SOURCE / _name).read_bytes()).hexdigest() != _sha:
        raise ValueError("Actual frozen final47 source changed")
sys.path.insert(0, str(FINAL_SOURCE))
from final47_base import (
    Budget as Budget, CueSpec as CueSpec, EXPECTED_CUES as EXPECTED_CUES,
    FilePin as FilePin, JsonObject as JsonObject, JsonValue as JsonValue, MACHINE as MACHINE,
    MEDIA_ROOT as MEDIA_ROOT, R05Acceptance as R05Acceptance, Resources as Resources,
    RetainedAsset as RetainedAsset, SourceError as SourceError, canonical as canonical,
    decimal64 as decimal64, decode as decode, digest as digest, integer as integer,
    json_domain as json_domain, need as need, now as now, object_row as object_row,
    pin as pin, process_birth as process_birth, rows as rows, sha as sha, string as string,
    validate_encoded_probe as validate_encoded_probe,
)
from final47_recipe import (
    CompleteRecipe as CompleteRecipe, CueRecipe as CueRecipe, concat_plan as concat_plan,
)
from final47_products import (
    CAS_TOTAL_MAX as CAS_TOTAL_MAX, CUE_MAX as CUE_MAX, FULL_MAX as FULL_MAX,
    CueProduct as CueProduct, FullTimeline as FullTimeline, original_wait as original_wait,
)
from produce_actual_assets import allocation
SOURCE_LIMIT = 524288
SOURCE_DEADLINE = dt.datetime(2026, 10, 22, 20, tzinfo=dt.UTC)
SOURCE_CARD_PATH = str(SOURCE_ROOT / "CAPACITY-ADMISSION.actual-a01.json")
SOURCE_CARD_BYTES = 1044
SOURCE_CARD_SHA = "6e9840a77a590a5c6d52e2eac4bd0c6f88ce12858eba34a132c03478396d1ae5"
SOURCE_PURPOSE = FilePin(str(BASE / "root-phase7/ROOT-FINAL47-EXECUTOR-SOURCE-PURPOSE.actual-a01.json"),
    1700, "35c16f2c23f317a94b276db3d13a9a96eac8ea525121d624895b5f58ce97b27c")
FINAL_FREEZE = FilePin(str(FINAL_SOURCE / "a04/SOURCE-FREEZE.actual.json"), 14738,
    "ec15ee5a4afb60d6401ddcdd3de8484b4f4e9cc11328b024f948db80da24ea1f")
ROOT_REVIEW = FilePin(str(BASE / "root-phase7/ROOT-FINAL47-SOURCE-REVIEW.actual-a01.json"), 2062,
    "c9f3e199637683ac646d4dbfa251484c5992b3c7682946bfa1a273fb6461d844")
FONT_PIN = FilePin(str(Path("C:/Windows/Fonts/msyh.ttc")), 19704352,
    "d79c55e68b1131eea0cc1c47be4f572d964f28c682e143db2ad09c1e4cb07a3f")
Operation = Literal["cue_encode", "cue_decode_probe", "movie_concat", "movie_decode_probe", "census"]


def verify_freeze(ref: FilePin, schema: str) -> None:
    r = object_row(decode(ref.verify(32768)))
    need(r.get("schema") == schema and r.get("machine_id") == MACHINE, "Actual same-machine source freeze")
    for key in ("source_pins", "dependency_pins"):
        values = rows(r[key])
        need(bool(values), "Nonempty frozen source/dependency closure")
        for value in values:
            item = FilePin.parse(value)
            item.verify(33554432)


def source_authority() -> Budget:
    ref = FilePin(SOURCE_CARD_PATH, SOURCE_CARD_BYTES, SOURCE_CARD_SHA)
    r = object_row(decode(ref.verify(16384)))
    need(r.get("schema") == "xar.capacity.independent-finite-source-plan-admission.v1"
         and r.get("machine_id") == MACHINE and r.get("admitted") is True
         and r.get("source_plan_only_admitted") is True
         and r.get("deletion_Game_Steam_SDK_media_Git_execution_admitted") is False and r.get("budget_status") == "GREEN"
         and r.get("owner") == "/root/r08_causal_source"
         and Path(string(r["exact_root"])) == SOURCE_ROOT
         and integer(r["maximum_new_C_allocated_bytes"]) == SOURCE_LIMIT
         and integer(r["maximum_new_D_allocated_bytes"]) == 0
         and r["hard_deadline_utc"] == "2026-10-22T20:00:00Z"
         and FilePin.parse(r["Root_independent_purpose"]) == SOURCE_PURPOSE,
         "Independent actual executor-source admission")
    SOURCE_PURPOSE.verify(4096)
    return Budget(SOURCE_ROOT, SOURCE_DEADLINE, SOURCE_LIMIT)


@dataclass(frozen=True)
class NativeItem:
    path: str
    size: int
    allocated: int
    device: str
    inode: str
    links: int


def unique_allocation(items: tuple[NativeItem, ...]) -> tuple[int, int, int]:
    groups: dict[tuple[str, str], list[NativeItem]] = {}
    for item in items:
        need(type(item.size) is type(item.allocated) is type(item.links) is int
             and item.size >= 0 and item.allocated >= 0 and item.links >= 1, "Actual Native item types")
        decimal64(item.device)
        decimal64(item.inode)
        groups.setdefault((item.device, item.inode), []).append(item)
    logical = allocated = aliases = 0
    for same in groups.values():
        first = same[0]
        need(len({p.path for p in same}) == len(same) and all(
            (p.size, p.allocated, p.links) == (first.size, first.allocated, first.links) for p in same)
             and first.links == len(same), "All hardlink aliases must be accounted inside own root")
        logical += first.size * len(same)
        allocated += first.allocated
        aliases += len(same) - 1
    return logical, allocated, aliases


class NewOutputBudget(Budget):
    def snapshot(self) -> JsonObject:
        found: list[NativeItem] = []
        count = 0
        stack = [self.root] if self.root.exists() else []
        started = time.monotonic()
        while stack:
            with os.scandir(stack.pop()) as entries:
                for entry in entries:
                    count += 1
                    need(count <= 2000 and time.monotonic() - started <= 15, "Bounded Native census")
                    info = entry.stat(follow_symlinks=False)
                    need(not info.st_file_attributes & 0x400, "No reparse own output")
                    if entry.is_dir(follow_symlinks=False):
                        stack.append(Path(entry.path))
                    else:
                        size, assigned = allocation(Path(entry.path))
                        found.append(NativeItem(str(Path(entry.path).resolve()), size, assigned,
                            str(info.st_dev), str(info.st_ino), info.st_nlink))
        logical, assigned, aliases = unique_allocation(tuple(found))
        self.peak_observed_allocated = max(self.peak_observed_allocated, assigned)
        return {"logical_bytes": logical, "allocated_bytes": assigned, "entries": count,
            "hardlink_aliases": aliases, "unique_files": len(found) - aliases,
            "payload_bytes_read_for_allocation": 0}


def link_new_output(budget: NewOutputBudget, source: FilePin, maximum: int) -> RetainedAsset:
    actual_path = Path(source.path).resolve()
    need(actual_path.is_relative_to(budget.root.resolve())
         and (actual_path.is_relative_to((budget.root / "work").resolve())
              or actual_path.is_relative_to((budget.root / "final").resolve())),
         "Only this attempt's own encoded output can become CAS")
    source.verify(maximum)
    before = Path(source.path).stat()
    need(before.st_nlink == 1, "No preexisting aliases or old CAS shortcut")
    target = budget.root / "native/derived/sha256" / source.sha256[:2] / (source.sha256 + ".mp4")
    need(not target.exists(), "Create-only own new CAS; no content-hash reuse")
    budget.guard(target, 0)  # Creating an alias writes no payload;8192 reserve covers metadata.
    target.parent.mkdir(parents=True, exist_ok=True)
    os.link(source.path, target)
    left, right = Path(source.path).stat(), target.stat()
    need((left.st_dev, left.st_ino) == (right.st_dev, right.st_ino)
         and left.st_nlink == right.st_nlink == 2, "Exact two own aliases to one new file")
    result = RetainedAsset.actual(pin(target))
    need((result.media.bytes, result.media.sha256) == (source.bytes, source.sha256), "Actual new work/CAS equality")
    budget.snapshot()  # All aliases reverified after the link.
    return result


@dataclass(frozen=True)
class RuntimeAdmission:
    budget: NewOutputBudget
    financial_card: FilePin
    Root_purpose: FilePin
    executor_freeze: FilePin
    game_closed: FilePin
    r05: R05Acceptance

    @staticmethod
    def parse(ref: FilePin) -> RuntimeAdmission:
        r = object_row(decode(ref.verify(65536)))
        need(r.get("schema") == "xar.capacity.final47-media-execution-admission.v1"
             and r.get("machine_id") == MACHINE and r.get("owner") == "/root/r08_causal_source"
             and r.get("admitted") is True and r.get("budget_status") == "GREEN"
             and r.get("final47_media_execution_admitted") is True
             and r.get("Game_closed_actual") is True
             and r.get("allow_new_output_work_CAS_hardlinks") is True,
             "Separate actual final47 media execution admission")
        need(Path(string(r["exact_root"])) == MEDIA_ROOT
             and integer(r["maximum_new_D_allocated_bytes"]) == 0
             and integer(r["maximum_new_C_allocated_bytes"]) > 0
             and FilePin.parse(r["final47_source_freeze"]) == FINAL_FREEZE
             and FilePin.parse(r["font"]) == FONT_PIN, "Exact media root/frozen recipe/font")
        deadline = dt.datetime.fromisoformat(string(r["hard_deadline_utc"]))
        need(deadline.tzinfo is not None and deadline.utcoffset() == dt.timedelta(0)
             and dt.datetime.now(dt.UTC) < deadline, "Fresh finite UTC media deadline")
        verify_freeze(FINAL_FREEZE, "xar.e04.final47.source-freeze.v1")
        review = object_row(decode(ROOT_REVIEW.verify(4096)))
        need(review.get("source_review_only") is True and FilePin.parse(review["source_freeze"]) == FINAL_FREEZE,
             "Actual Root source review")
        FONT_PIN.verify(33554432)
        executor = FilePin.parse(r["executor_source_freeze"])
        need(Path(executor.path).resolve().is_relative_to(SOURCE_ROOT.resolve()), "Actual new executor freeze root")
        verify_freeze(executor, "xar.e04.final47.executor-source-freeze.v1")
        purpose = FilePin.parse(r["Root_independent_purpose"])
        p = object_row(decode(purpose.verify(32768)))
        need(p.get("schema") == "xar.root.final47-media-purpose.v1"
             and p.get("machine_id") == MACHINE and p.get("Game_closed_actual") is True
             and p.get("allow_new_output_work_CAS_hardlinks") is True, "Actual Root media purpose")
        for key in ("exact_root", "maximum_new_C_allocated_bytes", "maximum_new_D_allocated_bytes",
                    "hard_deadline_utc", "Game_closed_proof", "final47_source_freeze",
                    "executor_source_freeze", "R05_shot_acceptance", "font"):
            need(canonical(p[key]) == canonical(r[key]), "Root purpose/card field mismatch: " + key)
        closed = FilePin.parse(r["Game_closed_proof"])
        need(object_row(decode(closed.verify(65536))).get("machine_id") == MACHINE, "Actual same-machine Game closure source")
        r05 = R05Acceptance.parse(FilePin.parse(r["R05_shot_acceptance"]))
        budget = NewOutputBudget(MEDIA_ROOT, deadline, integer(r["maximum_new_C_allocated_bytes"]))
        return RuntimeAdmission(budget, ref, purpose, executor, closed, r05)


MOVIE_FIELDS = frozenset(("schema", "machine_id", "observed_at_utc", "state", "frame_rate",
    "cue_count", "total_frames", "financial_card", "final47_source_freeze", "executor_source_freeze",
    "font", "R05_actual_acceptance", "timeline", "work_movie", "native_CAS_movie",
    "actual_concat_original_wait", "actual_concat_progress", "actual_full_decode_probe",
    "all47_derived_videos_new", "retained44_input_signature", "whole_movie_PTS_audio_visual_QA",
    "human1x", "signoff", "TTS_calls", "raster_calls"))


@dataclass(frozen=True)
class ActualMovie:
    observed_at_utc: str
    total_frames: int
    timeline: FilePin
    work: FilePin
    native: RetainedAsset
    concat_wait: FilePin
    concat_progress: FilePin
    probe: FilePin

    def wire(self, admission: RuntimeAdmission, resources: Resources) -> JsonObject:
        return {"schema": "xar.e04.final47.actual-movie.v1", "machine_id": MACHINE,
            "observed_at_utc": self.observed_at_utc, "state": "ACTUAL_FULL_MOVIE_DECODE_COUNT_VERIFIED",
            "frame_rate": 30, "cue_count": 47, "total_frames": self.total_frames,
            "financial_card": admission.financial_card.wire(), "final47_source_freeze": FINAL_FREEZE.wire(),
            "executor_source_freeze": admission.executor_freeze.wire(), "font": FONT_PIN.wire(),
            "R05_actual_acceptance": admission.r05.source.wire(), "timeline": self.timeline.wire(),
            "work_movie": self.work.wire(), "native_CAS_movie": self.native.wire(),
            "actual_concat_original_wait": self.concat_wait.wire(), "actual_concat_progress": self.concat_progress.wire(),
            "actual_full_decode_probe": self.probe.wire(), "all47_derived_videos_new": True,
            "retained44_input_signature": resources.unchanged44(),
            "whole_movie_PTS_audio_visual_QA": "PENDING_SEPARATE_ACTUAL_REVIEW",
            "human1x": False, "signoff": False, "TTS_calls": 0, "raster_calls": 0}

    @staticmethod
    def parse(value: JsonValue, admission: RuntimeAdmission, resources: Resources) -> ActualMovie:
        r = object_row(value, set(MOVIE_FIELDS))
        result = ActualMovie(string(r["observed_at_utc"]), integer(r["total_frames"]),
            FilePin.parse(r["timeline"]), FilePin.parse(r["work_movie"]),
            RetainedAsset.parse(r["native_CAS_movie"]), FilePin.parse(r["actual_concat_original_wait"]),
            FilePin.parse(r["actual_concat_progress"]), FilePin.parse(r["actual_full_decode_probe"]))
        need(integer(r["frame_rate"]) == 30 and integer(r["cue_count"]) == 47
             and integer(r["TTS_calls"]) == integer(r["raster_calls"]) == 0
             and r["human1x"] is False and r["signoff"] is False
             and r["all47_derived_videos_new"] is True, "Actual movie types and honest QA boundary")
        need(canonical(result.wire(admission, resources)) == canonical(r), "Single actual movie metadata contract")
        return result

    def verify(self, admission: RuntimeAdmission, resources: Resources, timeline: FullTimeline) -> None:
        import re
        expected_frames = sum(p.spec.slot.frames for p in timeline.products)
        need(self.total_frames == expected_frames and self.total_frames > 0, "Actual total frame clock")
        actual = FullTimeline.consume(decode(self.timeline.verify(524288)),
            tuple(p.spec for p in timeline.products), resources)
        need(canonical(actual.wire()) == canonical(timeline.wire()), "Actual movie uses the actual complete47 timeline")
        plan = concat_plan(resources, actual, root=MEDIA_ROOT)
        need(Path(self.work.path) == plan.final_output and
             Path(self.native.media.path).resolve().is_relative_to((MEDIA_ROOT / "native").resolve())
             and Path(self.native.media.path).stem.lower() == self.native.media.sha256,
             "New whole movie work/CAS paths")
        self.native.verify_identity()
        payload = self.native.media.verify(FULL_MAX)
        need(payload[4:8] == b"ftyp" and (self.work.bytes, self.work.sha256) ==
             (self.native.media.bytes, self.native.media.sha256), "Actual whole movie MP4/work/CAS")
        self.work.verify(FULL_MAX)
        left, right = Path(self.work.path).stat(), Path(self.native.media.path).stat()
        need((left.st_dev, left.st_ino) == (right.st_dev, right.st_ino)
             and left.st_nlink == right.st_nlink == 2, "Actual two-name whole movie alias")
        waited = original_wait(self.concat_wait, plan.commands[0].spec.argv, "movie_concat", "full47")
        need(waited.get("owner_error") is None and waited.get("protocol_prefix_only") is False
             and FilePin.parse(waited["stdout"]) == self.concat_progress, "Actual clean concat original stdout")
        need(re.search(r"^progress=end\s*$", self.concat_progress.verify(262144).decode("utf-8"),
                       re.MULTILINE) is not None, "Actual concat finished progress")
        probe = object_row(decode(self.probe.verify(65536)))
        need(probe.get("schema") == "xar.e04.final47.encode-probe.v1" and probe.get("machine_id") == MACHINE
             and probe.get("actual_decode_count_frames") is True and integer(probe["original_wait"]) == 0
             and integer(probe["expected_frames"]) == expected_frames
             and FilePin.parse(probe["media"]) == self.work, "Actual full decode/count source")
        argv = (resources.tools.ffprobe.media.path, "-v", "error", "-count_frames",
                "-show_streams", "-show_format", "-of", "json", self.work.path)
        checked = original_wait(FilePin.parse(probe["original_wait_pin"]), argv, "movie_decode_probe", "full47")
        need(checked.get("owner_error") is None and checked.get("protocol_prefix_only") is False
             and canonical(decode(FilePin.parse(checked["stdout"]).verify(65536))) == canonical(probe["observed"]),
             "Actual full probe is original untruncated stdout")
        validate_encoded_probe(object_row(probe["observed"]), expected_frames)

