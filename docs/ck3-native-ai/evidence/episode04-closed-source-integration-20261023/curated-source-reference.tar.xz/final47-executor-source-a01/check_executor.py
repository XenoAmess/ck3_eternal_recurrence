"""Pure executor Protocol/contract tests. No Popen, Job, media tool or output media is created."""
from __future__ import annotations

from dataclasses import replace
from decimal import Decimal
import json
from pathlib import Path
import subprocess
from typing import Callable
from executor_contract import (
    ActualMovie, Budget, CUE_MAX, FINAL_FREEZE, FONT_PIN, FULL_MAX, FullTimeline,
    JsonObject, JsonValue, MACHINE, MEDIA_ROOT, NativeItem, NewOutputBudget, ROOT_REVIEW,
    R05Acceptance, Resources, RetainedAsset, RuntimeAdmission, SOURCE_DEADLINE,
    canonical, decode, integer, json_domain, need, object_row, pin, sha, string,
    unique_allocation, validate_encoded_probe, CompleteRecipe, CueRecipe,
)
from final47_base import R05Record
from produce_final47 import Request, close_owned, custody_good, start_ready

CHECKS: list[str] = []


def rejects(action: Callable[[], object]) -> None:
    try:
        action()
    except (ValueError, TypeError, KeyError, OSError):
        return
    raise AssertionError("Expected strict refusal")


class FakeProcess:
    def __init__(self, code: int = 0, *, timeout_once: bool = False) -> None:
        self.code = code
        self.timeout_once = timeout_once
        self.killed = False
        self.waits = 0

    def wait(self, timeout: float | None = None) -> int:
        self.waits += 1
        if self.timeout_once:
            self.timeout_once = False
            raise subprocess.TimeoutExpired("pure_fixture", 0.0 if timeout is None else timeout)
        return self.code

    def kill(self) -> None:
        self.killed = True
        self.code = 1


class FakeJob:
    def __init__(self, active: int = 0, *, unknown: bool = False, close_fails: bool = False) -> None:
        self.active = active
        self.unknown = unknown
        self.close_fails = close_fails
        self.stops = 0
        self.closed = False

    def count(self) -> int:
        if self.unknown:
            raise OSError("pure_fixture unknown Job count")
        return self.active

    def terminate(self) -> None:
        self.stops += 1
        self.active = 0

    def close(self) -> None:
        if self.close_fails:
            raise OSError("pure_fixture close failure")
        self.closed = True


def run_checks() -> JsonObject:
    value: JsonValue
    normal, job = FakeProcess(), FakeJob()
    result = close_owned(normal, job, failed=False)
    need(custody_good(result) and normal.waits == 1 and job.closed, "Original normal lifecycle")
    failed, busy = FakeProcess(), FakeJob(1)
    result = close_owned(failed, busy, failed=True)
    need(custody_good(result) and busy.stops == 1 and failed.waits == 1 and busy.closed,
         "Own failure terminates Job then waits original")
    timed, busy = FakeProcess(timeout_once=True), FakeJob(1)
    result = close_owned(timed, busy, failed=False)
    need(timed.killed and timed.waits == 2 and result["original_wait"] == 1
         and result["job_active_processes"] == 0 and not custody_good(result),
         "Timeout original kill/wait is failure, never success")
    CHECKS.append("production_close_owned_Protocol_normal_failure_timeout_original_wait")

    for unknown, close_fails in ((True, False), (False, True)):
        original, uncertain = FakeProcess(), FakeJob(unknown=unknown, close_fails=close_fails)
        result = close_owned(original, uncertain, failed=False)
        need(not custody_good(result) and result["job_closed"] is False, "Unknown closure is not zero")
    for key, value in (("original_wait", False), ("job_active_processes", False),
                       ("original_wait", None), ("job_closed", 1)):
        bad: JsonObject = {"original_wait": 0, "job_active_processes": 0, "job_closed": True,
                           "custody_errors": []}
        bad[key] = value
        need(not custody_good(bad), "Exact custody types")
    CHECKS.append("unknown_active_close_failure_and_bool_zero_never_pass")

    start_ready(suspended=True, assigned=True, member=True, active=1, flags=8192)
    for field, value in (("suspended", False), ("assigned", False), ("member", False),
                         ("active", 0), ("flags", 0)):
        kwargs: JsonObject = {"suspended": True, "assigned": True, "member": True, "active": 1, "flags": 8192}
        kwargs[field] = value
        # Runtime JSON boundary to the typed production helper, without invoking any Native call.
        try:
            start_ready(suspended=kwargs["suspended"] is True, assigned=kwargs["assigned"] is True,
                member=kwargs["member"] is True, active=integer(kwargs["active"]), flags=integer(kwargs["flags"]))
        except ValueError:
            continue
        raise AssertionError("Assignment failure must prevent resume")
    rejects(lambda: start_ready(suspended=True, assigned=True, member=True, active=True, flags=8192))
    CHECKS.append("production_start_gate_requires_suspended_assigned_member_kill_on_close_before_resume")

    for operation, timeout, cap in (("cue_encode", 300, CUE_MAX), ("cue_decode_probe", 120, 0),
                                    ("movie_concat", 180, FULL_MAX), ("movie_decode_probe", 180, 0)):
        if operation == "cue_encode":
            request = Request("cue_encode", "fixture", timeout, cap)
        elif operation == "cue_decode_probe":
            request = Request("cue_decode_probe", "fixture", timeout, cap)
        elif operation == "movie_concat":
            request = Request("movie_concat", "fixture", timeout, cap)
        else:
            request = Request("movie_decode_probe", "fixture", timeout, cap)
        request.validate()
        rejects(lambda: replace(request, timeout=request.timeout + 1).validate())
        rejects(lambda: replace(request, output_cap=request.output_cap + 1).validate())
    rejects(lambda: Request("cue_encode", "fixture", True, CUE_MAX).validate())
    CHECKS.append("four_typed_finite_operations_no_selected871_946_guard_or_retry")

    first = NativeItem("own/work/a.mp4", 10000, 12288, "13886423844274364792", "9007199254740993", 2)
    alias = replace(first, path="own/native/a.mp4")
    need(unique_allocation((first, alias)) == (20000, 12288, 1), "One Native file counts once")
    other = NativeItem("own/work/b.mp4", 500, 4096, first.device, "9007199254740994", 1)
    need(unique_allocation((first, alias, other)) == (20500, 16384, 1), "Independent output adds its actual allocation")
    rejects(lambda: unique_allocation((first,)))
    rejects(lambda: unique_allocation((first, replace(alias, links=3))))
    rejects(lambda: unique_allocation((first, replace(alias, allocated=8192))))
    rejects(lambda: unique_allocation((first, first)))
    rejects(lambda: unique_allocation((replace(other, inode="09007199254740994"),)))
    rejects(lambda: unique_allocation((replace(other, size=True),)))
    CHECKS.append("Native_unique_FileID_all_aliases_known_no_external_alias_or_precision_loss")

    resources = Resources.load()
    n05 = resources.spec("N05-01")
    r08 = resources.spec("N06-05")
    need(n05.slot.frames == 1597 and r08.slot.frames == 946, "Actual frozen input clocks")
    recipes = [CueRecipe.prepare(resources, resources.spec(k))
               for k in ("N01-04", "N05-01", "N06-08", "N06-05")]
    need([r.spec.slot.frames for r in recipes] == [717, 1597, 871, 946], "Generic actual known plans")
    rejects(lambda: CompleteRecipe.prepare(resources, None))
    rejects(lambda: RuntimeAdmission.parse(FINAL_FREEZE))
    CHECKS.append("pinned_generic_actual_recipe_seam_missing_R05_or_actual_media_card_rejected")

    frames = n05.slot.frames
    observed: JsonObject = {"streams": [
        {"codec_type": "video", "codec_name": "h264", "pix_fmt": "yuv420p", "width": 1920,
         "height": 1080, "r_frame_rate": "30/1", "nb_read_frames": str(frames),
         "time_base": "1/15360", "duration_ts": frames * 512},
        {"codec_type": "audio", "codec_name": "aac", "sample_rate": "48000", "channels": 2}],
        "format": {"duration": str(Decimal(frames) / 30)}}
    validate_encoded_probe(observed, frames)
    rejects(lambda: validate_encoded_probe(observed, 946))
    rejects(lambda: validate_encoded_probe(observed, True))
    for key, value in (("width", 1280), ("duration_ts", frames * 512 + 1), ("nb_read_frames", str(frames - 1))):
        bad = object_row(json_domain(json.loads(canonical(observed))))
        streams = bad["streams"]
        need(isinstance(streams, list), "Fixture JSON list")
        if not isinstance(streams, list):
            raise AssertionError("Narrow fixture list")
        object_row(streams[0])[key] = value
        rejects(lambda: validate_encoded_probe(bad, frames))
    CHECKS.append("generic_actual_decode_probe_frames_geometry_timebase_not_old_two_cue_validator")

    # Existing PNG Pins deliberately form nonqualifying RAM metadata fixtures, never future media claims.
    raw = RetainedAsset.actual(resources.R08_plan.raw)
    record = R05Record("2026-10-22T19:00:00Z", ROOT_REVIEW, MACHINE + "--vanilla--R9999",
                       "R9999", raw, 180, 1051, 1332, ("pure_RAM_fixture",))
    fake_admission = RuntimeAdmission(NewOutputBudget(MEDIA_ROOT, SOURCE_DEADLINE, 1),
        ROOT_REVIEW, ROOT_REVIEW, FINAL_FREEZE, ROOT_REVIEW, R05Acceptance(ROOT_REVIEW, record))
    p = resources.R08_png
    movie = ActualMovie("2026-10-22T19:00:00Z", frames, ROOT_REVIEW, p,
                        RetainedAsset.actual(p), ROOT_REVIEW, p, ROOT_REVIEW)
    value = movie.wire(fake_admission, resources)
    parsed = ActualMovie.parse(json_domain(json.loads(canonical(value))), fake_admission, resources)
    need(parsed == movie, "Single actual metadata producer/consumer JSON domain")
    for key in value:
        bad = dict(value)
        bad.pop(key)
        rejects(lambda: ActualMovie.parse(bad, fake_admission, resources))
    for key, value_bad in (("cue_count", True), ("total_frames", 1.0), ("human1x", True),
                           ("signoff", True), ("TTS_calls", 1), ("all47_derived_videos_new", False)):
        bad = dict(value)
        bad[key] = value_bad
        rejects(lambda: ActualMovie.parse(bad, fake_admission, resources))
    empty = FullTimeline((), sha(resources.project), string(resources.unchanged44()["input_signature_sha256"]))
    rejects(lambda: parsed.verify(fake_admission, resources, empty))
    rejects(lambda: CompleteRecipe.prepare(resources, fake_admission.r05))
    CHECKS.append("ActualMovie_single_contract_roundtrip_bad_missing_metadata_and_RAM_false_qualification_rejected")

    return {"schema": "xar.e04.final47.executor-pure-focused.v1", "machine_id": MACHINE,
        "status": "PASS", "groups": len(CHECKS), "checks": list(CHECKS),
        "real_Popen_Job_media_Game_SDK_created": False, "R05_actual_path": "PENDING_REAL_ACCEPTANCE",
        "RAM_metadata_fixtures_nonqualifying": True}


if __name__ == "__main__":
    print(json.dumps(run_checks(), ensure_ascii=False, sort_keys=True))

