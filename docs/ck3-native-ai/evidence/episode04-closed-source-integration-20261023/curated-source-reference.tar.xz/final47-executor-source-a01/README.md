# Actual final47 executor source

machine_id: desktop-3fevhd2-1c74096080

Independent source-only root, C512KiB/D0/writehard2026-10-22T20:00Z.
The source CLI starts only two pure Python check children. It never constructs
Native Jobs, starts media tools, or calls Game/Steam/SDK/screen/Git/TTS/raster.
The existing final47-source and all old source/media roots remain read-only.

Run produce_final47.py source-check aNN with the retained workspace Python -B
-X utf8. Every write uses the actual Native allocation guard plus rounded payload
and8192 reserve. Create-only attempts retain exact original Popen identities,
stdout/stderr and original waits. The source freeze grants no media execution.

The separately admitted future entry is produce_final47.py execute CARD SHA256.
It requires the following single actual runtime contract; no future Pin is
pre-filled in this source:

schema xar.capacity.final47-media-execution-admission.v1;
machine_id;owner /root/r08_causal_source;admitted true;budget_status GREEN;
exact_root final47-media-a01;maximum_new_C_allocated_bytes strictpositiveint;
maximum_new_D_allocated_bytes strict0;hard_deadline_utc fresh UTC;
final47_media_execution_admitted true;Game_closed_actual true;
Game_closed_proof FilePin;Root_independent_purpose FilePin;
final47_source_freeze exact14738/ec15ee5a4afb60d6401ddcdd3de8484b4f4e9cc11328b024f948db80da24ea1f;
executor_source_freeze actual this-source freeze FilePin;R05_shot_acceptance
actual Root-qualified FilePin;font exact msyh.ttc19704352/d79c55e68b1131eea0cc1c47be4f572d964f28c682e143db2ad09c1e4cb07a3f;
allow_new_output_work_CAS_hardlinks true.

Root purpose schema is xar.root.final47-media-purpose.v1 with same machine/root/
limits/deadline/input Pins and true Game_closed_actual/hardlink allowance.
The source/card are re-read and pinned, all frozen dependencies and actual font
are verified, the original Game closure source is linked, and the real R05
acceptance is independently consumed. Missing source/card/R05/closure fails.
The original native Window or a generic Game ACK cannot supply R05 acceptance.
The fresh actual entry additionally checks ck3.exe/ffmpeg.exe occupancy with
retained finite tasklist processes. No old selected-only qualification is used.

CompleteRecipe.prepare produces all47 only after real R05 acceptance. Each cue
writes the exact common safe ASS and once marker, executes the frozen public
render plan through the new Owner, retains its original suspended Popen assigned
to a verified kill-on-close Job before resume, waits the original object and
proves Job0/closed. Then actual count_frames ffprobe stdout is validated against
that cue's real arbitrary frame clock and the work file becomes a new CAS alias.
CueProduct.parse/verify consume those actual receipts; all47 products produce
and reconsume FullTimeline, then exactly one concat/remux occurs. The complete
movie receives its own real count_frames/decode probe and ActualMovie.parse/
verify before FINAL47-ACTUAL-METADATA is written. Command plans never qualify as
actual products. PTS/audio/visual whole-movie QA, human1x and signoff stay pending.

Operations are Literal branches: cue_encode300s/cue_decode_probe120s/
movie_concat180s/movie_decode_probe180s/census15s. No automatic retry. All failures
preserve actual partials, original stdout/stderr/custody and the failed marker.
Oversized protocol is marked prefix-only and fails; it never qualifies as clean
complete stdout. Only owned process/Job handles are terminated. Finally records
original waits and exact custody proof, never converting unknown into0.

Same-new-root work/CAS hardlinks avoid duplicate output payloads. The new encoded
work must have one link; CAS creation uses os.link without copy fallback and
proves exactly two names share the same actual FileID. No old CAS shortcut or
external alias is allowed. NewOutputBudget snapshots prove every alias is inside
the own root and count each Native allocated FileID once; all64bit identities
use decimal strings. Link creation reserves metadata; external encoding reserves
the full output cap plus protocol before launch. No outputs are deleted here.

Cue cap18MiB with frozen17MiB FFmpeg -fs; aggregate CAS144MiB; full movie144MiB.
Actual media budget is whatever the separate actual Root/CAP card admits and
must cover unique CAS/work files, final movie, all protocol and TEMP concurrently.
None of these safety maxima is a current media allocation.

Pure focused tests exercise the actual close_owned/start_ready/Request/Native
accounting/metadata producer-consumer functions with Protocol fakes and real
pinned recipe inputs. The RAM metadata fixtures deliberately use non-video real
Pins and cannot qualify as a movie. Positive actual R05/media paths remain pending.

