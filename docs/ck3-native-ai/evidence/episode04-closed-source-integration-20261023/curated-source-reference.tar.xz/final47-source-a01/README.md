# Final47 successor source

machine_id: desktop-3fevhd2-1c74096080

This is source-only, C2MiB/D0 through2026-10-22T20:00Z in this exact directory.
It grants no FFmpeg/ffprobe/TTS/raster/Game/SDK/screen/Git/media-copy execution.
Every write uses actual Win32 Native allocation + next cluster payload +8192.

## CLI and actual source checks

Use retained workspace Python -B -X utf8 produce_source.py source-check aNN.
Create-only attempts retain original Popen identities, original waits and bounded
stdout/stderr of pure focused and five-file strict checks. A successful freeze
states SOURCE_READY_WAITING_ACTUAL_R05; it is not an actual-media or R05 result.
EARLY-SOURCE-CHECK-OWNER-GAP.actual-a01.json preserves the first development
PID/Popen helper misuse and unknown original child wait. Later passes do not
change that history. The current owner always reaps its original child.

## Active inputs and exact clocks

The pinned final N05 project and final47 timeline are read as external files,
without Git. Old timeline video descriptors are historical metadata only:
old47 MP4 files and old whole movie are not read or required to exist.
The future render reads original raw/card/voice and regenerated ASS source.
No old video reference is adopted.

Forty-four original cue fields, narration, visual inputs and frame counts stay
exact while all47 derived videos are rebuilt. N05-01 keeps actual52.224000s voice,
1597frames and final K17 SHA7cb50df4003cecf7ca020972bff47e8b5437736ca4169e936b4653c0a510ab77.
R08 N06-08 keeps Root-accepted raw[180,1051),871frames and full client HUD.
N06-05 uses actual F13 and explicit946frames. Real voices remain22.704000s and
25.896000s; no duration is fabricated. R08 scope remains maintenance offset
against a positive net receipt, with no independent gross debit/payer/period claim.

All47 Chinese captions use pinned canonical2c151 mechanics_composer SHA
56358fd6ac3dee1f89f52382e3442444bd00dbac099743c9b50e7ea904e3e494:
complete sentence/clause pages, at most two lines,32characters/1370pixels per line
at actual Microsoft YaHei36, no leading closing punctuation or split numbers.
The two R08 texts use this same algorithm while preserving their approved five
English sentences and measured paired subtitle times exactly. The brown/gold
palette,1536x864 HUD area and bilingual lower band remain.

## Single R05 acceptance contract

R05AcceptanceDocument/R05Record/R05Acceptance in final47_base.py are the shared
producer and consumer. Generated R05-ACCEPTANCE-CONTRACT.source.json is only a
description. Actual schema is xar.e04.final47.r05-shot-acceptance.v1 with exact:

- machine_id; observed_at_utc(UTC ISO8601); reviewer literal /root
- Root_accepted true; business_qualified true
- business_result FilePin(path:string,bytes:strict int,sha256:lowercase hex64)
- run_id full machine--mode--Rdigits; case_id R[0-9]{4,6}, exact run suffix
- raw RetainedAsset(path,bytes,retained_sha256,identity)
- identity.mtime_ns/st_dev/st_ino canonical unsigned64 decimal strings
- start_frame/end_frame/actual_raw_frames strict ints,0<=start<end<=total; fps strict30
- client_HUD_complete true; looping/interpolation/freeze_tail false
- Root_actual_review_tool_chunks nonempty list of nonempty strings

Missing/extra fields and legacy shot_review aliases are rejected. The real
business_result file must independently contain exact machine_id/run_id and
business_qualified is True. Null/missing/numeric1 is rejected. Root only writes
its actual causal result after positive strict-stock<10 physical troop deduction.
The native Window is not relabelled as that result; no duplicate shot_review
Pin is required. Actual raw identity/hash and accepted frame bounds are checked.

CompleteRecipe.prepare reparses the actual acceptance FilePin. A manually
assembled dataclass cannot bypass it. Missing actual acceptance blocks N03-02
and complete47 planning. Current source declaration has46 known plans and null
R05 acceptance. Future accepted N03-02 uses original26.544000s voice and F04,
with canonical actual raw/card clock and no frozen/looped live tail.

## Future actual media producer/consumer interface

This package exposes pure CueRecipe.prepare, CompleteRecipe.prepare, CueProduct,
FullTimeline and concat_plan. It contains no media process launcher. A separately
admitted actual-media adapter must materialize these exact plans and produce real
receipts into final47-media-a01; no future Pin/process or capacity card is invented.

Finite one-attempt contract: sequential encoders300s, cue decode probes120s,
concat180s, full probe180s. Timeout closes actual Job and waits original Popen.
All actual output and TEMP stay in the separately admitted media root.
Encoder settings:1920x1080/30,H264high4.0,yuv420p,AAC48k stereo,veryfastCRF21,
one encoder/filter thread,4Mmaxrate/8Mbuf, explicit frames and17MiB -fs.
Cue envelope18MiB; aggregate CAS144MiB. These are protocol maxima, not capacity
grants or peak quotes. Future capacity must include work/CAS/concat/TEMP/protocol.

CueProduct.parse validates JSON; verify(resources) qualifies actual files:
new exact work/CAS destinations and identities; exact safe ASS; freshly generated
original encoder argv; original stdout frame count/progress=end; original process
identity, wait0 and Job0/closed; original decode probe argv/stdout/frames/duration;
actual work/CAS byte equality. Equal MP4 SHA may result from true deterministic
re-encoding, so SHA change is neither required nor accepted as proof. Historical
video identity or old destination references cannot be directly adopted.

Required actual original-wait schema: xar.e04.final47.original-wait.v1;
machine_id,operation(cue_encode/cue_decode_probe),cue_id,argv:list[str],
pid:positive strict int,process_create_time_100ns:canonical decimal64,
actual_original_Popen:true,actual_original_wait:true,stdout:FilePin,
custody:{original_wait:strict0,job_active_processes:strict0,job_closed:true}.
Cue probe schema xar.e04.final47.encode-probe.v1 requires machine_id,
actual_decode_count_frames:true,original_wait:strict0,expected_frames,media:FilePin,
original_wait_pin:FilePin,observed:exact original ffprobe JSON stdout.
Future actual producers must retain real values; source fixtures cannot qualify.

FullTimeline.actual consumes47 ordered physically verified new products.
FullTimeline.consume checks JSON and actual files; parse alone is structural.
New schema xar.e04.final47.full-timeline.v1 separates44 unchanged source inputs
from47 updated videos, with old_video_refs_adopted empty. Complete movie remains
unencoded at that stage. concat_plan requires verified47 actual products and
stream-copies their new CAS paths once with explicit frame-grid durations.
The final whole movie still needs independent count_frames/PTS/audio/visual QA
and delivery admission; source checks never substitute for that.

