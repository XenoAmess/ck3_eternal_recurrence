"""Actual47 new video products and a new final timeline; no old-video preservation alias."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
from pathlib import Path
import re
from final47_base import (
    CueSpec, EXPECTED_CUES, FilePin, JsonObject, JsonValue, MACHINE, MEDIA_ROOT, MECHANISM_IDS,
    R05Acceptance, Resources, RetainedAsset, SAFE_SOURCE, SourceError, canonical, cue_id, decode, decimal64, digest,
    integer, modern_pin, need, object_row, rows, sha, string, validate_encoded_probe,
)

CUE_MAX = 18 * 1048576
CAS_TOTAL_MAX = 144 * 1048576
FULL_MAX = 144 * 1048576
PRODUCT_FIELDS = frozenset(("schema", "machine_id", "state", "cue_id", "order", "origin",
    "frames", "raw_frames", "card_frames", "voice_seconds", "source_fields_sha256",
    "input_binding_sha256", "Chinese_policy_source", "voice", "subtitle", "work",
    "native", "encoder_progress", "encoder_wait", "probe"))


def original_wait(ref: FilePin, argv: tuple[str, ...], operation: str,
                  key: str) -> JsonObject:
    r = object_row(decode(ref.verify(65536)))
    need(r.get("schema") == "xar.e04.final47.original-wait.v1"
         and r.get("machine_id") == MACHINE and r.get("actual_original_Popen") is True
         and r.get("actual_original_wait") is True and r.get("operation") == operation
         and r.get("cue_id") == key and tuple(string(v) for v in rows(r["argv"])) == argv,
         "Actual same-machine original retained process")
    need(integer(r["pid"]) > 0 and int(decimal64(r["process_create_time_100ns"])) > 0,
         "Original process identity uses canonical64 decimal time")
    custody = object_row(r["custody"])
    need(integer(custody["original_wait"]) == 0 and integer(custody["job_active_processes"]) == 0
         and custody.get("job_closed") is True, "Original wait0 and Job0/closed")
    return r


def validate_new_destinations(spec: CueSpec, work: FilePin, native: RetainedAsset) -> None:
    need(Path(work.path).resolve() == (MEDIA_ROOT / "work" / (spec.cue.cue_id + ".mp4")).resolve()
         and Path(native.media.path).resolve().is_relative_to((MEDIA_ROOT / "native").resolve())
         and Path(native.media.path).stem.lower() == native.media.sha256,
         "Actual new work and CAS destination paths")
    need((native.device, native.inode) != (spec.old_video.device, spec.old_video.inode),
         "Historical video file identity cannot be adopted as a new product")


@dataclass(frozen=True)
class CueProduct:
    spec: CueSpec
    subtitle: FilePin
    work: FilePin
    native: RetainedAsset
    encoder_progress: FilePin
    encoder_wait: FilePin
    probe: FilePin

    @staticmethod
    def parse(value: JsonValue, spec: CueSpec) -> CueProduct:
        r = object_row(value, set(PRODUCT_FIELDS))
        need(r["schema"] == "xar.e04.final47.cue-product.v1" and r["machine_id"] == MACHINE
             and r["state"] == "ACTUAL_NEW_DERIVED_VIDEO" and cue_id(r["cue_id"]) == spec.cue.cue_id
             and r["origin"] == spec.origin and integer(r["order"]) == spec.order, "Actual final47 cue identity")
        need((integer(r["frames"]), integer(r["raw_frames"]), integer(r["card_frames"])) ==
             (spec.slot.frames, spec.slot.raw_frames, spec.slot.card_frames)
             and r["voice_seconds"] == str(spec.voice.seconds), "Actual fixed source clock and real voice seconds")
        need(digest(r["source_fields_sha256"]) == sha(spec.fields)
             and digest(r["input_binding_sha256"]) == sha(spec.binding())
             and FilePin.parse(r["Chinese_policy_source"]) == SAFE_SOURCE
             and FilePin.parse(r["voice"]) == modern_pin(spec.voice.native), "Actual source/voice/policy binding")
        result = CueProduct(spec, FilePin.parse(r["subtitle"]), FilePin.parse(r["work"]),
            RetainedAsset.parse(r["native"]), FilePin.parse(r["encoder_progress"]),
            FilePin.parse(r["encoder_wait"]), FilePin.parse(r["probe"]))
        need((result.work.bytes, result.work.sha256) == (result.native.media.bytes, result.native.media.sha256),
             "Actual work and CAS equal bytes")
        # Equal hashes can result from real deterministic re-encoding. Actual process/source
        # provenance and new file identities, checked by verify(), establish new production.
        return result

    def wire(self) -> JsonObject:
        s = self.spec
        return {"schema": "xar.e04.final47.cue-product.v1", "machine_id": MACHINE,
            "state": "ACTUAL_NEW_DERIVED_VIDEO", "cue_id": s.cue.cue_id, "order": s.order,
            "origin": s.origin, "frames": s.slot.frames, "raw_frames": s.slot.raw_frames,
            "card_frames": s.slot.card_frames, "voice_seconds": str(s.voice.seconds),
            "source_fields_sha256": sha(s.fields), "input_binding_sha256": sha(s.binding()),
            "Chinese_policy_source": SAFE_SOURCE.wire(), "voice": modern_pin(s.voice.native).wire(),
            "subtitle": self.subtitle.wire(), "work": self.work.wire(), "native": self.native.wire(),
            "encoder_progress": self.encoder_progress.wire(), "encoder_wait": self.encoder_wait.wire(),
            "probe": self.probe.wire()}

    def verify(self, resources: Resources) -> None:
        from final47_recipe import CueRecipe
        r05 = None if self.spec.actual_R05_acceptance is None else R05Acceptance.parse(self.spec.actual_R05_acceptance)
        actual_spec = resources.spec(self.spec.cue.cue_id, r05)
        need(canonical(actual_spec.binding()) == canonical(self.spec.binding()), "Fresh actual source binding")
        recipe = CueRecipe.prepare(resources, actual_spec)
        validate_new_destinations(self.spec, self.work, self.native)
        self.native.verify_identity()
        actual = self.native.media.verify(CUE_MAX)
        need(len(actual) >= 12 and actual[4:8] == b"ftyp", "Actual MP4 bytes")
        self.work.verify(CUE_MAX)
        expected_ass = self.spec.ass().encode("utf-8")
        need(self.subtitle.verify(131072) == expected_ass, "Actually burned subtitle source must match common safe policy")
        progress = self.encoder_progress.verify(262144).decode("utf-8")
        values = re.findall(r"^frame=([0-9]+)\s*$", progress, re.MULTILINE)
        need(bool(values) and int(values[-1]) == self.spec.slot.frames
             and re.search(r"^progress=end\s*$", progress, re.MULTILINE) is not None,
             "Actual complete selected encoder progress")
        encoded = original_wait(self.encoder_wait, recipe.render.commands[0].spec.argv,
                                "cue_encode", self.spec.cue.cue_id)
        need(FilePin.parse(encoded["stdout"]) == self.encoder_progress,
             "Actual encoder progress is the original process stdout")
        r = object_row(decode(self.probe.verify(65536)))
        need(r.get("schema") == "xar.e04.final47.encode-probe.v1" and r.get("machine_id") == MACHINE
             and r.get("actual_decode_count_frames") is True and integer(r["original_wait"]) == 0
             and integer(r["expected_frames"]) == self.spec.slot.frames, "Actual decode-count probe")
        bound = FilePin.parse(r["media"])
        need((bound.bytes, bound.sha256) == (self.native.media.bytes, self.native.media.sha256),
             "Decode probe refers to the actual work/CAS bytes")
        probed = original_wait(FilePin.parse(r["original_wait_pin"]), recipe.decode_probe_argv,
                               "cue_decode_probe", self.spec.cue.cue_id)
        observed = decode(FilePin.parse(probed["stdout"]).verify(65536))
        need(canonical(observed) == canonical(r["observed"]), "Probe observed JSON is the original stdout")
        validate_encoded_probe(object_row(r["observed"]), self.spec.slot.frames)


@dataclass(frozen=True)
class FullTimeline:
    products: tuple[CueProduct, ...]
    source_project_sha256: str
    source_input44_sha256: str

    @staticmethod
    def actual(products: tuple[CueProduct, ...], resources: Resources) -> FullTimeline:
        need(tuple(p.spec.cue.cue_id for p in products) == EXPECTED_CUES
             and tuple(p.spec.order for p in products) == tuple(range(47)), "Actual exactly47 ordered new products")
        need(sum(p.spec.origin == "retained44" for p in products) == 44
             and {p.spec.cue.cue_id for p in products if p.spec.origin != "retained44"} == MECHANISM_IDS,
             "44 unchanged source inputs and three actual mechanism visuals")
        need(sum(p.native.media.bytes for p in products) <= CAS_TOTAL_MAX, "Actual aggregate47 CAS cap")
        for product in products:
            product.verify(resources)
        return FullTimeline(products, sha(resources.project),
                            digest(resources.unchanged44()["input_signature_sha256"]))

    def wire(self) -> JsonObject:
        at = 0
        entries: list[JsonValue] = []
        for product in self.products:
            entries.append({"start_frame": at, "actual_new_video": product.wire()})
            at += product.spec.slot.frames
        return {"schema": "xar.e04.final47.full-timeline.v1", "machine_id": MACHINE,
            "state": "ACTUAL_47_NEW_DERIVED_VIDEOS", "frame_rate": 30, "cue_count": 47,
            "total_frames": at, "source_project_sha256": self.source_project_sha256,
            "retained44_input_signature_sha256": self.source_input44_sha256,
            "unchanged_source_input_cues": [p.spec.cue.cue_id for p in self.products if p.spec.origin == "retained44"],
            "updated_derived_video_cues": [p.spec.cue.cue_id for p in self.products],
            "old_video_refs_adopted": [], "Chinese_policy_source": SAFE_SOURCE.wire(),
            "entries": entries, "complete_movie_encoded": False}

    @staticmethod
    def parse(value: JsonValue, specs: tuple[CueSpec, ...]) -> FullTimeline:
        """Validate the JSON domain; call consume() for actual file/result qualification."""
        r = object_row(value, {"schema", "machine_id", "state", "frame_rate", "cue_count",
            "total_frames", "source_project_sha256", "retained44_input_signature_sha256",
            "unchanged_source_input_cues", "updated_derived_video_cues", "old_video_refs_adopted",
            "Chinese_policy_source", "entries", "complete_movie_encoded"})
        need(r["schema"] == "xar.e04.final47.full-timeline.v1" and r["machine_id"] == MACHINE
             and r["state"] == "ACTUAL_47_NEW_DERIVED_VIDEOS" and integer(r["frame_rate"]) == 30
             and integer(r["cue_count"]) == 47 and r["complete_movie_encoded"] is False
             and rows(r["old_video_refs_adopted"]) == [] and FilePin.parse(r["Chinese_policy_source"]) == SAFE_SOURCE,
             "New final47 timeline semantics, never old44-video preservation")
        entries = rows(r["entries"])
        need(len(entries) == len(specs) == 47, "Exactly47 actual products")
        products: list[CueProduct] = []
        at = 0
        for entry, spec in zip(entries, specs, strict=True):
            row = object_row(entry, {"start_frame", "actual_new_video"})
            need(integer(row["start_frame"]) == at, "Canonical frame placements")
            product = CueProduct.parse(row["actual_new_video"], spec)
            products.append(product)
            at += spec.slot.frames
        need(integer(r["total_frames"]) == at and
             [cue_id(x) for x in rows(r["updated_derived_video_cues"])] == list(EXPECTED_CUES)
             and [cue_id(x) for x in rows(r["unchanged_source_input_cues"])] ==
             [p.spec.cue.cue_id for p in products if p.spec.origin == "retained44"],
             "All47 derived outputs and unchanged44 inputs have separate meanings")
        return FullTimeline(tuple(products), digest(r["source_project_sha256"]),
                            digest(r["retained44_input_signature_sha256"]))

    @staticmethod
    def consume(value: JsonValue, specs: tuple[CueSpec, ...], resources: Resources) -> FullTimeline:
        parsed = FullTimeline.parse(value, specs)
        expected = FullTimeline.actual(parsed.products, resources)
        need(canonical(parsed.wire()) == canonical(expected.wire()),
             "Actual final47 source, all new CAS and original waits must agree")
        return expected

