"""One typed, pinned source boundary for the final47 successor. No media execution."""
from __future__ import annotations

from dataclasses import dataclass, replace
import datetime as dt
from decimal import Decimal, ROUND_CEILING
import hashlib
from pathlib import Path
import re
import sys
from typing import Literal, TypedDict

BASE = Path("C:/ck3-e04-resume-20261022-b01")
ROOT = BASE / "final47-source-a01"
MEDIA_ROOT = BASE / "final47-media-a01"
SOURCE_LIMIT = 2097152
DEADLINE = dt.datetime(2026, 10, 22, 20, tzinfo=dt.UTC)
SELECTED = BASE / "r08-selected-render-source-a01"
LEGACY = Path("C:/ck3-e04-resume-20261020-a01/r22-mechanics-render-a01")
SAFE = BASE / "root/subtitles"
if hashlib.sha256((SELECTED / "selected_contract.py").read_bytes()).hexdigest() != "f5e144227568b006a407fc503698fe3e3ce1d605a7ce4cacc9079ec2f708814d":
    raise ValueError("Pinned shared typed/Win32 allocation boundary changed")
sys.path.insert(0, str(SELECTED))
from selected_contract import (
    Budget as Budget, FilePin as FilePin, JsonObject as JsonObject, JsonValue as JsonValue,
    MACHINE as MACHINE, RetainedAsset as RetainedAsset, SourceError as SourceError,
    SourcePlan as SourcePlan, Tools as Tools, ActualVoice as ActualVoice,
    canonical as canonical, clock as r08_clock, decode as decode, decimal64 as decimal64,
    digest as digest, duration as duration, integer as integer, json_domain as json_domain,
    make_ass as _make_r08_ass, need as need, now as now, object_row as object_row,
    parse_ass as _parse_r08_ass, pin as pin, process_birth as process_birth,
    project_cues as project_cues, render_ass as render_r08_ass, rows as rows,
    string as string, verify_actual_voices as verify_actual_voices,
    validate_encoded_probe as validate_encoded_probe,
)
from two_cue_edit import Dialogue
CONTRACT = FilePin(str(LEGACY / "mechanics_contract.py"), 21687,
    "4e6e93c69a02b58a2f94e5893c33ecffe62fb92db6dfee1cccef7dddfc438f28")
SAFE_SOURCE = FilePin(str(SAFE / "mechanics_composer.py"), 11746,
    "56358fd6ac3dee1f89f52382e3442444bd00dbac099743c9b50e7ea904e3e494")
CONTRACT.verify(32768)
SAFE_SOURCE.verify(16384)
sys.path.insert(0, str(LEGACY))
from mechanics_contract import (
    Asset as Asset, Cue as Cue, EXPECTED_CUES as EXPECTED_CUES, Pin as Pin,
    RawWindow as RawWindow, SourceProof as SourceProof, Visual as Visual, Voice as Voice,
)
sys.path.insert(0, str(SAFE))
from mechanics_composer import (
    chinese_pages as chinese_pages, clock as legacy_clock,
    cue_plan as _legacy_cue_plan, subtitles as legacy_subtitles,
)
from PIL import ImageFont
make_r08_ass = _make_r08_ass
parse_r08_ass = _parse_r08_ass
legacy_cue_plan = _legacy_cue_plan

PROJECT = FilePin("C:/ck3-e04-resume-20261020-a01/r22-n05-weight-explainer-a01/promo-project.mechanics.N05-a01.json",
    65382, "bd55844551e11f647bd8c3b19aae741a2bd4224a398b3021d1570223f766bfe6")
TIMELINE = FilePin("C:/ck3-e04-resume-20261020-a01/r22-mechanics-full-a01/attempt-a02/FULL-TIMELINE.actual.json",
    84633, "7ad06f7cb04dd3291feb96437e2fe85818bb787e96505cfa0f03901c9965e0a5")
VISUALS = FilePin(str(LEGACY / "VISUAL-MAP.source-a02.json"), 25391,
    "c6c4d355aa9be34e765d28ef52ea16c2f596004664631b73a516ed6a7e382887")
PRODUCTS = FilePin("C:/ck3-e04-resume-20261020-a01/r22-mechanics-voice-assets-a01/ASSETS.actual.json",
    66127, "3261facde509f0e162fa469a172200d9c415e9c6a777de8de96e4ac7a6ba8fd5")
YELLOW = FilePin("C:/ck3-e04-resume-20261020-a01/r22-mechanics-yellow-assets-a01/ASSETS.actual-a02.json",
    38902, "9b89690382b630a29c1e71bc363c11bf1d6348673e9e353e16b8db64b750e07a")
N05 = FilePin("C:/ck3-e04-resume-20261020-a01/r22-n05-weight-explainer-a01/ASSETS.actual-a01.json",
    2867, "e3cd9b887b7baab86df6c46f6e39beed575e28169c27fe314499d2868e5454f8")
R08_FREEZE = FilePin(str(BASE / "r08-edit-source-a01/SOURCE-FREEZE.actual-a02.json"),
    4436, "99a52a815cc407794c84e6ce3ccec73ee08d3b0d778738a7c8d5600e8931d8ba")
R08_REVIEW = FilePin(str(BASE / "root-phase5/ROOT-R08-AUDIO-RASTER-REVIEW.actual-a02.json"),
    1930, "bbf3df3143a9206f00b8521a38d430f0cb81999576b6cdd7834406d06614339c")
R08_VOICES = FilePin(str(BASE / "r08-audio-raster-a01/ACTUAL-VOICES.actual.json"),
    2928, "e72296db24bc9ff84b7b476ec4bf0c9837401f05ec8a376b722d5eabad08e6e5")
R08_IMAGE = FilePin(str(BASE / "r08-audio-raster-a01/ACTUAL-IMAGE.actual.json"),
    1514, "61336b1d036cef5c38f6d833f25f1972c0fa7456b40780847afedd2108701233")
FONT = Path("C:/Windows/Fonts/msyh.ttc")
MECHANISM_IDS = frozenset(("N03-02", "N06-08", "N06-05"))
Origin = Literal["retained44", "accepted_R08", "accepted_R05"]
R05_FIELDS = frozenset(("schema", "machine_id", "observed_at_utc", "reviewer",
    "Root_accepted", "business_qualified", "business_result", "run_id", "case_id",
    "raw", "start_frame", "end_frame", "fps", "actual_raw_frames",
    "client_HUD_complete", "looping", "interpolation", "freeze_tail",
    "Root_actual_review_tool_chunks"))


def legacy_pin(value: FilePin) -> Pin:
    return Pin(Path(value.path), value.bytes, value.sha256)


def modern_pin(value: Pin) -> FilePin:
    return FilePin(str(value.path), value.size, value.sha)


def sha(value: JsonValue) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()


def cue_id(value: JsonValue) -> str:
    result = string(value)
    need(result in EXPECTED_CUES, "Exact original47 cue ID")
    return result


def ordinary_pin(ref: FilePin, maximum: int) -> None:
    ref.verify(maximum)


class PinDocument(TypedDict):
    path: str
    bytes: int
    sha256: str


class IdentityDocument(TypedDict):
    mtime_ns: str
    st_dev: str
    st_ino: str


class AssetDocument(TypedDict):
    path: str
    bytes: int
    retained_sha256: str
    identity: IdentityDocument


class R05AcceptanceDocument(TypedDict):
    schema: Literal["xar.e04.final47.r05-shot-acceptance.v1"]
    machine_id: str
    observed_at_utc: str
    reviewer: Literal["/root"]
    Root_accepted: Literal[True]
    business_qualified: Literal[True]
    business_result: PinDocument
    run_id: str
    case_id: str
    raw: AssetDocument
    start_frame: int
    end_frame: int
    fps: Literal[30]
    actual_raw_frames: int
    client_HUD_complete: Literal[True]
    looping: Literal[False]
    interpolation: Literal[False]
    freeze_tail: Literal[False]
    Root_actual_review_tool_chunks: list[str]


def validate_r05_business(value: JsonValue, run_id: str) -> None:
    actual = object_row(value)
    need(actual.get("machine_id") == MACHINE and actual.get("run_id") == run_id
         and actual.get("business_qualified") is True,
         "Actual qualified business result machine/run binding")


@dataclass(frozen=True)
class R05Record:
    observed_at_utc: str
    business_result: FilePin
    run_id: str
    case_id: str
    raw: RetainedAsset
    start_frame: int
    end_frame: int
    actual_raw_frames: int
    review_chunks: tuple[str, ...]

    @staticmethod
    def parse(value: JsonValue) -> R05Record:
        r = object_row(value, set(R05_FIELDS))
        need(r["schema"] == "xar.e04.final47.r05-shot-acceptance.v1"
             and r["machine_id"] == MACHINE and r["reviewer"] == "/root"
             and r["Root_accepted"] is True and r["business_qualified"] is True,
             "Root actual qualified R05 result and shot acceptance required")
        observed = string(r["observed_at_utc"])
        when = dt.datetime.fromisoformat(observed)
        need(when.tzinfo is not None and when.utcoffset() == dt.timedelta(0), "Observed UTC time")
        run = string(r["run_id"])
        case = string(r["case_id"])
        need(re.fullmatch(r"R[0-9]{4,6}", case) is not None and run.startswith(MACHINE + "--")
             and run.endswith("--" + case) and len(run.split("--")) == 3,
             "Full real same-machine RunID with exact case suffix")
        result = FilePin.parse(r["business_result"])
        validate_r05_business(decode(result.verify(262144)), run)
        need(r["client_HUD_complete"] is True and r["looping"] is False
             and r["interpolation"] is False and r["freeze_tail"] is False
             and integer(r["fps"]) == 30, "Complete HUD and original continuous30fps")
        start, end, total = integer(r["start_frame"]), integer(r["end_frame"]), integer(r["actual_raw_frames"])
        need(0 <= start < end <= total, "Accepted span within actual decoded raw frames")
        raw_row = object_row(r["raw"], {"path", "bytes", "retained_sha256", "identity"})
        raw = RetainedAsset.parse(raw_row)
        raw.verify_identity()
        raw.media.verify(256 * 1048576)
        chunks = tuple(string(v) for v in rows(r["Root_actual_review_tool_chunks"]))
        need(bool(chunks), "Actual direct Root review chunks")
        return R05Record(observed, result, run, case, raw, start, end, total, chunks)

    def document(self) -> R05AcceptanceDocument:
        return {"schema": "xar.e04.final47.r05-shot-acceptance.v1", "machine_id": MACHINE,
            "observed_at_utc": self.observed_at_utc, "reviewer": "/root", "Root_accepted": True,
            "business_qualified": True, "business_result": {"path": self.business_result.path,
                "bytes": self.business_result.bytes, "sha256": self.business_result.sha256},
            "run_id": self.run_id, "case_id": self.case_id,
            "raw": {"path": self.raw.media.path, "bytes": self.raw.media.bytes,
                "retained_sha256": self.raw.media.sha256, "identity": {"mtime_ns": self.raw.mtime_ns,
                    "st_dev": self.raw.device, "st_ino": self.raw.inode}},
            "start_frame": self.start_frame, "end_frame": self.end_frame, "fps": 30,
            "actual_raw_frames": self.actual_raw_frames, "client_HUD_complete": True,
            "looping": False, "interpolation": False, "freeze_tail": False,
            "Root_actual_review_tool_chunks": list(self.review_chunks)}


@dataclass(frozen=True)
class R05Acceptance:
    source: FilePin
    record: R05Record

    @staticmethod
    def parse(ref: FilePin) -> R05Acceptance:
        return R05Acceptance(ref, R05Record.parse(decode(ref.verify(32768))))

    def window(self) -> RawWindow:
        r = self.record
        source = Asset(legacy_pin(r.raw.media), r.raw.mtime_ns, r.raw.device, r.raw.inode)
        return RawWindow("actual.R05." + r.case_id, source, r.start_frame, r.end_frame,
                         SourceProof(legacy_pin(self.source), None))


@dataclass(frozen=True)
class Slot:
    frames: int
    raw_frames: int
    card_frames: int

    def wire(self) -> JsonObject:
        return {"frames": self.frames, "raw_frames": self.raw_frames, "card_frames": self.card_frames}


@dataclass(frozen=True)
class CueSpec:
    cue: Cue
    fields: JsonObject
    origin: Origin
    voice: Voice
    card: FilePin
    raw: RawWindow | None
    slot: Slot
    order: int
    old_video: RetainedAsset
    R08_voice: ActualVoice | None = None
    actual_R05_acceptance: FilePin | None = None

    def binding(self) -> JsonObject:
        raw: JsonValue = None
        if self.raw is not None:
            raw = {"key": self.raw.key, "source": json_domain(self.raw.source.wire()),
                   "first": self.raw.first, "end": self.raw.end}
        return {"cue_id": self.cue.cue_id, "fields": self.fields, "origin": self.origin,
            "voice": modern_pin(self.voice.native).wire(), "actual_seconds": str(self.voice.seconds),
            "card": self.card.wire(), "raw": raw, "slot": self.slot.wire(),
            "safe_Chinese_algorithm": SAFE_SOURCE.wire(),
            "actual_R05_acceptance": None if self.actual_R05_acceptance is None else self.actual_R05_acceptance.wire(),
            "input_source_unchanged": self.origin == "retained44",
            "derived_video_must_be_new": True}

    def ass(self) -> str:
        if self.R08_voice is None:
            return legacy_subtitles(self.cue, self.voice, self.slot.frames, FONT)
        source_plan = SourcePlan.parse(decode((BASE / "r08-edit-source-a01/EDIT-PLAN.source.json").read_bytes()))
        cue = next(c for c in source_plan.cues if c.cue_id == self.cue.cue_id)
        document = make_r08_ass(cue, self.R08_voice.actual_seconds)
        wrapped = chinese_pages(self.cue.zh, ImageFont.truetype(str(FONT), 36))
        old_chinese = [d for d in document.dialogues if d.style == "Chinese"]
        need(len(wrapped) == len(old_chinese), "R08 complete semantic sentence pairing preserved")
        at = 0
        changed: list[Dialogue] = []
        for d in document.dialogues:
            if d.style == "Chinese":
                changed.append(replace(d, text=wrapped[at].replace("\n", r"\N")))
                at += 1
            else:
                changed.append(d)  # Exact approved English words, lines, and measured times.
        output = render_r08_ass(replace(document, dialogues=tuple(changed)))
        need(parse_r08_ass(output).dialogues == tuple(changed), "Actual R08 ASS roundtrip")
        return output


@dataclass(frozen=True)
class Resources:
    original_project: JsonObject
    project: JsonObject
    old_timeline: JsonObject
    voices: dict[str, Voice]
    cards: dict[str, FilePin]
    visuals: dict[str, Visual]
    raw_windows: dict[str, RawWindow]
    R08_plan: SourcePlan
    R08_voices: tuple[ActualVoice, ActualVoice]
    R08_png: FilePin
    tools: Tools

    @staticmethod
    def load() -> Resources:
        original = object_row(decode(PROJECT.verify(131072)))
        old_timeline = object_row(decode(TIMELINE.verify(131072)))
        project = object_row(decode(canonical(original)))
        before, after = project_cues(original), project_cues(project)
        need(tuple(string(r["id"]) for r in before) == EXPECTED_CUES, "Pinned47 order")
        frozen = object_row(decode(R08_FREEZE.verify(8192)))
        for p in rows(frozen["source_pins"]):
            FilePin.parse(p).verify(131072)
        plan = SourcePlan.parse(decode((BASE / "r08-edit-source-a01/EDIT-PLAN.source.json").read_bytes()))
        review = object_row(decode(R08_REVIEW.verify(8192)))
        need(review.get("machine_id") == MACHINE and review.get("accepted_as_actual_two_cue_render_inputs") is True,
             "Root active actual R08 review")
        R08_VOICES.verify(8192)
        actual_voices = verify_actual_voices(Path(R08_VOICES.path), plan)
        image = object_row(decode(R08_IMAGE.verify(8192)))
        png, native = FilePin.parse(image["original_PNG"]), FilePin.parse(image["native_CAS"])
        need((png.bytes, png.sha256) == (native.bytes, native.sha256), "Actual F13 PNG/CAS")
        png.verify(1048576)
        native.verify(1048576)
        need(FilePin.parse(review["direct_visual_source"]) == png, "Root-reviewed F13 bytes")
        need(FilePin.parse(image["source_SVG"]) == pin(BASE / "r08-edit-source-a01/F13.svg"), "F13 actual SVG binding")
        for old, new in zip(before, after, strict=True):
            changed = next((c for c in plan.cues if c.cue_id == old["id"]), None)
            if changed is not None:
                new.update(changed.project_fields())
            else:
                need(canonical(old) == canonical(new), "Unchanged retained source fields")
        products = object_row(decode(PRODUCTS.verify(131072)))
        voices = {v.cue_id: v for v in (Voice.parse(x) for x in rows(products["actual_voice_cues"]))}
        n05 = object_row(decode(N05.verify(8192)))
        successor = Voice.parse(n05["voice_override"])
        need(successor.cue_id == "N05-01" and successor.seconds == Decimal("52.224000"), "Adopted final N05 voice")
        voices["N05-01"] = successor
        for actual in actual_voices:
            voices[actual.cue_id] = Voice(actual.cue_id, "E4-06", actual.text_sha256,
                actual.actual_seconds, int((actual.actual_seconds * 30).to_integral_value(rounding=ROUND_CEILING)),
                legacy_pin(actual.original_mp3), legacy_pin(actual.native_cas), False)
        need(set(voices) == set(EXPECTED_CUES), "Actual complete adopted47 voice source")
        for row in after:
            key = string(row["id"])
            need(hashlib.sha256(string(object_row(row["narration"])["zh-CN"]).encode("utf-8")).hexdigest()
                 == voices[key].text_sha, "Adopted source narration/voice hash")
            modern_pin(voices[key].native).verify(524288)
        y = object_row(decode(YELLOW.verify(65536)))
        cards: dict[str, FilePin] = {}
        for value in rows(y["actual_images"]):
            entry = object_row(value)
            card_pin = FilePin.parse(entry["native_CAS"])
            card_pin.verify(1048576)
            cards[string(entry["id"])] = card_pin
        override = object_row(n05["knowledge_image_override"])
        final_k17 = FilePin.parse(override["native_CAS"])
        final_k17.verify(1048576)
        cards["K17"] = final_k17
        visuals = object_row(decode(VISUALS.verify(65536)))
        visual_rows = {v.cue_id: v for v in (Visual.parse(x) for x in rows(visuals["cues"]))}
        raws = {v.key: v for v in (RawWindow.parse(x) for x in rows(visuals["raw_windows"]))}
        for raw in raws.values():
            raw.source.verify_identity()
        old_entries = [object_row(v) for v in rows(old_timeline["entries"])]
        need(tuple(string(r["cue_id"]) for r in old_entries) == EXPECTED_CUES, "Original47 media source order")
        for value in old_entries:
            # Historical descriptors only. Old MP4 files are not active render inputs.
            RetainedAsset.parse(value["review_cas"])
        need(voices["N03-02"].seconds == Decimal("26.544000"), "Original R05 real measured voice")
        return Resources(original, project, old_timeline, voices, cards, visual_rows,
                         raws, plan, actual_voices, native, Tools.load())

    def spec(self, key: str, r05: R05Acceptance | None = None) -> CueSpec:
        need(key in EXPECTED_CUES, "Exact47 source cue")
        index = EXPECTED_CUES.index(key)
        fields = project_cues(self.project)[index]
        subtitles = object_row(fields["subtitles"])
        chapter = next(string(c["id"]) for c in (object_row(x) for x in rows(self.project["chapters"]))
                       if any(object_row(x)["id"] == key for x in rows(c["cues"])))
        cue = Cue(key, chapter, string(subtitles["zh-CN"]), string(subtitles["en"]),
                  string(object_row(fields["narration"])["zh-CN"]))
        voice = self.voices[key]
        old = object_row(rows(self.old_timeline["entries"])[index])
        old_video = RetainedAsset.parse(old["review_cas"])
        visual = self.visuals[key]
        card = self.cards[visual.card_id]
        raw = self.raw_windows[visual.raw_key] if visual.raw_key is not None else None
        if key == "N03-02":
            need(r05 is not None, "R05_PENDING: actual Root qualified shot is required")
            if r05 is None:
                raise SourceError("R05 acceptance narrowing")
            raw = r05.window()
            timing = legacy_clock(voice, raw)
            return CueSpec(cue, fields, "accepted_R05", voice, self.cards["F04"], raw,
                Slot(timing.frames, timing.raw_frames, timing.card_frames), index, old_video,
                actual_R05_acceptance=r05.source)
        if key in ("N06-08", "N06-05"):
            planned = next(c for c in self.R08_plan.cues if c.cue_id == key)
            actual_voice = next(v for v in self.R08_voices if v.cue_id == key)
            r08_timing = r08_clock(planned, actual_voice.actual_seconds)
            raw = None
            if key == "N06-08":
                self.R08_plan.raw.verify(32 * 1048576)
                retained = RetainedAsset.actual(self.R08_plan.raw)
                raw = RawWindow("actual.R08.R0241", Asset(legacy_pin(retained.media), retained.mtime_ns,
                    retained.device, retained.inode), 180, 1051,
                    SourceProof(legacy_pin(self.R08_plan.actual_shot), None))
            return CueSpec(cue, fields, "accepted_R08", voice, self.R08_png, raw,
                Slot(r08_timing.frames, r08_timing.raw_frames, r08_timing.card_frames), index, old_video, actual_voice)
        timing = legacy_clock(voice, raw)
        need((timing.frames, timing.raw_frames, timing.card_frames) ==
             (integer(old["frames"]), integer(old["raw_frames"]), integer(old["card_frames"])),
             "Retained44 raw/card/voice/clock must exactly match original")
        return CueSpec(cue, fields, "retained44", voice, card, raw,
            Slot(timing.frames, timing.raw_frames, timing.card_frames), index, old_video)

    def unchanged44(self) -> JsonObject:
        before, after = project_cues(self.original_project), project_cues(self.project)
        kept = [i for i, row in enumerate(before) if row["id"] not in MECHANISM_IDS]
        need(len(kept) == 44 and all(canonical(before[i]) == canonical(after[i]) for i in kept),
             "Retained44 source narration fields")
        signatures: list[JsonValue] = [self.spec(string(before[i]["id"])).binding() for i in kept]
        return {"cue_ids": [string(before[i]["id"]) for i in kept],
                "source_fields_sha256": sha([before[i] for i in kept]),
                "input_signature_sha256": sha(signatures), "source_count": 44,
                "derived_video_unchanged_claim": False}

