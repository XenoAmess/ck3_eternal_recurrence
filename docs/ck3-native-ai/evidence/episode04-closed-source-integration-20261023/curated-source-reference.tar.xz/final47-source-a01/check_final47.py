"""Pure checks over pinned real inputs; RAM product fixtures are deliberately nonqualifying."""
from __future__ import annotations

from dataclasses import replace
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
from typing import Callable
from PIL import ImageFont
from final47_base import (
    Cue, CueSpec, EXPECTED_CUES, FONT, FilePin, JsonObject, JsonValue, MACHINE,
    MEDIA_ROOT, MECHANISM_IDS, PROJECT, R05Acceptance, R05AcceptanceDocument,
    R05Record, R05_FIELDS, R08_REVIEW, Resources, RetainedAsset, SAFE_SOURCE,
    Slot, SourceError, canonical, chinese_pages, integer, json_domain, modern_pin,
    need, object_row, parse_r08_ass, project_cues, rows, sha, string, validate_r05_business,
)
from final47_products import CueProduct, FullTimeline, PRODUCT_FIELDS, validate_new_destinations
from final47_recipe import CompleteRecipe, CueRecipe, cue_plan, source_declaration

REPORT: list[str] = []


def rejects(action: Callable[[], object], label: str) -> None:
    try:
        action()
    except (ValueError, TypeError, KeyError, OSError):
        return
    raise AssertionError("Expected strict rejection: " + label)


def clone(value: JsonValue) -> JsonValue:
    return json_domain(json.loads(canonical(value)))


def run_checks() -> JsonObject:
    value: JsonValue
    resources = Resources.load()
    known = tuple(resources.spec(k) for k in EXPECTED_CUES if k != "N03-02")
    retained = resources.unchanged44()
    need(integer(retained["source_count"]) == 44 and retained["derived_video_unchanged_claim"] is False,
         "Source44/media47 distinction")
    before, after = project_cues(resources.original_project), project_cues(resources.project)
    need([r["id"] for a, r in zip(before, after, strict=True) if canonical(a) != canonical(r)]
         == ["N06-08", "N06-05"], "Only actual two R08 source rewrites")
    for spec in known:
        need(spec.origin == ("accepted_R08" if spec.cue.cue_id in MECHANISM_IDS else "retained44"),
             "Actual source origin")
        need(CueRecipe.prepare(resources, spec).spec == spec, "Actual producer inputs")
    REPORT.append("real_pinned44_fields_inputs_clocks_and46_known_recipe_producer")

    n05 = resources.spec("N05-01")
    need(n05.voice.seconds == Decimal("52.224000") and n05.slot.frames == 1597
         and n05.card.sha256 == "7cb50df4003cecf7ca020972bff47e8b5437736ca4169e936b4653c0a510ab77",
         "Final N05 voice52.224/K17")
    REPORT.append("final_N05_voice52_224_clock1597_K17_not_old_assets")

    font = ImageFont.truetype(str(FONT), 36)
    text_pages = 0
    closing = "\uff0c\u3002\uff01\uff1f\uff1b\uff1a\u3001,.!?;:\uff09\u3011\u300b\u201d\u2019"
    for row in after:
        value = string(object_row(row["subtitles"])["zh-CN"])
        pages = chinese_pages(value, font)
        need("".join(p.replace("\n", "") for p in pages) == re.sub(r"\s+", "", value),
             "All47 Chinese text complete and ordered")
        for page in pages:
            lines = page.splitlines()
            need(1 <= len(lines) <= 2, "At most two Chinese lines")
            for line in lines:
                need(len(line) <= 32 and font.getlength(line) <= 1370 and line[0] not in closing,
                     "Same approved2c151 character/pixel/punctuation limits")
            joined = page.replace("\n", "")
            split_at = len(lines[0])
            if len(lines) == 2:
                for number in re.finditer(r"[\u96f6\u3007\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u5341\u767e\u5343\u4e07\u4ebf\u4e24\u70b9]+|\d+(?:[.,]\d+)*", joined):
                    need(not number.start() < split_at < number.end(), "Number tokens remain intact")
        text_pages += len(pages)
    REPORT.append("all47_safe_Chinese_complete_two_lines_32chars_1370px_numbers_punctuation")

    for spec in known:
        content = spec.ass()
        for line in content.splitlines():
            if line.startswith("Dialogue: ") and line.split(",", 4)[3] == "Chinese":
                value = line.split(",", 9)[9]
                value = re.sub(r"^\{\\q[0-3]\}", "", value)
                need(all(len(part) <= 32 for part in value.split(r"\N")), "Actual ASS uses safe32 algorithm")
        recipe = CueRecipe.prepare(resources, spec)
        argv = recipe.render.commands[0].spec.argv
        graph = argv[argv.index("-filter_complex") + 1]
        need(graph.count("drawbox=x=0:y=864") == 1 and "pad=1920:1080:192:0:color=0x211813" in graph
             and argv[argv.index("-frames:v") + 1] == str(spec.slot.frames)
             and argv[argv.index("-threads:v") + 1] == "1"
             and "atempo" not in graph and "minterpolate" not in graph, "Common real composer/caption seam")
        input_paths = [Path(argv[i + 1]) for i, arg in enumerate(argv) if arg == "-i"]
        need(spec.voice.native.path in input_paths and "-fs" in argv, "Real native voice/output bounded")
        if spec.raw is not None:
            need(f"trim=start_frame={spec.raw.first}:end_frame={spec.raw.end}" in graph
                 and "tpad" not in graph.split("[live]")[0], "No frozen or looped live shot")
    REPORT.append("46_actual_ASS_and_public_composer_geometry_real_inputs_framecap")

    for key, frames in (("N06-08", 871), ("N06-05", 946)):
        spec = resources.spec(key)
        need(spec.slot.frames == frames and spec.R08_voice is not None, "Exact frozen R08 override")
        document = parse_r08_ass(spec.ass())
        need(len([d for d in document.dialogues if d.style == "Chinese"]) == 5
             and len([d for d in document.dialogues if d.style == "English"]) == 5,
             "Five actual paired sentences")
        planned = next(c for c in resources.R08_plan.cues if c.cue_id == key)
        from final47_base import make_r08_ass
        original = make_r08_ass(planned, spec.voice.seconds)
        need([d for d in document.dialogues if d.style == "English"] ==
             [d for d in original.dialogues if d.style == "English"], "English text/times unchanged")
        need([(d.start_cs, d.end_cs) for d in document.dialogues] ==
             [(d.start_cs, d.end_cs) for d in original.dialogues], "Actual R08 timing unchanged")
    REPORT.append("R08_actual22_704_25_896_voice_871_946_English_times_preserved_safeChinese")

    declaration = source_declaration(resources)
    need(declaration["complete_actual_recipe"] is False and declaration["pending_R05_acceptance"] is None
         and declaration["media_executed"] is False
         and len(rows(declaration["known_actual_input_cues"])) == 46, "Honest source-only pending state")
    rejects(lambda: resources.spec("N03-02"), "No actual R05 shot")
    rejects(lambda: CompleteRecipe.prepare(resources, None), "No full47 without actual R05")
    rejects(lambda: cue_plan(resources, known[0], root=MEDIA_ROOT.parent), "Exact future output root")
    REPORT.append("missing_R05_blocks_complete47_no_future_Pin_or_media_execution")

    run = MACHINE + "--vanilla--R9999"
    positive: JsonObject = {"machine_id": MACHINE, "run_id": run, "business_qualified": True}
    validate_r05_business(positive, run)
    for value in (None, False, 1, 1.0, "true"):
        bad = dict(positive)
        bad["business_qualified"] = value
        rejects(lambda: validate_r05_business(bad, run), "Business bool literaltrue")
    for key, value in (("machine_id", "other"), ("run_id", MACHINE + "--vanilla--R9998")):
        bad = dict(positive)
        bad[key] = value
        rejects(lambda: validate_r05_business(bad, run), "Business identity")
    missing = dict(positive)
    missing.pop("business_qualified")
    rejects(lambda: validate_r05_business(missing, run), "Missing causal qualification")
    REPORT.append("R05_business_literalTrue_and_exact_machine_run_no_ACK_substitution")

    # RAM schema fixture; its real file is the R08 review and must never qualify as R05.
    ref = R08_REVIEW
    raw = RetainedAsset.actual(resources.R08_plan.raw)
    record = R05Record("2026-10-22T19:00:00Z", ref, run, "R9999", raw, 180, 1051, 1332, ("RAM_fixture",))
    acceptance_document: R05AcceptanceDocument = record.document()
    wire = json_domain(acceptance_document)
    need(set(object_row(wire)) == R05_FIELDS and canonical(clone(wire)) == canonical(wire),
         "Single TypedDict producer/JSON domain roundtrip")
    for key, value in (("fps", True), ("start_frame", 1.0), ("case_id", "R9998"),
                       ("Root_accepted", 1), ("reviewer", "/other"),
                       ("business_qualified", None), ("observed_at_utc", "2026-10-22T19:00:00")):
        bad = object_row(clone(wire))
        bad[key] = value
        rejects(lambda: R05Record.parse(bad), "R05 bad field " + key)
    for key in R05_FIELDS:
        bad = object_row(clone(wire))
        bad.pop(key)
        rejects(lambda: R05Record.parse(bad), "R05 missing " + key)
    bad = object_row(clone(wire))
    bad["old_shot_review_alias"] = ref.wire()
    rejects(lambda: R05Record.parse(bad), "Unknown alias")
    rejects(lambda: R05Record.parse(wire), "Actual R08 result is not an R05 causal result")
    rejects(lambda: CompleteRecipe.prepare(resources, R05Acceptance(ref, record)),
            "Hand-assembled acceptance cannot bypass source reparse")
    REPORT.append("single_R05_document_roundtrip_wrong_missing_types_64bit_source_and_fake_acceptance_rejected")

    # Existing actual PNG is intentionally an invalid video fixture. No future media Pin is fabricated.
    png = resources.R08_png
    fixture = CueProduct(known[0], png, png, RetainedAsset.actual(png), png, png, png)
    parsed = CueProduct.parse(clone(fixture.wire()), known[0])
    need(parsed == fixture and set(parsed.wire()) == PRODUCT_FIELDS, "One product producer/consumer JSON contract")
    rejects(lambda: parsed.verify(resources), "PNG cannot qualify as MP4 or carry actual waits")
    for key in PRODUCT_FIELDS:
        bad = object_row(clone(fixture.wire()))
        bad.pop(key)
        rejects(lambda: CueProduct.parse(bad, known[0]), "Product missing " + key)
    for key, value in (("frames", True), ("order", 0.0), ("origin", "old44"),
                       ("voice_seconds", "99"), ("input_binding_sha256", "0" * 64)):
        bad = object_row(clone(fixture.wire()))
        bad[key] = value
        rejects(lambda: CueProduct.parse(bad, known[0]), "Product wrong " + key)
    adopted = replace(fixture, spec=replace(known[0], old_video=RetainedAsset.actual(png)))
    need(CueProduct.parse(adopted.wire(), adopted.spec) == adopted,
         "Hash equality alone does not decide actual re-encoding")
    rejects(lambda: validate_new_destinations(adopted.spec, adopted.work, adopted.native),
            "Old video identity or path cannot be adopted")
    rejects(lambda: FullTimeline.actual((fixture,), resources), "Not47 real products")
    rejects(lambda: FullTimeline.parse({"schema": "old-preserve44"}, known), "Old partial merge schema")
    REPORT.append("actual_product_single_contract_roundtrip_corruption_oldvideo_PNG_falsequalification_rejected")

    for value in (True, 30.0, "30", None):
        rejects(lambda: integer(value), "No bool/float/string integer")
    for value in (True, 13886423844274364792, 13886423844274364792.0, "01", "1e3"):
        bad_asset = object_row(clone(raw.wire()))
        identity = object_row(bad_asset["identity"])
        identity["st_dev"] = value
        rejects(lambda: RetainedAsset.parse(bad_asset), "Canonical decimal64 only")
    REPORT.append("strict_integer_and_canonical_decimal64_JSON_identity_boundaries")
    need(len(REPORT) == 10, "Focused group count")
    return {"schema": "xar.e04.final47.pure-focused.v1", "machine_id": MACHINE,
        "status": "PASS", "checks": list(REPORT), "check_groups": len(REPORT),
        "safe_Chinese_pages": text_pages, "actual_media_executed": False,
        "RAM_product_fixtures_nonqualifying": True, "actual_R05_positive_path": "PENDING_REAL_ROOT_ACCEPTANCE"}


if __name__ == "__main__":
    print(json.dumps(run_checks(), ensure_ascii=False, sort_keys=True))

