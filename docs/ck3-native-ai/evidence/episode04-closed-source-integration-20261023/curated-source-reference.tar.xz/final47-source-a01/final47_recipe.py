"""Pure per-cue/concat production recipe. Planning never launches a media process."""
from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from xar_promo.audio import AudioMixSpec, AudioStem
from xar_promo.render import (
    GeneratedTextFile, RenderOptions, RenderPlan, ass_burn_in_filter, plan_concat, plan_render,
)
from final47_base import (
    CueSpec, EXPECTED_CUES, FONT, JsonObject, JsonValue, MACHINE, MEDIA_ROOT,
    R05Acceptance, Resources, SAFE_SOURCE, canonical, legacy_cue_plan, modern_pin,
    need, sha, string,
)
from final47_products import FullTimeline, FULL_MAX

CUE_FS = 17 * 1048576
ENCODER_SECONDS = 300
PROBE_SECONDS = 120
CONCAT_SECONDS = 180


def plan_wire(plan: RenderPlan) -> JsonObject:
    return {"commands": [{"argv": [str(a) for a in p.spec.argv],
            "working_directory": None if p.spec.cwd is None else str(p.spec.cwd),
            "audit_directory": str(p.audit_directory)} for p in plan.commands],
        "generated_files": [{"path": str(f.path), "encoding": f.encoding,
                              "content": f.content} for f in plan.generated_files],
        "partial_output": str(plan.partial_output), "final_output": str(plan.final_output)}


def cue_plan(resources: Resources, spec: CueSpec, *, root: Path) -> RenderPlan:
    need(root.resolve() == MEDIA_ROOT.resolve(), "One declared future final47 media root")
    need(spec.slot.frames > 0 and spec.slot.frames == spec.slot.raw_frames + spec.slot.card_frames,
         "Exact common frame clock")
    ass = root / "subtitles" / (spec.cue.cue_id + ".ass")
    if spec.origin != "accepted_R08":
        plan, timing = legacy_cue_plan(spec.cue, resources.visuals[spec.cue.cue_id],
            spec.voice, spec.raw, Path(spec.card.path), Path(resources.tools.music.media.path),
            ass, work=root / "work", ffmpeg=Path(resources.tools.ffmpeg.media.path), font_path=FONT)
        need((timing.frames, timing.raw_frames, timing.card_frames) ==
             (spec.slot.frames, spec.slot.raw_frames, spec.slot.card_frames), "Generic actual cue clock")
        command = plan.commands[0]
        argv = list(command.spec.argv)
        argv[-1:-1] = ["-fs", str(CUE_FS)]
        return replace(plan, commands=(replace(command, spec=replace(command.spec, argv=tuple(argv))),),
                       generated_files=(GeneratedTextFile(ass, spec.ass()),))
    duration = spec.slot.frames / 30
    output = root / "work" / (spec.cue.cue_id + ".mp4")
    source = Path(spec.card.path) if spec.raw is None else spec.raw.source.pin.path
    plan = plan_render(ffmpeg=resources.tools.ffmpeg.media.path, video_input=source,
        partial_output=output.with_suffix(".partial.mp4"), final_output=output,
        audit_directory=root / "audit" / spec.cue.cue_id,
        options=RenderOptions(1920, 1080, 30, duration, preset="veryfast", crf=21,
                              audio_bitrate="192k", pad_color="0x211813"),
        ass_path=ass, working_directory=root,
        audio_mix=AudioMixSpec((AudioStem("narration", spec.voice.native.path),
            AudioStem("music", Path(resources.tools.music.media.path), gain_db=-24,
                      fade_in_seconds=1, fade_out_seconds=2)), duration_seconds=duration))
    need(len(plan.commands) == 1, "One installed public selected command")
    command = plan.commands[0]
    argv = list(command.spec.argv)
    graph_at = argv.index("-filter_complex") + 1
    graph = argv[graph_at]
    geometry = ("scale=1536:864:force_original_aspect_ratio=decrease:flags=lanczos,"
                "pad=1920:1080:192:0:color=0x211813,setsar=1")
    caption = ass_burn_in_filter(ass)
    if spec.cue.cue_id == "N06-08":
        need(spec.raw is not None and (spec.raw.first, spec.raw.end) == (180, 1051)
             and (spec.slot.frames, spec.slot.raw_frames, spec.slot.card_frames) == (871, 871, 0),
             "Accepted continuous original R0241 shot")
        need(graph.startswith("[0:v]") and ";" in graph and "-loop" not in argv, "Unlooped raw source")
        graph = ("[0:v]trim=start_frame=180:end_frame=1051,setpts=PTS-STARTPTS,"
                 + geometry + ",fps=30," + caption + ",format=yuv420p[v];" + graph.split(";", 1)[1])
    else:
        need(spec.cue.cue_id == "N06-05" and spec.raw is None
             and (spec.slot.frames, spec.slot.raw_frames, spec.slot.card_frames) == (946, 0, 946),
             "Explicit frozen946 still-card override, real voice unchanged")
        before = "scale=1920:1080:force_original_aspect_ratio=decrease:flags=lanczos"
        pad = "pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=0x211813"
        need(graph.count(before) == graph.count(pad) == 1, "Public still geometry seam")
        graph = graph.replace(before, geometry.split(",pad=")[0], 1).replace(
            pad, "pad=1920:1080:192:0:color=0x211813", 1)
    need(graph.count(caption) == 1 and all(t not in graph for t in ("minterpolate", "atempo"))
         and (spec.raw is None or "tpad" not in graph),
         "Actual raw HUD, one caption band, unchanged-speed real voice")
    argv[graph_at] = graph.replace(caption,
        "drawbox=x=0:y=864:w=iw:h=2:color=0xCBA56A:t=fill," + caption, 1)
    argv[1:1] = ["-threads", "1", "-filter_complex_threads", "1", "-nostats", "-progress", "pipe:1"]
    argv[-1:-1] = ["-threads:v", "1", "-frames:v", str(spec.slot.frames), "-profile:v", "high",
        "-level:v", "4.0", "-video_track_timescale", "15360", "-maxrate", "4M",
        "-bufsize", "8M", "-fs", str(CUE_FS)]
    return replace(plan, commands=(replace(command, spec=replace(command.spec, argv=tuple(argv))),),
                   generated_files=(GeneratedTextFile(ass, spec.ass()),))


@dataclass(frozen=True)
class CueRecipe:
    spec: CueSpec
    render: RenderPlan
    decode_probe_argv: tuple[str, ...]

    @staticmethod
    def prepare(resources: Resources, spec: CueSpec) -> CueRecipe:
        plan = cue_plan(resources, spec, root=MEDIA_ROOT)
        probe = (resources.tools.ffprobe.media.path, "-v", "error", "-count_frames",
                 "-show_streams", "-show_format", "-of", "json", str(plan.final_output))
        return CueRecipe(spec, plan, probe)

    def wire(self) -> JsonObject:
        return {"cue_id": self.spec.cue.cue_id, "binding": self.spec.binding(),
            "render": plan_wire(self.render), "decode_probe_argv": list(self.decode_probe_argv),
            "encoder_timeout_seconds": ENCODER_SECONDS, "probe_timeout_seconds": PROBE_SECONDS,
            "maximum_encoder_output_bytes": CUE_FS, "maximum_actual_cue_bytes": 18 * 1048576,
            "one_encoder_attempt": True, "one_decode_probe_attempt": True,
            "actual_original_Popen_wait_and_Job0_required": True, "new_actual_CAS_required": True}


@dataclass(frozen=True)
class CompleteRecipe:
    resources: Resources
    acceptance: R05Acceptance
    cues: tuple[CueRecipe, ...]

    @staticmethod
    def prepare(resources: Resources, acceptance: R05Acceptance | None) -> CompleteRecipe:
        need(acceptance is not None, "R05_PENDING: complete47 recipe requires actual Root acceptance")
        if acceptance is None:
            raise ValueError("Missing actual R05 acceptance")
        # Reconsume the real source at the public boundary; never trust a manually assembled dataclass.
        verified = R05Acceptance.parse(acceptance.source)
        need(verified == acceptance, "Actual R05 record and source Pin agree")
        cues = tuple(CueRecipe.prepare(resources, resources.spec(k, verified)) for k in EXPECTED_CUES)
        need(len(cues) == 47 and tuple(c.spec.order for c in cues) == tuple(range(47)),
             "Single full47 ordered recipe")
        return CompleteRecipe(resources, verified, cues)

    def wire(self) -> JsonObject:
        unchanged = self.resources.unchanged44()
        return {"schema": "xar.e04.final47.complete-recipe.v1", "machine_id": MACHINE,
            "state": "SOURCE_RECIPE_ACTUAL47_MEDIA_UNMATERIALIZED", "media_root": str(MEDIA_ROOT),
            "R05_actual_acceptance": self.acceptance.source.wire(),
            "project": self.resources.project, "retained44_source_inputs": unchanged,
            "Chinese_policy_source": SAFE_SOURCE.wire(), "derived_video_updates": 47,
            "old_video_refs_adopted": [], "cues": [c.wire() for c in self.cues],
            "all_render_outputs_unmaterialized": True,
            "separate_fresh_actual_media_capacity_admission_required": True}


def source_declaration(resources: Resources) -> JsonObject:
    known: list[JsonValue] = [CueRecipe.prepare(resources, resources.spec(k)).wire()
             for k in EXPECTED_CUES if k != "N03-02"]
    return {"schema": "xar.e04.final47.pending-source-recipe.v1", "machine_id": MACHINE,
        "state": "SOURCE_READY_WAITING_ACTUAL_R05", "complete_actual_recipe": False,
        "known_actual_input_cues": known, "pending_cue_id": "N03-02",
        "pending_R05_acceptance": None, "retained44_source_inputs": resources.unchanged44(),
        "safe_Chinese_algorithm": SAFE_SOURCE.wire(), "derived_videos_to_update": 47,
        "old_video_refs_adopted": [], "media_executed": False,
        "future_media_root": str(MEDIA_ROOT), "source_project_sha256": sha(resources.project),
        "finite_execution_contract": {"sequential_cue_encoder_seconds": ENCODER_SECONDS,
            "cue_probe_seconds": PROBE_SECONDS, "concat_seconds": CONCAT_SECONDS,
            "full_probe_seconds": 180, "max_attempts_per_command": 1,
            "original_Popen_wait_required": True, "JobObject_active0_closed_required": True,
            "timeout_terminate_Job_then_wait_original": True,
            "media_and_TEMP_all_in_new_media_root": True,
            "no_TTS_or_raster_or_old_video_reuse": True}}


def concat_plan(resources: Resources, timeline: FullTimeline, *, root: Path) -> RenderPlan:
    need(root.resolve() == MEDIA_ROOT.resolve(), "Exact future media root")
    need(timeline.source_project_sha256 == sha(resources.project)
         and timeline.source_input44_sha256 == string(resources.unchanged44()["input_signature_sha256"]),
         "Actual final47 timeline binds the current source")
    # Every supplied product is reverified before a complete-movie command can exist.
    checked = FullTimeline.actual(timeline.products, resources)
    need(canonical(checked.wire()) == canonical(timeline.wire()), "Canonical actual47 timeline")
    output = root / "final" / "episode04.final47.mp4"
    plan = plan_concat(ffmpeg=resources.tools.ffmpeg.media.path,
        segment_paths=tuple(Path(p.native.media.path) for p in checked.products),
        concat_path=root / "final" / "actual47.concat.txt",
        partial_output=output.with_suffix(".partial.mp4"), final_output=output,
        audit_directory=root / "audit", working_directory=root)
    command = plan.commands[0]
    argv = list(command.spec.argv)
    argv[1:1] = ["-threads", "1", "-nostats", "-progress", "pipe:1"]
    argv[-1:-1] = ["-fs", str(FULL_MAX - 1048576), "-video_track_timescale", "15360"]
    # Explicit frame-grid durations prevent AAC packet padding from moving the next visual shot.
    generated = plan.generated_files[0]
    file_lines = [line for line in generated.content.splitlines() if line.startswith("file ")]
    need(len(file_lines) == 47, "Public concat manifest seam")
    content = "ffconcat version 1.0\n" + "".join(
        line + "\nduration " + f"{product.spec.slot.frames / 30:.9f}" + "\n"
        for line, product in zip(file_lines, checked.products, strict=True))
    return replace(plan, commands=(replace(command, spec=replace(command.spec, argv=tuple(argv))),),
                   generated_files=(GeneratedTextFile(generated.path, content),))

