"""Typed selected R08 render inputs and explicit three-cue adoption boundary."""
from __future__ import annotations

import copy
from dataclasses import dataclass
import datetime as dt
from decimal import Decimal
import hashlib
import importlib.metadata
from pathlib import Path
import re
import io
import subprocess
import sys
import tarfile
from typing import Literal

BASE = Path("C:/ck3-e04-resume-20261022-b01")
SOURCE_ROOT = BASE / "r08-selected-render-source-a01"
RENDER_ROOT = BASE / "r08-selected-render-a01"
OLD_SOURCE = BASE / "r08-edit-source-a01"
AUDIO_ROOT = BASE / "r08-audio-raster-a01"
DEADLINE = dt.datetime(2026, 10, 22, 19, 30, tzinfo=dt.UTC)
SOURCE_LIMIT = 1048576
RENDER_LIMIT = 83886080
MOVIE_MAX = 18 * 1048576
ENCODER_FS = 17 * 1048576
CARD = BASE / "capacity/future-control-a01/R08-SELECTED-RENDER-SOURCE-ADMISSION.actual-a01.json"
CARD_SHA = "62f5d82f501e24baa6575f3962b4b93aa99f9a7dfff55db99873aa5d4d97567b"
PURPOSE = BASE / "root-phase5/ROOT-R08-SELECTED-RENDER-SOURCE-PURPOSE.actual-a01.json"
PURPOSE_SHA = "aaa1dc6d34f3df145112c2592f443c070575c719d7201ae1d77b64c0408edd71"

for _path, _sha in [
    (OLD_SOURCE / "two_cue_edit.py", "5889e1bd598d8994d71434ab9a4273aaf16e1826d6be7696357d9e26e7f66c58"),
    (AUDIO_ROOT / "produce_actual_assets.py", "6e12e9235616fefbaf16da2c439297ffb712fc4dc2e1070897e509bf6dde30b0"),
]:
    if hashlib.sha256(_path.read_bytes()).hexdigest() != _sha:
        raise ValueError("Frozen shared boundary changed")
sys.path.insert(0, str(AUDIO_ROOT))
sys.path.insert(0, str(OLD_SOURCE))
from two_cue_edit import (  # noqa: E402
    ActualVoice as ActualVoice, Cue as Cue, CueClock as CueClock, FilePin as FilePin,
    JsonObject as JsonObject, JsonValue as JsonValue, MACHINE as MACHINE,
    SourceError as SourceError, SourcePlan as SourcePlan, canonical as canonical,
    clock as clock, decode as decode, digest as digest, duration as duration,
    integer as integer, json_domain as json_domain, load_baseline as load_baseline,
    make_ass as make_ass, object_row as object_row, parse_ass as parse_ass,
    project_cues as project_cues, render_ass as render_ass, rows as rows,
    string as string, verify_actual_voices as verify_actual_voices,
)
from produce_actual_assets import (  # noqa: E402
    Budget as Budget, now as now, pin as pin, process_birth as process_birth,
)

REVIEW = FilePin(str(BASE / "root-phase5/ROOT-R08-AUDIO-RASTER-REVIEW.actual-a02.json"),
    1930, "bbf3df3143a9206f00b8521a38d430f0cb81999576b6cdd7834406d06614339c")
VOICES = FilePin(str(AUDIO_ROOT / "ACTUAL-VOICES.actual.json"),
    2928, "e72296db24bc9ff84b7b476ec4bf0c9837401f05ec8a376b722d5eabad08e6e5")
IMAGE = FilePin(str(AUDIO_ROOT / "ACTUAL-IMAGE.actual.json"),
    1514, "61336b1d036cef5c38f6d833f25f1972c0fa7456b40780847afedd2108701233")
FREEZE = FilePin(str(OLD_SOURCE / "SOURCE-FREEZE.actual-a02.json"),
    4436, "99a52a815cc407794c84e6ce3ccec73ee08d3b0d778738a7c8d5600e8931d8ba")
TOOLS = FilePin("C:/ck3-e04-resume-20261020-a01/r22-mechanics-render-a01/INPUTS.yellow-base46.actual-a04.json",
    4787, "13da45a4a0bca3af76b357ac1afafb560925bd58a4cb1be80f1fc192cd116029")
PatchId = Literal["N06-08", "N06-05", "N03-02"]


def need(condition: bool, message: str) -> None:
    if not condition:
        raise SourceError(message)


def decimal64(value: JsonValue) -> str:
    text = string(value)
    need(re.fullmatch(r"0|[1-9][0-9]*", text) is not None and int(text) < 2**64,
         "Canonical unsigned64 decimal string")
    return text


def source_budget() -> Budget:
    raw = CARD.read_bytes()
    need(len(raw) == 4221 and hashlib.sha256(raw).hexdigest() == CARD_SHA, "Actual source card pin")
    card = object_row(decode(raw))
    need(card.get("schema") == "xar.capacity.r08-selected-render-source-only-admission.v1"
         and card.get("machine_id") == MACHINE and card.get("admitted") is True
         and card.get("budget_status") == "GREEN" and card.get("source_only_admitted") is True
         and card.get("actual_FFmpeg_TTS_PNG_Game_SDK_screen_W_media_copy_admitted") is False,
         "Source-only financial admission")
    need(Path(string(card["exact_root"])) == SOURCE_ROOT
         and integer(card["maximum_new_C_allocated_bytes"]) == SOURCE_LIMIT
         and integer(card["maximum_new_D_allocated_bytes"]) == 0
         and card["hard_deadline_utc"] == "2026-10-22T19:30:00Z", "Source bounds")
    purpose = FilePin.parse(card["Root_independent_purpose"])
    need(Path(purpose.path) == PURPOSE and purpose.sha256 == PURPOSE_SHA, "Root source purpose")
    purpose.verify(8192)
    need(FilePin.parse(card["actual_inputs_review_a02"]) == REVIEW, "Active a02 review only")
    REVIEW.verify(8192)
    return Budget(SOURCE_ROOT, DEADLINE, limit=SOURCE_LIMIT)


@dataclass(frozen=True)
class RetainedAsset:
    media: FilePin
    mtime_ns: str
    device: str
    inode: str

    @staticmethod
    def parse(value: JsonValue) -> RetainedAsset:
        r = object_row(value)
        identity = object_row(r["identity"], {"mtime_ns", "st_dev", "st_ino"})
        return RetainedAsset(FilePin.parse({"path": r["path"], "bytes": r["bytes"],
            "sha256": r["retained_sha256"]}), decimal64(identity["mtime_ns"]),
            decimal64(identity["st_dev"]), decimal64(identity["st_ino"]))

    @staticmethod
    def actual(media: FilePin) -> RetainedAsset:
        info = Path(media.path).stat()
        need(info.st_size == media.bytes, "Closed media size")
        return RetainedAsset(media, str(info.st_mtime_ns), str(info.st_dev), str(info.st_ino))

    def verify_identity(self) -> None:
        p = Path(self.media.path)
        info = p.stat()
        need(p.is_file() and not info.st_file_attributes & 0x400 and
             (info.st_size, str(info.st_mtime_ns), str(info.st_dev), str(info.st_ino)) ==
             (self.media.bytes, self.mtime_ns, self.device, self.inode), "Retained ordinary media identity")

    def wire(self) -> JsonObject:
        return {"path": self.media.path, "bytes": self.media.bytes,
            "retained_sha256": self.media.sha256,
            "identity": {"mtime_ns": self.mtime_ns, "st_dev": self.device, "st_ino": self.inode}}


@dataclass(frozen=True)
class Tools:
    ffmpeg: RetainedAsset
    ffprobe: RetainedAsset
    music: RetainedAsset
    job_helper: FilePin

    @staticmethod
    def load() -> Tools:
        r = object_row(decode(TOOLS.verify(16384)))
        result = Tools(RetainedAsset.parse(r["ffmpeg"]), RetainedAsset.parse(r["ffprobe"]),
                       RetainedAsset.parse(r["music"]), FilePin.parse(r["job_helper"]))
        for asset in (result.ffmpeg, result.ffprobe, result.music):
            asset.verify_identity()
        result.job_helper.verify(32768)
        need(importlib.metadata.version("xar-promo-toolchain") == "0.3.0", "Actual public toolchain")
        return result


@dataclass(frozen=True)
class SelectedCue:
    cue: Cue
    voice: ActualVoice
    timing: CueClock
    visual: FilePin
    source_fields: JsonObject
    project_order_index: int

    def ass(self) -> str:
        document = make_ass(self.cue, self.voice.actual_seconds)
        encoded = render_ass(document)
        need(parse_ass(encoded) == document, "Actual ASS supported-domain exact roundtrip")
        return encoded

    def binding(self, tools: Tools) -> JsonObject:
        return {"cue_id": self.cue.cue_id, "project_fields": self.source_fields,
            "voice": self.voice.wire(), "frames": self.timing.frames,
            "raw_frames": self.timing.raw_frames, "card_frames": self.timing.card_frames,
            "actual_voice_seconds": str(self.voice.actual_seconds),
            "visual": self.visual.wire(),
            "source_frames": [180, 1051] if self.cue.cue_id == "N06-08" else None,
            "target_frames": 946 if self.cue.cue_id == "N06-05" else None,
            "ASS_sha256": hashlib.sha256(self.ass().encode("utf-8")).hexdigest(),
            "music": tools.music.wire(), "ffmpeg": tools.ffmpeg.wire(),
            "Root_actual_input_review": REVIEW.wire(), "actual_voice_manifest": VOICES.wire()}

    def fingerprint(self, tools: Tools) -> str:
        return hashlib.sha256(canonical(self.binding(tools))).hexdigest()


@dataclass(frozen=True)
class ActualInputs:
    plan: SourcePlan
    selected: tuple[SelectedCue, SelectedCue]
    project: JsonObject
    timeline: JsonObject
    tools: Tools
    image_png: FilePin
    readonly_git_proof: JsonObject

    @staticmethod
    def load(repo: Path) -> ActualInputs:
        frozen = object_row(decode(FREEZE.verify(8192)))
        refs = rows(frozen["source_pins"])
        need(len(refs) == 8, "Exact edited-source freeze")
        for ref in refs:
            FilePin.parse(ref).verify(131072)
        plan = SourcePlan.parse(decode((OLD_SOURCE / "EDIT-PLAN.source.json").read_bytes()))
        review = object_row(decode(REVIEW.verify(8192)))
        need(review.get("machine_id") == MACHINE and review.get("accepted_as_actual_two_cue_render_inputs") is True
             and review.get("F13_Root_visual_reviewed") is True
             and FilePin.parse(review["actual_voices"]) == VOICES, "Active independent actual input acceptance")
        VOICES.verify(8192)
        voices = verify_actual_voices(Path(VOICES.path), plan)
        image = object_row(decode(IMAGE.verify(8192)))
        need(image.get("machine_id") == MACHINE and image.get("status") == "ACTUAL_SINGLE_F13_RASTER"
             and image.get("id") == "F13" and image.get("review_label") is False
             and [integer(x) for x in rows(image["dimensions"])] == [1920, 1080]
             and image.get("mode") == "RGB", "Actual single F13 image")
        png = FilePin.parse(image["original_PNG"])
        native = FilePin.parse(image["native_CAS"])
        need((png.bytes, png.sha256) == (native.bytes, native.sha256), "Actual PNG/CAS equality")
        png.verify(1048576)
        native.verify(1048576)
        svg = FilePin.parse(image["source_SVG"])
        need(svg == pin(OLD_SOURCE / "F13.svg"), "Actual raster bound to edited F13 SVG")
        svg.verify(8192)
        plan.actual_shot.verify(16384)
        plan.raw.verify(32 * 1048576)
        project, timeline, git_proof = read_baseline(plan, repo)
        project_rows = project_cues(project)
        selected: list[SelectedCue] = []
        for cue, voice in zip(plan.cues, voices, strict=True):
            index = next(i for i, row in enumerate(project_rows) if row["id"] == cue.cue_id)
            selected.append(SelectedCue(cue, voice, clock(cue, voice.actual_seconds),
                plan.raw if cue.cue_id == "N06-08" else native, cue.project_fields(), index))
        return ActualInputs(plan, (selected[0], selected[1]), project, timeline, Tools.load(), native, git_proof)

    def declared(self) -> JsonObject:
        selected_ids = {s.cue.cue_id for s in self.selected}
        project_rows = [r for r in project_cues(self.project) if r["id"] not in selected_ids]
        media = [r for r in rows(self.timeline["entries"]) if object_row(r)["cue_id"] not in selected_ids]
        need(len(project_rows) == len(media) == 45, "R08-only unchanged45 cardinality")
        return {"schema": "xar.e04.r08.selected-render-inputs.v1", "machine_id": MACHINE,
            "state": "SOURCE_READY_RENDER_UNMATERIALIZED", "Root_review": REVIEW.wire(),
            "edited_source_freeze": FREEZE.wire(), "actual_voices": VOICES.wire(),
            "actual_image": IMAGE.wire(), "baseline": json_domain(self.plan.baseline.__dict__),
            "selected": [s.binding(self.tools) for s in self.selected],
            "unchanged45_project_sha256": hashlib.sha256(b"\n".join(canonical(r) for r in project_rows)).hexdigest(),
            "unchanged45_media_sha256": hashlib.sha256(b"\n".join(canonical(r) for r in media)).hexdigest(),
            "source_contains_no_render_output_pins": True, "complete_project": False,
            "readonly_Git_original_wait": self.readonly_git_proof,
            "later_R05_N03_02_actual_patch_required_for_final_three": True}


def read_baseline(plan: SourcePlan, repo: Path) -> tuple[JsonObject, JsonObject, JsonObject]:
    b = plan.baseline
    argv = ["git", "--no-lazy-fetch", "-C", str(repo), "show", b.commit + ":" + b.tracked_archive_path]
    process = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               creationflags=subprocess.CREATE_NO_WINDOW)
    created: str | None = None
    out = err = b""
    try:
        created = process_birth(process)
        out, err = process.communicate(timeout=30)
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                out, err = process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                out, err = process.communicate()
        code = process.wait()
    need(code == 0 and len(out) == b.archive_bytes and hashlib.sha256(out).hexdigest() == b.archive_sha256,
         "Finite read-only fixed Git archive")
    result: list[JsonObject] = []
    with tarfile.open(fileobj=io.BytesIO(out), mode="r:xz") as archive:
        for name, size, sha in [(b.project_member, b.project_bytes, b.project_sha256),
                                (b.timeline_member, b.timeline_bytes, b.timeline_sha256)]:
            member = archive.getmember(name)
            need(member.isfile() and member.size == size and size <= 131072, "Bounded ordinary source member")
            stream = archive.extractfile(member)
            need(stream is not None, "Source member stream")
            if stream is None:
                raise SourceError("Member stream narrowing")
            raw = stream.read()
            need(len(raw) == size and hashlib.sha256(raw).hexdigest() == sha, "Fixed source member pin")
            result.append(object_row(decode(raw)))
    proof: JsonObject = {"machine_id": MACHINE, "observed_at_utc": now(), "argv": [str(x) for x in argv],
        "pid": process.pid, "process_create_time_100ns": created, "actual_original_wait": True,
        "returncode": code, "archive_bytes": len(out), "archive_sha256": hashlib.sha256(out).hexdigest(),
        "stderr": err.decode("utf-8", "replace"), "fetch_or_mutation": False}
    return result[0], result[1], proof


def patch_id(value: JsonValue) -> PatchId:
    text = string(value)
    if text == "N06-08":
        return "N06-08"
    if text == "N06-05":
        return "N06-05"
    if text == "N03-02":
        return "N03-02"
    raise SourceError("Only explicit R08 two-cue / R05 one-cue adoption")


@dataclass(frozen=True)
class ActualPatch:
    cue_id: PatchId
    project_fields: JsonObject
    media_row: JsonObject

    @staticmethod
    def parse(value: JsonValue) -> ActualPatch:
        r = object_row(value, {"cue_id", "project_fields", "media_row"})
        key = patch_id(r["cue_id"])
        fields = object_row(r["project_fields"], {"id", "narration", "subtitles"})
        need(fields["id"] == key, "Actual patch source identity")
        narration = object_row(fields["narration"], {"zh-CN"})
        subtitles = object_row(fields["subtitles"], {"zh-CN", "en"})
        need(string(narration["zh-CN"]) == string(subtitles["zh-CN"]), "One actual voice/Chinese subtitle source")
        string(subtitles["en"])
        media = object_row(r["media_row"])
        need(media.get("cue_id") == key and integer(media["frames"]) > 0, "Actual media cue/frames")
        need(media.get("state") == "ACTUAL_RENDERED_CUE" and media.get("machine_id") == MACHINE,
             "An actual rendered patch is required")
        need(digest(media["project_fields_sha256"]) == hashlib.sha256(canonical(fields)).hexdigest(),
             "Actual media belongs to the selected source fields")
        FilePin.parse(media["voice"])
        RetainedAsset.parse(media["review_cas"])
        for name in ("subtitle", "actual_probe", "original_wait", "actual_encoder_progress"):
            FilePin.parse(media[name])
        digest(media["source_binding_sha256"])
        return ActualPatch(key, fields, media)

    def wire(self) -> JsonObject:
        return {"cue_id": self.cue_id, "project_fields": self.project_fields, "media_row": self.media_row}

    def verify(self) -> None:
        m = self.media_row
        frames = integer(m["frames"])
        asset = RetainedAsset.parse(m["review_cas"])
        asset.verify_identity()
        data = asset.media.verify(MOVIE_MAX)
        need(len(data) >= 12 and data[4:8] == b"ftyp", "Actual MP4 container")
        FilePin.parse(m["voice"]).verify(524288)
        FilePin.parse(m["subtitle"]).verify(131072)
        progress = FilePin.parse(m["actual_encoder_progress"]).verify(262144).decode("utf-8")
        counts = re.findall(r"^frame=([0-9]+)\s*$", progress, re.MULTILINE)
        need(bool(counts) and int(counts[-1]) == frames and
             re.search(r"^progress=end\s*$", progress, re.MULTILINE) is not None, "Actual complete encoder progress")
        wait = object_row(decode(FilePin.parse(m["original_wait"]).verify(32768)))
        custody = object_row(wait["custody"])
        need(wait.get("machine_id") == MACHINE and wait.get("actual_original_wait") is True
             and wait.get("kind") == "encoder" and integer(custody["original_wait"]) == 0
             and integer(custody["job_active_processes"]) == 0 and custody.get("job_closed") is True,
             "Actual original encoder wait and Job closure")
        probe = object_row(decode(FilePin.parse(m["actual_probe"]).verify(32768)))
        need(probe.get("schema") == "xar.e04.selected-render-probe.v1"
             and probe.get("machine_id") == MACHINE and probe.get("actual_decode_count_frames") is True
             and integer(probe["actual_original_wait"]) == 0 and integer(probe["expected_frames"]) == frames,
             "Actual decode/count probe receipt")
        measured = FilePin.parse(probe["media"])
        need((measured.bytes, measured.sha256) == (asset.media.bytes, asset.media.sha256), "Probe/CAS exact bytes")
        validate_encoded_probe(object_row(probe["observed"]), frames)


def validate_encoded_probe(observed: JsonObject, expected_frames: int) -> None:
    need(type(expected_frames) is int and expected_frames > 0, "Exact positive frame count")
    streams = [object_row(v) for v in rows(observed["streams"])]
    videos = [r for r in streams if r.get("codec_type") == "video"]
    audios = [r for r in streams if r.get("codec_type") == "audio"]
    need(len(videos) == len(audios) == 1 and len(streams) == 2, "One actual video and audio stream")
    v, a = videos[0], audios[0]
    need(v.get("codec_name") == "h264" and v.get("pix_fmt") == "yuv420p"
         and integer(v["width"]) == 1920 and integer(v["height"]) == 1080
         and v.get("r_frame_rate") == "30/1" and int(decimal64(v["nb_read_frames"])) == expected_frames
         and v.get("time_base") == "1/15360" and integer(v["duration_ts"]) == expected_frames * 512,
         "Actual fully decoded frame clock/geometry")
    need(a.get("codec_name") == "aac" and a.get("sample_rate") == "48000" and integer(a["channels"]) == 2,
         "Actual AAC48k stereo")
    actual_duration = Decimal(string(object_row(observed["format"])["duration"]))
    target = Decimal(expected_frames) / 30
    need(actual_duration.is_finite() and target - Decimal(".05") <= actual_duration <= target + Decimal(".10"),
         "Actual encoded duration matches the frame clock")


def merge_actual_patches(project: JsonObject, timeline: JsonObject,
                         patches: tuple[ActualPatch, ...], *, final_three: bool) -> JsonObject:
    for patch in patches:
        patch.verify()
    return _merge_metadata(project, timeline, patches, final_three=final_three)


def _merge_metadata(project: JsonObject, timeline: JsonObject,
                    patches: tuple[ActualPatch, ...], *, final_three: bool) -> JsonObject:
    """Pure adoption; original source rows remain intact, derived placements are separate."""
    expected = {"N06-08", "N06-05", "N03-02"} if final_three else {"N06-08", "N06-05"}
    need(len(patches) == len(expected) and {p.cue_id for p in patches} == expected,
         "Exact actual patch set; final assembly requires the real R05 patch")
    current = copy.deepcopy(project)
    previous = project_cues(project)
    updated = project_cues(current)
    media_rows = [object_row(r) for r in rows(timeline["entries"])]
    need(len(previous) == len(media_rows) == 47, "Complete original47 reference")
    by: dict[str, ActualPatch] = {p.cue_id: p for p in patches}
    result_rows: list[JsonValue] = []
    placements: list[JsonValue] = []
    cursor = 0
    for old, new, original_media in zip(previous, updated, media_rows, strict=True):
        key = string(old["id"])
        need(key == original_media["cue_id"], "Original project/media order")
        patch = by.get(key)
        if patch is None:
            need(canonical(old) == canonical(new), "Untouched source bytes")
            actual_row = original_media
        else:
            need(set(new) == set(patch.project_fields), "Adopted cue fields shape")
            new.update(patch.project_fields)
            actual_row = patch.media_row
        result_rows.append(actual_row)
        frames = integer(actual_row["frames"])
        placements.append({"cue_id": key, "start_frame": cursor, "frames": frames})
        cursor += frames
    unchanged = 47 - len(expected)
    need(sum(canonical(a) == canonical(b) for a, b in zip(previous, updated, strict=True)) >= unchanged,
         "Preserve original44/45 source fields")
    return {"schema": "xar.e04.explicit-three-cue-adoption.v1", "machine_id": MACHINE,
        "state": "ADOPTED_METADATA_ONLY_NO_FULL_MOVIE", "project": current,
        "source_media_rows": result_rows, "derived_placements": placements,
        "changed_cue_ids": [str(key) for key in sorted(expected)], "unchanged_cue_count": unchanged,
        "original_source_media_rows_preserved_byteexact": True,
        "derived_placements_do_not_overwrite_original_rows": True,
        "full_movie_produced": False}
