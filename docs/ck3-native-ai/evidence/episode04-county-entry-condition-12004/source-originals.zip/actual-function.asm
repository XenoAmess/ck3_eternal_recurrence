; machine_id: desktop-3fevhd2-1c74096080
; actual1.20.0.4 98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518
024E2230 48 89 5c 24 08                   mov      qword ptr [rsp + 8], rbx
024E2235 48 89 6c 24 10                   mov      qword ptr [rsp + 0x10], rbp
024E223A 48 89 74 24 18                   mov      qword ptr [rsp + 0x18], rsi
024E223F 48 89 7c 24 20                   mov      qword ptr [rsp + 0x20], rdi
024E2244 41 56                            push     r14
024E2246 48 83 ec 20                      sub      rsp, 0x20
024E224A 48 8b 42 08                      mov      rax, qword ptr [rdx + 8]
024E224E 41 8b f1                         mov      esi, r9d
024E2251 4d 8b f0                         mov      r14, r8
024E2254 48 8b e9                         mov      rbp, rcx
024E2257 80 78 1b 00                      cmp      byte ptr [rax + 0x1b], 0
024E225B 0f 84 56 01 00 00                je       0x24e23b7
024E2261 49 8b 40 08                      mov      rax, qword ptr [r8 + 8]
024E2265 80 78 1b 00                      cmp      byte ptr [rax + 0x1b], 0
024E2269 0f 84 48 01 00 00                je       0x24e23b7
024E226F 49 8b b8 48 08 00 00             mov      rdi, qword ptr [r8 + 0x848]
024E2276 48 8b 9a 48 08 00 00             mov      rbx, qword ptr [rdx + 0x848]
024E227D 48 3b df                         cmp      rbx, rdi
024E2280 0f 84 31 01 00 00                je       0x24e23b7
024E2286 48 85 db                         test     rbx, rbx
024E2289 0f 84 28 01 00 00                je       0x24e23b7
024E228F 45 85 c9                         test     r9d, r9d
024E2292 75 17                            jne      0x24e22ab
024E2294 e8 e7 da 3d 00                   call     0x28bfd80
024E2299 48 8b 8b c8 03 00 00             mov      rcx, qword ptr [rbx + 0x3c8]
024E22A0 8b 40 18                         mov      eax, dword ptr [rax + 0x18]
024E22A3 39 41 30                         cmp      dword ptr [rcx + 0x30], eax
024E22A6 0f 95 c0                         setne    al
024E22A9 eb 08                            jmp      0x24e22b3
024E22AB 48 8b d3                         mov      rdx, rbx
024E22AE e8 3d 7b 72 00                   call     0x2c09df0
024E22B3 84 c0                            test     al, al
024E22B5 0f 84 fc 00 00 00                je       0x24e23b7
024E22BB 49 8b 9e 48 08 00 00             mov      rbx, qword ptr [r14 + 0x848]
024E22C2 48 85 db                         test     rbx, rbx
024E22C5 0f 84 ec 00 00 00                je       0x24e23b7
024E22CB 48 8b cd                         mov      rcx, rbp
024E22CE 85 f6                            test     esi, esi
024E22D0 75 17                            jne      0x24e22e9
024E22D2 e8 a9 da 3d 00                   call     0x28bfd80
024E22D7 48 8b 8b c8 03 00 00             mov      rcx, qword ptr [rbx + 0x3c8]
024E22DE 8b 40 18                         mov      eax, dword ptr [rax + 0x18]
024E22E1 39 41 30                         cmp      dword ptr [rcx + 0x30], eax
024E22E4 0f 95 c0                         setne    al
024E22E7 eb 08                            jmp      0x24e22f1
024E22E9 48 8b d3                         mov      rdx, rbx
024E22EC e8 ff 7a 72 00                   call     0x2c09df0
024E22F1 84 c0                            test     al, al
024E22F3 0f 84 be 00 00 00                je       0x24e23b7
024E22F9 81 bf e0 03 00 00 61 44 6f 43    cmp      dword ptr [rdi + 0x3e0], 0x436f4461
024E2303 0f 85 ae 00 00 00                jne      0x24e23b7
024E2309 80 bf 88 00 00 00 00             cmp      byte ptr [rdi + 0x88], 0
024E2310 75 27                            jne      0x24e2339
024E2312 80 bf 8a 00 00 00 00             cmp      byte ptr [rdi + 0x8a], 0
024E2319 75 1e                            jne      0x24e2339
024E231B 85 f6                            test     esi, esi
024E231D 75 1e                            jne      0x24e233d
024E231F 48 8b cd                         mov      rcx, rbp
024E2322 e8 59 da 3d 00                   call     0x28bfd80
024E2327 48 8b 8f c8 03 00 00             mov      rcx, qword ptr [rdi + 0x3c8]
024E232E 8b 40 18                         mov      eax, dword ptr [rax + 0x18]
024E2331 39 41 30                         cmp      dword ptr [rcx + 0x30], eax
024E2334 0f 95 c0                         setne    al
024E2337 eb 0f                            jmp      0x24e2348
024E2339 85 f6                            test     esi, esi
024E233B 74 7a                            je       0x24e23b7
024E233D 48 8b d7                         mov      rdx, rdi
024E2340 48 8b cd                         mov      rcx, rbp
024E2343 e8 a8 7a 72 00                   call     0x2c09df0
024E2348 84 c0                            test     al, al
024E234A 74 6b                            je       0x24e23b7
024E234C 48 8b 5f 40                      mov      rbx, qword ptr [rdi + 0x40]
024E2350 48 63 47 4c                      movsxd   rax, dword ptr [rdi + 0x4c]
024E2354 4c 8d 34 c3                      lea      r14, [rbx + rax*8]
024E2358 49 3b de                         cmp      rbx, r14
024E235B 74 56                            je       0x24e23b3
024E235D 0f 1f 00                         nop      dword ptr [rax]
024E2360 48 8b 3b                         mov      rdi, qword ptr [rbx]
024E2363 85 f6                            test     esi, esi
024E2365 75 23                            jne      0x24e238a
024E2367 48 85 ff                         test     rdi, rdi
024E236A 75 04                            jne      0x24e2370
024E236C b0 01                            mov      al, 1
024E236E eb 36                            jmp      0x24e23a6
024E2370 48 8b cd                         mov      rcx, rbp
024E2373 e8 08 da 3d 00                   call     0x28bfd80
024E2378 48 8b 8f c8 03 00 00             mov      rcx, qword ptr [rdi + 0x3c8]
024E237F 8b 40 18                         mov      eax, dword ptr [rax + 0x18]
024E2382 39 41 30                         cmp      dword ptr [rcx + 0x30], eax
024E2385 0f 94 c0                         sete     al
024E2388 eb 1c                            jmp      0x24e23a6
024E238A 48 85 ff                         test     rdi, rdi
024E238D 75 04                            jne      0x24e2393
024E238F 32 c0                            xor      al, al
024E2391 eb 13                            jmp      0x24e23a6
024E2393 48 8b cf                         mov      rcx, rdi
024E2396 e8 35 2b ff ff                   call     0x24d4ed0
024E239B 48 8b d0                         mov      rdx, rax
024E239E 48 8b cd                         mov      rcx, rbp
024E23A1 e8 4a 74 72 00                   call     0x2c097f0
024E23A6 84 c0                            test     al, al
024E23A8 75 0d                            jne      0x24e23b7
024E23AA 48 83 c3 08                      add      rbx, 8
024E23AE 49 3b de                         cmp      rbx, r14
024E23B1 75 ad                            jne      0x24e2360
024E23B3 b0 01                            mov      al, 1
024E23B5 eb 02                            jmp      0x24e23b9
024E23B7 32 c0                            xor      al, al
024E23B9 48 8b 5c 24 30                   mov      rbx, qword ptr [rsp + 0x30]
024E23BE 48 8b 6c 24 38                   mov      rbp, qword ptr [rsp + 0x38]
024E23C3 48 8b 74 24 40                   mov      rsi, qword ptr [rsp + 0x40]
024E23C8 48 8b 7c 24 48                   mov      rdi, qword ptr [rsp + 0x48]
024E23CD 48 83 c4 20                      add      rsp, 0x20
024E23D1 41 5e                            pop      r14
024E23D3 c3                               ret      
