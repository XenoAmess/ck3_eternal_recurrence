"""Shared finite clock-diagnostic card, with execution evidence in separate receipts."""
from typing import Literal, TypedDict

class Pin(TypedDict):
    path: str
    bytes: int
    sha256: str

class ClockDiagnosticCardDocument(TypedDict):
    schema: Literal["xar.capacity.e04.full-working-review-clock-diagnostic.v1"]
    machine_id: str
    owner: Literal["/root/fullreview"]
    admitted: Literal[True]
    budget_status: Literal["GREEN"]
    exact_root: str
    maximum_new_C_allocated_bytes: Literal[16777216]
    maximum_new_D_allocated_bytes: Literal[0]
    hard_deadline_utc: str
    Root_independent_purpose: Pin
    diagnostic_source_freeze: Pin

CLOCK_SCHEMA = "xar.capacity.e04.full-working-review-clock-diagnostic.v1"
CLOCK_FIELDS: frozenset[str] = ClockDiagnosticCardDocument.__required_keys__
