"""Shared pure-stdlib successor source admission fields."""
from typing import Literal, TypedDict

SOURCE_SCHEMA = "xar.capacity.e04.full-working-review-source-successor.v1"


class PinDocument(TypedDict):
    path: str
    bytes: int
    sha256: str


class SourceSuccessorCardDocument(TypedDict):
    schema: Literal["xar.capacity.e04.full-working-review-source-successor.v1"]
    machine_id: Literal["desktop-3fevhd2-1c74096080"]
    owner: Literal["/root/fullreview"]
    admitted: Literal[True]
    budget_status: Literal["GREEN"]
    exact_root: str
    maximum_new_C_allocated_bytes: Literal[524288]
    maximum_new_D_allocated_bytes: Literal[0]
    hard_deadline_utc: Literal["2026-10-23T00:30:00Z"]
    Root_independent_purpose: PinDocument
    Root_scope_amendment: str


SOURCE_FIELDS = frozenset(SourceSuccessorCardDocument.__required_keys__)
