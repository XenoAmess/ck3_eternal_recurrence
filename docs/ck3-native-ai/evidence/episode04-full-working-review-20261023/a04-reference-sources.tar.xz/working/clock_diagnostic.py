"""One admitted readonly four-cue concat using the production clock/audio consumers."""
from __future__ import annotations

from dataclasses import dataclass, replace
import datetime as dt
import json
from pathlib import Path
import sys

from working_contract import (
    BASE, SOURCE, MACHINE, DEADLINE_TEXT, SOURCE_DEADLINE, CombinedBudget,
    FilePin, JsonObject, JsonValue, Resources, WorkingCue, WorkingOwner,
    canonical, decode, integer, json_domain, need, now, object_row, pin, rows,
    string, utc, validate_encoded_probe,
)
from working_recipe import prepare
from produce_working_review import (
    Product, Request, SOURCE_NAMES, actual_probe, movie_plan, packet_audit, audio_audit,
)
from produce_final47 import custody_good

CLOCK_FIELDS_PIN = FilePin(str(BASE/'capacity/clock_diagnostic_fields.py'),811,
    'c008b7aa2ca350fb9a3173f06d7130c1e1eebfea5c7aff6ddd69fbc2fd813b5d')
CLOCK_FIELDS_PIN.verify(4096)
sys.path.insert(0,str(BASE/'capacity'))
from clock_diagnostic_fields import CLOCK_FIELDS, CLOCK_SCHEMA as CLOCK_SCHEMA

DIAGNOSTIC_ROOT = BASE/'fullreview-clock-diagnostic-a01'
DIAGNOSTIC_LIMIT = 16*1048576
DIAGNOSTIC_MOVIE_CAP = 8*1048576
RETAINED_ROOT = BASE/'fullreview-media-a03'
ROOT_PURPOSE = FilePin(str(BASE/'root/ROOT-FULLREVIEW-CLOCK-DIAGNOSTIC-PURPOSE.actual-a01.json'),
    1072,'f3726cf575305dca508cfc4bf6cdfecddb848abf498511ec8e2d878fcf877120')
PRODUCT_PINS = (
    FilePin(str(RETAINED_ROOT/'products/BRAND.actual.json'),1737,
        '3bf82c99bd93f42050ae7ba66200c912d7802afc7fb2a1835f4c61a725e7a14e'),
    FilePin(str(RETAINED_ROOT/'products/C01-01.actual.json'),2893,
        '06439ca6e846d2de81c770284d0441bf9a266d5ae2520e3cc67ab3171562aa22'),
    FilePin(str(RETAINED_ROOT/'products/CHAPTER01.actual.json'),1704,
        '3fd57ee2a16230b1b69aa955881926e8877b76a6ec0bf3025a0de50a59d69346'),
    FilePin(str(RETAINED_ROOT/'products/END.actual.json'),1694,
        '5606d7b42a9d41ebce1a94877124a06e72fcc80dd30b5c1a0decfc92008de370'),
)
OLD_CLOSURE = FilePin(str(RETAINED_ROOT/'EXECUTOR-OWNER-CLOSED.actual.json'),3576,
    'acab76aa19ac5ca9b465e7837562615a40631ec8a741c80625e937696c9f9c7e')


def validate_card(value: JsonValue) -> JsonObject:
    r=object_row(value,set(CLOCK_FIELDS))
    need(r['schema']==CLOCK_SCHEMA and r['machine_id']==MACHINE
         and r['owner']=='/root/fullreview' and r['admitted'] is True
         and r['budget_status']=='GREEN' and Path(string(r['exact_root']))==DIAGNOSTIC_ROOT
         and integer(r['maximum_new_C_allocated_bytes'])==DIAGNOSTIC_LIMIT
         and integer(r['maximum_new_D_allocated_bytes'])==0
         and r['hard_deadline_utc']==DEADLINE_TEXT
         and FilePin.parse(r['Root_independent_purpose'])==ROOT_PURPOSE,
         'Exact single-purpose current clock admission')
    freeze=FilePin.parse(r['diagnostic_source_freeze'])
    need(Path(freeze.path)==SOURCE/'SOURCE-FREEZE.actual.json','Exact frozen a04 clock source')
    return r


def validate_wait(ref: FilePin) -> None:
    r=object_row(decode(ref.verify(32768)))
    need(r['schema']=='xar.e04.final47.original-wait.v1' and r['machine_id']==MACHINE
         and r['actual_original_Popen'] is True and r['actual_original_wait'] is True
         and r['protocol_prefix_only'] is False and r['owner_error'] is None
         and custody_good(object_row(r['custody'])), 'Retained actual original Popen wait0/Job0')
    for name in ('stdout','stderr'):
        FilePin.parse(r[name]).verify(262144)


def retained_products(resources: Resources) -> tuple[Product,...]:
    """Consume real prior producers without treating their failed smoke as accepted."""
    closed=object_row(decode(OLD_CLOSURE.verify(8192)))
    need(closed['machine_id']==MACHINE and closed['failed'] is True
         and integer(closed['owned_Popen_remaining'])==0
         and closed['all_original_children_wait0_Job0'] is True
         and all(integer(v)==0 for v in rows(closed['actual_original_waits']))
         and all(custody_good(object_row(c)) for c in rows(closed['actual_custodies'])),
         'Retained a03 failure remains a failure with original closed children')
    cues={c.cue_id:c for c in prepare(resources)}
    result: list[Product]=[]
    for ref,expected in zip(PRODUCT_PINS,('BRAND','C01-01','CHAPTER01','END'),strict=True):
        r=object_row(decode(ref.verify(8192)),{'cue','start_frame','end_frame','work','native_CAS',
            'actual_encode_original_wait','actual_decode_probe'})
        cue=cues[expected]
        wire=object_row(r['cue'],{'cue_id','kind','frames','evidence','ASS_sha256','output'})
        work=FilePin.parse(r['work']);native=FilePin.parse(r['native_CAS'])
        need(Path(work.path)==RETAINED_ROOT/'work'/(expected+'.mp4')
             and Path(native.path)==RETAINED_ROOT/'native/derived/sha256'/work.sha256[:2]/(work.sha256+'.mp4')
             and integer(r['start_frame'])==0 and integer(r['end_frame'])==cue.frames
             and integer(wire['frames'])==cue.frames
             and canonical(wire)==canonical({**cue.wire(),'output':work.path}),
             'Exact real four-cue producer JSON and original source/ASS bindings')
        work.verify(18*1048576);native.verify(18*1048576)
        a=Path(work.path).stat(follow_symlinks=False);b=Path(native.path).stat(follow_symlinks=False)
        need((work.bytes,work.sha256)==(native.bytes,native.sha256)
             and not (a.st_file_attributes|b.st_file_attributes)&0x400
             and a.st_dev>0 and a.st_ino>0 and (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino)
             and a.st_nlink==b.st_nlink==2,'Exact readonly two-name ordinary retained media identity')
        waited=FilePin.parse(r['actual_encode_original_wait']);validate_wait(waited)
        probe=FilePin.parse(r['actual_decode_probe']);p=object_row(decode(probe.verify(8192)))
        need(p['machine_id']==MACHINE and p['actual_full_decode'] is True
             and integer(p['expected_frames'])==cue.frames and FilePin.parse(p['media'])==work,
             'Retained actual full-frame decode')
        observed=object_row(p['observed']);validate_encoded_probe(observed,cue.frames)
        video=next(object_row(v) for v in rows(observed['streams']) if object_row(v).get('codec_type')=='video')
        need(video['pix_fmt']=='yuv420p' and video['color_range']=='tv'
             and video['color_space']==video['color_transfer']==video['color_primaries']=='bt709',
             'Retained actual limited BT709 output')
        validate_wait(FilePin.parse(p['original_wait']))
        # Only the frame count and source media are used by shared movie_plan.
        oldcue=replace(cue,plan=replace(cue.plan,final_output=Path(work.path)))
        result.append(Product(oldcue,work,native,waited,probe))
    need(sum(p.cue.frames for p in result)==1182,'Exact 39.4-second finite diagnostic')
    return tuple(result)


@dataclass(frozen=True)
class DiagnosticAdmission:
    card: FilePin
    freeze: FilePin
    budget: CombinedBudget

    @staticmethod
    def parse(card: FilePin) -> DiagnosticAdmission:
        r=validate_card(decode(card.verify(8192)))
        purpose=object_row(decode(ROOT_PURPOSE.verify(8192)))
        need(purpose['schema']=='xar.root.e04.full-working-review-clock-diagnostic-purpose.v1'
             and purpose['machine_id']==MACHINE and purpose['author']=='/root'
             and purpose['owner']=='/root/fullreview' and purpose['onedrive_write'] is False
             and purpose['Game_SDK_Film'] is False and purpose['human1x'] is False
             and purpose['signoff'] is False and purpose['preserve_source_and_old_failures'] is True,
             'Actual Root clock-only scope')
        for name in ('exact_root','maximum_new_C_allocated_bytes','maximum_new_D_allocated_bytes','hard_deadline_utc'):
            need(canonical(purpose[name])==canonical(r[name]),'Exact Root/CAP diagnostic scope')
        FilePin.parse(purpose['Root_source_scope']).verify(8192)
        freeze=FilePin.parse(r['diagnostic_source_freeze']);f=object_row(decode(freeze.verify(65536)))
        need(f['schema']=='xar.e04.full-working-review.source-freeze.v1' and f['machine_id']==MACHINE,
             'Actual a04 checked source freeze')
        actual_sources=tuple(FilePin.parse(v) for v in rows(f['source_pins']))
        need({Path(p.path).name for p in actual_sources}==set(SOURCE_NAMES)
             and all(Path(p.path).parent==SOURCE for p in actual_sources),'Exact six frozen diagnostic/production sources')
        for ref in (*actual_sources,*(FilePin.parse(v) for v in rows(f['input_pins']))):
            ref.verify(1048576)
        for name in ('focused_original_wait','strict_original_wait'):
            waited=object_row(decode(FilePin.parse(f[name]).verify(16384)))
            need(waited['machine_id']==MACHINE and waited['actual_original_Popen'] is True
                 and integer(waited['original_wait'])==0 and waited['timed_out'] is False,
                 'Actual focused/strict original source wait0')
        need(dt.datetime.now(dt.UTC)<utc(r['hard_deadline_utc']) and not DIAGNOSTIC_ROOT.exists(),
             'Fresh create-only finite diagnostic root')
        return DiagnosticAdmission(card,freeze,CombinedBudget(DIAGNOSTIC_ROOT,SOURCE_DEADLINE,DIAGNOSTIC_LIMIT))


class DiagnosticRequest(Request):
    def validate(self) -> None:
        if self.operation=='movie_concat':
            need(type(self.timeout) is type(self.output_cap) is int
                 and self.timeout==600 and self.output_cap==DIAGNOSTIC_MOVIE_CAP,
                 'Single finite 8MiB concat under actual 16MiB clock admission')
        else:
            super().validate()


def execute(card: FilePin) -> FilePin:
    admission=DiagnosticAdmission.parse(card);budget=admission.budget
    resources=Resources.load();products=retained_products(resources)
    budget.guard(DIAGNOSTIC_ROOT/'temp/reserve',8192)
    (DIAGNOSTIC_ROOT/'temp').mkdir(parents=True,exist_ok=False)
    budget.json('EXECUTOR-ONCE.actual.json',{'machine_id':MACHINE,'observed_at_utc':now(),
        'financial_card':card.wire(),'Root_purpose':ROOT_PURPOSE.wire(),'source_freeze':admission.freeze.wire(),
        'readonly_input_products':[p.wire() for p in PRODUCT_PINS],
        'included_in_formal62_timeline':False,'onedrive_write':False,'Game_SDK_Film':False})
    owner=WorkingOwner(budget,resources);failure: str|None=None
    try:
        owner.idle()
        plan=movie_plan(owner,products,key='first4-smoke',output_cap=DIAGNOSTIC_MOVIE_CAP)
        result=owner.render(plan,DiagnosticRequest('movie_concat','first4-smoke',600,DIAGNOSTIC_MOVIE_CAP))
        movie=pin(plan.final_output)
        probe=actual_probe(owner,movie,1182,'first4-smoke',movie=True)
        clocks=packet_audit(owner,movie,1182,key='first4-smoke')
        audio=audio_audit(owner,movie,key='first4-smoke')
        return budget.json('DIAGNOSTIC-ACTUAL.json',{'machine_id':MACHINE,'observed_at_utc':now(),
            'source_freeze':admission.freeze.wire(),'movie':movie.wire(),'total_frames':1182,
            'shared_production_movie_plan':True,'copyts':True,'avoid_negative_ts':'disabled',
            'actual_concat_original_wait':result.wait_pin.wire(),'actual_full_decode':probe.wire(),
            'actual_all_packet_clocks':clocks.wire(),'actual_full_audio_statistics':audio.wire(),
            'actual_input_products':[p.wire(0) for p in products],
            'included_in_formal62_timeline':False,'onedrive_write':False,'human1x':False,'signoff':False})
    except BaseException as error:
        failure=type(error).__name__+': '+str(error)[:2500]
        budget.json('FAILED-PRESERVED.actual.json',{'machine_id':MACHINE,'observed_at_utc':now(),
            'diagnostic':failure,'partials_retained':True,'no_retry':True})
        raise
    finally:
        budget.json('EXECUTOR-OWNER-CLOSED.actual.json',{'machine_id':MACHINE,'observed_at_utc':now(),
            'failed':failure is not None,'owner_error':failure,'owned_Popen_remaining':owner.children,
            'actual_original_waits':json_domain(owner.codes),'actual_custodies':owner.custodies,
            'all_original_children_wait0_Job0':bool(owner.custodies) and all(custody_good(object_row(c)) for c in owner.custodies),
            'native_allocation_before_receipt':budget.snapshot(),'human1x':False,'signoff':False})


def main() -> None:
    need(len(sys.argv)==4 and sys.argv[1]=='execute','Exactly one admitted clock diagnostic execution')
    card=pin(Path(sys.argv[2]));need(card.sha256==sys.argv[3],'Exact actual clock card SHA')
    print(json.dumps(execute(card).wire(),ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
