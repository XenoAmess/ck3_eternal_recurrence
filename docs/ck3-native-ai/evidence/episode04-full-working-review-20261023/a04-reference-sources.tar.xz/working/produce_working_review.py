"""Actual complete review production, finite children, one music bed, exact output copy."""
from __future__ import annotations

from dataclasses import dataclass, replace
import csv
import datetime as dt
import math
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
from typing import Literal
from working_contract import (
    SOURCE, MEDIA, ONEDRIVE, SOURCE_LIMIT, SOURCE_DEADLINE, LIMIT, CUE_TOTAL_MAX,
    FULL_MAX, ENVIRONMENT, PENDING, FONT_PIN, MACHINE, FilePin, JsonObject, JsonValue,
    Resources, WorkingCue, MediaAdmission, WorkingOwner, CombinedBudget, Budget, RetainedAsset,
    canonical, decode, integer, json_domain, need, now, object_row, pin, rows, string,
    consume_cue, source_budget, validate_encoded_probe, link_new_output,
    SOURCE_FIELDS_PIN, PREDECESSOR, SourceError,
)
from working_recipe import EDITORIAL, STRUCTURE, DYNAMIC, VOICE_PROBES, prepare
from produce_final47 import Request as OriginalRequest, custody_good
from executor_contract import process_birth, CUE_MAX
from xar_promo.process import CommandSpec
from xar_promo.render import RenderPlan, GeneratedTextFile, plan_concat
from PIL import Image, ImageDraw

SOURCE_NAMES=('working_fields.py','working_contract.py','working_recipe.py','produce_working_review.py','check_working_review.py','clock_diagnostic.py')
META_MAX=32*1048576


class Request(OriginalRequest):
    def validate(self) -> None:
        if self.operation in ('movie_concat','movie_decode_probe'):
            need(type(self.timeout) is type(self.output_cap) is int and self.timeout==600
                 and self.output_cap==(FULL_MAX if self.operation=='movie_concat' else 0),
                 'Finite actual full-movie policy600s, no retry, same original Job custody')
        else:
            super().validate()


def native_regression(budget: Budget,attempt: str) -> FilePin:
    base=SOURCE/('native-identity-'+attempt)
    body=b'windows-native-identity\n'*400
    first=budget.write(str((base/'work/probe.bin').relative_to(SOURCE)),body)
    alias=base/'cas/probe.bin'
    budget.guard(alias,0);alias.parent.mkdir(parents=True,exist_ok=True)
    os.link(first.path,alias)
    left=Path(first.path).stat(follow_symlinks=False);right=alias.stat(follow_symlinks=False)
    need(left.st_dev>0 and left.st_ino>0 and left.st_nlink==right.st_nlink==2
         and (left.st_dev,left.st_ino)==(right.st_dev,right.st_ino),
         'Real Windows two-name hardlink identity')
    first.verify(16384);second=pin(alias)
    need((first.bytes,first.sha256)==(second.bytes,second.sha256),'Actual two-name exact bytes/SHA')
    actual=CombinedBudget(base,SOURCE_DEADLINE,SOURCE_LIMIT).snapshot()
    need(integer(actual['unique_files'])==1 and integer(actual['hardlink_aliases'])==1
         and integer(actual['logical_bytes'])==2*len(body)
         and integer(actual['allocated_bytes'])>0,'Real complete Native hardlink allocation counted once')
    rejected=False
    try:
        CombinedBudget(base,SOURCE_DEADLINE,8192).guard(base/'underfunded.bin',8193)
    except SourceError:
        rejected=True
    need(rejected,'Real existing Native allocation plus proposed output cap fails underfunded guard')
    return budget.json('NATIVE-IDENTITY-REGRESSION.'+attempt+'.actual.json',
        {'schema':'xar.e04.full-working-review.native-identity-regression.v1','machine_id':MACHINE,
         'observed_at_utc':now(),'first':first.wire(),'second':second.wire(),
         'identity':{'st_dev':str(left.st_dev),'st_ino':str(left.st_ino),'mtime_ns':str(left.st_mtime_ns),
                     'links':left.st_nlink},'actual_snapshot':actual,
         'actual_two_aliases_one_file':True,'underfunded_guard_rejected':True,'media_executed':False})


def checked_child(budget: Budget,key: str,argv: tuple[str,...],env: dict[str,str]) -> FilePin:
    budget.guard(SOURCE/'checks'/key/'reserve',262144)
    proc: subprocess.Popen[bytes]=subprocess.Popen(argv,cwd=SOURCE,env=env,stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
    created=process_birth(proc)
    timed_out=False
    try:
        out,err=proc.communicate(timeout=120)
    except subprocess.TimeoutExpired:
        timed_out=True;proc.kill();out,err=proc.communicate(timeout=15)
    code=proc.wait(timeout=15)
    need(len(out)+len(err)<=131072,'Bounded complete source check protocol')
    stdout=budget.write(f'checks/{key}/stdout.txt',out)
    stderr=budget.write(f'checks/{key}/stderr.txt',err)
    receipt=budget.json(f'checks/{key}/ORIGINAL-WAIT.actual.json',
        {'machine_id':MACHINE,'observed_at_utc':now(),'argv':list(argv),'pid':proc.pid,
         'process_create_time_100ns':created,'actual_original_Popen':True,'original_wait':code,
         'timed_out':timed_out,'stdout':stdout.wire(),'stderr':stderr.wire()})
    need(code==0 and not timed_out,'Actual source check failed; original receipt retained: '+receipt.path)
    return receipt


def source_check(attempt: str) -> FilePin:
    from clock_diagnostic import CLOCK_FIELDS_PIN, ROOT_PURPOSE, PRODUCT_PINS, OLD_CLOSURE
    need(re.fullmatch(r'a[0-9]{2}',attempt) is not None,'Finite unique source attempt before writes')
    budget=source_budget()
    need(not (SOURCE/'SOURCE-FREEZE.actual.json').exists(),'Create-only source freeze')
    native=native_regression(budget,attempt)
    env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
    env['TEMP']=env['TMP']=str(SOURCE/'temp')
    budget.guard(SOURCE/'temp/reserve',8192);(SOURCE/'temp').mkdir(exist_ok=True)
    env['PYTHONPATH']=str(SOURCE)
    need(re.fullmatch(r'a[0-9]{2}',attempt) is not None,'Finite unique source attempt')
    focused=checked_child(budget,attempt+'/focused',(sys.executable,'-B','-X','utf8',str(SOURCE/'check_working_review.py'),attempt),env)
    strict_env=dict(env)
    strict_env['PYTHONPATH']=os.pathsep.join((
        'C:/ck3-e04-resume-20261020-a01/r08-mypy1201-tools-2115-a01/Lib',str(SOURCE)))
    strict_env['MYPYPATH']=os.pathsep.join((str(SOURCE),str(SOURCE.parent/'capacity'),
        'C:/ck3-e04-resume-20261022-b01/final47-executor-source-a01',
        'C:/ck3-e04-resume-20261022-b01/final47-source-a01',
        'C:/ck3-e04-resume-20261022-b01/r08-selected-render-source-a01',
        'C:/ck3-e04-resume-20261022-b01/r08-audio-raster-a01',
        'C:/ck3-e04-resume-20261022-b01/r08-edit-source-a01',
        'C:/ck3-e04-resume-20261022-b01/root/subtitles',
        'C:/ck3-e04-resume-20261020-a01/r22-mechanics-render-a01',
        'C:/ck3-e04-resume-20261020-a01/r17-b-firstclip-qa-a01'))
    strict=checked_child(budget,attempt+'/strict',(sys.executable,'-B','-X','utf8','-m','mypy','--strict',
        '--follow-imports=silent','--follow-untyped-imports','--cache-dir=nul',*(str(SOURCE/name) for name in SOURCE_NAMES)),strict_env)
    resources=Resources.load();cues=prepare(resources)
    predecessor=object_row(decode(PREDECESSOR.verify(65536)))
    assets=tuple(FilePin.parse(v) for v in rows(predecessor['asset_pins']))
    summary: JsonObject={'schema':'xar.e04.full-working-review.recipe.v1','machine_id':MACHINE,
        'fps':30,'total_frames':sum(c.frames for c in cues),'total_cues':len(cues),
        'all47_mechanics_new_encodes':True,'R05_actual_acceptance':None,
        'R05_business_qualified':False,'single_continuous_music_bed':True,
        'cues':[c.wire() for c in cues],'review_only':True,'human1x':False,'signoff':False}
    recipe=budget.json('FULL-WORKING-REVIEW-RECIPE.source.json',summary)
    freeze=budget.json('SOURCE-FREEZE.actual.json',
        {'schema':'xar.e04.full-working-review.source-freeze.v1','machine_id':MACHINE,
         'observed_at_utc':now(),'source_pins':[pin(SOURCE/name).wire() for name in SOURCE_NAMES],
         'input_pins':[p.wire() for p in (PENDING,EDITORIAL,STRUCTURE,DYNAMIC,VOICE_PROBES,ENVIRONMENT,recipe,
                                         SOURCE_FIELDS_PIN,PREDECESSOR,native,CLOCK_FIELDS_PIN,
                                         ROOT_PURPOSE,*PRODUCT_PINS,OLD_CLOSURE)],
         'asset_pins':[p.wire() for p in assets],
         'predecessor_source_freeze':PREDECESSOR.wire(),
         'actual_Native_identity_regression':native.wire(),
         'focused_original_wait':focused.wire(),'strict_original_wait':strict.wire(),
         'recipe':recipe.wire(),'old_formal_gates_changed':False,'actual_media_execution':False,
         'maximum_new_C_allocated_bytes':LIMIT,'cue_media_cap':CUE_TOTAL_MAX,
         'whole_media_cap':FULL_MAX,'onedrive_copy_cap':FULL_MAX,'QA_TEMP_protocol_cap':META_MAX,
         'hard_peak_upper_bound_bytes':CUE_TOTAL_MAX+FULL_MAX*2+META_MAX,
         'source_native_allocation_before_freeze':budget.snapshot()})
    return freeze


@dataclass(frozen=True)
class Product:
    cue: WorkingCue
    work: FilePin
    native: FilePin
    encode_wait: FilePin
    decode_probe: FilePin

    def wire(self,start: int) -> JsonObject:
        return {'cue':self.cue.wire(),'start_frame':start,'end_frame':start+self.cue.frames,
                'work':self.work.wire(),'native_CAS':self.native.wire(),
                'actual_encode_original_wait':self.encode_wait.wire(),
                'actual_decode_probe':self.decode_probe.wire()}


def actual_probe(owner: WorkingOwner,media: FilePin,frames: int,key: str,*,movie: bool=False) -> FilePin:
    argv=(owner.resources.tools.ffprobe.media.path,'-v','error','-count_frames',
          '-show_streams','-show_format','-of','json',media.path)
    result=owner.call(CommandSpec.create(argv,label='Actual complete decode and frame count'),
        audit_directory=owner.budget.root/'audit'/key/'probe',
        request=Request('movie_decode_probe' if movie else 'cue_decode_probe',key,600 if movie else 120,0))
    observed=object_row(decode(result.stdout_pin.verify(65536)))
    validate_encoded_probe(observed,frames)
    video=next(object_row(v) for v in rows(observed['streams']) if object_row(v).get('codec_type')=='video')
    need(video.get('pix_fmt')=='yuv420p' and video.get('color_range')=='tv'
         and video.get('color_space')==video.get('color_transfer')==video.get('color_primaries')=='bt709',
         'Actual encoded output is consistently limited BT709')
    return owner.budget.json('probes/'+key+'.actual.json',
        {'machine_id':MACHINE,'media':media.wire(),'expected_frames':frames,
         'actual_full_decode':True,'observed':observed,'original_wait':result.wait_pin.wire()})


def movie_plan(owner: WorkingOwner,products: tuple[Product,...],
               *,key: Literal['full-working-review','first4-smoke']='full-working-review',
               output_cap: int=FULL_MAX) -> RenderPlan:
    need(type(output_cap) is int and 1048576<output_cap<=FULL_MAX,'Exact finite movie output cap')
    root=owner.budget.root
    output=root/('qa/first4-smoke.mp4' if key=='first4-smoke' else 'final/episode04.full-working-review.mp4')
    plan=plan_concat(ffmpeg=owner.resources.tools.ffmpeg.media.path,
        segment_paths=tuple(Path(p.native.path) for p in products),
        concat_path=output.with_suffix('.concat.txt'),partial_output=output.with_suffix('.partial.mp4'),
        final_output=output,audit_directory=root/'audit'/key,working_directory=root)
    command=plan.commands[0];argv=list(command.spec.argv)
    duration=sum(p.cue.frames for p in products)/30
    # The movie receives exactly one continuous bed; every source cue contains narration only.
    insertion=argv.index('-c')
    argv[insertion:insertion]=['-stream_loop','-1','-i',owner.resources.tools.music.media.path,
        '-filter_complex',f'[0:a]aresample=48000:async=1:first_pts=0[voice];'
            f'[1:a]volume=-30dB,afade=t=in:st=0:d=2,afade=t=out:st={duration-4:.9f}:d=4[music];'
            f'[voice][music]amix=inputs=2:duration=first:dropout_transition=0:normalize=0,'
            f'apad,atrim=duration={duration:.9f},asetpts=N/SR/TB[a]',
        '-map','0:v:0','-map','[a]','-t',f'{duration:.9f}']
    at=argv.index('-c');argv[at:at+2]=['-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-ac','2']
    argv[1:1]=['-copyts','-threads','1','-filter_complex_threads','1','-nostats','-progress','pipe:1']
    argv[-1:-1]=['-fs',str(output_cap-1048576),'-avoid_negative_ts','disabled','-video_track_timescale','15360']
    files=[line for line in plan.generated_files[0].content.splitlines() if line.startswith('file ')]
    need(len(files)==len(products),'Complete actual concat source count')
    content='ffconcat version 1.0\n'+''.join(line+'\nduration '+f'{p.cue.frames/30:.9f}'+'\n'
        for line,p in zip(files,products,strict=True))
    return replace(plan,commands=(replace(command,spec=replace(command.spec,argv=tuple(argv))),),
        generated_files=(GeneratedTextFile(plan.generated_files[0].path,content),))


def packet_audit(owner: WorkingOwner,movie: FilePin,frames: int,*,key: str='full-working-review') -> FilePin:
    target=owner.budget.root/'qa'/(key+'-packets.csv')
    owner.budget.guard(target,8*1048576);target.parent.mkdir(parents=True,exist_ok=True)
    argv=(owner.resources.tools.ffprobe.media.path,'-v','error','-show_packets',
          '-show_entries','packet=stream_index,pts,dts,duration','-of','csv=p=0','-o',str(target),movie.path)
    result=owner.call(CommandSpec.create(argv,label='Actual all-stream packet PTS/DTS audit'),
        audit_directory=owner.budget.root/'audit'/(key+'-packet-clock'),request=Request('movie_decode_probe',key+'-packet-clock',600,0))
    need(target.is_file() and target.stat().st_size<=8*1048576,'Finite complete packet protocol')
    video_pts: list[int]=[];video_dts: list[int]=[];audio_pts: list[int]=[];audio_end=0
    with target.open(encoding='utf-8',newline='') as stream:
        for row in csv.reader(stream):
            if not row:
                continue
            need(len(row)>=4 and all(re.fullmatch(r'-?[0-9]+',v) is not None for v in row[:4]),
                 'Exact actual integer packet fields')
            channel,pts,dts,duration=(int(v) for v in row[:4])
            if channel==0:
                need(duration==512,'Video packet frame duration')
                video_pts.append(pts);video_dts.append(dts)
            else:
                need(channel==1 and duration>0,'Single positive-duration audio stream')
                audio_pts.append(pts);audio_end=pts+duration
    need(len(video_pts)==frames and sorted(video_pts)==list(range(0,frames*512,512))
         and all(b-a==512 for a,b in zip(video_dts,video_dts[1:])),
         'Whole movie exact video PTS coverage and monotonic DTS')
    need(bool(audio_pts) and audio_pts[0] in (-1024,0)
         and all(b-a==1024 for a,b in zip(audio_pts,audio_pts[1:]))
         and abs(audio_end-frames*1600)<=1024,'Whole audio continuous PTS and aligned end')
    return owner.budget.json('qa/'+key+'-ALL-PACKET-CLOCK.actual.json',
        {'machine_id':MACHINE,'observed_at_utc':now(),'movie':movie.wire(),
         'packet_protocol':pin(target).wire(),'original_wait':result.wait_pin.wire(),
         'video_packets':len(video_pts),'audio_packets':len(audio_pts),'video_exact_frame_PTS':True,
         'video_DTS_monotonic':True,'audio_PTS_continuous':True,'audio_end_samples':audio_end,
         'expected_audio_samples':frames*1600,'audio_end_tolerance_samples':1024})


def audio_audit(owner: WorkingOwner,movie: FilePin,*,key: str='full-working-review') -> FilePin:
    escaped=Path(movie.path).as_posix().replace(':',r'\:')
    argv=(owner.resources.tools.ffprobe.media.path,'-hide_banner','-v','info','-f','lavfi',
          '-i',"amovie=filename='"+escaped+"',astats=metadata=0:reset=0",
          '-count_frames','-show_streams','-of','json')
    result=owner.call(CommandSpec.create(argv,label='Actual full mixed-audio statistics'),
        audit_directory=owner.budget.root/'audit'/(key+'-audio'),request=Request('movie_decode_probe',key+'-audio',600,0))
    waited=object_row(decode(result.wait_pin.verify(16384)))
    stderr=FilePin.parse(waited['stderr']);text=stderr.verify(262144).decode('utf-8')
    peaks=[float(v) for v in re.findall(r'Peak level dB:\s*(-?[0-9.]+)',text)]
    rms=[float(v) for v in re.findall(r'RMS level dB:\s*(-?[0-9.]+)',text)]
    need(bool(peaks) and bool(rms) and all(math.isfinite(v) for v in (*peaks,*rms))
         and max(peaks)<0 and -60<rms[-1]<-5,'Actual full audio is present with no sample clipping')
    return owner.budget.json('qa/'+key+'-AUDIO-STATISTICS.actual.json',
        {'machine_id':MACHINE,'observed_at_utc':now(),'movie':movie.wire(),
         'original_wait':result.wait_pin.wire(),'complete_actual_statistics':stderr.wire(),
         'peak_levels_dB':json_domain(peaks),'RMS_levels_dB':json_domain(rms),'sample_clipping_observed':False,
         'human1x':False})


def extract_frame(owner: WorkingOwner,source: FilePin,key: str,frame: int) -> FilePin:
    output=MEDIA/'qa'/('frame-'+key+'.jpg')
    spec=CommandSpec.create((owner.resources.tools.ffmpeg.media.path,'-nostdin','-hide_banner',
        '-loglevel','error','-n','-ss',f'{frame/30:.9f}','-i',source.path,
        '-frames:v','1','-threads:v','1','-q:v','3','-update','1',str(output)),
        label='Actual full-resolution frame JPEG encoding for direct visual inspection',partial_artifacts=(output,))
    owner.call(spec,audit_directory=MEDIA/'audit'/('frame-'+key),request=Request('cue_encode','frame-'+key,300,CUE_MAX))
    ref=pin(output);need(ref.bytes<=4*1048576,'Finite full-resolution frame JPEG')
    return ref


def preview_gate(owner: WorkingOwner,admission: MediaAdmission,previews: tuple[FilePin,...]) -> None:
    """Independent Root direct-pixel review, with no live media child held open."""
    need(owner.children==0 and all(custody_good(object_row(c)) for c in owner.custodies),
         'Every preview child originally waited and Job0 before direct review')
    request=owner.budget.json('PREVIEW-READY.actual.json',
        {'schema':'xar.e04.full-working-review.preview-ready.v1','machine_id':MACHINE,
         'observed_at_utc':now(),'source_freeze':admission.freeze.wire(),
         'previews':[p.wire() for p in previews],'all_preview_children_wait0_Job0':True})
    print('ACTUAL PREVIEW GATE',request.path,flush=True)
    acceptance=MEDIA.parent/'root/ROOT-FULLREVIEW-PREVIEW-ACCEPTANCE.actual-a01.json'
    stop=time.monotonic()+1800
    while not acceptance.exists():
        need(time.monotonic()<stop and dt.datetime.now(dt.UTC)<owner.budget.deadline-dt.timedelta(minutes=30),
             'Finite independent Root preview-review window expired')
        time.sleep(.25)
    receipt=pin(acceptance)
    r=object_row(decode(receipt.verify(32768)),
        {'schema','machine_id','observed_at_utc','reviewer','accepted','preview_ready','direct_reviewed_images'})
    need(r['schema']=='xar.root.e04.full-working-review.preview-acceptance.v1'
         and r['machine_id']==MACHINE and r['reviewer']=='/root' and r['accepted'] is True
         and FilePin.parse(r['preview_ready'])==request
         and canonical(r['direct_reviewed_images'])==canonical([p.wire() for p in previews]),
         'Actual independent direct-pixel Root review of these exact preview files')
    owner.budget.json('PREVIEW-REVIEW-CONSUMED.actual.json',
        {'machine_id':MACHINE,'observed_at_utc':now(),'Root_actual_visual_review':receipt.wire()})


def enforce_allocations(owner: WorkingOwner,products: tuple[Product,...],movie: FilePin | None) -> None:
    media_bytes=sum(p.work.bytes for p in products)+(0 if movie is None else movie.bytes)
    copy_bytes=ONEDRIVE.stat().st_size if ONEDRIVE.exists() else 0
    total=integer(owner.budget.snapshot()['allocated_bytes'])
    need(sum(p.work.bytes for p in products)<=CUE_TOTAL_MAX and copy_bytes<=FULL_MAX
         and (movie is None or movie.bytes<=FULL_MAX)
         and total-media_bytes-copy_bytes<=META_MAX and total<=LIMIT,
         'Actual all-cue/whole/OneDrive/protocol subcaps and combined physical allocation')


def contact_sheets(owner: WorkingOwner,frames: tuple[JsonObject,...]) -> tuple[FilePin,...]:
    results: list[FilePin]=[]
    for offset in range(0,len(frames),32):
        selected=frames[offset:offset+32]
        image=Image.new('RGB',(1920,math.ceil(len(selected)/4)*300),(8,16,21))
        drawer=ImageDraw.Draw(image)
        for index,row in enumerate(selected):
            source=FilePin.parse(row['source']);source.verify(4*1048576)
            with Image.open(source.path) as original:
                thumbnail=original.convert('RGB').resize((480,270))
            x=(index%4)*480;y=(index//4)*300
            image.paste(thumbnail,(x,y))
            drawer.text((x+8,y+276),string(row['cue_id'])+'  frame '+str(integer(row['frame'])),fill=(230,240,245))
        target=MEDIA/'qa'/f'contact-{offset//32+1:02d}.jpg'
        owner.budget.guard(target,4*1048576)
        image.save(target,quality=88)
        image.close();results.append(pin(target))
    return tuple(results)


def execute(card: FilePin) -> FilePin:
    admission=MediaAdmission.parse(card);budget=admission.budget
    resources=Resources.load();cues=prepare(resources)
    frozen=object_row(decode(admission.freeze.verify(65536)))
    summary=object_row(decode(FilePin.parse(frozen['recipe']).verify(262144)))
    need(canonical(summary['cues'])==canonical([c.wire() for c in cues]),'Exact frozen complete recipe')
    budget.guard(MEDIA/'temp/reserve',8192);(MEDIA/'temp').mkdir(parents=True,exist_ok=True)
    budget.json('EXECUTOR-ONCE.actual.json',{'machine_id':MACHINE,'observed_at_utc':now(),
        'financial_card':card.wire(),'Root_purpose':admission.purpose.wire(),'source_freeze':admission.freeze.wire(),
        'review_only':True,'R05_actual_acceptance':None,'human1x':False,'signoff':False})
    owner=WorkingOwner(budget,resources);products: list[Product]=[];movie: FilePin | None=None
    failure: str | None=None
    try:
        owner.idle()
        # Brand/chapter/ending are encoded first so Root can inspect their actual new pixels early.
        early=('BRAND','CHAPTER01','END','C01-01')
        order=tuple(next(c for c in cues if c.cue_id==key) for key in early)+tuple(
            c for c in cues if c.cue_id not in early)
        previews: list[FilePin]=[]
        for cue in order:
            consume_cue(json_domain(cue.wire()),cue)
            budget.json('once/'+cue.cue_id+'.json',{'machine_id':MACHINE,'cue':cue.wire(),'max_attempts':1})
            rendered=owner.render(cue.plan,Request('cue_encode',cue.cue_id,300,CUE_MAX))
            work=pin(cue.plan.final_output)
            probe=actual_probe(owner,work,cue.frames,cue.cue_id)
            native=link_new_output(budget,work,CUE_MAX)
            product=Product(cue,work,native.media,rendered.wait_pin,probe)
            products.append(product)
            enforce_allocations(owner,tuple(products),None)
            budget.json('products/'+cue.cue_id+'.actual.json',product.wire(0))
            if cue.cue_id in (*early,'N03-02','N06-08'):
                preview=extract_frame(owner,work,cue.cue_id,min(cue.frames-1,60))
                if cue.cue_id in early:
                    previews.append(preview)
                print('ACTUAL PREVIEW',preview.path,flush=True)
            print('ACTUAL CUE',cue.cue_id,cue.frames,work.bytes,flush=True)
            if cue.cue_id=='C01-01':
                by_preview={p.cue.cue_id:p for p in products}
                pilot=tuple(by_preview[k] for k in ('BRAND','C01-01','CHAPTER01','END'))
                smoke_plan=movie_plan(owner,pilot,key='first4-smoke')
                smoke_result=owner.render(smoke_plan,Request('movie_concat','first4-smoke',600,FULL_MAX))
                smoke=pin(smoke_plan.final_output);smoke_frames=sum(p.cue.frames for p in pilot)
                smoke_probe=actual_probe(owner,smoke,smoke_frames,'first4-smoke',movie=True)
                smoke_clocks=packet_audit(owner,smoke,smoke_frames,key='first4-smoke')
                smoke_audio=audio_audit(owner,smoke,key='first4-smoke')
                budget.json('FIRST4-SMOKE.actual.json',{'machine_id':MACHINE,'movie':smoke.wire(),
                    'total_frames':smoke_frames,'actual_concat':smoke_result.wait_pin.wire(),
                    'actual_full_decode':smoke_probe.wire(),'actual_packet_clocks':smoke_clocks.wire(),
                    'actual_audio_statistics':smoke_audio.wire(),'included_in_formal62_timeline':False,
                    'copied_to_OneDrive':False})
                enforce_allocations(owner,tuple(products),None)
                preview_gate(owner,admission,tuple(previews))
        by_id={p.cue.cue_id:p for p in products}
        ordered=tuple(by_id[c.cue_id] for c in cues)
        timeline: list[JsonValue]=[];at=0
        for product in ordered:
            timeline.append(product.wire(at));at+=product.cue.frames
        timeline_ref=budget.json('FULL-WORKING-REVIEW-TIMELINE.actual.json',
            {'schema':'xar.e04.full-working-review.actual-timeline.v1','machine_id':MACHINE,
             'fps':30,'total_frames':at,'entries':timeline,'R05_actual_acceptance':None,
             'review_only':True,'human1x':False,'signoff':False})
        plan=movie_plan(owner,ordered)
        joined=owner.render(plan,Request('movie_concat','full-working-review',600,FULL_MAX))
        movie=pin(plan.final_output);full_probe=actual_probe(owner,movie,at,'full-working-review',movie=True)
        movie_native=link_new_output(budget,movie,FULL_MAX)
        clocks=packet_audit(owner,movie,at)
        audio=audio_audit(owner,movie)
        enforce_allocations(owner,ordered,movie)
        preview_frames: list[JsonObject]=[];position=0
        for product in ordered:
            # Every cut gets actual movie pixels; these frames are samples, never human1x.
            preview=extract_frame(owner,movie,'movie-'+product.cue.cue_id,position+min(30,product.cue.frames-1))
            preview_frames.append({'cue_id':product.cue.cue_id,'frame':position+min(30,product.cue.frames-1),
                                   'source':preview.wire()})
            position+=product.cue.frames
        sheets=contact_sheets(owner,tuple(preview_frames))
        enforce_allocations(owner,ordered,movie)
        budget.guard(MEDIA/'onedrive-copy-reserve',movie.bytes)
        with Path(movie.path).open('rb') as source,ONEDRIVE.open('xb') as destination:
            shutil.copyfileobj(source,destination,1024*1024)
            destination.flush();os.fsync(destination.fileno())
        copied=pin(ONEDRIVE)
        need((copied.bytes,copied.sha256)==(movie.bytes,movie.sha256),'Actual OneDrive local full-copy SHA')
        enforce_allocations(owner,ordered,movie)
        return budget.json('FULL-WORKING-REVIEW-ACTUAL-METADATA.actual.json',
            {'schema':'xar.e04.full-working-review.actual-movie.v1','machine_id':MACHINE,
             'observed_at_utc':now(),'total_frames':at,'fps':30,'cue_count':len(ordered),
             'movie':movie.wire(),'native_CAS':movie_native.wire(),'onedrive_local_copy':copied.wire(),
             'actual_concat_wait':joined.wait_pin.wire(),'timeline':timeline_ref.wire(),
             'full_decode':full_probe.wire(),'packet_clocks':clocks.wire(),'sampled_movie_frames':json_domain(preview_frames),
             'full_audio_statistics':audio.wire(),'contact_sheets':[p.wire() for p in sheets],
             'all47_mechanics_new_encodes':True,'complete_opening_chapters_ending':True,
             'single_continuous_music_bed':True,'R05_actual_acceptance':None,'R05_business_qualified':False,
             'review_only':True,'human1x':False,'signoff':False,'onedrive_cloud_sync':'PENDING_CLIENT_READBACK',
             'actual_native_allocation_before_metadata':budget.snapshot()})
    except BaseException as error:
        failure=type(error).__name__+': '+str(error)[:2500]
        budget.json('FAILED-PRESERVED.actual.json',{'machine_id':MACHINE,'observed_at_utc':now(),
            'diagnostic':failure,'completed_cues':len(products),'partials_retained':True,'no_retry':True})
        raise
    finally:
        budget.json('EXECUTOR-OWNER-CLOSED.actual.json',{'machine_id':MACHINE,'observed_at_utc':now(),
            'failed':failure is not None,'owner_error':failure,'owned_Popen_remaining':owner.children,
            'actual_original_waits':json_domain(owner.codes),'actual_custodies':owner.custodies,
            'all_original_children_wait0_Job0':bool(owner.custodies) and all(custody_good(object_row(c)) for c in owner.custodies),
            'native_allocation_before_receipt':budget.snapshot(),'human1x':False,'signoff':False})


def main() -> None:
    need(len(sys.argv) in (3,4),'source-check aNN or execute CARD SHA256')
    if sys.argv[1]=='source-check':
        need(len(sys.argv)==3,'Unique source attempt')
        result=source_check(sys.argv[2])
    else:
        need(len(sys.argv)==4 and sys.argv[1]=='execute','Only explicit admitted media execution')
        card=pin(Path(sys.argv[2]));need(card.sha256==sys.argv[3],'Exact actual card SHA')
        result=execute(card)
    print(json.dumps(result.wire(),ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
