"""Independent full working review contract; formal final47 gates remain intact."""
from __future__ import annotations

from dataclasses import dataclass
import ctypes
import datetime as dt
import hashlib
import os
from pathlib import Path
import sys
from typing import Literal
from working_fields import (
    COMMON_FIELDS as COMMON_FIELDS, CARD_FIELDS as CARD_FIELDS,
    PURPOSE_FIELDS as PURPOSE_FIELDS, CAP_SCHEMA, ROOT_SCHEMA,
)

OLD = Path('C:/ck3-e04-resume-20261022-b01')
BASE = Path('C:/ck3-e04-resume-20261023-a01')
SOURCE = BASE / 'fullreview-source-a04'
MEDIA = BASE / 'fullreview-media-a04'
ONEDRIVE = Path('C:/Users/1/OneDrive/CK3-War-AI-20260923/CK3-Episode04-Full-Working-Review-20261023-a01.mp4')
EXECUTOR = OLD / 'final47-executor-source-a01'
for _name, _sha in (
    ('executor_contract.py', 'e1a31efa312bd7890ea021f1d87a4c132d1f3ca3e3bd0c2ae71861f229043514'),
    ('produce_final47.py', 'c8db9e2bdd7e883d6fef3a0fc24af2ab68d23afbff3968a3ec3b7d255aa13321'),
):
    if hashlib.sha256((EXECUTOR / _name).read_bytes()).hexdigest() != _sha:
        raise ValueError('Frozen original executor dependency changed')
sys.path.insert(0, str(EXECUTOR))
from executor_contract import (
    Budget as Budget, NewOutputBudget as NewOutputBudget, FilePin as FilePin,
    JsonObject as JsonObject, JsonValue as JsonValue, Resources as Resources,
    RetainedAsset as RetainedAsset, MACHINE as MACHINE, FONT_PIN as FONT_PIN,
    canonical as canonical, decode as decode, integer as integer, json_domain as json_domain,
    need as need, now as now, object_row as object_row, pin as pin, rows as rows,
    string as string, validate_encoded_probe as validate_encoded_probe, decimal64 as decimal64,
    link_new_output as link_new_output, SourceError as SourceError,
    NativeItem, unique_allocation,
)
from produce_final47 import Owner as OriginalOwner
from qa_firstclip import Native
from qa_contract import Pin as JobPin
from produce_actual_assets import allocation, K, Standard
from xar_promo.render import RenderPlan, GeneratedTextFile, PlannedCommand
from xar_promo.process import CommandSpec

PENDING = FilePin(str(OLD / 'final47-source-a01/a04/FINAL47-PENDING-SOURCE-RECIPE.actual.json'),
    442494, '36512ef7aa2d9cdf330b7260fa5a51beb9fdb0a9deb7f9b34d16e9d84cd7146a')
ENVIRONMENT = FilePin(str(BASE / 'r05-runtime/ACTUAL-PROMO-ENVIRONMENT.actual-a01.json'),
    3168, '817710b682661d5555c43ed5f02bd72d807af4138f3a5249e566137e10918c7a')
SOURCE_CARD = FilePin(str(BASE / 'capacity/FULLREVIEW-SOURCE-A04-ADMISSION.actual-a01.json'),
    814, '47401a80ce674c1011715dbb05af9b4f356c8c1c8f19f5bcf3841cffba401ee6')
SOURCE_FIELDS_PIN=FilePin(str(BASE/'capacity/source_successor_fields.py'),855,
    '7b2cc4e1f5f5fa1e9d6082e1f51bf6cfaea8942d2af9b07ecb5e2197fac193ca')
SOURCE_FIELDS_PIN.verify(4096)
sys.path.insert(0,str(BASE/'capacity'))
from source_successor_fields import SOURCE_FIELDS,SOURCE_SCHEMA
PREDECESSOR=FilePin(str(BASE/'fullreview-source-a03/SOURCE-FREEZE.actual.json'),38796,
    'a06dacdda7f6619ae727bf27ee5e1871c5f4ab4baf0a590b4dd0d7a276e5e325')
LIMIT = 500 * 1048576
CUE_TOTAL_MAX = 144 * 1048576
FULL_MAX = 144 * 1048576
SOURCE_LIMIT = 524288
SOURCE_DEADLINE = dt.datetime(2026, 10, 23, 0, 30, tzinfo=dt.UTC)
DEADLINE_TEXT = '2026-10-23T00:30:00Z'
OLD_MEDIA = OLD / 'final47-media-a01'
Kind = Literal['mechanics', 'r05_rule_only', 'retained_opening', 'retained_ending', 'brand', 'chapter', 'end_credit']


def utc(value: JsonValue) -> dt.datetime:
    result = dt.datetime.fromisoformat(string(value))
    need(result.tzinfo is not None and result.utcoffset() == dt.timedelta(0), 'Explicit UTC datetime')
    return result


def source_budget() -> Budget:
    value = object_row(decode(SOURCE_CARD.verify(8192)),set(SOURCE_FIELDS))
    need(value['schema']==SOURCE_SCHEMA and value['machine_id'] == MACHINE
         and value['owner']=='/root/fullreview' and value['admitted'] is True
         and value['budget_status']=='GREEN', 'Current source admission')
    need(Path(string(value['exact_root'])) == SOURCE
         and integer(value['maximum_new_C_allocated_bytes']) == SOURCE_LIMIT
         and integer(value['maximum_new_D_allocated_bytes']) == 0
         and utc(value['hard_deadline_utc']) == SOURCE_DEADLINE, 'Exact source bounds')
    FilePin.parse(value['Root_independent_purpose']).verify(8192)
    need(bool(string(value['Root_scope_amendment'])),'Actual narrow successor scope amendment')
    return CombinedBudget(SOURCE, SOURCE_DEADLINE, SOURCE_LIMIT)


def validate_closed(value: JsonValue) -> None:
    r=object_row(value)
    need(r['schema']=='xar.root.e04.full-working-review-game-closed.v1'
         and r['machine_id']==MACHINE and r['author']=='/root'
         and r['Game_closed_actual'] is True
         and len(rows(r['current_game_media_processes']))==0
         and len(rows(r['current_screen_owners']))==0
         and integer(object_row(r['native_census'])['original_wait'])==0,
         'Actual Root same-machine Game closure and strictly empty native scene census')


def alias_allocation(path: Path,expected_links: int) -> tuple[int,int]:
    """Narrow existing Win32 ABI, accepting only the enumerated exact link count."""
    need(type(expected_links) is int and expected_links>=1,'Exact expected Native link count')
    handle: object=K.CreateFileW(str(path),0x80,7,None,3,0x00200000,None)
    if type(handle) is not int or handle==ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    if not isinstance(handle,int):
        raise SourceError('Native handle narrowing')
    try:
        info=Standard()
        ok: object=K.GetFileInformationByHandleEx(handle,1,ctypes.byref(info),ctypes.sizeof(info))
        need(type(ok) is int and ok!=0,'Actual Native standard information query')
        logical,allocated,links=int(info.EndOfFile),int(info.AllocationSize),int(info.NumberOfLinks)
        need(logical>=0 and allocated>=0 and not info.Directory and not info.DeletePending
             and links==expected_links,'Live ordinary file with exact observed Native link count')
        return logical,allocated
    finally:
        closed: object=K.CloseHandle(handle)
        need(type(closed) is int and closed!=0,'Actual Native allocation handle close')


class CombinedBudget(NewOutputBudget):
    """Native allocation of new media plus its exact new OneDrive copy."""
    def snapshot(self) -> JsonObject:
        found: list[NativeItem]=[];count=0
        import time
        started=time.monotonic()
        stack=[self.root] if self.root.exists() else []
        while stack:
            with os.scandir(stack.pop()) as entries:
                for entry in entries:
                    count+=1
                    need(count<=2000 and time.monotonic()-started<=15,'Bounded complete Native census')
                    path=Path(entry.path)
                    # Windows DirEntry.stat caches zero identity/link fields. Path.stat opens the real file.
                    info=path.stat(follow_symlinks=False)
                    need(not info.st_file_attributes&0x400,'No reparse entry in own output root')
                    if entry.is_dir(follow_symlinks=False):
                        stack.append(path)
                    else:
                        need(info.st_dev>0 and info.st_ino>0 and info.st_nlink>=1,
                             'Real nonzero Native device/FileID/link count from Path.stat')
                        size,assigned=alias_allocation(path,info.st_nlink)
                        found.append(NativeItem(str(path.resolve()),size,assigned,str(info.st_dev),
                                                str(info.st_ino),info.st_nlink))
        logical,assigned,aliases=unique_allocation(tuple(found))
        result: JsonObject={'logical_bytes':logical,'allocated_bytes':assigned,'entries':count,
            'hardlink_aliases':aliases,'unique_files':len(found)-aliases,'payload_bytes_read_for_allocation':0}
        extra = 0
        if ONEDRIVE.exists():
            info = ONEDRIVE.stat()
            need(not info.st_file_attributes & 0x400 and info.st_nlink == 1,
                 'Exact ordinary OneDrive review copy with no external aliases')
            _, extra = allocation(ONEDRIVE)
        total = integer(result['allocated_bytes']) + extra
        self.peak_observed_allocated = max(self.peak_observed_allocated, total)
        return {**result, 'allocated_bytes': total, 'onedrive_allocated_bytes': extra,
                'onedrive_exact_path': str(ONEDRIVE)}


@dataclass(frozen=True)
class MediaAdmission:
    card: FilePin
    purpose: FilePin
    freeze: FilePin
    closed: FilePin
    budget: CombinedBudget

    @staticmethod
    def parse(ref: FilePin) -> MediaAdmission:
        r = object_row(decode(ref.verify(32768)), set(CARD_FIELDS))
        need(r['schema'] == CAP_SCHEMA
             and r['admitted'] is True and r['budget_status'] == 'GREEN'
             and r['full_working_review_execution_admitted'] is True,
             'Actual independent working review media admission')
        purpose = FilePin.parse(r['Root_independent_purpose'])
        p = object_row(decode(purpose.verify(32768)), set(PURPOSE_FIELDS))
        need(p['schema'] == ROOT_SCHEMA, 'Independent Root purpose')
        for key in COMMON_FIELDS:
            need(canonical(p[key]) == canonical(r[key]), 'Root/CAP unique field mismatch: ' + key)
        need(r['machine_id'] == MACHINE and r['owner'] == '/root/fullreview'
             and Path(string(r['exact_root'])) == MEDIA
             and Path(string(r['onedrive_output'])) == ONEDRIVE
             and integer(r['maximum_new_C_allocated_bytes']) == LIMIT
             and integer(r['maximum_new_D_allocated_bytes']) == 0
             and r['hard_deadline_utc'] == DEADLINE_TEXT
             and r['Game_closed_actual'] is True
             and r['allow_new_output_work_CAS_hardlinks'] is True
             and r['review_only'] is True and r['R05_actual_acceptance'] is None
             and r['human1x'] is False and r['signoff'] is False
             and r['formal_final47_guards_unchanged'] is True
             and FilePin.parse(r['font']) == FONT_PIN, 'Single exact media contract')
        deadline = utc(r['hard_deadline_utc'])
        need(dt.datetime.now(dt.UTC) < deadline and not MEDIA.exists()
             and not ONEDRIVE.exists() and ONEDRIVE.parent.is_dir(), 'Fresh create-only output destinations')
        freeze = FilePin.parse(r['source_freeze'])
        f = object_row(decode(freeze.verify(65536)))
        need(f['schema'] == 'xar.e04.full-working-review.source-freeze.v1'
             and f['machine_id'] == MACHINE, 'Actual checked successor source')
        for v in rows(f['source_pins']):
            FilePin.parse(v).verify(262144)
        for v in rows(f['input_pins']):
            FilePin.parse(v).verify(1048576)
        for v in rows(f['asset_pins']):
            FilePin.parse(v).verify(256*1048576)
        closed = FilePin.parse(r['Game_closed_proof'])
        validate_closed(decode(closed.verify(65536)))
        FONT_PIN.verify(33554432)
        ENVIRONMENT.verify(8192)
        return MediaAdmission(ref, purpose, freeze, closed, CombinedBudget(MEDIA, deadline, LIMIT))


class WorkingOwner(OriginalOwner):
    """Reuse reviewed custody implementation without constructing formal R05 admission."""
    def __init__(self, budget: CombinedBudget, resources: Resources) -> None:
        self.budget = budget
        self.resources = resources
        helper = resources.tools.job_helper
        self.native = Native(JobPin(helper.path, helper.bytes, helper.sha256))
        self.children = 0
        self.codes = []
        self.custodies = []
        self.last = None
        self.current = None


def relocate(text: str) -> str:
    output = text.replace(str(OLD_MEDIA), str(MEDIA)).replace(OLD_MEDIA.as_posix(), MEDIA.as_posix())
    old_ass = OLD_MEDIA.as_posix().replace(':', r'\\:')
    new_ass = MEDIA.as_posix().replace(':', r'\\:')
    return output.replace(old_ass, new_ass).replace(OLD_MEDIA.as_posix()[2:], MEDIA.as_posix()[2:])


def plan_parse(value: JsonValue) -> RenderPlan:
    r = object_row(value, {'commands','generated_files','partial_output','final_output'})
    commands: list[PlannedCommand] = []
    partial = Path(relocate(string(r['partial_output'])))
    final = Path(relocate(string(r['final_output'])))
    for v in rows(r['commands']):
        c = object_row(v, {'argv','working_directory','audit_directory'})
        argv = tuple(relocate(string(a)) for a in rows(c['argv']))
        work = c['working_directory']
        need(work is not None, 'Explicit command working directory')
        spec = CommandSpec.create(argv, cwd=Path(relocate(string(work))),
                                  label='Independent full working review cue', partial_artifacts=(partial,))
        commands.append(PlannedCommand(spec, Path(relocate(string(c['audit_directory'])))))
    generated: list[GeneratedTextFile] = []
    for v in rows(r['generated_files']):
        g = object_row(v, {'path','encoding','content'})
        need(g['encoding'] == 'utf-8', 'Single generated text encoding')
        generated.append(GeneratedTextFile(Path(relocate(string(g['path']))), string(g['content'])))
    need(len(commands) == len(generated) == 1 and partial.is_relative_to(MEDIA)
         and final.is_relative_to(MEDIA) and Path(commands[0].spec.argv[-1]) == partial,
         'One create-only output under independent new media root')
    return RenderPlan(tuple(commands), tuple(generated), partial, final)


@dataclass(frozen=True)
class WorkingCue:
    cue_id: str
    kind: Kind
    frames: int
    plan: RenderPlan
    evidence: JsonObject

    def wire(self) -> JsonObject:
        return {'cue_id': self.cue_id, 'kind': self.kind, 'frames': self.frames,
                'evidence': self.evidence,
                'ASS_sha256': hashlib.sha256(self.plan.generated_files[0].content.encode('utf-8')).hexdigest(),
                'output': str(self.plan.final_output)}


def consume_cue(value: JsonValue, actual: WorkingCue) -> WorkingCue:
    r = object_row(value, {'cue_id','kind','frames','evidence','ASS_sha256','output'})
    need(integer(r['frames']) > 0 and canonical(actual.wire()) == canonical(r),
         'Producer/consumer cue JSON roundtrip and exact field contract')
    return actual
