"""Complete editorial sequence built from retained source voices and new mechanics."""
from __future__ import annotations

from dataclasses import replace
from decimal import Decimal
from pathlib import Path
import hashlib

from working_contract import (
    SOURCE, MEDIA, PENDING, FilePin, Resources, WorkingCue, JsonObject, JsonValue,
    canonical, decode, integer, need, object_row, rows, string, plan_parse, Kind, RetainedAsset,
)
from final47_base import Cue, Voice, Pin, FONT, legacy_cue_plan, project_cues, EXPECTED_CUES
from mechanics_composer import subtitles as legacy_subtitles
from xar_promo.audio import AudioMixSpec, AudioStem
from xar_promo.render import (
    GeneratedTextFile, RenderPlan, RenderOptions, plan_render, ass_burn_in_filter,
)

EDITORIAL = FilePin('C:/ck3-e04-resume-20261023-a01/intro-source/EDITORIAL-SOURCE-INPUTS.actual-a01.json',
    21892, '3f64a52255530c4ebdd4be33b7ccfc98c63d09fcb5e90f0a03db30dfb3205718')
STRUCTURE = FilePin('C:/ck3-e04-resume-20261023-a01/intro-source/EDITORIAL-STRUCTURE.source-a02.json',
    24657, '49496ee3845c9cb9a667b74c469459fdbc784c161cc7f45bf87397142831c2ca')
DYNAMIC = FilePin('C:/ck3-e04-resume-20261023-a01/intro-source/DYNAMIC-OPENING-VISUAL.source-a03.json',
    5878,'b57fc0ad21a17acaacc0e8700dc06a283a334f49cc4111cfe83af3df088d62bb')
VOICE_PROBES = FilePin('C:/ck3-e04-resume-20261023-a01/intro-source/OUTER-VOICE-PROBES.actual-a01.json',
    7501,'a472766efa55a1979e0b77082dba79829c3c371f708337fbe074534f58218830')
OUTER_KEYS = ('C01-01','C01-08','C01-04','C01-05','C01-06','C06-03','C06-10')
CHAPTERS = ('补给不是兵力','缺员怎样补回来','谁在扣兵','分兵与合军','行军锁定与海运','军费与远征预算')
OUTER_TITLES = {
    'C01-01':'出发时的人数，只是起点', 'C01-08':'物资、兵员、路线：出征前的三张账',
    'C01-04':'先分清：物资、人数、移动', 'C01-05':'减少的兵，去了哪里？',
    'C01-06':'计划、估计与实际到达', 'C06-03':'先核对人数，再解释变化',
    'C06-10':'把补给、损耗、路线与军费一起算',
}


def narration_only(plan: RenderPlan) -> RenderPlan:
    """Remove the exact per-cue background stem; the whole movie gets one music bed."""
    command = plan.commands[0]
    argv = list(command.spec.argv)
    inputs = [i for i, value in enumerate(argv) if value == '-i']
    need(len(inputs) in (3,4), 'Known original narration/music source layout')
    del argv[inputs[2]:inputs[2]+2]
    at = argv.index('-filter_complex') + 1
    graph = argv[at]
    split = graph.index('[1:a]')
    video = graph[:split].replace('[3:v]', '[2:v]')
    voice = graph[split:].split(';',1)[0]
    need(voice.endswith('[xar_mix_0]') and '[2:a]' not in voice,
         'Exact public original narration stem')
    argv[at] = video + voice[:-len('[xar_mix_0]')] + '[a]'
    need('amix=' not in argv[at] and '[2:a]' not in argv[at], 'One voice stem only')
    return replace(plan, commands=(replace(command, spec=replace(command.spec, argv=tuple(argv))),))


def finish_plan(plan: RenderPlan, frames: int) -> RenderPlan:
    command = plan.commands[0]
    argv = list(command.spec.argv)
    at=argv.index('-filter_complex')+1
    graph=argv[at]
    normalize=('scale=out_range=tv:out_color_matrix=bt709,format=yuv420p,'
               'setparams=range=limited:color_primaries=bt709:color_trc=bt709:colorspace=bt709')
    if normalize not in graph:
        need(graph.count('format=yuv420p[v]')==1,'Exact public final video-format seam')
        argv[at]=graph.replace('format=yuv420p[v]',normalize+'[v]',1)
    if '-color_range' not in argv:
        argv[-1:-1]=['-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709']
    if '-frames:v' not in argv:
        argv[1:1] = ['-threads','1','-filter_complex_threads','1','-nostats','-progress','pipe:1']
        argv[-1:-1] = ['-threads:v','1','-frames:v',str(frames),'-profile:v','high',
            '-level:v','4.0','-video_track_timescale','15360','-maxrate','4M','-bufsize','8M']
    if '-fs' not in argv:
        argv[-1:-1] = ['-fs',str(17*1048576)]
    return replace(plan, commands=(replace(command, spec=replace(command.spec, argv=tuple(argv))),))


def overlay_ass(content: str, title: str, frames: int, *, warning: bool = False) -> str:
    style = ('Style: Editorial,Microsoft YaHei,44,&H00E8F5F4,&H000000FF,&H0012171C,&H980B1015,'
             '-1,0,0,0,100,100,0,0,1,2,1,8,110,110,110,1\n')
    color = r'{\c&H006FD6FF&}' if warning else ''
    end = f'{frames/30:.2f}'
    seconds = frames / 30
    stamp = f'{int(seconds//3600)}:{int(seconds//60)%60:02d}:{seconds%60:05.2f}'
    need('[Events]' in content and '\nStyle: Editorial,' not in content, 'One editorial overlay')
    return content.replace('[Events]',style+'\n[Events]',1) + (
        f'Dialogue: 4,0:00:00.00,{stamp},Editorial,editorial,0,0,0,,{{\\q2}}{color}{title}\n')


def body_ass(content: str, lines: tuple[str,...], frames: int) -> str:
    seconds=frames/30
    stamp=f'{int(seconds//3600)}:{int(seconds//60)%60:02d}:{seconds%60:05.2f}'
    style=('Style: Body,Microsoft YaHei,38,&H00E8F5F4,&H000000FF,&H0012171C,&HB00B1015,'
           '0,0,0,0,100,100,0,0,3,18,0,5,130,130,0,1\n')
    result=content.replace('[Events]',style+'\n[Events]',1)
    for index,line in enumerate(lines):
        result += f'Dialogue: 3,0:00:00.00,{stamp},Body,body,0,0,0,,{{\\pos(960,{330+index*95})\\q2}}{line}\n'
    return result


def title_ass(key: str, title: str, subtitle: str, frames: int) -> str:
    seconds = frames / 30
    end = f'0:{int(seconds//60):02d}:{seconds%60:05.2f}'
    return ('[Script Info]\nTitle: '+key+'\nScriptType: v4.00+\nPlayResX: 1920\nPlayResY: 1080\nWrapStyle: 2\n'
        '\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n'
        'Style: Main,Microsoft YaHei,66,&H00E8F5F4,&H000000FF,&H00101720,&H98081018,-1,0,0,0,100,100,0,0,1,2,1,5,110,110,0,1\n'
        'Style: Sub,Microsoft YaHei,32,&H00ABC3C6,&H000000FF,&H00101720,&H98081018,0,0,0,0,100,100,0,0,1,1,0,5,110,110,0,1\n'
        '\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n'
        f'Dialogue: 1,0:00:00.00,{end},Main,title,0,0,0,,{{\\pos(960,460)\\fad(500,500)\\q2}}{title}\n'
        f'Dialogue: 1,0:00:00.00,{end},Sub,subtitle,0,0,0,,{{\\pos(960,600)\\fad(500,500)\\q2}}{subtitle}\n')


def still_plan(resources: Resources, key: str, cover: FilePin, frames: int, ass: str,
               voice: FilePin | None) -> RenderPlan:
    output = MEDIA / 'work' / (key+'.mp4')
    caption = MEDIA / 'subtitles' / (key+'.ass')
    source = resources.tools.music.media if voice is None else voice
    mix = AudioMixSpec((AudioStem('narration',Path(source.path),gain_db=-120 if voice is None else 0),),
                       duration_seconds=frames/30)
    plan = plan_render(ffmpeg=resources.tools.ffmpeg.media.path, video_input=Path(cover.path),
        partial_output=output.with_suffix('.partial.mp4'), final_output=output,
        audit_directory=MEDIA/'audit'/key, options=RenderOptions(1920,1080,30,frames/30,
            preset='veryfast',crf=21,audio_bitrate='192k',pad_color='0x081015'),
        ass_path=caption,working_directory=MEDIA,audio_mix=mix)
    command = plan.commands[0]
    argv = list(command.spec.argv)
    at = argv.index('-filter_complex')+1
    burn = ass_burn_in_filter(caption)
    need(argv[at].count(burn)==1,'One installed public ASS burn')
    argv[at] = argv[at].replace(burn, 'eq=brightness=-0.25:saturation=0.65,'+burn,1)
    plan = replace(plan,commands=(replace(command,spec=replace(command.spec,argv=tuple(argv))),),
                   generated_files=(GeneratedTextFile(caption,ass),))
    return finish_plan(plan,frames)


def opening_plan(resources: Resources,raw: FilePin,voice: FilePin,ass: str) -> RenderPlan:
    output=MEDIA/'work/C01-01.mp4';caption=MEDIA/'subtitles/C01-01.ass'
    plan=plan_render(ffmpeg=resources.tools.ffmpeg.media.path,video_input=Path(raw.path),
        partial_output=output.with_suffix('.partial.mp4'),final_output=output,
        audit_directory=MEDIA/'audit/C01-01',options=RenderOptions(1920,1080,30,20.4,
            preset='veryfast',crf=21,audio_bitrate='192k',pad_color='0x081015'),
        ass_path=caption,working_directory=MEDIA,
        audio_mix=AudioMixSpec((AudioStem('narration',Path(voice.path)),),duration_seconds=20.4))
    command=plan.commands[0];argv=list(command.spec.argv);at=argv.index('-filter_complex')+1
    graph=argv[at]
    argv[at]=('[0:v]trim=start_frame=15:end_frame=627,setpts=PTS-STARTPTS,'
        'scale=1536:864:force_original_aspect_ratio=decrease:flags=lanczos,'
        'pad=1920:1080:192:0:color=0x081015,setsar=1,fps=30,'
        'drawbox=x=0:y=864:w=iw:h=2:color=0xCBA56A:t=fill,'
        +ass_burn_in_filter(caption)+',format=yuv420p[v];'+graph.split(';',1)[1])
    need(all(s not in argv[at] for s in ('tpad','minterpolate','atempo')),'Continuous real opening; no synthetic tail')
    return finish_plan(replace(plan,commands=(replace(command,spec=replace(command.spec,argv=tuple(argv))),),
        generated_files=(GeneratedTextFile(caption,ass),)),612)


def prepare(resources: Resources) -> tuple[WorkingCue,...]:
    pending = object_row(decode(PENDING.verify(524288)))
    need(pending['schema']=='xar.e04.final47.pending-source-recipe.v1'
         and pending['pending_cue_id']=='N03-02' and pending['pending_R05_acceptance'] is None,
         'Retained formal pending state is unchanged')
    original: dict[str,WorkingCue] = {}
    for value in rows(pending['known_actual_input_cues']):
        r=object_row(value)
        key=string(r['cue_id']); binding=object_row(r['binding'])
        frames=integer(object_row(binding['slot'])['frames'])
        plan=narration_only(plan_parse(r['render']))
        original[key]=WorkingCue(key,'mechanics',frames,plan,binding)
    need(len(original)==46 and set(original)==set(EXPECTED_CUES)-{'N03-02'},'All46 real mechanics input recipes')
    row=next(c for c in project_cues(resources.project) if c['id']=='N03-02')
    subs=object_row(row['subtitles']);voice=resources.voices['N03-02']
    cue=Cue('N03-02','E4-03',string(subs['zh-CN']),string(subs['en']),
            string(object_row(row['narration'])['zh-CN']))
    plan,timing=legacy_cue_plan(cue,resources.visuals['N03-02'],voice,None,
        Path(resources.cards['F04'].path),Path(resources.tools.music.media.path),
        MEDIA/'subtitles/N03-02.ass',work=MEDIA/'work',ffmpeg=Path(resources.tools.ffmpeg.media.path),font_path=FONT)
    plan=narration_only(plan)
    warning='规则说明｜低补给实体减员的实机因果镜头仍待验证'
    ass=overlay_ass(plan.generated_files[0].content,warning,timing.frames,warning=True)
    plan=replace(plan,generated_files=(GeneratedTextFile(MEDIA/'subtitles/N03-02.ass',ass),))
    original['N03-02']=WorkingCue('N03-02','r05_rule_only',timing.frames,finish_plan(plan,timing.frames),
        {'actual_R05_acceptance':None,'business_qualified':False,'source_narration':row,
         'voice':{'path':str(voice.native.path),'bytes':voice.native.size,'sha256':voice.native.sha},
         'card':resources.cards['F04'].wire(),'viewer_notice':warning})
    editorial=object_row(decode(EDITORIAL.verify(32768)))
    structure=object_row(decode(STRUCTURE.verify(32768)))
    probe_doc=object_row(decode(VOICE_PROBES.verify(16384)))
    voice_probes={string(r['cue_id']):r for r in (object_row(v) for v in rows(probe_doc['voice_probes']))}
    dynamic=object_row(decode(DYNAMIC.verify(8192)))
    visual=object_row(dynamic['visual'])
    need(dynamic['cue_id']=='C01-01' and integer(dynamic['actor_character_id'])==31254
         and integer(visual['source_first_frame'])==15
         and integer(visual['source_end_frame_exclusive'])==627
         and integer(visual['tail_hold_frames'])==0 and visual['preserve_complete_HUD'] is True,
         'Actual same-protagonist continuous 612-frame opening binding')
    opening_raw=FilePin.parse(dynamic['adopted_raw']);opening_raw.verify(32*1048576)
    opening_asset=RetainedAsset.parse({'path':opening_raw.path,'bytes':opening_raw.bytes,
        'retained_sha256':opening_raw.sha256,'identity':dynamic['raw_identity']})
    opening_asset.verify_identity()
    placements={string(r['cue_id']):object_row(r['visual'])
                for r in (object_row(v) for v in rows(structure['placements']))}
    need(editorial['schema']=='xar.e04.complete-review.editorial-source-inputs.v1', 'Pinned editorial source')
    cover=FilePin.parse(editorial['existing_cover']);cover.verify(1048576)
    outer: dict[str,WorkingCue] = {}
    for value in rows(editorial['cues']):
        r=object_row(value);key=string(r['cue_id'])
        if key not in OUTER_KEYS:
            continue
        frames=integer(r['frames']);vp=FilePin.parse(r['voice']);vp.verify(524288)
        narration=string(r['narration_zh']);english=string(r['subtitle_en'])
        # Measured voice frame clock is retained. No old encoded picture or mixed audio is consumed.
        observed=voice_probes[key]
        need(FilePin.parse(observed['voice'])==vp and integer(observed['actual_original_wait'])==0,
             'Actual original voice duration source binding')
        stdout=object_row(decode(string(observed['probe_stdout']).encode('utf-8')))
        need(object_row(stdout['format'])['duration']==observed['actual_duration_seconds'],
             'Measured duration is the exact original ffprobe result')
        seconds=Decimal(string(observed['actual_duration_seconds']))
        need(seconds.is_finite() and 0<seconds<=Decimal(frames)/30,'Real voice duration fits retained cue clock')
        voice=Voice(key,'editorial',hashlib.sha256(narration.encode()).hexdigest(),seconds,
                    int((seconds*30).to_integral_value(rounding='ROUND_CEILING')),
                    Pin(Path(vp.path),vp.bytes,vp.sha256),Pin(Path(vp.path),vp.bytes,vp.sha256),False)
        cue=Cue(key,'editorial',narration,english,narration)
        visual=placements[key]
        title=string(visual['title_zh'])
        ass=legacy_subtitles(cue,voice,frames,FONT)
        if key!='C01-01':
            ass=overlay_ass(ass,title,frames)
            ass=body_ass(ass,tuple(string(v) for v in rows(visual['body_zh'])),frames)
        kind: Kind='retained_ending' if key.startswith('C06') else 'retained_opening'
        plan=opening_plan(resources,opening_raw,vp,ass) if key=='C01-01' else still_plan(resources,key,cover,frames,ass,vp)
        outer[key]=WorkingCue(key,kind,frames,plan,
                              {'source_voice':vp.wire(),'source_editorial':EDITORIAL.wire(),
                               'title':title,'narration_zh':narration,'subtitle_en':english,
                               'actual_voice_seconds':str(seconds),
                               'actual_dynamic_source':DYNAMIC.wire() if key=='C01-01' else None})
    need(set(outer)==set(OUTER_KEYS),'All seven accepted outer source voices')
    def card(key: str,title: str,subtitle: str,frames: int,kind: Kind) -> WorkingCue:
        return WorkingCue(key,kind,frames,still_plan(resources,key,cover,frames,
            title_ass(key,title,subtitle,frames),None),{'title':title,'subtitle':subtitle,'cover':cover.wire()})
    result=[card('BRAND','CK3:战争机器','第四集 · 行军与后勤\\N大军为什么越走越少？\\NCK3 1.20.0.4 · 阿普利亚的罗贝尔',240,'brand'),
            outer['C01-01'],outer['C01-08']]
    for chapter,value in enumerate(rows(structure['chapters']),1):
        chapter_row=object_row(value)
        title=string(chapter_row['title_zh'])
        result.append(card(f'CHAPTER{chapter:02d}',f'{chapter:02d}   {title}',string(chapter_row['title_en']),90,'chapter'))
        prelude={1:'C01-04',3:'C01-05',5:'C01-06'}.get(chapter)
        if prelude is not None:
            result.append(outer[prelude])
        result.extend(original[k] for k in EXPECTED_CUES if k.startswith(f'N{chapter:02d}-'))
    result.extend((outer['C06-03'],outer['C06-10'],
        card('END','CK3:战争机器','补给、损耗、路线、军费｜把远征的四本账算清楚',240,'end_credit')))
    need(len(result)==62 and sum(c.cue_id.startswith('N') for c in result)==47,
         'Complete opening/six chapters/all47 mechanics/ending')
    need(tuple(c.cue_id for c in result if c.cue_id.startswith('N'))==EXPECTED_CUES,
         'All47 complete original mechanics order')
    return tuple(replace(c,plan=finish_plan(c.plan,c.frames)) for c in result)
