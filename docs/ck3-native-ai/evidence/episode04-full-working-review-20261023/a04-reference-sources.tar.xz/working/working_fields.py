"""Shared pure-stdlib producer/consumer document contract for this media admission."""
from __future__ import annotations

from typing import Literal, TypedDict

CAP_SCHEMA='xar.capacity.e04.full-working-review-media-admission.v1'
ROOT_SCHEMA='xar.root.e04.full-working-review-media-purpose.v1'


class PinDocument(TypedDict):
    path: str
    bytes: int
    sha256: str


class CommonMediaDocument(TypedDict):
    machine_id: Literal['desktop-3fevhd2-1c74096080']
    owner: Literal['/root/fullreview']
    exact_root: str
    onedrive_output: str
    maximum_new_C_allocated_bytes: Literal[524288000]
    maximum_new_D_allocated_bytes: Literal[0]
    hard_deadline_utc: Literal['2026-10-23T00:30:00Z']
    source_freeze: PinDocument
    Game_closed_proof: PinDocument
    Game_closed_actual: Literal[True]
    font: PinDocument
    allow_new_output_work_CAS_hardlinks: Literal[True]
    review_only: Literal[True]
    R05_actual_acceptance: None
    human1x: Literal[False]
    signoff: Literal[False]
    formal_final47_guards_unchanged: Literal[True]


class RootMediaPurposeDocument(CommonMediaDocument):
    schema: Literal['xar.root.e04.full-working-review-media-purpose.v1']


class MediaCardDocument(CommonMediaDocument):
    schema: Literal['xar.capacity.e04.full-working-review-media-admission.v1']
    admitted: Literal[True]
    budget_status: Literal['GREEN']
    full_working_review_execution_admitted: Literal[True]
    Root_independent_purpose: PinDocument


COMMON_FIELDS=frozenset(CommonMediaDocument.__required_keys__)
CARD_FIELDS=frozenset(MediaCardDocument.__required_keys__)
PURPOSE_FIELDS=frozenset(RootMediaPurposeDocument.__required_keys__)
