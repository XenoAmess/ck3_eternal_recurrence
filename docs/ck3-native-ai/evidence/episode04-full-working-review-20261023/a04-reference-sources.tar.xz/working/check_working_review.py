"""Pure real-producer/consumer checks; never starts a media process."""
from __future__ import annotations

from dataclasses import replace
import json
from pathlib import Path
from typing import Callable
from working_contract import (
    Resources, JsonValue, JsonObject, MEDIA, OLD_MEDIA, canonical, decode, json_domain,
    need, consume_cue, integer, object_row, SourceError, plan_parse, PENDING,
    validate_closed, MACHINE,
    SOURCE, CombinedBudget, SOURCE_DEADLINE, SOURCE_LIMIT, FilePin, rows, decimal64,
)
from working_recipe import prepare, narration_only


def rejected(call: Callable[[],object]) -> None:
    try:
        call()
    except (ValueError,TypeError,KeyError):
        return
    raise AssertionError('Invalid boundary accepted')


def checks() -> JsonObject:
    resources=Resources.load();cues=prepare(resources)
    need(len(cues)==62 and sum(c.frames for c in cues)==50138,'Complete actual-source duration')
    for cue in cues:
        consume_cue(decode(canonical(cue.wire())),cue)
        need(cue.plan.final_output.is_relative_to(MEDIA),'Exact independent new output')
        argv=cue.plan.commands[0].spec.argv
        graph=argv[argv.index('-filter_complex')+1]
        need(OLD_MEDIA.as_posix()[2:] not in graph and 'amix=inputs=2' not in graph,
             'Rebased captions and no per-cue doubled music')
        need('minterpolate' not in graph and 'atempo' not in graph,'Unchanged real voice/raw speed')
    first=cues[0]
    actual=first.wire()
    rejected(lambda:consume_cue({**actual,'frames':True},first))
    rejected(lambda:consume_cue({k:v for k,v in actual.items() if k!='frames'},first))
    rejected(lambda:consume_cue({**actual,'frame_count':first.frames},first))
    rejected(lambda:consume_cue({**actual,'frames':float(first.frames)},first))
    rejected(lambda:consume_cue({**actual,'evidence':None},first))
    rejected(lambda:consume_cue({**actual,'evidence':{}},first))
    rejected(lambda:integer(True));rejected(lambda:integer(30.0))
    closure=object_row(decode(Path('C:/ck3-e04-resume-20261023-a01/root/ROOT-GAME-CLOSED.actual-a01.json').read_bytes()))
    validate_closed(closure)
    bad_values: tuple[JsonValue,...]=(None,{},False)
    for bad in bad_values:
        rejected(lambda:validate_closed({**closure,'current_screen_owners':bad}))
    rejected(lambda:validate_closed({**closure,'Game_closed_actual':1}))
    rejected(lambda:validate_closed({**closure,'native_census':{'original_wait':False}}))
    rejected(lambda:validate_closed({k:v for k,v in closure.items() if k!='current_game_media_processes'}))
    r05=next(c for c in cues if c.cue_id=='N03-02')
    need(r05.kind=='r05_rule_only' and r05.evidence['actual_R05_acceptance'] is None
         and r05.evidence['business_qualified'] is False
         and '实机因果镜头仍待验证' in r05.plan.generated_files[0].content,
         'Honest review-only R05 rule and persistent viewer notice')
    need(next(c for c in cues if c.cue_id=='N05-01').frames==1597
         and next(c for c in cues if c.cue_id=='N06-08').frames==871,
         'Final N05 voice and new accepted R08 retained')
    pending=object_row(decode(PENDING.verify(524288)))
    need(pending['pending_R05_acceptance'] is None and pending['complete_actual_recipe'] is False,
         'Frozen formal R05 gates unchanged')
    need(cues[0].cue_id=='BRAND' and cues[1].cue_id=='C01-01' and cues[2].cue_id=='C01-08'
         and tuple(c.cue_id for c in cues[-3:])==('C06-03','C06-10','END'),
         'Complete opening and ending')
    return {'status':'PASS','groups':['complete62','all47new','JSONroundtrip',
        'strict_wrong_missing_extra_fields','bool_float_rejected','R05honesty',
        'N05final_R08actual','singlemusic_no_speedchange','caption_output_rebase','opening_ending']}


def successor_checks() -> JsonObject:
    import sys
    from clock_diagnostic import (
        retained_products, validate_card, DIAGNOSTIC_ROOT, DIAGNOSTIC_LIMIT,
        DIAGNOSTIC_MOVIE_CAP, ROOT_PURPOSE, CLOCK_SCHEMA,
    )
    from produce_working_review import movie_plan
    from working_contract import WorkingOwner, DEADLINE_TEXT
    attempt=sys.argv[1]
    path=SOURCE/('NATIVE-IDENTITY-REGRESSION.'+attempt+'.actual.json')
    report=object_row(decode(path.read_bytes()))
    need(report['machine_id']==MACHINE and report['actual_two_aliases_one_file'] is True
         and report['underfunded_guard_rejected'] is True,'Actual Native producer result')
    first=FilePin.parse(report['first']);second=FilePin.parse(report['second'])
    first.verify(16384);second.verify(16384)
    a=Path(first.path).stat();b=Path(second.path).stat();identity=object_row(report['identity'])
    need((str(a.st_dev),str(a.st_ino),str(a.st_mtime_ns))==
         (decimal64(identity['st_dev']),decimal64(identity['st_ino']),decimal64(identity['mtime_ns']))
         and (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino) and a.st_nlink==b.st_nlink==2,
         'Real Native identity roundtrip and source consumer')
    actual=CombinedBudget(Path(first.path).parent.parent,SOURCE_DEADLINE,SOURCE_LIMIT).snapshot()
    need(integer(actual['unique_files'])==1 and integer(actual['hardlink_aliases'])==1,
         'Actual aliases are counted once by the real successor consumer')
    card: JsonObject={'schema':CLOCK_SCHEMA,'machine_id':MACHINE,'owner':'/root/fullreview',
        'admitted':True,'budget_status':'GREEN','exact_root':str(DIAGNOSTIC_ROOT),
        'maximum_new_C_allocated_bytes':DIAGNOSTIC_LIMIT,'maximum_new_D_allocated_bytes':0,
        'hard_deadline_utc':DEADLINE_TEXT,'Root_independent_purpose':ROOT_PURPOSE.wire(),
        'diagnostic_source_freeze':{'path':str(SOURCE/'SOURCE-FREEZE.actual.json'),
                                   'bytes':1,'sha256':'0'*64}}
    need(canonical(validate_card(decode(canonical(card))))==canonical(card),'Clock card real parser JSON roundtrip')
    rejected(lambda:validate_card({**card,'maximum_new_D_allocated_bytes':False}))
    rejected(lambda:validate_card({**card,'maximum_new_C_allocated_bytes':float(DIAGNOSTIC_LIMIT)}))
    rejected(lambda:validate_card({k:v for k,v in card.items() if k!='diagnostic_source_freeze'}))
    rejected(lambda:validate_card({**card,'alias_freeze':None}))
    resources=Resources.load();products=retained_products(resources)
    owner=WorkingOwner(CombinedBudget(DIAGNOSTIC_ROOT,SOURCE_DEADLINE,DIAGNOSTIC_LIMIT),resources)
    plan=movie_plan(owner,products,key='first4-smoke',output_cap=DIAGNOSTIC_MOVIE_CAP)
    argv=plan.commands[0].spec.argv
    need('-copyts' in argv and '-start_at_zero' not in argv
         and argv[argv.index('-avoid_negative_ts')+1]=='disabled'
         and argv[argv.index('-fs')+1]==str(DIAGNOSTIC_MOVIE_CAP-1048576)
         and plan.final_output.is_relative_to(DIAGNOSTIC_ROOT)
         and all(g.path.is_relative_to(DIAGNOSTIC_ROOT) for g in plan.generated_files),
         'Shared actual production clock plan in independent finite diagnostic root')
    return {'status':'PASS','groups':['real_Windows_Path_stat_identity','actual_two_alias_Native_allocation',
        'real_Native_identity_JSON_roundtrip','actual_underfunded_guard_rejection',
        'readonly_real_four_product_consumer','clock_card_JSON_and_negative_types','shared_movie_clock_plan']}


if __name__=='__main__':
    print(json.dumps(successor_checks(),ensure_ascii=False))
