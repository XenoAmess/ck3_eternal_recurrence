"""Finalize the real a04 full62 with an exact 48K sample clock; no cue re-encoding."""
from __future__ import annotations

from dataclasses import replace
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

from working_contract import (
    BASE, MEDIA, ONEDRIVE, FULL_MAX, SOURCE, MACHINE, FilePin, JsonObject, JsonValue,
    Resources, WorkingCue, WorkingOwner, MediaAdmission, CombinedBudget,
    canonical, decode, integer, json_domain, need, now, object_row, pin, rows,
    validate_encoded_probe, link_new_output,
)
from working_recipe import prepare
from produce_working_review import (
    Product, Request, META_MAX, movie_plan, actual_probe, packet_audit, audio_audit,
    extract_frame, contact_sheets,
)
from produce_final47 import custody_good
from clock_diagnostic import validate_wait

RETAINED_ROOT=BASE/'fullreview-media-a04'
RETAINED_TIMELINE=FilePin(str(RETAINED_ROOT/'FULL-WORKING-REVIEW-TIMELINE.actual.json'),240907,
    '1ac1b2a178a56fa73eb364210dad22626286c2ad6dc9fb4cfa203954d9755374')
RETAINED_CLOSURE=FilePin(str(RETAINED_ROOT/'EXECUTOR-OWNER-CLOSED.actual.json'),23700,
    'b72a518057fd77793035ed08d682bb3003ca38fe7f1b1f7358ab5215004b52ef')
PRIOR_ROOT_VISUAL=FilePin(str(BASE/'root/ROOT-FULLREVIEW-PREVIEW-ACCEPTANCE.actual-a01.json'),1322,
    'ef3f3c3aec05f941b2cccc0d1e1575fe7b4da9b3d21ce56fb0367204e6791658')
PRIOR_PREVIEW_READY=FilePin(str(RETAINED_ROOT/'PREVIEW-READY.actual.json'),1300,
    'd0608abb3aba0642a953af6c7084c1e9e4402bdaa164c02206f2ea518687b5fe')
NEW_PEAK_MAX=FULL_MAX*2+META_MAX
INPUT_PINS=(RETAINED_TIMELINE,RETAINED_CLOSURE,PRIOR_ROOT_VISUAL,PRIOR_PREVIEW_READY)


def bound_wait(ref: FilePin,operation: str,key: str) -> None:
    validate_wait(ref)
    r=object_row(decode(ref.verify(32768)))
    need(r['operation']==operation and r['cue_id']==key,'Exact actual retained process purpose/cue')


def consume_entry(value: JsonValue,cue: WorkingCue,start: int) -> Product:
    r=object_row(value,{'cue','start_frame','end_frame','work','native_CAS',
        'actual_encode_original_wait','actual_decode_probe'})
    c=object_row(r['cue'],{'cue_id','kind','frames','evidence','ASS_sha256','output'})
    work=FilePin.parse(r['work']);native=FilePin.parse(r['native_CAS'])
    need(type(start) is int and integer(r['start_frame'])==start
         and integer(r['end_frame'])==start+cue.frames and integer(c['frames'])==cue.frames
         and Path(work.path)==RETAINED_ROOT/'work'/(cue.cue_id+'.mp4')
         and Path(native.path)==RETAINED_ROOT/'native/derived/sha256'/work.sha256[:2]/(work.sha256+'.mp4')
         and canonical(c)==canonical({**cue.wire(),'output':work.path}),
         'Exact actual a04 cue/ASS/source binding and complete persisted frame clock')
    work.verify(18*1048576);native.verify(18*1048576)
    a=Path(work.path).stat(follow_symlinks=False);b=Path(native.path).stat(follow_symlinks=False)
    need((work.bytes,work.sha256)==(native.bytes,native.sha256)
         and not (a.st_file_attributes|b.st_file_attributes)&0x400
         and a.st_dev>0 and a.st_ino>0 and (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino)
         and a.st_nlink==b.st_nlink==2,'Readonly ordinary a04 media with exact closed two-name identity')
    waited=FilePin.parse(r['actual_encode_original_wait']);bound_wait(waited,'cue_encode',cue.cue_id)
    probe=FilePin.parse(r['actual_decode_probe']);p=object_row(decode(probe.verify(8192)))
    need(p['machine_id']==MACHINE and p['actual_full_decode'] is True
         and integer(p['expected_frames'])==cue.frames and FilePin.parse(p['media'])==work,
         'Retained real per-cue full decode')
    observed=object_row(p['observed']);validate_encoded_probe(observed,cue.frames)
    video=next(object_row(v) for v in rows(observed['streams']) if object_row(v).get('codec_type')=='video')
    need(video['pix_fmt']=='yuv420p' and video['color_range']=='tv'
         and video['color_space']==video['color_transfer']==video['color_primaries']=='bt709',
         'Actual retained limited BT709')
    bound_wait(FilePin.parse(p['original_wait']),'cue_decode_probe',cue.cue_id)
    retained=replace(cue,plan=replace(cue.plan,final_output=Path(work.path)))
    product=Product(retained,work,native,waited,probe)
    need(canonical(product.wire(start))==canonical(r),'Actual timeline producer/consumer JSON roundtrip')
    return product


def readonly_products(resources: Resources) -> tuple[Product,...]:
    closure=object_row(decode(RETAINED_CLOSURE.verify(32768)))
    need(closure['machine_id']==MACHINE and closure['failed'] is True
         and integer(closure['owned_Popen_remaining'])==0
         and closure['all_original_children_wait0_Job0'] is True
         and len(rows(closure['actual_custodies']))==139
         and all(integer(v)==0 for v in rows(closure['actual_original_waits']))
         and all(custody_good(object_row(v)) for v in rows(closure['actual_custodies'])),
         'Actual a04 failed whole audit retained; all original children closed')
    visual=object_row(decode(PRIOR_ROOT_VISUAL.verify(8192)),
        {'schema','machine_id','observed_at_utc','reviewer','accepted','preview_ready','direct_reviewed_images'})
    ready=object_row(decode(PRIOR_PREVIEW_READY.verify(8192)))
    need(visual['schema']=='xar.root.e04.full-working-review.preview-acceptance.v1'
         and visual['machine_id']==MACHINE and visual['reviewer']=='/root' and visual['accepted'] is True
         and FilePin.parse(visual['preview_ready'])==PRIOR_PREVIEW_READY
         and ready['machine_id']==MACHINE and ready['all_preview_children_wait0_Job0'] is True
         and canonical(visual['direct_reviewed_images'])==canonical(ready['previews']),
         'Prior Root direct review applies to these immutable same cue pixels')
    for v in rows(ready['previews']):
        FilePin.parse(v).verify(4*1048576)
    timeline=object_row(decode(RETAINED_TIMELINE.verify(262144)),
        {'schema','machine_id','fps','total_frames','entries','R05_actual_acceptance','review_only','human1x','signoff'})
    need(timeline['schema']=='xar.e04.full-working-review.actual-timeline.v1'
         and timeline['machine_id']==MACHINE and integer(timeline['fps'])==30
         and integer(timeline['total_frames'])==50138 and timeline['R05_actual_acceptance'] is None
         and timeline['review_only'] is True and timeline['human1x'] is False and timeline['signoff'] is False,
         'Complete review-only actual a04 timeline, with no human or R05 signoff')
    expected=prepare(resources);entries=rows(timeline['entries'])
    need(len(expected)==len(entries)==62,'All real a04 full62 inputs')
    result: list[Product]=[];position=0
    for cue,value in zip(expected,entries,strict=True):
        result.append(consume_entry(value,cue,position));position+=cue.frames
    need(position==50138 and len({p.cue.cue_id for p in result})==62
         and sum(p.cue.cue_id.startswith('N') for p in result)==47,
         'Actual all47 newly encoded mechanics and complete outer structure')
    return tuple(result)


def enforce_new_allocations(owner: WorkingOwner,movie: FilePin) -> None:
    copy_bytes=ONEDRIVE.stat().st_size if ONEDRIVE.exists() else 0
    actual=integer(owner.budget.snapshot()['allocated_bytes'])
    overhead=actual-movie.bytes-copy_bytes
    need(movie.bytes<=FULL_MAX and copy_bytes<=FULL_MAX and 0<=overhead<=META_MAX
         and actual<=NEW_PEAK_MAX,'New owned whole/copy/QA only; no subtraction of readonly old cue bytes')


def execute(card: FilePin) -> FilePin:
    admission=MediaAdmission.parse(card)
    # The admitted500MiB is narrowed further for this finalization:144+144+32MiB.
    budget=CombinedBudget(MEDIA,admission.budget.deadline,NEW_PEAK_MAX)
    resources=Resources.load();products=readonly_products(resources)
    frozen=object_row(decode(admission.freeze.verify(65536)))
    recipe=object_row(decode(FilePin.parse(frozen['recipe']).verify(262144)))
    need(recipe['execution_mode']=='readonly_actual_a04_full62_and_new_final_remix'
         and canonical(recipe['cues'])==canonical([p.cue.wire() for p in products]),
         'Frozen actual readonly62 recipe and sole final-remix mode')
    budget.guard(MEDIA/'temp/reserve',8192);(MEDIA/'temp').mkdir(parents=True,exist_ok=False)
    budget.json('EXECUTOR-ONCE.actual.json',{'machine_id':MACHINE,'observed_at_utc':now(),
        'financial_card':card.wire(),'Root_purpose':admission.purpose.wire(),'source_freeze':admission.freeze.wire(),
        'readonly_actual_timeline':RETAINED_TIMELINE.wire(),'Root_prior_visual_acceptance':PRIOR_ROOT_VISUAL.wire(),
        'new_cue_encodes':0,'new_owned_peak_upper_bound_bytes':NEW_PEAK_MAX,
        'review_only':True,'R05_actual_acceptance':None,'human1x':False,'signoff':False})
    owner=WorkingOwner(budget,resources);failure: str|None=None
    try:
        owner.idle()
        timeline=budget.json('FULL-WORKING-REVIEW-TIMELINE.actual.json',
            object_row(decode(RETAINED_TIMELINE.verify(262144))))
        plan=movie_plan(owner,products)
        joined=owner.render(plan,Request('movie_concat','full-working-review',600,FULL_MAX))
        movie=pin(plan.final_output)
        # Fast strict clock and clipping checks precede the complete video decode.
        clocks=packet_audit(owner,movie,50138)
        print('ACTUAL FULL PACKET CLOCK',clocks.path,flush=True)
        audio=audio_audit(owner,movie)
        print('ACTUAL FULL AUDIO',audio.path,flush=True)
        probe=actual_probe(owner,movie,50138,'full-working-review',movie=True)
        native=link_new_output(budget,movie,FULL_MAX)
        enforce_new_allocations(owner,movie)
        images: list[JsonObject]=[];position=0
        for product in products:
            frame=position+min(30,product.cue.frames-1)
            photo=extract_frame(owner,movie,'movie-'+product.cue.cue_id,frame)
            images.append({'cue_id':product.cue.cue_id,'frame':frame,'source':photo.wire()})
            position+=product.cue.frames
        sheets=contact_sheets(owner,tuple(images));enforce_new_allocations(owner,movie)
        budget.guard(MEDIA/'onedrive-copy-reserve',movie.bytes)
        with Path(movie.path).open('rb') as source,ONEDRIVE.open('xb') as destination:
            shutil.copyfileobj(source,destination,1024*1024)
            destination.flush();os.fsync(destination.fileno())
        copied=pin(ONEDRIVE)
        need((copied.bytes,copied.sha256)==(movie.bytes,movie.sha256),'Actual new OneDrive local copy full SHA')
        enforce_new_allocations(owner,movie)
        return budget.json('FULL-WORKING-REVIEW-ACTUAL-METADATA.actual.json',
            {'schema':'xar.e04.full-working-review.actual-movie.v1','machine_id':MACHINE,
             'observed_at_utc':now(),'total_frames':50138,'fps':30,'cue_count':62,
             'execution_mode':'readonly_actual_a04_full62_and_new_final_remix',
             'cue_encoding_attempt':str(RETAINED_ROOT),'cue_encodes_in_this_finalization':0,
             'retained_actual_timeline':RETAINED_TIMELINE.wire(),'prior_Root_visual_acceptance':PRIOR_ROOT_VISUAL.wire(),
             'movie':movie.wire(),'native_CAS':native.wire(),'onedrive_local_copy':copied.wire(),
             'actual_concat_wait':joined.wait_pin.wire(),'timeline':timeline.wire(),'full_decode':probe.wire(),
             'packet_clocks':clocks.wire(),'full_audio_statistics':audio.wire(),
             'sampled_movie_frames':json_domain(images),'contact_sheets':[p.wire() for p in sheets],
             'all47_mechanics_new_encodes':True,'complete_opening_chapters_ending':True,
             'single_continuous_music_bed':True,'R05_actual_acceptance':None,'R05_business_qualified':False,
             'review_only':True,'human1x':False,'signoff':False,'onedrive_cloud_sync':'PENDING_CLIENT_READBACK',
             'new_owned_peak_upper_bound_bytes':NEW_PEAK_MAX,
             'readonly_input_cue_bytes':sum(p.work.bytes for p in products),
             'actual_native_allocation_before_metadata':budget.snapshot()})
    except BaseException as error:
        failure=type(error).__name__+': '+str(error)[:2500]
        budget.json('FAILED-PRESERVED.actual.json',{'machine_id':MACHINE,'observed_at_utc':now(),
            'diagnostic':failure,'readonly_actual_cues':62,'partials_retained':True,'no_retry':True})
        raise
    finally:
        budget.json('EXECUTOR-OWNER-CLOSED.actual.json',{'machine_id':MACHINE,'observed_at_utc':now(),
            'failed':failure is not None,'owner_error':failure,'owned_Popen_remaining':owner.children,
            'actual_original_waits':json_domain(owner.codes),'actual_custodies':owner.custodies,
            'all_original_children_wait0_Job0':bool(owner.custodies) and all(custody_good(object_row(c)) for c in owner.custodies),
            'native_allocation_before_receipt':budget.snapshot(),'human1x':False,'signoff':False})


def main() -> None:
    need(len(sys.argv)==4 and sys.argv[1]=='execute','One explicitly admitted typed finalization')
    card=pin(Path(sys.argv[2]));need(card.sha256==sys.argv[3],'Exact current finalization admission SHA')
    print(json.dumps(execute(card).wire(),ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
