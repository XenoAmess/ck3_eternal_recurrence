"""Append-only R192 CUnit/CArmy correction; assemble existing packets without SDK."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
BASE=Path(__file__).parent/'root_ui_frame.py'
data=BASE.read_bytes()
if len(data)!=12440 or hashlib.sha256(data).hexdigest()!='b4be3f7eb26d2f4d7b1545ce9c24cfdb2a457e363203e72dbcd4959d485fc8be':
    raise RuntimeError('original frozen UI helper changed')
spec=importlib.util.spec_from_file_location('r192_original_ui_frame',BASE)
old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
s=old.s
BASELINE={'path':'D:/workspace/ck3_native_war_ai_promo_work/e04-r192-r09-forward-a01/r09-root-controller-a01/baseline-ENDPOINT.actual.json',
 'bytes':71272,'sha256':'2dbb679dd967632f9869f53d56ce96a141ccbba879678faf1b2c3901b410b3e8'}
def existing():
    # Scope/allocator/source/capacity qualification is metadata only. No process
    # inspection, SDK request or desktop operation belongs to this assembly.
    c,repo,scene,run,raw=s.config(old.SCOPE);proof=s.load_pin(c['identity']);baseline=s.load_pin(BASELINE)
    s.need(baseline.get('machine_id')==c['machine_id'] and baseline.get('run_id')==run.name
       and baseline.get('source_head')==c['source_head'] and baseline['frozen_observable'].get('date_raw')==c['expected_start_date_raw']
       and proof.get('machine_id')==c['machine_id'] and proof.get('run_id')==run.name
       and proof.get('source_head')==c['source_head'] and proof.get('initial_date_raw')==c['expected_start_date_raw'],
       'actual baseline/identity scope differs')
    rows=[r['army'] for r in baseline['frozen_observable']['armies'] if r.get('army',{}).get('army_id')==c['army_id']]
    s.need(len(rows)==1 and rows[0].get('status')=='available' and type(rows[0].get('native_carmy_id')) is int
       and rows[0]['native_carmy_id']>0,'actual baseline CUnit-to-CArmy mapping unavailable')
    native_id=rows[0]['native_carmy_id']
    classified=baseline.get('current_refill_classification',{}).get(str(c['army_id']),{})
    s.need(classified.get('army_id')==c['army_id'] and classified.get('native_carmy_id')==native_id,
           'baseline army and current classification native mapping disagree')
    prefix='r192-ui-verify-a02';packets=[];pins=[]
    for label,tool,args in [('03-independent-before','ck3_take_snapshot',{}),
       ('04-independent-window','ck3_query_ingame_ui_window_v1',None),('05-independent-after','ck3_take_snapshot',{})]:
        p=run/'responses'/(prefix+'-'+label+'.json');pin=s.pin(p);packet=s.load_pin(pin)
        if args is None:args={'window_kind':'army','expected_revision':packets[0]['body']['revision']}
        s.need(packet.get('machine_id')==c['machine_id'] and packet.get('is_error') is False
           and packet.get('request')=={'request_id':prefix+'-'+label,'tool':tool,'arguments':args},
           'actual independent original packet binding differs')
        packets.append(packet);pins.append(pin)
    before,body,after=(p['body'] for p in packets)
    old.bind(c,proof,before);old.bind(c,proof,after)
    s.need(before['snapshot_id']==after['snapshot_id']==body.get('queried_snapshot_id')
       and before['revision']==after['revision']==body.get('queried_revision')
       and before['native_revision']==after['native_revision']==body.get('native_revision')==body.get('queried_native_revision')
       and body.get('queried_connection_generation')==proof['connection_generation']
       and body.get('episode_run_id')==proof['episode_run_id']
       and body.get('accepted') is True and body.get('available') is True and body.get('effective_visible') is True
       and body.get('window_kind')=='army' and body.get('current_subject_id')==c['army_id']
       and body.get('native_army_id')==native_id and body.get('owner_character_id')==body.get('played_character_id')==c['actor_id']
       and body.get('paused') is True and body.get('date_raw')==c['expected_start_date_raw'],
       'actual CUnit subject/CArmy mapped native identity/frame/readback differs')
    claim_path=scene/'r192-ui-single-select.claim.json';claim=s.small_json(claim_path)
    s.need(claim.get('identity')==c['identity'] and claim.get('run_id')==run.name,'original single Select claim differs')
    select_pin=s.pin(run/'responses'/(claim['selection_request_id']+'.json'));select=s.load_pin(select_pin)
    s.need(select.get('is_error') is False and select.get('request',{}).get('tool')=='ck3_select_army_ui_v1'
       and select['request']['arguments'].get('subject_army_id')==c['army_id']
       and select.get('body',{}).get('dispatch_invoked') is True,'actual single native Select original absent')
    row={'machine_id':c['machine_id'],'observed_at_utc':old.rt.now(),'source_head':c['source_head'],'run_id':run.name,
        'identity':c['identity'],'scope':s.pin(old.SCOPE),'selected_army_id':c['army_id'],'date_raw':c['expected_start_date_raw'],
        'native_army93_visible_subject_verified':True,'native_carmy_id_from_actual_baseline':native_id,'baseline':BASELINE,
        'baseline_mapping_path':'frozen_observable.armies[*].army where army_id equals scope.army_id; independently matches current_refill_classification',
        'native_army_readback':pins[1],'before_snapshot':pins[0],'after_snapshot':pins[2],
        'selection_claim':s.pin(claim_path),'native_selection_response':select_pin,
        'method':'pure-file assembly of already successful native Select and independent true UI readback; CUnit subject and CArmy ID kept distinct',
        'correction':'old helper incorrectly required CUnit ID == CArmy ID; prior false diagnostics remain unchanged',
        'Root_reports_no_counter_click':True,'Root_statement_source':'parent task reports native Select opened Army250; no Root click performed',
        'desktop_input_by_this_script':False,'SDK_calls_by_this_script':0,'new_live_observation':False,'time_advanced':False,
        'business_or_dynamic_qualified':False}
    return scene,row
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('stage',choices=['check-existing','assemble','capture','review'])
    p.add_argument('--execute-file-assembly',action='store_true');p.add_argument('--execute-live',action='store_true')
    p.add_argument('--stem',default='r192-pre-film-frame-a01');p.add_argument('--frame',type=Path)
    p.add_argument('--root-reviewed-paused-army93-foreground',action='store_true');a=p.parse_args()
    if a.stage in ['check-existing','assemble']:
        scene,row=existing()
        if a.stage=='check-existing':print(json.dumps({'validation':'PASS_ACTUAL_CUNIT_CARMY_MAPPING_AND_THREE_ORIGINALS','native_carmy_id':row['native_carmy_id_from_actual_baseline'],'SDK_calls':0,'desktop_calls':0}));return
        s.need(a.execute_file_assembly,'Root explicit --execute-file-assembly required')
        target=scene/'ARMY93-UI-SELECT.actual-a01.json';s.write_new(target,row)
        supplement=scene/'R192-UI-CUNIT-CARMY-CORRECTION.actual-a02.json'
        s.write_new(supplement,{**row,'sealed_UI_receipt':s.pin(target),'old_helper':s.pin(BASE)})
        print(json.dumps({'army_ui_receipt':s.pin(target),'correction':s.pin(supplement)}))
    elif a.stage=='capture':s.need(a.execute_live,'Root explicit --execute-live required');old.capture(a.stem)
    else:old.review(a.frame or old.SCOPE.parent/'r192-pre-film-frame-a01.actual.json',a.root_reviewed_paused_army93_foreground)
if __name__=='__main__':main()
