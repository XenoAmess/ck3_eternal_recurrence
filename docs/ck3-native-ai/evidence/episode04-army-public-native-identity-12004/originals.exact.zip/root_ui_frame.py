"""Thin Root-only R192 presentation and original-frame gates; import performs no live action."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,importlib.util,json,re,sys,time
sys.dont_write_bytecode=True
sys.path.insert(0,'C:/ck3-e04-resume-20261015-a01/r09-runtime-adapter-prep-a02')
import root_runtime as rt
s=rt.scope
SCOPE=Path('D:/workspace/ck3_native_war_ai_promo_work/e04-r192-r09-forward-a01/R09-IDENTITY-SCOPE.actual-a01.json')
def context():
    c,repo,scene,run,raw=s.config(SCOPE);proof=s.load_pin(c['identity'])
    s.need(c['army_id']==93 and c['actor_id']==31254 and c['expected_start_date_raw']==53146632
       and run.name.endswith('--R0192') and proof.get('machine_id')==c['machine_id']
       and proof.get('run_id')==run.name and proof.get('source_head')==c['source_head']
       and proof.get('initial_date_raw')==c['expected_start_date_raw']
       and proof.get('actual_runtime_character_full_id')==c['actor_id'], 'actual R192 identity/scope differs')
    s.need(s.creation_filetime(proof['pid'])==proof['process_creation_filetime_100ns'],'owned PID reused')
    s.capacity(c,measure=False)
    return c,proof,repo,scene,run
def bind(c,proof,b):
    d=b.get('diagnostics') or {};p=b.get('played_character') or {}
    s.need(b.get('paused') is True and b.get('map_ready') is True and b.get('date_raw')==53146632
       and b.get('episode_run_id')==proof['episode_run_id'] and b.get('episode_character_id')==31254
       and p.get('character_id')==31254 and p.get('alive') is True
       and d.get('bridge_pid')==proof['pid'] and d.get('connection_generation')==proof['connection_generation']
       and not b.get('active_event') and not b.get('pending_character_interaction'),'paused identity/date/modal frame differs')
    rows=[r for r in b.get('player_armies',[]) if r.get('army_id')==93]
    s.need(len(rows)==1 and rows[0].get('owner_character_id')==31254 and rows[0].get('controllable') is True
       and rows[0].get('in_combat') is False and rows[0].get('retreating') is False,'watched Army93 unavailable')
def relay(c,proof,run,prefix):
    deadline=time.monotonic()+60;pins=[]
    def request(label,tool,args):
        s.need(time.monotonic()<deadline,'presentation common60s exhausted; no replay')
        s.need(s.creation_filetime(proof['pid'])==proof['process_creation_filetime_100ns'],'owned PID reused')
        body=s.request(run,prefix+'-'+label,tool,args,min(20,deadline-time.monotonic()))
        pin=s.pin(run/'responses'/(prefix+'-'+label+'.json'));packet=s.load_pin(pin)
        s.need(packet.get('machine_id')==c['machine_id'] and packet.get('request')=={
            'request_id':prefix+'-'+label,'tool':tool,'arguments':args},'original presentation response differs')
        pins.append(pin);return body
    return request,pins
def selection(mode,attempt):
    c,proof,repo,scene,run=context();prefix='r192-ui-'+mode+'-'+attempt
    claim=scene/'r192-ui-single-select.claim.json';request,pins=relay(c,proof,run,prefix)
    if mode=='select':
        s.need(not claim.exists(),'original Select claim exists; never replay mutation')
        s.write_new(claim,{'machine_id':c['machine_id'],'observed_at_utc':rt.now(),'run_id':run.name,
            'identity':c['identity'],'scope':s.pin(SCOPE),'selection_request_id':prefix+'-02-select-once'})
        before=request('01-before','ck3_take_snapshot',{});bind(c,proof,before)
        request('02-select-once','ck3_select_army_ui_v1',{'subject_army_id':93,'expected_revision':before['revision']})
    else:
        prior=s.small_json(claim)
        s.need(prior.get('identity')==c['identity'] and prior.get('run_id')==run.name
           and (run/'requests'/(prior['selection_request_id']+'.json')).is_file(),'actual original Select submission required; verify never selects')
    before=request('03-independent-before','ck3_take_snapshot',{});bind(c,proof,before)
    body=request('04-independent-window','ck3_query_ingame_ui_window_v1',{'window_kind':'army','expected_revision':before['revision']})
    after=request('05-independent-after','ck3_take_snapshot',{});bind(c,proof,after)
    visible=(body.get('accepted') is True and body.get('available') is True and body.get('effective_visible') is True
       and body.get('window_kind')=='army' and body.get('native_army_id')==body.get('current_subject_id')==93
       and body.get('owner_character_id')==body.get('played_character_id')==31254 and body.get('paused') is True
       and body.get('date_raw')==53146632 and body.get('native_revision')==before['native_revision']==after['native_revision'])
    row={'machine_id':c['machine_id'],'observed_at_utc':rt.now(),'source_head':c['source_head'],'run_id':run.name,
        'identity':c['identity'],'scope':s.pin(SCOPE),'selected_army_id':93,'date_raw':53146632,
        'native_army93_visible_subject_verified':visible,'native_army_readback':pins[-2],
        'before_snapshot':pins[-3],'after_snapshot':pins[-1],'all_request_pins':pins,'selection_claim':s.pin(claim),
        'native_only_UI_qualification':False,'qualification_note':'actual visible postcondition only; Root may have separately used a guarded counter click',
        'desktop_input_by_this_script':False,'time_advanced':False}
    target=scene/(prefix+'.actual.json');s.write_new(target,row)
    if visible:
        sealed=scene/'ARMY93-UI-SELECT.actual-a01.json';s.write_new(sealed,row)
        print(json.dumps({'army_ui_receipt':s.pin(sealed),'visible':True}))
    else:print(json.dumps({'independent_readback':s.pin(target),'visible':False,'next':'Root direct original and guarded counter click if needed; verify sends no new Select'}))
def camera(mode,attempt):
    c,proof,repo,scene,run=context();prefix='r192-camera-'+mode+'-'+attempt;request,pins=relay(c,proof,run,prefix)
    if mode=='center-realm':
        claim=scene/'r192-ui-single-realm-center.claim.json';s.need(not claim.exists(),'realm camera claim exists; never repeat unknown action')
        s.write_new(claim,{'machine_id':c['machine_id'],'observed_at_utc':rt.now(),'scope':s.pin(SCOPE)})
        before=request('01-before','ck3_take_snapshot',{});bind(c,proof,before)
        request('02-center-once','ck3_center_map_on_player_realm_v1',{'expected_revision':before['revision']})
    status=request('03-status','ck3_realm_camera_status_v1',{})
    path=scene/(prefix+'.actual.json');s.write_new(path,{'machine_id':c['machine_id'],'observed_at_utc':rt.now(),
        'run_id':run.name,'identity':c['identity'],'source_head':c['source_head'],'scope':s.pin(SCOPE),
        'request_pins':pins,'native_status':status,'visual_army_position_proven':False,'ACK_is_not_visual_coverage':True})
    print(json.dumps({'camera_receipt':s.pin(path),'status':status}))
def capture(stem):
    c,proof,repo,scene,run=context();s.need(re.fullmatch('[A-Za-z0-9_-]{1,80}',stem) is not None,'unique stem required')
    task=s.small_json(Path(c['screen']['task_bus'])/'tasks'/(c['screen']['task_id']+'.json'))
    s.need(task.get('state')=='running' and 'ck3-screen:acquired' in task.get('resources',[])
       and task.get('git',{}).get('head')==c['source_head'],'current exclusive source-bound screen absent')
    sys.path.insert(0,str(repo/'promo/ck3_native_war_ai/episode-04-march-logistics/tools'))
    from capture_recorder import inspect_owned_client
    import pyautogui,win32gui,win32process
    before=inspect_owned_client(proof['pid']);desktop=list(pyautogui.size());shot=pyautogui.screenshot();after=inspect_owned_client(proof['pid'])
    keys=['owned_ck3_pid','owned_ck3_create_time','hwnd','desktop','client_screen_rect','output_size','occluding_windows']
    s.need(all(before[k]==after[k] for k in keys) and before['output_size']==[1280,720]
       and before['desktop']==desktop==list(shot.size)==list(pyautogui.size())
       and win32gui.GetForegroundWindow()==before['hwnd'] and win32process.GetWindowThreadProcessId(before['hwnd'])[1]==proof['pid'],
       'actual physical foreground/client/desktop changed or differs')
    png=scene/(stem+'.png');crop_png=scene/(stem+'.client.png');out=scene/(stem+'.actual.json')
    s.need(not any(p.exists() for p in [png,crop_png,out]),'new original path required')
    rect=before['client_screen_rect'];s.need(0<=rect[0]<rect[2]<=shot.width and 0<=rect[1]<rect[3]<=shot.height,'client outside desktop')
    crop=shot.crop(tuple(rect))
    with png.open('xb') as f:shot.save(f,format='PNG')
    with crop_png.open('xb') as f:crop.save(f,format='PNG')
    row={'machine_id':c['machine_id'],'observed_at_utc':rt.now(),'run_id':run.name,'source_head':c['source_head'],
        'identity':c['identity'],'scope':s.pin(SCOPE),'foreground_pid':proof['pid'],'foreground_hwnd':before['hwnd'],
        'desktop_size':desktop,'image_size':list(shot.size),'client_screen_rect':rect,'screenshot':s.pin(png),
        'client_screenshot':s.pin(crop_png),'client_image_size':list(crop.size),'input_performed':False,'SDK_calls':0,
        'screen_task':task['task_id'],'screen_sequence':task['last_sequence'],'direct_Root_review_required':True}
    s.write_new(out,row);print(json.dumps({'frame_original':s.pin(out),'screenshot':row['screenshot'],'client_screenshot':row['client_screenshot']}))
def review(frame_path,reviewed):
    s.need(reviewed,'Root must directly inspect this original paused foreground Army93 image')
    c,proof,repo,scene,run=context();original=s.pin(frame_path);f=s.load_pin(original)
    s.need(f.get('machine_id')==c['machine_id'] and f.get('identity')==c['identity'] and f.get('run_id')==run.name
       and f.get('foreground_pid')==proof['pid'] and f.get('source_head')==c['source_head']
       and 0<=(datetime.now(timezone.utc)-s.instant(f['observed_at_utc'])).total_seconds()<=120
       and s.same_pin(s.pin(f['screenshot']['path']),f['screenshot']),'actual original frame identity/freshness differs')
    ui_path=scene/'ARMY93-UI-SELECT.actual-a01.json';ui=s.small_json(ui_path)
    s.need(ui.get('identity')==c['identity'] and ui.get('native_army93_visible_subject_verified') is True,'actual independent Army93 UI receipt absent')
    sys.path.insert(0,str(repo/'promo/ck3_native_war_ai/episode-04-march-logistics/tools'))
    from capture_recorder import inspect_owned_client
    owned=inspect_owned_client(proof['pid'])
    s.need(owned['hwnd']==f['foreground_hwnd'] and owned['desktop']==f['desktop_size']==f['image_size']
       and owned['client_screen_rect']==f['client_screen_rect'] and owned['output_size']==[1280,720],
       'actual current foreground/client differs from Root reviewed original')
    row={'machine_id':c['machine_id'],'observed_at_utc':rt.now(),'source_head':c['source_head'],'run_id':run.name,
        'identity':c['identity'],'current_ck3_foreground':True,'paused_visible':True,'selected_army_id':93,
        'client_screen_rect':owned['client_screen_rect'],'desktop_size':owned['desktop'],'ck3_hwnd':owned['hwnd'],
        'screenshot':f['screenshot'],'original_frame':original,'native_army_UI_receipt':s.pin(ui_path),
        'reviewer':'Root directly reviewed actual original paused foreground Army93 with no foreign window occlusion',
        'business_or_clean_span_qualified':False,'human_approval':False,'SDK_calls':0}
    target=scene/'R09-FRAME-REVIEW.actual-a01.json';s.write_new(target,row);print(json.dumps({'frame_review':s.pin(target)}))
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('stage',choices=['select','verify','center-realm','camera-status','capture','review'])
    p.add_argument('--attempt',default='a01');p.add_argument('--stem',default='r192-pre-film-frame-a01');p.add_argument('--frame',type=Path)
    p.add_argument('--root-reviewed-paused-army93-foreground',action='store_true');p.add_argument('--execute-live',action='store_true');a=p.parse_args()
    s.need(re.fullmatch('a[0-9]{2}',a.attempt) is not None,'explicit bounded attempt label required')
    if a.stage in ['select','verify']:
        s.need(a.execute_live,'Root explicit --execute-live required');selection(a.stage,a.attempt)
    elif a.stage in ['center-realm','camera-status']:
        s.need(a.execute_live,'Root explicit --execute-live required');camera(a.stage,a.attempt)
    elif a.stage=='capture':
        s.need(a.execute_live,'Root explicit --execute-live required');capture(a.stem)
    else:review(a.frame or SCOPE.parent/'r192-pre-film-frame-a01.actual.json',a.root_reviewed_paused_army93_foreground)
if __name__=='__main__':main()
