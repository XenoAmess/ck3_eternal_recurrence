"""Pure R192 F0/F1/F2 DATA, finite-role and stock replay. No SDK or raw access.

F2 is the compact exact-literal packet supplied by the single raw-reader lane.
Original strict failure remains false; a separate role-aware result never
rewrites the failed film, old attempt or original strict invariant.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
REPO=Path('D:/workspace/ck3_eternal_recurrence')
SCENE=Path('D:/workspace/ck3_native_war_ai_promo_work/e04-r192-r09-forward-a01')
OLD=SCENE/'r09-split-merge-relay-a01/r09-forward-a01'
PINS={
 'F0':{'path':str(OLD/'baseline.actual.json'),'bytes':152618,'sha256':'ef4a366e8179db0d969873d346915e6513c6034a24edaf3549626a53c15e039d'},
 'F1':{'path':str(OLD/'post-split-observation.actual.json'),'bytes':157700,'sha256':'94644d5a84ee0f10c11c546cdbdd7c7d7a89551523d14a7a95efd8529ac1c3f8'},
}
U,V=93,16777378
def need(value,why):
    if not value:raise ValueError(why)
def pin(path):
    p=Path(path).resolve(strict=True);need(p.stat().st_size<=2*1024*1024,'compact packet exceeds2MiB')
    raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def load(path,expected=None):
    actual=pin(path)
    if expected:need(actual['bytes']==expected['bytes'] and actual['sha256']==expected['sha256'],'literal original changed')
    return json.loads(Path(path).read_text(encoding='utf-8-sig')),actual
def module(path,name):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
sys.path.insert(0,str(REPO/'ck3_autonomous_player/src'))
from xar_autoplayer.bridge import army_split_transfer_assertions_12004 as transfer
from xar_autoplayer.bridge import army_split_merge_observation_12004 as observation
RELAY=REPO/'promo/ck3_native_war_ai/episode-04-march-logistics/tools/review02/split_merge/root_relay.py'
need(pin(RELAY)['sha256']=='cf348d964ddef87fe8406d4de02eb16a5373ebe2a6ce5d8be91584aef8758071','current production formula/role source changed')
relay=module(RELAY,'r192_existing_pure_formula')
def packet(wrapper):
    p=wrapper['packet'];frame=p['frame'];q=p['query']
    need(wrapper.get('machine_id')=='desktop-3fevhd2-1c74096080' and wrapper.get('source_head')=='60de49f61d23b9c3437af4544c3f12bb28445429'
         and wrapper.get('run_id')=='desktop-3fevhd2-1c74096080--vanilla--R0192','actual R192 wrapper binding differs')
    need(q.get('accepted') is True and q.get('queried_snapshot_id')==frame['snapshot_id']
      and q.get('queried_revision')==frame['revision'] and q.get('queried_native_revision')==frame['native_revision'],
      'complete literal query is not bound to its independent frame')
    rows={r['army_id']:r for r in q['army_strengths']};need(len(rows)==len(q['army_strengths']),'duplicate Army ID')
    need(set(rows)==set(observation._roster(frame)),'complete query does not cover exact actual roster')
    unavailable={i:r for i,r in rows.items() if r['status']!='available'}
    need(set(unavailable)=={16777321} and unavailable[16777321]['status']=='unavailable'
      and unavailable[16777321]['unavailable_reason']=='native_carmy_not_found'
      and unavailable[16777321].get('native_carmy_id') is None,'unavailable row changed or was filled')
    available=[r for r in rows.values() if r['status']=='available']
    observation.compare_split_merge_cohorts(available,available)
    return p,rows,available
def current(p,rows,identity):
    return observation.read_bound_current_commander(p['commanders'][str(identity)],p['frame'],
      army_id=identity,native_carmy_id=rows[identity]['native_carmy_id'])
def finite_role_transition(before,after,allowed_characters):
    old,physical0,occ0=transfer._observe(before);new,physical1,occ1=transfer._observe(after)
    added,removed=sorted(set(new)-set(old)),sorted(set(old)-set(new));reasons=[]
    if physical0!=physical1:reasons.append('unique_physical_values_or_IDs_changed')
    if occ0!=occ1:reasons.append('ArRg_DATA_occurrences_or_backlinks_changed')
    for identity in set(old)&set(new):
        if old[identity]['strength']!=new[identity]['strength']:reasons.append('existing_ArRg_cache_changed:'+str(identity))
        if old[identity]['signature']!=new[identity]['signature']:reasons.append('existing_DATA_identity_order_or_values_changed:'+str(identity))
        if old[identity]['data'].get('native_loss_writer_skipped')!=new[identity]['data'].get('native_loss_writer_skipped'):
            reasons.append('existing_native_Character_predicate_changed:'+str(identity))
    roles=[]
    for kind,ids,values in (('added',added,new),('removed',removed,old)):
        for identity in ids:
            row=values[identity];role=row['data'].get('native_character_role_v1') or {};character=role.get('resolved_character_id')
            source_armies=after if kind=='added' else before
            native=next(a['native_carmy_id'] for a in source_armies if a['army_id']==row['army_id'])
            explained=(transfer._empty_character(row) and character in allowed_characters
              and role.get('character_raw_id_148')==character and role.get('native_carmy_id')==role.get('arrg_army_id_140')==native
              and role.get('extension_arrg_id_f8')==identity)
            if not explained:reasons.append('not_exact_empty_role_of_actual_selected_commander:'+kind+':'+str(identity))
            roles.append({'change':kind,'army_regiment_id':identity,'army_id':row['army_id'],'character_id':character,
              'native_character_role_v1':role,'cache_current_max':[row['strength']['current_soldiers'],row['strength']['maximum_soldiers']],
              'DATA_count':row['data']['native_data_record_count'],'source_consistent_current_role_explanation':explained})
    def total(values):return [sum(v[k] for v in values.values()) for k in (0,1)]
    return {'accepted':not reasons,'reasons':reasons,'unique_physical_before_current_max':total(physical0),
      'unique_physical_after_current_max':total(physical1),'all_DATA_occurrences_conserved':occ0==occ1,
      'role_changes':roles,'allowed_characters_from_independent_selected_commanders':sorted(allowed_characters),
      'birth_producer_observed':False,'physical_refill_or_loss_cause_observed':False,'native_Knight_membership':None}
def qualify(f2_path,f2_sha256):
    b,bpin=load(PINS['F0']['path'],PINS['F0']);s,spin=load(PINS['F1']['path'],PINS['F1']);m,mpin=load(f2_path)
    need(mpin['sha256']==f2_sha256,'the sole raw-reader F2 compact packet exact SHA differs')
    merge_id='r192-merge-cont-once-a01';run=SCENE/'desktop-3fevhd2-1c74096080--vanilla--R0192'
    request,rqpin=load(run/'requests'/(merge_id+'.json'));response,rspin=load(run/'responses'/(merge_id+'.json'))
    need(request.get('request_id')==merge_id and request.get('tool')=='ck3_execute_step'
      and request.get('arguments')=={'step':'merge-armies-93-with-16777378','expected_revision':5}
      and response.get('machine_id')=='desktop-3fevhd2-1c74096080' and response.get('is_error') is False
      and response.get('request')==request and response.get('body',{}).get('accepted') is True
      and response.get('body',{}).get('step')=='merge-armies-93-with-16777378','actual unique Root Merge ACK/request differs')
    need(b['binding']==s['binding']==m['binding'],'actual runtime PID/create/gen/episode changed')
    p0,r0,a0=packet(b);p1,r1,a1=packet(s);p2,r2,a2=packet(m)
    split=transfer.assert_fresh_split_transfer_12004(p0['frame'],p1['frame'],source_army_id=U,pre_strengths=p0['query'],post_strengths=p1['query'],
      pre_commander=p0['commanders'][str(U)],post_commanders={int(k):v for k,v in p1['commanders'].items()})
    need(split['accepted'] is True and split['identity']['sibling_army_id']==V
      and split['identity']['native_carmy_ids']=={U:85,V:16777371},'existing actual Split identity/DATA differs')
    observation._fresh_pair(p1['frame'],p2['frame'])
    need(set(r2)==set(r1)-{V} and r2[U]['native_carmy_id']==85,'actual Merge survivor/source-removal differs')
    for identity in set(r1)-{V}:
        need(r1[identity].get('native_carmy_id')==r2[identity].get('native_carmy_id'),'surviving Army generation changed')
    for identity in set(r1)-{U,V}:
        old,new=observation._roster(p1['frame'])[identity],observation._roster(p2['frame'])[identity]
        for key in ('owner_character_id','current_province_id','controllable','in_combat','retreating','route_province_ids'):
            need(old.get(key)==new.get(key),'unrelated actual roster identity/location/state changed')
    c0=current(p0,r0,U);c1=current(p1,r1,U);child=current(p1,r1,V);c2=current(p2,r2,U)
    need(c0==c1==34232 and child==36445 and c2 in {34232,36445},'independent selected commander chain differs')
    split_roles=finite_role_transition(a0,a1,{34232,36445})
    need(split_roles['accepted'] and len(split_roles['role_changes'])==1
      and split_roles['role_changes'][0]['change']=='removed' and split_roles['role_changes'][0]['army_id']==18
      and split_roles['role_changes'][0]['army_regiment_id']==65 and split_roles['role_changes'][0]['character_id']==36445,
      'original strict exception is not the exact actual R19265/36445 role removal')
    merge_roles=finite_role_transition(a1,a2,{34232,36445})
    selected=relay.compare_data_roles(transfer,[r1[U],r1[V]],[r2[U]])
    supply=relay.compare_merge_supply(p1,p2,[U,V])
    strict=observation.compare_split_merge_cohorts([r1[i] for i in sorted(set(r1)-{U,V,16777321})],
      [r2[i] for i in sorted(set(r2)-{U,16777321})])
    return {'schema':'xar.e04.r192-f0f1f2-limited-role-replay.v1','machine_id':'desktop-3fevhd2-1c74096080',
      'source_head':'60de49f61d23b9c3437af4544c3f12bb28445429','run_id':b['run_id'],'binding':b['binding'],
      'F0':bpin,'F1':spin,'F2':mpin,'actual_unique_Merge':{'request':rqpin,'response':rspin},
      'selected_split':split,'split_global_finite_role_result':split_roles,
      'selected_merge_DATA_roles':selected,'merge_global_finite_role_result':merge_roles,'merge_supply':supply,
      'actual_survivor_current_commander':c2,'merge_unrelated_original_strict_result':strict,
      'original_F0_to_F1_strict_unrelated_freeze_pass':False,'original_film_RED_preserved':True,
      'new_actual_Merge_postconditions_pass':selected['accepted'] and merge_roles['accepted'],
      'all_roster_strengths_qualified':False,'unavailable_army_id':16777321,'unavailable_strengths_filled_zero':False,
      'SDK_calls':0,'large_Driver_reads':0,'dynamic_video_qualified':False,'human_signoff':False,'R09_full_card_closed':False}
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--f2-packet',type=Path,required=True);p.add_argument('--f2-sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    result=qualify(a.f2_packet,a.f2_sha256)
    with a.output.open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'result':pin(a.output),'new_actual_Merge_postconditions_pass':result['new_actual_Merge_postconditions_pass'],
      'original_film_RED_preserved':True,'R09_full_card_closed':False}))
if __name__=='__main__':main()
