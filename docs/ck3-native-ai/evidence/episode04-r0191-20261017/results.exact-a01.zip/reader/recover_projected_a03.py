"""Root-approved recovery: reuse day0 summary, read day1 total2/day2 total1."""
from pathlib import Path
import hashlib, inspect, io, json, re, subprocess, sys, zipfile
import baseline_identity_entry

HERE=Path(__file__).resolve().parent
OUT=Path('C:/ck3-e04-resume-20261015-a01/r191-portable-candidate-a01/reader-derived-a03')
LIMIT=48*1024
ARTIFACTS={}
PROJECTED=[]

def need(value,message):
    if not value:
        raise RuntimeError(message)

def pin(path,data=None):
    path=Path(path)
    if data is None:
        data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def run():
    global ARTIFACTS, PROJECTED
    m=baseline_identity_entry.load()
    m.write_new=inspect.getclosurevars(m.write_new).nonlocals['original']
    manifest=json.loads((HERE/'INPUT.actual-a01.json').read_bytes())
    m.require_manifest(manifest)
    need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=manifest['repo'],text=True).strip()==manifest['source_head'],
         'Actual consumer checkout source differs')
    claims=[]
    for path in sorted((HERE/'actual-a02').glob('*.claim.json')):
        value=json.loads(path.read_bytes())
        claims.append({'pin':pin(path),'day_index':value['endpoint_day'],'reference':value['reference']})
    need(sorted(x['day_index'] for x in claims)==[0,1],'Unexpected original claim inventory; do not reopen raw')
    baseline_path=HERE/'actual-a02/day-00.summary.actual.json'
    baseline_pin=pin(baseline_path)
    need(baseline_pin['bytes']==19368 and baseline_pin['sha256']=='9ac857da445b98cb1cb2fa43165706bc642adc7b47593df61ce1983da32f0df7',
         'Saved day0 summary changed')
    baseline=json.loads(baseline_path.read_bytes())
    need(baseline['day_index']==0 and baseline['original_full_reference']==next(x['reference'] for x in claims if x['day_index']==0),
         'Saved baseline does not match actual day0 read claim')
    # Actual two-digit names are tested before any raw body read; old sealed wrapper stays intact.
    need(all(re.fullmatch(r'day-0[012]\.summary\.actual\.json',f'day-{i:02d}.summary.actual.json') for i in range(3)),
         'Actual two-digit summary filename coverage failed')
    need(re.fullmatch(r'day-[012]\.summary\.actual\.json','day-00.summary.actual.json') is None,
         'Expected historical regex counterexample no longer reproduces')
    need(not OUT.exists(),'Recovery result child already exists; never replay raw automatically')
    metadata=[]
    previous=None
    for index,epin in enumerate(manifest['endpoints']):
        endpoint=m.small(epin)
        meta=m.validate_metadata(manifest,endpoint,index,previous)
        metadata.append(meta)
        previous=meta
    need(metadata[0]['reference']==baseline['original_full_reference'],'Metadata differs from saved baseline raw reference')
    need(metadata[1]['reference']==next(x['reference'] for x in claims if x['day_index']==1),'Prior day1 claim reference changed')
    need(len({x['reference']['path'] for x in metadata})==3,'Endpoint raw paths duplicate')
    need(sum(p.stat().st_size for p in HERE.rglob('*') if p.is_file())<=96*1024,'Original code lane exceeds96KiB')
    OUT.mkdir()
    m.HERE=OUT
    m.MAX_LANE=LIMIT
    intent={'machine_id':manifest['machine_id'],'at_utc':m.utc(),'schema':'xar.e04.r191-approved-read-recovery.v1',
      'old_claims':claims,'reused_day0_summary':baseline_pin,'new_raw_body_read_days':[1,2],
      'total_raw_body_reads_after_success_by_day':{'0':1,'1':2,'2':1},
      'correction':'Traceback-only initial interpretation was wrong: day0 summary had succeeded and day1 was also read before the96KiB write failure. Actual claim inventory, not the exception location, determines read counts.',
      'pre_read_budget':{'child_ceiling_bytes':LIMIT,'claim_intent_reserve_bytes':4096,'staged_result_and_zip_reserve_bytes':45056,
        'writes':'Only two small read claims before all derived payloads are encoded and total-budget checked in RAM'},
      'actual_filename_counterexample_passed':True,'SDK_game_desktop_build_calls':0}
    m.write_new(OUT/'INTENT.actual.json',intent)
    api=m.production(Path(manifest['repo']))
    need(manifest['executable_sha256'].lower()==api[5],'Executable/source consumer identity differs')
    baseline['row']=None
    baseline['baseline_projection_only']=True
    baseline['baseline_summary_pin']=baseline_pin
    PROJECTED=[baseline]
    for index in (1,2):
        meta=metadata[index]
        row,pointers=m.read_raw_once(meta,OUT)
        endpoint=meta['endpoint']
        PROJECTED.append({'day_index':index,'date_raw':endpoint['date_raw'],'endpoint':manifest['endpoints'][index],
          'original_full_reference':meta['reference'],'original_top_level_evidence':meta['evidence'],
          'query_sequence':meta['sequence'],'identity':endpoint['identity'],
          'before_after_public_revision':[meta['before']['revision'],meta['after']['revision']],
          'native_revision':meta['before']['native_revision'],'row':row,'physical':m.physical_snapshot(row,api),
          'value_projection_sources':pointers})
    intervals=[]
    maths=[]
    for left,right in zip(PROJECTED,PROJECTED[1:]):
        result,detail=m.compare_interval(left,right,manifest,api)
        intervals.append(result)
        maths.append(detail)
    sourcepins=[]
    for name in m.CONSUMERS:
        path=Path(manifest['repo'])/'ck3_autonomous_player/src/xar_autoplayer/bridge'/name
        sourcepins.append({**pin(path),'repo_relative_path':path.relative_to(manifest['repo']).as_posix()})
    witness={'schema':'xar.e04.r191-natural-loss-recovered-three-endpoint-portable.v1',
      'machine_id':manifest['machine_id'],'source_head':manifest['source_head'],'run_id':manifest['run_id'],
      'game_version':manifest['game_version'],'executable_sha256':manifest['executable_sha256'],
      'endpoints':PROJECTED,'intervals':intervals,'production_math':maths,'consumer_source_pins':sourcepins,
      'baseline_replay_limit':'Day0 is the saved actual once-derived physical/role/fence projection with exact whole-raw pin and original JSON pointers; its complete normalized row is not held. Verify baseline physical sums/keysets directly. Re-normalize rows1/2 and replay production interval consumers. Do not run _observe on baseline row=None.',
      'projection_kind':'Canonical JSON value projections, not original byte offsets or pipe bytes',
      'total_raw_body_reads_by_day':{'0':1,'1':2,'2':1},'allworld_event_dates_observed':False,
      'R03_full_card_or_media_qualified':False,'exact_event_PTS_claimed':False}
    buffer=io.BytesIO()
    with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        archive.writestr('loss-three-endpoint-witness.json',m.encoded(witness))
    ARTIFACTS['R191-loss-three-endpoints.portable.zip']=buffer.getvalue()
    compact=[]
    for item in PROJECTED:
        physical=item['physical']
        compact.append({**{k:item[k] for k in ('day_index','date_raw','endpoint','original_full_reference','query_sequence','before_after_public_revision','native_revision')},
          'physical':{k:physical[k] for k in ('physical_unique_slot_count','physical_current_max','cached_current_max','stock_raw','capacity_raw','writer_fence','callback_fence')}})
    result={'schema':'xar.e04.r191-recovered-three-endpoint-analysis.actual.v1','machine_id':manifest['machine_id'],
      'at_utc':m.utc(),'source_head':manifest['source_head'],'run_id':manifest['run_id'],
      'status':'THREE_ACTUAL_ENDPOINTS_BOUND_STRICT_PRODUCTION_INTERVAL_CONSUMERS_EXECUTED',
      'endpoints':compact,'intervals':intervals,'consumer_source_pins':sourcepins,
      'portable':pin(OUT/'R191-loss-three-endpoints.portable.zip',ARTIFACTS['R191-loss-three-endpoints.portable.zip']),
      'total_raw_body_reads_by_day':{'0':1,'1':2,'2':1},'new_raw_body_reads_this_attempt':2,
      'old_failures_preserved':True,'reused_day0_summary':baseline_pin,'correction':intent['correction'],
      'R03_single_event_positive_obtained':any(x['R03_single_event_positive_from_strict_production_consumer'] for x in intervals),
      'R03_full_card_or_media_qualified':False,'SDK_game_desktop_build_calls':0,
      'time_precision':'Copied native invocation identities and actual game-date intervals; no invented event monotonic/PTS or allworld date distribution'}
    ARTIFACTS['ANALYSIS.actual.json']=m.encoded(result)
    finalbytes=m.used_bytes()+sum(map(len,ARTIFACTS.values()))
    need(finalbytes<=LIMIT,'All staged outputs exceed48KiB; RAM remains in interactive interpreter')
    for name,data in ARTIFACTS.items():
        with (OUT/name).open('xb') as stream:
            stream.write(data)
    print(json.dumps({'analysis':pin(OUT/'ANALYSIS.actual.json',ARTIFACTS['ANALYSIS.actual.json']),
      'portable':result['portable'],'actual_child_bytes':finalbytes,'endpoints':compact,'intervals':intervals},ensure_ascii=False))

if __name__=='__main__':
    run()
