"""Offline three-endpoint loss reader. No SDK, gameplay, build, or recorder API."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
MAX_LANE=96*1024
MAX_META=1024*1024
PROFILE='observed_history_full_v1'
WRITER='actual_loss_writer_observations_v1'
CALLBACK='actual_supply_callback_observations_v1'
KEEP=('status','army_id','native_carmy_id','owner_character_id','regiment_count',
      'current_soldiers','maximum_soldiers','current_supply_raw','current_supply_scale',
      'current_supply_capacity_raw','current_supply_capacity_scale',
      'regiment_strengths','regiment_replenishment_records_v1',WRITER,CALLBACK)
CONSUMERS=('army_physical_loss_evidence_12004.py','army_actual_supply_parent_join_summary.py',
           'army_siege_parent_loss_evidence_12004.py','army_periodic_loss_component_12004.py',
           'army_actual_loss_writer_observations_contract.py','army_actual_supply_parent_join_contract.py',
           'episode04_starvation_loss_12004.py','army_split_transfer_assertions_12004.py',
           'army_replenishment_records_contract.py')


def need(ok,reason):
    if not ok:
        raise ValueError(reason)


def utc():
    return datetime.now(timezone.utc).isoformat()


def encoded(value):
    return (json.dumps(value,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf-8')


def bytes_pin(path,data):
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


def same_pin(left,right):
    return (type(left) is dict and type(right) is dict and
            left.get('bytes')==right.get('bytes') and str(left.get('sha256','')).lower()==str(right.get('sha256','')).lower()
            and Path(left.get('path','')).resolve()==Path(right.get('path','')).resolve())


def file_pin(path):
    path=Path(path)
    data=path.read_bytes()
    return bytes_pin(path,data)


def checked_stat(path,amount,limit):
    need(type(amount) is int and 0<amount<=limit,'Pinned bytes missing/outside explicit read bound')
    path=Path(path)
    stat=path.lstat()
    need(path.is_file() and not path.is_symlink() and not getattr(stat,'st_file_attributes',0)&0x400
         and stat.st_nlink==1 and stat.st_size==amount,'Pinned ordinary single-link file stat changed')
    return stat


def small(pin):
    path=Path(pin['path'])
    checked_stat(path,pin['bytes'],MAX_META)
    data=path.read_bytes()
    need(bytes_pin(path,data)['sha256']==pin['sha256'].lower(),'Metadata exact SHA changed')
    return json.loads(data)


def used_bytes():
    return sum(path.stat().st_size for path in HERE.rglob('*') if path.is_file())


def write_new(path,value):
    data=encoded(value)
    need(used_bytes()+len(data)<=MAX_LANE,'Reader lane96KiB budget exhausted; do not write a larger derived copy')
    with Path(path).open('xb') as stream:
        stream.write(data)
    return bytes_pin(path,data)


def require_manifest(manifest):
    need(manifest.get('schema')=='xar.e04.r191-loss-three-endpoint-input.v1','Exact reader manifest schema required')
    for key in ['machine_id','run_id','source_head','native_build_source_head','repo','evidence_dir']:
        need(type(manifest.get(key)) is str and manifest[key],key+' missing')
    need(re.fullmatch('[0-9a-f]{40}',manifest['source_head']) is not None,'Explicit exact source40hex required')
    need(manifest['source_head']==manifest['native_build_source_head'],'Runtime/native source differ')
    need(type(manifest.get('actor_id')) is int and manifest['actor_id']>0,'Actual actor FullID required')
    need(type(manifest.get('army_id')) is int and manifest['army_id']!=-1,'Actual public Army FullID required')
    need(type(manifest.get('endpoints')) is list and len(manifest['endpoints'])==3,'Exactly day0/day1/day2 pins required')
    need(manifest.get('game_version')=='1.20.0.4' and re.fullmatch('[0-9a-fA-F]{64}',str(manifest.get('executable_sha256'))) is not None,
         'Root exact-build binding required; reader never hashes EXE')
    need(type(manifest.get('maximum_reference_bytes')) is int and 0<manifest['maximum_reference_bytes']<=128*1024*1024,
         'Explicit existing full-reference limit up to128MiB required')


def bound_frame(manifest,proof,frame,date):
    need(frame.get('map_ready') is True and frame.get('paused') is True and frame.get('date_raw')==date,'Endpoint map/paused/date changed')
    need(frame.get('episode_run_id')==proof['episode_run_id'] and frame.get('episode_character_id')==manifest['actor_id'],
         'Endpoint actor/episode differs')
    actor=frame.get('played_character') or {}
    need(actor.get('character_id')==manifest['actor_id'] and actor.get('alive') is True,'Actual living played actor missing')
    diag=frame.get('diagnostics') or {}
    need(diag.get('bridge_pid')==proof['pid'] and diag.get('connection_generation')==proof['connection_generation'],'Endpoint PID/connection changed')
    need(not frame.get('active_event') and not frame.get('pending_character_interaction'),'Endpoint active event/interaction unresolved')
    armies=[row for row in frame.get('player_armies',[]) if row.get('army_id')==manifest['army_id']]
    need(len(armies)==1 and armies[0].get('owner_character_id')==manifest['actor_id']
         and armies[0].get('controllable') is True and armies[0].get('in_combat') is False
         and armies[0].get('retreating') is False,'Endpoint actual watched owner/control/combat/retreat changed')
    return armies[0]


def validate_metadata(manifest,endpoint,index,previous):
    need(endpoint.get('machine_id')==manifest['machine_id'] and endpoint.get('source_head')==manifest['source_head']
         and endpoint.get('native_build_source_head')==manifest['native_build_source_head']
         and endpoint.get('run_id')==manifest['run_id'],'Endpoint machine/source/run changed')
    need(endpoint.get('day_index')==index and type(endpoint.get('date_raw')) is int,'Endpoint day index/date missing')
    proof=small(endpoint['identity'])
    config=small(endpoint['input_config'])
    need(proof.get('machine_id')==manifest['machine_id'] and proof.get('run_id')==manifest['run_id']
         and proof.get('source_head')==manifest['source_head'] and proof.get('native_build_source_head')==manifest['native_build_source_head'],
         'Actual identity source/native/machine/run changed')
    need(type(proof.get('process_creation_filetime_100ns')) is int and proof['process_creation_filetime_100ns']>0,'Actual process create time absent')
    need(proof.get('actual_runtime_character_full_id')==manifest['actor_id'],'Actual identity actor differs')
    need(config.get('machine_id')==manifest['machine_id'] and config.get('source_head')==manifest['source_head']
         and config.get('native_build_source_head')==manifest['native_build_source_head']
         and Path(config['run_dir']).name==manifest['run_id'] and config.get('actor_id')==manifest['actor_id']
         and config.get('army_id')==manifest['army_id'] and config.get('identity')==endpoint['identity'],'Actual film-input identity/source differs')
    spec=config.get('post_day_full') or {}
    need(spec.get('profile')==PROFILE and spec.get('ordered_refill_entry_mode')=='observed_prepared'
         and spec.get('ordered_besieging_entry_mode')=='observed_prepared'
         and spec.get('maximum_reference_bytes')==manifest['maximum_reference_bytes']
         and Path(spec.get('evidence_dir','')).resolve()==Path(manifest['evidence_dir']).resolve(),
         'Actual film query/evidence byte contract differs')
    if index>0:
        need(same_pin(spec.get('baseline_endpoint'),manifest['endpoints'][0]),'Actual film does not bind this immutable day0 baseline')
    date=config['expected_start_date_raw']+24*index
    need(endpoint['date_raw']==date and proof.get('initial_date_raw')==config['expected_start_date_raw'],'Endpoint not the actual consecutive natural date')
    before_env=small(endpoint['before_snapshot'])
    full_env=small(endpoint['full_response'])
    after_env=small(endpoint['after_snapshot'])
    for envelope in [before_env,full_env,after_env]:
        need(envelope.get('machine_id')==manifest['machine_id'] and envelope.get('is_error') is False,'Actual endpoint response error/machine differs')
    before,after=before_env['body'],after_env['body']
    bound_frame(manifest,proof,before,date)
    bound_frame(manifest,proof,after,date)
    # Match the actual owner helper: query public revision binds to before;
    # native/date/actor frame must remain fixed through independent readback.
    need(before.get('native_revision')==after.get('native_revision'),'Native frame changed across the readonly full request')
    need(type(before.get('revision')) is int and type(after.get('revision')) is int,'Public revision must be observed, not assumed')
    args={'army_ids':[manifest['army_id']],'expected_revision':before['revision'],
          'ordered_refill_entry_mode':'observed_prepared','ordered_besieging_entry_mode':'observed_prepared','profile':PROFILE}
    request_id=endpoint['request_id']
    need(endpoint.get('arguments')==args and full_env.get('request')=={'request_id':request_id,'tool':'ck3_query_army_strengths','arguments':args},
         'Original full request/arguments differ')
    evidence=full_env.get('army_history_evidence')
    body=full_env.get('body') or {}
    need(type(evidence) is dict,'Full reference must be at original SDK envelope TOP LEVEL, never body')
    need(evidence.get('machine_id')==manifest['machine_id'] and evidence.get('request_id')==request_id
         and evidence.get('full_result_preserved') is True and evidence.get('full_result_kind')=='complete Driver result; not original pipe bytes'
         and evidence.get('army_strengths_profile')==PROFILE,'Complete Driver source reference unavailable')
    sequence=evidence.get('query_sequence')
    need(type(sequence) is int and sequence>0 and endpoint.get('query_sequence')==body.get('query_sequence')==sequence
         and body.get('accepted') is True and body.get('status')=='available' and body.get('army_ids')==[manifest['army_id']]
         and body.get('army_strengths_profile')==PROFILE,'Compact/E query sequence/profile/scope differs')
    need(evidence.get('queried_revision')==before['revision']==args['expected_revision']
         and evidence.get('queried_native_revision')==before['native_revision']
         and body.get('source')=={'revision':before['revision'],'native_revision':before['native_revision']},'Compact/E revision does not bind to actual query frame')
    rows=[row for row in body.get('armies',[]) if row.get('army_id')==manifest['army_id']]
    need(len(rows)==1 and rows[0].get('status')=='available' and rows[0].get('native_carmy_id')==endpoint.get('native_carmy_id'),
         'Compact native Army identity changed')
    ref=evidence.get('raw_result_reference')
    need(type(ref) is dict and ref==endpoint.get('raw_result_reference') and ref.get('kind')=='complete-driver-army-query-result-json-v1'
         and ref.get('wire_bytes_preserved') is False,'Immutable raw reference differs from original top-level producer')
    need(type(ref.get('bytes')) is int and 0<ref['bytes']<=manifest['maximum_reference_bytes']
         and type(evidence.get('limit_bytes')) is int and ref['bytes']<=evidence['limit_bytes']<=128*1024*1024
         and re.fullmatch('[0-9a-fA-F]{64}',str(ref.get('sha256'))) is not None,'Reference size/hash/admitted limit invalid')
    path=Path(ref['path'])
    need(path.is_absolute() and path.resolve().parent==Path(manifest['evidence_dir']).resolve()
         and re.fullmatch(r'army-query-[0-9a-f]{32}\.json',path.name) is not None,'Raw reference outside exact scene sidecar leaf')
    checked_stat(path,ref['bytes'],manifest['maximum_reference_bytes'])
    if previous is not None:
        need(endpoint['identity']==previous['endpoint']['identity'],'Identity changed between adjacent endpoints')
        # The final film config necessarily adds baseline_endpoint after day0;
        # each exact config pin is retained, while the actual source/runtime/
        # actor/scope/query contract above and the baseline link stay fixed.
        need(date==previous['endpoint']['date_raw']+24 and sequence>previous['sequence']
             and endpoint['native_carmy_id']==previous['endpoint']['native_carmy_id'],'Skipped/duplicate day/query or CArmy generation changed')
        need(ref['path']!=previous['reference']['path'],'Same raw file cannot count as another natural-day endpoint')
    return {'endpoint':endpoint,'proof':proof,'config':config,'before':before,'after':after,
            'reference':ref,'sequence':sequence,'evidence':evidence}


def read_raw_once(metadata,out):
    ref=metadata['reference']
    path=Path(ref['path'])
    claim=Path(out)/('raw-'+ref['sha256'].lower()+'.read-once.claim.json')
    need(not claim.exists(),'This immutable full was already claimed; no automatic reread')
    checked_stat(path,ref['bytes'],metadata['config']['post_day_full']['maximum_reference_bytes'])
    write_new(claim,{'machine_id':metadata['endpoint']['machine_id'],'at_utc':utc(),'reference':ref,
                     'endpoint_day':metadata['endpoint']['day_index'],'one_original_full_read_only':True})
    data=path.read_bytes()
    need(len(data)==ref['bytes'] and hashlib.sha256(data).hexdigest()==ref['sha256'].lower(),'Complete full raw bytes/SHA changed')
    result=json.loads(data)
    del data
    frame=metadata['before']
    need(result.get('accepted') is True and result.get('status')=='available' and result.get('query_sequence')==metadata['sequence']
         and result.get('army_strengths_profile')==PROFILE,'Actual complete Driver profile/status/sequence differs')
    for qkey,fkey in [('queried_snapshot_id','snapshot_id'),('queried_revision','revision'),
                      ('queried_native_revision','native_revision'),('queried_date_raw','date_raw'),('queried_episode_run_id','episode_run_id')]:
        need(result.get(qkey)==frame.get(fkey),'Complete query frame binding differs: '+qkey)
    need(result.get('queried_connection_generation')==metadata['proof']['connection_generation'],'Raw query connection generation changed')
    need(result.get('army_strengths_query_scope')=={'army_ids':[metadata['config']['army_id']],'published_scope_status':'available'},'Raw full selected scope differs')
    rows=result.get('army_strengths')
    need(type(rows) is list and len(rows)==1 and rows[0].get('army_id')==metadata['config']['army_id']
         and rows[0].get('native_carmy_id')==metadata['endpoint']['native_carmy_id'],'Raw full Army/whole-ID differs')
    selected={key:rows[0][key] for key in KEEP if key in rows[0]}
    pointers=[{'json_pointer':'/army_strengths/0/'+key,'canonical_value_bytes':len(encoded(value)),
               'canonical_value_sha256':hashlib.sha256(encoded(value)).hexdigest()} for key,value in selected.items()]
    return selected,pointers


def header(family):
    if type(family) is not dict:
        return None
    keys=('status','source','membership_basis','observer_installed','oldest_available_sequence','latest_sequence',
          'overwritten_events','unattributed_capture_failures','event_count')
    return {key:family.get(key) for key in keys}


def interval_fence(before,after):
    result={'before':before,'after':after,'coverage_complete':False,'missing_reasons':[],
            'global_new_sequence_count':None,'overwrite_counter_delta':None,'capture_failure_delta':None,
            'allworld_event_dates_observed':False,'zero_loss_proved':False}
    why=result['missing_reasons']
    if before is None or after is None:
        why.append('journal_header_absent')
        return result
    if before.get('observer_installed') is not True or after.get('observer_installed') is not True:
        why.append('observer_not_continuously_installed')
    if before.get('status')!='available' or after.get('status')!='available':
        why.append('journal_status_not_available')
    names=('oldest_available_sequence','latest_sequence','overwritten_events','unattributed_capture_failures')
    if any(type(row.get(key)) is not int or row[key]<0 for row in [before,after] for key in names):
        why.append('journal_counter_unavailable')
        return result
    latest=after['latest_sequence']
    fence=before['latest_sequence']
    delta=latest-fence
    result.update(global_new_sequence_count=delta,
                  overwrite_counter_delta=after['overwritten_events']-before['overwritten_events'],
                  capture_failure_delta=after['unattributed_capture_failures']-before['unattributed_capture_failures'])
    if delta<0 or result['overwrite_counter_delta']<0 or result['capture_failure_delta']<0:
        why.append('counter_reset_or_journal_lifetime_changed')
    if delta>0 and (after['oldest_available_sequence']==0 or after['oldest_available_sequence']>fence+1):
        why.append('needed_interval_events_overwritten_or_missing')
    if result['capture_failure_delta']!=0:
        why.append('new_or_reset_unattributed_capture_failure')
    result['coverage_complete']=not why
    return result


def production(repo):
    sys.path.insert(0,str(Path(repo)/'ck3_autonomous_player/src'))
    from xar_autoplayer.bridge.army_split_transfer_assertions_12004 import _observe,_empty_character
    from xar_autoplayer.bridge.army_physical_loss_evidence_12004 import evaluate_army_physical_loss_evidence_12004
    from xar_autoplayer.bridge.army_actual_supply_parent_join_summary import join_actual_supply_parent_writer_observations_v1
    from xar_autoplayer.bridge.army_siege_parent_loss_evidence_12004 import evaluate_siege_parent_loss_evidence_12004
    from xar_autoplayer.bridge.episode04_starvation_loss_12004 import EXE_SHA256
    return _observe,_empty_character,evaluate_army_physical_loss_evidence_12004,join_actual_supply_parent_writer_observations_v1,evaluate_siege_parent_loss_evidence_12004,EXE_SHA256


def physical_snapshot(row,api):
    observed,physical,occurrences=api[0]([row])
    return {'army_id':row['army_id'],'native_carmy_id':row['native_carmy_id'],
       'cached_current_max':[row['current_soldiers'],row['maximum_soldiers']],
       'cached_regiment_sum_current_max':[sum(value['strength'][key] for value in observed.values()) for key in ['current_soldiers','maximum_soldiers']],
       'physical_unique_slot_count':len(physical),'physical_current_max':[sum(value[index] for value in physical.values()) for index in [0,1]],
       'DATA_occurrence_count':sum(occurrences.values()),
       'physical_slots':[{'persistent_regiment_id':key[0],'chunk_index':key[1],'current_soldiers':value[0],
                          'maximum_soldiers':value[1],'state_raw':value[2]} for key,value in sorted(physical.items())],
       'cached_regiments':[{'army_regiment_id':key,'current_soldiers':value['strength']['current_soldiers'],
                            'maximum_soldiers':value['strength']['maximum_soldiers'],
                            'DATA_count':value['data']['native_data_record_count'],
                            'empty_character_1_1_proved':api[1](value),
                            'character_role':value['data'].get('native_character_role_v1')} for key,value in observed.items()],
       'stock_raw':row.get('current_supply_raw'),'capacity_raw':row.get('current_supply_capacity_raw'),
       'writer_fence':header(row.get(WRITER)),'callback_fence':header(row.get(CALLBACK))}


def compare_interval(left,right,manifest,api):
    old,new=left['physical'],right['physical']
    old_keys={(slot['persistent_regiment_id'],slot['chunk_index']):slot for slot in old['physical_slots']}
    new_keys={(slot['persistent_regiment_id'],slot['chunk_index']):slot for slot in new['physical_slots']}
    same_keys=old_keys.keys()==new_keys.keys()
    same_max=same_keys and all(old_keys[key]['maximum_soldiers']==new_keys[key]['maximum_soldiers'] for key in old_keys)
    loss_fence=interval_fence(old['writer_fence'],new['writer_fence'])
    callback_fence=interval_fence(old['callback_fence'],new['callback_fence'])
    low,high=left['date_raw'],right['date_raw']
    baseline_loss=None if old['writer_fence'] is None else old['writer_fence']['latest_sequence']
    baseline_callback=None if old['callback_fence'] is None else old['callback_fence']['latest_sequence']
    refusal=None
    try:
        need(type(baseline_loss) is int and type(baseline_callback) is int,'Actual baseline sequence unavailable; cannot invent zero fence')
        physical=api[2](right['row'],exact_source=True,after_sequence=baseline_loss,
                        date_raw_min_exclusive=low,date_raw_max_inclusive=high)
        joined=api[3](right['row'],game_version=manifest['game_version'],executable_sha256=manifest['executable_sha256'],
                      callback_after_sequence=baseline_callback,loss_after_sequence=baseline_loss)
        siege=api[4](right['row'],game_version=manifest['game_version'],executable_sha256=manifest['executable_sha256'],
                     callback_after_sequence=baseline_callback,loss_after_sequence=baseline_loss,
                     date_raw_min_exclusive=low,date_raw_max_inclusive=high)
    except ValueError as exc:
        refusal=str(exc)
        physical={'positive_events':[],'status':'strict_consumer_refused','refusal':refusal}
        joined={'unknown_reasons':['strict_consumer_refused: '+refusal]}
        siege={'combined_stage_positive_events':[],'siege_only_positive_writer_events':[],'status':'strict_consumer_refused'}
    result={'from_day':left['day_index'],'to_day':right['day_index'],'date_raw_min_exclusive':low,'date_raw_max_inclusive':high,
       'writer_fence_coverage':loss_fence,'callback_fence_coverage':callback_fence,
       'physical_identity_keyset_stable':same_keys,'physical_maxima_stable':same_max,
       'endpoint_same_cohort_net_debit':old['physical_current_max'][0]-new['physical_current_max'][0] if same_max else None,
       'endpoint_cached_current_delta':new['cached_current_max'][0]-old['cached_current_max'][0],
       'empty_character_1_1_ids_before':[r['army_regiment_id'] for r in old['cached_regiments'] if r['empty_character_1_1_proved']],
       'empty_character_1_1_ids_after':[r['army_regiment_id'] for r in new['cached_regiments'] if r['empty_character_1_1_proved']],
       'positive_physical_writer_count':len(physical['positive_events']),
       'positive_physical_writer_debit_sum':sum(e['actual_physical_soldier_debit'] for e in physical['positive_events']),
       'same_callback_combined_stage_positive_count':len(siege['combined_stage_positive_events']),
       'source_bound_siege_only_positive_count':len(siege['siege_only_positive_writer_events']),
       'parent_unknown_reasons':joined['unknown_reasons'],
       'strict_consumer_refusal':refusal,
       'R03_single_event_positive_from_strict_production_consumer':bool(siege['siege_only_positive_writer_events']),
       'complete_interval_loss_total_claimed':False,'R03_full_card_or_media_qualified':False,
       'allworld_dates_observed':False,'exact_event_PTS_claimed':False}
    return result,{'physical':physical,'joined':joined,'siege':siege}


def consume(manifest,out):
    require_manifest(manifest)
    repo=Path(manifest['repo']).resolve()
    need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==manifest['source_head'],'Consumer checkout is not the exact actual runtime source')
    api=production(repo)
    need(manifest['executable_sha256'].lower()==api[5],'Root exact executable binding differs from production consumer source')
    out=Path(out).resolve()
    need(out.is_relative_to(HERE) and out!=HERE and not out.exists(),'Use one new result directory inside admitted external reader lane')
    out.mkdir()
    write_new(out/'INTENT.actual.json',{'machine_id':manifest['machine_id'],'at_utc':utc(),'manifest':manifest,
                                      'SDK_game_desktop_calls':0,'original_full_read_policy':'once per immutable reference; claim survives failures'})
    projected=[]
    previous=None
    seen_paths=set()
    for index,endpoint_pin in enumerate(manifest['endpoints']):
        endpoint=small(endpoint_pin)
        metadata=validate_metadata(manifest,endpoint,index,previous)
        need(metadata['reference']['path'] not in seen_paths,'Raw reference repeated across endpoint series')
        seen_paths.add(metadata['reference']['path'])
        row,pointers=read_raw_once(metadata,out)
        projected.append({'day_index':index,'date_raw':endpoint['date_raw'],'endpoint':endpoint_pin,
                          'original_full_reference':metadata['reference'],'original_top_level_evidence':metadata['evidence'],
                          'query_sequence':metadata['sequence'],'identity':endpoint['identity'],
                          'before_after_public_revision':[metadata['before']['revision'],metadata['after']['revision']],
                          'native_revision':metadata['before']['native_revision'],'row':row,'physical':physical_snapshot(row,api),
                          'value_projection_sources':pointers})
        previous=metadata
        projected[-1]['summary']=write_new(out/f'day-{index:02d}.summary.actual.json',
                                          {key:value for key,value in projected[-1].items() if key not in ['row']})
    intervals=[]
    math=[]
    for left,right in zip(projected,projected[1:]):
        summary,detail=compare_interval(left,right,manifest,api)
        intervals.append(summary)
        math.append(detail)
    sourcepins=[]
    for name in CONSUMERS:
        path=repo/'ck3_autonomous_player/src/xar_autoplayer/bridge'/name
        sourcepins.append({**file_pin(path),'repo_relative_path':path.relative_to(repo).as_posix()})
    witness={'schema':'xar.e04.r191-natural-loss-three-endpoint-portable.v1','machine_id':manifest['machine_id'],
       'source_head':manifest['source_head'],'game_version':manifest['game_version'],'executable_sha256':manifest['executable_sha256'],
       'run_id':manifest['run_id'],'endpoints':projected,'intervals':intervals,'production_math':math,'consumer_source_pins':sourcepins,
       'projection_kind':'Canonical JSON value projections at stated original JSON pointers; projection bytes/SHA are not original byte offsets or pipe bytes',
       'allworld_event_dates_unavailable':True,'R03_full_card_or_media_qualified':False}
    buffer=io.BytesIO()
    with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        archive.writestr('loss-three-endpoint-witness.json',encoded(witness))
    packed=buffer.getvalue()
    zip_path=out/'R191-loss-three-endpoints.portable.zip'
    result={'schema':'xar.e04.r191-loss-three-endpoint-analysis.actual.v1','machine_id':manifest['machine_id'],'at_utc':utc(),
       'source_head':manifest['source_head'],'run_id':manifest['run_id'],'status':'ACTUAL_THREE_ORIGINAL_FULLS_READ_ONCE_STRICT_CONSUMERS_EXECUTED',
       'endpoints':[{key:item[key] for key in ['day_index','date_raw','endpoint','original_full_reference','query_sequence','summary']} for item in projected],
       'intervals':intervals,'portable':bytes_pin(zip_path,packed),'consumer_source_pins':sourcepins,
       'SDK_game_desktop_or_build_actions':0,'original_raw_read_count':3,'original_raw_bytes_read':sum(item['original_full_reference']['bytes'] for item in projected),
       'R03_single_event_positive_obtained':any(item['R03_single_event_positive_from_strict_production_consumer'] for item in intervals),
       'R03_full_card_or_media_qualified':False,'time_precision':'Actual game-date intervals and copied native invocation identities only; no invented event monotonic time/PTS or allworld dates'}
    need(used_bytes()+len(packed)+len(encoded(result))<=MAX_LANE,
         'Portable necessary witness/result exceeds remaining96KiB; do not copy whole full or reread raw')
    with zip_path.open('xb') as stream:
        stream.write(packed)
    result_pin=write_new(out/'ANALYSIS.actual.json',result)
    return result_pin


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True)
    parser.add_argument('--consume-after-film',action='store_true',help='Root invokes only after recording finishes; no live request is issued')
    args=parser.parse_args()
    need(args.consume_after_film,'Prepare-only default: do not read fulls until Root confirms film ended')
    manifest_data=args.manifest.read_bytes()
    need(len(manifest_data)<=MAX_META,'Reader manifest exceeds bounded metadata')
    result=consume(json.loads(manifest_data),args.output_dir)
    print(json.dumps({'analysis':result,'lane_bytes':used_bytes(),'native_or_SDK_calls':0},ensure_ascii=False))


if __name__=='__main__':
    main()
