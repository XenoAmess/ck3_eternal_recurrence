"""Keep all necessary witness values; avoid repeating them in small summaries."""
from pathlib import Path
import hashlib
import importlib.util
import re
import sys

HERE=Path(__file__).resolve().parent
BASE=HERE/'loss_endpoints.py'
BASE_SHA='03b999c34941c97f87d2e2d707c40df28eeddc84dc01d637988ed7ae9aa0aacd'


def compact_day(value):
    result={key:value[key] for key in ['day_index','date_raw','endpoint','original_full_reference','query_sequence']}
    original=value['physical']
    physical={key:item for key,item in original.items() if key!='cached_regiments'}
    physical['cached_regiments']=[{key:item for key,item in row.items() if key!='character_role'}
                                  for row in original['cached_regiments']]
    result['physical']=physical
    result['remaining_source_fields']='Exact field pointers, complete Character roles, actual full top-level evidence, full selected rows, both journal families and replay math remain in the same portable witness ZIP; no original full is discarded or reread.'
    return result


def load():
    data=BASE.read_bytes()
    if len(data)!=29027 or hashlib.sha256(data).hexdigest()!=BASE_SHA:
        raise RuntimeError('Prepared original reader changed')
    spec=importlib.util.spec_from_file_location('xar_e04_r191_loss_original_reader',BASE)
    if spec is None or spec.loader is None:
        raise RuntimeError('Cannot load prepared reader')
    module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    original=module.write_new
    def write_new(path,value):
        if re.fullmatch(r'day-[012]\.summary\.actual\.json',Path(path).name):
            value=compact_day(value)
        return original(path,value)
    module.write_new=write_new
    return module


if __name__=='__main__':
    load().main()
