"""Only the explicitly handed-off immutable R193 F2 Driver, one body read."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
HERE=Path(__file__).resolve().parent
SCENE=Path('D:/workspace/ck3_native_war_ai_promo_work/e04-r193-r09-reverse-a01')
RAW=None
PROJECTED=None
def need(v,s):
    if not v:raise RuntimeError(s)
def enc(v):return (json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n').encode()
def pin(p,b):return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def small(ref):
    p=Path(ref['path']);need(p.is_file() and p.stat().st_size==ref['bytes']<=2*1024*1024,'Small exact metadata required')
    b=p.read_bytes();need(hashlib.sha256(b).hexdigest()==ref['sha256'],'Small exactpin changed');return json.loads(b)
def main():
    global RAW,PROJECTED
    rp=Path('C:/ck3-e04-resume-20261015-a01/r193-reverse-packet-fix-a01/R193-F2-EXISTING-REFERENCES.actual.json')
    rb=rp.read_bytes();need(hashlib.sha256(rb).hexdigest()=='584f6b4b4fa5b5a39b9b2792e17e6c83f2ff134ce62db974fa452cf0b7cadc3e','Frozen peer metadata differs')
    refs=json.loads(rb)
    envelope=small(refs['strength_response']);snapshot=small(refs['snapshot_response']);frame=snapshot['body']
    need(envelope['is_error'] is False and snapshot['is_error'] is False,'Actual SDK original failed')
    ref=envelope['army_history_evidence']['raw_result_reference']
    need(ref==refs['complete_driver_reference_NOT_READ'],'Top-level original full reference differs')
    proof=small({'path':str(SCENE/'runtime-actor-identity.actual-a01.json'),'bytes':7767,'sha256':'5b582d575e5257ccee9cc882fafb8aa996d71b77b8cee363005073a731f0ecef'})
    need(frame['paused'] is True and frame['map_ready'] is True and frame['date_raw']==53146632 and frame['revision']==6 and frame['native_revision']==5 and frame['snapshot_id']=='native:5','Actual F2 source frame differs')
    need(frame['diagnostics']['bridge_pid']==proof['pid'] and frame['diagnostics']['connection_generation']==proof['connection_generation'] and frame['episode_run_id']==proof['episode_run_id'] and frame['played_character']['character_id']==proof['actual_runtime_character_full_id'],'Actual proof/frame lifetime differs')
    film=json.loads((SCENE/'r09-root-controller-a01/FILM-CONTROLLER.actual.json').read_bytes())
    need(film['recorder_finish']['state']=='NORMAL_TREE_EMPTY' and film['recorder_finish']['job']['returncode']==0 and film['recorder_finish']['job']['job_active_processes']==0,'Recorder must already be finished')
    path=Path(ref['path']);need(path.parent==SCENE/'state-a01/native-session/army-query-history-results' and path.stat().st_size==ref['bytes']==38197564<=64*1024*1024,'Immutable F2 stat/path differs')
    with (HERE/'F2-full.read-once.claim.json').open('xb') as f:f.write(enc({'machine_id':'desktop-3fevhd2-1c74096080','at_utc':datetime.now(timezone.utc).isoformat(),'reference':ref,'reason':'Actual reverse Merge succeeded; fixed selected93 prevented saved F2 packet. Recover once, no business request replay.','F2_body_read_count':1,'F0_body_read_count':0}))
    data=path.read_bytes();need(len(data)==ref['bytes'] and hashlib.sha256(data).hexdigest()==ref['sha256'],'F2 raw exact bytes differ')
    RAW=json.loads(data);del data
    for qkey,key in [('queried_snapshot_id','snapshot_id'),('queried_revision','revision'),('queried_native_revision','native_revision'),('queried_date_raw','date_raw'),('queried_episode_run_id','episode_run_id')]:
        need(RAW[qkey]==frame[key],'Raw query own frame differs '+qkey)
    need(RAW['queried_connection_generation']==proof['connection_generation'] and RAW['accepted'] is True and RAW['army_strengths_profile']=='ordinary_core_v1','Actual F2 query binding differs')
    ids=[r['army_id'] for r in frame['player_armies']];need(93 not in ids and 16777378 in ids,'Actual reverse survivor roster differs')
    need(set(ids)=={r['army_id'] for r in RAW['army_strengths']},'Actual whole query roster differs')
    selected=next(r for r in RAW['army_strengths'] if r['army_id']==16777378)
    need(selected['status']=='available' and type(selected['native_carmy_id']) is int,'Actual survivor native receiver unavailable')
    keys=('army_id','native_carmy_id','status','regiment_count','current_soldiers','maximum_soldiers','regiment_strengths','regiment_replenishment_records_v1','unavailable_reason','current_supply_raw','current_supply_scale','current_supply_capacity_raw','current_supply_capacity_scale','merge_supply_destination_weight_raw','merge_supply_destination_weight_scale')
    rows=[{k:r[k] for k in keys if k in r} for r in RAW['army_strengths']]
    fr={k:frame[k] for k in ('snapshot_id','revision','native_revision','date_raw','episode_run_id','paused','map_ready','played_character','player_armies')}
    fr['diagnostics']={k:frame['diagnostics'][k] for k in ('bridge_pid','connection_generation','connected','hello')}
    sys.path.insert(0,'D:/workspace/ck3_eternal_recurrence/ck3_autonomous_player/src')
    from xar_autoplayer.bridge.army_persistent_refill_eligibility_12004 import classify_army_persistent_refill_eligibility_12004
    classification=classify_army_persistent_refill_eligibility_12004(fr,RAW,army_id=16777378)
    PROJECTED={'schema':'xar.e04.r193-F2-once-read-recovery.v1','machine_id':'desktop-3fevhd2-1c74096080','source_head':'60de49f61d23b9c3437af4544c3f12bb28445429','run_id':'desktop-3fevhd2-1c74096080--vanilla--R0193',
      'frame':fr,'query':{**{k:RAW[k] for k in ('accepted','queried_snapshot_id','queried_revision','queried_native_revision')},'army_strengths':rows},
      'original_full_reference':ref,'source_pins':{'strength_response':refs['strength_response'],'snapshot_response':refs['snapshot_response']},
      'survivor_public_id':16777378,'survivor_native_carmy_id':selected['native_carmy_id'],'current_refill_classification':classification,
      'source_value_pointers':[{'json_pointer':'/army_strengths/'+str(i)+'/'+k,'canonical_value_bytes':len(enc(r[k])),'canonical_value_sha256':hashlib.sha256(enc(r[k])).hexdigest()} for i,r in enumerate(RAW['army_strengths']) for k in keys if k in r],
      'F2_Driver_body_reads':1,'F0_Driver_body_reads':0,'typed_survivor_query_pending':True,'original_film_RED_preserved':True,'R09_full_card_closed':False,'SDK_game_desktop_build_main_actions':0}
    b=enc(PROJECTED);out=HERE/'F2-RAW-PROJECTION.actual.json'
    need(sum(p.stat().st_size for p in HERE.rglob('*') if p.is_file())+len(b)<=256*1024,'R193 lane budget; parsed RAM retained')
    with out.open('xb') as f:f.write(b)
    print(json.dumps({'projection':pin(out,b),'survivor':{k:selected.get(k) for k in keys[:6]+keys[9:]},'classes':classification['physical_chunks'],'empty_roles':classification['empty_ArRg_rows'],'raw_body_read_count':1},ensure_ascii=False))
if __name__=='__main__':main()
