"""Only missing actual F1 guard138 inputs; once immutable body, no query."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys,io,zipfile
HERE=Path(__file__).resolve().parent
SCENE=Path('D:/workspace/ck3_native_war_ai_promo_work/e04-r193-r09-reverse-a01')
RAW=None
def need(v,s):
    if not v:raise RuntimeError(s)
def enc(v):return (json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n').encode()
def pin(p,b):return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def main():
    global RAW
    p=SCENE/'r09-split-merge-relay-a01/r09-reverse-a01/post-split.actual.json'
    need(p.stat().st_size<=2*1024*1024,'F1 small packet limit')
    b=p.read_bytes();sourcepin=pin(p,b);saved=json.loads(b);packet=saved['packet'];frame=packet['frame']
    need(saved['split_assertion']['accepted'] is True and frame['date_raw']==53146632 and frame['paused'] is True,'Actual F1 split packet unqualified')
    ids=(93,saved['split_assertion']['identity']['sibling_army_id'])
    cut=[row for row in packet['query']['army_strengths'] if row['army_id'] in ids]
    need(len(cut)==2 and all('fixed_chunk0_preparation_inputs_v1' not in row for row in cut),'Do not open full when saved packet already holds the guard inputs')
    ref=packet['refs']['strength_raw'];path=Path(ref['path'])
    need(path.parent==SCENE/'state-a01/native-session/army-query-history-results' and path.stat().st_size==ref['bytes']<=64*1024*1024,'Immutable F1 stat/parent mismatch')
    with (HERE/'F1-full.read-once.claim.json').open('xb') as f:f.write(enc({'machine_id':'desktop-3fevhd2-1c74096080','at_utc':datetime.now(timezone.utc).isoformat(),'reference':ref,
      'actual_small_packet':sourcepin,'reason':'Saved F1 allDATA has nativeCan/chunkCan but its fixed preparation guard138 leaf was omitted; original ENDPOINT not produced after F2 packet failed. Root conditionally authorized one F1 body for three-frame actual special inputs.',
      'F1_body_read_count':1,'F0_body_read_count':0,'SHA_and_parse_share_one_read_bytes':True}))
    data=path.read_bytes();need(len(data)==ref['bytes'] and hashlib.sha256(data).hexdigest()==ref['sha256'],'F1 exact body SHA mismatch')
    RAW=json.loads(data);del data
    for q,k in [('queried_snapshot_id','snapshot_id'),('queried_revision','revision'),('queried_native_revision','native_revision'),('queried_date_raw','date_raw'),('queried_episode_run_id','episode_run_id')]:
        need(RAW[q]==frame[k],'F1 raw own frame binding differs '+q)
    need(RAW['queried_connection_generation']==frame['diagnostics']['connection_generation'],'F1 connection generation changed')
    sys.path.insert(0,'D:/workspace/ck3_eternal_recurrence/ck3_autonomous_player/src')
    from xar_autoplayer.bridge.army_persistent_refill_eligibility_12004 import classify_army_persistent_refill_eligibility_12004
    classes={str(aid):classify_army_persistent_refill_eligibility_12004(frame,RAW,army_id=aid) for aid in ids}
    necessary=[]
    for i,row in enumerate(RAW['army_strengths']):
        if row['army_id'] in ids:
            value={k:row[k] for k in ('army_id','native_carmy_id','status','regiment_replenishment_records_v1','fixed_chunk0_preparation_inputs_v1') if k in row}
            necessary.append({'original_json_pointer':'/army_strengths/'+str(i),'value':value,'canonical_value_sha256':hashlib.sha256(enc(value)).hexdigest()})
    witness={'machine_id':'desktop-3fevhd2-1c74096080','source_head':saved['source_head'],'run_id':saved['run_id'],'date_raw':frame['date_raw'],'current_classification':classes,
      'original_reference':ref,'source_value_projections':necessary,'source_small_packet':sourcepin,'new_Driver_body_read_count':1,'SDK_calls':0,'R09_full_card_closed':False}
    archive=io.BytesIO()
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:z.writestr('F1-current-flags-witness.json',enc(witness))
    packed=archive.getvalue();summary={k:v for k,v in witness.items() if k!='source_value_projections'}
    summary['portable']=pin(HERE/'F1-CURRENT-FLAGS.portable.zip',packed)
    payload=enc(summary);need(sum(p.stat().st_size for p in HERE.rglob('*') if p.is_file())+len(payload)+len(packed)<=256*1024,'R193 budget; parsed RAM retained')
    for name,content in [('F1-CURRENT-FLAGS.actual.json',payload),('F1-CURRENT-FLAGS.portable.zip',packed)]:
        with (HERE/name).open('xb') as f:f.write(content)
    print(json.dumps({'summary':pin(HERE/'F1-CURRENT-FLAGS.actual.json',payload),'portable':summary['portable'],'actual_raw_bytes_read':ref['bytes'],'actual_guard138':[x['containing_guard_138_raw'] for v in classes.values() for x in v['physical_chunks']]},ensure_ascii=False))
if __name__=='__main__':main()
