"""Consume only immutable small DTOs after Root normal-close handoff; no raw opens."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,importlib.util,json,subprocess,sys,types,shutil
L=Path(__file__).resolve().parent;R=Path('D:/workspace/ck3_eternal_recurrence')
S=Path('D:/workspace/ck3_native_war_ai_promo_work/e04-r193-r09-reverse-a01');C=S/'r09-split-merge-relay-a01/r09-reverse-a01';T=S/'r09-root-controller-a01'
H='60de49f61d23b9c3437af4544c3f12bb28445429';M='desktop-3fevhd2-1c74096080';RUN=M+'--vanilla--R0193'
inputs={};cache={};sourcebytes={}
def need(v,s):
 if not v:raise ValueError(s)
def encode(v):return (json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n').encode()
def wire(v):return json.loads(json.dumps(v,ensure_ascii=False))
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p,expected=None):
 p=Path(p);key=str(p.resolve())
 if key not in cache:
  need(p.is_file() and not p.is_symlink() and p.stat().st_size<=2*1024*1024,'Only bounded small exact named input: '+key)
  b=p.read_bytes();cache[key]=b;inputs[key]={'path':key,'bytes':len(b),'sha256':sha(b)}
 b=cache[key]
 if expected:need(len(b)==expected['bytes'] and sha(b)==expected['sha256'],'Exact input changed '+key)
 return json.loads(b)
def pinned(pin):return read(pin['path'],pin)
def pin(p):read(p);return inputs[str(Path(p).resolve())]
def historical(rel):
 b=subprocess.check_output(['git','show',H+':'+rel],cwd=R);sourcebytes[rel]=b;return b
def module(name,b,path):
 m=types.ModuleType(name);m.__file__=str(path);sys.modules[name]=m;exec(compile(b,str(path),'exec'),m.__dict__);return m
def save(name,v):
 p=L/name;b=encode(v);need(not p.exists(),'Create-only '+str(p))
 need(sum(x.stat().st_size for x in L.rglob('*') if x.is_file())+len(b)<=1024*1024,'Root1MiB lane ceiling')
 with p.open('xb') as f:f.write(b)
 return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def available(packet):return [v for v in packet['query']['army_strengths'] if v['status']=='available']
def main():
 need(sys.version_info[:2]==(3,14),'Explicit main venv required');need(shutil.disk_usage(L).free>20*1024**3,'Local system floor')
 sys.path.insert(0,str(R/'ck3_autonomous_player/src'))
 from xar_autoplayer.bridge import army_split_merge_observation_12004 as obs
 root='promo/ck3_native_war_ai/episode-04-march-logistics/tools/review02/split_merge/'
 relay=module('r193_historical_relay',historical(root+'root_relay.py'),R/root/'root_relay.py')
 transfer=module('r193_historical_transfer',historical(root+'army_split_transfer_assertions_12004.py'),R/root/'army_split_transfer_assertions_12004.py')
 policyrel='ck3_autonomous_player/src/xar_autoplayer/bridge/army_split_unrelated_role_transfer_12004.py'
 pp=L/'policy-candidate-a01/patch-root'/policyrel;policybytes=pp.read_bytes();need(len(policybytes)==6303 and sha(policybytes)=='ad159c4feae262dd84aa33ef993fcc9d39ccd6f7e4cabd4eeea87a704e0e81f8','Exact qualified role policy')
 policy=module('r193_finite_role_policy',policybytes,pp)
 config=read(T/'controller-input.actual.json');proof=read(S/'runtime-actor-identity.actual-a01.json')
 need(config['source_head']==proof['source_head']==H and config['run_id']==proof['run_id']==RUN and config['direction']=='sibling','Historical source/run exact')
 binding=relay.admission(pinned(config['context']),proof,run_id=RUN,source=H,sequence=193,machine=M,minimum_sequence=1)
 before=read(C/'baseline.actual.json');splitstored=read(C/'post-split.actual.json');f0=before['packet'];f1=splitstored['packet']
 projection=read(L/'F2-RAW-PROJECTION.actual.json',{'bytes':78208,'sha256':'ca208fb76e66f874dd095e570d67b9525305badae937c3e6b210b16301c5c27b'})
 recovery=read(S/'r09-f2-readonly-recovery-a01/RECOVERY.actual.json',{'bytes':7835,'sha256':'ab38710a824b783e4ab568a2f38a826359ca02c963cc970065dc96e1e75b8900'})
 need(recovery['same_frame_fence_verified'] is True and recovery['new_actions']==recovery['new_strength_queries']==0,'Recovery read-only actual')
 f2={'frame':projection['frame'],'query':projection['query'],'commanders':{},'refs':{},'literal_projection_only':True}
 _,excluded=relay.selected_available_cohorts(f2['query']['army_strengths'],f2['frame'],16777378)
 f2.update(excluded_unavailable_cohorts=excluded,strategy_army_ids=[16777378],qualified_scope='available actual roster; known unavailable row retained',all_roster_strengths_qualified=False,R09_full_card_closed=False)
 for k in ('01-before','06-fence'):
  packet=pinned(recovery['refs'][k]['response']);need(packet['is_error'] is False,'Recovery snapshot error');relay.validate_frame(packet['body'],binding);relay.same_frame(packet['body'],f2['frame']);f2['refs'][k]=recovery['refs'][k]
 for k,row in recovery['typed_commanders'].items():
  envelope=pinned(row['response']);need(envelope['is_error'] is False,'Typed response error');body=envelope['body'];dto=body['army_commander_candidates']
  minimal={x:body[x] for x in ('accepted','read_only','queried_snapshot_id','queried_revision','queried_native_revision')}
  minimal['army_commander_candidates']={x:dto[x] for x in ('army_id','native_carmy_id','date_raw','snapshot_revision','current_commander')}
  need(obs.read_bound_current_commander(minimal,f2['frame'],army_id=int(k),native_carmy_id=row['native_carmy_id'])==row['current_commander_id'],'Actual typed commander mismatch')
  need(next(a['native_carmy_id'] for a in available(f2) if a['army_id']==int(k))==row['native_carmy_id'],'Actual typed/full native CArmy mismatch')
  f2['commanders'][k]=minimal;f2['refs']['typed-'+k]=row['response']
 f2['refs'].update(original_full_reference=projection['original_full_reference'],original_projection=pin(L/'F2-RAW-PROJECTION.actual.json'),recovery=pin(S/'r09-f2-readonly-recovery-a01/RECOVERY.actual.json'))
 for packet in (f0,f1,f2):
  relay.validate_frame(packet['frame'],binding)
  q=packet['query'];need(q['accepted'] is True,'Strength accepted required')
  need([q[x] for x in ('queried_snapshot_id','queried_revision','queried_native_revision')]==[packet['frame'][x] for x in ('snapshot_id','revision','native_revision')],'Query own frame mismatch')
 need({p['frame']['date_raw'] for p in (f0,f1,f2)}=={53146632},'Paused day changed')
 child=obs.identify_split_sibling(f0['frame'],f1['frame'],source_army_id=93,pre_strengths=f0['query'],post_strengths=f1['query'])['sibling_army_id'];need(child==16777378,'Actual child identity')
 need(child in relay.roster(f2['frame']) and 93 not in relay.roster(f2['frame']),'Reverse survivor/removal')
 split=transfer.assert_fresh_split_transfer_12004(f0['frame'],f1['frame'],source_army_id=93,pre_strengths=f0['query'],post_strengths=f1['query'],pre_commander=f0['commanders']['93'],post_commanders={int(k):v for k,v in f1['commanders'].items()})
 role=policy.qualify_unrelated_role_removal(f0,f1,source_army_id=93)
 maps=[{a['army_id']:a for a in p['query']['army_strengths']} for p in (f0,f1,f2)]
 merge=relay.compare_data_roles(transfer,[maps[1][child],maps[1][93]],[maps[2][child]])
 supply=relay.compare_merge_supply(f1,f2,[child,93]);unrelated=obs.compare_split_merge_cohorts([maps[1][i] for i in (18,94,95)],[maps[2][i] for i in (18,94,95)])
 need(unrelated['frozen_exact_cohort_pass'] is True,'Merge unrelated full physical/cache changed')
 for i in (18,94,95):
  need(relay.roster(f1['frame'])[i]==relay.roster(f2['frame'])[i],'Merge unrelated roster changed')
  for key in ('current_supply_raw','current_supply_capacity_raw','merge_supply_destination_weight_raw','native_carmy_id'):
   need(maps[1][i][key]==maps[2][i][key],'Merge unrelated scalar changed '+key)
  need(obs.read_bound_current_commander(f1['commanders'][str(i)],f1['frame'],army_id=i,native_carmy_id=maps[1][i]['native_carmy_id'])==obs.read_bound_current_commander(f2['commanders'][str(i)],f2['frame'],army_id=i,native_carmy_id=maps[2][i]['native_carmy_id']),'Merge unrelated typed commander changed')
 observations=[transfer._observe(available(p)) for p in (f0,f1,f2)]
 totals=[{'unique_physical_slots':len(v[1]),'physical_current_max':[sum(w[i] for w in v[1].values()) for i in (0,1)],'cached_current_max':[sum(a[k] for a in available(p)) for k in ('current_soldiers','maximum_soldiers')]} for p,v in zip((f0,f1,f2),observations)]
 need(observations[0][1]==observations[1][1]==observations[2][1] and observations[0][2]==observations[1][2]==observations[2][2],'Global physical/occurrence values changed')
 old,new=observations[1][0],observations[2][0];added=set(new)-set(old);removed=set(old)-set(new)
 need(not removed and added=={33554491} and transfer._empty_character(new[33554491]),'New reverse role must be actual empty1/1')
 rr=new[33554491];rd=rr['data']['native_character_role_v1'];need(rd['character_raw_id_148']==rd['resolved_character_id']==36445 and rd['arrg_army_id_140']==rd['native_carmy_id']==16777371 and rd['extension_arrg_id_f8']==33554491 and rd['extension_army_id_f4']==-1,'Reverse new role full backlink mismatch')
 for i in set(old)&set(new):need(old[i]['signature']==new[i]['signature'],'Common global physical record signature changed')
 e0=read(T/'baseline-ENDPOINT.actual.json');ff0=read(Path('D:/workspace/ck3_native_war_ai_promo_work/e04-r192-r09-forward-a01/r09-root-controller-a01/baseline-ENDPOINT.actual.json'))
 forwardproof=read(Path('D:/workspace/ck3_native_war_ai_promo_work/e04-r192-r09-forward-a01/runtime-actor-identity.actual-a01.json'))
 need(e0['normal_save_sha256']==ff0['normal_save_sha256']==config['source_checkpoint']['save']['sha256'] and e0['frozen_observable']==ff0['frozen_observable'],'Pair common frozen S0/observable mismatch')
 need((proof['pid'],proof['process_creation_filetime_100ns'])!=(forwardproof['pid'],forwardproof['process_creation_filetime_100ns']),'Actual cold lifetimes must differ')
 flags1=read(L/'F1-CURRENT-FLAGS.actual.json');flags=[e0['current_refill_classification'],flags1['current_classification'],{str(child):projection['current_refill_classification']}]
 classification=[]
 for n,stage in enumerate(flags):
  chunks=[x for row in stage.values() for x in row['physical_chunks']];keys={(x['persistent_regiment_id'],x['chunk_index']) for x in chunks}
  need(len(chunks)==len(keys)==4 and all(x['containing_guard_138_raw']==1 and x['native_can_replenish'] is False and x['native_chunk_can_replenish'] is False and x['observed_prepared148_raw']==0 for x in chunks),'Three-frame current flags mismatch')
  classification.append({'stage':'F'+str(n),'physical_chunks':chunks})
 claim=read(C/'merge.once.claim.json');ack=read(C/'merge.submission.actual.json');need(claim['army_ids']==[child,93] and ack['body']['accepted'] is True and ack['body']['war_action']['postcondition_verified'] is True,'Actual unique reverse Merge ACK')
 close={}
 for name,expected in [('NORMAL-SAVE.actual.json',{'bytes':4747,'sha256':'8384275eeec29935712a196d28d082480861545d1450b759c9c501b5a3c06253'}),('BOOTSTRAP-OBSERVED.actual.json',{'bytes':917,'sha256':'93fd723c170af2622044374c933720a1ef5f9e3ee02f45048d8edf9434c849bc'}),('SCREEN-RELEASE.actual.json',{'bytes':4849,'sha256':'9556280bfd7975d9c131d06b933d6e3c45ff499ada2a7b3d3493005476c193fa'})]:
  p=S/'r09-reverse-a01-ready-close-a01'/name;close[name]=read(p,expected)
 film=read(T/'FILM-CONTROLLER.actual.json');need(film['error']=="RuntimeError('selected Army unavailable; cannot proceed')" and film['R09_full_card_closed'] is False,'Original primary RED preserved')
 media=read(Path('D:/workspace/ck3_native_war_ai_promo_work/e04-r193-media-audit-bounded-a01/portable-media-facts.actual-a01.json'),{'bytes':12000,'sha256':'029f1691966b4e8baf4f6771b19fdcb7578f130b6d110a99bf6ace3f962c396a'})
 numeric=split['accepted'] and merge['accepted'] and supply['weighted_supply_match'] and role['role_aware_physical_guard_pass']
 result={'schema':'xar.e04.r193-recovered-reverse-and-r192-pair.v1','machine_id':M,'at_utc':datetime.now(timezone.utc).isoformat(),'source_head':H,'run_id':RUN,'same_normal_S0':True,'full_F0_observable_equals_R192':True,'independent_actual_cold_process_lifetime':True,'paused_date_raw':53146632,'source_public_native':[93,85],'child_public_native':[child,16777371], 'reverse_merge_army_ids':[child,93],
 'split_assertion_recomputed':wire(split),'split_finite_unrelated_role_policy':wire(role),'merge_DATA_roles':wire(merge),'merge_unrelated_strict':wire(unrelated),'merge_supply':supply,'global_physical_and_cached_F0_F1_F2':totals,'global_physical_ID_current_max_state_and_occurrences_equal':True,
 'merge_new_empty_role':{'army_regiment_id':33554491,'army_id':child,'current_max':[1,1],'native_character_role_v1':rd},'current_survivor_commander':obs.read_bound_current_commander(f2['commanders'][str(child)],f2['frame'],army_id=child,native_carmy_id=16777371),
 'three_frame_current_refill_classification':classification,'sameS0_two_directions_numeric_qualified':bool(numeric),'forward_result_reference':{'path':'C:/ck3-e04-resume-20261015-a01/r192-r09-forward-analysis-a01/MERGE-ANALYSIS.actual.json','bytes':15268,'sha256':'a4b4f8e2fb75d99f2142906bc7132cc76dfec65f0cde3862c23ad5cc261b6da6'},
 'R192_original_strict_RED_preserved':True,'R193_original_film_RED_preserved':True,'R193_original_error':film['error'],'survivor_GUI_stage_executed':False,'media_encoded_seconds':65.033,'media_wall_seconds':68.598599,'recorded_120_seconds_qualified':False,'dynamic_clean_human_qualified':False,'R09_full_card_closed':False,'distinct_stock_observed':supply['distinct_pre_stock_observed'],'upper_clamp_positive':supply['upper_clamp_observed'],'distinct_stock_or_clamp_are_extra_R09_card_gates':False,
 'all_roster_strengths_qualified':False,'excluded_unavailable_cohorts':excluded,'birth_PC_or_spawn_enum_observed':False,'actual_physical_refill_observed':False,'normal_close_small_original_pins':[inputs[str((S/'r09-reverse-a01-ready-close-a01'/n).resolve())] for n in close],
 'raw_Driver_body_reads_this_analysis':0,'cumulative_R193_raw_body_read_counts':{'F0':0,'F1':1,'F2':1},'SDK_game_desktop_main_build_actions':0,'source_value_pointers':{'F0':'/packet/query/army_strengths + baseline-ENDPOINT /current_refill_classification','F1':'/packet/query/army_strengths + F1-CURRENT-FLAGS /current_classification','F2':'F2-RAW-PROJECTION /query/army_strengths and /source_value_pointers','typed':'RECOVERY /typed_commanders response /body/army_commander_candidates/current_commander'},'actual_input_pins':list(inputs.values()),'python':{'executable':sys.executable,'version':sys.version,'argv':sys.argv}}
 need(numeric,'Actual numerical qualification failed')
 packetpin=save('POSTMERGE-PACKET.actual-a02.json',{'machine_id':M,'source_head':H,'run_id':RUN,'binding':binding,'packet':f2,'recovery_only':True,'original_controller_RED_preserved':True,'R09_full_card_closed':False})
 result['recovered_F2_packet']=packetpin
 resultpin=save('REVERSE-PAIR-ANALYSIS.actual-a02.json',result)
 print(json.dumps({'result':resultpin,'packet':packetpin,'numeric':numeric,'physical_and_cache':totals,'supply':supply,'R09_full_card_closed':False}))
if __name__=='__main__':main()
