"""Offline exact first-take fixture and rejection check; never changes it."""
from __future__ import annotations
from copy import deepcopy
import json
from pathlib import Path
from r203_postcondition_contract import exact_day_postcondition

RUN = Path("D:/workspace/ck3_native_war_ai_promo_work/e04-r203-battle-logistics-a01/desktop-3fevhd2-1c74096080--vanilla--R0203/responses")

def body(name):
    path = RUN / (name + ".json")
    row = json.loads(path.read_text(encoding="utf-8"))
    assert row["is_error"] is False
    return row["body"]

def main():
    before = body("r203-film-d01-before")
    step = body("r203-film-d01-life-advance-once")
    later = body("r203-battle-a01-ready-record-cleanup-a01-before")
    good = exact_day_postcondition(step, before, later)
    assert good["exact_day"] and good["ending_date_raw"] == 53148888
    for key, bad in (("progress_status", "submitted"), ("elapsed_days", 2),
                     ("paused", False)):
        changed = deepcopy(step)
        changed[key] = bad
        try:
            exact_day_postcondition(changed, before, later)
        except ValueError:
            pass
        else:
            raise AssertionError("bad composite accepted: " + key)
    altered = deepcopy(later)
    altered["date_raw"] += 24
    try:
        exact_day_postcondition(step, before, altered)
    except ValueError:
        pass
    else:
        raise AssertionError("bad independent snapshot accepted")
    print(json.dumps({"offline_contract_pass": True, "historical_first_take_relabelled": False,
                      "original_step_date": good["ending_date_raw"], "sdk_calls": 0}))

if __name__ == "__main__":
    main()
