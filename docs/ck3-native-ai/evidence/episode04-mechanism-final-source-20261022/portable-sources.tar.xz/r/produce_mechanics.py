"""One bounded cue pass, then one public full concat; no automatic retry."""
from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys

from mechanics_contract import (ACTIVE_WORK_MAX, FULL_LIMIT, FULL_MOVIE_MAX, MACHINE,
    LATE_LIMIT, LATE_WORK_MAX, LATE_CAS_MAX, Phase, EXPECTED_CUES, SERIES_PALETTE,
    SEGMENT_CAS_MAX, SEGMENT_LIMIT, Asset, Editorial, Inputs, Pin, Production, array, decimal64,
    integer, need, obj, project_successor, read, text)
from mechanics_composer import clock, cue_plan, knowledge_svg
from xar_promo.operations import preserve_artifact, start_run
from xar_promo.process import CommandResult, CommandSpec, run_command
from xar_promo.project import artifact_path
from xar_promo.render import execute_render_plan, plan_concat

SUPPORT = Path('C:/ck3-e04-resume-20261020-a01/r17-b-firstclip-qa-a01')
for name, size, sha in [('qa_contract.py',7782,'3e4767dd66b8b4a1ef537b2126b564a15bf58e8c8082dc948631b2358bb071fb'),
                      ('qa_firstclip.py',22781,'27634f311d1c2f11707fcf5128138cf13bc587b78677dd1a1a90b7a86e30f955')]:
    Pin(SUPPORT / name, size, sha).verify()
sys.path.insert(0,str(SUPPORT))
from qa_firstclip import Native, birth, finish_custody
from qa_contract import Pin as JobPin


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def total(root: Path) -> int:
    return sum(p.stat().st_size for p in root.rglob('*') if p.is_file())


def saved(root: Path, name: str, row: dict[str, object], limit: int) -> Pin:
    path = root / name
    path.parent.mkdir(parents=True,exist_ok=True)
    raw = (json.dumps({'machine_id':MACHINE,'observed_at_utc':now(),**row},ensure_ascii=False,indent=2)+'\n').encode()
    need(total(root)+len(raw) <= limit, 'Metadata exceeds actual phase aggregate cap')
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    return Pin(path,len(raw),hashlib.sha256(raw).hexdigest())


def phase_limit(phase: Phase) -> int:
    return LATE_LIMIT if phase == 'n05' else SEGMENT_LIMIT if phase == 'segments' else FULL_LIMIT


def stage_ids(phase: Phase) -> tuple[str,...]:
    return (('N05-01',) if phase == 'n05' else
            tuple(c for c in EXPECTED_CUES if c != 'N05-01') if phase == 'segments' else EXPECTED_CUES)


def cue_fingerprint(production: Production, inputs: Inputs, index: int) -> str:
    cue, visual = production.editorial.cues[index], production.visuals[index]
    if production.products.knowledge_override is not None and visual.card_id == 'K17':
        source: object = production.products.knowledge_override.svg.wire()
    elif production.yellow is not None:
        source = next(f.svg.wire() for f in production.yellow.formulas if f.card_id == visual.card_id)
    elif visual.card_id.startswith('K'):
        card = next(c for c in production.knowledge if c.card_id == visual.card_id)
        source = knowledge_svg(card)
    elif visual.card_id == 'F16':
        source = obj(array(inputs.formula_override.load().get('overrides'))[0]).get('new_SVG')
    else:
        source = next(f.svg.wire() for f in production.products.formulas if f.card_id == visual.card_id)
    raw: object = None
    if visual.raw_key is not None:
        window = production.raw_windows[visual.raw_key]
        raw = {'source':window.source.wire(),'first':window.first,'end':window.end}
    return hashlib.sha256(json.dumps({'cue':asdict(cue),'visual':asdict(visual),'card_source':source,
        'raw':raw},sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()


def product_rows(data: dict[str,object], phase: Phase) -> list[dict[str,object]]:
    need(phase != 'full' and data.get('machine_id') == MACHINE and
         data.get('schema') == 'xar.e04.mechanics.segment-products.v1' and data.get('phase') == phase and
         data.get('complete_project') is False and integer(data.get('expected_project_cues')) == 47 and
         integer(data.get('frame_rate')) == 30, 'Not an explicitly partial cue-products manifest')
    rows = [obj(v) for v in array(data.get('entries'))]
    need(tuple(text(r.get('cue_id')) for r in rows) == stage_ids(phase) and
         integer(data.get('actual_cue_count')) == len(rows) and
         tuple(text(v) for v in array(data.get('deferred_cues'))) ==
         tuple(c for c in EXPECTED_CUES if c not in stage_ids(phase)), 'Wrong actual/deferred cue set')
    need('total_frames' not in data and all('timeline_start_frame' not in r for r in rows),
         'Partial stages cannot claim a complete timeline')
    return rows


class Owner:
    def __init__(self, root: Path, inputs: Inputs, admission: dict[str, object],
                 phase: Phase) -> None:
        self.root, self.inputs, self.phase = root, inputs, phase
        self.limit = phase_limit(phase)
        self.work_max = LATE_WORK_MAX if phase == 'n05' else ACTIVE_WORK_MAX if phase == 'segments' else FULL_MOVIE_MAX
        self.deadline = datetime.fromisoformat(text(admission.get('hard_deadline_utc')).replace('Z','+00:00'))
        self.card = admission
        self.children = 0
        self.successful_children = 0
        self.last_wait: Pin | None = None
        self.last_success = False
        self.native = Native(JobPin(str(inputs.job_helper.path),inputs.job_helper.size,inputs.job_helper.sha))

    def save(self, name: str, row: dict[str,object]) -> Pin:
        return saved(self.root,name,row,self.limit)

    def guard(self) -> None:
        need(datetime.now(timezone.utc) < self.deadline, 'Actual media deadline expired')
        need(total(self.root) < self.limit, 'All-inclusive media root limit exceeded')
        active = sum(p.stat().st_size for p in (self.root/'work').rglob('*.mp4') if p.is_file())
        need(active <= self.work_max, 'Active work movie cap exceeded; preserve partial')

    def command(self, spec: CommandSpec, *, audit_directory: Path) -> CommandResult:
        def owned(argv: list[str], *, cwd: str | None, env: dict[str,str] | None,
                  shell: bool, check: bool, stdout: int, stderr: int, text: bool,
                  encoding: str, errors: str) -> subprocess.CompletedProcess[str]:
            need(not shell and not check and text, 'Public process ABI changed')
            self.last_wait,self.last_success = None,False
            self.guard()
            job = integer(self.native.call('_new_job'),1)
            process: subprocess.Popen[bytes] | None = None
            born: str | None = None
            failure: str | None = None
            out, err = b'', b''
            custody: dict[str,object] = {}
            try:
                process = subprocess.Popen(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,
                    stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                    creationflags=4 | subprocess.BELOW_NORMAL_PRIORITY_CLASS)
                self.children += 1
                handle: object = getattr(process,'_handle')
                need(isinstance(handle,int) and not isinstance(handle,bool), 'Original HANDLE unavailable')
                need(bool(self.native.call('_assign_job',job,handle)), 'Job assignment failed')
                member = wintypes.BOOL()
                need(bool(self.native.call('_in_job',handle,job,ctypes.byref(member))) and bool(member.value)
                     and self.native.count(job) == 1, 'Original Job membership before resume failed')
                need(integer(self.native.call('_verified_limit_flags',job)) & 8192 != 0,
                     'Kill-on-close flag absent')
                born = birth(process)
                self.save(str(audit_directory.relative_to(self.root)/'ORIGINAL-START.actual.json'),
                      {'argv':argv,'pid':process.pid,'birth_filetime':born,'assigned_before_resume':True})
                self.native.call('_resume_only_thread',process.pid)
                while True:
                    self.guard()
                    try:
                        out,err = process.communicate(timeout=.25)
                        break
                    except subprocess.TimeoutExpired:
                        continue
            except BaseException as error:
                failure = type(error).__name__ + ': ' + str(error)
            finally:
                if process is not None:
                    try:
                        custody = finish_custody(process,failed=failure is not None,
                            terminate=lambda:self.native.stop(job),active=lambda:self.native.count(job),
                            close=lambda:self.native.close(job))
                    except BaseException as custody_error:
                        failure = (failure or '') + ' custody: ' + repr(custody_error)
                        custody = {'original_wait':process.poll(),'job_active_processes':None,
                                   'job_closed':False,'custody_error':repr(custody_error)}
                    if process.poll() is not None:
                        self.children -= 1
                        if failure is not None:
                            out,err = process.communicate()
                    for pipe in (process.stdout,process.stderr):
                        if pipe is not None:
                            pipe.close()
                else:
                    self.native.close(job)
                codec = 'mbcs' if Path(argv[0]).name.lower() == 'tasklist.exe' else encoding
                need(total(self.root)+len(out)+len(err) < self.limit,'Raw process streams exceed phase budget')
                for filename,payload in [('original-stdout.bin',out),('original-stderr.bin',err)]:
                    with (audit_directory/filename).open('xb') as stream:stream.write(payload)
                self.last_wait = self.save(str(audit_directory.relative_to(self.root)/'ORIGINAL-WAIT.actual.json'),
                    {'argv':argv,'pid':process.pid if process else None,'birth_filetime':born,**custody,
                     'error':failure,'same_original_Popen_retained':process is not None,
                     'actual_stream_encoding':codec,'no_retry':True})
            code = custody.get('original_wait')
            ok = (failure is None and type(code) is int and code == 0 and
                  custody.get('job_active_processes') == 0 and custody.get('job_closed') is True)
            if ok:
                self.successful_children += 1
                self.last_success = True
            return subprocess.CompletedProcess(argv,0 if ok else -1,out.decode(codec,errors),
                err.decode(codec,errors) + ('\n'+failure if failure else ''))
        environment = dict(os.environ)
        environment.update(TMP=str(self.root/'temp'),TEMP=str(self.root/'temp'),PYTHONDONTWRITEBYTECODE='1')
        return run_command(spec,audit_directory=audit_directory,environment=environment,run=owned)

    def idle(self) -> None:
        spec = CommandSpec.create(['C:/Windows/System32/tasklist.exe','/FI','IMAGENAME eq ffmpeg.exe',
                                  '/FO','CSV','/NH'],label='No recorder or QA overlap')
        result = self.command(spec,audit_directory=self.root/'audit'/self.phase/'census')
        need(result.succeeded and 'ffmpeg.exe' not in result.stdout.lower(), 'Another FFmpeg owns the scene')


class FileInformation(ctypes.Structure):
    _fields_ = [('attributes',wintypes.DWORD),('creation',wintypes.FILETIME),
        ('access',wintypes.FILETIME),('write',wintypes.FILETIME),('volume',wintypes.DWORD),
        ('size_high',wintypes.DWORD),('size_low',wintypes.DWORD),('links',wintypes.DWORD),
        ('index_high',wintypes.DWORD),('index_low',wintypes.DWORD)]


def retire_own_work(owner: Owner, work: Path, native: Pin, cue_id: str) -> None:
    """Delete only this closed producer's exact duplicate through the same held HANDLE."""
    need(owner.phase in ('segments','n05') and owner.card.get('exact_own_work_retirement_admitted') is True
         and owner.children == 0 and owner.last_success and owner.last_wait is not None,
         'Self-work retirement not admitted/original child not proven closed')
    if owner.last_wait is None:
        raise ValueError('No original FFmpeg wait')
    original_wait = owner.last_wait.load()
    argv = array(original_wait.get('argv'))
    need(bool(argv) and Path(text(argv[0])).resolve() == owner.inputs.ffmpeg.pin.path.resolve()
         and integer(original_wait.get('original_wait')) == 0 and
         integer(original_wait.get('job_active_processes')) == 0 and original_wait.get('job_closed') is True,
         'The original FFmpeg wait0/Job0 is required before duplicate retirement')
    target = work.resolve()
    need(target == (owner.root/'work/segments'/(cue_id+'.mp4')).resolve()
         and target.is_relative_to((owner.root/'work/segments').resolve()), 'Not the exact self-created cue work')
    registry = owner.inputs.permanent_registry.load()
    need(registry.get('schema') == 'xar.user-explicit-permanent-assets.v1', 'Permanent registry unavailable')
    for value in array(registry.get('assets')):
        asset = obj(value)
        if asset.get('machine_id') == MACHINE:
            need(Path(text(asset.get('absolute_path'))).resolve() != target, 'Permanent asset protected')
    native.verify()
    kernel = ctypes.WinDLL('kernel32',use_last_error=True)
    create = kernel.CreateFileW
    create.argtypes = [wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,
                       wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE]
    create.restype = wintypes.HANDLE
    close = kernel.CloseHandle
    close.argtypes, close.restype = [wintypes.HANDLE], wintypes.BOOL
    info = kernel.GetFileInformationByHandle
    info.argtypes, info.restype = [wintypes.HANDLE,ctypes.POINTER(FileInformation)],wintypes.BOOL
    final_name = kernel.GetFinalPathNameByHandleW
    final_name.argtypes = [wintypes.HANDLE,wintypes.LPWSTR,wintypes.DWORD,wintypes.DWORD]
    final_name.restype = wintypes.DWORD
    read_file = kernel.ReadFile
    read_file.argtypes = [wintypes.HANDLE,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(wintypes.DWORD),ctypes.c_void_p]
    read_file.restype = wintypes.BOOL
    dispose = kernel.SetFileInformationByHandle
    dispose.argtypes = [wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD]
    dispose.restype = wintypes.BOOL
    handle = create(str(target),0x80000000|0x10000,1,None,3,0x00200000,None)
    need(handle not in (None,ctypes.c_void_p(-1).value), 'Exact owned work READ+DELETE handle unavailable')
    try:
        actual = FileInformation()
        need(bool(info(handle,ctypes.byref(actual))) and not actual.attributes & 0x410 and actual.links == 1,
             'Owned work is not a regular single-link file')
        buf = ctypes.create_unicode_buffer(32768)
        count: object = final_name(handle,buf,len(buf),0)
        need(integer(count,1) < len(buf), 'Owned work final path unavailable')
        resolved = buf.value[4:] if buf.value.startswith('\\\\?\\') else buf.value
        need(Path(resolved).resolve() == target, 'Held work final path differs')
        size = (int(actual.size_high)<<32)|int(actual.size_low)
        need(size == native.size, 'Work and immutable CAS sizes differ')
        chunk = ctypes.create_string_buffer(1024*1024)
        digest = hashlib.sha256()
        while True:
            got = wintypes.DWORD()
            need(bool(read_file(handle,chunk,len(chunk),ctypes.byref(got),None)), 'Held work read failed')
            if not got.value:
                break
            digest.update(chunk.raw[:got.value])
        need(digest.hexdigest() == native.sha, 'Held work/full CAS SHA differs')
        owner.save('retirement/'+cue_id+'-INTENT.actual.json',{'work_path':str(target),
            'work_bytes':size,'work_sha256':native.sha,'work_volume_serial32':int(actual.volume),
            'work_file_id':str((int(actual.index_high)<<32)|int(actual.index_low)),
            'native_CAS':native.wire(),'original_FFmpeg_wait':owner.last_wait.wire(),
            'source': 'same READ+DELETE handle denies writes/deletes',
            'permanent_registry':owner.inputs.permanent_registry.wire(),'scope':'self-created successful duplicate only'})
        disposition = wintypes.BOOL(True)
        need(bool(dispose(handle,4,ctypes.byref(disposition),ctypes.sizeof(disposition))), 'Exact work disposition failed')
    finally:
        need(bool(close(handle)), 'Exact work handle close failed')
    need(not target.exists() and native.path.is_file(), 'Exact retirement readback failed')
    owner.save('retirement/'+cue_id+'-RESULT.actual.json',{'work_path':str(target),'deleted':True,
        'logical_duplicate_bytes':native.size,'physical_credit_claimed':0,'native_CAS_retained':native.wire()})


def card_paths(production: Production) -> dict[str,Path]:
    need(production.yellow is not None,'Actual adopted yellow35 required; old blue assets are not executable')
    if production.yellow is None:
        raise ValueError('Yellow images absent')
    result = {f.card_id:f.native.path for f in production.yellow.formulas}
    if production.products.knowledge_override is not None:
        image = production.products.knowledge_override
        result['K17'] = image.native.path
    return result


def verify_inputs(inputs: Inputs, production: Production) -> None:
    source = inputs.source_plan.load()
    need(source.get('machine_id') == MACHINE, 'Accepted source-plan machine differs')
    closed = inputs.producer_closure.load()
    need(closed.get('machine_id') == MACHINE and closed.get('state') == 'ACTUAL_ASSETS_OWNER_CLOSED'
         and integer(closed.get('owned_Popen_remaining')) == 0 and integer(closed.get('author_writers_remaining')) == 0
         and closed.get('all_original_current_children_wait0') is True, 'Voice/PNG producer not closed')
    ready = inputs.toolchain.load()
    need(ready.get('machine_id') == MACHINE and ready.get('ready') is True and ready.get('wheel_digest_match') is True,
         'No same-run current official toolchain qualification')
    Pin.parse(ready.get('official_current_query')).verify()
    retained = inputs.retained_products.load()
    need(retained.get('machine_id') == MACHINE, 'Retained asset identity machine differs')
    assets = tuple(Asset.parse(v) for v in array(retained.get('assets'))) + inputs.product_override_identities
    lookup = {a.pin:a for a in assets}
    required = [v.native for v in production.products.voices] + [f.native for f in production.products.formulas]
    if production.products.knowledge_override is not None:
        required.append(production.products.knowledge_override.native)
    for pin in required:
        need(pin in lookup,'Missing retained native asset identity')
        lookup[pin].verify_identity()
    for raw in production.raw_windows.values():raw.source.verify_identity()
    inputs.music.verify_identity();inputs.ffmpeg.verify_identity();inputs.ffprobe.verify_identity()
    if production.yellow is not None:
        for asset in production.yellow.identities:asset.verify_identity()
        for image in production.yellow.formulas:image.svg.verify()
    drawing = inputs.renderer_inputs.load()
    for key in ('font_regular','font_bold'):
        row = obj(drawing.get(key)); identity = obj(row.get('identity'))
        actual = Path(text(row.get('path'))).stat()
        need((actual.st_size,str(actual.st_mtime_ns),str(actual.st_dev),str(actual.st_ino)) ==
             (integer(row.get('bytes'),1),decimal64(identity.get('mtime_ns')),
              decimal64(identity.get('st_dev')),decimal64(identity.get('st_ino'))), 'Qualified font identity changed')


def start_native(owner: Owner, phase: str) -> tuple[Path,Path]:
    config = owner.root/'native'/('project-'+phase+'.json')
    with config.open('xb') as stream:stream.write(owner.inputs.project.path.read_bytes())
    run = start_run(config,run_id='mechanics-'+phase+'-a01',
                    run_directory=owner.root/'native/runs'/('mechanics-'+phase+'-a01'))
    return config,run


def validate_native(owner: Owner, config: Path, run: Path) -> None:
    for label,path in [('config',config),('run',run)]:
        spec = CommandSpec.create([sys.executable,'-X','utf8','-B','-m','xar_promo','validate',str(path),
            '--profile','authoring','--json'],label='Standard authoring '+label)
        result = owner.command(spec,audit_directory=owner.root/'audit'/owner.phase/('validate-'+label))
        need(result.succeeded,'Standard native authoring CLI failed')


def segments(owner: Owner, production: Production, input_pin: Pin) -> None:
    config,run = start_native(owner,owner.phase)
    preserve_artifact(run,input_pin.path,artifact_id='mechanics.render.inputs',collection='derived',
        role='production-input',label='Explicit cue subset with measured voice and accepted raw',media_type='application/json')
    cards = card_paths(production)
    font = Path(text(obj(owner.inputs.renderer_inputs.load().get('font_regular')).get('path')))
    entries: list[dict[str,object]] = []
    frames_sum,cas_sum = 0,0
    cas_max = LATE_CAS_MAX if owner.phase == 'n05' else SEGMENT_CAS_MAX
    for index,(cue,voice,visual) in enumerate(zip(production.editorial.cues,production.products.voices,production.visuals)):
        if cue.cue_id not in stage_ids(owner.phase):
            continue
        owner.guard()
        need(total(owner.root)+2*owner.work_max < owner.limit,'Next cue work/CAS peak does not fit')
        raw = production.raw_windows[visual.raw_key] if visual.raw_key is not None else None
        ass = owner.root/'subtitles'/(cue.cue_id+'.ass')
        plan,timing = cue_plan(cue,visual,voice,raw,cards[visual.card_id],owner.inputs.music.pin.path,ass,
            work=owner.root/'work/segments',ffmpeg=owner.inputs.ffmpeg.pin.path,font_path=font)
        owner.save('cue-intents/'+cue.cue_id+'.json',{'cue_id':cue.cue_id,'frames':timing.frames,
            'raw_frames':timing.raw_frames,'card_frames':timing.card_frames,'voice_seconds':str(voice.seconds),
            'voice':voice.native.wire(),'visual_kind':visual.kind,'card_id':visual.card_id,'raw_key':visual.raw_key,
            'subtitle_timing':'approximate readable phrases from measured cue duration; not ASR/word marks',
            'last_caption_may_remain_for_reading':True,'no_automatic_retry':True})
        execute_render_plan(plan,command_runner=owner.command)
        progress_path = plan.commands[0].audit_directory/'stdout.txt'
        progress = progress_path.read_text('utf8')
        observed = re.findall(r'^frame=([0-9]+)\s*$',progress,re.MULTILINE)
        need(bool(observed) and int(observed[-1]) == timing.frames and
             re.search(r'^progress=end\s*$',progress,re.MULTILINE) is not None,
             'Actual encoder did not report the complete expected frame count; retain work')
        work = plan.final_output
        work_pin = Pin.actual(work)
        need(work_pin.size <= owner.work_max and cas_sum+work_pin.size <= cas_max,
             'Actual segment/CAS hard cap exceeded; closed work retained')
        record = preserve_artifact(run,work,artifact_id='mechanics.segment.'+cue.cue_id,collection='derived',
            role='rendered-segment',label=cue.cue_id+' actual new narration and visual',media_type='video/mp4')
        native = artifact_path(record,run.parent);native.chmod(stat.S_IREAD)
        native_pin = Pin.actual(native)
        need(native_pin.size == work_pin.size and native_pin.sha == work_pin.sha,'Public segment preserve differs')
        asset = Asset.actual(native_pin)
        entries.append({'cue_id':cue.cue_id,'chapter_id':cue.chapter,'frames':timing.frames,
            'project_order_index':index,'cue_fields_sha256':cue_fingerprint(production,owner.inputs,index),
            'review_cas':asset.wire(),'voice':voice.native.wire(),
            'subtitle':Pin.actual(ass).wire(),'raw_key':visual.raw_key,'raw_frames':timing.raw_frames,
            'card_frames':timing.card_frames,'actual_encoder_progress':Pin.actual(progress_path).wire(),
            'source_formal_credit_increased':False})
        frames_sum += timing.frames;cas_sum += native_pin.size
        retire_own_work(owner,work,native_pin,cue.cue_id)
    products = owner.save('SEGMENTS-CLOSED.actual.json',{'schema':'xar.e04.mechanics.segment-products.v1',
        'project':owner.inputs.project.wire(),'inputs':input_pin.wire(),'frame_rate':30,'phase':owner.phase,
        'expected_project_cues':47,'actual_cue_count':len(entries),'complete_project':False,
        'deferred_cues':[c for c in EXPECTED_CUES if c not in stage_ids(owner.phase)],
        'encoded_frames_sum':frames_sum,'entries':entries,'retained_segment_CAS_bytes':cas_sum,
        'complete_original_raw_windows':sum(v.kind == 'raw' for v in production.visuals if v.cue_id in stage_ids(owner.phase)),
        'no_chapter_movie_duplicates':True,
        'remaining_owned_Popen':owner.children,'subtitle_timing':'approximate, not ASR; last phrase may remain for reading',
        'human_audio_listen':False,'human1x':False,'whole_movie_QA':'not yet produced'})
    product_rows(products.load(),owner.phase)
    preserve_artifact(run,products.path,artifact_id='mechanics.actual.segment-products',collection='derived',
        role='segment-products',label='Actual partial cue products; complete timeline deferred',media_type='application/json')
    validate_native(owner,config,run)
    owner.save('SEGMENT-OWNER-CLOSED.actual.json',{'products':products.wire(),'native_run':Pin.actual(run).wire(),
        'phase':owner.phase,'actual_cue_count':len(entries),'complete_project':False,
        'all_original_children_wait0_Job0':True,'writer_count':0,'remaining_owned_Popen':owner.children,
        'actual_successful_children':owner.successful_children,'next_phase':'full concat requires separate admission'})


def full(owner: Owner, production: Production, input_pin: Pin, segment_pin: Pin, late_pin: Pin) -> None:
    joined: dict[str,dict[str,object]] = {}
    for phase,pin,key in [('segments',segment_pin,'segment_owner_closed'),('n05',late_pin,'n05_owner_closed')]:
        source_owner = Pin.parse(owner.card.get(key)).load()
        need(source_owner.get('machine_id') == MACHINE and
             source_owner.get('all_original_children_wait0_Job0') is True and
             integer(source_owner.get('writer_count')) == 0 and
             integer(source_owner.get('remaining_owned_Popen')) == 0 and
             Pin.parse(source_owner.get('products')) == pin, 'Actual cue stage owner not closed')
        data = pin.load()
        previous = Editorial.parse(Pin.parse(data.get('project')).load())
        project_successor(previous,production.editorial)
        stage: Phase = 'segments' if phase == 'segments' else 'n05'
        for row in product_rows(data,stage):
            key_id = text(row.get('cue_id'))
            need(key_id not in joined,'Duplicate cue products across stages')
            joined[key_id] = row
    need(set(joined) == set(EXPECTED_CUES),'All47 final adopted actual cues are required')
    entries: list[dict[str,object]] = []
    assets: list[Asset] = []
    cursor = 0
    for index,(cue,voice,visual) in enumerate(zip(production.editorial.cues,production.products.voices,production.visuals)):
        row = joined[cue.cue_id]
        raw = production.raw_windows[visual.raw_key] if visual.raw_key is not None else None
        timing = clock(voice,raw)
        need(integer(row.get('project_order_index')) == index and row.get('chapter_id') == cue.chapter and
             row.get('cue_fields_sha256') == cue_fingerprint(production,owner.inputs,index) and
             Pin.parse(row.get('voice')) == voice.native and integer(row.get('frames'),1) == timing.frames,
             'Final cue fields/actual voice/frame product is stale')
        Pin.parse(row.get('actual_encoder_progress')).verify()
        entries.append({**row,'timeline_start_frame':cursor})
        cursor += timing.frames
        asset = Asset.parse(row.get('review_cas'));asset.verify_identity();assets.append(asset)
    timeline = owner.save('FULL-TIMELINE.actual.json',{'schema':'xar.e04.mechanics.timeline.v1',
        'project':owner.inputs.project.wire(),'frame_rate':30,'cue_count':47,'total_frames':cursor,
        'base46_products':segment_pin.wire(),'n05_products':late_pin.wire(),'entries':entries})
    need(total(owner.root)+2*FULL_MOVIE_MAX < FULL_LIMIT,'RetainedS+2F/control peak does not fit')
    config,run = start_native(owner,'full')
    preserve_artifact(run,timeline.path,artifact_id='mechanics.full.timeline',collection='derived',
        role='timeline',label='Actual47cue complete clock',media_type='application/json')
    plan = plan_concat(ffmpeg=owner.inputs.ffmpeg.pin.path,segment_paths=[a.pin.path for a in assets],
        concat_path=owner.root/'work/full/concat.txt',partial_output=owner.root/'work/full/E04-MECHANICS-REVIEW.partial.mp4',
        final_output=owner.root/'work/full/E04-MECHANICS-REVIEW.mp4',audit_directory=owner.root/'audit/full/concat',
        working_directory=owner.root/'work/full')
    execute_render_plan(plan,command_runner=owner.command)
    movie = Pin.actual(plan.final_output)
    need(movie.size <= FULL_MOVIE_MAX,'Actual full movie exceeds144MiB; preserve partial/current output')
    record = preserve_artifact(run,movie.path,artifact_id='mechanics.full.review',collection='derived',
        role='deliverable',label='Episode04 mechanics working review',media_type='video/mp4')
    native = Pin.actual(artifact_path(record,run.parent));need(native.sha == movie.sha and native.size == movie.size,
        'Full native preserve differs')
    native.path.chmod(stat.S_IREAD)
    validate_native(owner,config,run)
    owner.save('FULL-OWNER-CLOSED.actual.json',{'inputs':input_pin.wire(),'timeline':timeline.wire(),
        'work_movie':movie.wire(),'native_CAS_movie':native.wire(),'actual_expected_video_frames':cursor,
        'native_run':Pin.actual(run).wire(),'writer_count':0,'remaining_owned_Popen':owner.children,
        'all_original_children_wait0_Job0':True,'actual_successful_children':owner.successful_children,
        'whole_movie_AV_PTS_QA':'pending separate admitted unique decode','human1x':False,'signoff':False})


def production_ids() -> tuple[str,...]:
    from mechanics_contract import EXPECTED_CUES
    return EXPECTED_CUES


def main() -> None:
    SERIES_PALETTE.verify()
    parser = argparse.ArgumentParser()
    parser.add_argument('--root',required=True,type=Path)
    parser.add_argument('--inputs',required=True,type=Path)
    parser.add_argument('--inputs-sha',required=True)
    parser.add_argument('--capacity',type=Path)
    parser.add_argument('--capacity-sha')
    parser.add_argument('--phase',choices=['segments','n05','full'],default='segments')
    parser.add_argument('--segments-manifest',type=Path)
    parser.add_argument('--segments-sha')
    parser.add_argument('--n05-manifest',type=Path)
    parser.add_argument('--n05-sha')
    parser.add_argument('--execute',action='store_true')
    args = parser.parse_args()
    input_pin = Pin.actual(args.inputs);need(input_pin.sha == args.inputs_sha,'Inputs changed')
    inputs = Inputs.parse(input_pin.load());production = inputs.materialize()
    if not args.execute:
        frames = sum(clock(v,production.raw_windows[x.raw_key] if x.raw_key else None).frames
                     for v,x in zip(production.products.voices,production.visuals) if v.cue_id in stage_ids(args.phase))
        print(json.dumps({'machine_id':MACHINE,'source_only':True,'actual_voice_rows':47,
            'selected_cues':len(stage_ids(args.phase)),'deferred_cues':[c for c in EXPECTED_CUES if c not in stage_ids(args.phase)],
            'planned_selected_frames_from_actual_voices':frames,'complete_project':False,'media_execution':False}));return
    need(args.capacity is not None and args.capacity_sha is not None,'Actual execution card required')
    capacity_pin = Pin.actual(args.capacity);need(capacity_pin.sha == args.capacity_sha,'Capacity pin changed')
    card = capacity_pin.load();root = args.root.resolve()
    phase: Phase = 'segments' if args.phase == 'segments' else 'n05' if args.phase == 'n05' else 'full'
    limit = phase_limit(phase)
    need(card.get('machine_id') == MACHINE and card.get('budget_status') == 'GREEN'
         and card.get('source_bound_media_execution_admitted') is True
         and card.get('full_future_held_until_closed') is True and Path(text(card.get('aggregate_root'))).resolve() == root
         and integer(card.get('aggregate_ceiling_bytes')) == limit and card.get('phase') == phase,
         'Wrong source-only/root/phase/finite financial admission')
    need(Pin.parse(card.get('inputs')) == input_pin and
         Pin.parse(card.get('producer')) == Pin.actual(Path(__file__)) and
         Pin.parse(card.get('contract')) == Pin.actual(Path(__file__).with_name('mechanics_contract.py')) and
         Pin.parse(card.get('composer')) == Pin.actual(Path(__file__).with_name('mechanics_composer.py')),
         'Source-bound input/producer/contract/composer differs')
    need(card.get('segment_render_execution_admitted') is (phase != 'full') and
         card.get('full_concat_execution_admitted') is (phase == 'full'),'Phase execution differs')
    need(tuple(text(v) for v in array(card.get('selected_cue_ids'))) == stage_ids(phase), 'Wrong explicitly admitted cue subset')
    if phase != 'full':
        need(card.get('exact_own_work_retirement_admitted') is True,'No exact duplicate-work retirement authority')
    if phase != 'segments':
        need(inputs.product_overrides is not None,'Final N05-01 actual onevoice/oneimage override required')
    need(production.yellow is not None,'Yellow35 actual products/closed owner required before any media execution')
    verify_inputs(inputs,production)
    for name in ['temp','native','cards','subtitles','work/segments','work/full','audit']:
        (root/name).mkdir(parents=True,exist_ok=True)
    once = 'ONCE-'+phase.upper()+'.actual.json'
    owner = Owner(root,inputs,card,phase);owner.guard()
    owner.save(once,{'inputs':input_pin.wire(),'capacity':capacity_pin.wire(),'phase':phase,'no_retry':True})
    owner.idle()
    if phase != 'full':
        segments(owner,production,input_pin)
    else:
        need(args.segments_manifest is not None and args.segments_sha is not None and
             args.n05_manifest is not None and args.n05_sha is not None,'Actual closed46+1 cue manifests required')
        segment_pin = Pin.actual(args.segments_manifest);need(segment_pin.sha == args.segments_sha,'Cue manifest changed')
        late_pin = Pin.actual(args.n05_manifest);need(late_pin.sha == args.n05_sha,'N05 manifest changed')
        full(owner,production,input_pin,segment_pin,late_pin)


if __name__ == '__main__':
    main()
