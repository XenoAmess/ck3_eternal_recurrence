"""One typed boundary for the 47-cue mechanics successor; no media execution."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING
import hashlib
import json
from pathlib import Path
import re
from typing import Literal

MACHINE = 'desktop-3fevhd2-1c74096080'
MIB = 1048576
SEGMENT_LIMIT = 256 * MIB
FULL_LIMIT = 512 * MIB
SEGMENT_CAS_MAX = 144 * MIB
ACTIVE_WORK_MAX = 12 * MIB
FULL_MOVIE_MAX = 144 * MIB
LATE_LIMIT = 8 * MIB
LATE_WORK_MAX = 3 * MIB
LATE_CAS_MAX = 3 * MIB
Phase = Literal['segments', 'n05', 'full']
EXPECTED_CUES = (
    'N01-01','N01-02','N01-03','N01-11','N01-04','N01-05','N01-06','N01-10','N01-07','N01-08','N01-09',
    'N02-01','N02-02','N02-06','N02-04','N02-03','N02-05',
    'N03-01','N03-02','N03-03','N03-04','N03-05','N03-06','N03-07',
    'N04-01','N04-02','N04-03','N04-04','N04-05','N04-06',
    'N05-01','N05-02','N05-03','N05-04','N05-05','N05-06','N05-07','N05-09','N05-08',
    'N06-01','N06-02','N06-03','N06-04','N06-08','N06-05','N06-07','N06-06')
CARD_IDS = frozenset('F' + str(i).zfill(2) for i in range(1,19))


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def obj(value: object) -> dict[str, object]:
    if not isinstance(value, dict):
        raise ValueError('Expected JSON object')
    result: dict[str, object] = {}
    for key, item in value.items():
        if not isinstance(key, str):
            raise ValueError('Expected string field name')
        result[key] = item
    return result


def array(value: object) -> list[object]:
    if not isinstance(value, list):
        raise ValueError('Expected JSON array')
    return list(value)


def text(value: object) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError('Expected nonempty string')
    return value


def integer(value: object, minimum: int = 0) -> int:
    if type(value) is not int or value < minimum:
        raise ValueError('Expected exact integer, excluding bool/float')
    return value


def boolean(value: object) -> bool:
    if type(value) is not bool:
        raise ValueError('Expected exact bool')
    return value


def decimal64(value: object) -> str:
    result = text(value)
    need(re.fullmatch(r'0|[1-9][0-9]*', result) is not None and int(result) < 2**64,
         'Expected canonical unsigned64 decimal string')
    return result


def duration(value: object) -> Decimal:
    result = text(value)
    need(re.fullmatch(r'(0|[1-9][0-9]*)(\.[0-9]+)?', result) is not None,
         'Expected measured decimal seconds string')
    seconds = Decimal(result)
    need(seconds.is_finite() and seconds > 0, 'Nonpositive actual voice duration')
    return seconds


def frames_for(seconds: Decimal) -> int:
    return int((seconds * 30).to_integral_value(rounding=ROUND_CEILING))


def read(path: Path) -> dict[str, object]:
    return obj(json.loads(path.read_bytes()))


@dataclass(frozen=True)
class Pin:
    path: Path
    size: int
    sha: str

    @classmethod
    def parse(cls, value: object) -> Pin:
        row = obj(value)
        sha = text(row.get('sha256'))
        need(re.fullmatch('[0-9a-f]{64}', sha) is not None, 'Invalid SHA256')
        return cls(Path(text(row.get('path'))), integer(row.get('bytes'), 1), sha)

    @classmethod
    def actual(cls, path: Path) -> Pin:
        with path.open('rb') as stream:
            sha = hashlib.file_digest(stream, 'sha256').hexdigest()
        return cls(path, path.stat().st_size, sha)

    def wire(self) -> dict[str, object]:
        return {'path': str(self.path), 'bytes': self.size, 'sha256': self.sha}

    def verify(self) -> None:
        need(self.path.is_file() and not self.path.is_symlink() and Pin.actual(self.path) == self,
             'Actual file pin changed: ' + str(self.path))

    def load(self) -> dict[str, object]:
        raw = self.path.read_bytes()
        need(len(raw) == self.size and hashlib.sha256(raw).hexdigest() == self.sha,
             'JSON source pin changed')
        return obj(json.loads(raw))


@dataclass(frozen=True)
class Asset:
    pin: Pin
    mtime: str
    device: str
    inode: str

    @classmethod
    def parse(cls, value: object) -> Asset:
        row = obj(value)
        identity = obj(row.get('identity'))
        return cls(Pin.parse({'path': row.get('path'), 'bytes': row.get('bytes'),
                              'sha256': row.get('retained_sha256')}),
                   decimal64(identity.get('mtime_ns')), decimal64(identity.get('st_dev')),
                   decimal64(identity.get('st_ino')))

    @classmethod
    def actual(cls, pin: Pin) -> Asset:
        stat = pin.path.stat()
        need(stat.st_size == pin.size, 'Closed product size changed')
        return cls(pin, str(stat.st_mtime_ns), str(stat.st_dev), str(stat.st_ino))

    def verify_identity(self) -> None:
        stat = self.pin.path.stat()
        need(self.pin.path.is_file() and not self.pin.path.is_symlink() and
             (stat.st_size, str(stat.st_mtime_ns), str(stat.st_dev), str(stat.st_ino)) ==
             (self.pin.size, self.mtime, self.device, self.inode), 'Retained media identity changed')

    def wire(self) -> dict[str, object]:
        return {'path': str(self.pin.path), 'bytes': self.pin.size, 'retained_sha256': self.pin.sha,
                'identity': {'mtime_ns': self.mtime, 'st_dev': self.device, 'st_ino': self.inode}}


@dataclass(frozen=True)
class Cue:
    cue_id: str
    chapter: str
    zh: str
    en: str
    narration: str


@dataclass(frozen=True)
class Editorial:
    cues: tuple[Cue, ...]

    @classmethod
    def parse(cls, value: object) -> Editorial:
        row = obj(value)
        need(integer(row.get('format_version')) == 1 and row.get('kind') == 'xar_promo_project_config',
             'Wrong actual project contract')
        cues: list[Cue] = []
        chapters = array(row.get('chapters'))
        need(len(chapters) == 6, 'Six actual editorial chapters required')
        for value in chapters:
            chapter = obj(value)
            key = text(chapter.get('id'))
            for item in array(chapter.get('cues')):
                cue = obj(item)
                subtitles = obj(cue.get('subtitles'))
                cues.append(Cue(text(cue.get('id')), key, text(subtitles.get('zh-CN')),
                                text(subtitles.get('en')), text(obj(cue.get('narration')).get('zh-CN'))))
        need(tuple(c.cue_id for c in cues) == EXPECTED_CUES, '47-cue order differs')
        return cls(tuple(cues))


def project_successor(previous: Editorial, current: Editorial) -> None:
    need(len(previous.cues) == len(current.cues) == 47, 'Incomplete project successor')
    for old,new in zip(previous.cues,current.cues):
        need((old == new) if old.cue_id != 'N05-01' else
             (old.cue_id,old.chapter) == (new.cue_id,new.chapter),
             'Project successor changed another cue or map identity')


@dataclass(frozen=True)
class Voice:
    cue_id: str
    chapter: str
    text_sha: str
    seconds: Decimal
    minimum_frames: int
    original: Pin
    native: Pin
    cache_hit: bool

    @classmethod
    def parse(cls, value: object) -> Voice:
        row = obj(value)
        seconds = duration(row.get('actual_seconds'))
        minimum = integer(row.get('minimum_voice_frames_30fps'), 1)
        need(minimum == frames_for(seconds) and integer(row.get('provider_calls')) == 1
             and row.get('atempo_or_trim') is False, 'Actual voice production contract differs')
        sha = text(row.get('text_sha256'))
        need(re.fullmatch('[0-9a-f]{64}', sha) is not None, 'Invalid actual voice text SHA')
        return cls(text(row.get('cue_id')), text(row.get('chapter_id')), sha, seconds, minimum,
                   Pin.parse(row.get('original_MP3')), Pin.parse(row.get('native_CAS')),
                   boolean(row.get('cache_hit')))


@dataclass(frozen=True)
class Formula:
    card_id: str
    svg: Pin
    png: Pin
    native: Pin

    @classmethod
    def parse(cls, value: object) -> Formula:
        row = obj(value)
        need(row.get('old_review_banner') is False, 'Old review banner not allowed')
        return cls(text(row.get('id')), Pin.parse(row.get('source_SVG')),
                   Pin.parse(row.get('original_PNG')), Pin.parse(row.get('native_CAS')))


SERIES_PALETTE = Pin(Path('D:/workspace/ck3_eternal_recurrence/promo/ck3_native_war_ai/integration/src/war_ai_promo/series_palette.py'),
    583,'df63962c4ce3260e4b864a46b652631fb99cd17a306515ad5078af9bc57b465b')


@dataclass(frozen=True)
class YellowAssets:
    formulas: tuple[Formula,...]
    identities: tuple[Asset,...]

    @classmethod
    def parse(cls, value: object, base: Pin) -> YellowAssets:
        row = obj(value)
        need(row.get('schema') == 'xar.e04.mechanics.yellow-assets.v1' and row.get('machine_id') == MACHINE and
             Pin.parse(row.get('palette_source')) == SERIES_PALETTE and Pin.parse(row.get('base_assets')) == base,
             'Yellow assets/palette/base input differ')
        images: list[Formula] = []
        identities: list[Asset] = []
        for item in array(row.get('actual_images')):
            raw = obj(item);image = Formula.parse(raw)
            need((image.png.size,image.png.sha) == (image.native.size,image.native.sha), 'Yellow PNG/CAS differ')
            identity = obj(raw.get('native_identity'))
            images.append(image)
            identities.append(Asset(image.native,decimal64(identity.get('mtime_ns')),
                decimal64(identity.get('st_dev')),decimal64(identity.get('st_ino'))))
        need(len(images) == 35 and {i.card_id for i in images} ==
             CARD_IDS | {'K'+str(i).zfill(2) for i in range(1,18)}, 'Exactly35 unique yellow F/K images required')
        return cls(tuple(images),tuple(identities))


@dataclass(frozen=True)
class Products:
    voices: tuple[Voice, ...]
    formulas: tuple[Formula, ...]
    knowledge_override: Formula | None

    @classmethod
    def parse(cls, value: object, editorial: Editorial, override: object | None = None) -> Products:
        row = obj(value)
        need(row.get('machine_id') == MACHINE, 'Actual assets machine differs')
        voices = tuple(Voice.parse(v) for v in array(row.get('actual_voice_cues')))
        formulas = tuple(Formula.parse(v) for v in array(row.get('actual_formula_images')))
        image: Formula | None = None
        if override is not None:
            replacement = obj(override)
            need(replacement.get('machine_id') == MACHINE and
                 Pin.parse(replacement.get('palette_source')) == SERIES_PALETTE, 'Override machine/yellow palette differs')
            voice = Voice.parse(replacement.get('voice_override'))
            image = Formula.parse(replacement.get('knowledge_image_override'))
            need(voice.cue_id == 'N05-01' and image.card_id == 'K17', 'Only N05-01/K17 late override admitted')
            closed = Pin.parse(replacement.get('owner_closed')).load()
            need(closed.get('machine_id') == MACHINE and
                 integer(closed.get('owned_Popen_remaining')) == 0 and
                 integer(closed.get('author_writers_remaining')) == 0 and
                 closed.get('all_original_current_children_wait0') is True,
                 'Onevoice/onePNG producer is not actually closed')
            voices = tuple(voice if v.cue_id == 'N05-01' else v for v in voices)
        need(tuple(v.cue_id for v in voices) == EXPECTED_CUES, 'Actual47 voices incomplete/order changed')
        need(len(formulas) == 18 and {f.card_id for f in formulas} == CARD_IDS, 'Actual18 PNG set differs')
        for cue, voice in zip(editorial.cues, voices):
            need(cue.chapter == voice.chapter and
                 hashlib.sha256(cue.narration.encode('utf8')).hexdigest() == voice.text_sha,
                 'Voice belongs to another frozen text/chapter')
            need(voice.original.size == voice.native.size and voice.original.sha == voice.native.sha,
                 'Original MP3/nativeCAS differ')
        for formula in formulas:
            need(formula.png.size == formula.native.size and formula.png.sha == formula.native.sha,
                 'Original PNG/nativeCAS differ')
        if image is not None:
            need(image.png.size == image.native.size and image.png.sha == image.native.sha,
                 'Override PNG/nativeCAS differ')
        return cls(voices, formulas, image)


@dataclass(frozen=True)
class GitProof:
    repository: Path
    commit: str
    relative: str
    size: int
    sha: str


@dataclass(frozen=True)
class SourceProof:
    file: Pin | None
    git: GitProof | None

    @classmethod
    def parse(cls, value: object) -> SourceProof:
        row = obj(value)
        if row.get('kind') != 'git-blob':
            return cls(Pin.parse(row), None)
        commit, sha = text(row.get('commit')), text(row.get('sha256'))
        need(re.fullmatch('[0-9a-f]{40}', commit) is not None and
             re.fullmatch('[0-9a-f]{64}', sha) is not None, 'Invalid retained Git provenance')
        return cls(None, GitProof(Path(text(row.get('repository'))), commit,
                                  text(row.get('repo_relative')), integer(row.get('bytes'), 1), sha))


@dataclass(frozen=True)
class RawWindow:
    key: str
    source: Asset
    first: int
    end: int
    scope: SourceProof

    @classmethod
    def parse(cls, value: object) -> RawWindow:
        row = obj(value)
        first, end = integer(row.get('start_frame')), integer(row.get('end_frame'), 1)
        need(end > first and integer(row.get('fps')) == 30 and row.get('playback_speed') == '1',
             'Continuous original30fps raw window required')
        need(row.get('looping') is False and row.get('interpolation') is False and
             row.get('freeze_tail') is False, 'Raw interpolation/freeze/loop prohibited')
        return cls(text(row.get('key')), Asset.parse(row.get('source')), first, end,
                   SourceProof.parse(row.get('source_scope')))

    @property
    def frames(self) -> int:
        return self.end - self.first


@dataclass(frozen=True)
class Visual:
    cue_id: str
    kind: Literal['card', 'raw']
    card_id: str
    raw_key: str | None

    @classmethod
    def parse(cls, value: object) -> Visual:
        row = obj(value)
        kind = text(row.get('kind'))
        need('raw_key' in row, 'Missing differs from explicit null raw_key')
        raw = None if row['raw_key'] is None else text(row['raw_key'])
        card = text(row.get('card_id'))
        need(card in CARD_IDS or re.fullmatch('K[0-9]{2}', card) is not None, 'Unknown formula/knowledge card')
        if kind == 'card':
            need(raw is None, 'Card cannot silently use raw')
            return cls(text(row.get('cue_id')), 'card', card, None)
        need(kind == 'raw' and raw is not None, 'Raw key required')
        return cls(text(row.get('cue_id')), 'raw', card, raw)


@dataclass(frozen=True)
class KnowledgeCard:
    card_id: str
    title: str
    hero: str
    rows: tuple[str, ...]
    note: str

    @classmethod
    def parse(cls, value: object) -> KnowledgeCard:
        row = obj(value)
        key = text(row.get('id'))
        need(re.fullmatch('K[0-9]{2}', key) is not None, 'Unknown knowledge card ID')
        lines = tuple(text(v) for v in array(row.get('rows')))
        need(1 <= len(lines) <= 5, 'Knowledge card must be concise')
        return cls(key, text(row.get('title')), text(row.get('hero')), lines, text(row.get('note')))


@dataclass(frozen=True)
class Production:
    editorial: Editorial
    products: Products
    visuals: tuple[Visual, ...]
    raw_windows: dict[str, RawWindow]
    knowledge: tuple[KnowledgeCard, ...]
    yellow: YellowAssets | None = None


@dataclass(frozen=True)
class Inputs:
    project: Pin
    products: Pin
    source_plan: Pin
    visual_plan: Pin
    producer_closure: Pin
    toolchain: Pin
    ffmpeg: Asset
    ffprobe: Asset
    job_helper: Pin
    music: Asset
    renderer_inputs: Pin
    formula_override: Pin
    permanent_registry: Pin
    product_overrides: Pin | None
    retained_products: Pin
    product_override_identities: tuple[Asset, ...]
    yellow_assets: Pin | None
    yellow_owner: Pin | None

    @classmethod
    def parse(cls, value: object) -> Inputs:
        row = obj(value)
        need(row.get('schema') == 'xar.e04.mechanics.render-inputs.v1' and row.get('machine_id') == MACHINE,
             'Wrong render input schema/machine')
        need(all(k in row for k in ('product_overrides','yellow_assets','yellow_owner')),
             'Missing differs from explicit null product/yellow pins')
        return cls(project=Pin.parse(row.get('project')),products=Pin.parse(row.get('products')),
                   source_plan=Pin.parse(row.get('source_plan')),visual_plan=Pin.parse(row.get('visual_plan')),
                   producer_closure=Pin.parse(row.get('producer_closure')),toolchain=Pin.parse(row.get('toolchain')),
                   ffmpeg=Asset.parse(row.get('ffmpeg')),ffprobe=Asset.parse(row.get('ffprobe')),
                   job_helper=Pin.parse(row.get('job_helper')),music=Asset.parse(row.get('music')),
                   renderer_inputs=Pin.parse(row.get('renderer_inputs')),
                   formula_override=Pin.parse(row.get('formula_override')),
                   permanent_registry=Pin.parse(row.get('permanent_registry')),
                   product_overrides=None if row['product_overrides'] is None else Pin.parse(row['product_overrides']),
                   retained_products=Pin.parse(row.get('retained_products')),
                    product_override_identities=tuple(Asset.parse(v) for v in array(row.get('product_override_identities'))),
                    yellow_assets=None if row['yellow_assets'] is None else Pin.parse(row['yellow_assets']),
                    yellow_owner=None if row['yellow_owner'] is None else Pin.parse(row['yellow_owner']))

    def materialize(self) -> Production:
        editorial = Editorial.parse(self.project.load())
        replacement = self.product_overrides.load() if self.product_overrides is not None else None
        if replacement is not None:
            need(Pin.parse(replacement.get('current_project')) == self.project,
                 'Actual one-cue override/current project differ')
        products = Products.parse(self.products.load(), editorial, replacement)
        if replacement is None:
            need(not self.product_override_identities, 'Identity override without an actual product override')
        else:
            need(products.knowledge_override is not None, 'Actual K17 product missing')
            if products.knowledge_override is None:
                raise ValueError('Actual K17 missing')
            voice = next(v for v in products.voices if v.cue_id == 'N05-01')
            need({a.pin for a in self.product_override_identities} ==
                 {voice.native,products.knowledge_override.native}, 'Actual onecue retained identities differ')
        plan = self.visual_plan.load()
        if plan.get('schema') == 'xar.e04.mechanics.visual-map-project-delta.v1':
            need(plan.get('machine_id') == MACHINE and plan.get('only_changed_cue') == 'N05-01'
                 and Pin.parse(plan.get('project')) == self.project and replacement is not None,
                 'Only an actual N05-01 project successor may derive a visual map')
            base = Pin.parse(plan.get('base_visual_plan')).load()
            previous = Editorial.parse(Pin.parse(base.get('project')).load())
            project_successor(previous,editorial)
            plan = {**base,'project':self.project.wire()}
        need(plan.get('schema') == 'xar.e04.mechanics.visual-map.v1','Unknown visual map schema')
        need(plan.get('machine_id') == MACHINE and Pin.parse(plan.get('project')) == self.project,
             'Visual map/current project differ')
        visuals = tuple(Visual.parse(v) for v in array(plan.get('cues')))
        need(tuple(v.cue_id for v in visuals) == EXPECTED_CUES, 'Visual47 order differs')
        knowledge = tuple(KnowledgeCard.parse(v) for v in array(plan.get('knowledge_cards')))
        card_keys = [k.card_id for k in knowledge]
        need(len(set(card_keys)) == len(card_keys) and
             {v.card_id for v in visuals} <= CARD_IDS | set(card_keys), 'Missing/duplicate knowledge card')
        raws = tuple(RawWindow.parse(v) for v in array(plan.get('raw_windows')))
        keys = [r.key for r in raws]
        need(len(raws) == 10 and len(set(keys)) == 10 and
             [v.raw_key for v in visuals if v.kind == 'raw'] != [] and
             sorted(v.raw_key for v in visuals if v.raw_key is not None) == sorted(keys),
             'Each of ten accepted raw windows must occur once')
        yellow: YellowAssets | None = None
        need((self.yellow_assets is None) == (self.yellow_owner is None), 'Yellow product/owner must be paired')
        if self.yellow_assets is not None and self.yellow_owner is not None:
            closed = self.yellow_owner.load()
            need(closed.get('machine_id') == MACHINE and integer(closed.get('owned_Popen_remaining')) == 0 and
                 integer(closed.get('author_writers_remaining')) == 0 and
                 closed.get('all_original_current_children_wait0') is True and
                 Pin.parse(closed.get('assets')) == self.yellow_assets, 'Yellow owner/assets not actually closed')
            yellow = YellowAssets.parse(self.yellow_assets.load(),self.products)
        return Production(editorial, products, visuals, {r.key:r for r in raws}, knowledge, yellow)
