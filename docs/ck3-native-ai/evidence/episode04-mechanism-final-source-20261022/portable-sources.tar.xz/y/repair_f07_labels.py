"""One data-only contrast repair; keep the earlier35 originals and index immutable."""
from __future__ import annotations
import argparse
import datetime as dt
import importlib.util
import os
from pathlib import Path
from PIL import Image
from xar_promo.operations import preserve_artifact
from xar_promo.project import artifact_path
from produce_yellow import ROOT, MACHINE, read, checked, obj, seq, pin, save, identity, retained_font, guard, string


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--admission', type=Path, required=True)
    parser.add_argument('--admission-sha', required=True)
    args = parser.parse_args()
    card = read(args.admission)
    if (pin(args.admission)['sha256'] != args.admission_sha or card.get('machine_id') != MACHINE
        or card.get('admitted') is not True or card.get('actual_F07_readability_raster_execution_admitted') is not True
        or Path(string(card['aggregate_root'])) != ROOT or card.get('aggregate_ceiling_bytes') != 16777216
        or card.get('producer_sha256') != pin(Path(__file__))['sha256']):
        raise ValueError('Exact one-F07 admission required')
    source = checked(card['source_SVG'])
    assets_path = checked(card['prior_assets'])
    inputs = read(ROOT / 'INPUTS.source-a01.json')
    renderer = checked(inputs['rasterizer'])
    regular, bold = retained_font(inputs['font_regular']), retained_font(inputs['font_bold'])
    deadline = dt.datetime.fromisoformat(string(card['hard_deadline_utc']).replace('Z', '+00:00'))
    os.environ.update(TMP=str(ROOT / 'temp'), TEMP=str(ROOT / 'temp'), PYTHONDONTWRITEBYTECODE='1')
    guard(deadline, preview=False, reserve=524288)
    save(ROOT / 'ONCE-F07-READABILITY.actual-a02.json', {'machine_id': MACHINE, 'admission': pin(args.admission)})
    spec = importlib.util.spec_from_file_location('retained_f07_rasterizer', renderer)
    if spec is None or spec.loader is None:
        raise ValueError('Retained rasterizer missing')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    raster = getattr(module, 'raster_image', None)
    if not callable(raster):
        raise ValueError('Retained raster_image missing')
    value: object = raster(source.read_bytes(), regular, bold, review_label=False)
    if not isinstance(value, Image.Image) or value.size != (1920, 1080):
        raise ValueError('Original lossless geometry')
    path = ROOT / 'cards/F07.readable-a02.png'
    with path.open('xb') as stream:
        value.save(stream, format='PNG')
    run = ROOT / 'native/runs/yellow35-a01/run-manifest.json'
    record = preserve_artifact(run, path, artifact_id='yellow.F07.readable-a02', collection='derived',
        role='formula-still', label='Series yellow F07 readable barony labels', media_type='image/png')
    native = artifact_path(record, run.parent)
    assets = read(assets_path)
    rows = [obj(row) for row in seq(assets['actual_images'])]
    changed = 0
    for row in rows:
        if row['id'] == 'F07':
            row.update(source_SVG=pin(source), original_PNG=pin(path), native_CAS=pin(native), native_identity=identity(native))
            changed += 1
    if changed != 1 or len(rows) != 35:
        raise ValueError('Exact35/oneF07 replacement')
    assets.update(actual_images=rows, observed_at_utc=dt.datetime.now(dt.UTC).isoformat(),
        readability_overlay={'prior_assets': pin(assets_path), 'changed_id': 'F07',
        'change': 'Only two barony labels on dark child panels use warm INK, all wording and other34 rows unchanged'})
    save(ROOT / 'ASSETS.actual-a02.json', assets)
    guard(deadline, preview=False)
    print('ACTUAL F07 contrast successor;35 final rows', flush=True)


if __name__ == '__main__':
    main()
