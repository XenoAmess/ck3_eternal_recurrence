"""Raster the retained SVG subset once, then preserve originals through public API."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path

from PIL import Image
from xar_promo.operations import preserve_artifact, start_run
from xar_promo.project import artifact_path

MACHINE = "desktop-3fevhd2-1c74096080"
ROOT = Path("C:/ck3-e04-resume-20261020-a01/r22-mechanics-yellow-assets-a01")


def obj(value: object) -> dict[str, object]:
    if not isinstance(value, dict):
        raise ValueError("Expected object")
    result: dict[str, object] = {}
    for key, item in value.items():
        if not isinstance(key, str):
            raise ValueError("Expected string key")
        result[key] = item
    return result


def seq(value: object) -> list[object]:
    if not isinstance(value, list):
        raise ValueError("Expected list")
    return list(value)


def string(value: object) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError("Expected nonempty string")
    return value


def read(path: Path) -> dict[str, object]:
    value: object = json.loads(path.read_text(encoding="utf-8"))
    return obj(value)


def pin(path: Path) -> dict[str, object]:
    body = path.read_bytes()
    return {"path": str(path), "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}


def checked(value: object) -> Path:
    ref = obj(value)
    path = Path(string(ref["path"]))
    if path.stat().st_size > 1048576 or pin(path) != ref:
        raise ValueError("Small source changed: " + str(path))
    return path


def save(path: Path, body: dict[str, object]) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(body, stream, ensure_ascii=False, indent=2)


def identity(path: Path) -> dict[str, str]:
    st = path.stat()
    return {"mtime_ns": str(st.st_mtime_ns), "st_dev": str(st.st_dev), "st_ino": str(st.st_ino)}


def retained_font(value: object) -> Path:
    ref = obj(value)
    path = Path(string(ref["path"]))
    if path.stat().st_size != ref["bytes"] or identity(path) != ref["identity"]:
        raise ValueError("Retained font identity changed")
    return path


def aggregate() -> int:
    return sum(p.stat().st_size for p in ROOT.rglob("*") if p.is_file())


def guard(deadline: dt.datetime, *, preview: bool, reserve: int = 0) -> None:
    total = aggregate()
    png = sum(p.stat().st_size for p in ROOT.rglob("*.png"))
    if dt.datetime.now(dt.UTC) >= deadline:
        raise ValueError("Deadline; preserve actual partial")
    if total + reserve > 16 * 1048576 or png + reserve > 12 * 1048576:
        raise ValueError("Allinclusive PNG/aggregate limit")
    if total - png > 4 * 1048576 or preview and total + reserve > 524288:
        raise ValueError("Source/preview or metadata limit")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--admission", type=Path, required=True)
    parser.add_argument("--admission-sha", required=True)
    parser.add_argument("--phase", choices=("preview", "batch"), required=True)
    args = parser.parse_args()
    inputs = read(args.inputs)
    card = read(args.admission)
    if pin(args.admission)["sha256"] != args.admission_sha or card.get("machine_id") != MACHINE:
        raise ValueError("Admission identity/SHA")
    preview = args.phase == "preview"
    key = "actual_PNG_raster_preview_execution_admitted" if preview else "actual_batch_raster_execution_admitted"
    if card.get(key) is not True or card.get("admitted") is not True:
        raise ValueError("Phase not admitted")
    if Path(string(card["aggregate_root"])) != ROOT or card.get("aggregate_ceiling_bytes") != 16 * 1048576:
        raise ValueError("Admission root/ceiling")
    if card.get("inputs_sha256") != pin(args.inputs)["sha256"] or card.get("producer_sha256") != pin(Path(__file__))["sha256"]:
        raise ValueError("Sourcebinding")
    deadline = dt.datetime.fromisoformat(string(card["hard_deadline_utc"]).replace("Z", "+00:00"))
    if inputs.get("machine_id") != MACHINE:
        raise ValueError("Input machine")
    checked(inputs["palette_source"])
    checked(inputs["base_assets"])
    project = checked(inputs["project"])
    renderer = checked(inputs["rasterizer"])
    regular, bold = retained_font(inputs["font_regular"]), retained_font(inputs["font_bold"])
    rows = [obj(x) for x in seq(inputs["sources"])]
    expected = [f"F{i:02}" for i in range(1, 19)] + [f"K{i:02}" for i in range(1, 18)]
    if [x["id"] for x in rows] != expected:
        raise ValueError("Exact35 IDs")
    sources = {string(x["id"]): checked(x["source_SVG"]) for x in rows}
    (ROOT / "temp").mkdir(exist_ok=True)
    os.environ.update(TMP=str(ROOT / "temp"), TEMP=str(ROOT / "temp"), PYTHONDONTWRITEBYTECODE="1")
    guard(deadline, preview=preview)
    save(ROOT / ("ONCE-" + args.phase + ".actual.json"), {"machine_id": MACHINE,
        "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(), "admission": pin(args.admission), "inputs": pin(args.inputs)})
    spec = importlib.util.spec_from_file_location("retained_yellow_svg_rasterizer", renderer)
    if spec is None or spec.loader is None:
        raise ValueError("Retained rasterizer missing")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    raster = getattr(module, "raster_image", None)
    if not callable(raster):
        raise ValueError("Retained raster_image missing")
    if not preview:
        review = checked(card["Root_preview_adoption"])
        if read(review).get("yellow_F11_preview_accepted") is not True:
            raise ValueError("Root actual sample review pending")
        (ROOT / "native").mkdir()
        config = ROOT / "native/promo-project.json"
        with config.open("xb") as stream:
            stream.write(project.read_bytes())
        run = start_run(config, run_id="yellow35-a01", run_directory=ROOT / "native/runs/yellow35-a01")
    (ROOT / "cards").mkdir(exist_ok=True)
    images: list[dict[str, object]] = []
    for image_id in (["F11"] if preview else expected):
        path = ROOT / "cards" / (image_id + ".png")
        if preview or image_id != "F11":
            guard(deadline, preview=preview, reserve=262144)
            value: object = raster(sources[image_id].read_bytes(), regular, bold, review_label=False)
            if not isinstance(value, Image.Image) or value.size != (1920, 1080):
                raise ValueError("Original lossless1920x1080 required")
            with path.open("xb") as stream:
                value.save(stream, format="PNG")
        elif pin(path) != read(ROOT / "PREVIEW.actual.json")["original_PNG"]:
            raise ValueError("Accepted preview original changed")
        guard(deadline, preview=preview, reserve=path.stat().st_size if not preview else 0)
        row: dict[str, object] = {"id": image_id, "source_SVG": pin(sources[image_id]),
                                  "original_PNG": pin(path), "old_review_banner": False}
        if not preview:
            record = preserve_artifact(run, path, artifact_id="yellow." + image_id,
                collection="derived", role="formula-still", label="Series yellow " + image_id, media_type="image/png")
            native = artifact_path(record, run.parent)
            row.update(native_CAS=pin(native), native_identity=identity(native))
            images.append(row)
        else:
            save(ROOT / "PREVIEW.actual.json", {"machine_id": MACHINE,
                "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(), **row, "palette_source": inputs["palette_source"]})
        print("ACTUAL " + image_id + " " + str(path.stat().st_size), flush=True)
        guard(deadline, preview=preview)
    if not preview:
        save(ROOT / "ASSETS.actual.json", {"schema": "xar.e04.mechanics.yellow-assets.v1",
            "machine_id": MACHINE, "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(),
            "palette_source": inputs["palette_source"], "base_assets": inputs["base_assets"], "actual_images": images})
    save(ROOT / ("PHASE-" + args.phase + "-CLOSED.actual.json"), {"machine_id": MACHINE,
        "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(), "new_PNG_rasters": 1 if preview else 34,
        "FFmpeg_TTS_Game_calls": 0, "aggregate_bytes_before_this_leaf": aggregate()})


if __name__ == "__main__":
    main()
