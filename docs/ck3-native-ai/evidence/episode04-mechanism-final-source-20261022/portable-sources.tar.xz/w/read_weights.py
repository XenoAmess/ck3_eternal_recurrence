"""Finite exact-address static reads; never scan or execute the target image."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import struct
import sys

import capstone

ROOT = Path(__file__).resolve().parent
EXE = Path("C:/ck3-e04-resume-20261015-a01/frozen-game-12004/ck3.exe")
MACHINE = "desktop-3fevhd2-1c74096080"
LEDGER = ROOT / "READ-LEDGER.latest.json"


def need(ok: bool, reason: str) -> None:
    if not ok:
        raise ValueError(reason)


def main() -> None:
    need(len(sys.argv) >= 3, "name plus explicitly located RVA targets required")
    name = sys.argv[1]
    need(name.isascii() and all(c.isalnum() or c == "-" for c in name), "output name")
    compact = sys.argv[2] == "--compact"
    targets = [int(s, 16) for s in sys.argv[3:] if compact] if compact else [int(s, 16) for s in sys.argv[2:]]
    previous = 0
    prior_failure_reservation = 0
    if LEDGER.exists():
        value = json.loads(LEDGER.read_bytes())
        previous = value["cumulative_exe_bytes_read"]
        need(type(previous) is int and 0 <= previous <= 83886080, "prior read ledger")
        prior_failure_reservation = value.get("includes_conservative_failure_reservation_bytes", 0)
        need(type(prior_failure_reservation) is int and prior_failure_reservation >= 0, "prior failed-read reservation")
    read_rows: list[dict[str, int | str]] = []
    spent = 0
    before = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (101040248, 1792052259095683000), "frozen file stat")
    with EXE.open("rb") as stream:
        def read(offset: int, size: int, purpose: str) -> bytes:
            nonlocal spent
            need(0 <= size <= 8192 and previous + spent + size <= 83886080, "EXE read ceiling")
            stream.seek(offset)
            data = stream.read(size)
            need(len(data) == size, "short source read")
            spent += size
            read_rows.append({"offset": offset, "bytes": size, "purpose": purpose})
            LEDGER.write_text(json.dumps({"cumulative_exe_bytes_read": previous + spent, "includes_conservative_failure_reservation_bytes": prior_failure_reservation, "pending_source": name}) + "\n")
            return data

        header = read(0, 4096, "PE header and section table")
        pe = struct.unpack_from("<I", header, 0x3C)[0]
        count = struct.unpack_from("<H", header, pe + 6)[0]
        optional = struct.unpack_from("<H", header, pe + 20)[0]
        sections: list[tuple[str, int, int, int, int]] = []
        for i in range(count):
            row = header[pe + 24 + optional + i * 40:pe + 64 + optional + i * 40]
            n = row[:8].rstrip(b"\0").decode("ascii")
            virtual_size, rva, raw_size, raw = struct.unpack_from("<IIII", row, 8)
            sections.append((n, rva, virtual_size, raw, raw_size))

        def offset(rva: int) -> int:
            for _, start, _, raw, size in sections:
                if start <= rva < start + size:
                    return raw + rva - start
            raise ValueError("RVA has no file-backed bytes")

        anchor = read(offset(0x262BE10), 660, "existing exact4 identity anchor")
        need(hashlib.sha256(anchor).hexdigest() == "b565d2261e9e4549c7f34ff31c97fd14849756a8e68d10e6fb7c23e9109230ef", "identity anchor")
        pdata = next(s for s in sections if s[0] == ".pdata")
        spans = []
        for target in targets:
            low, high = 0, min(pdata[2], pdata[4]) // 12
            found: tuple[int, int, int] | None = None
            while low < high:
                middle = (low + high) // 2
                start, end, unwind = struct.unpack("<III", read(pdata[3] + middle * 12, 12, "exact target runtime-function lookup"))
                if target < start:
                    high = middle
                elif target >= end:
                    low = middle + 1
                else:
                    found = start, end, unwind
                    break
            need(found is not None, "target lacks runtime-function interval")
            if found is None:
                raise ValueError("missing interval")
            start, end, unwind = found
            need(end - start <= 8192, "single callee size ceiling")
            data = read(offset(start), end - start, "direct located function " + hex(target))
            instructions = [[f"{i.address:X}", i.bytes.hex(), i.mnemonic, i.op_str] for i in capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64).disasm(data, start)]
            selected = [row for row in instructions if row[2] in ["call", "sqrtss", "sqrtsd"] or "rip" in row[3] or (row[2] == "mov" and row[3].startswith("qword ptr [") and "rsp" not in row[3] and "rbp" not in row[3])] if compact else instructions
            spans.append({"requested_rva": f"{target:X}", "start_rva": f"{start:X}", "end_rva_exclusive": f"{end:X}", "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "raw_hex": data.hex(), "instructions": selected, "instruction_list_is_selected": compact, "complete_decoded_instruction_count": len(instructions)})
    after = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), "frozen input changed")
    receipt = {"machine_id": MACHINE, "observed_utc": datetime.now(timezone.utc).isoformat(), "prior_exe_sha256": "98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518", "source_path": str(EXE), "identity_anchor_sha256": hashlib.sha256(anchor).hexdigest(), "previous_scope_exe_read_budget_charged_bytes": previous, "new_exe_read_bytes": spent, "cumulative_exe_read_budget_charged_bytes": previous + spent, "includes_conservative_prior_failure_reservation_bytes": prior_failure_reservation, "read_ledger": read_rows, "spans": spans, "Game_SDK_build": False}
    data = (json.dumps(receipt, separators=(",", ":")) + "\n").encode()
    used = sum(p.stat().st_size for p in ROOT.rglob("*") if p.is_file())
    need(used + len(data) + 1024 <= 262144, "author output budget")
    need(sum(p.stat().st_size for p in ROOT.glob("*.source.json")) + len(data) <= 131072, "native source output ceiling")
    with (ROOT / (name + ".source.json")).open("xb") as target_stream:
        target_stream.write(data)
    ledger_data = (json.dumps({"cumulative_exe_bytes_read": previous + spent, "includes_conservative_failure_reservation_bytes": prior_failure_reservation, "latest_source": name + ".source.json"}) + "\n").encode()
    LEDGER.write_bytes(ledger_data)
    print(json.dumps({"file": name + ".source.json", "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "cumulative_exe_bytes_read": previous + spent, "spans": [{k: v for k, v in row.items() if k not in ["instructions", "raw_hex"]} for row in spans]}))


if __name__ == "__main__":
    main()
