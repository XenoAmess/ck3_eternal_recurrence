"""One specific singleton-store locator, proving boundaries from .pdata starts."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import re
import struct

import capstone
from capstone.x86_const import X86_OP_MEM, X86_REG_RIP

from cache_locator import EXE, LEDGER, MACHINE, ROOT, need, put


def main() -> None:
    prior: object = json.loads(LEDGER.read_bytes())
    if not isinstance(prior, dict):
        raise ValueError('ledger object')
    previous = prior.get('cumulative_exe_bytes_read')
    reserve = prior.get('includes_conservative_failure_reservation_bytes')
    if type(previous) is not int or type(reserve) is not int:
        raise ValueError('exact ledger integers')
    spent = 0
    target = 0x5c6a488
    reads: list[dict[str, int | str]] = []
    before = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (101040248, 1792052259095683000), 'frozen stat')
    with EXE.open('rb') as stream:
        def read(offset: int, size: int, why: str) -> bytes:
            nonlocal spent
            need(previous + spent + size <= 268435456, '256MiB cumulative read ceiling')
            stream.seek(offset)
            out = stream.read(size)
            spent += len(out)
            reads.append({'file_offset': offset, 'bytes': len(out), 'purpose': why})
            LEDGER.write_text(json.dumps({'cumulative_exe_bytes_read': previous + spent, 'includes_conservative_failure_reservation_bytes': reserve, 'pending_source': 'map-singleton-writes'}) + '\n')
            need(len(out) == size, 'short image read')
            return out

        header = read(0, 4096, 'PE sections')
        pe = struct.unpack_from('<I', header, 0x3c)[0]
        count = struct.unpack_from('<H', header, pe + 6)[0]
        optional = struct.unpack_from('<H', header, pe + 20)[0]
        sections: list[tuple[str, int, int, int, int]] = []
        for i in range(count):
            row = header[pe + 24 + optional + i * 40:pe + 64 + optional + i * 40]
            vsize, rva, raw_size, raw = struct.unpack_from('<IIII', row, 8)
            sections.append((row[:8].rstrip(b'\0').decode('ascii'), rva, vsize, raw, raw_size))
        anchor_offset = next(raw + 0x262be10 - rva for _, rva, _, raw, size in sections if rva <= 0x262be10 < rva + size)
        need(hashlib.sha256(read(anchor_offset, 660, 'exact4 identity anchor')).hexdigest() == 'b565d2261e9e4549c7f34ff31c97fd14849756a8e68d10e6fb7c23e9109230ef', 'identity')
        text = next(s for s in sections if s[0] == '.text')
        pdata = next(s for s in sections if s[0] == '.pdata')
        need(text[4] <= 71141888, 'single authorized text pass')
        code = read(text[3], text[4], 'specific RIP-relative writes to singleton 5C6A488')
        entries: dict[int, tuple[int, int, int]] = {}

        def interval(site: int) -> tuple[int, int] | None:
            low, high = 0, min(pdata[2], pdata[4]) // 12
            while low < high:
                mid = (low + high) // 2
                if mid not in entries:
                    entries[mid] = struct.unpack('<III', read(pdata[3] + mid * 12, 12, 'specific candidate boundary lookup'))
                a, b, _ = entries[mid]
                if site < a:
                    high = mid
                elif site >= b:
                    low = mid + 1
                else:
                    return a, b
            return None

        # Overlapping ModRM probes do not assume LEA/MOV encoding. Only the
        # requested target displacement is tested. Full decoding then proves
        # the instruction boundary, effective target, and memory WRITE access.
        pattern = re.compile(rb'(?=[\x05\x0d\x15\x1d\x25\x2d\x35\x3d]....)', re.DOTALL)
        possible: set[int] = set()
        for match in pattern.finditer(code):
            pos = match.start()
            base = text[1] + pos + 5 + struct.unpack_from('<i', code, pos + 1)[0]
            if target - base in (0, 1, 2, 4, 8):
                possible.add(text[1] + pos)
        md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
        md.detail = True
        found: dict[int, dict[str, int | str | bool]] = {}
        bodies: dict[int, tuple[int, bytes]] = {}
        unavailable: list[str] = []
        for site in sorted(possible):
            bound = interval(site)
            if bound is None:
                unavailable.append(f'{site:X}')
                continue
            a, b = bound
            body = code[a - text[1]:b - text[1]]
            for ins in md.disasm(body, a):
                if ins.address > site:
                    break
                if not ins.address <= site < ins.address + ins.size:
                    continue
                for operand in ins.operands:
                    if operand.type == X86_OP_MEM and operand.mem.base == X86_REG_RIP and ins.address + ins.size + operand.mem.disp == target and operand.access & capstone.CS_AC_WRITE:
                        found[ins.address] = {'site_rva': f'{ins.address:X}', 'hex': ins.bytes.hex(), 'mnemonic': ins.mnemonic, 'operands': ins.op_str, 'target_rva': f'{target:X}', 'runtime_start_rva': f'{a:X}', 'runtime_end_rva_exclusive': f'{b:X}', 'runtime_bytes': b - a, 'boundary_and_write_access_proved': True}
                        bodies[a] = b, body
        need(len(found) <= 16, 'candidate count')
    after = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), 'source changed')
    stamp = datetime.now(timezone.utc).isoformat()
    record = {'machine_id': MACHINE, 'observed_utc': stamp, 'prior_exe_sha256': '98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518', 'source_path': str(EXE), 'specific_global_rva': f'{target:X}', 'raw_displacement_candidates': len(possible), 'verified_writes': list(found.values()), 'boundary_unavailable': unavailable, 'new_exe_read_bytes': spent, 'cumulative_exe_charge': previous + spent, 'includes_failed_read_reservation_bytes': reserve, 'text_read_bytes': text[4], 'pdata_read_bytes': sum(r['bytes'] for r in reads if r['purpose'] == 'specific candidate boundary lookup'), 'section_saved': False, 'game_sdk_build': False}
    out = (json.dumps(record, separators=(',', ':')) + '\n').encode()
    need(len(out) <= 4096, 'locator output ceiling')
    put('MAP-SINGLETON-WRITES.actual-a01.json', out)
    print(json.dumps({'file': 'MAP-SINGLETON-WRITES.actual-a01.json', 'bytes': len(out), 'sha256': hashlib.sha256(out).hexdigest(), 'writes': list(found.values()), 'cumulative_exe_charge': previous + spent}))
    # At most two true setter bodies, already in this one authorized buffer.
    # More candidates or a long body are left as metadata for explicit choice.
    if 0 < len(bodies) <= 2 and all(b - a <= 8192 for a, (b, _) in bodies.items()):
        spans = []
        md.detail = False
        for a, (b, body) in sorted(bodies.items()):
            instructions = [[f'{i.address:X}', i.bytes.hex(), i.mnemonic, i.op_str] for i in md.disasm(body, a)]
            selected = [i for i in instructions if i[2] in ['call', 'ret'] or 'rip' in i[3] or (i[2] == 'mov' and i[3].startswith('qword ptr [') and 'rsp' not in i[3] and 'rbp' not in i[3])]
            spans.append({'start_rva': f'{a:X}', 'end_rva_exclusive': f'{b:X}', 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest(), 'raw_hex': body.hex(), 'instructions_selected': selected, 'complete_decoded_instruction_count': len(instructions)})
        payload = (json.dumps({'machine_id': MACHINE, 'observed_utc': stamp, 'prior_exe_sha256': record['prior_exe_sha256'], 'source': 'same authorized singleton-store text buffer; no body reread', 'spans': spans}, separators=(',', ':')) + '\n').encode()
        need(sum(p.stat().st_size for p in ROOT.glob('*.source.json')) + len(payload) <= 163840, '160KiB core-source ceiling')
        put('map-singleton-setters-a01.source.json', payload)
        print(json.dumps({'file': 'map-singleton-setters-a01.source.json', 'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest(), 'functions': len(spans)}))


if __name__ == '__main__':
    main()
