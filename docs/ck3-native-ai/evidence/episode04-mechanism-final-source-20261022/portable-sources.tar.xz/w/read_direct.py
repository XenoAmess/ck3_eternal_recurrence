"""At most four explicitly authorized direct bodies; lossless bounded evidence."""
from __future__ import annotations

import base64
from datetime import datetime, timezone
import hashlib
import json
import struct
import sys
import zlib

import capstone

from cache_locator import EXE, LEDGER, MACHINE, ROOT, need, put


def main() -> None:
    need(len(sys.argv) == 2, 'one exact direct target required')
    target = int(sys.argv[1], 16)
    need(len(list(ROOT.glob('direct-phase-a02-*.source.json'))) < 4, 'four-body quota')
    original: object = json.loads(LEDGER.read_bytes())
    if not isinstance(original, dict):
        raise ValueError('ledger object')
    previous = original.get('cumulative_exe_bytes_read')
    reserve = original.get('includes_conservative_failure_reservation_bytes')
    if type(previous) is not int or type(reserve) is not int:
        raise ValueError('ledger integers')
    spent = 0
    before = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (101040248, 1792052259095683000), 'frozen stat')
    with EXE.open('rb') as stream:
        def read(offset: int, size: int) -> bytes:
            nonlocal spent
            need(previous + spent + size <= 268435456, '256MiB total read ceiling')
            stream.seek(offset)
            out = stream.read(size)
            spent += len(out)
            LEDGER.write_text(json.dumps({'cumulative_exe_bytes_read': previous + spent, 'includes_conservative_failure_reservation_bytes': reserve, 'pending_source': f'direct-phase-a02-{target:X}'}) + '\n')
            need(len(out) == size, 'short input')
            return out

        low, high = 0, 2933220 // 12
        found: tuple[int, int, int] | None = None
        found_bytes = b''
        while low < high:
            middle = (low + high) // 2
            row = read(96838656 + middle * 12, 12)
            a, b, u = struct.unpack('<III', row)
            if target < a:
                high = middle
            elif target >= b:
                low = middle + 1
            else:
                found, found_bytes = (a, b, u), row
                break
        if found is None:
            raise ValueError('no runtime interval; no body read')
        a, b, unwind = found
        need(b - a <= 8192, 'single direct body cap')
        data = read(a - 3072, b - a)
    after = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), 'source changed')
    md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
    instructions = [[f'{i.address:X}', i.bytes.hex(), i.mnemonic, i.op_str] for i in md.disasm(data, a)]
    decoded_bytes = sum(len(bytes.fromhex(i[1])) for i in instructions)
    selected = [i for i in instructions if i[2] in ['call', 'jmp', 'ret'] or ('mov' in i[2] and i[3].startswith(('qword ptr [', 'dword ptr [')) and 'rsp' not in i[3] and 'rbp' not in i[3])]
    packed = base64.b64encode(zlib.compress(data, 9)).decode('ascii')
    need(zlib.decompress(base64.b64decode(packed)) == data, 'lossless raw codec')
    record = {'machine_id': MACHINE, 'observed_utc': datetime.now(timezone.utc).isoformat(), 'source_path': str(EXE), 'prior_exe_sha256': '98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518', 'target_rva': f'{target:X}', 'start_rva': f'{a:X}', 'end_rva_exclusive': f'{b:X}', 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'runtime_function_row_hex': found_bytes.hex(), 'unwind_rva': f'{unwind:X}', 'raw_codec': 'base64(zlib(raw)); SHA256 applies to decompressed original bytes', 'raw_zlib_base64': packed, 'selected_instructions': selected, 'linear_instruction_count': len(instructions), 'linear_decoded_bytes': decoded_bytes, 'linear_decode_covers_raw_interval': decoded_bytes == len(data), 'new_exe_bytes_read': spent, 'cumulative_exe_charge': previous + spent, 'game_sdk_build': False}
    output = (json.dumps(record, separators=(',', ':')) + '\n').encode()
    primary = sum(p.stat().st_size for p in ROOT.iterdir() if p.is_file() and p.suffix != '.py')
    if primary + len(output) > 163840:
        record['selected_instructions'] = []
        output = (json.dumps(record, separators=(',', ':')) + '\n').encode()
    need(primary + len(output) <= 163840, '160KiB primary evidence cap')
    put(f'direct-phase-a02-{target:X}.source.json', output)
    print(json.dumps({'bytes': len(output), 'sha256': hashlib.sha256(output).hexdigest(), 'function': {k: v for k, v in record.items() if k not in ['raw_zlib_base64', 'selected_instructions']}}))
    print('\n'.join(' '.join(i) for i in instructions))


if __name__ == '__main__':
    main()
