"""Only the exact game-side CMap RTTI name in its actual .data section."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import struct
import sys

from cache_locator import EXE, LEDGER, MACHINE, need, put


def main() -> None:
    kind = sys.argv[1] if len(sys.argv) == 2 else 'CMap'
    need(kind in ('CMap', 'CTerrainType'), 'exact authorized RTTI name')
    obj: object = json.loads(LEDGER.read_bytes())
    if not isinstance(obj, dict):
        raise ValueError('ledger object')
    previous = obj.get('cumulative_exe_bytes_read')
    reserve = obj.get('includes_conservative_failure_reservation_bytes')
    if type(previous) is not int or type(reserve) is not int:
        raise ValueError('ledger integers')
    spent = 0
    before = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (101040248, 1792052259095683000), 'frozen stat')
    with EXE.open('rb') as stream:
        def read(offset: int, size: int) -> bytes:
            nonlocal spent
            need(previous + spent + size <= 318767104, '304MiB cumulative ceiling')
            stream.seek(offset)
            out = stream.read(size)
            spent += len(out)
            LEDGER.write_text(json.dumps({'cumulative_exe_bytes_read': previous + spent, 'includes_conservative_failure_reservation_bytes': reserve, 'pending_source': 'exact-CMap-type-data-locator'}) + '\n')
            need(len(out) == size, 'short source read')
            return out

        header = read(0, 4096)
        pe = struct.unpack_from('<I', header, 0x3c)[0]
        count = struct.unpack_from('<H', header, pe + 6)[0]
        optional = struct.unpack_from('<H', header, pe + 20)[0]
        section: tuple[int, int, int] | None = None
        for i in range(count):
            row = header[pe + 24 + optional + i * 40:pe + 64 + optional + i * 40]
            if row[:8].rstrip(b'\0') == b'.data':
                _, rva, size, raw = struct.unpack_from('<IIII', row, 8)
                section = rva, raw, size
        if section is None:
            raise ValueError('data section missing')
        rva, raw, size = section
        need(size <= 9 * 1048576, 'single data pass bound')
        data = read(raw, size)
    need((before.st_size, before.st_mtime_ns) == (EXE.stat().st_size, EXE.stat().st_mtime_ns), 'source changed')
    needle = f'.?AV{kind}@@\0'.encode('ascii')
    matches: list[dict[str, int | str | list[str]]] = []
    at = 0
    while True:
        at = data.find(needle, at)
        if at < 0:
            break
        need(at >= 16, 'type descriptor header')
        td = rva + at - 16
        refs: list[str] = []
        start = 0
        while True:
            pos = data.find(struct.pack('<I', td), start)
            if pos < 0:
                break
            refs.append(f'{rva + pos:X}')
            start = pos + 1
        matches.append({'name': f'.?AV{kind}@@', 'name_rva': f'{rva + at:X}', 'type_descriptor_rva': f'{td:X}', 'descriptor_header_and_name_hex': data[at - 16:at + len(needle)].hex(), 'same_data_rva_references': refs[:16], 'same_data_rva_reference_count': len(refs)})
        at += 1
    need(len(matches) <= 4, 'unexpected exact-name multiplicity')
    record = {'machine_id': MACHINE, 'observed_utc': datetime.now(timezone.utc).isoformat(), 'source_path': str(EXE), 'prior_exe_sha256': '98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518', 'data_rva': f'{rva:X}', 'data_file_offset': raw, 'data_bytes_read': size, 'data_sha256': hashlib.sha256(data).hexdigest(), 'exact_name_matches': matches, 'previous_exe_charge': previous, 'new_exe_bytes': spent, 'cumulative_exe_charge': previous + spent, 'section_saved': False, 'game_sdk_build': False}
    out = (json.dumps(record, separators=(',', ':')) + '\n').encode()
    need(len(out) <= 4096, 'small locator output')
    put(f'{kind.upper()}-TYPE-LOCATOR.actual-a01.json', out)
    print(json.dumps({'bytes': len(out), 'sha256': hashlib.sha256(out).hexdigest(), 'matches': matches, 'cumulative_exe_charge': previous + spent}))


if __name__ == '__main__':
    main()
