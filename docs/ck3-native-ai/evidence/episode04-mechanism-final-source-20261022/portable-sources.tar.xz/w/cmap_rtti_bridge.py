"""One exact CMap TypeDescriptor -> COL -> vtable reverse locator."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import struct
import sys

from cache_locator import EXE, LEDGER, MACHINE, ROOT, need, put


def positions(data: bytes, needle: bytes) -> list[int]:
    result: list[int] = []
    start = 0
    while True:
        start = data.find(needle, start)
        if start < 0:
            return result
        result.append(start)
        start += 1


def main() -> None:
    terrain = len(sys.argv) == 2 and sys.argv[1] == 'CTerrainType'
    target_td = 0x55CB8E8 if terrain else 0x59AB410
    kind = 'CTerrainType' if terrain else 'CMap'
    original: object = json.loads(LEDGER.read_bytes())
    if not isinstance(original, dict):
        raise ValueError('ledger object')
    previous = original.get('cumulative_exe_bytes_read')
    reserve = original.get('includes_conservative_failure_reservation_bytes')
    if type(previous) is not int or type(reserve) is not int:
        raise ValueError('ledger integers')
    size, raw, base = (17124224 if terrain else 17124352), 71142912, 71147520
    need(previous + size <= 318767104, '304MiB authorized cumulative ceiling')
    before = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (101040248, 1792052259095683000), 'frozen stat')
    with EXE.open('rb') as stream:
        stream.seek(raw)
        data = stream.read(size)
    LEDGER.write_text(json.dumps({'cumulative_exe_bytes_read': previous + len(data), 'includes_conservative_failure_reservation_bytes': reserve, 'pending_source': 'exact-CMap-RTTI-reverse-bridge'}) + '\n')
    need(len(data) == size, 'short rdata read')
    need((before.st_size, before.st_mtime_ns) == (EXE.stat().st_size, EXE.stat().st_mtime_ns), 'frozen source changed')
    previous_section: object = json.loads((ROOT / 'CACHE-POINTER-TABLE-LOCATOR.actual-a01.json').read_bytes())
    if not isinstance(previous_section, dict):
        raise ValueError('previous section identity object')
    digest = hashlib.sha256(data).hexdigest()
    need(terrain or previous_section.get('rdata_sha256') == digest, 'same complete rdata hash for CMap; Terrain uses explicitly bounded prefix')

    def at(rva: int, count: int) -> bytes:
        need(base <= rva and rva + count <= base + size, 'bounded in-buffer metadata')
        return data[rva - base:rva - base + count]

    def functions(vtable: int) -> list[str]:
        out: list[str] = []
        for i in range(32):
            value = struct.unpack('<Q', at(vtable + 8 * i, 8))[0] - 0x140000000
            if not 0x1000 <= value < 0x43d9a00:
                break
            out.append(f'{value:X}')
        return out

    base_funcs = [] if terrain else functions(0x4927540)
    matches: list[dict[str, object]] = []
    for pos in positions(data, struct.pack('<I', target_td)):
        if pos < 12 or pos + 12 > size:
            continue
        a = pos - 12
        sig, offset, cd, td, hierarchy, self_rva = struct.unpack_from('<6I', data, a)
        if sig != 1 or self_rva != base + a:
            continue
        hsig, attrs, count, array = struct.unpack('<4I', at(hierarchy, 16))
        need(hsig == 0 and 0 < count <= 64, 'class hierarchy shape')
        descriptors: list[dict[str, int | str]] = []
        for ptr in struct.unpack('<' + 'I' * count, at(array, count * 4)):
            t, contained, mdisp, pdisp, vdisp, flags, nested = struct.unpack('<IIiiiII', at(ptr, 28))
            descriptors.append({'descriptor_rva': f'{ptr:X}', 'type_descriptor_rva': f'{t:X}', 'contained': contained, 'mdisp': mdisp, 'pdisp': pdisp, 'vdisp': vdisp, 'attributes': flags})
        need(terrain or any(d['type_descriptor_rva'] == '59AB430' for d in descriptors), 'CMap requires actual CJominiMap base')
        col = base + a
        for slot in positions(data, struct.pack('<Q', 0x140000000 + col)):
            vt = base + slot + 8
            funcs = functions(vt)
            if not funcs:
                continue
            differences = [{'slot_index': i, 'slot_offset': f'{8 * i:X}', 'CMap_target_rva': value, 'CJominiMap_target_rva': base_funcs[i] if i < len(base_funcs) else None} for i, value in enumerate(funcs) if i >= len(base_funcs) or value != base_funcs[i]]
            matches.append({'col_rva': f'{col:X}', 'col_hex': data[a:a + 24].hex(), 'subobject_offset': offset, 'vtable_rva': f'{vt:X}', 'col_pointer_slot_hex': data[slot:slot + 8].hex(), 'vtable_words_hex': at(vt, len(funcs) * 8).hex(), 'function_rvas': funcs, 'class_hierarchy_rva': f'{hierarchy:X}', 'actual_base_descriptors': descriptors, 'different_slots': differences})
    need(0 < len(matches) <= 4, 'exact typed reverse match')
    record = {'machine_id': MACHINE, 'observed_utc': datetime.now(timezone.utc).isoformat(), 'source_path': str(EXE), 'prior_exe_sha256': '98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518', 'target_type_descriptor_rva': f'{target_td:X}', 'target_name_from_actual_data': f'.?AV{kind}@@', 'base_type_descriptor_rva': None if terrain else '59AB430', 'base_vtable_rva': None if terrain else '4927540', 'base_function_rvas': base_funcs, 'matches': matches, 'rdata_prefix_bytes': size, 'rdata_prefix_sha256': digest, 'rdata_tail128_not_read': terrain, 'new_exe_bytes': size, 'cumulative_exe_charge': previous + size, 'section_saved': False, 'game_sdk_build': False}
    output = (json.dumps(record, separators=(',', ':')) + '\n').encode()
    need(len(output) <= 8192, 'small exact RTTI artifact')
    put(f'{kind.upper()}-RTTI-VTABLE-BRIDGE.actual-a01.json', output)
    print(json.dumps({'bytes': len(output), 'sha256': hashlib.sha256(output).hexdigest(), 'matches': matches, 'base_function_rvas': base_funcs, 'cumulative_exe_charge': previous + size}))


if __name__ == '__main__':
    main()
