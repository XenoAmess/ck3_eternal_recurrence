"""One bounded, literal-specific map-cache source locator; no image execution."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parent
EXE = Path('C:/ck3-e04-resume-20261015-a01/frozen-game-12004/ck3.exe')
NODES = Path('C:/SteamLibrary/steamapps/common/Crusader Kings III/game/map_data/nodes.dat')
LEDGER = ROOT / 'READ-LEDGER.latest.json'
MACHINE = 'desktop-3fevhd2-1c74096080'


def need(ok: bool, why: str) -> None:
    if not ok:
        raise ValueError(why)


def put(name: str, data: bytes) -> None:
    used = sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())
    need(used + len(data) + 8192 <= 294912, 'author budget')
    with (ROOT / name).open('xb') as stream:
        stream.write(data)


def main() -> None:
    original: object = json.loads(LEDGER.read_bytes())
    need(isinstance(original, dict), 'ledger object')
    if not isinstance(original, dict):
        raise ValueError('ledger object')
    previous = original.get('cumulative_exe_bytes_read')
    reserve = original.get('includes_conservative_failure_reservation_bytes')
    need(type(previous) is int and type(reserve) is int, 'exact ledger integers')
    if type(previous) is not int or type(reserve) is not int:
        raise ValueError('ledger integers')
    spent = 0
    read_rows: list[dict[str, int | str]] = []
    before = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (101040248, 1792052259095683000), 'frozen stat')
    with EXE.open('rb') as stream:
        def read(offset: int, size: int, purpose: str) -> bytes:
            nonlocal spent
            need(previous + spent + size <= 201326592, '192MiB cumulative budget')
            stream.seek(offset)
            data = stream.read(size)
            spent += len(data)
            read_rows.append({'offset': offset, 'bytes': len(data), 'purpose': purpose})
            LEDGER.write_text(json.dumps({'cumulative_exe_bytes_read': previous + spent, 'includes_conservative_failure_reservation_bytes': reserve, 'pending_source': 'cache-literal-locator'}) + '\n')
            need(len(data) == size, 'short image read')
            return data

        header = read(0, 4096, 'PE section metadata')
        pe = struct.unpack_from('<I', header, 0x3c)[0]
        count = struct.unpack_from('<H', header, pe + 6)[0]
        optional = struct.unpack_from('<H', header, pe + 20)[0]
        sections: list[tuple[str, int, int, int, int]] = []
        for i in range(count):
            row = header[pe + 24 + optional + i * 40:pe + 64 + optional + i * 40]
            vsize, rva, raw_size, raw = struct.unpack_from('<IIII', row, 8)
            sections.append((row[:8].rstrip(b'\0').decode('ascii'), rva, vsize, raw, raw_size))
        anchor_offset = next(raw + 0x262be10 - rva for _, rva, _, raw, size in sections if rva <= 0x262be10 < rva + size)
        anchor = read(anchor_offset, 660, 'retained exact4 identity anchor')
        need(hashlib.sha256(anchor).hexdigest() == 'b565d2261e9e4549c7f34ff31c97fd14849756a8e68d10e6fb7c23e9109230ef', 'identity anchor')
        section = next(s for s in sections if s[0] == '.rdata')
        need(section[4] <= 18 * 1048576, 'rdata bound')
        data = read(section[3], section[4], 'one nodes.dat literal-specific rdata locator')
        hits: list[dict[str, int | str]] = []
        for encoding in ('ascii', 'utf-16-le'):
            needle = 'nodes.dat'.encode(encoding)
            start = 0
            while True:
                pos = data.find(needle, start)
                if pos < 0:
                    break
                lo, hi = max(0, pos - 48), min(len(data), pos + len(needle) + 96)
                hits.append({'needle': 'nodes.dat', 'encoding': encoding, 'rva': f'{section[1] + pos:X}', 'context_start_rva': f'{section[1] + lo:X}', 'context_hex': data[lo:hi].hex()})
                start = pos + 1
        need(len(hits) <= 12, 'unexpected literal multiplicity')
    after = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), 'input stat changed')
    nstat = NODES.stat()
    record = {'machine_id': MACHINE, 'observed_utc': datetime.now(timezone.utc).isoformat(), 'prior_exe_sha256': '98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518', 'source_path': str(EXE), 'nodes_path': str(NODES), 'nodes_bytes': nstat.st_size, 'nodes_mtime_ns': nstat.st_mtime_ns, 'nodes_header_bytes': 1024, 'nodes_header_sha256': 'e8855188a86b1b4b1687601dc3a55b24b98913d77da6d8fceb32d3be5a0f7080', 'nodes_header_source': 'prior read-only tool chunk 3b8e5c; no repeat header read', 'nodes_header_ascii_magic_observed': False, 'nodes_full_sha256': None, 'nodes_version_binding_proved': False, 'previous_exe_charge': previous, 'new_exe_read_bytes': spent, 'cumulative_exe_charge': previous + spent, 'failure_reservation_included': reserve, 'reads': read_rows, 'literal_hits': hits, 'mapnode_relation_proved': False, 'game_sdk_build': False}
    raw = (json.dumps(record, separators=(',', ':')) + '\n').encode()
    need(len(raw) <= 8192, 'small locator output')
    put('CACHE-LITERAL-LOCATOR.actual-a01.json', raw)
    print(json.dumps({'file': 'CACHE-LITERAL-LOCATOR.actual-a01.json', 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'hits': hits, 'cumulative_exe_charge': previous + spent}))


if __name__ == '__main__':
    main()
