"""One literal-specific .text pass; candidate metadata, not a producer claim."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import struct

from cache_locator import EXE, LEDGER, MACHINE, ROOT, need, put


def main() -> None:
    value: object = json.loads(LEDGER.read_bytes())
    if not isinstance(value, dict):
        raise ValueError('ledger object')
    previous = value.get('cumulative_exe_bytes_read')
    reserve = value.get('includes_conservative_failure_reservation_bytes')
    if type(previous) is not int or type(reserve) is not int:
        raise ValueError('ledger integer fields')
    spent = 0
    rows: list[dict[str, int | str]] = []
    before = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (101040248, 1792052259095683000), 'frozen stat')
    with EXE.open('rb') as stream:
        def read(offset: int, size: int, purpose: str) -> bytes:
            nonlocal spent
            need(previous + spent + size <= 201326592, 'cumulative read ceiling')
            stream.seek(offset)
            data = stream.read(size)
            spent += len(data)
            rows.append({'offset': offset, 'bytes': len(data), 'purpose': purpose})
            LEDGER.write_text(json.dumps({'cumulative_exe_bytes_read': previous + spent, 'includes_conservative_failure_reservation_bytes': reserve, 'pending_source': 'nodes-dat-rip-xrefs'}) + '\n')
            need(len(data) == size, 'short source read')
            return data

        header = read(0, 4096, 'PE sections')
        pe = struct.unpack_from('<I', header, 0x3c)[0]
        count = struct.unpack_from('<H', header, pe + 6)[0]
        optional = struct.unpack_from('<H', header, pe + 20)[0]
        sections: list[tuple[str, int, int, int, int]] = []
        for i in range(count):
            row = header[pe + 24 + optional + i * 40:pe + 64 + optional + i * 40]
            vsize, rva, raw_size, raw = struct.unpack_from('<IIII', row, 8)
            sections.append((row[:8].rstrip(b'\0').decode('ascii'), rva, vsize, raw, raw_size))
        anchor_offset = next(raw + 0x262be10 - rva for _, rva, _, raw, size in sections if rva <= 0x262be10 < rva + size)
        need(hashlib.sha256(read(anchor_offset, 660, 'exact4 retained identity anchor')).hexdigest() == 'b565d2261e9e4549c7f34ff31c97fd14849756a8e68d10e6fb7c23e9109230ef', 'identity anchor')
        text = next(s for s in sections if s[0] == '.text')
        pdata = next(s for s in sections if s[0] == '.pdata')
        need(text[4] <= 68 * 1048576, 'one text pass bound')
        code = read(text[3], text[4], 'one complete literal-specific text pass')
        candidates: list[dict[str, int | str | bool]] = []
        pattern = re.compile(rb'[\x48-\x4f]\x8d[\x05\x0d\x15\x1d\x25\x2d\x35\x3d]....', re.DOTALL)
        for match in pattern.finditer(code):
            site = text[1] + match.start()
            target = site + 7 + struct.unpack_from('<i', match[0], 3)[0]
            if target != 0x48ec9b0:
                continue
            low, high = 0, min(pdata[2], pdata[4]) // 12
            start = end = 0
            while low < high:
                mid = (low + high) // 2
                a, b, _ = struct.unpack('<III', read(pdata[3] + mid * 12, 12, 'candidate runtime-function interval'))
                if site < a:
                    high = mid
                elif site >= b:
                    low = mid + 1
                else:
                    start, end = a, b
                    break
            candidates.append({'site_rva': f'{site:X}', 'target_rva': f'{target:X}', 'candidate_bytes': match[0].hex(), 'runtime_start_rva': f'{start:X}', 'runtime_end_rva_exclusive': f'{end:X}', 'runtime_bytes': end - start, 'instruction_boundary_proven': False})
        need(len(candidates) <= 8, 'unexpected multiplicity')
    after = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), 'input changed')
    record = {'machine_id': MACHINE, 'observed_utc': datetime.now(timezone.utc).isoformat(), 'prior_exe_sha256': '98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518', 'source_path': str(EXE), 'literal': 'map_data/nodes.dat', 'literal_rva': '48EC9B0', 'new_exe_read_bytes': spent, 'cumulative_exe_charge': previous + spent, 'conservative_failed_read_reservation_included': reserve, 'read_rows': rows, 'candidates': candidates, 'section_saved': False, 'game_sdk_build': False}
    data = (json.dumps(record, separators=(',', ':')) + '\n').encode()
    need(len(data) <= 4096, 'locator output bound')
    put('NODES-DAT-RIP-LOCATOR.actual-a01.json', data)
    print(json.dumps({'file': 'NODES-DAT-RIP-LOCATOR.actual-a01.json', 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'candidates': candidates, 'cumulative_exe_charge': previous + spent}))


if __name__ == '__main__':
    main()
