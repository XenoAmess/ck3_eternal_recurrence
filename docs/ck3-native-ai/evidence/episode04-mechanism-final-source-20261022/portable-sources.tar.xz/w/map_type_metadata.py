"""Small exact-vtable RTTI reads following the proven singleton constructor."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import struct

from cache_locator import EXE, LEDGER, MACHINE, need, put


def main() -> None:
    original: object = json.loads(LEDGER.read_bytes())
    if not isinstance(original, dict):
        raise ValueError('ledger object')
    previous = original.get('cumulative_exe_bytes_read')
    reserve = original.get('includes_conservative_failure_reservation_bytes')
    if type(previous) is not int or type(reserve) is not int:
        raise ValueError('ledger integers')
    spent = 0
    rows: list[dict[str, int | str]] = []
    before = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (101040248, 1792052259095683000), 'frozen stat')
    with EXE.open('rb') as stream:
        def read(offset: int, size: int, purpose: str) -> bytes:
            nonlocal spent
            need(spent + size <= 8192 and previous + spent + size <= 268435456, 'finite metadata read budget')
            stream.seek(offset)
            out = stream.read(size)
            spent += len(out)
            rows.append({'file_offset': offset, 'bytes': len(out), 'purpose': purpose, 'hex': out.hex(), 'sha256': hashlib.sha256(out).hexdigest()})
            LEDGER.write_text(json.dumps({'cumulative_exe_bytes_read': previous + spent, 'includes_conservative_failure_reservation_bytes': reserve, 'pending_source': 'exact-map-type-metadata'}) + '\n')
            need(len(out) == size, 'short metadata read')
            return out

        header = read(0, 4096, 'PE header')
        pe = struct.unpack_from('<I', header, 0x3c)[0]
        n = struct.unpack_from('<H', header, pe + 6)[0]
        optional = struct.unpack_from('<H', header, pe + 20)[0]
        sections: list[tuple[str, int, int, int]] = []
        for i in range(n):
            row = header[pe + 24 + optional + i * 40:pe + 64 + optional + i * 40]
            _, start, size, raw = struct.unpack_from('<IIII', row, 8)
            sections.append((row[:8].rstrip(b'\0').decode('ascii'), start, raw, size))

        def offset(rva: int) -> int:
            for name, start, raw, size in sections:
                if start <= rva < start + size:
                    need(name != '.text', 'no new instruction body read')
                    return raw + rva - start
            raise ValueError('unbacked RVA')

        types: list[dict[str, int | str | list[str]]] = []
        for vt in (0x4927540, 0x4927e38):
            table = read(offset(vt - 8), 72, 'exact constructor vtable and RTTI pointer ' + hex(vt))
            col_va = struct.unpack_from('<Q', table)[0]
            need(0x140000000 <= col_va < 0x140000000 + 110000000, 'COL image pointer')
            col = read(offset(col_va - 0x140000000), 24, 'RTTI complete-object locator')
            signature, suboffset, cd, td, ch, self_rva = struct.unpack('<6I', col)
            need(signature == 1 and self_rva == col_va - 0x140000000, 'COL relative-format identity')
            desc = read(offset(td), 128, 'exact RTTI descriptor and bounded class name')
            name = desc[16:].split(b'\0', 1)[0].decode('ascii')
            funcs = [f'{a - 0x140000000:X}' for a in struct.unpack_from('<8Q', table, 8)]
            types.append({'vtable_rva': f'{vt:X}', 'col_rva': f'{col_va - 0x140000000:X}', 'type_descriptor_rva': f'{td:X}', 'class_name': name, 'subobject_offset': suboffset, 'class_hierarchy_rva': f'{ch:X}', 'first_eight_vtable_function_rvas': funcs})
    need((before.st_size, before.st_mtime_ns) == (EXE.stat().st_size, EXE.stat().st_mtime_ns), 'input changed')
    # Header bytes are not duplicated in the persistent primary fragment.
    record = {'machine_id': MACHINE, 'observed_utc': datetime.now(timezone.utc).isoformat(), 'prior_exe_sha256': '98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518', 'source_path': str(EXE), 'previous_exe_charge': previous, 'new_exe_read_bytes': spent, 'cumulative_exe_charge': previous + spent, 'types': types, 'reads': [{k: v for k, v in r.items() if k != 'hex'} if r['purpose'] == 'PE header' else r for r in rows], 'game_sdk_build': False}
    data = (json.dumps(record, separators=(',', ':')) + '\n').encode()
    need(len(data) <= 8192, 'small metadata artifact')
    put('MAP-TYPE-METADATA.actual-a01.json', data)
    print(json.dumps({'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'types': types, 'new_exe_read_bytes': spent, 'cumulative_exe_charge': previous + spent}))


if __name__ == '__main__':
    main()
