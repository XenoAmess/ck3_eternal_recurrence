"""Extend a retained prolog fragment only along its real forward branch targets."""
from __future__ import annotations
import base64
from datetime import datetime, timezone
import hashlib
import json
import struct
import sys
import zlib
import capstone
from cache_locator import EXE, LEDGER, ROOT, MACHINE, need, put


def main() -> None:
    need(len(sys.argv) == 3, 'source basename and explicit body limit')
    source = ROOT / sys.argv[1]
    old = json.loads(source.read_bytes())
    start = int(old['start_rva'], 16)
    raw = zlib.decompress(base64.b64decode(old['raw_zlib_base64']))
    original_size = len(raw)
    limit = int(sys.argv[2])
    need(limit in (4096, 8192), 'explicit authorized bound')
    ledger = json.loads(LEDGER.read_bytes())
    previous = ledger['cumulative_exe_bytes_read']
    spent = 0
    ranges: list[str] = []
    md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
    md.detail = True
    with EXE.open('rb') as stream:
        def read(offset: int, size: int) -> bytes:
            nonlocal spent
            need(previous + spent + size <= 318767104, '304MiB ceiling')
            stream.seek(offset)
            data = stream.read(size)
            spent += len(data)
            ledger['cumulative_exe_bytes_read'] = previous + spent
            ledger['pending_source'] = f'complete-{start:X}'
            LEDGER.write_text(json.dumps(ledger) + '\n')
            need(len(data) == size, 'short read')
            return data
        for _ in range(12):
            instructions = list(md.disasm(raw, start))
            end = start + len(raw)
            targets = [o.imm for i in instructions if i.mnemonic.startswith('j') for o in i.operands if o.type == capstone.CS_OP_IMM and end <= o.imm < start + limit]
            if targets:
                target = max(targets)
            elif instructions and instructions[-1].mnemonic not in ('ret', 'int3', 'jmp'):
                target = end
            else:
                break
            low, high = 0, 2933220 // 12
            found: tuple[int, int, int] | None = None
            while low < high:
                middle = (low + high) // 2
                row = read(96838656 + middle * 12, 12)
                a, b, u = struct.unpack('<III', row)
                if target < a:
                    high = middle
                elif target >= b:
                    low = middle + 1
                else:
                    found = (a, b, u)
                    ranges.append(row.hex())
                    break
            need(found is not None, 'forward target has no unwind range')
            if found is None:
                break
            stop = found[1]
            need(end < stop <= start + limit, 'same method explicit body bound')
            raw += read(end - 3072, stop - end)
        record = {'machine_id': MACHINE, 'observed_utc': datetime.now(timezone.utc).isoformat(), 'source_path': str(EXE), 'prior_exe_sha256': old['prior_exe_sha256'], 'start_rva': f'{start:X}', 'end_rva_exclusive': f'{start + len(raw):X}', 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'initial_source': source.name, 'initial_source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'extension_runtime_function_rows': ranges, 'raw_codec': 'base64(zlib(raw))', 'raw_zlib_base64': base64.b64encode(zlib.compress(raw, 9)).decode('ascii'), 'previous_fragment_bytes': original_size, 'new_exe_bytes_read': spent, 'cumulative_exe_charge': previous + spent}
    output = (json.dumps(record, separators=(',', ':')) + '\n').encode()
    need(sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file()) + len(output) + 8192 <= 294912, 'freeze reserve')
    put(f'complete-{start:X}.source.json', output)
    print(json.dumps({k: v for k, v in record.items() if k != 'raw_zlib_base64'}))
    print('OUTPUT', len(output), hashlib.sha256(output).hexdigest())
    print('\n'.join(f'{i.address:X} {i.bytes.hex()} {i.mnemonic} {i.op_str}' for i in md.disasm(raw, start)))


if __name__ == '__main__':
    main()
