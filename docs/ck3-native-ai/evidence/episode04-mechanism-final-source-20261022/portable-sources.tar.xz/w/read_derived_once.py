"""Read the single authorized RTTI-linked CMap initialization candidate."""
from __future__ import annotations
import base64
from datetime import datetime, timezone
import hashlib
import json
import struct
import zlib
import sys
import capstone
from cache_locator import EXE, LEDGER, MACHINE, ROOT, need, put


def main() -> None:
    need(len(sys.argv) == 2, 'one exact typed target')
    target = int(sys.argv[1], 16)
    name = f'typed-phase03-{target:X}.source.json'
    prior = list(ROOT.glob('typed-phase03-*.source.json'))
    need(len(prior) < 28, 'typed bodies including final actually branching terrain-manager getter')
    consumed = sum(json.loads(x.read_bytes())['bytes'] for x in prior)
    need(consumed < 131072, '48KiB plus two8KiB and two4KiB explicit extension')
    need(not (ROOT / name).exists(), 'single derived read already consumed')
    ledger = json.loads(LEDGER.read_bytes())
    previous = ledger['cumulative_exe_bytes_read']
    reserve = ledger['includes_conservative_failure_reservation_bytes']
    need(type(previous) is int and type(reserve) is int, 'exact ledger integers')
    spent = 0
    before = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (101040248, 1792052259095683000), 'frozen stat')
    with EXE.open('rb') as stream:
        def read(offset: int, size: int) -> bytes:
            nonlocal spent
            need(previous + spent + size <= 318767104, '304MiB cumulative ceiling')
            stream.seek(offset)
            data = stream.read(size)
            spent += len(data)
            LEDGER.write_text(json.dumps({'cumulative_exe_bytes_read': previous + spent, 'includes_conservative_failure_reservation_bytes': reserve, 'pending_source': name}) + '\n')
            need(len(data) == size, 'short input')
            return data
        low, high = 0, 2933220 // 12
        found: tuple[int, int, int] | None = None
        row = b''
        while low < high:
            middle = (low + high) // 2
            row = read(96838656 + middle * 12, 12)
            start, end, unwind = struct.unpack('<III', row)
            if target < start:
                high = middle
            elif target >= end:
                low = middle + 1
            else:
                found = (start, end, unwind)
                break
        prefix_only = found is None
        if found is None:
            start, end, unwind = target, target + 16, 0
        else:
            start, end, unwind = found
        need(start == target and end - start <= (4096 if target in (0x36E8EA0, 0x22CDE10, 0x22CF370, 0x22CD240, 0x22CDFB0, 0x22CD850) else 8192) and consumed + end - start <= 131072, f'body bound {start:X}..{end:X}')
        raw = read(start - 3072, end - start)
    after = EXE.stat()
    record = {'machine_id': MACHINE, 'observed_utc': datetime.now(timezone.utc).isoformat(), 'source_path': str(EXE), 'prior_exe_sha256': '98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518', 'typed_bridge': 'actual typed virtual/direct source chain; source edge explained by caller artifact', 'start_rva': f'{start:X}', 'end_rva_exclusive': f'{end:X}', 'bytes': len(raw), 'prefix_only_no_unwind': prefix_only, 'sha256': hashlib.sha256(raw).hexdigest(), 'runtime_function_hex': row.hex(), 'unwind_rva': f'{unwind:X}', 'raw_codec': 'base64(zlib(raw)); SHA applies to decompressed original bytes', 'raw_zlib_base64': base64.b64encode(zlib.compress(raw, 9)).decode('ascii'), 'source_stat_unchanged': (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), 'new_exe_bytes_read': spent, 'cumulative_exe_charge': previous + spent, 'game_sdk_build': False}
    output = (json.dumps(record, separators=(',', ':')) + '\n').encode()
    core = sum(p.stat().st_size for p in ROOT.glob('*.source.json'))
    need(core + len(output) <= 229376, '224KiB core source cap')
    need(sum(x.stat().st_size for x in ROOT.rglob('*') if x.is_file()) + len(output) + 8192 <= 294912, '8KiB freeze reserve')
    put(name, output)
    print(json.dumps({'path': str(ROOT / name), 'bytes': len(output), 'sha256': hashlib.sha256(output).hexdigest(), 'function': {k: v for k, v in record.items() if k != 'raw_zlib_base64'}}))
    md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
    print('\n'.join(f'{i.address:X} {i.bytes.hex()} {i.mnemonic} {i.op_str}' for i in md.disasm(raw, start)))


if __name__ == '__main__':
    main()
