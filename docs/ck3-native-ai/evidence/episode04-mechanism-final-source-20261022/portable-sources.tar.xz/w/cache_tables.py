"""Explicit second rdata pass: one cache literal's pointer slots and two keys."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import struct

from cache_locator import EXE, LEDGER, MACHINE, need, put


def locations(data: bytes, needle: bytes) -> list[int]:
    result: list[int] = []
    start = 0
    while True:
        at = data.find(needle, start)
        if at < 0:
            return result
        result.append(at)
        start = at + 1


def main() -> None:
    original: object = json.loads(LEDGER.read_bytes())
    if not isinstance(original, dict):
        raise ValueError('ledger object')
    previous = original.get('cumulative_exe_bytes_read')
    reserve = original.get('includes_conservative_failure_reservation_bytes')
    if type(previous) is not int or type(reserve) is not int:
        raise ValueError('exact ledger integers')
    size, raw, rva = 17124352, 71142912, 71147520
    need(previous + size <= 201326592, '192MiB total ceiling')
    before = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (101040248, 1792052259095683000), 'frozen stat')
    with EXE.open('rb') as stream:
        stream.seek(raw)
        data = stream.read(size)
    LEDGER.write_text(json.dumps({'cumulative_exe_bytes_read': previous + len(data), 'includes_conservative_failure_reservation_bytes': reserve, 'pending_source': 'cache-pointer-table'}) + '\n')
    need(len(data) == size, 'complete bounded rdata read')
    after = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), 'source changed')
    pointers: list[dict[str, int | str]] = []
    for name, needle in [('absolute_va', struct.pack('<Q', 0x140000000 + 0x48ec9b0)), ('image_rva', struct.pack('<I', 0x48ec9b0))]:
        hits = locations(data, needle)
        need(len(hits) <= 8, 'unexpected pointer multiplicity')
        for at in hits:
            lo, hi = max(0, at - 48), min(size, at + 80)
            pointers.append({'representation': name, 'slot_rva': f'{rva + at:X}', 'context_start_rva': f'{rva + lo:X}', 'context_hex': data[lo:hi].hex()})
    keys: list[dict[str, int | str | list[str]]] = []
    for key in ['adjacencies', 'movement_speed']:
        hits = locations(data, b'\0' + key.encode('ascii') + b'\0')
        keys.append({'key': key, 'exact_null_delimited_ascii_count': len(hits), 'literal_rvas': [f'{rva + at + 1:X}' for at in hits[:16]]})
    record = {'machine_id': MACHINE, 'observed_utc': datetime.now(timezone.utc).isoformat(), 'source_path': str(EXE), 'prior_exe_sha256': '98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518', 'rdata_rva': f'{rva:X}', 'rdata_file_offset': raw, 'rdata_bytes': size, 'rdata_sha256': hashlib.sha256(data).hexdigest(), 'nodes_literal_rva': '48EC9B0', 'nodes_pointer_slots': pointers, 'keys': keys, 'previous_exe_charge': previous, 'new_exe_read_bytes': size, 'cumulative_exe_charge': previous + size, 'prior_conservative_failed_read_bytes_included': reserve, 'producer_proved': False, 'section_saved': False, 'game_sdk_build': False}
    output = (json.dumps(record, separators=(',', ':')) + '\n').encode()
    need(len(output) <= 4096, 'locator output ceiling')
    put('CACHE-POINTER-TABLE-LOCATOR.actual-a01.json', output)
    print(json.dumps({'bytes': len(output), 'sha256': hashlib.sha256(output).hexdigest(), 'pointers': pointers, 'keys': keys, 'cumulative_exe_charge': previous + size}))


if __name__ == '__main__':
    main()
