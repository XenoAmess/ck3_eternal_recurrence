"""Project rasterizer for the inspected source-card SVG subset, using Pillow.

This is not a browser SVG engine. Unknown elements/attributes fail closed.
Source cards and resulting stills remain review material, never game footage.
"""
from pathlib import Path
from io import BytesIO
import math,re,xml.etree.ElementTree as ET
from PIL import Image,ImageDraw,ImageFont

ATTRS={
 'svg':{'width','height','viewBox','role'},'title':set(),'desc':set(),'metadata':set(),
 'defs':set(),'marker':{'id','markerWidth','markerHeight','refX','refY','orient'},'path':{'d','fill'},
 'rect':{'x','y','width','height','rx','fill','stroke','stroke-width'},
 'circle':{'cx','cy','r','fill','stroke','stroke-width'},
 'line':{'x1','y1','x2','y2','stroke','stroke-width','marker-end'},
 'polyline':{'points','fill','stroke','stroke-width'},'polygon':{'points','fill'},
 'text':{'x','y','fill','font-family','font-size','font-weight','textLength','lengthAdjust','text-anchor','dominant-baseline'},
}
def need(ok,message):
 if not ok:raise ValueError(message)
def tag(e):return e.tag.rsplit('}',1)[-1]
def parse_svg(raw):
 need(len(raw)<=128*1024 and b'<!DOCTYPE'not in raw and b'<!ENTITY'not in raw,'unsafe/oversize source card')
 root=ET.fromstring(raw);need(tag(root)=='svg','SVG root required')
 for e in root.iter():
  t=tag(e);need(t in ATTRS and not(set(e.attrib)-ATTRS[t]),'unsupported SVG vocabulary: '+t)
  if t=='path':need(e.get('d')=='M0,0 L12,6 L0,12 Z','uninspected marker path')
  if t=='text':
   need(not list(e),'nested text unsupported')
   need(e.get('text-anchor','start')in('start','middle','end'),'unknown text anchor')
   need(e.get('dominant-baseline','alphabetic')in('alphabetic','middle','central','text-before-edge'),'unknown baseline')
   need(e.get('lengthAdjust','spacingAndGlyphs')=='spacingAndGlyphs','unknown textLength policy')
 w,h=int(root.get('width','0')),int(root.get('height','0'))
 need(0<w<=2560 and 0<h<=1440 and root.get('viewBox')==f'0 0 {w} {h}','unexpected SVG geometry')
 return root
def colour(v):return None if v in(None,'none')else v
def points(v):
 nums=[float(x)for x in re.split('[ ,]+',v.strip())];need(len(nums)>=4 and len(nums)%2==0,'invalid points')
 return list(zip(nums[::2],nums[1::2]))
def raster_image(raw,regular,bold,*,review_label=True):
 root=parse_svg(raw);w,h=int(root.get('width')),int(root.get('height'))
 image=Image.new('RGB',(w,h),'#211813');draw=ImageDraw.Draw(image);markers={e.get('id'):e for e in root.iter()if tag(e)=='marker'};fonts={}
 def num(e,k,default=0):return float(e.get(k,str(default)))
 def font(size,weight):
  key=(size,weight)
  if key not in fonts:fonts[key]=ImageFont.truetype(str(bold if weight>=600 else regular),size)
  return fonts[key]
 for e in root:
  t=tag(e)
  if t in('title','desc','metadata','defs'):continue
  width=max(1,round(num(e,'stroke-width',1)));fill=colour(e.get('fill'));stroke=colour(e.get('stroke'))
  if t=='rect':
   x,y=num(e,'x'),num(e,'y');box=(x,y,x+num(e,'width'),y+num(e,'height'))
   if num(e,'rx'):draw.rounded_rectangle(box,radius=num(e,'rx'),fill=fill,outline=stroke,width=width)
   else:draw.rectangle(box,fill=fill,outline=stroke,width=width)
  elif t=='circle':
   x,y,r=num(e,'cx'),num(e,'cy'),num(e,'r');draw.ellipse((x-r,y-r,x+r,y+r),fill=fill,outline=stroke,width=width)
  elif t in('polyline','polygon'):
   pts=points(e.get('points'))
   if t=='polygon':draw.polygon(pts,fill=fill)
   else:
    need(fill is None,'filled polyline not held');draw.line(pts,fill=stroke,width=width,joint='curve')
  elif t=='line':
   x1,y1,x2,y2=(num(e,k)for k in('x1','y1','x2','y2'));draw.line((x1,y1,x2,y2),fill=stroke,width=width)
   if e.get('marker-end'):
    match=re.fullmatch(r'url\(#([A-Za-z0-9_-]+)\)',e.get('marker-end'));need(match and match[1]in markers,'unknown marker')
    marker=markers[match[1]];need(marker.get('orient')=='auto'and marker.get('markerWidth')=='12'and marker.get('markerHeight')=='12'and marker.get('refX')=='10'and marker.get('refY')=='6','uninspected marker geometry')
    angle=math.atan2(y2-y1,x2-x1);c,s=math.cos(angle),math.sin(angle)
    pts=[(x2+(x-10)*width*c-(y-6)*width*s,y2+(x-10)*width*s+(y-6)*width*c)for x,y in((0,0),(12,6),(0,12))]
    draw.polygon(pts,fill=marker[0].get('fill'))
  elif t=='text':
   value=e.text or'';face=font(round(num(e,'font-size')),int(e.get('font-weight','400')));box=face.getbbox(value,anchor='ls');advance=face.getlength(value)
   if not value:continue
   target=num(e,'textLength',advance);ratio=target/advance if advance else 1
   glyph=Image.new('RGBA',(max(1,box[2]-box[0]),max(1,box[3]-box[1])))
   ImageDraw.Draw(glyph).text((-box[0],-box[1]),value,font=face,fill=fill or'#000000',anchor='ls')
   if abs(ratio-1)>1e-7:glyph=glyph.resize((max(1,round(glyph.width*ratio)),glyph.height),Image.Resampling.LANCZOS)
   x,y=num(e,'x'),num(e,'y');anchor=e.get('text-anchor','start');x-=target/2 if anchor=='middle'else target if anchor=='end'else 0
   if e.get('dominant-baseline')in('middle','central'):y-= (box[1]+box[3])/2
   elif e.get('dominant-baseline')=='text-before-edge':y-=box[1]
   image.paste(glyph,(round(x+box[0]*ratio),round(y+box[1])),glyph)
  else:raise ValueError('uninspected top-level SVG '+t)
 if review_label:
  need((w,h)==(2560,1440),'movie review label requires original geometry')
  draw.rectangle((0,0,2560,34),fill='#100D0B')
  draw.text((48,5),'机制 / 方法审阅版 · R10三臂结果待观测  |  METHODOLOGY REVIEW · RESULTS PENDING',font=font(20,400),fill='#CBA56A')
 return image
def raster_to_new_png(source,target,regular,bold):
 target=Path(target);need(not target.exists(),'still output exists: use fresh workdir');target.parent.mkdir(parents=True,exist_ok=True)
 image=raster_image(Path(source).read_bytes(),regular,bold)
 with target.open('xb')as f:image.save(f,format='PNG')
 return target
