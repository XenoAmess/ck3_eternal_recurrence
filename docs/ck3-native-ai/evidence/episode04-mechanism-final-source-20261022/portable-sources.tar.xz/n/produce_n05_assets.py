"""One accepted N05 voice and one series-yellow K17; no encoder or other cue."""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import subprocess
import sys
from decimal import Decimal
from PIL import Image
from xar_promo.operations import preserve_artifact, start_run
from xar_promo.project import artifact_path
from xar_promo.tts import EdgeTtsProvider, TtsCache, TtsRequest

V = Path('C:/ck3-e04-resume-20261020-a01/r22-mechanics-voice-assets-a01')
sys.path.insert(0, str(V))
from produce_voice_assets_a02 import RetainProviderFailure, mapping, text, pin, checked, save, load

ROOT = Path('C:/ck3-e04-resume-20261020-a01/r22-n05-weight-explainer-a01')
MACHINE = 'desktop-3fevhd2-1c74096080'


def identity(path: Path) -> dict[str, str]:
    st = path.stat()
    return {'mtime_ns': str(st.st_mtime_ns), 'st_dev': str(st.st_dev), 'st_ino': str(st.st_ino)}


def retained(value: object) -> Path:
    ref = mapping(value)
    path = Path(text(ref['path']))
    if path.stat().st_size != ref['bytes'] or identity(path) != ref['identity']:
        raise ValueError('Retained tool/font identity changed')
    return path


def aggregate() -> int:
    return sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())


def guard(deadline: dt.datetime, reserve: int = 0) -> None:
    total = aggregate()
    audio = sum(p.stat().st_size for p in ROOT.rglob('*.mp3'))
    png = sum(p.stat().st_size for p in ROOT.rglob('*.png'))
    if dt.datetime.now(dt.UTC) >= deadline or total + reserve > 8388608:
        raise ValueError('Deadline or same8MiB aggregate; preserve actual partial')
    if audio > 2097152 or png > 1048576 or total - audio - png > 5242880:
        raise ValueError('Audio/PNG/control component limit')


def probe(ffprobe: Path, audio: Path, deadline: dt.datetime) -> str:
    guard(deadline, 262144)
    argv = [str(ffprobe), '-v', 'error', '-show_entries', 'format=duration', '-of', 'json', str(audio)]
    process = subprocess.Popen(argv, cwd=ROOT, env=dict(os.environ), stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
    output, error = b'', b''
    try:
        output, error = process.communicate(timeout=max(0.1, min(30.0, (deadline - dt.datetime.now(dt.UTC)).total_seconds())))
    finally:
        if process.poll() is None:
            process.kill()
            output, error = process.communicate()
        wait = process.wait()
        save(ROOT / 'DURATION-ORIGINAL-WAIT.actual-a01.json', {'machine_id': MACHINE,
             'observed_at_utc': dt.datetime.now(dt.UTC).isoformat(), 'PID': process.pid,
             'argv': argv, 'original_Popen_wait': wait, 'stdout': output.decode('utf-8'),
             'stderr': error.decode('utf-8'), 'owned_Popen_remaining': 0})
    if wait != 0 or len(output) + len(error) > 65536:
        raise ValueError('Actual one duration probe failed')
    parsed: object = json.loads(output)
    return text(mapping(mapping(parsed)['format'])['duration'])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--admission', type=Path, required=True)
    parser.add_argument('--admission-sha', required=True)
    args = parser.parse_args()
    inputs, card = load(args.inputs), load(args.admission)
    if (pin(args.admission)['sha256'] != args.admission_sha or card.get('machine_id') != MACHINE
        or card.get('admitted') is not True or card.get('N05_TTS_and_K17_raster_execution_admitted') is not True
        or Path(text(card['aggregate_root'])) != ROOT or card.get('aggregate_ceiling_bytes') != 8388608
        or card.get('producer_sha256') != pin(Path(__file__))['sha256']
        or card.get('inputs_sha256') != pin(args.inputs)['sha256']):
        raise ValueError('Exact same8MiB N05 asset admission required')
    deadline = dt.datetime.fromisoformat(text(card['hard_deadline_utc']).replace('Z', '+00:00'))
    checked(inputs['retained_voice_helper'])
    project = checked(inputs['current_project'])
    cue = load(checked(inputs['cue']))
    source = checked(inputs['knowledge_SVG'])
    renderer = checked(inputs['rasterizer'])
    checked(inputs['palette_source'])
    regular, bold = retained(inputs['font_regular']), retained(inputs['font_bold'])
    ffprobe = retained(inputs['ffprobe'])
    if cue.get('cue_id') != 'N05-01' or cue.get('chapter_id') != 'E4-05':
        raise ValueError('Only accepted N05-01')
    for name in ('audio-cache', 'native', 'cards', 'partial'):
        (ROOT / name).mkdir()
    (ROOT / 'temp').mkdir(exist_ok=True)
    os.environ.update(TMP=str(ROOT / 'temp'), TEMP=str(ROOT / 'temp'), PYTHONDONTWRITEBYTECODE='1')
    guard(deadline, 2097152)
    save(ROOT / 'ONCE-N05-ASSETS.actual-a01.json', {'machine_id': MACHINE,
        'observed_at_utc': dt.datetime.now(dt.UTC).isoformat(), 'admission': pin(args.admission),
        'provider_executions_ceiling': 1, 'other46_voices_unchanged': True})
    config = ROOT / 'native/promo-project.json'
    with config.open('xb') as stream:
        stream.write(project.read_bytes())
    run = start_run(config, run_id='n05-weights-assets-a01', run_directory=ROOT / 'native/runs/n05-weights-assets-a01')
    provider = RetainProviderFailure(EdgeTtsProvider(), ROOT, 'N05-01')
    chinese = text(cue['chinese'])
    audio = TtsCache(ROOT / 'audio-cache').get_or_create(TtsRequest(chinese,
        'zh-CN-XiaoxiaoNeural', rate='-5%'), provider, max_attempts=1)
    guard(deadline)
    if 2 * audio.media_path.stat().st_size > 2097152:
        raise ValueError('Actual voice cannot fit source-original plus CAS')
    seconds = probe(ffprobe, audio.media_path, deadline)
    duration = Decimal(seconds)
    if not duration.is_finite() or duration <= 0:
        raise ValueError('Actual duration must be positive')
    record = preserve_artifact(run, audio.media_path, artifact_id='voice.N05-01', collection='derived',
        role='narration', label='Actual updated N05 path-weight explanation', media_type='audio/mpeg')
    voice = {'cue_id': 'N05-01', 'chapter_id': 'E4-05', 'text_sha256': hashlib.sha256(chinese.encode()).hexdigest(),
        'actual_seconds': seconds, 'minimum_voice_frames_30fps': math.ceil(duration * 30),
        'original_MP3': pin(audio.media_path), 'native_CAS': pin(artifact_path(record, run.parent)),
        'provider_calls': provider.calls, 'cache_hit': audio.cache_hit, 'atempo_or_trim': False}
    spec = importlib.util.spec_from_file_location('retained_n05_yellow_rasterizer', renderer)
    if spec is None or spec.loader is None:
        raise ValueError('Retained rasterizer missing')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    raster = getattr(module, 'raster_image', None)
    if not callable(raster):
        raise ValueError('Retained raster_image missing')
    value: object = raster(source.read_bytes(), regular, bold, review_label=False)
    if not isinstance(value, Image.Image) or value.size != (1920, 1080):
        raise ValueError('Lossless original1920x1080 required')
    path = ROOT / 'cards/K17.png'
    with path.open('xb') as stream:
        value.save(stream, format='PNG')
    guard(deadline, path.stat().st_size)
    record = preserve_artifact(run, path, artifact_id='knowledge.K17', collection='derived',
        role='formula-still', label='Series yellow path-weight calculation', media_type='image/png')
    native = artifact_path(record, run.parent)
    image = {'id': 'K17', 'source_SVG': pin(source), 'original_PNG': pin(path),
        'native_CAS': pin(native), 'old_review_banner': False, 'native_identity': identity(native)}
    save(ROOT / 'ASSETS.actual-a01.json', {'machine_id': MACHINE,
        'observed_at_utc': dt.datetime.now(dt.UTC).isoformat(), 'current_project': pin(project),
        'voice_override': voice, 'knowledge_image_override': image, 'palette_source': inputs['palette_source'],
        'TTS_provider_calls': provider.calls, 'actual_seconds': seconds, 'new_PNG_rasters': 1,
        'FFmpeg_encoder_calls': 0, 'other46_voice_rows_and_segment_CAS_unchanged': True})
    guard(deadline)
    print('ACTUAL N05-01 ' + seconds + 's; K17 yellow PNG; no encoder', flush=True)


if __name__ == '__main__':
    main()
