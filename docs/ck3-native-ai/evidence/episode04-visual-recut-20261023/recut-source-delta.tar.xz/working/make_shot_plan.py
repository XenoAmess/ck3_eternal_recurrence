"""Produce the single bounded recut picture contract from retained source evidence."""
from __future__ import annotations

from pathlib import Path
from working_contract import (
    SOURCE, AUDIT, MACHINE, Resources, FilePin, JsonObject, JsonValue,
    canonical, decode, integer, need, now, object_row, rows, string, pin, source_budget, source_relative,
)
from working_recipe import prepare_base, DYNAMIC
from recut_shots import NativeShot, CardShot, Shot, CueShots, ShotSource

RUNTIME=FilePin(str(AUDIT/'runtime-shots.actual-a01.json'),43604,
    '94c18f63c3a3b88e47017ee63d3dad0b831522f62cfb973ea95fab45c21a8335')
INTRO=FilePin(str(AUDIT/'intro-style-and-shots.actual-a01.json'),19576,
    'c2a97a84c6a2abf88c3800e101406102c5a2c8b2a7ceb91b793fd0b7b9da182a')
D=Path('D:/workspace/ck3_native_war_ai_promo_work')
C15=Path('C:/ck3-e04-resume-20261015-a01')


def partition_native(native: tuple[NativeShot,...],card_frames: int) -> tuple[Shot,...]:
    """Keep exact selected frames in order, with at most12s cards between native ranges."""
    need(type(card_frames) is int and card_frames>=0,'Exact nonnegative card remainder')
    if card_frames==0:
        return native
    if not native:
        return (CardShot(card_frames),)
    pieces=(card_frames+359)//360
    total=sum(n.frames for n in native)
    need(total>=pieces+1,'A real native separator for every short card')
    remaining=list(native);result: list[Shot]=[]
    for index in range(pieces+1):
        target=total//(pieces+1)+(1 if index<total%(pieces+1) else 0)
        while target:
            shot=remaining.pop(0);count=min(target,shot.frames)
            result.append(NativeShot(shot.source,shot.first,shot.first+count,shot.player_actor,shot.army_owner,shot.relation,shot.label))
            if count<shot.frames:
                remaining.insert(0,NativeShot(shot.source,shot.first+count,shot.end,shot.player_actor,shot.army_owner,shot.relation,shot.label))
            target-=count
        if index<pieces:
            result.append(CardShot(card_frames//pieces+(1 if index<card_frames%pieces else 0)))
    need(not remaining,'All and only actual selected native frames')
    return tuple(result)


def build_document(resources: Resources) -> JsonObject:
    rt=object_row(decode(RUNTIME.verify(65536)));intro=object_row(decode(INTRO.verify(32768)))
    need(rt['machine_id']==intro['machine_id']==MACHINE,'Same-machine source mapping')
    source_rows: JsonObject={}
    sources: dict[str,ShotSource]={}
    def add(key: str,media: FilePin,end: int,actor: int | None,owner: int | None,evidence: tuple[FilePin,...]) -> None:
        media.verify(1536*1048576)
        for ref in evidence:
            ref.verify(1048576)
        row: JsonObject={'media':media.wire(),'maximum_source_end_exclusive':end,
                        'player_actor_character_id':actor,'subject_army_owner_character_id':owner,
                        'evidence':[p.wire() for p in evidence]}
        source_rows[key]=row;sources[key]=ShotSource.parse(key,row)
    for key,value in object_row(rt['sources']).items():
        r=object_row(value);raw=object_row(r['raw']);probe=object_row(r['existing_probe'])
        end_value=probe['actual_frames']
        end=integer(end_value) if end_value is not None else {'R221':990,'R215':5683,'R171':932}[key]
        add(key,FilePin(string(raw['path']),integer(raw['bytes']),string(raw['retained_sha256'])),end,
            None if key in ('R221','R215','R193') else 31254,
            33388 if key in ('R221','R215') else (31254 if key in ('B1','B2') else None),
            (FilePin.parse(r['source_receipt']),FilePin.parse(probe['source']),RUNTIME))
    raw_rows=object_row(intro['raw_sources'])
    for key,end in (('R11',1350),('R12',1350),('R13',1350),('R03',1200)):
        raw=object_row(raw_rows[key]);add(key,FilePin(string(raw['path']),integer(raw['bytes']),
            string(raw['retained_sha256'])),end,31254,None,(INTRO,))
    window=resources.raw_windows['R04'];p=window.source.pin
    need(window.scope.file is not None,'Retained actual enemy-county source review')
    ref=window.scope.file
    if ref is None:
        raise ValueError('Missing actual enemy-county source review')
    add('R04',FilePin(str(p.path),p.size,p.sha),900,None,33388,
        (FilePin(str(ref.path),ref.size,ref.sha),))
    p=resources.raw_windows['R07'].source.pin
    add('R196',FilePin(str(p.path),p.size,p.sha),2369,31254,None,
        (pin(D/'e04-r196-media-audit-a01/limited-eight-frame-review.actual-a01.json'),))
    dynamic=object_row(decode(DYNAMIC.verify(8192)))
    add('R204',FilePin.parse(dynamic['adopted_raw']),698,31254,None,(DYNAMIC,))
    for key,raw_path,end,actor,evidence_path in (
        ('R190',D/'e04-r190-window-capture-a01/raw-window-a01/raw.mkv',900,31254,
         D/'e04-r190-window-capture-a01/runtime-actor-identity.actual-a01.json'),
        ('R198',D/'e04-r198-military-toggle-a01/raw-r198-military-a01/raw.mkv',1718,31254,
         D/'e04-r198-media-audit-a01/asset-manifest.json'),
        ('R216',D/'e04-r216-county-entry-positive-a01/raw-r216/take01/raw.mkv',568,33388,
         D/'e04-r216-county-entry-positive-a01/media-probe-take01-a01/PROBE.actual.json'),
        ('R217',D/'e04-r217-county-owner-entry-a01/resume-a02/raw/take01/raw.mkv',1493,33388,
         D/'e04-r217-county-owner-entry-a01/resume-a02/media-qa-take01-a01/MEDIA-QA.actual.json'),
        ('R08',Path('C:/ck3-e04-resume-20261022-b01/r08-settlement-a01/camera-raw-a01/r08-postload-a01/raw.mkv'),
         1320,31254,Path('C:/ck3-e04-resume-20261022-b01/r08-settlement-a01/camera-raw-a01/r08-postload-a01/R08-CONTINUOUS-TAKE.actual.json')),
    ):
        evidence: tuple[FilePin,...]=(pin(evidence_path),)
        if key=='R217':
            evidence=(*evidence,pin(Path('C:/ck3-e04-resume-20261020-a01/r06-resume-a02/r0217-positive-scope-review-a01/NATIVE-SCOPE-DETAILS.actual.json')))
        add(key,pin(raw_path),end,None if key in ('R216','R217') else actor,
            33388 if key=='R217' else None,evidence)
    def shot(key: str,a: int,b: int,*,exact: bool=False,label: str='') -> NativeShot:
        source=sources[key]
        prefix=('威廉军队' if source.army_owner==33388 else
                ('罗贝尔军队' if source.player_actor==31254 else '分兵实机画面'))
        return NativeShot(key,a,b,source.player_actor,source.army_owner,'direct_evidence' if exact else 'context_only',
            label or prefix+(' · 实机观察' if exact else ' · 界面示例'))
    assignments: dict[str,tuple[NativeShot,...]]={}
    scopes: dict[str,str]={}
    for value in rows(rt['cues']):
        r=object_row(value);key=string(r['cue_id']);source=r['source_key'];interval=r['suggested_frames_half_open']
        scopes[key]=string(r['match_and_claim_scope'])+' '+string(r['editorial_limit'])
        if source is not None:
            pair=rows(interval);a,b=integer(pair[0]),integer(pair[1])
            exact=r['match_kind']=='exact_visible_observation'
            assignments[key]=(shot(string(source),a,b,exact=exact),)
    supplements=(('N01-06','R199',2696,3508),('N01-10','R171',300,932),
        ('N01-07','R215',300,801),('N01-08','R215',801,1258),('N02-02','R215',1258,1765),
        ('N01-09','R196',1560,2160))
    for cue_id,key,a,b in supplements:
        assignments[cue_id]=(shot(key,a,b,label=('威廉军队' if sources[key].army_owner==33388 else '罗贝尔军队')+' · 计算示例'),)
        scopes[cue_id]=scopes.get(cue_id,'')+' Explicit hypothetical rule; original UI is context only, no claimed number/action shown.'
    assignments.update({
        'C01-01':(shot('R204',15,627,exact=True,label='罗贝尔 · 墨西拿海峡'),),
        'C01-08':(shot('R12',0,884,label='罗贝尔 · 行军画面'),),
        'C01-04':(shot('R194',0,450,label='罗贝尔 · 分兵画面'),shot('R13',0,406,label='回顾 · 锁定改道')),
        'C01-05':(shot('R03',0,948,label='回顾 · 罗贝尔围攻'),),
        'C01-06':(shot('R13',0,866,label='罗贝尔 · 行军路线'),),
        'C06-03':(shot('R12',0,918,label='回顾 · 锁定后停止'),),
        'C06-10':(shot('R13',0,237,label='回顾 · 路线与条件'),shot('R11',0,600,label='回顾 · 未锁定停止'),
                    shot('R13',237,274,label='回顾 · 再作决定')),
        'N03-01':(shot('R03',0,1200,exact=True,label='罗贝尔 · 围攻损耗'),),
        'N03-03':(shot('R190',0,365,label='计算示例 · 围攻画面'),shot('R204',0,302,label='计算示例 · 接战画面')),
        'N03-04':(shot('R190',365,900,label='计算示例 · 围攻画面'),),
        'N03-05':(shot('R04',0,900,exact=True,label='威廉军队 · 跨县损耗'),),
        'N03-06':(shot('R217',900,1493,label='计算示例 · 威廉路线'),),
        'N03-07':(shot('R216',0,568,label='跨县实机画面 · 路线示例'),),
        'N05-01':(shot('R13',900,1350,label='计算示例 · 行军路线'),
                  shot('R12',900,1350,label='计算示例 · 行程终点'),shot('R199',3508,3845,label='计算示例 · 陆上路线')),
        'N05-02':(shot('R199',3845,4464,label='计算示例 · 陆上路线'),),
        'N05-03':(shot('R11',0,763,exact=True,label='罗贝尔 · 未锁定停止'),),
        'N05-04':(shot('R12',0,1020,exact=True,label='罗贝尔 · 锁定后停止'),),
        'N05-05':(shot('R13',0,900,exact=True,label='罗贝尔 · 锁定后改道'),),
        'N05-06':(shot('R196',0,646,label='计算示例 · 登船前军队'),),
        'N05-07':(shot('R196',960,1560,exact=True,label='罗贝尔 · 登船付费'),
                  shot('R196',2160,2363,label='罗贝尔 · 登船后')),
        'N05-09':(shot('R196',646,960,label='计算示例 · 登船前'),shot('R12',900,1350,label='计算示例 · 航行画面')),
        'N05-08':(shot('R13',538,1350,label='罗贝尔 · 海路回顾'),),
        'N06-01':(shot('R12',600,1122,label='计算示例 · 海上军队'),),
        'N06-02':(shot('R198',780,1429,label='罗贝尔 · 兵士补员开关'),),
        'N06-03':(shot('R198',553,780,label='计算示例 · 兵士界面'),shot('R198',1429,1718,label='计算示例 · 兵士界面')),
        'N06-04':(shot('R198',0,553,label='罗贝尔 · 军费界面'),),
        'N06-08':(shot('R08',180,1051,exact=True,label='罗贝尔 · 同次入账'),),
        'N06-05':(shot('R08',0,180,label='回顾 · 同次入账前'),shot('R08',1051,1320,label='回顾 · 同次入账后')),
        'N06-07':(shot('R215',1765,2377,label='威廉军队 · 兵力组成'),),
        'N06-06':(shot('R13',989,1350,label='回顾 · 远征的四本账'),),
    })
    cues: list[JsonValue]=[]
    for cue in prepare_base(resources):
        native=assignments.get(cue.cue_id,())
        amount=sum(s.frames for s in native)
        need(amount<=cue.frames,'Selected raw does not overrun retained cue '+cue.cue_id)
        shots=partition_native(native,cue.frames-amount)
        scope=scopes.get(cue.cue_id,'Root-selected same-actor recap/context; no new numerical outcome or event PTS qualification.')
        if cue.cue_id=='N03-02':
            scope='Unverified R05 rule only; persistent viewer notice; actual acceptance stays null.'
        if cue.cue_id in ('N06-08','N06-05'):
            scope='One already accepted settlement net amount includes military cost. No full-cycle or duplicate-charge claim.'
        row=CueShots(cue.cue_id,cue.frames,shots,scope).wire()
        CueShots.parse(decode(canonical(row)),sources)
        cues.append(row)
    return {'schema':'xar.e04.recut.shots.v2','machine_id':MACHINE,'observed_at_utc':now(),
            'sources':source_rows,'cues':cues,'R05_actual_acceptance':None,'human1x':False,'signoff':False}


def main() -> None:
    budget=source_budget();resources=Resources.load()
    document=build_document(resources)
    target=SOURCE/'RECUT-SHOTS.source-a02.json'
    if target.exists():
        prior=object_row(decode(target.read_bytes()))
        document['observed_at_utc']=prior['observed_at_utc']
        need(canonical(document)==canonical(prior),'Reexecuted producer equals the retained exact shot document')
        result=pin(target)
    else:
        result=budget.json(source_relative(budget,'RECUT-SHOTS.source-a02.json'),document)
    print(canonical(result.wire()).decode('utf-8'))


if __name__=='__main__':
    main()
