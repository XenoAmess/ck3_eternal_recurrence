"""One typed frame-range contract for the recut producer and renderer."""
from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Literal

from working_contract import (
    FilePin, JsonObject, JsonValue, WorkingCue, MEDIA, SOURCE, MACHINE,
    canonical, decode, integer, need, object_row, rows, string,
)
from xar_promo.render import RenderPlan, GeneratedTextFile, ass_burn_in_filter

SHOTS = SOURCE.parent / 'a02/RECUT-SHOTS.source-a02.json'
Relation = Literal['direct_evidence', 'context_only']


@dataclass(frozen=True)
class NativeShot:
    source: str
    first: int
    end: int
    player_actor: int | None
    army_owner: int | None
    relation: Relation
    label: str

    @property
    def frames(self) -> int:
        return self.end-self.first

    def wire(self) -> JsonObject:
        return {'kind':'native','source':self.source,'first_frame':self.first,
                'end_frame_exclusive':self.end,'player_actor_character_id':self.player_actor,
                'subject_army_owner_character_id':self.army_owner,
                'relation':self.relation,'label':self.label}


@dataclass(frozen=True)
class CardShot:
    frames: int

    def wire(self) -> JsonObject:
        return {'kind':'card','frames':self.frames}


Shot = NativeShot | CardShot


def parse_shot(value: JsonValue) -> Shot:
    r=object_row(value)
    if r.get('kind')=='card':
        object_row(value,{'kind','frames'})
        count=integer(r['frames']);need(count>0,'Positive real card duration')
        return CardShot(count)
    object_row(value,{'kind','source','first_frame','end_frame_exclusive',
                     'player_actor_character_id','subject_army_owner_character_id','relation','label'})
    need(r['kind']=='native','Single discriminated shot kind')
    first=integer(r['first_frame']);end=integer(r['end_frame_exclusive'])
    player=r['player_actor_character_id'];owner=r['subject_army_owner_character_id']
    actor=None if player is None else integer(player)
    army_owner=None if owner is None else integer(owner)
    relation=r['relation']
    need(0<=first<end and actor in (None,31254,33388) and army_owner in (None,31254,33388),
         'Real source range; player and subject owner remain separately nullable')
    need(relation in ('direct_evidence','context_only'),'Known exact/context distinction')
    if relation=='direct_evidence':
        exact: Relation='direct_evidence'
    else:
        exact='context_only'
    label=string(r['label']);need(bool(label) and '\\' not in label,'Safe explicit source label')
    return NativeShot(string(r['source']),first,end,actor,army_owner,exact,label)


@dataclass(frozen=True)
class ShotSource:
    key: str
    media: FilePin
    maximum_end: int
    player_actor: int | None
    army_owner: int | None
    evidence: tuple[FilePin,...]

    @staticmethod
    def parse(key: str,value: JsonValue) -> ShotSource:
        r=object_row(value,{'media','maximum_source_end_exclusive','player_actor_character_id',
                           'subject_army_owner_character_id','evidence'})
        end=integer(r['maximum_source_end_exclusive'])
        player=r['player_actor_character_id'];owner=r['subject_army_owner_character_id']
        actor=None if player is None else integer(player)
        army_owner=None if owner is None else integer(owner)
        need(end>0 and actor in (None,31254,33388) and army_owner in (None,31254,33388),
             'Exact bounded raw; explicit unknown player differs from subject owner')
        media=FilePin.parse(r['media']);need(Path(media.path).suffix.lower()=='.mkv','Actual raw MKV input')
        evidence=tuple(FilePin.parse(v) for v in rows(r['evidence']))
        need(bool(evidence),'Raw ranges have retained machine-specific source evidence')
        return ShotSource(key,media,end,actor,army_owner,evidence)


@dataclass(frozen=True)
class CueShots:
    cue_id: str
    frames: int
    shots: tuple[Shot,...]
    scope: str

    @staticmethod
    def parse(value: JsonValue,sources: dict[str,ShotSource]) -> CueShots:
        r=object_row(value,{'cue_id','frames','shots','claim_scope'})
        key=string(r['cue_id']);frames=integer(r['frames'])
        shots=tuple(parse_shot(v) for v in rows(r['shots']))
        need(frames>0 and bool(shots) and sum(s.frames for s in shots)==frames,'Exact whole cue frame clock')
        used: dict[str,list[tuple[int,int]]]={}
        for shot in shots:
            if isinstance(shot,CardShot):
                need(shot.frames<=360 or key=='N03-02' or not key.startswith(('N','C01','C06')),
                     'Rule cards at most twelve seconds; honest R05 exception')
            else:
                source=sources[shot.source]
                need(shot.end<=source.maximum_end and shot.player_actor==source.player_actor
                     and shot.army_owner==source.army_owner,'Actual source extent and separate identity roles')
                for a,b in used.get(shot.source,[]):
                    need(shot.end<=a or shot.first>=b,'No repeated real frame within a cue')
                used.setdefault(shot.source,[]).append((shot.first,shot.end))
        return CueShots(key,frames,shots,string(r['claim_scope']))

    def wire(self) -> JsonObject:
        return {'cue_id':self.cue_id,'frames':self.frames,'shots':[s.wire() for s in self.shots],
                'claim_scope':self.scope}


def load_shots() -> tuple[dict[str,ShotSource],dict[str,CueShots]]:
    r=object_row(decode(SHOTS.read_bytes()),{'schema','machine_id','observed_at_utc','sources','cues',
                                         'R05_actual_acceptance','human1x','signoff'})
    need(r['schema']=='xar.e04.recut.shots.v2' and r['machine_id']==MACHINE
         and r['R05_actual_acceptance'] is None and r['human1x'] is False and r['signoff'] is False,
         'Same-machine independent working-review shot plan')
    sources={k:ShotSource.parse(k,v) for k,v in object_row(r['sources']).items()}
    cues: dict[str,CueShots]={}
    for value in rows(r['cues']):
        cue=CueShots.parse(value,sources);need(cue.cue_id not in cues,'Unique cue sequence')
        cues[cue.cue_id]=cue
        need(canonical(cue.wire())==canonical(value),'Shot producer/consumer JSON roundtrip')
    need(len(cues)==62 and sum(c.frames for c in cues.values())==50138,'Complete original 62 cue clock')
    return sources,cues


@dataclass(frozen=True)
class NativePreviewSample:
    source: str
    source_first: int
    source_end: int
    source_frame: int
    local_frame: int
    position: str


def new_native_samples(sequence: CueShots) -> tuple[NativePreviewSample,...]:
    """Map each new/wider raw window's first/middle/last to actual edited cue frames."""
    accepted: dict[str,tuple[int,int]]={
        'B1':(420,1137),'B2':(420,1120),'R221':(0,990),'R194':(0,450),
        'R03':(0,1200),'R04':(0,900),'R11':(0,600),'R12':(0,1020),
        'R13':(0,900),'R196':(960,1560),'R08':(180,1051),'R204':(15,627),
    }
    groups: list[list[tuple[NativeShot,int]]]=[]
    local=0
    for shot in sequence.shots:
        if isinstance(shot,NativeShot):
            if groups and groups[-1][-1][0].source==shot.source and groups[-1][-1][0].end==shot.first:
                groups[-1].append((shot,local))
            else:
                groups.append([(shot,local)])
        local+=shot.frames
    result: list[NativePreviewSample]=[]
    for group in groups:
        first=group[0][0];end=group[-1][0].end
        old=accepted.get(first.source)
        if old is not None and old[0]<=first.first and end<=old[1]:
            continue
        for position,frame in (('first',first.first),('middle',(first.first+end-1)//2),('tail',end-1)):
            matches=[(part,base) for part,base in group if part.first<=frame<part.end]
            need(len(matches)==1,'Exact new native sample source-to-edited-frame projection')
            part,base=matches[0]
            result.append(NativePreviewSample(first.source,first.first,end,frame,
                                              base+frame-part.first,position))
    return tuple(result)


def ass_stamp(frames: int) -> str:
    seconds=frames/30
    return f'{int(seconds//3600)}:{int(seconds//60)%60:02d}:{seconds%60:05.2f}'


def labels_ass(content: str,sequence: CueShots) -> str:
    style=('Style: ShotLabel,Microsoft YaHei,24,&H006AA5CB,&H000000FF,&H00131821,&H001F2935,'
           '0,0,0,0,100,100,0,0,3,7,0,7,8,8,12,1\n')
    need('[Events]' in content and 'Style: ShotLabel,' not in content,'One shared shot-label style')
    result=content.replace('[Events]',style+'\n[Events]',1)
    position=0
    for shot in sequence.shots:
        if isinstance(shot,NativeShot):
            # The 192px editorial side margin sits outside the full game viewport/HUD.
            parts=shot.label.replace('｜','\n').replace(' · ','\n').splitlines()
            label=r'\N'.join(part[i:i+7] for part in parts for i in range(0,len(part),7))
            result+=f'Dialogue: 5,{ass_stamp(position)},{ass_stamp(position+shot.frames)},ShotLabel,source,0,0,0,,{{\\pos(12,28)\\q2}}{label}\n'
        position+=shot.frames
    return result


def apply_shots(cue: WorkingCue,sequence: CueShots,sources: dict[str,ShotSource]) -> WorkingCue:
    """Replace only picture construction, retaining exact voice and safe subtitle timing."""
    need(cue.cue_id==sequence.cue_id and cue.frames==sequence.frames,'Single unchanged narration clock')
    original=cue.plan.commands[0];argv=list(original.spec.argv)
    inputs=[argv[i+1] for i,v in enumerate(argv) if v=='-i']
    voice=[p for p in inputs if Path(p).suffix.lower() in ('.mp3','.wav')]
    need(len(voice)==1,'Single retained narration stem')
    card=[p for p in inputs if Path(p).suffix.lower() in ('.png','.jpg','.jpeg')]
    native_keys=tuple(dict.fromkeys(s.source for s in sequence.shots if isinstance(s,NativeShot)))
    new_argv=argv[:argv.index('-i')]
    # Image-input flags belong to the old still source, not the new first MKV input.
    for option in ('-loop','-framerate'):
        if option in new_argv:
            i=new_argv.index(option);del new_argv[i:i+2]
    for key in native_keys:
        new_argv.extend(('-i',sources[key].media.path))
    has_card=any(isinstance(s,CardShot) for s in sequence.shots)
    if has_card:
        need(len(card)==1,'Exactly one honest retained rule card')
        card_index=len(native_keys);new_argv.extend(('-loop','1','-framerate','30','-i',card[0]))
    else:
        card_index=-1
    voice_index=len(native_keys)+(1 if has_card else 0)
    new_argv.extend(('-i',voice[0]))
    graph_parts: list[str]=[]
    for index,shot in enumerate(sequence.shots):
        stream=native_keys.index(shot.source) if isinstance(shot,NativeShot) else card_index
        trim=(f'trim=start_frame={shot.first}:end_frame={shot.end}' if isinstance(shot,NativeShot)
              else f'trim=end_frame={shot.frames}')
        graph_parts.append(f'[{stream}:v]{trim},setpts=PTS-STARTPTS,'
            'scale=1536:864:force_original_aspect_ratio=decrease:flags=lanczos,'
            'pad=1920:1080:192:0:color=0x211813,setsar=1,fps=30,format=yuv420p'+f'[shot{index}]')
    joined=''.join(f'[shot{i}]' for i in range(len(sequence.shots)))
    caption=cue.plan.generated_files[0]
    graph_parts.append(joined+f'concat=n={len(sequence.shots)}:v=1:a=0,'
        'drawbox=x=0:y=864:w=iw:h=2:color=0xCBA56A:t=fill,'+ass_burn_in_filter(caption.path)+
        ',scale=out_range=tv:out_color_matrix=bt709,format=yuv420p,'
        'setparams=range=limited:color_primaries=bt709:color_trc=bt709:colorspace=bt709[v]')
    old_graph=argv[argv.index('-filter_complex')+1]
    voice_graph=old_graph[old_graph.index('[1:a]'):]
    need(voice_graph.endswith('[a]') and 'amix=' not in voice_graph and '[2:a]' not in voice_graph,
         'Reviewed single original voice graph')
    graph_parts.append(voice_graph.replace('[1:a]',f'[{voice_index}:a]',1))
    tail=argv[argv.index('-filter_complex')+2:]
    new_argv.extend(('-filter_complex',';'.join(graph_parts),*tail))
    ass=labels_ass(caption.content,sequence)
    plan=replace(cue.plan,commands=(replace(original,spec=replace(original.spec,argv=tuple(new_argv))),),
                 generated_files=(GeneratedTextFile(caption.path,ass),))
    native=sum(s.frames for s in sequence.shots if isinstance(s,NativeShot))
    evidence={**cue.evidence,'recut_sequence':sequence.wire(),'native_frames':native,
              'card_frames':cue.frames-native,'native_visual_credit':'original_speed_raw_viewport_only',
              'source_game_pixels_tinted':False,'exact_native_event_PTS':None}
    return replace(cue,plan=plan,evidence=evidence)
