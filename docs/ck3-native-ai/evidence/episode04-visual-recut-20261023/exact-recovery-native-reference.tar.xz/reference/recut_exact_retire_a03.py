"""Task-local Native retirement boundary for reviewed complete MP4 link groups."""
from __future__ import annotations
import ctypes
from ctypes import wintypes as W
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import sys
sys.path.insert(0, "C:/ck3-e04-resume-20261023-a01/capacity")
from inspect_bootstrap import Json, Obj, obj
from admit_metadata import MACHINE, now, pin, array, integer
from admit_media import write
from closed_allocation import K, Standard
from plan_two_wholes import candidate, OUT
sys.path.insert(0, "C:/ck3-e04-resume-20261020-a01/r08-r223-lossless-replacement-2200-a01")
import lossless_exact5 as safe

K.SetFileInformationByHandle.argtypes = [W.HANDLE, ctypes.c_int, ctypes.c_void_p, W.DWORD]
K.SetFileInformationByHandle.restype = W.BOOL
K.SetFileAttributesW.argtypes = [W.LPCWSTR, W.DWORD]
K.SetFileAttributesW.restype = W.BOOL

@dataclass(frozen=True)
class Group:
    names: tuple[Path, ...]
    attributes: int
    volume: str
    file_id: str
    logical: int
    allocated: int
    sha256: str
    mtime_ns: str

def text(value: Json) -> str:
    if not isinstance(value, str):
        raise ValueError("Exact string required")
    return value

def group(value: Json) -> Group:
    row = obj(value)
    names = tuple(Path(text(obj(a)["path"])) for a in array(row["aliases"]))
    attrs = {integer(obj(a)["attributes"]) for a in array(row["aliases"])}
    if len(names) not in (1, 2) or len(set(names)) != len(names) or integer(row["links"]) != len(names) or len(attrs) != 1 or not attrs <= {32, 33}:
        raise ValueError("Complete ordinary or readonly group required")
    volume, identity, sha = text(row["volume_serial"]), text(row["FileID128"]), text(row["sha256"])
    if any(not s.isdecimal() or str(int(s)) != s for s in (volume, identity)) or len(sha) != 64 or any(c not in "0123456789abcdef" for c in sha):
        raise ValueError("Canonical identity/SHA required")
    logical, allocated = integer(row["logical_bytes"]), integer(row["allocated_bytes"])
    mtimes = {text(obj(a)["mtime_ns"]) for a in array(row["aliases"])}
    if len(mtimes) != 1 or any(not v.isdecimal() or str(int(v)) != v for v in mtimes):
        raise ValueError("One canonical frozen group mtime required")
    if logical <= 0 or allocated <= 0:
        raise ValueError("Actual positive allocated file required")
    return Group(names, next(iter(attrs)), volume, identity, logical, allocated, sha, next(iter(mtimes)))

class ExactGroupHandles(safe.Handles):
    def __init__(self, selected: Group, remaining: int) -> None:
        super().__init__()
        self.selected = selected
        self.remaining = remaining

    def check(self, held: safe.Held) -> int:
        selected = self.selected
        if held.path not in selected.names or held.path.resolve(strict=True) != held.path:
            raise ValueError("Only exact selected alias allowed")
        if not held.path.is_absolute() or not held.path.is_file():
            raise ValueError("Absolute regular selected file required")
        for part in (held.path, *held.path.parents):
            if part.lstat().st_file_attributes & 0x400:
                raise ValueError("Original plain_path ancestor reparse guard")
        current = os.fstat(held.fd)
        # Preserve the original check against the snapshot captured by open_exact.
        frozen_identity = obj(held.identity.to_json())
        if set(frozen_identity) != {"volume_serial", "file_id", "bytes", "mtime_ns", "fstat_ctime_ns"}:
            raise ValueError("Exact retained Native identity wire contract required")
        if (str(current.st_dev), str(current.st_ino), current.st_size, str(current.st_mtime_ns), str(current.st_ctime_ns)) != (held.identity.volume_serial, held.identity.file_id, held.identity.bytes, held.identity.mtime_ns, text(frozen_identity["fstat_ctime_ns"])):
            raise ValueError("Original held identity generation changed")
        if str(current.st_mtime_ns) != selected.mtime_ns:
            raise ValueError("Frozen plan generation differs at open/check")
        pathinfo = held.path.stat(follow_symlinks=False)
        actual = (str(current.st_dev), str(current.st_ino), current.st_size, current.st_file_attributes)
        expected = (selected.volume, selected.file_id, selected.logical, selected.attributes)
        if actual != expected or (pathinfo.st_dev, pathinfo.st_ino, pathinfo.st_size, pathinfo.st_mtime_ns) != (current.st_dev, current.st_ino, current.st_size, current.st_mtime_ns) or pathinfo.st_file_attributes & 0x400:
            raise ValueError("Exact held generation/attributes changed")
        info = Standard()
        ok: object = K.GetFileInformationByHandleEx(held.handle, 1, ctypes.byref(info), ctypes.sizeof(info))
        if type(ok) is not int or ok == 0:
            raise ctypes.WinError(ctypes.get_last_error())
        if info.NumberOfLinks != self.remaining or info.Directory or info.DeletePending or info.AllocationSize != selected.allocated or info.EndOfFile != selected.logical:
            raise ValueError("Full group remaining links/allocation changed")
        final = ctypes.create_unicode_buffer(32768)
        count: object = K.GetFinalPathNameByHandleW(held.handle, final, len(final), 0)
        if type(count) is not int or not isinstance(count, int) or not 0 < count < len(final) or Path(final.value.removeprefix("\\\\?\\")) != held.path:
            raise ValueError("Native held FinalPath changed")
        return selected.allocated

    def dispose(self, held: safe.Held) -> None:
        self.check(held)
        # Reuse the original Native API; only readonly uses its documented Ex flag.
        data = W.DWORD(17 if self.selected.attributes == 33 else 1)
        kind = 21 if self.selected.attributes == 33 else 4
        ok: object = K.SetFileInformationByHandle(held.handle, kind, ctypes.byref(data), ctypes.sizeof(data))
        if type(ok) is not int or ok == 0:
            raise ctypes.WinError(ctypes.get_last_error())

def retire(selected: Group) -> Obj:
    removed: list[Json] = []
    for index, path in enumerate(selected.names):
        api = ExactGroupHandles(selected, len(selected.names) - index)
        held = api.open_exact(path, deletion=True)
        try:
            if safe.full_hash(held) != selected.sha256:
                raise ValueError("Fresh held full SHA changed")
            api.check(held)
            api.dispose(held)
        finally:
            held.close()
        try:
            path.lstat()
        except FileNotFoundError:
            removed.append(str(path))
        else:
            raise ValueError("Disposed original alias remains readable")
    return {"removed_original_names": removed, "original_availability": "deleted", "same_name_substitute_created": False, "actual_unique_allocated_bytes_recovered": selected.allocated, "volume_serial": selected.volume, "FileID128": selected.file_id, "sha256": selected.sha256}

def sentinel() -> None:
    root = OUT / "exact-boundary-sentinel-a03"
    root.mkdir()
    results: list[Json] = []
    for attributes in (32, 33):
        first, alias = root / (str(attributes) + "-one.bin"), root / (str(attributes) + "-two.bin")
        data = bytes(range(251)) * 32 + b"sentinel" * 20 + b"!"
        with first.open("xb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(first, alias)
        changed: object = K.SetFileAttributesW(str(first), attributes)
        if type(changed) is not int or changed == 0:
            raise ctypes.WinError(ctypes.get_last_error())
        raw = candidate(first, [first, alias])
        selected = group(raw)
        changed_plan = dict(raw)
        changed_plan["aliases"] = [{**obj(a), "mtime_ns": str(int(selected.mtime_ns) + 1)} for a in array(raw["aliases"])]
        wrong_generation = ExactGroupHandles(group(changed_plan), 2)
        try:
            stale = wrong_generation.open_exact(first, deletion=True)
        except ValueError:
            generation_rejected = True
        else:
            stale.close()
            raise ValueError("Changed frozen mtime was accepted")
        wrong = ExactGroupHandles(selected, 1)
        try:
            bad = wrong.open_exact(first, deletion=True)
        except ValueError:
            negative = True
        else:
            bad.close()
            raise ValueError("Unobserved link count was accepted")
        result = retire(selected)
        assert not first.exists() and not alias.exists()
        result.update(attributes=attributes, wrong_remaining_links_rejected=negative, frozen_generation_mismatch_rejected=generation_rejected, exact_source_sha256=hashlib.sha256(data).hexdigest(), new_sentinel_only=True)
        results.append(result)
    reference = write(OUT / "EXACT-BOUNDARY-SENTINEL-ACTUAL.actual-a03.json", {"schema": "xar.capacity.readonly-oldmedia-exact48-actual-recovery.v1", "machine_id": MACHINE, "observed_at_utc": now(), "sentinel_only": True, "actual_results": results, "formal_asset_deletions": 0, "Native_single_call_per_alias": True, "READONLY_attribute_never_cleared": True, "source": obj(pin(Path(__file__)))})
    print(json.dumps({"sentinel": reference}, ensure_ascii=True))

if __name__ == "__main__":
    if sys.argv[1:] != ["sentinel"]:
        raise ValueError("Only new sentinel permitted before Root source review")
    sentinel()
