"""One new argv check against the real adapter's parser; no adapter action."""
import argparse
import ast
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from build_card import make_card, RESEARCH


class Card(unittest.TestCase):
    def test_exact_production_parser_and_create_only_directory(self):
        repo = Path(__file__).resolve().parents[0]
        # Explicit test input, rather than guessing a repository from the scratch path.
        repo = Path(sys.argv[1]).resolve()
        head = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                              check=True, capture_output=True, text=True).stdout.strip()
        tree = ast.parse((repo / RESEARCH / "prepare_writer_admission.py").read_text(encoding="utf-8-sig"))
        function = next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == "main")
        statements = []
        for node in function.body:
            if isinstance(node, ast.Assign) and any(isinstance(x, ast.Name) and x.id == "args" for x in node.targets):
                break
            statements.append(node)
        namespace = {"argparse": argparse, "Path": Path, "__doc__": "Parser-only actual source test"}
        exec(compile(ast.Module(body=statements, type_ignores=[]), "actual-adapter-parser-only", "exec"), namespace)
        with tempfile.TemporaryDirectory(prefix="card-", dir=Path(__file__).parent) as scratch:
            root = Path(scratch)
            for name in ("gate.json", "cash.json", "before.json"):
                (root / name).write_text("{}", encoding="utf-8")
            config = {"repo": str(repo), "python": sys.executable, "source_head": head,
                      "build_dir": str(root), "machine_execution_gate": str(root / "gate.json"),
                      "cash_response": str(root / "cash.json"), "before_response": str(root / "before.json"),
                      "watch_output_root": str(root / "not-created-watch"), "timeout_ms": 30000,
                      "max_slot_hits": 128,
                      "expected": dict(pid=1, created=2, generation=3, window=4, epoch=5,
                                       character_id=6, revision=7, native_revision=8, date=9,
                                       episode="synthetic-parser-only", machine="synthetic-parser-only")}
            card = make_card(config)
            parsed = namespace["parser"].parse_args(card["prepare_argv"][4:])
            self.assertTrue(parsed.prepare_only)
            self.assertTrue(parsed.enable_ck3_12004_data_watch)
            self.assertEqual(parsed.expected_character_id, 6)
            self.assertEqual((parsed.timeout_ms, parsed.max_slot_hits), (30000, 128))
            self.assertFalse((root / "not-created-watch").exists())
            self.assertEqual(card["status"], "ARGV_ONLY_NOT_RUNTIME_ADMITTED")
            config["expected"]["generation"] = True
            with self.assertRaises(ValueError):
                make_card(config)
            config["expected"]["generation"] = 3
            (root / "not-created-watch").mkdir()
            with self.assertRaises(ValueError):
                make_card(config)


if __name__ == "__main__":
    unittest.main(argv=[sys.argv[0]], verbosity=2)
