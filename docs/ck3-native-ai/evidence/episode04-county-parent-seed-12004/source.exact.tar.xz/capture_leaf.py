"""Reuse held H leaf-CFG capture after, never instead of, intact runtime-entry refusal."""
from datetime import datetime,timezone
import hashlib,json,re,zipfile
from pathlib import Path
R=Path(__file__).resolve().parent;B=R.parent;MID='desktop-3fevhd2-1c74096080'
def need(x,m):
 if not x:raise RuntimeError(m)
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(n,x):
 with (R/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,indent=2);f.write('\n')
guard=json.loads((R/'EXACT-ENTRY-GUARD-STOP.actual-a01.json').read_bytes());probe=guard['entry_probe'];previous=[int(x,16) for x in probe['previous_runtime_row']];following=[int(x,16) for x in probe['next_runtime_row']]
need(guard['body_reads']==0 and guard['metadata_reads']<=512 and previous[1]<=0x28BFC50<following[0]==0x28BFD40,'No unsupported leaf gap')
held=B/'r04-or-nested-three-source-a01/completed-derivations.exact-a01.zip'
with zipfile.ZipFile(held) as z:original=z.read('read_H_leaf.py')
code=original.decode('utf-8')
for old,new in [('ENTRY=0x28BFD80','ENTRY=0x28BFC50'),("R/'RESEARCH-PLAN.proposed-a01.json'","R/'RESEARCH-PLAN.proposed-a02.json'"),('28BFD80','28BFC50'),('28BFE20','28BFD40'),("'H-","'GETTER-"),('H_runtime_metadata_fact','leaf_runtime_metadata_fact')]:code=code.replace(old,new)
code=re.sub(r'\b96\b','240',code);code=re.sub(r'\b160\b','240',code)
code=re.sub(r'(?<!\d)(?:96|160)B','240B',code)
for old,new in [('prefix96','prefix240'),('within96','within240')]:code=code.replace(old,new)
old="p['observation']['stop_condition']='Only named28BFC50 prefix240B, at most240B before known next runtime entry28BFD40 if a specific in-prefix branch requires tail. Save raw/ledger before decode; complete only with reachable instruction CFG closed byRET and no external jump. No callees/header/fullhash/installed/SDK/main/build. Combined authorized bodies+unwind remain<4096B.'"
new="p['observation']['stop_condition']='Only named28BFC50 leaf prefix[28BFC50,28BFD40)240B between verified noncovering runtime rows; metadata216B already read, no new metadata/unwind. Code<=1024B/meta<=512B total. Preserve exact-entry refusal. Complete only with closed reachableRET CFG and noCALL/external jump; otherwise stop, no extension/header/fullhash/installed/main/SDK/UI/build.'"
need(code.count(old)==1,'Held leaf stop seam changed '+repr(next(x for x in code.splitlines() if "['stop_condition']" in x)));code=code.replace(old,new)
old="p['leaf_runtime_metadata_fact']={'exact_runtime_function_entry':False,'next_runtime_entry':'28BFD40','maximum_named_prefix_bytes':240}"
new="p['leaf_runtime_metadata_fact']={'exact_runtime_function_entry':False,'previous_runtime_end':'28BFC47','next_runtime_entry':'28BFD40','maximum_named_prefix_bytes':240,'original_guard_stop':pin(R/'EXACT-ENTRY-GUARD-STOP.actual-a01.json'),'no_neighbor_unwind_used':True}"
need(code.count(old)==1,'Held leaf bounds seam changed');code=code.replace(old,new)
old="need(not missing and exits,'H CFG needs a specific bounded tail; do not auto-read extra')"
new="need(not missing and exits and not calls,'Named leaf CFG not closed orCALL present; stop without extension')"
need(code.count(old)==1,'Held CFG stop seam changed');code=code.replace(old,new)
code=code.replace("p['topic']='actual4-H28BFC50-leaf-prefix-append'","p['topic']='actual4-28BFC50-leaf-source-after-entry-guard'").replace("p['question']='Can the named H entry28BFC50 be closed from a bounded leaf prefix despite no exact runtime function row?'","p['question']='What native single-step Character does28BFC50 return inside its exact metadata gap, independently of adopted provider names?'")
write('LEAF-READER-DERIVATION.actual-a02.json',{'machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'held_reader':str(held)+'!read_H_leaf.py','held_bytes':len(original),'held_sha256':hashlib.sha256(original).hexdigest(),'derived_bytes':len(code.encode()),'derived_sha256':hashlib.sha256(code.encode()).hexdigest(),'contract_reused':'Existing named-window frozen-file/closedCFG leaf capture; exact runtime guard refusal preserved','correction':'A01 generic filename substitution stopped at missing plan filename before any newEXEread; A02 only substitutes quoted leaf-output prefix','new_code_window':['28BFC50','28BFD40'],'prior_metadata_bytes':216,'maximum_new_code_bytes':240,'neighbor_runtime_unwind_borrowed':False})
exec(compile(code,'<held-H-leaf-capture-single-getter-derivative>','exec'),globals())
write('source-28BFC50.function.json',{'machine_id':MID,'body':pin(R/'source-28BFC50.bin'),'asm':pin(R/'source-28BFC50.asm'),'window':pin(R/'source-28BFC50.prefix240.bin'),'begin':'28BFC50','reachable_end_exclusive':hex(end),'runtime_exact_entry':False,'unwind':None,'neighbor_runtime_rows':probe,'instruction_count':len(reached),'calls':calls,'reachable_RET_RVAs':[hex(x) for x in exits],'code_bytes_read':240,'prior_metadata_bytes':216,'no_external_body_followed':True})
print(json.dumps({'body':pin(R/'source-28BFC50.bin'),'actual_code_metadata_bytes':[240,216],'new_EXE_reads':1,'complete_leaf_CFG':True}))
