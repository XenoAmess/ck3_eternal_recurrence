"""One newly named source entry via the existing bounded reader and intact entry guard."""
from datetime import datetime,timezone
import hashlib,io,json,subprocess,sys,tarfile,zipfile
from pathlib import Path
R=Path(__file__).resolve().parent;B=R.parent;REPO=Path('D:/workspace/ck3_eternal_recurrence');MID='desktop-3fevhd2-1c74096080'
def need(x,m):
 if not x:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def write(n,x):
 with (R/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,indent=2);f.write('\n')
context=B/'r04-context-selector-source-a01/R04-CONTEXT-SOURCE.exact-a01.tar.gz'
base=B/'r04-first-or-directions-source-a01/R04-DIRECTIONS-APPEND.exact-a01.zip'
if sys.argv[1:]==['--prepare']:
 machine=subprocess.run([sys.executable,'-B','-X','utf8',str(REPO/'tools/ck3_live_run_id.py'),'machine'],capture_output=True,text=True,check=True).stdout.strip();need(machine==MID,'Machine mismatch')
 with tarfile.open(context,'r:gz') as tar:
  old=json.loads(tar.extractfile('CURRENT-IDENTITY-METADATA.actual-a01.json').read());caller=tar.extractfile('CONTEXT-SELECTOR-CONTRACT.proposed-a01.json').read()
 exe=Path(old['frozen_path']);s=exe.stat();current={'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'ino':s.st_ino,'dev':s.st_dev};need(current==old['current_frozen_stat'] and not exe.is_symlink(),'Own frozen metadata changed')
 write('CURRENT-IDENTITY-METADATA.actual-a01.json',{'machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'frozen_path':str(exe),'current_frozen_stat':current,'historical_exact_EXE_SHA':'98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518','historical_identity':pin(B/'frozen-game-12004/IDENTITY.actual.json'),'no_fullhash_header_installed_reads':True,'shared_pool_bytes':134217728,'new_lane_ceiling_bytes':16384})
 with (R/'CALLER-SELECTOR.exact.json').open('xb') as f:f.write(caller)
 plan={'schema':'xar.native-research-plan.v1','machine_id':MID,'topic':'actual4-native-parent-seed-getter-source','question':'What does original28BFC50(A) return to0FEC0 before candidate traversal, independently of adopted immediate_liege naming?','purpose':'engine-transition','build':{'version':'1.20.0.4','exe_sha256':old['historical_exact_EXE_SHA']},'observation':{'mode':'offline-only','actor_kind':'engine','owner_scope':'Static exact frozen bytes only; no current PID/run/HEAD freeze or runtime owner','identity_kind':'generation-id','identity_lifetime':'Character values per native invocation; frozen code exact-build only','producer_trigger':'not-applicable','producer':'Existing bounded source reader first probes exact runtime entry/unwind; at most one function code1024B/meta512B','caller':'0FEC0 calls28BFC50 withRCX=A and consumes fullRAX as initialseed, compareseed==A then loop/fallback','consumer':'Seed candidate consumed by original firstOR selector; no new actual OR samples','cache_lifetime':'No live cache produced; future fields bound to their original P/OR invocation','expected_signal':'Independent body fields/input/return, or explicit intact-guard stop; no provider-label substitution','zero_sample_meaning':'No actual calls observed; source cannot fill R197OR or physical positive','stop_condition':'Only28BFC50, code<=1024B, metadata includingunwind<=512B. Exact runtime guard remains intact; missing row is recorded before any leaf capture; no callee follow/fullhash/header/installed/main/SDK/UI/build','runtime_window_ref':None},'evidence':[{'id':'caller','layer':'source-contract','path':str(R/'CALLER-SELECTOR.exact.json'),'sha256':sha(caller),'exe_sha256':old['historical_exact_EXE_SHA'],'supports':'Held complete0FEC0 body proves exactseedcall and full pointer consumer independently of providername'}],'nodes':[{'id':'selector','label':'Original0FEC0 candidate selector'},{'id':'getter','label':'28BFC50 body unknown'},{'id':'seed','label':'Native seed Character pointer'}],'edges':[{'id':'native-call','from':'selector','to':'getter','label':'RCX=A -> fullRAX seed','status':'static-confirmed','evidence':['caller']},{'id':'getter-body','from':'getter','to':'seed','label':'Native body not yet held','status':'unknown','evidence':['caller'],'open_question':'Capture only exact bounded source, do not adopt label as proof'}],'cases':[{'id':'body-source','question':'New native body fields/return','status':'pending','evidence':['caller']},{'id':'actual-OR','question':'R197 actual OR / physical positive','status':'not-applicable','reason':'Offline source, no live sample','evidence':['caller']}]}
 write('RESEARCH-PLAN.proposed-a02.json',plan)
 argv=[sys.executable,'-B','-X','utf8',str(REPO/'tools/native_research_plan.py'),'check',str(R/'RESEARCH-PLAN.proposed-a02.json')];c=subprocess.run(argv,cwd=REPO,capture_output=True,text=True)
 write('STATIC-PLAN-CHECK.actual-a02.json',{'machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'argv':argv,'exit_code':c.returncode,'stdout':c.stdout,'stderr':c.stderr,'plan':pin(R/'RESEARCH-PLAN.proposed-a02.json'),'new_EXE_reads':0});need(c.returncode==0,'Ordinary source plan rejected')
 write('SOURCE-FIRST.actual-a01.json',{'machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'reader':pin(Path(__file__)),'plan':pin(R/'RESEARCH-PLAN.proposed-a02.json'),'check':pin(R/'STATIC-PLAN-CHECK.actual-a02.json'),'identity':pin(R/'CURRENT-IDENTITY-METADATA.actual-a01.json'),'code_limit':1024,'metadata_limit':512,'runtime_qualified':False})
 print('Pre-read ordinary check passed; no EXE reads')
elif sys.argv[1:]==['--read']:
 with zipfile.ZipFile(base) as z:inner=z.read('completed-acquisition.exact-a01.zip')
 with zipfile.ZipFile(io.BytesIO(inner)) as z:raw=z.read('bounded_read.py')
 code=raw.decode('utf-8');old='ENTRIES=(0x2C09280,0x2C09410)';need(code.count(old)==1,'Entry seam changed');code=code.replace(old,'ENTRIES=(0x28BFC50,)').replace('2048','1024')
 old="rt=row(lo);need(rt[0]==entry,'No exact runtime entry '+hex(entry))"
 new="rt=row(lo);previous=row(lo-1) if rt[0]!=entry and lo>0 else None;ledger['entry_probe']={'requested':hex(entry),'next_runtime_row':[hex(x) for x in rt],'previous_runtime_row':[hex(x) for x in previous] if previous else None};persist();need(rt[0]==entry,'No exact runtime entry '+hex(entry))"
 need(code.count(old)==1,'Guard seam changed');code=code.replace(old,new)
 write('READER-DERIVATION.actual-a01.json',{'machine_id':MID,'original_source':str(base)+'!completed-acquisition.exact-a01.zip!bounded_read.py','original_bytes':len(raw),'original_sha256':sha(raw),'derived_bytes':len(code.encode()),'derived_sha256':sha(code.encode()),'changes':['single namedentry','1024code cap','record neighboringmetadata before intact exactentry guard'],'exact_entry_guard_removed':False})
 try:exec(compile(code,'<existing-source-reader-single-getter>','exec'),globals())
 except RuntimeError as e:
  if not str(e).startswith('No exact runtime entry '):raise
  write('EXACT-ENTRY-GUARD-STOP.actual-a01.json',{'machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'error':str(e),'ledger':pin(R/'RAW-READ-LEDGER.actual-a01.json'),'entry_probe':ledger.get('entry_probe'),'body_reads':ledger['budget']['code'],'metadata_reads':ledger['budget']['metadata_unwind'],'guard_bypassed':False});print('Exact-entry guard stopped before body; inspect preserved metadata')
else:raise SystemExit('--prepare or --read required')
