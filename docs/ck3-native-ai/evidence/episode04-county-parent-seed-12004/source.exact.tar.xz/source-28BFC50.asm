; machine_id: desktop-3fevhd2-1c74096080
; bounded named leaf CFG, no exact .pdata row
028BFC50 48 8b 81 c0 01 00 00             mov      rax, qword ptr [rcx + 0x1c0]
028BFC57 48 8b 91 b8 01 00 00             mov      rdx, qword ptr [rcx + 0x1b8]
028BFC5E 48 85 c0                         test     rax, rax
028BFC61 74 1e                            je       0x28bfc81
028BFC63 48 8b 80 c0 01 00 00             mov      rax, qword ptr [rax + 0x1c0]
028BFC6A 48 8b 40 28                      mov      rax, qword ptr [rax + 0x28]
028BFC6E 81 78 1c 72 61 68 43             cmp      dword ptr [rax + 0x1c], 0x43686172
028BFC75 75 06                            jne      0x28bfc7d
028BFC77 83 78 18 ff                      cmp      dword ptr [rax + 0x18], -1
028BFC7B 75 48                            jne      0x28bfcc5
028BFC7D 48 8b c1                         mov      rax, rcx
028BFC80 c3                               ret      
028BFC81 48 85 d2                         test     rdx, rdx
028BFC84 74 38                            je       0x28bfcbe
028BFC86 48 8b 05 db 78 3a 03             mov      rax, qword ptr [rip + 0x33a78db]
028BFC8D 48 85 c0                         test     rax, rax
028BFC90 74 2c                            je       0x28bfcbe
028BFC92 44 8b 82 c8 00 00 00             mov      r8d, dword ptr [rdx + 0xc8]
028BFC99 41 8b c8                         mov      ecx, r8d
028BFC9C 81 e1 ff ff ff 00                and      ecx, 0xffffff
028BFCA2 3b 48 2c                         cmp      ecx, dword ptr [rax + 0x2c]
028BFCA5 73 17                            jae      0x28bfcbe
028BFCA7 48 8b 40 20                      mov      rax, qword ptr [rax + 0x20]
028BFCAB 48 03 c9                         add      rcx, rcx
028BFCAE 48 8b 44 c8 08                   mov      rax, qword ptr [rax + rcx*8 + 8]
028BFCB3 48 85 c0                         test     rax, rax
028BFCB6 74 06                            je       0x28bfcbe
028BFCB8 44 39 40 18                      cmp      dword ptr [rax + 0x18], r8d
028BFCBC 74 07                            je       0x28bfcc5
028BFCBE 48 8b 05 ab 78 3a 03             mov      rax, qword ptr [rip + 0x33a78ab]
028BFCC5 c3                               ret      
