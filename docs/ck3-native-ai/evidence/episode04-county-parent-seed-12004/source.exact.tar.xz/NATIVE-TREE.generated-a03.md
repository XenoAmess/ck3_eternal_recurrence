# Research plan: actual4-parent-seed-getter-source-closed

GENERATED from the supplied research plan; no native semantics are inferred.

Question: What independently held single-step Character does28BFC50 return to0FEC0, and how does it differ fromH?

```mermaid
flowchart TD
    n0["Original0FEC0 candidate selector"]
    n1["28BFC50 body unknown"]
    n2["Native seed Character pointer"]
    n0 -->|"native-call [static-confirmed] RCX=A -&gt; fullRAX seed"| n1
    n1 -->|"getter-body [static-confirmed] One parent step; context invalid returns input, noncontext failure returns globalfallback"| n2
```

| Edge | Declared status | Evidence IDs | Open question |
|---|---|---|---|
| native-call | static-confirmed | caller |  |
| getter-body | static-confirmed | getter-source |  |

| Observation design | Value |
|---|---|
| mode | offline-only |
| actor_kind | engine |
| owner_scope | Static exact frozen bytes only; no current PID/run/HEAD freeze or runtime owner |
| identity_kind | generation-id |
| identity_lifetime | Character values per native invocation; frozen code exact-build only |
| producer_trigger | not-applicable |
| producer | Existing bounded source reader first probes exact runtime entry/unwind; at most one function code1024B/meta512B |
| caller | 0FEC0 calls28BFC50 withRCX=A and consumes fullRAX as initialseed, compareseed==A then loop/fallback |
| consumer | Seed candidate consumed by original firstOR selector; no new actual OR samples |
| cache_lifetime | No live cache produced; future fields bound to their original P/OR invocation |
| expected_signal | Independent118B body held: RCX only, fullRAX pointer, no incomingRDX/closure use, noCALL/loop/write, no exactpdata or borrowed unwind |
| zero_sample_meaning | No actual calls observed; source cannot fill R197OR or physical positive |
| stop_condition | Only named28BFC50 leaf prefix[28BFC50,28BFD40)240B between verified noncovering runtime rows; metadata216B already read, no new metadata/unwind. Code&lt;=1024B/meta&lt;=512B total. Preserve exact-entry refusal. Complete only with closed reachableRET CFG and noCALL/external jump; otherwise stop, no extension/header/fullhash/installed/main/SDK/UI/build. |
| runtime_window_ref | None |

| Evidence ID | Declared layer | File | SHA-256 | Supports |
|---|---|---|---|---|
| caller | source-contract | C:\ck3-e04-resume-20261015-a01\r04-immediate-getter-source-a01\CALLER-SELECTOR.exact.json | 00a900509b64692d57da06076f231044777ef47761586ab0010832c9c327bb06 | Held complete0FEC0 body proves exactseedcall and full pointer consumer independently of providername |
| getter-source | source-contract | C:\ck3-e04-resume-20261015-a01\r04-immediate-getter-source-a01\IMMEDIATE-GETTER-CONTRACT.proposed-a01.json | 0f259c28a5f8dacfba8dede31b0ed200517d4f83ae62817e98939e582404282d | Full reachable118B native leaf CFG and input/field/return contract independently reviewed, not adopted from provider label |

Check result (file integrity and declarations only):

```json
{
  "schema": "xar.native-research-plan-check.v1",
  "result": "plan-consistent",
  "proof_layer": "record-structure-and-file-integrity",
  "semantic_correctness_verified": false,
  "live_execution_performed": false,
  "observation_plan_issues": [
    "offline-only plan does not define a live observation window",
    "the real producer trigger must be located before live sampling"
  ],
  "declared_edges_by_status": {
    "counter-policy": 0,
    "inference": 0,
    "live-confirmed": 0,
    "static-confirmed": 2,
    "unknown": 0
  },
  "enumerated_native_edges": 2,
  "declared_cases_by_status": {
    "pending": 0,
    "observed": 0,
    "not-applicable": 2
  },
  "checked_evidence_files": 2,
  "limitations": [
    "Evidence layers and conclusions are author declarations; hashes bind bytes, not their truth.",
    "Counts cover this enumerated graph only, not all CK3 branches.",
    "A consistent observation plan is not authorization to run or manipulate CK3."
  ],
  "plan_sha256": "7cd73886af22019c04660442cfcbed25ba5afa41e22b0a7603e56e2f897efb50"
}
```
