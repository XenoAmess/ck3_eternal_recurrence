import hashlib,io,json,lzma,tarfile
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parent
def need(x,m):
 if not x:raise RuntimeError(m)
obsolete=R/'seal_getter.py';oldraw=obsolete.read_bytes();parts={p.name:p.read_bytes() for p in R.iterdir() if p.is_file() and p!=obsolete}
parts['COMPLETED-PACK-PRODUCER.actual.json']=(json.dumps({'machine_id':'desktop-3fevhd2-1c74096080','omitted_completed_packager':{'name':obsolete.name,'bytes':len(oldraw),'sha256':hashlib.sha256(oldraw).hexdigest()},'reason':'Oversize unissued packaging attempt; disposable packaging derivative only. All native raw/ASM, read producers, exact ledgers/guards and source checks remain preserved.','prior_budget_gate':[16604,730]},separators=(',',':'))+'\n').encode()
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.USTAR_FORMAT) as tar:
 for n,b in sorted(parts.items()):
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b))
packed=lzma.compress(buf.getvalue(),preset=9|lzma.PRESET_EXTREME);out=R/'R04-PARENT-SEED-SOURCE.exact-a01.tar.xz'
receipt={'schema':'xar.e04.r04.seed-source.v1','machine_id':'desktop-3fevhd2-1c74096080','observed_at_utc':datetime.now(timezone.utc).isoformat(),'archive':{'file':out.name,'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest()},'R197_actual_OR':'unknown','R04_physical_positive':False}
rr=(json.dumps(receipt,separators=(',',':'))+'\n').encode();need(len(packed)+len(rr)<=16384,'16KiB gate '+str((len(packed),len(rr))))
with out.open('xb') as f:f.write(packed)
with tarfile.open(out,'r:xz') as tar:
 for n,b in parts.items():need(tar.extractfile(n).read()==b,'New portable exact readback '+n)
for p in list(R.iterdir()):
 if p.is_file() and p!=out:p.unlink()
with (R/'ROOT-DELIVERY.actual-a01.json').open('xb') as f:f.write(rr)
print(json.dumps({'total_bytes':len(packed)+len(rr),'archive_bytes':len(packed),'archive_sha256':hashlib.sha256(packed).hexdigest(),'delivery_bytes':len(rr),'delivery_sha256':hashlib.sha256(rr).hexdigest()}))
