; machine_id: desktop-3fevhd2-1c74096080
; actual1.20.0.4 98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518
02C09620 48 89 5c 24 08                   mov      qword ptr [rsp + 8], rbx
02C09625 48 89 74 24 10                   mov      qword ptr [rsp + 0x10], rsi
02C0962A 57                               push     rdi
02C0962B 48 83 ec 20                      sub      rsp, 0x20
02C0962F 8b 42 18                         mov      eax, dword ptr [rdx + 0x18]
02C09632 49 8b d8                         mov      rbx, r8
02C09635 48 8b fa                         mov      rdi, rdx
02C09638 48 8b f1                         mov      rsi, rcx
02C0963B 39 41 18                         cmp      dword ptr [rcx + 0x18], eax
02C0963E 0f 84 89 00 00 00                je       0x2c096cd
02C09644 e8 07 2c cb ff                   call     0x28bc250
02C09649 8b 40 20                         mov      eax, dword ptr [rax + 0x20]
02C0964C 83 f8 ff                         cmp      eax, -1
02C0964F 74 49                            je       0x2c0969a
02C09651 48 8b 0d 00 48 11 03             mov      rcx, qword ptr [rip + 0x3114800]
02C09658 48 85 c9                         test     rcx, rcx
02C0965B 74 23                            je       0x2c09680
02C0965D 8b d0                            mov      edx, eax
02C0965F 81 e2 ff ff ff 00                and      edx, 0xffffff
02C09665 3b 51 2c                         cmp      edx, dword ptr [rcx + 0x2c]
02C09668 73 16                            jae      0x2c09680
02C0966A 48 8b 49 20                      mov      rcx, qword ptr [rcx + 0x20]
02C0966E 48 03 d2                         add      rdx, rdx
02C09671 48 8b 4c d1 08                   mov      rcx, qword ptr [rcx + rdx*8 + 8]
02C09676 48 85 c9                         test     rcx, rcx
02C09679 74 05                            je       0x2c09680
02C0967B 39 41 08                         cmp      dword ptr [rcx + 8], eax
02C0967E 74 07                            je       0x2c09687
02C09680 48 8b 0d b9 47 11 03             mov      rcx, qword ptr [rip + 0x31147b9]
02C09687 80 b9 58 03 00 00 00             cmp      byte ptr [rcx + 0x358], 0
02C0968E 75 0a                            jne      0x2c0969a
02C09690 48 85 db                         test     rbx, rbx
02C09693 74 26                            je       0x2c096bb
02C09695 48 3b cb                         cmp      rcx, rbx
02C09698 74 21                            je       0x2c096bb
02C0969A 4c 8b c3                         mov      r8, rbx
02C0969D 48 8b d7                         mov      rdx, rdi
02C096A0 48 8b ce                         mov      rcx, rsi
02C096A3 e8 d8 fe ff ff                   call     0x2c09580
02C096A8 84 c0                            test     al, al
02C096AA 75 0f                            jne      0x2c096bb
02C096AC 48 8b d7                         mov      rdx, rdi
02C096AF 48 8b ce                         mov      rcx, rsi
02C096B2 e8 c9 00 00 00                   call     0x2c09780
02C096B7 84 c0                            test     al, al
02C096B9 74 12                            je       0x2c096cd
02C096BB b0 01                            mov      al, 1
02C096BD 48 8b 5c 24 30                   mov      rbx, qword ptr [rsp + 0x30]
02C096C2 48 8b 74 24 38                   mov      rsi, qword ptr [rsp + 0x38]
02C096C7 48 83 c4 20                      add      rsp, 0x20
02C096CB 5f                               pop      rdi
02C096CC c3                               ret      
02C096CD 48 8b 5c 24 30                   mov      rbx, qword ptr [rsp + 0x30]
02C096D2 32 c0                            xor      al, al
02C096D4 48 8b 74 24 38                   mov      rsi, qword ptr [rsp + 0x38]
02C096D9 48 83 c4 20                      add      rsp, 0x20
02C096DD 5f                               pop      rdi
02C096DE c3                               ret      
