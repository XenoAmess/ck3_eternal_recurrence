# Research plan: actual4-context-predicate-and-selector-source-closed

GENERATED from the supplied research plan; no native semantics are inferred.

Question: How do09360(context,A) and0FEC0(A,context) derive/filter/return the candidate used by09280?

```mermaid
flowchart TD
    n0["09280 initializes stack context"]
    n1["09360 context predicate unknown"]
    n2["0FEC0 candidate selector unknown"]
    n3["Selected native Character consumed by09280"]
    n4["28BFC50 seed getter body not read"]
    n5["2494B40 remains opaque inside heldD0"]
    n0 -->|"pred-call [static-confirmed] context address and A; original AL"| n1
    n0 -->|"select-call [static-confirmed] A and same context address; returnedRAX"| n2
    n1 -->|"pred-body [static-confirmed] Context B/F rereads, sameID orD0 true, otherwise pair gate AL"| n3
    n2 -->|"select-body [static-confirmed] Seed then upward candidates, test current after next computed, full pointer return or fallback"| n3
    n2 -. "seed-body-unknown [unknown] First candidate is original28BFC50(A) return" .-> n4
    n1 -. "M-still-unknown [unknown] HeldD0 uses2494B40 descriptor predicate" .-> n5
```

| Edge | Declared status | Evidence IDs | Open question |
|---|---|---|---|
| pred-call | static-confirmed | caller |  |
| select-call | static-confirmed | caller |  |
| pred-body | static-confirmed | predicate-source |  |
| select-body | static-confirmed | selector-source |  |
| seed-body-unknown | unknown | selector-source | Current round does not read seed getter body; adopted immediate_liege name alone is not independent source proof |
| M-still-unknown | unknown | predicate-source | This prior lower helper remains unexpanded; do not invent enemy/attacker/defender labels |

| Observation design | Value |
|---|---|
| mode | offline-only |
| actor_kind | engine |
| owner_scope | Static exact-build source only; no PID/run/native owner or game use |
| identity_kind | generation-id |
| identity_lifetime | Original A/B/F identities belong to their natural call/P TLS; frozen bytes persist only for this exact build |
| producer_trigger | not-applicable |
| producer | Metadata-bound read of named09360 and0FEC0 only, same frozen file/cached PE mapping; no new callee follows |
| caller | 09280 initializes context qwords B,F then09360(RCX=&amp;ctx,RDX=A); false calls0FEC0(RCX=A,RDX=&amp;samectx), R8 not reloaded |
| consumer | 09280 selects originalA or returnedCharacter then validates Character and pair gate; downstream firstOR AL still unobserved |
| cache_lifetime | No live cache produced; future data must expire with actual original parent invocation |
| expected_signal | Actual full176B and347B bodies held, no context stores in either; exact native field reads and return forms are confirmed, lower side effects not generalized as pure |
| zero_sample_meaning | No runtime samples collected; neither no candidates nor R197 ORfalse nor physical county-loss positive follows |
| stop_condition | Metadata first. At most09360 and0FEC0; code&lt;=2048B, metadata+unwind&lt;=512B total. If combined spans exceed code budget read only09360; any next unknown callee stays unexpanded. No fullhash/header/installed/main/SDK/desktop/build |
| runtime_window_ref | None |

| Evidence ID | Declared layer | File | SHA-256 | Supports |
|---|---|---|---|---|
| caller | source-contract | C:\ck3-e04-resume-20261015-a01\r04-context-selector-source-a01\CALLER-CONTEXT.exact-a02.json | 529359cb0c8bef1cfa56481d8ef056eba77403c1e8d2a9d64e7c2efe76e41570 | Complete09280 caller contract pins stack context initialization, original input ABI and candidate return consumption |
| predicate-source | source-contract | C:\ck3-e04-resume-20261015-a01\r04-context-selector-source-a01\CONTEXT-PREDICATE-CONTRACT.proposed-a01.json | d4bb5c672e0c8318ae7d357cd0d51bb1f5d6631f26bbb9033bcbfabd5c7423be | Complete newly held exact body and ABI/field/branch/return contract independently reviewed without following callees |
| selector-source | source-contract | C:\ck3-e04-resume-20261015-a01\r04-context-selector-source-a01\CONTEXT-SELECTOR-CONTRACT.proposed-a01.json | 00a900509b64692d57da06076f231044777ef47761586ab0010832c9c327bb06 | Complete newly held exact body and ABI/field/branch/return contract independently reviewed without following callees |

Check result (file integrity and declarations only):

```json
{
  "schema": "xar.native-research-plan-check.v1",
  "result": "plan-consistent",
  "proof_layer": "record-structure-and-file-integrity",
  "semantic_correctness_verified": false,
  "live_execution_performed": false,
  "observation_plan_issues": [
    "offline-only plan does not define a live observation window",
    "the real producer trigger must be located before live sampling"
  ],
  "declared_edges_by_status": {
    "counter-policy": 0,
    "inference": 0,
    "live-confirmed": 0,
    "static-confirmed": 4,
    "unknown": 2
  },
  "enumerated_native_edges": 6,
  "declared_cases_by_status": {
    "pending": 0,
    "observed": 0,
    "not-applicable": 2
  },
  "checked_evidence_files": 3,
  "limitations": [
    "Evidence layers and conclusions are author declarations; hashes bind bytes, not their truth.",
    "Counts cover this enumerated graph only, not all CK3 branches.",
    "A consistent observation plan is not authorization to run or manipulate CK3."
  ],
  "plan_sha256": "941ca636c93ab568a0dd9739eef1475093757319e2294e4f2a55c3caacd5a45c"
}
```
