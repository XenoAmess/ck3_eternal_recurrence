"""Seal actual new source in a compact exact tar.gz; never touch main or an image."""
from datetime import datetime,timezone
import gzip,hashlib,io,json,subprocess,sys,tarfile
from pathlib import Path
R=Path(__file__).resolve().parent;REPO=Path('D:/workspace/ck3_eternal_recurrence');MID='desktop-3fevhd2-1c74096080'
def need(x,m):
 if not x:raise RuntimeError(m)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pin(p):
 raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':sha(raw)}
def write(n,x):
 with (R/n).open('x',encoding='utf-8',newline='\n') as f:
  if isinstance(x,str):f.write(x)
  else:json.dump(x,f,indent=2);f.write('\n')
one=R/'CONTEXT-PREDICATE-CONTRACT.proposed-a01.json';two=R/'CONTEXT-SELECTOR-CONTRACT.proposed-a01.json';need(one.exists() and two.exists(),'Both independent source contracts required')
plan=json.loads((R/'RESEARCH-PLAN.proposed-a02.json').read_bytes());plan['topic']='actual4-context-predicate-and-selector-source-closed'
for ident,p in [('predicate-source',one),('selector-source',two)]:
 pp=pin(p);plan['evidence'].append({'id':ident,'layer':'source-contract','path':pp['path'],'sha256':pp['sha256'],'exe_sha256':plan['build']['exe_sha256'],'supports':'Complete newly held exact body and ABI/field/branch/return contract independently reviewed without following callees'})
for edge in plan['edges']:
 if edge['id'] in ['pred-body','select-body']:
  edge.update(status='static-confirmed',evidence=[{'pred-body':'predicate-source','select-body':'selector-source'}[edge['id']]])
  edge['label']={'pred-body':'Context B/F rereads, sameID orD0 true, otherwise pair gate AL','select-body':'Seed then upward candidates, test current after next computed, full pointer return or fallback'}[edge['id']];edge.pop('open_question',None)
plan['nodes'] += [{'id':'seed','label':'28BFC50 seed getter body not read'},{'id':'lowerM','label':'2494B40 remains opaque inside heldD0'}]
plan['edges'] += [{'id':'seed-body-unknown','from':'selector','to':'seed','label':'First candidate is original28BFC50(A) return','status':'unknown','evidence':['selector-source'],'open_question':'Current round does not read seed getter body; adopted immediate_liege name alone is not independent source proof'},{'id':'M-still-unknown','from':'predicate','to':'lowerM','label':'HeldD0 uses2494B40 descriptor predicate','status':'unknown','evidence':['predicate-source'],'open_question':'This prior lower helper remains unexpanded; do not invent enemy/attacker/defender labels'}]
plan['cases'][0].update(status='not-applicable',reason='Source-confirmed graph only; no natural calls or live values observed',evidence=['predicate-source','selector-source'])
plan['observation']['expected_signal']='Actual full176B and347B bodies held, no context stores in either; exact native field reads and return forms are confirmed, lower side effects not generalized as pure'
write('RESEARCH-PLAN.static-closed-a03.json',plan)
checks=[]
for args in [['check',str(R/'RESEARCH-PLAN.static-closed-a03.json')],['render',str(R/'RESEARCH-PLAN.static-closed-a03.json'),'--output',str(R/'NATIVE-TREE.generated-a03.md')]]:
 argv=[sys.executable,'-B','-X','utf8',str(REPO/'tools/native_research_plan.py'),*args];c=subprocess.run(argv,cwd=REPO,capture_output=True,text=True);checks.append({'argv':argv,'exit_code':c.returncode,'stdout':c.stdout,'stderr':c.stderr});need(c.returncode==0,'New source graph check/render failed')
write('STATIC-CHECK-RENDER.actual-a03.json',{'machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'plan':pin(R/'RESEARCH-PLAN.static-closed-a03.json'),'checks':checks,'for_observation':False,'runtime_qualified':False})
ledger=json.loads((R/'RAW-READ-LEDGER.actual-a01.json').read_bytes());need(ledger['complete'] and ledger['budget']=={'code':523,'metadata_unwind':332} and len(ledger['reads'])==31,'Actual read accounting changed')
functions={e:json.loads((R/f'source-{e}.function.json').read_bytes()) for e in ['2C09360','2C0FEC0']}
write('SOURCE-INDEX.actual-a01.json',{'schema':'xar.e04.r04.context-source-index.v1','machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'exe_sha256':plan['build']['exe_sha256'],'functions':{e:{'runtime_function':x['runtime_function'],'instruction_count':x['instruction_count'],'body':x['body'],'unwind':x['unwind'],'asm':pin(R/f'source-{e}.asm')} for e,x in functions.items()},'actual_read_accounting':{'code_bytes':523,'metadata_including32B_unwind':332,'total_EXE_bytes':855,'reads':31,'code_limit':2048,'metadata_limit':512,'functions_read':2,'callee_bodies_followed':0},'original_ledger_member':'RAW-READ-LEDGER.actual-a01.json','source_first_member':'SOURCE-FIRST.actual-a01.json','identity_member':'CURRENT-IDENTITY-METADATA.actual-a01.json','prior_failed_plan_check':'STATIC-PLAN-CHECK.actual-a01.json: caller reserialization SHA mismatch, no EXE read; corrected exact bytes A02 check0 before sole acquisition','new_body_gap':'28BFC50 seed getter body not read; adopted immediate_liege name is separate knowledge','prior_gap_still_unknown':'2494B40 inside heldD0; other oldG-helper unknowns untouched','R197_actual_OR':'unknown','R04_physical_positive':False,'main_rebase_inputs_modified':False})
readme='''# R04 context predicate / selector exact static source

machine_id: desktop-3fevhd2-1c74096080. Exact1.20.0.4 / Steam25734779 / EXE SHA98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518. Original observation times and own frozen-file metadata remain exact in the archive. Another machine may reuse source knowledge/code, not machine/runtime qualification.

Read SOURCE-INDEX.actual-a01.json, both CONTEXT-*-CONTRACT.proposed-a01.json and NATIVE-TREE.generated-a03.md. Raw body/ASM/runtime/unwind, all read-ledger rows, original admission failures, corrected checks and producer derivation are retained exact. The first plan failed before any EXE read because a reformatted caller file did not match its exact SHA; corrected A02 copied original bytes and passed before the only31-read acquisition.

09360(ctx,A) gets B fromctx[0] and F fromctx[1], not entryR8. Entry sameFullID orD0(B,A,F).ALtrue returnsALtrue, which makes09280 keep originalA. D0false then rereads B: a second sameID check returnsfalse; otherwise28BC250(B,A), fullWarID/registry/fallback,+358==0 and currentctx[1] null-or-W-pointer decideAL. There are no explicit context stores, and context address is not passed down. Do not freeze its multiple slot reads or call all lower functions pure.

0FEC0(A,ctx) gets seed from original28BFC50(A); seed==A returns globalCharacterFallback, notA. Each loop saves current, computes its next parent through context-parent or+1B8/+C8 completeID resolver, then tests current with context B/F. SameID orD0true accepts current; afterD0false it rereadsctx and uses a cached postD0F for the pair/War gate. Failure advances only when current!=next; fixedpoint failure returns globalfallback. FullRAX is a Character pointer; no visited/maxloop bound is present. No explicit context stores exist. New seed getter28BFC50 was not followed: its adopted immediate_liege name is separate from this independently held body.2494B40 inside heldD0 remains unknown; no business enemy/side labels are invented.

The concrete future read seam is natural09360 entry/return filtered by caller2C092AF (context pointer slots, candidate A ID, originalAL), and0FEC0 entry/return filtered by2C092C0 (A/context input and actual returnedCharacter ID/fallback status). Record actual before/after slots instead of treating originalB/F initialization as a fresh sample. These are proposed observation fields, not a current API or capability. DefaultOFF, only existing P/firstOR TLS with identity/caller binding, no extra predicate invocation. Outer OR observation remains09580/09780 at096A8/096B7.

R197 actual OR remains unknown; physical county-loss positive remains false. Static source/check/render does not grant a natural call, arrival, writer reduction, new runtime, video clean span or performance superiority. No main/SDK/desktop/game/build operation occurred. The original native path is studied first; no policy or implementation replacement is proposed without its independent comparison.
'''
write('README.md',readme)
parts={p.name:p.read_bytes() for p in R.iterdir() if p.is_file()};buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.USTAR_FORMAT) as tar:
 for name,raw in sorted(parts.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
packed=gzip.compress(buf.getvalue(),compresslevel=9,mtime=0)
delivery={'schema':'xar.e04.r04.context-source-delivery.v1','machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'archive':{'path':str(R/'R04-CONTEXT-SOURCE.exact-a01.tar.gz'),'bytes':len(packed),'sha256':sha(packed)},'read_first':['README.md','SOURCE-INDEX.actual-a01.json','CONTEXT-PREDICATE-CONTRACT.proposed-a01.json','CONTEXT-SELECTOR-CONTRACT.proposed-a01.json','NATIVE-TREE.generated-a03.md'],'actual_new_source':{'09360_body_bytes':176,'0FEC0_body_bytes':347,'code_bytes':523,'metadata_including_unwind_bytes':332,'unwind_payload_already_in_metadata_bytes':32,'read_count':31,'code_limit':2048,'metadata_limit':512,'no_callee_following':True},'new_ordinary_plan_check_render_exit_codes':[0,0],'pre_read_corrected_A02_check':0,'pre_read_failed_A01_check':2,'for_observation_qualified':False,'next_minimal_actual_input_seam':{'predicate':{'entry':'2C09360','native_caller_return':'2C092AF','inputs':'RCX=ctx*,RDX=candidateA; B/F fromctx[0]/ctx[1], not entryR8','return':'originalAL'},'selector':{'entry':'2C0FEC0','native_caller_return':'2C092C0','inputs':'RCX=A,RDX=ctx*','return':'fullRAX Character ID/fallback identity'},'proposed_only':True,'native_scope':'existing P/firstOR TLS; defaultOFF; natural original calls only; no extra predicates'},'unknowns':['28BFC50 seed-getter body not read; adopted name not independent proof','2494B40 prior helper remains unknown','Old G lower helper gaps unchanged','Actual native invocation values absent'],'R197_actual_OR':'unknown','R04_physical_positive':False,'new_runtime_PID_run_qualification':None,'main_SDK_desktop_game_build_operations':0,'storage':{'shared_pool_bytes':134217728,'parent_pool_time':'13:29','new_lane_ceiling_bytes':24576,'exact_tar_replaces_uncompressed_derivatives_after_verified_readback':True}}
receipt=(json.dumps(delivery,indent=2)+'\n').encode('utf-8');need(len(packed)+len(receipt)<=24576,'24KiB final budget stop '+str((len(packed),len(receipt))))
out=R/'R04-CONTEXT-SOURCE.exact-a01.tar.gz'
with out.open('xb') as f:f.write(packed)
with tarfile.open(out,'r:gz') as tar:
 for name,raw in parts.items():need(tar.extractfile(name).read()==raw,'Disk tar roundtrip '+name)
for name in parts:
 p=R/name;need(p.resolve().parent==R.resolve(),'Nonlocal cleanup');p.unlink()
with (R/'ROOT-DELIVERY.actual-a01.json').open('xb') as f:f.write(receipt)
print(json.dumps({'root_bytes':len(packed)+len(receipt),'archive_bytes':len(packed),'archive_sha256':sha(packed),'delivery_bytes':len(receipt),'delivery_sha256':sha(receipt),'new_check_render_exit_codes':[0,0],'actual_code_metadata_bytes':[523,332]}))
