; machine_id: desktop-3fevhd2-1c74096080
; exact runtime body 0x2c0fec0..0x2c1001b; no callee body read
02C0FEC0 48 89 5c 24 08                   mov      qword ptr [rsp + 8], rbx
02C0FEC5 48 89 74 24 10                   mov      qword ptr [rsp + 0x10], rsi
02C0FECA 48 89 7c 24 18                   mov      qword ptr [rsp + 0x18], rdi
02C0FECF 41 56                            push     r14
02C0FED1 48 83 ec 20                      sub      rsp, 0x20
02C0FED5 4c 8b f2                         mov      r14, rdx
02C0FED8 48 8b f9                         mov      rdi, rcx
02C0FEDB e8 70 fd ca ff                   call     0x28bfc50
02C0FEE0 48 8b d8                         mov      rbx, rax
02C0FEE3 48 3b f8                         cmp      rdi, rax
02C0FEE6 0f 84 0d 01 00 00                je       0x2c0fff9
02C0FEEC 0f 1f 40 00                      nop      dword ptr [rax]
02C0FEF0 48 8b 83 c0 01 00 00             mov      rax, qword ptr [rbx + 0x1c0]
02C0FEF7 48 8b fb                         mov      rdi, rbx
02C0FEFA 48 8b 8b b8 01 00 00             mov      rcx, qword ptr [rbx + 0x1b8]
02C0FF01 48 85 c0                         test     rax, rax
02C0FF04 74 1f                            je       0x2c0ff25
02C0FF06 48 8b 80 c0 01 00 00             mov      rax, qword ptr [rax + 0x1c0]
02C0FF0D 48 8b 48 28                      mov      rcx, qword ptr [rax + 0x28]
02C0FF11 81 79 1c 72 61 68 43             cmp      dword ptr [rcx + 0x1c], 0x43686172
02C0FF18 75 4b                            jne      0x2c0ff65
02C0FF1A 83 79 18 ff                      cmp      dword ptr [rcx + 0x18], -1
02C0FF1E 74 45                            je       0x2c0ff65
02C0FF20 48 8b d9                         mov      rbx, rcx
02C0FF23 eb 40                            jmp      0x2c0ff65
02C0FF25 48 85 c9                         test     rcx, rcx
02C0FF28 74 34                            je       0x2c0ff5e
02C0FF2A 48 8b 1d 37 76 05 03             mov      rbx, qword ptr [rip + 0x3057637]
02C0FF31 48 85 db                         test     rbx, rbx
02C0FF34 74 28                            je       0x2c0ff5e
02C0FF36 8b 91 c8 00 00 00                mov      edx, dword ptr [rcx + 0xc8]
02C0FF3C 8b c2                            mov      eax, edx
02C0FF3E 25 ff ff ff 00                   and      eax, 0xffffff
02C0FF43 3b 43 2c                         cmp      eax, dword ptr [rbx + 0x2c]
02C0FF46 73 16                            jae      0x2c0ff5e
02C0FF48 48 8b 5b 20                      mov      rbx, qword ptr [rbx + 0x20]
02C0FF4C 48 03 c0                         add      rax, rax
02C0FF4F 48 8b 5c c3 08                   mov      rbx, qword ptr [rbx + rax*8 + 8]
02C0FF54 48 85 db                         test     rbx, rbx
02C0FF57 74 05                            je       0x2c0ff5e
02C0FF59 39 53 18                         cmp      dword ptr [rbx + 0x18], edx
02C0FF5C 74 07                            je       0x2c0ff65
02C0FF5E 48 8b 1d 0b 76 05 03             mov      rbx, qword ptr [rip + 0x305760b]
02C0FF65 49 8b 0e                         mov      rcx, qword ptr [r14]
02C0FF68 8b 41 18                         mov      eax, dword ptr [rcx + 0x18]
02C0FF6B 39 47 18                         cmp      dword ptr [rdi + 0x18], eax
02C0FF6E 0f 84 a2 00 00 00                je       0x2c10016
02C0FF74 4d 8b 46 08                      mov      r8, qword ptr [r14 + 8]
02C0FF78 48 8b d7                         mov      rdx, rdi
02C0FF7B e8 50 91 ff ff                   call     0x2c090d0
02C0FF80 84 c0                            test     al, al
02C0FF82 0f 85 8e 00 00 00                jne      0x2c10016
02C0FF88 49 8b 0e                         mov      rcx, qword ptr [r14]
02C0FF8B 8b 47 18                         mov      eax, dword ptr [rdi + 0x18]
02C0FF8E 49 8b 76 08                      mov      rsi, qword ptr [r14 + 8]
02C0FF92 39 41 18                         cmp      dword ptr [rcx + 0x18], eax
02C0FF95 74 59                            je       0x2c0fff0
02C0FF97 48 8b d7                         mov      rdx, rdi
02C0FF9A e8 b1 c2 ca ff                   call     0x28bc250
02C0FF9F 8b 40 20                         mov      eax, dword ptr [rax + 0x20]
02C0FFA2 83 f8 ff                         cmp      eax, -1
02C0FFA5 74 49                            je       0x2c0fff0
02C0FFA7 48 8b 0d aa de 10 03             mov      rcx, qword ptr [rip + 0x310deaa]
02C0FFAE 48 85 c9                         test     rcx, rcx
02C0FFB1 74 23                            je       0x2c0ffd6
02C0FFB3 8b d0                            mov      edx, eax
02C0FFB5 81 e2 ff ff ff 00                and      edx, 0xffffff
02C0FFBB 3b 51 2c                         cmp      edx, dword ptr [rcx + 0x2c]
02C0FFBE 73 16                            jae      0x2c0ffd6
02C0FFC0 48 8b 49 20                      mov      rcx, qword ptr [rcx + 0x20]
02C0FFC4 48 03 d2                         add      rdx, rdx
02C0FFC7 48 8b 4c d1 08                   mov      rcx, qword ptr [rcx + rdx*8 + 8]
02C0FFCC 48 85 c9                         test     rcx, rcx
02C0FFCF 74 05                            je       0x2c0ffd6
02C0FFD1 39 41 08                         cmp      dword ptr [rcx + 8], eax
02C0FFD4 74 07                            je       0x2c0ffdd
02C0FFD6 48 8b 0d 63 de 10 03             mov      rcx, qword ptr [rip + 0x310de63]
02C0FFDD 80 b9 58 03 00 00 00             cmp      byte ptr [rcx + 0x358], 0
02C0FFE4 75 0a                            jne      0x2c0fff0
02C0FFE6 48 85 f6                         test     rsi, rsi
02C0FFE9 74 2b                            je       0x2c10016
02C0FFEB 48 3b ce                         cmp      rcx, rsi
02C0FFEE 74 26                            je       0x2c10016
02C0FFF0 48 3b fb                         cmp      rdi, rbx
02C0FFF3 0f 85 f7 fe ff ff                jne      0x2c0fef0
02C0FFF9 48 8b 05 70 75 05 03             mov      rax, qword ptr [rip + 0x3057570]
02C10000 48 8b 5c 24 30                   mov      rbx, qword ptr [rsp + 0x30]
02C10005 48 8b 74 24 38                   mov      rsi, qword ptr [rsp + 0x38]
02C1000A 48 8b 7c 24 40                   mov      rdi, qword ptr [rsp + 0x40]
02C1000F 48 83 c4 20                      add      rsp, 0x20
02C10013 41 5e                            pop      r14
02C10015 c3                               ret      
02C10016 48 8b c7                         mov      rax, rdi
02C10019 eb e5                            jmp      0x2c10000
