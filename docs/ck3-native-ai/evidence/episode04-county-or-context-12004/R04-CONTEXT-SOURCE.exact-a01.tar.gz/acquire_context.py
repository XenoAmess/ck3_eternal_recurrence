"""Reuse the held bounded reader, with only two newly authorized context entries."""
from datetime import datetime,timezone
import hashlib,io,json,shutil,subprocess,sys,zipfile
from pathlib import Path
R=Path(__file__).resolve().parent;B=R.parent;REPO=Path('D:/workspace/ck3_eternal_recurrence');MID='desktop-3fevhd2-1c74096080'
def need(x,m):
 if not x:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def write(n,x):
 with (R/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,indent=2);f.write('\n')
def nested(archive,inner,member):
 with zipfile.ZipFile(archive) as z:raw=z.read(inner)
 with zipfile.ZipFile(io.BytesIO(raw)) as z:return z.read(member)
base=B/'r04-first-or-directions-source-a01/R04-DIRECTIONS-APPEND.exact-a01.zip'
if sys.argv[1:]==['--prepare']:
 machine=subprocess.run([sys.executable,'-B','-X','utf8',str(REPO/'tools/ck3_live_run_id.py'),'machine'],capture_output=True,text=True,check=True).stdout.strip();need(machine==MID,'Machine mismatch')
 old=json.loads(nested(base,'completed-acquisition.exact-a01.zip','CURRENT-IDENTITY-METADATA.actual-a01.json'));exe=Path(old['frozen_path']);s=exe.stat();actual={'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'ino':s.st_ino,'dev':s.st_dev};need(actual==old['current_frozen_stat'],'Frozen own metadata changed');need(not exe.is_symlink(),'Frozen symlink')
 identity={'machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'frozen_path':str(exe),'current_frozen_stat':actual,'historical_identity':pin(B/'frozen-game-12004/IDENTITY.actual.json'),'historical_exact_EXE_SHA':'98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518','no_fullhash_header_installed_EXE_reads':True,'shared_pool':{'bytes':134217728,'parent_pool_observation':'13:29 parent-owned pool; not a new ledger','new_lane_ceiling_bytes':24576,'C_free_bytes':shutil.disk_usage(R).free,'policy':pin(REPO/'docs/storage-retention-policy.json')}}
 write('CURRENT-IDENTITY-METADATA.actual-a01.json',identity)
 caller=B/'r04-first-or-directions-source-a01/R04-DIRECTIONS-APPEND.exact-a01.zip'
 with zipfile.ZipFile(caller) as z:contract=z.read('FIRST-DIRECTION-CONTRACT.proposed-a01.json')
 write('CALLER-CONTEXT.exact.json',json.loads(contract))
 plan={'schema':'xar.native-research-plan.v1','machine_id':MID,'topic':'actual4-first-OR-context-selector-source','question':'How do09360(context,A) and0FEC0(A,context) derive/filter/return the candidate used by09280?','purpose':'engine-transition','build':{'version':'1.20.0.4','exe_sha256':identity['historical_exact_EXE_SHA']},'observation':{'mode':'offline-only','actor_kind':'engine','owner_scope':'Static exact-build source only; no PID/run/native owner or game use','identity_kind':'generation-id','identity_lifetime':'Original A/B/F identities belong to their natural call/P TLS; frozen bytes persist only for this exact build','producer_trigger':'not-applicable','producer':'Metadata-bound read of named09360 and0FEC0 only, same frozen file/cached PE mapping; no new callee follows','caller':'09280 initializes context qwords B,F then09360(RCX=&ctx,RDX=A); false calls0FEC0(RCX=A,RDX=&samectx), R8 not reloaded','consumer':'09280 selects originalA or returnedCharacter then validates Character and pair gate; downstream firstOR AL still unobserved','cache_lifetime':'No live cache produced; future data must expire with actual original parent invocation','expected_signal':'Exact body source establishes context reads/writes, candidate source, cheap filters and true return form, leaving new helper meanings unknown','zero_sample_meaning':'No runtime samples collected; neither no candidates nor R197 ORfalse nor physical county-loss positive follows','stop_condition':'Metadata first. At most09360 and0FEC0; code<=2048B, metadata+unwind<=512B total. If combined spans exceed code budget read only09360; any next unknown callee stays unexpanded. No fullhash/header/installed/main/SDK/desktop/build','runtime_window_ref':None},'evidence':[{'id':'caller','layer':'source-contract','path':str(R/'CALLER-CONTEXT.exact.json'),'sha256':sha(contract),'exe_sha256':identity['historical_exact_EXE_SHA'],'supports':'Complete09280 caller contract pins stack context initialization, original input ABI and candidate return consumption'}],'nodes':[{'id':'caller','label':'09280 initializes stack context'},{'id':'predicate','label':'09360 context predicate unknown'},{'id':'selector','label':'0FEC0 candidate selector unknown'},{'id':'candidate','label':'Selected native Character consumed by09280'}],'edges':[{'id':'pred-call','from':'caller','to':'predicate','label':'context address and A; original AL','status':'static-confirmed','evidence':['caller']},{'id':'select-call','from':'caller','to':'selector','label':'A and same context address; returnedRAX','status':'static-confirmed','evidence':['caller']},{'id':'pred-body','from':'predicate','to':'candidate','label':'Body not held yet','status':'unknown','evidence':['caller'],'open_question':'Read only newly named body within authorized bounds'},{'id':'select-body','from':'selector','to':'candidate','label':'Body not held yet','status':'unknown','evidence':['caller'],'open_question':'Metadata decides whether code budget allows body'}],'cases':[{'id':'static-source','question':'Native candidate/filters/return source','status':'pending','evidence':['caller']},{'id':'R197-actual','question':'R197 actual OR / physical positive','status':'not-applicable','reason':'Offline source only, no actual call or writer observation','evidence':['caller']}]}
 write('RESEARCH-PLAN.proposed-a01.json',plan)
 argv=[sys.executable,'-B','-X','utf8',str(REPO/'tools/native_research_plan.py'),'check',str(R/'RESEARCH-PLAN.proposed-a01.json')];c=subprocess.run(argv,cwd=REPO,capture_output=True,text=True)
 write('STATIC-PLAN-CHECK.actual-a01.json',{'machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'argv':argv,'exit_code':c.returncode,'stdout':c.stdout,'stderr':c.stderr,'plan':pin(R/'RESEARCH-PLAN.proposed-a01.json'),'vanilla_first_contract':pin(REPO/'docs/ck3-native-ai/vanilla-first-implementation-prompt.md'),'new_EXE_reads':0});need(c.returncode==0,'Ordinary source plan failed')
 write('SOURCE-FIRST.actual-a01.json',{'machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'plan':pin(R/'RESEARCH-PLAN.proposed-a01.json'),'check':pin(R/'STATIC-PLAN-CHECK.actual-a01.json'),'reader':pin(Path(__file__)),'identity':pin(R/'CURRENT-IDENTITY-METADATA.actual-a01.json'),'new_code_limit':2048,'metadata_unwind_limit':512,'maximum_functions':2,'if_overcombined_code':'only09360','runtime_qualified':False})
 print('Source plan ordinary check passed; no EXE read')
elif sys.argv[1:]==['--repair-a02']:
 with zipfile.ZipFile(base) as z:contract=z.read('FIRST-DIRECTION-CONTRACT.proposed-a01.json')
 with (R/'CALLER-CONTEXT.exact-a02.json').open('xb') as f:f.write(contract)
 plan=json.loads((R/'RESEARCH-PLAN.proposed-a01.json').read_bytes());plan['evidence'][0].update(path=str(R/'CALLER-CONTEXT.exact-a02.json'),sha256=sha(contract))
 write('RESEARCH-PLAN.proposed-a02.json',plan)
 argv=[sys.executable,'-B','-X','utf8',str(REPO/'tools/native_research_plan.py'),'check',str(R/'RESEARCH-PLAN.proposed-a02.json')];c=subprocess.run(argv,cwd=REPO,capture_output=True,text=True)
 write('STATIC-PLAN-CHECK.actual-a02.json',{'machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'argv':argv,'exit_code':c.returncode,'stdout':c.stdout,'stderr':c.stderr,'plan':pin(R/'RESEARCH-PLAN.proposed-a02.json'),'correction':'Preserve exact original caller bytes; A01 reserialization had a different SHA, before any EXE read','prior_failed_check':pin(R/'STATIC-PLAN-CHECK.actual-a01.json'),'new_EXE_reads':0});need(c.returncode==0,'Exact-source corrected plan failed')
 write('SOURCE-FIRST.actual-a01.json',{'machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'plan':pin(R/'RESEARCH-PLAN.proposed-a02.json'),'check':pin(R/'STATIC-PLAN-CHECK.actual-a02.json'),'reader':pin(Path(__file__)),'identity':pin(R/'CURRENT-IDENTITY-METADATA.actual-a01.json'),'new_code_limit':2048,'metadata_unwind_limit':512,'maximum_functions':2,'if_overcombined_code':'only09360','runtime_qualified':False})
 print('Exact-source corrected ordinary check passed; no EXE read')
elif sys.argv[1:]==['--read']:
 raw=nested(base,'completed-acquisition.exact-a01.zip','bounded_read.py');code=raw.decode('utf-8')
 replacements=[('ENTRIES=(0x2C09280,0x2C09410)','ENTRIES=(0x2C09360,0x2C0FEC0)'),('for e in ENTRIES]','for e in rows]')]
 for old,new in replacements:need(code.count(old)==1,'Held reader seam changed '+old);code=code.replace(old,new)
 old="rt=row(lo);need(rt[0]==entry,'No exact runtime entry '+hex(entry));need(0<rt[1]-entry<=2048,'Span stop before code '+hex(entry))"
 new="""rt=row(lo);need(rt[0]==entry,'No exact runtime entry '+hex(entry))
   if entry==0x2C0FEC0 and sum(v[1][1]-e for e,v in rows.items())+rt[1]-entry>2048:
    ledger['second_body_stopped']={'entry':hex(entry),'runtime_row':[hex(x) for x in rt],'body_bytes':rt[1]-entry,'reason':'Combined code span exceeds2048; only09360 authorized fallback'};persist();break
   need(0<rt[1]-entry<=2048,'Span stop before code '+hex(entry))"""
 need(code.count(old)==1,'Held extent seam changed');code=code.replace(old,new)
 write('READER-DERIVATION.actual-a01.json',{'machine_id':MID,'held_source':str(base)+'!completed-acquisition.exact-a01.zip!bounded_read.py','held_source_bytes':len(raw),'held_source_sha256':sha(raw),'derived_source_bytes':len(code.encode()),'derived_source_sha256':sha(code.encode()),'bounded_seams':['two named entry constants','ordinary checked plan path','metadata-only combined-code fallback to09360','summary lists only selected rows'],'no_extra_game_or_EXE_tools':True})
 exec(compile(code,'<held-bounded-reader-context-derivative>','exec'),globals())
else:raise SystemExit('--prepare or --read required')
