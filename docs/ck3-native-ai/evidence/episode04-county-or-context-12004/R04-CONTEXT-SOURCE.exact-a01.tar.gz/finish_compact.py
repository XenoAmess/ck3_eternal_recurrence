import gzip,hashlib,io,json,tarfile
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parent
def need(x,m):
 if not x:raise RuntimeError(m)
parts={p.name:p.read_bytes() for p in R.iterdir() if p.is_file()};buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.USTAR_FORMAT) as tar:
 for name,raw in sorted(parts.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
packed=gzip.compress(buf.getvalue(),compresslevel=9,mtime=0);out=R/'R04-CONTEXT-SOURCE.exact-a01.tar.gz'
receipt={'schema':'xar.e04.r04.context-source-final.v1','machine_id':'desktop-3fevhd2-1c74096080','observed_at_utc':datetime.now(timezone.utc).isoformat(),'archive':{'path':str(out),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest()},'read_first':['README.md','SOURCE-INDEX.actual-a01.json'],'code_metadata_bytes':[523,332],'reads':31,'new_check_render_exit_codes':[0,0],'R197_actual_OR':'unknown','R04_physical_positive':False,'new_runtime':None,'main_modified':False,'ceiling_bytes':24576,'prior_pack_size_gate_rejected':[23053,2252],'no_check_or_EXE_rerun':True}
rawreceipt=(json.dumps(receipt,separators=(',',':'))+'\n').encode();need(len(packed)+len(rawreceipt)<=24576,'24KiB budget '+str((len(packed),len(rawreceipt))))
with out.open('xb') as f:f.write(packed)
with tarfile.open(out,'r:gz') as tar:
 for name,raw in parts.items():need(tar.extractfile(name).read()==raw,'New pack exact portable readback '+name)
for name in parts:
 p=R/name;need(p.resolve().parent==R.resolve(),'Outside cleanup');p.unlink()
with (R/'ROOT-DELIVERY.actual-a01.json').open('xb') as f:f.write(rawreceipt)
print(json.dumps({'total_bytes':len(packed)+len(rawreceipt),'archive_bytes':len(packed),'archive_sha256':hashlib.sha256(packed).hexdigest(),'delivery_bytes':len(rawreceipt),'delivery_sha256':hashlib.sha256(rawreceipt).hexdigest()}))
