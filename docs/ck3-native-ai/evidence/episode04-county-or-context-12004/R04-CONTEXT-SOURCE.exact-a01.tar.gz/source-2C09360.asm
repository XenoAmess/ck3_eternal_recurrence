; machine_id: desktop-3fevhd2-1c74096080
; exact runtime body 0x2c09360..0x2c09410; no callee body read
02C09360 48 89 5c 24 08                   mov      qword ptr [rsp + 8], rbx
02C09365 57                               push     rdi
02C09366 48 83 ec 20                      sub      rsp, 0x20
02C0936A 48 8b d9                         mov      rbx, rcx
02C0936D 48 8b fa                         mov      rdi, rdx
02C09370 48 8b 09                         mov      rcx, qword ptr [rcx]
02C09373 8b 41 18                         mov      eax, dword ptr [rcx + 0x18]
02C09376 39 42 18                         cmp      dword ptr [rdx + 0x18], eax
02C09379 0f 84 84 00 00 00                je       0x2c09403
02C0937F 4c 8b 43 08                      mov      r8, qword ptr [rbx + 8]
02C09383 e8 48 fd ff ff                   call     0x2c090d0
02C09388 84 c0                            test     al, al
02C0938A 75 77                            jne      0x2c09403
02C0938C 48 8b 0b                         mov      rcx, qword ptr [rbx]
02C0938F 8b 47 18                         mov      eax, dword ptr [rdi + 0x18]
02C09392 39 41 18                         cmp      dword ptr [rcx + 0x18], eax
02C09395 75 0d                            jne      0x2c093a4
02C09397 32 c0                            xor      al, al
02C09399 48 8b 5c 24 30                   mov      rbx, qword ptr [rsp + 0x30]
02C0939E 48 83 c4 20                      add      rsp, 0x20
02C093A2 5f                               pop      rdi
02C093A3 c3                               ret      
02C093A4 48 8b d7                         mov      rdx, rdi
02C093A7 e8 a4 2e cb ff                   call     0x28bc250
02C093AC 8b 40 20                         mov      eax, dword ptr [rax + 0x20]
02C093AF 83 f8 ff                         cmp      eax, -1
02C093B2 74 e3                            je       0x2c09397
02C093B4 4c 8b 05 9d 4a 11 03             mov      r8, qword ptr [rip + 0x3114a9d]
02C093BB 4d 85 c0                         test     r8, r8
02C093BE 74 26                            je       0x2c093e6
02C093C0 8b c8                            mov      ecx, eax
02C093C2 81 e1 ff ff ff 00                and      ecx, 0xffffff
02C093C8 41 3b 48 2c                      cmp      ecx, dword ptr [r8 + 0x2c]
02C093CC 73 18                            jae      0x2c093e6
02C093CE 8b d1                            mov      edx, ecx
02C093D0 49 8b 48 20                      mov      rcx, qword ptr [r8 + 0x20]
02C093D4 48 03 d2                         add      rdx, rdx
02C093D7 48 8b 4c d1 08                   mov      rcx, qword ptr [rcx + rdx*8 + 8]
02C093DC 48 85 c9                         test     rcx, rcx
02C093DF 74 05                            je       0x2c093e6
02C093E1 39 41 08                         cmp      dword ptr [rcx + 8], eax
02C093E4 74 07                            je       0x2c093ed
02C093E6 48 8b 0d 53 4a 11 03             mov      rcx, qword ptr [rip + 0x3114a53]
02C093ED 80 b9 58 03 00 00 00             cmp      byte ptr [rcx + 0x358], 0
02C093F4 75 a1                            jne      0x2c09397
02C093F6 48 83 7b 08 00                   cmp      qword ptr [rbx + 8], 0
02C093FB 74 06                            je       0x2c09403
02C093FD 48 3b 4b 08                      cmp      rcx, qword ptr [rbx + 8]
02C09401 75 94                            jne      0x2c09397
02C09403 48 8b 5c 24 30                   mov      rbx, qword ptr [rsp + 0x30]
02C09408 b0 01                            mov      al, 1
02C0940A 48 83 c4 20                      add      rsp, 0x20
02C0940E 5f                               pop      rdi
02C0940F c3                               ret      
