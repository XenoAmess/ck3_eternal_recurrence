# Research plan: actual4-first-OR-directions-source-closed

GENERATED from the supplied research plan; no native semantics are inferred.

Question: What do exact2C09280 and2C09410 do with A/B/F on all four known first-OR directional calls?

```mermaid
flowchart TD
    n0["First OR original09580"]
    n1["Directional alternative09280"]
    n2["Directional alternative09410"]
    n3["Bounded source semantics"]
    n4["R197 actual OR unknown"]
    n5["2C09360 stack-context predicate unknown"]
    n6["2C0FEC0 stack-context selector unknown"]
    n7["2494B40 descriptor predicate remains unknown"]
    n0 -->|"call09280 [static-confirmed] A B F then B A F"| n1
    n0 -->|"call09410 [static-confirmed] After09280 false A B F then B A F"| n2
    n1 -->|"body09280 [static-confirmed] Context selector then Character validity/difference then pair War gate"| n3
    n2 -->|"body09410 [static-confirmed] Priority descriptor ID -&gt; Character resolver -&gt;09280 C B null"| n3
    n1 -. "ctx-test-unknown [unknown] RCX=&amp;initial B F context RDX=A; AL chooses keepA" .-> n5
    n1 -. "ctx-select-unknown [unknown] If testfalse A and same context address; use returned pointer" .-> n6
    n2 -. "M-unknown [unknown] A membership-like test selects28C or288 field" .-> n7
    n2 -->|"nested-call-known [static-confirmed] Natural09280 C B null at caller09534"| n1
```

| Edge | Declared status | Evidence IDs | Open question |
|---|---|---|---|
| call09280 | static-confirmed | caller-source |  |
| call09410 | static-confirmed | caller-source |  |
| body09280 | static-confirmed | direction-one-source |  |
| body09410 | static-confirmed | direction-two-source |  |
| ctx-test-unknown | unknown | direction-one-source | Body not authorized/read; context side effects and semantics unknown |
| ctx-select-unknown | unknown | direction-one-source | Body not authorized/read; cannot assert context still initial B F |
| M-unknown | unknown | direction-two-source | Prior2494B40 remains unexpanded; no attacker/defender labels |
| nested-call-known | static-confirmed | direction-two-source |  |

| Observation design | Value |
|---|---|
| mode | offline-only |
| actor_kind | engine |
| owner_scope | Static source only; no PID/run/runtime native owner |
| identity_kind | generation-id |
| identity_lifetime | Native Character full IDs/opaque F are per original invocation; frozen bytes exact-build only |
| producer_trigger | not-applicable |
| producer | Single reader uses cached PE mapping and named exact runtime entries; code&lt;=2048B and metadata+unwind&lt;=512B |
| caller | 2C09580 passes(A,B,F)/(B,A,F) to09280 then09410, explicitly reloads originalF before each CALL |
| consumer | Original first OR AL consumed at2C096A8 by2C09620; this append observes no actual calls |
| cache_lifetime | No live cache produced; future optional fields expire with their exact parent P TLS invocation |
| expected_signal | Complete220B/360B bodies and exact native field/helper/AL contracts obtained; actual R197 observations remain absent |
| zero_sample_meaning | Static bytes do not observe R197 OR values, natural calls or county writer positive; no samples is unknown not false/count0 |
| stop_condition | Only exact entries2C09280/2C09410; code&lt;=2048B and metadata+unwind&lt;=512B total. Stop before any over-budget read, missing exact runtime or chained/handler unwind; no CALL following/header/fullhash/installed/main/SDK/build/game |
| runtime_window_ref | None |

| Evidence ID | Declared layer | File | SHA-256 | Supports |
|---|---|---|---|---|
| caller-source | source-contract | C:\ck3-e04-resume-20261015-a01\r04-or-callees-source-a01\FIRST-CALLEE-CONTRACT.proposed-a01.json | 746c20d3670a29f978d46368c9d146296e7368939cccc3eb8e2a1379fe7eb7b3 | Complete149B first OR proves both directional call orders, explicitF reload and actual caller return RVAs |
| direction-one-source | source-contract | C:\ck3-e04-resume-20261015-a01\r04-first-or-directions-source-a01\FIRST-DIRECTION-CONTRACT.proposed-a01.json | 529359cb0c8bef1cfa56481d8ef056eba77403c1e8d2a9d64e7c2efe76e41570 | Complete exact-build native body, full ABI/field/AL contract manually cross-reviewed against original instructions |
| direction-two-source | source-contract | C:\ck3-e04-resume-20261015-a01\r04-first-or-directions-source-a01\SECOND-DIRECTION-CONTRACT.proposed-a01.json | 6d688dd8e5bf9b965ee9d0734f0b3a63c08eb76f7d4ac1a0c66241de61f6a22e | Complete exact-build native body, full ABI/field/AL contract manually cross-reviewed against original instructions |

Check result (file integrity and declarations only):

```json
{
  "schema": "xar.native-research-plan-check.v1",
  "result": "plan-consistent",
  "proof_layer": "record-structure-and-file-integrity",
  "semantic_correctness_verified": false,
  "live_execution_performed": false,
  "observation_plan_issues": [
    "offline-only plan does not define a live observation window",
    "the real producer trigger must be located before live sampling"
  ],
  "declared_edges_by_status": {
    "counter-policy": 0,
    "inference": 0,
    "live-confirmed": 0,
    "static-confirmed": 5,
    "unknown": 3
  },
  "enumerated_native_edges": 8,
  "declared_cases_by_status": {
    "pending": 0,
    "observed": 0,
    "not-applicable": 2
  },
  "checked_evidence_files": 3,
  "limitations": [
    "Evidence layers and conclusions are author declarations; hashes bind bytes, not their truth.",
    "Counts cover this enumerated graph only, not all CK3 branches.",
    "A consistent observation plan is not authorization to run or manipulate CK3."
  ],
  "plan_sha256": "a7bffab28149e2e6640994313864c6e4395f00061559a91693f9e435e95111d0"
}
```
