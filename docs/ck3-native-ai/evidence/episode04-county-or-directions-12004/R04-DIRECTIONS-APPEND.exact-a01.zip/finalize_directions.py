"""Seal the new two-body source increment; main and earlier canonical bundle remain untouched."""
from datetime import datetime,timezone
import difflib,hashlib,io,json,subprocess,sys,zipfile
from pathlib import Path
R=Path(__file__).resolve().parent;B=R.parent;REPO=Path('D:/workspace/ck3_eternal_recurrence');MID='desktop-3fevhd2-1c74096080'
def need(x,m):
 if not x:raise RuntimeError(m)
def load(p):return json.loads(p.read_bytes())
def pin(p):
 raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(n,x):
 with (R/n).open('x',encoding='utf-8',newline='\n') as f:
  if isinstance(x,str):f.write(x)
  else:json.dump(x,f,indent=2);f.write('\n')
plan=load(R/'RESEARCH-PLAN.proposed-a02.json');plan['topic']='actual4-first-OR-directions-source-closed'
plan['observation']['expected_signal']='Complete220B/360B bodies and exact native field/helper/AL contracts obtained; actual R197 observations remain absent'
for ident,name in [('direction-one-source','FIRST-DIRECTION-CONTRACT.proposed-a01.json'),('direction-two-source','SECOND-DIRECTION-CONTRACT.proposed-a01.json')]:
 p=pin(R/name);plan['evidence'].append({'id':ident,'layer':'source-contract','path':p['path'],'sha256':p['sha256'],'exe_sha256':plan['build']['exe_sha256'],'supports':'Complete exact-build native body, full ABI/field/AL contract manually cross-reviewed against original instructions'})
for edge in plan['edges']:
 if edge['id'] in ['body09280','body09410']:
  edge['status']='static-confirmed';edge['evidence']=[{'body09280':'direction-one-source','body09410':'direction-two-source'}[edge['id']]];edge.pop('open_question',None)
  edge['label']={'body09280':'Context selector then Character validity/difference then pair War gate','body09410':'Priority descriptor ID -> Character resolver ->09280 C B null'}[edge['id']]
plan['nodes'] += [{'id':'ctx-test','label':'2C09360 stack-context predicate unknown'},{'id':'ctx-select','label':'2C0FEC0 stack-context selector unknown'},{'id':'M','label':'2494B40 descriptor predicate remains unknown'}]
plan['edges'] += [
 {'id':'ctx-test-unknown','from':'direction09280','to':'ctx-test','label':'RCX=&initial B F context RDX=A; AL chooses keepA','status':'unknown','evidence':['direction-one-source'],'open_question':'Body not authorized/read; context side effects and semantics unknown'},
 {'id':'ctx-select-unknown','from':'direction09280','to':'ctx-select','label':'If testfalse A and same context address; use returned pointer','status':'unknown','evidence':['direction-one-source'],'open_question':'Body not authorized/read; cannot assert context still initial B F'},
 {'id':'M-unknown','from':'direction09410','to':'M','label':'A membership-like test selects28C or288 field','status':'unknown','evidence':['direction-two-source'],'open_question':'Prior2494B40 remains unexpanded; no attacker/defender labels'},
 {'id':'nested-call-known','from':'direction09410','to':'direction09280','label':'Natural09280 C B null at caller09534','status':'static-confirmed','evidence':['direction-two-source']}]
plan['cases'][0].update(status='not-applicable',reason='Static source facts are in confirmed edges; no runtime observation collected',evidence=['direction-one-source','direction-two-source'])
write('RESEARCH-PLAN.static-closed-a03.json',plan)
checks=[]
for args in [['check',str(R/'RESEARCH-PLAN.static-closed-a03.json')],['render',str(R/'RESEARCH-PLAN.static-closed-a03.json'),'--output',str(R/'NATIVE-TREE.generated-a03.md')]]:
 argv=[sys.executable,'-B','-X','utf8',str(REPO/'tools/native_research_plan.py'),*args];c=subprocess.run(argv,cwd=REPO,capture_output=True,text=True);checks.append({'argv':argv,'exit_code':c.returncode,'stdout':c.stdout,'stderr':c.stderr});need(c.returncode==0,'New source closure check/render failed')
write('STATIC-CHECK-RENDER.actual-a03.json',{'machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'plan':pin(R/'RESEARCH-PLAN.static-closed-a03.json'),'checks':checks,'for_observation_used':False,'live_execution':False})
oldzip=B/'r04-or-canonical-candidate-a01/R04-CANONICAL-CANDIDATE.exact-a01.zip';need(pin(oldzip)['sha256']=='2d71e686149b23cb94b72574345dac56f1534c317ad262faf8a37faadeb44558','Frozen canonical changed')
topic='docs/ck3-native-ai/episode04-county-entry-relation-core-12004.md'
with zipfile.ZipFile(oldzip) as z:before=z.read(topic)
append='''

## 2026-10-17 first OR 的四方向函数增量

上节“2C09280/2C09410尚未展开”保留为当时边界；此后独立读取已完成两体
220B/360B和各16B/28B unwind。机器desktop-3fevhd2-1c74096080，exact1.20.0.4
与同EXE SHA；新code580B、metadata含unwind272B、25reads，无CALL追读。

2C09280(A,B,F)把栈context初始两个qword写为{B,F}；实际2C09360调用是
RCX=&context、RDX=A，不是直接把B当RCX。其ALtrue保留A，false才调用
2C0FEC0(A,&同context)取返回Character；不假定opaque前callee没有改context。
selected须magic正确、ID!=-1且不同于原B。随后28BC250(原B,selected)的pairWarID
须!=-1，经完整ID registry/fallback，+358=0且原F为null或对象指针相等才true。
两个新helper2C09360/2C0FEC0未读，不先命名层级/敌我。原B/F从非易失寄存器取，
不受context是否改变的假设替代。返回只消费AL。

2C09410(A,B,F)遍历A的context+318完整ID列表。非null F按record+8完整ID过滤，
不是D0或09280尾gate的指针比较。M(record+20,A.ID)true优先取+28C；否则
M(record+80,A.ID)true取+288，都false取-1。selectedID经Character registry/fallback
后调用2C09280(C,原B,null)；没有独立-1 skip，也不透传原F。M2494B40仍未知。

已闭合firstOR四方向的本体和字段链；不能把这句升级为所有helper或实际触发已闭。
09280的自然return callers为095B7/095C9与09410内09534，后者F明确为null；
09410的callers为095DB/095ED。深层09280出现次数随枚举变化，不借用外层单调用DTO。
最小下一原生观测仍可只捕09580/09780原调用的AL及实际输入，分别过滤096A8/096B7，
默认OFF且限定当前P TLS；不额外调用谓词。R197实际OR仍unknown、physical positive
仍false，未授新runtime/视频资格。精确增量见共享evidence归档及Root交付索引。
'''
before_text=before.decode('utf-8');eol='\r\n' if b'\r\n' in before else '\n';after_text=before_text+append.replace('\n',eol)
patch=''.join(difflib.unified_diff(before_text.splitlines(True),after_text.splitlines(True),fromfile='a/'+topic,tofile='b/'+topic))
write('NATIVE-TREE-INCREMENT.after-canonical-a01.patch',patch)
with zipfile.ZipFile(R/'completed-acquisition.exact-a01.zip') as z:ledger=json.loads(z.read('RAW-READ-LEDGER.actual-a01.json'))
need(ledger['complete'] and ledger['budget']=={'code':580,'metadata_unwind':272} and len(ledger['reads'])==25,'Actual acquisition differs')
bodypins={e:{'body':pin(R/f'source-{e}.bin'),'unwind':pin(R/f'source-{e}.unwind.bin')} for e in ['2C09280','2C09410']}
index={'schema':'xar.e04.r04.firstOR-directions-source-index.v1','machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'exact_EXE_SHA':plan['build']['exe_sha256'],'raw_source':bodypins,'runtime_extents':{'2C09280':['2C09280','2C0935C','510A2E0'],'2C09410':['2C09410','2C09578','52B1270']},'read_accounting':{'code_bytes':580,'metadata_including_unwind_bytes':272,'unwind_payload_bytes_already_in_metadata':44,'total_EXE_bytes':852,'read_count':25},'actual_ledger':'completed-acquisition.exact-a01.zip!RAW-READ-LEDGER.actual-a01.json','first_failed_plan':'completed-acquisition.exact-a01.zip!STATIC-PLAN-CHECK.actual-a01.json','R197_actual_OR':'unknown','R04_physical_positive':False,'new_unread_helpers':['2C09360','2C0FEC0'],'prior_M_remains_unknown':'2494B40','old_canonical_package_unchanged':pin(oldzip),'topic_increment_preimage':{'from':str(oldzip)+'!'+topic,'bytes':len(before),'sha256':sha(before)},'topic_increment_postimage':{'bytes':len(after_text.encode('utf-8')),'sha256':sha(after_text.encode('utf-8'))},'portable_binding':'Relative members in this archive; original absolute paths in exact records remain historical machine-local provenance'}
write('SOURCE-INDEX.actual-a01.json',index)
parts={p.name:p.read_bytes() for p in R.iterdir() if p.is_file()};buf=io.BytesIO()
with zipfile.ZipFile(buf,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,raw in sorted(parts.items()):z.writestr(n,raw)
packed=buf.getvalue()
with zipfile.ZipFile(io.BytesIO(packed)) as z:
 need(z.testzip() is None,'CRC')
 for n,raw in parts.items():need(z.read(n)==raw,'Exact roundtrip '+n)
delivery={'schema':'xar.e04.r04.firstOR-directions-delivery.v1','machine_id':MID,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'archive':{'path':str(R/'R04-DIRECTIONS-APPEND.exact-a01.zip'),'bytes':len(packed),'sha256':sha(packed)},'read_first':['SOURCE-INDEX.actual-a01.json','FIRST-DIRECTION-SEMANTICS.md','SECOND-DIRECTION-SEMANTICS.md','NATIVE-TREE.generated-a03.md'],'contracts':['FIRST-DIRECTION-CONTRACT.proposed-a01.json','SECOND-DIRECTION-CONTRACT.proposed-a01.json'],'ordinary_static_checks':{'pre_read_A01':2,'pre_read_corrected_A02':0,'new_source_closed_A03':0,'new_source_render_A03':0,'for_observation':False},'bounded_actual_reads':{'code_bytes':580,'metadata_including_unwind_bytes':272,'reads':25,'unwind_payload_included_bytes':44,'new_fullhash_header_installed_EXE_or_CALL_body_reads':0},'first_OR_four_direction_bodies_closed_to_fields':True,'new_unread_helper_entries':['2C09360','2C0FEC0'],'prior_M2494B40_still_unknown':True,'next_minimal_original_observer':{'runtime_qualified':False,'default':'OFF','scope':'Existing single original P TLS, actual same-thread identity/caller checks, no added predicate calls','first_OR':{'entry':'2C09580','caller_return':'2C096A8','inputs':['RCX=receiver','RDX=actor','R8=opaqueF'],'return':'AL'},'second_OR':{'entry':'2C09780','caller_return':'2C096B7','inputs':['RCX=receiver','RDX=actor'],'R8_semantic':None,'return':'AL'},'deep_09280_callers':['2C095B7','2C095C9','2C09534'],'deep_09410_callers':['2C095DB','2C095ED'],'warning':'Deep09280 is not fixed-count1;09534 is nested C B null.09360 RCX is stack-context address, notB. Uncovered is unknown, not count0/false.'},'R197_actual_OR':'unknown','R04_physical_positive':False,'new_runtime_PID_run_qualification':None,'main_SDK_Driver_build_game_operations':0,'earlier_canonical_package_untouched':True,'knowledge_patch':'NATIVE-TREE-INCREMENT.after-canonical-a01.patch','knowledge_patch_base':'Earlier frozen canonical topic postimage, not current main; apply after canonical intake/rebase concurrent topic changes','canonical_evidence_root':'docs/ck3-native-ai/evidence/episode04-county-or-directions-12004/','storage':{'shared_pool_bytes':134217728,'new_append_ceiling_bytes':49152,'exact_archive_replaces_uncompressed_derivatives':True,'no_raw_evidence_payload_discarded':True}}
receipt=(json.dumps(delivery,indent=2)+'\n').encode('utf-8');need(len(packed)+len(receipt)<=49152,'Final compact append exceeds48KiB '+str((len(packed),len(receipt))))
out=R/'R04-DIRECTIONS-APPEND.exact-a01.zip'
with out.open('xb') as f:f.write(packed)
with zipfile.ZipFile(out) as z:
 for n,raw in parts.items():need(z.read(n)==raw,'Disk roundtrip '+n)
for n in parts:
 p=R/n;need(p.resolve().parent==R.resolve(),'Nonlocal deletion');p.unlink()
with (R/'ROOT-DELIVERY.actual-a01.json').open('xb') as f:f.write(receipt)
print(json.dumps({'root_bytes':len(packed)+len(receipt),'archive_bytes':len(packed),'archive_sha256':sha(packed),'delivery_bytes':len(receipt),'delivery_sha256':sha(receipt),'actual_code_metadata_bytes':[580,272],'static_check_render_exit_codes':[0,0]}))
