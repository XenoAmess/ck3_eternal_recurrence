# 2C09280: context-based selection, then raw pair/War gating

machine_id: `desktop-3fevhd2-1c74096080`  
observed_at_utc: `2026-10-17T09:44:38Z`

Scope: only the unified reader's saved `source-2C09280.asm` and `.function.json`; no EXE/callee-body/SDK/Driver/game/build access, main edit or old-check rerun by this lane. The paired09410 caller fact below was supplied by its owner, not acquired by a further body read.

Root: `C:/ck3-e04-resume-20261015-a01/r04-first-or-directions-source-a01/`. Complete body `[2C09280,2C0935C)`,220 B/65 instructions,12 internal branches/3 calls. `source-2C09280.bin` SHA256 `a303ad6fefa856a9c93585380422b5255e597754f07b4551520c32266e10dd50`; `source-2C09280.unwind.bin`16 B SHA256 `d95dec7a506aa265e67c8078b348991ba97d4271c5c73fa68982ef362b5dd60d`. Runtime xdata `510A2E0`, flags0. Prologue pushes RDI and allocates48 B; original RBX/RSI are restored at final RSP+0x40/+0x48. This is its own source/unwind contract, not a neighboring function's.

ASM SHA256 `3f7b0b95b317dc1bddb2595bed699aa1d9852c75cb86e0ad2af2a44fda773a85`; function JSON SHA256 `68a3c87da909c3a316957578d8cd08b13d88b7d32cf7b34e58ed94b81e827c4e`.

## Exact inputs and helper ABI

Let A=original RCX, B=original RDX, F=original R8. Original B is preserved inRSI, original F inRDI, A initially inRBX. After the prologue the caller initializes two consecutive qwords at RSP+20/+28 to `{B,F}`. Their address is C. No entry R9 consumption is explicit in this body.

| CALL | Return | Actual caller setup / use |
| --- | --- | --- |
|`2C092AA -> 2C09360`|`2C092AF`|RCX=C (stack context address), RDX=A, R8 still original F. Test only AL. Nonzero retains A as selected; zero takes the selector path.|
|`2C092BB -> 2C0FEC0`|`2C092C0`|Only after first ALzero: RCX=original A, RDX=same C. R8 is **not reloaded** after09360. Use full RAX as selected pointer S, not AL.|
|`2C092DF -> 28BC250`|`2C092E4`|RCX=original B, RDX=selected S. Read returned object+20 as signed32-bit ID.|

The first helper is not directly invoked with RCX=B. A flattened pure data model may unpack `{B,F}` intentionally, but that is not the native entry signature. The opaque helper may modify C; its initialization does not prove those two qwords are unchanged when the selector receives C. This body does not reread C into its preserved RSI/RDI, so the later pair query and F tail filter still use **original** B/F. No helper body was followed, and no existing pure projection is declared incorrect solely from this ABI distinction.

## Ordered gates and returned AL

1. S is original A when09360 returns ALnonzero; otherwise S is selector RAX. Thus helper ALzero is a selection branch, not immediate rejection.
2. Require `u32[S+1C]==43686172` (Character tag), `u32[S+18]!=FFFFFFFF`, and `u32[originalB+18]!=u32[S+18]`. Compare full IDs, not low24 bits. No S-null guard precedes these reads.
3. Query pair28BC250(originalB,S), read raw ID at return+20, reject exactly-1. No null-return guard precedes this field read.
4. Resolve the raw ID via slot5D1DE58 using low24-bit index/capacity and complete row object+8 equality. Null manager, out-of-range index, null row or mismatched complete ID selects fallback slot5D1DE40. The fallback receives no extra ID/tag check here.
5. Require selected object/fallback+358 raw byte==0. Then require original F==0 or **F equals that selected object pointer**. Nonzero unequal F rejects. No selected-object-null guard precedes+358.

Only those passed gates execute `MOV AL,1` at2C09338. Every rejection reaches `XOR AL,AL` at2C0934F. Own return AL is normalized0/1; this caller does not return the selected Character. The raw+358 byte's gameplay label and the selector's business role remain unknown in this acquisition.

## Natural caller and observation boundary

Held09580 uses native returns2C095B7 for09280(A,B,F), and2C095C9 for09280(B,A,F), testing AL as positive short-circuit alternatives. The paired09410 owner also reports return2C09534 for its nested09280 call, with R8 explicitly zero. This extra natural caller must remain distinct: do not assume all09280 invocations are the first two outer alternatives, fixed original direction, or one call per preview. Capture each invocation's actual A/B/F and provenance rather than impose a count from this function body.

For a future natural observer, opaque RCX/RDX/R8/R9 pass-through at09280 entry is straightforward; any deeper09360 observation must record RCX as C, not a Character pointer. Original outer AL remains independent, and source control flow does not backfill R197 helper values, chosen S, pair inputs or OR outcomes. The unexpanded entries here are2C09360,2C0FEC0 and28BC250; no further reads or implementation are requested by this document. It grants no runtime, R04-positive or clean-footage credit.
