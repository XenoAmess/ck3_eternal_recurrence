; machine_id: desktop-3fevhd2-1c74096080
; exact runtime body 0x2c09410..0x2c09578; no callee body read
02C09410 48 89 74 24 18                   mov      qword ptr [rsp + 0x18], rsi
02C09415 48 89 7c 24 20                   mov      qword ptr [rsp + 0x20], rdi
02C0941A 41 54                            push     r12
02C0941C 41 56                            push     r14
02C0941E 41 57                            push     r15
02C09420 48 83 ec 20                      sub      rsp, 0x20
02C09424 48 8b 81 c0 01 00 00             mov      rax, qword ptr [rcx + 0x1c0]
02C0942B 4d 8b f0                         mov      r14, r8
02C0942E 4c 8b e2                         mov      r12, rdx
02C09431 4c 8b f9                         mov      r15, rcx
02C09434 48 85 c0                         test     rax, rax
02C09437 74 08                            je       0x2c09441
02C09439 48 05 18 03 00 00                add      rax, 0x318
02C0943F eb 07                            jmp      0x2c09448
02C09441 48 8d 05 f0 08 85 02             lea      rax, [rip + 0x28508f0]
02C09448 48 8b 38                         mov      rdi, qword ptr [rax]
02C0944B 48 63 40 0c                      movsxd   rax, dword ptr [rax + 0xc]
02C0944F 48 89 5c 24 40                   mov      qword ptr [rsp + 0x40], rbx
02C09454 48 89 6c 24 48                   mov      qword ptr [rsp + 0x48], rbp
02C09459 48 8d 34 87                      lea      rsi, [rdi + rax*4]
02C0945D 48 3b fe                         cmp      rdi, rsi
02C09460 0f 84 ed 00 00 00                je       0x2c09553
02C09466 48 8b 15 eb 49 11 03             mov      rdx, qword ptr [rip + 0x31149eb]
02C0946D 4c 8b 0d cc 49 11 03             mov      r9, qword ptr [rip + 0x31149cc]
02C09474 48 85 d2                         test     rdx, rdx
02C09477 74 29                            je       0x2c094a2
02C09479 44 8b 07                         mov      r8d, dword ptr [rdi]
02C0947C 41 8b c0                         mov      eax, r8d
02C0947F 25 ff ff ff 00                   and      eax, 0xffffff
02C09484 3b 42 2c                         cmp      eax, dword ptr [rdx + 0x2c]
02C09487 73 19                            jae      0x2c094a2
02C09489 8b c8                            mov      ecx, eax
02C0948B 48 8b 42 20                      mov      rax, qword ptr [rdx + 0x20]
02C0948F 48 03 c9                         add      rcx, rcx
02C09492 48 8b 6c c8 08                   mov      rbp, qword ptr [rax + rcx*8 + 8]
02C09497 48 85 ed                         test     rbp, rbp
02C0949A 74 06                            je       0x2c094a2
02C0949C 44 39 45 08                      cmp      dword ptr [rbp + 8], r8d
02C094A0 74 03                            je       0x2c094a5
02C094A2 49 8b e9                         mov      rbp, r9
02C094A5 4d 85 f6                         test     r14, r14
02C094A8 74 0d                            je       0x2c094b7
02C094AA 41 8b 46 08                      mov      eax, dword ptr [r14 + 8]
02C094AE 39 45 08                         cmp      dword ptr [rbp + 8], eax
02C094B1 0f 85 8f 00 00 00                jne      0x2c09546
02C094B7 41 8b 5f 18                      mov      ebx, dword ptr [r15 + 0x18]
02C094BB 48 8d 4d 20                      lea      rcx, [rbp + 0x20]
02C094BF 8b d3                            mov      edx, ebx
02C094C1 e8 7a b6 88 ff                   call     0x2494b40
02C094C6 84 c0                            test     al, al
02C094C8 74 08                            je       0x2c094d2
02C094CA 8b 95 8c 02 00 00                mov      edx, dword ptr [rbp + 0x28c]
02C094D0 eb 1f                            jmp      0x2c094f1
02C094D2 48 8d 8d 80 00 00 00             lea      rcx, [rbp + 0x80]
02C094D9 8b d3                            mov      edx, ebx
02C094DB e8 60 b6 88 ff                   call     0x2494b40
02C094E0 84 c0                            test     al, al
02C094E2 74 08                            je       0x2c094ec
02C094E4 8b 95 88 02 00 00                mov      edx, dword ptr [rbp + 0x288]
02C094EA eb 05                            jmp      0x2c094f1
02C094EC ba ff ff ff ff                   mov      edx, 0xffffffff
02C094F1 4c 8b 05 70 e0 05 03             mov      r8, qword ptr [rip + 0x305e070]
02C094F8 4d 85 c0                         test     r8, r8
02C094FB 74 25                            je       0x2c09522
02C094FD 8b c2                            mov      eax, edx
02C094FF 25 ff ff ff 00                   and      eax, 0xffffff
02C09504 41 3b 40 2c                      cmp      eax, dword ptr [r8 + 0x2c]
02C09508 73 18                            jae      0x2c09522
02C0950A 8b c8                            mov      ecx, eax
02C0950C 49 8b 40 20                      mov      rax, qword ptr [r8 + 0x20]
02C09510 48 03 c9                         add      rcx, rcx
02C09513 48 8b 4c c8 08                   mov      rcx, qword ptr [rax + rcx*8 + 8]
02C09518 48 85 c9                         test     rcx, rcx
02C0951B 74 05                            je       0x2c09522
02C0951D 39 51 18                         cmp      dword ptr [rcx + 0x18], edx
02C09520 74 07                            je       0x2c09529
02C09522 48 8b 0d 47 e0 05 03             mov      rcx, qword ptr [rip + 0x305e047]
02C09529 45 33 c0                         xor      r8d, r8d
02C0952C 49 8b d4                         mov      rdx, r12
02C0952F e8 4c fd ff ff                   call     0x2c09280
02C09534 84 c0                            test     al, al
02C09536 75 3c                            jne      0x2c09574
02C09538 48 8b 15 19 49 11 03             mov      rdx, qword ptr [rip + 0x3114919]
02C0953F 4c 8b 0d fa 48 11 03             mov      r9, qword ptr [rip + 0x31148fa]
02C09546 48 83 c7 04                      add      rdi, 4
02C0954A 48 3b fe                         cmp      rdi, rsi
02C0954D 0f 85 21 ff ff ff                jne      0x2c09474
02C09553 32 c0                            xor      al, al
02C09555 48 8b 6c 24 48                   mov      rbp, qword ptr [rsp + 0x48]
02C0955A 48 8b 5c 24 40                   mov      rbx, qword ptr [rsp + 0x40]
02C0955F 48 8b 74 24 50                   mov      rsi, qword ptr [rsp + 0x50]
02C09564 48 8b 7c 24 58                   mov      rdi, qword ptr [rsp + 0x58]
02C09569 48 83 c4 20                      add      rsp, 0x20
02C0956D 41 5f                            pop      r15
02C0956F 41 5e                            pop      r14
02C09571 41 5c                            pop      r12
02C09573 c3                               ret      
02C09574 b0 01                            mov      al, 1
02C09576 eb dd                            jmp      0x2c09555
