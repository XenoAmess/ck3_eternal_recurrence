; machine_id: desktop-3fevhd2-1c74096080
; exact runtime body 0x2c09280..0x2c0935c; no callee body read
02C09280 48 89 5c 24 08                   mov      qword ptr [rsp + 8], rbx
02C09285 48 89 74 24 10                   mov      qword ptr [rsp + 0x10], rsi
02C0928A 57                               push     rdi
02C0928B 48 83 ec 30                      sub      rsp, 0x30
02C0928F 48 8b f2                         mov      rsi, rdx
02C09292 48 89 54 24 20                   mov      qword ptr [rsp + 0x20], rdx
02C09297 48 8b d1                         mov      rdx, rcx
02C0929A 4c 89 44 24 28                   mov      qword ptr [rsp + 0x28], r8
02C0929F 48 8b d9                         mov      rbx, rcx
02C092A2 49 8b f8                         mov      rdi, r8
02C092A5 48 8d 4c 24 20                   lea      rcx, [rsp + 0x20]
02C092AA e8 b1 00 00 00                   call     0x2c09360
02C092AF 84 c0                            test     al, al
02C092B1 75 10                            jne      0x2c092c3
02C092B3 48 8d 54 24 20                   lea      rdx, [rsp + 0x20]
02C092B8 48 8b cb                         mov      rcx, rbx
02C092BB e8 00 6c 00 00                   call     0x2c0fec0
02C092C0 48 8b d8                         mov      rbx, rax
02C092C3 81 7b 1c 72 61 68 43             cmp      dword ptr [rbx + 0x1c], 0x43686172
02C092CA 75 7e                            jne      0x2c0934a
02C092CC 8b 43 18                         mov      eax, dword ptr [rbx + 0x18]
02C092CF 83 f8 ff                         cmp      eax, -1
02C092D2 74 76                            je       0x2c0934a
02C092D4 39 46 18                         cmp      dword ptr [rsi + 0x18], eax
02C092D7 74 71                            je       0x2c0934a
02C092D9 48 8b d3                         mov      rdx, rbx
02C092DC 48 8b ce                         mov      rcx, rsi
02C092DF e8 6c 2f cb ff                   call     0x28bc250
02C092E4 8b 40 20                         mov      eax, dword ptr [rax + 0x20]
02C092E7 83 f8 ff                         cmp      eax, -1
02C092EA 74 5e                            je       0x2c0934a
02C092EC 4c 8b 05 65 4b 11 03             mov      r8, qword ptr [rip + 0x3114b65]
02C092F3 4d 85 c0                         test     r8, r8
02C092F6 74 26                            je       0x2c0931e
02C092F8 8b c8                            mov      ecx, eax
02C092FA 81 e1 ff ff ff 00                and      ecx, 0xffffff
02C09300 41 3b 48 2c                      cmp      ecx, dword ptr [r8 + 0x2c]
02C09304 73 18                            jae      0x2c0931e
02C09306 8b d1                            mov      edx, ecx
02C09308 49 8b 48 20                      mov      rcx, qword ptr [r8 + 0x20]
02C0930C 48 03 d2                         add      rdx, rdx
02C0930F 48 8b 4c d1 08                   mov      rcx, qword ptr [rcx + rdx*8 + 8]
02C09314 48 85 c9                         test     rcx, rcx
02C09317 74 05                            je       0x2c0931e
02C09319 39 41 08                         cmp      dword ptr [rcx + 8], eax
02C0931C 74 07                            je       0x2c09325
02C0931E 48 8b 0d 1b 4b 11 03             mov      rcx, qword ptr [rip + 0x3114b1b]
02C09325 80 b9 58 03 00 00 00             cmp      byte ptr [rcx + 0x358], 0
02C0932C 75 1c                            jne      0x2c0934a
02C0932E 48 85 ff                         test     rdi, rdi
02C09331 74 05                            je       0x2c09338
02C09333 48 3b cf                         cmp      rcx, rdi
02C09336 75 12                            jne      0x2c0934a
02C09338 b0 01                            mov      al, 1
02C0933A 48 8b 5c 24 40                   mov      rbx, qword ptr [rsp + 0x40]
02C0933F 48 8b 74 24 48                   mov      rsi, qword ptr [rsp + 0x48]
02C09344 48 83 c4 30                      add      rsp, 0x30
02C09348 5f                               pop      rdi
02C09349 c3                               ret      
02C0934A 48 8b 5c 24 40                   mov      rbx, qword ptr [rsp + 0x40]
02C0934F 32 c0                            xor      al, al
02C09351 48 8b 74 24 48                   mov      rsi, qword ptr [rsp + 0x48]
02C09356 48 83 c4 30                      add      rsp, 0x30
02C0935A 5f                               pop      rdi
02C0935B c3                               ret      
