# 2C09410：数组内对象到派生对象的方向检查

machine_id: `desktop-3fevhd2-1c74096080`；只读观察时间 `2026-10-17T09:44:53Z`。完整边界 `[0x2C09410,0x2C09578)`，360 B／SHA `2d157dc7c1982c7079e2ccead5cb54e18f535a414f4968fd4bf094abab81290d`；保存原件 SHA 已重算吻合。unwind28 B／SHA `872b85ae0c15f041a6687302c17467b34498977ed80c873b769994a238055d91`。99 条指令、20 个本地分支均对齐；三个 CALL 位点只涉及两个未在此追读的目标。读取和 exact EXE 身份由 Root 集中账本绑定；我没有读取 EXE。

入口 A=RCX→R15、B=RDX→R12、F=R8→R14。F 是 opaque 输入；本体不能给它命名为某种业务对象。以下 O/C 只是本地对象变量。

```text
P = *(A+1C0)
header = P ? P+318 : static_header
for cursor=data; cursor!=data+4*sign_extend(count@0C); cursor+=4:
    rawID = u32(cursor)
    O = resolve_M1(rawID, validate_FullID_at_08, else_default_O)
    if F != 0 and u32(O+08) != u32(F+08): continue
    if CALL2494B40(RCX=&O+20, EDX=u32(A+18)).AL:
        selected = u32(O+28C)
    else if CALL2494B40(RCX=&O+80, EDX=u32(A+18)).AL:
        selected = u32(O+288)
    else: selected = FFFFFFFF
    C = resolve_M2(selected, validate_FullID_at_18, else_default_C)
    if CALL2C09280(RCX=C,RDX=B,R8=0).AL: return AL=1
return AL=0
```

## 字段和过滤的精确含义

数组来自 A 的 `+1C0` 指针所指对象内的 `+318` header；不是把 `A+318` 当数组。header 的 `+0` 为 data，`+0C` 为 signed int32 count，元素步长4。只见空数组判定和 end-pointer 循环，没有额外最大数量、负数检查或去重；不能将静态源码改述为已证明的有限安全采样上限。

M1 使用 rawID 低24位索引：manager `+2C` 容量、`+20` 表、16 B row 的 `+8` 对象指针；需非空且对象 `+08` FullID 精确匹配原 rawID。失败使用全局 default O，**不是直接跳过**。非空 F 仅作 `O.FullID@08 == F.FullID@08` 过滤，没有指针相等或类型 magic 检查。

`2494B40` 的 AL 分别决定读取 `O+28C` 或 `O+288`；前一检查为 true 时不执行后一检查。两个选取字段与 B、F 没有直接身份比较。两个 helper 都 false 时选取 `FFFFFFFF`，仍进入普通 M2 resolver 和后续调用，没有独立 sentinel skip。

M2 同样采用低24位索引、manager `+2C/+20`、16 B row `+8` 指针；这里检验对象 `+18` FullID。不合格就使用 default C。随后调用的是 **C 对原 B，且第三参数明确归零**，不是 A 对 B，也不是把原 F 传下去。`2C09280` 的内部关系及 default 对象业务语义须结合独立 source 合同；不能仅凭此体给 O/C/两个字段冠以上层、下层或对立方名称。

用于回链的局部 RIP 地址：static header `5459D38`，M1/default-O globals `5D1DE58/5D1DE40`，M2/default-C globals `5C67568/5C67570`。这是指令推得的地址，**未读取这些 globals 当前值**。下层调用返回 false 后重新加载 M1/default-O，再推进4 B；不能将跨 CALL 的 manager 寄存器当作永久缓存。

## ABI、自然 caller 与未知边界

旧 firstOR 的两个自然 caller return 为 `2C095DB`（A,B,F）和 `2C095ED`（B,A,F）；原 F 在这两个调用前均重装。不要误用外层 `2C096A8`。本体对 membership helper 只明确设置 RCX/EDX，不能据此断定其完整形式参数数目；对 `2C09280` 则明确 `xor r8d,r8d`，所以完整 R8=0。其自然 return 位点为 `2C09534`。

真/假出口只设置 AL，RAX 高位不归零，observer 不得按完整 RAX 非零判断。原件开头完整指令累计边界为5、10、12、14、16 B；不能照搬其他函数15 B detour prefix 而切断 `push r15`。本任务没有实施 hook。

尚未观测 R197 的数组内容、F、所选字段、fallback、membership AL 或嵌套返回；最终 relation false 不能回填这些实际值。此体没有自己执行 A/B FullID 相等的前置拒绝，不能把 firstOR 上层保护误作此体自身分支。这里只提供源码语义，不新增 DTO、consumer、矩阵、构建、策略或实机资格；旧 canonical 未改。
