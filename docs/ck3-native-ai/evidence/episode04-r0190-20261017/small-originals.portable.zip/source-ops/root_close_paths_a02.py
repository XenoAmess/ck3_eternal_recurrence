"""Exact R190 close routine with canonical Windows file-pin equality."""
from pathlib import Path
import hashlib
from root_identity_a02 import same_pin

SOURCE=Path('C:/ck3-e04-resume-20261015-a01/r190-close-prep-a01/owner_close_candidate.py')
raw=SOURCE.read_bytes()
if len(raw)!=38697 or hashlib.sha256(raw).hexdigest()!='ef95e0ffadf88cc17a13946d5c601e832fe9cb4b7c94ef1d7b20a274a02cae7f':
    raise RuntimeError('exact close dependency changed')
source=raw.decode('utf-8')
for key,selected in [('receipt','save_response'),('save','save'),('build_receipt','prepared')]:
    old=f'prepared_source.get("{key}") == source["{selected}"]'
    if source.count(old)!=1:
        raise RuntimeError('close source comparator structure changed')
    source=source.replace(old,f'_same_pin(prepared_source.get("{key}"), source["{selected}"])')
exec(compile(source,str(SOURCE)+'#r190-canonical-paths-a02','exec'),
     {'__name__':'__main__','__file__':str(SOURCE),'_same_pin':same_pin})
