"""New immutable config; normalize one Windows path without changing any source bytes."""
import json
from pathlib import Path
import r190_ops as op

m=op.owner();s=op.SCENE
old=s/'film-input.actual-a01.json';oldpin=m.pin(old)
m.need(oldpin['bytes']==6910 and oldpin['sha256']=='7c4a7f592fb190a9831c48b35efe4ddddc85328933f3e0eb9a7c1ffa94f459a1','old config changed')
c=m.small_json(old);before=c['checkpoint_source']['save']['path']
canonical=str(Path(before).resolve(strict=True))
m.need(Path(before).resolve()==Path(canonical).resolve(),'source target changed')
c['checkpoint_source']['save']['path']=canonical
actual=m.pin(canonical)
m.need(actual==c['checkpoint_source']['save'],'actual source size/SHA or canonical path differ')
new=s/'film-input.actual-a02.json';m.write_new(new,c);m.config(new)
m.write_new(s/'film-source-path-normalization.actual-a02.json',{
 'machine_id':c['machine_id'],'at_utc':m.now().isoformat(),'source_head':c['source_head'],
 'original_config':oldpin,'new_config':m.pin(new),
 'only_semantic_change':'/checkpoint_source/save/path canonical Windows spelling',
 'old_spelling':before,'new_spelling':canonical,'actual_unchanged_source':actual,
 'original_failed_preflight_had_no_recorder_or_SDK_calls':True})
print(json.dumps({'film_config':m.pin(new)}))
