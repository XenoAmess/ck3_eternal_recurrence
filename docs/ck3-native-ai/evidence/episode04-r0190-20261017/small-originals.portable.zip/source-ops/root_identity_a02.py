"""Root-only R190 identity; compare exact file pins using canonical Windows paths."""
from pathlib import Path
import hashlib
import importlib.util
import sys

sys.dont_write_bytecode = True
HOST = Path('C:/ck3-e04-resume-20261015-a01/r190-owner-prep-a01/owner_film_candidate.py')
SOURCE = Path('C:/ck3-e04-resume-20261015-a01/r186-owner-prep-a03/owner_identity_candidate.py')

def need(value, why):
    if not value:
        raise RuntimeError(why)

def same_pin(a, b):
    return (isinstance(a, dict) and isinstance(b, dict)
            and a.get('bytes') == b.get('bytes')
            and str(a.get('sha256', '')).lower() == str(b.get('sha256', '')).lower()
            and Path(a['path']).resolve(strict=True) == Path(b['path']).resolve(strict=True))

def main():
    raw = HOST.read_bytes()
    need(len(raw) == 45416 and hashlib.sha256(raw).hexdigest()
         == 'c6edde7ae91cf618c7f0034452723947a33c46f17ddae0a58993c6d948f42c5e', 'host changed')
    sys.path.insert(0, str(HOST.parent))
    spec = importlib.util.spec_from_file_location('owner_film_candidate', HOST)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    raw = SOURCE.read_bytes()
    need(hashlib.sha256(raw).hexdigest()
         == '90cefa1d1e19d31effd10a4f33ab332aafa8ce5e56bea556235e6a2ea25f9f36', 'identity routine changed')
    source = raw.decode('utf-8')
    old = 'prefix = c["request_prefix"]+"-identity"'
    need(source.count(old) == 2, 'prefix source changed')
    source = source.replace(old, 'prefix = c["request_prefix"]+"-identity-ready-r190-a02"')
    for key, selected in [('receipt', 'save_response'), ('save', 'save'), ('build_receipt', 'prepared')]:
        old = f'expected_source.get("{key}") == source["{selected}"]'
        need(source.count(old) == 1, 'pin comparison source changed')
        source = source.replace(old, f'_same_pin(expected_source.get("{key}"), source["{selected}"])')
    exec(compile(source, str(SOURCE)+'#r190-a02-canonical-pin-paths', 'exec'),
         {'__name__': '__main__', '__file__': str(SOURCE), '_same_pin': same_pin})

if __name__ == '__main__':
    main()
