"""Root-only exact identity adapter for a fresh R190 run.

Only imports the previously used identity routine after byte validation; no SDK
action occurs until Root explicitly executes this file with live context.
"""
from pathlib import Path
import hashlib
import importlib.util
import sys

sys.dont_write_bytecode = True
HOST = Path('C:/ck3-e04-resume-20261015-a01/r190-owner-prep-a01/owner_film_candidate.py')
HOST_SHA = 'c6edde7ae91cf618c7f0034452723947a33c46f17ddae0a58993c6d948f42c5e'
SOURCE = Path('C:/ck3-e04-resume-20261015-a01/r186-owner-prep-a03/owner_identity_candidate.py')
SOURCE_SHA = '90cefa1d1e19d31effd10a4f33ab332aafa8ce5e56bea556235e6a2ea25f9f36'


def need(value, reason):
    if not value:
        raise RuntimeError(reason)


def main():
    host = HOST.read_bytes()
    need(len(host) == 45416 and hashlib.sha256(host).hexdigest() == HOST_SHA,
         'R190 owner helper bytes changed')
    sys.path.insert(0, str(HOST.parent))
    spec = importlib.util.spec_from_file_location('owner_film_candidate', HOST)
    need(spec is not None and spec.loader is not None, 'owner helper unavailable')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    body = SOURCE.read_bytes()
    need(hashlib.sha256(body).hexdigest() == SOURCE_SHA, 'identity adapter source changed')
    source = body.decode('utf-8')
    old = 'prefix = c["request_prefix"]+"-identity"'
    need(source.count(old) == 2, 'identity source structure changed')
    source = source.replace(old, 'prefix = c["request_prefix"]+"-identity-ready-r190-a01"')
    exec(compile(source, str(SOURCE) + '#r190-ready-a01', 'exec'),
         {'__name__': '__main__', '__file__': str(SOURCE)})


if __name__ == '__main__':
    main()
