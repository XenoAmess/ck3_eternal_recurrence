"""Portable stdlib integrity/preimage check; never build, connect or write a repo."""
from pathlib import Path
import argparse
import hashlib
import json

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path)
    parser.add_argument('--adopted', action='store_true')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'SOURCE.final.json').read_text(encoding='utf-8'))
    checked = 0
    for row in manifest['files']:
        path = root / row['path']
        raw = path.read_bytes()
        if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            raise ValueError('candidate source drift: ' + row['path'])
        checked += 1
    if args.repo:
        for row in manifest['copy_plan']:
            target = args.repo / row['target']
            expected = row['source'] if args.adopted else row['preimage']
            if expected is None:
                if target.exists(): raise ValueError('new target already exists: ' + row['target'])
            else:
                raw = target.read_bytes()
                if len(raw) != expected['bytes'] or hashlib.sha256(raw).hexdigest() != expected['sha256']:
                    raise ValueError('target preimage/adopted bytes differ: ' + row['target'])
    print(json.dumps({'scope': 'source integrity and optional exact target bytes',
                      'checked_files': checked, 'targets': len(manifest['copy_plan']),
                      'repo_checked': args.repo is not None, 'adopted': args.adopted,
                      'SDK_or_game_or_build': False, 'live_qualification': False, 'status': 'PASS'}))

if __name__ == '__main__':
    main()
