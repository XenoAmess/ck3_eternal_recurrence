# Research plan: refill-core-carrier-12004

GENERATED from the supplied research plan; no native semantics are inferred.

Question: Can true core TLS identity join both fixed ADD traps and the actual natural parent?

```mermaid
flowchart TD
    n0["Actual natural post-date scope"]
    n1["True core TLS invocation"]
    n2["Fenced fixed DATA export"]
    n3["Two physical ADD traps"]
    n4["Strict CoreEvent same-token join"]
    n5["New qualified live sample"]
    n0 -->|"parent-core [static-confirmed] Literal same-thread parent"| n1
    n1 -->|"core-carrier [static-confirmed] True shared token around original once"| n2
    n2 -->|"carrier-trap [static-confirmed] Independent bounded double reads"| n3
    n3 -->|"trap-consumer [static-confirmed] Raw CoreEvent plus token join"| n4
    n4 -. "future-live [unknown] New deployment and actual positive sample" .-> n5
```

| Edge | Declared status | Evidence IDs | Open question |
|---|---|---|---|
| parent-core | static-confirmed | contract |  |
| core-carrier | static-confirmed | contract |  |
| carrier-trap | static-confirmed | contract |  |
| trap-consumer | static-confirmed | contract |  |
| future-live | unknown |  | New coherent production build/SYSTEM/runtime and Root scene remain NOTRUN |

| Observation design | Value |
|---|---|
| mode | offline-only |
| actor_kind | engine |
| owner_scope | Independent source candidate; no allocated live actor |
| identity_kind | process-ordinal |
| identity_lifetime | Shared invocation token and natural event identities are process-local; full generation IDs are retained; live epochs require Root admission |
| producer_trigger | daily-tick |
| producer | Existing natural post-date original-once regular-core thread |
| caller | Actual2A9A8DD to2A98AC0; physical2A98B88 and2A98B8B |
| consumer | Strict v4 native wire and independent raw CoreEvent same-invocation join |
| cache_lifetime | Fenced carrier active only during actual original call; nested state restored and return inactive |
| expected_signal | Both traps retain the same stable active token/thread/date/context and the original CoreEvent agrees |
| zero_sample_meaning | No positive target observed within the finite window; not proof of no ADD or disabled refill |
| stop_condition | Source edit and focused synthetic checks only; no SDK/game/DR or whole native build; Root review2026-10-18T05:30Z |
| runtime_window_ref | None |

| Evidence ID | Declared layer | File | SHA-256 | Supports |
|---|---|---|---|---|
| contract | source-contract | candidate/docs/ck3-native-ai/episode04-refill-core-carrier-12004.md | 88ce8223a0567202c59c45c6687274dd77aa11f042663f398223855f890aa345 | Reviewed exact-source implementation contract, not runtime qualification |

Check result (file integrity and declarations only):

```json
{
  "schema": "xar.native-research-plan-check.v1",
  "result": "plan-consistent",
  "proof_layer": "record-structure-and-file-integrity",
  "semantic_correctness_verified": false,
  "live_execution_performed": false,
  "observation_plan_issues": [
    "offline-only plan does not define a live observation window"
  ],
  "declared_edges_by_status": {
    "counter-policy": 0,
    "inference": 0,
    "live-confirmed": 0,
    "static-confirmed": 4,
    "unknown": 1
  },
  "enumerated_native_edges": 5,
  "declared_cases_by_status": {
    "pending": 1,
    "observed": 0,
    "not-applicable": 0
  },
  "checked_evidence_files": 1,
  "limitations": [
    "Evidence layers and conclusions are author declarations; hashes bind bytes, not their truth.",
    "Counts cover this enumerated graph only, not all CK3 branches.",
    "A consistent observation plan is not authorization to run or manipulate CK3."
  ],
  "plan_sha256": "90f943869966c404dec1a4f55f2a5f86842e2ea698cd529688b3a3893365e113"
}
```
