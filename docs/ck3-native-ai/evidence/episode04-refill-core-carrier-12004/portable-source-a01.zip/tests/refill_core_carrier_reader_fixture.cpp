// Source-only focused fixture. Synthetic local bytes; no process/debugger APIs.
#include "../candidate/ck3_autonomous_player/native_bridge/research/refill_add_live_12004/refill_core_carrier_reader_12004.hpp"
#include <cstdlib>
#include <iostream>
#define REQUIRE(expression) do { if (!(expression)) { std::cerr << "requirement failed at line " << __LINE__ << ": " << #expression << "\n"; std::abort(); } } while (false)
namespace r = xar::research::refill_core_carrier_12004;
namespace a = r::abi;
struct Fixture {
  std::vector<unsigned char> bytes = std::vector<unsigned char>(0x40000);
  r::Binding binding;
  std::size_t reads = 0, owner_reads = 0, frame_reads = 0, total_bytes = 0;
  std::uint64_t fail_at = 0;
  bool change_second_frame = false;
  static constexpr std::uint64_t base = 0x10000000, data = 0x4000;
  static constexpr std::size_t slot_index = 3;
  static constexpr std::uint64_t slot = data + sizeof(a::Header) + slot_index * sizeof(a::Slot);
  template<class T> void Put(std::uint64_t at, const T &value) {
    REQUIRE(at + sizeof value <= bytes.size());
    std::memcpy(bytes.data() + at, &value, sizeof value);
  }
  Fixture() {
    binding.module_path = "synthetic/xar_ck3_bridge.dll";
    binding.module_base = base; binding.module_size = bytes.size();
    IMAGE_DOS_HEADER dos{}; dos.e_magic = IMAGE_DOS_SIGNATURE; dos.e_lfanew = 0x80; Put(0,dos);
    IMAGE_NT_HEADERS64 nt{}; nt.Signature = IMAGE_NT_SIGNATURE;
    nt.FileHeader.Machine = IMAGE_FILE_MACHINE_AMD64; nt.FileHeader.NumberOfSections = 1;
    nt.FileHeader.SizeOfOptionalHeader = sizeof(IMAGE_OPTIONAL_HEADER64);
    nt.OptionalHeader.Magic = IMAGE_NT_OPTIONAL_HDR64_MAGIC;
    nt.OptionalHeader.SizeOfImage = static_cast<DWORD>(bytes.size()); nt.OptionalHeader.SizeOfHeaders = 0x400;
    nt.OptionalHeader.NumberOfRvaAndSizes = IMAGE_NUMBEROF_DIRECTORY_ENTRIES;
    nt.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT] = {0x1000,0x400}; Put(0x80,nt);
    IMAGE_SECTION_HEADER section{}; section.VirtualAddress = 0x3000; section.Misc.VirtualSize = 0x20000;
    section.Characteristics = IMAGE_SCN_MEM_READ | IMAGE_SCN_MEM_WRITE | IMAGE_SCN_CNT_INITIALIZED_DATA;
    Put(0x80 + sizeof nt,section);
    IMAGE_EXPORT_DIRECTORY exports{}; exports.NumberOfFunctions=1; exports.NumberOfNames=1;
    exports.AddressOfFunctions=0x1100; exports.AddressOfNames=0x1200; exports.AddressOfNameOrdinals=0x1300;
    Put(0x1000,exports); Put(0x1100,DWORD(data)); Put(0x1200,DWORD(0x1400)); Put(0x1300,WORD(0));
    std::memcpy(bytes.data()+0x1400,a::kExportName,sizeof a::kExportName);
    Put(data,a::kHeader);
  }
  bool operator()(std::uint64_t address, void *out, std::size_t count) {
    ++reads;total_bytes+=count;
    if (address < base || count > bytes.size() || address-base > bytes.size()-count || address==fail_at) return false;
    if (count==8 && address>=base+data+64 && address<base+data+sizeof(a::Directory)) ++owner_reads;
    if (address==base+slot && count==sizeof(a::Words)) ++frame_reads;
    std::memcpy(out,bytes.data()+address-base,count);
    if (change_second_frame && address==base+slot && count==sizeof(a::Words) && frame_reads==2)
      static_cast<a::Words *>(out)->at(a::sequence)+=2;
    return true;
  }
  bool Resolve() { std::string why;return r::ResolveFixedDataExport(*this,binding,why); }
  a::Words Active(std::uint64_t token=41) {
    a::Words w{};w[a::sequence]=2;w[a::owner_tid]=99;w[a::active]=1;
    w[a::invocation_token]=token;w[a::nesting_depth]=1;
    w[a::core_clock_identity]=7;w[a::natural_clock_identity]=7;
    w[a::core_entry_sequence]=9;w[a::natural_entry_sequence]=8;
    w[a::core_thread_id]=99;w[a::natural_thread_id]=99;w[a::date_raw]=53148912;
    w[a::manager_identity]=0x123000;w[a::secondary_manager_identity]=0x123008;
    w[a::game_state_identity]=0x456000;w[a::caller_return_rva]=0x2A9A8E2;
    w[a::natural_entry_rva]=0x2A9A570;w[a::entry_provenance_complete]=1;
    w[a::saved_mask02_admitted]=1;w[a::invocation_kind]=3;Put(slot,w);return w;
  }
};
int main() {
  {Fixture f;REQUIRE(f.Resolve());REQUIRE(f.total_bytes<=r::kMetadataBudget);
   REQUIRE(f.binding.export_rva==Fixture::data && f.binding.header==a::kHeader);
   const auto inactive=r::ReadSelected(f,f.binding,99);REQUIRE(!inactive.stable_active && inactive.owners_complete);
   f.Active();f.owner_reads=f.frame_reads=0;const auto x=r::ReadSelected(f,f.binding,99);
   REQUIRE(x.stable_active && x.slot_index==3 && f.owner_reads==16 && f.frame_reads==2);
   auto y=r::ReadSelected(f,f.binding,99);REQUIRE(r::SameActivePair(x,y,99));
   f.Active(42);y=r::ReadSelected(f,f.binding,99);REQUIRE(y.stable_active && !r::SameActivePair(x,y,99));}
  {Fixture f;f.Put(0x1100,DWORD(0x1010));REQUIRE(!f.Resolve());} // forwarder
  {Fixture f;f.Put(0x1100,DWORD(Fixture::data+1));REQUIRE(!f.Resolve());} // alignment
  {Fixture f;f.Put(0x80+offsetof(IMAGE_NT_HEADERS64,FileHeader)+offsetof(IMAGE_FILE_HEADER,Machine),WORD(IMAGE_FILE_MACHINE_I386));REQUIRE(!f.Resolve());}
  {Fixture f;f.Put(0x80+sizeof(IMAGE_NT_HEADERS64)+offsetof(IMAGE_SECTION_HEADER,Characteristics),DWORD(IMAGE_SCN_MEM_READ|IMAGE_SCN_MEM_EXECUTE|IMAGE_SCN_CNT_INITIALIZED_DATA));REQUIRE(!f.Resolve());}
  {Fixture f;auto bad=a::kHeader;bad[2]++;f.Put(Fixture::data,bad);REQUIRE(!f.Resolve());}
  {Fixture f;f.bytes[0x1400]='Y';REQUIRE(!f.Resolve());}
  {Fixture f;f.Put(0x1000+offsetof(IMAGE_EXPORT_DIRECTORY,NumberOfNames),DWORD(4097));REQUIRE(!f.Resolve());}
  {Fixture f;std::memset(f.bytes.data()+0x1400,'A',256);REQUIRE(!f.Resolve());}
  {Fixture f;REQUIRE(f.Resolve());auto w=f.Active();w[a::sequence]=3;f.Put(Fixture::slot,w);REQUIRE(!r::ReadSelected(f,f.binding,99).stable_active);}
  {Fixture f;REQUIRE(f.Resolve());f.Active();f.change_second_frame=true;const auto x=r::ReadSelected(f,f.binding,99);REQUIRE(x.first_complete && x.second_complete && !x.stable_active);}
  {Fixture f;REQUIRE(f.Resolve());f.Active();f.Put(Fixture::data+64+a::owner_tid*8,std::uint64_t(99));const auto x=r::ReadSelected(f,f.binding,99);REQUIRE(x.owner_matches==2 && !x.stable_active && !x.first_complete);}
  {Fixture f;REQUIRE(f.Resolve());f.Active();f.fail_at=Fixture::base+Fixture::slot;const auto x=r::ReadSelected(f,f.binding,99);REQUIRE(x.header_complete && !x.first_complete && !x.second_complete && !x.stable_active);}
  {Fixture f;REQUIRE(f.Resolve());f.Active();auto bad=a::kHeader;bad[0]++;f.Put(Fixture::data,bad);const auto x=r::ReadSelected(f,f.binding,99);REQUIRE(x.header_complete && x.first_complete && !x.stable_active);}
  std::cout<<"fixed exported carrier reader fixture: PASS (14 cases)\n";
}
