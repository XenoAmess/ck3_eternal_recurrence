// Synthetic carrier/common-TLS checks only. No Windows, game, DR or EXE input.
#include "xar_bridge/refill_core_carrier_12004.hpp"
#include "xar_bridge/ck3_12004_native_invocation_context.hpp"
#include <cassert>
#include <thread>

using namespace xar::ck3_12004;
namespace c = xar::ck3_12004::refill_carrier;
c::Words Payload(const NativeInvocationFrame12004 &scope, std::uint32_t tid) {
  c::Words w{};
  w[c::active] = 1; w[c::invocation_token] = scope.invocation_token;
  w[c::parent_invocation_token] = scope.parent_invocation_token.value_or(0);
  w[c::nesting_depth] = scope.nesting_depth;
  w[c::core_clock_identity] = w[c::natural_clock_identity] = 0x123400;
  w[c::core_entry_sequence] = 12; w[c::natural_entry_sequence] = 10;
  w[c::core_thread_id] = w[c::natural_thread_id] = tid;
  w[c::date_raw] = 53149656; w[c::manager_identity] = 0x100000;
  w[c::secondary_manager_identity] = 0x100008; w[c::game_state_identity] = 0x200000;
  w[c::caller_return_rva] = 0x2A9A8E2; w[c::natural_entry_rva] = 0x2A9A570;
  w[c::entry_provenance_complete] = w[c::saved_mask02_admitted] = 1;
  w[c::invocation_kind] = 3;
  return w;
}
int RunRefillCarrierChecks12004() {
  c::Directory d;
  assert(d.header == c::kHeader);
  assert(CurrentNativeInvocationContext12004() == nullptr);
  {
    NativeInvocationScope12004 outer(NativeInvocationParentKind12004::regular_refill_core, 11, nullptr);
    auto expected = Payload(outer.frame(), 11);
    c::Publication live(d, 11, expected);
    assert(live.published());
    auto a = c::LoadLocal(d.slots[0]);
    assert(c::StableActivePair(a, c::LoadLocal(d.slots[0]), 11));
    assert(a[c::invocation_token] == CurrentNativeInvocationContext12004()->invocation_token);
    {
      NativeInvocationScope12004 inner(NativeInvocationParentKind12004::regular_refill_core, 11, nullptr);
      c::Publication nested(d, 11, Payload(inner.frame(), 11));
      auto b = c::LoadLocal(d.slots[0]);
      assert(nested.published() && b[c::invocation_token] != a[c::invocation_token]);
      assert(b[c::parent_invocation_token] == a[c::invocation_token]);
      assert(!c::StableActivePair(a, b, 11));
    }
    auto restored = c::LoadLocal(d.slots[0]);
    assert(restored[c::invocation_token] == a[c::invocation_token]);
    assert(restored[c::sequence] > a[c::sequence]);
    {
      NativeInvocationScope12004 invalid(NativeInvocationParentKind12004::regular_refill_core, 11, nullptr);
      c::Publication hidden(d, 11, c::Words{});
      assert(!hidden.published());
      assert(!c::ValidActiveFrame(c::LoadLocal(d.slots[0]), 11));
    }
    assert(c::ValidActiveFrame(c::LoadLocal(d.slots[0]), 11));
    // Another native owner has a separate slot and cannot alter this payload.
    const auto before_other = c::LoadLocal(d.slots[0]);
    std::thread other([&] {
      NativeInvocationScope12004 scope(NativeInvocationParentKind12004::regular_refill_core, 22, nullptr);
      c::Publication separate(d, 22, Payload(scope.frame(), 22));
      assert(separate.published());
      assert(c::ValidActiveFrame(c::LoadLocal(d.slots[1]), 22));
    });
    other.join();
    assert(c::LoadLocal(d.slots[0]) == before_other);
    assert(!c::ValidActiveFrame(c::LoadLocal(d.slots[1]), 22));
    auto bad = before_other;
    bad[c::sequence] |= 1; assert(!c::StableActivePair(bad, bad, 11));
    bad = before_other; bad[c::active] = 0; assert(!c::StableActivePair(bad, bad, 11));
    bad = before_other; bad[c::invocation_token] = 0; assert(!c::StableActivePair(bad, bad, 11));
    assert(!c::StableActivePair(before_other, before_other, 22));
  }
  assert(CurrentNativeInvocationContext12004() == nullptr);
  assert(!c::ValidActiveFrame(c::LoadLocal(d.slots[0]), 11));
  // Full owner table and theoretical sequence exhaustion are fail closed.
  c::Directory full;
  for (std::size_t i = 0; i != c::kSlots; ++i) full.slots[i].words[c::owner_tid].store(i+1);
  c::Publication refused(full, 99, c::Words{}); assert(!refused.published());
  d.slots[0].words[c::sequence].store(UINT64_MAX-1);
  d.slots[0].words[c::active].store(1);
  { c::Publication exhausted(d, 11, c::Words{}); assert(!exhausted.published()); }
  assert(d.slots[0].words[c::sequence].load() == UINT64_MAX-1);
  assert(d.slots[0].words[c::active].load() == 0);
  return 0;
}
#if defined(XAR_REFILL_CARRIER_SYNTHETIC_DLL)
extern "C" __declspec(dllexport) int RunRefillCarrierFocused12004() {
  return RunRefillCarrierChecks12004();
}
#else
int main() { return RunRefillCarrierChecks12004(); }
#endif
