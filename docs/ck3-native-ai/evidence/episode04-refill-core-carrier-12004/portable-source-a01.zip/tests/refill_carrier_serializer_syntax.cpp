#include "xar_bridge/army_observed_phase_query_12004.hpp"
#include <string>
void CheckActualCoreSerializer() {
  xar::ck3_12004::ArmyRegularCoreObservation12004 event;
  event.native_core_invocation_token = 123;
  event.parent_invocation_token = 122;
  event.core_carrier_published = true;
  event.core_carrier_source_epoch = 20261018;
  std::string out;
  auto number = [](auto value) { return std::to_string(value); };
  auto string = [](std::string &target, std::string_view value) {
    target += '"'; target += value; target += '"';
  };
  xar::game::observed_assault_json_12004::CoreEvent(out, event, number, string);
}
