// Synthetic only: exercise the actual producer serializers and carrier, never Probe().
#define XAR_ENABLE_REFILL_ADD_HWPROBE_12004 0
#define wmain DisabledProbeEntryForSerializerFixture12004
#include "../candidate/ck3_autonomous_player/native_bridge/research/refill_add_hwprobe_12004.cpp"
#undef wmain
#include "xar_bridge/army_observed_phase_query_12004.hpp"
#include "xar_bridge/ck3_12004_native_invocation_context.hpp"
#include "army_natural_phase_json_12004.cpp"
#include <stdexcept>

using namespace xar::ck3_12004;
namespace abi = xar::ck3_12004::refill_carrier;
constexpr std::uint32_t Regi = 0x81000042U;
constexpr std::int32_t ArRg = static_cast<std::int32_t>(0x82000055U);
constexpr std::int32_t Army = static_cast<std::int32_t>(0x83000066U);
constexpr std::uintptr_t Clock = 0x8000000000000001ULL;
ArmyNaturalPhaseEvent12004 Event(std::uint64_t sequence) { return {Clock, sequence, 456}; }
ArmyRegularCoreOccurrence12004 Occurrence(std::int32_t id, std::uintptr_t pointer) {
  ArmyRegularCoreOccurrence12004 row;
  row.stored_index=0; row.raw_full_id=id; row.resolved_full_id=id;
  row.physical_token=pointer; row.used_fallback=false; return row;
}
ArmyRegularCoreFrame12004 Frame(std::int32_t current) {
  ArmyRegularCoreFrame12004 f;
  f.capture_complete=true;f.native_persistent_occurrence_count=1;f.native_army_refresh_occurrence_count=1;
  f.persistent_occurrences.push_back(Occurrence(static_cast<std::int32_t>(Regi),0x200000000));
  f.army_refresh_occurrences.push_back(Occurrence(Army,0x600000000));
  ArmyRegularCorePersistent12004 p;
  p.physical_token=0x200000000;p.resolved_full_id=static_cast<std::int32_t>(Regi);p.prepared_fraction_raw=100000;
  for(int i=0;i<7;++i){
    xar::game::ArmyOrderedRefillChunkV1 c;c.physical_index=i;c.current_soldiers=i==2?current:0;
    c.maximum_soldiers=100;c.owner_persistent_regiment_id=static_cast<std::int32_t>(Regi);
    c.q_ordinal_raw=5;c.army_regiment_id_raw=ArRg;c.state_raw=1;
    c.context_unavailable_reason="not required for raw closure";p.chunks.push_back(c);
  }
  f.persistent_objects.push_back(p);
  ArmyRegularCoreArmy12004 army;army.physical_token=0x600000000;army.resolved_full_id=Army;
  army.native_arrg_occurrence_count=1;
  ArmyRegularCoreArRg12004 arrg;arrg.occurrence=Occurrence(ArRg,0x500000000);
  arrg.resolved_magic_14_raw=0x41725267;arrg.native_refresh_admitted=true;
  arrg.native_loss_writer_skipped=false;arrg.native_record_count=1;arrg.records_complete=true;
  ArmyRegularCoreDataRecord12004 data;data.record_index=0;data.persistent_regiment_id=static_cast<std::int32_t>(Regi);
  data.chunk_index=2;data.persistent_physical_token=0x200000000;data.state_raw=1;data.native_record_admitted=true;
  arrg.records.push_back(data);army.arrg_occurrences.push_back(arrg);f.army_objects.push_back(army);return f;
}
ArmyRegularCoreObservation12004 Core() {
  ArmyRegularCoreObservation12004 e;e.journal_sequence=1;e.manager_identity=0x700000000;
  e.caller_return_rva=0x2A9A8E2;e.entry_date_raw=e.returned_date_raw=53148912;
  e.observed=e.original_called=e.original_returned=e.entry_provenance_complete=e.return_provenance_complete=true;
  e.entry_event=Event(20);e.returned_event=Event(30);e.entry=Frame(80);e.returned=Frame(90);
  auto &s=e.parent_scope;s.observed=true;s.phase=ArmyNaturalPhaseKind12004::post_date;
  s.actual_entry_rva=0x2A9A570;s.caller_return_rva=0x1234;s.primary_manager_identity=0x700000000;
  s.secondary_manager_identity=0x700000008;s.game_state_identity=0x800000000;
  s.entry_event=Event(10);s.date_raw=53148912;s.absolute_day_raw=1;s.entry_c0_raw=0;s.saved_c0_raw=std::nullopt;
  s.saved_mask02_admitted=true;s.saved_c0_observed_rva=0x2A9A8E2;s.saved_c0_event=Event(21);
  auto &r=s.original_army_roster;r.boundary=ArmyNaturalRosterBoundary12004::parent_entry;
  r.capture_rva=0x2A9A570;r.capture_event=Event(11);r.begin_identity=0x900000000;r.end_identity=0x900000004;
  r.count=1;r.complete=true;r.ordered_full_ids.push_back(static_cast<std::uint32_t>(Army));return e;
}
Hit Boundary(std::int32_t current,int site,const carrier::Capture &capture) {
  Hit h;h.site=site;h.tid=456;h.pointer=0x200000070;h.regi=0x200000000;h.rsp=0x300000000;
  h.iterator=0x400000000;h.qpc=100+site;h.core_caller=0x140001234;h.full_id=Regi;h.q_bits=10;
  h.current=current;h.maximum=100;h.q_index=5;h.slot=2;h.physical_complete=true;h.stack_q_source_complete=true;
  h.arrg_raw=h.arrg_resolved=ArRg;h.army_raw=h.army_resolved=Army;h.arrg_pointer=0x500000000;
  h.army_pointer=0x600000000;h.data_complete=true;h.data_count=1;h.data.push_back({Regi,2,Regi,2});
  const std::uint32_t maximum=100,q=10;const std::int32_t qi=5;
  std::memcpy(h.seven.data()+72,&maximum,4);std::memcpy(h.seven.data()+76,&current,4);
  std::memcpy(h.seven.data()+84,&qi,4);std::memcpy(h.seven.data()+88,&ArRg,4);
  std::memcpy(h.stack_q_window.data()+20,&q,4);h.core_carrier=capture;return h;
}
extern "C" __declspec(dllexport) int WriteRefillCarrierWireSynthetic12004(
    const wchar_t *hits_path,const wchar_t *core_path,const wchar_t *metadata_path) {
  try {
    auto e=Core();abi::Directory directory;
    {
      NativeInvocationScope12004 scope(NativeInvocationParentKind12004::regular_refill_core,456,&e);
      const auto &f=scope.frame();e.native_core_invocation_token=f.invocation_token;
      e.parent_invocation_token=f.parent_invocation_token;e.core_invocation_nesting_depth=f.nesting_depth;
      abi::Words p{};p[abi::active]=1;p[abi::invocation_token]=f.invocation_token;
      p[abi::parent_invocation_token]=f.parent_invocation_token.value_or(0);p[abi::nesting_depth]=f.nesting_depth;
      p[abi::core_clock_identity]=p[abi::natural_clock_identity]=Clock;p[abi::core_entry_sequence]=20;
      p[abi::natural_entry_sequence]=10;p[abi::core_thread_id]=p[abi::natural_thread_id]=456;
      p[abi::date_raw]=53148912;p[abi::manager_identity]=0x700000000;p[abi::secondary_manager_identity]=0x700000008;
      p[abi::game_state_identity]=0x800000000;p[abi::caller_return_rva]=0x2A9A8E2;
      p[abi::natural_entry_rva]=0x2A9A570;p[abi::entry_provenance_complete]=p[abi::saved_mask02_admitted]=1;
      p[abi::invocation_kind]=3;abi::Publication published(directory,456,p);
      if(!published.published())return 2;e.core_carrier_published=true;e.core_carrier_source_epoch=abi::kSourceEpoch;
      g_core_carrier.module_path="D:/constructed/xar_ck3_bridge.dll";g_core_carrier.module_base=0x180000000;
      g_core_carrier.export_rva=0x10000;g_core_carrier.directory_address=0x180010000;g_core_carrier.header=abi::kHeader;
      carrier::Capture capture;capture.attempted=capture.owners_complete=capture.header_complete=true;
      capture.first_complete=capture.second_complete=capture.stable_active=true;capture.owner_matches=1;
      capture.slot_index=0;capture.slot_address=0x180010040;capture.header=abi::kHeader;
      capture.first=capture.second=abi::LoadLocal(directory.slots[0]);capture.diagnostic="stable_active";
      std::vector<Hit> hits{Boundary(80,0,capture),Boundary(90,1,capture)};
      if(!PairIsUnique(hits))return 3;
      g_machine="constructed-not-live";std::ofstream out(std::filesystem::path(hits_path),std::ios::binary);
      for(std::size_t i=0;i<hits.size();++i){g_debug_hits=10+i;LogHit(out,hits[i],123,i+1);}
      out.close();if(!out)return 4;
      std::ofstream metadata(std::filesystem::path(metadata_path),std::ios::binary);
      metadata<<"{\"synthetic_scope\":true";LogCarrierMetadata(metadata,true);metadata<<"}\n";metadata.close();if(!metadata)return 5;
    }
    if(abi::LoadLocal(directory.slots[0])[abi::active]!=0)return 6;
    std::string wire;
    const auto number=[](auto n){return std::to_string(n);};
    const auto text=[](std::string &out,std::string_view s){out+=JsonString(std::string(s));};
    xar::game::observed_assault_json_12004::CoreEvent(wire,e,number,text);
    std::ofstream out(std::filesystem::path(core_path),std::ios::binary);out<<wire<<'\n';out.close();return out?0:7;
  } catch (...) { return 8; }
}
