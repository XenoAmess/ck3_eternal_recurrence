"""Portable math/source audit of retained small evidence; never reads full packets."""
from pathlib import Path
import argparse
import json
import sys

def need(ok,why):
 if not ok:raise ValueError(why)

def audit(root,repo):
 sys.path.insert(0,str(repo/'ck3_autonomous_player/src'))
 from xar_autoplayer.bridge.army_county_entry_loss_evidence_12004 import _RETURN_SOURCES
 original=json.loads((root/'ORIGINAL-SMALL.exact.json').read_bytes())
 small=json.loads((root/'SMALL-INPUTS.actual.json').read_bytes())
 leaf=json.loads((root/'ARRIVAL-MISSING-WRITER-LEAF.actual.json').read_bytes())
 fixed=json.loads((root/'ARRIVAL-FIXED-COUNTERS.actual.json').read_bytes())
 ev=original['writer_verdict']['events'];raw=leaf['events'];before=small['writer_fences'];family=fixed['actual_loss_writer_family']
 need(len(ev)==len(raw)==23,'Actual retained event count changed')
 need([e['sequence'] for e in ev]==list(range(1192,1215)),'Actual sequence set changed')
 for a,b in zip(ev,raw):
  for k in ['sequence','army_regiment_id','observed_date_raw','caller_return_rva','request_raw','actual_physical_soldier_debit']:
   need(a[k]==b[k],'Derived verdict and captured normalized leaf disagree: '+k)
  need(a['writer_request_source']==_RETURN_SOURCES.get(b['caller_return_rva']),'Production caller mapping disagrees')
 need({e['caller_return_rva'] for e in ev}=={0x24E25EE},'Unexpected actual caller')
 need(all(e['physical_evidence_qualified'] and e['dated_evidence_ready'] for e in ev),'Producer verdict qualification changed')
 need(before==dict(latest_sequence=0,oldest_available_sequence=0,overwritten_events=0,unattributed_capture_failures=0),'Actual baseline cursor changed')
 need(family['oldest_available_sequence']==872 and family['latest_sequence']==1383 and family['overwritten_events']==871,'Actual ring counters changed')
 need(family['unattributed_capture_failures']==0 and family['observer_installed'] is True,'Failure or installation state changed')
 need(original['writer_verdict']['reasons']==['requested_window_overwritten'],'Different incompleteness reason')
 need(before['latest_sequence']<family['oldest_available_sequence']-1,'Source coverage rejection does not follow')
 need(all(family['oldest_available_sequence']<=e['sequence']<=family['latest_sequence'] for e in ev),'Retained selected invocation outside range')
 values=[e['actual_physical_soldier_debit'] for e in ev]
 need(sum(v>0 for v in values)==17 and sum(v==0 for v in values)==6 and sum(values)==236,'Actual physical values changed')
 endpoint=original['endpoint_unique_physical']
 need(endpoint['before_current']==6741 and endpoint['after_current']==6505 and endpoint['unique_net_current']==-236,'Endpoint physical sum changed')
 need(small['baseline_county']['whole_soldiers']==6746 and small['baseline_county']['current_loss_budget']==236,'Cached layer/baseline budget changed')
 need(leaf['deduplicated_exact_parent_values']==[] and fixed['optional_parent_fields']=={},'Actual writer has a parent field requiring further audit')
 need(not any(any(s in k for s in ['parent','phase','invocation','thread']) for k in leaf['common_event_keys']),'Writer native DTO has a potential join key')
 need(leaf['selected_row']['army_id']==0 and leaf['selected_row']['native_carmy_id']==0,'Army0/native0 query binding changed')
 return dict(status='PASS_SMALL_MATH_AND_ACTUAL_FIELD_SOURCE_AUDIT',
   retained_county_primary_qualified_dated_invocations=23,positive_invocations=17,zero_invocations=6,
   actual_retained_physical_debit=236,caller_return_rva='0x24E25EE',observed_dates=[53147544],
   native_writer_schema_parent_thread_or_invocation_fields=[],
   baseline_global_cursor=0,after_global_oldest=872,after_global_latest=1383,global_overwritten=871,
   global_retained_nonmatching_current_roster_events=512-23,
   all_23_reported_matching_events_within_retained_range=True,selected_complete_history_unknown=True,
   same_army_at_invocation_observed=False,complete_county_army_total=None,
   full_physical_raw_reverification=False,producer_physical_qualification_reused=True,
   original_full_reads_this_verifier=0,SDK_calls=0,R04_entire_card_closed_by_this_audit=False)

def main():
 p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--output',type=Path)
 a=p.parse_args();result=audit(a.root,a.repo)
 if a.output:
  with a.output.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps(result));return 0

if __name__=='__main__':raise SystemExit(main())
