"""Root-approved corrected scope: one .text read, independent opcode starts."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, sys
H=Path(__file__).parent
R=Path('D:/workspace/ck3_eternal_recurrence')
E=Path('C:/SteamLibrary/steamapps/common/Crusader Kings III/binaries/ck3.exe')
TARGET=0x44DB128
SHA='98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518'
sys.path.insert(0,str(R/'tools'))
from ck3_live_run_id import current_machine_id
def need(ok,msg):
    if not ok:raise ValueError(msg)
def pin(name):
    b=(H/name).read_bytes()
    return dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(name,obj):
    with (H/name).open('x',encoding='utf-8',newline='\n') as f:
        json.dump(obj,f,indent=2);f.write('\n')
def stamp():
    s=E.stat()
    return dict(bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,device=s.st_dev,inode=s.st_ino)
def locate(data,section_rva,target):
    hits=[];tested=0
    for opcode in (b'\x8b',b'\x8d'):
        pos=data.find(opcode)
        while pos!=-1:
            if pos+6<=len(data) and data[pos+1] in (5,13,21,29,37,45,53,61):
                tested+=1
                displacement=int.from_bytes(data[pos+2:pos+6],'little',signed=True)
                if section_rva+pos+6+displacement==target:
                    hits.append(pos)
            pos=data.find(opcode,pos+1)
    return sorted(hits),tested
old=json.loads((H/'NAMED-RIP.actual.json').read_bytes())
corr=json.loads((H/'NAMED-RIP-COVERAGE-CORRECTION.actual.json').read_bytes())
plan=json.loads((H/'PLAN.before-overlap-complete-RIP.json').read_bytes())
check=json.loads((H/'CHECK-RENDER.before-overlap-complete-RIP.actual.json').read_bytes())
machine=current_machine_id()
need(pin('PLAN.before-overlap-complete-RIP.json')['sha256']=='b478da86964a698b2924a2c41dd43510eb739a13140f69c3cf950523365d99f4','Plan changed')
need(all(v['exit_code']==0 for v in check['results']),'Prior ordinary check/render failed')
need(machine==old['machine_id']==corr['machine_id']==plan['machine_id'],'Machine changed')
need(old['exe_sha256_reused']==plan['build']['exe_sha256']==SHA,'Image pin')
syn=corr['synthetic']
got,_=locate(bytes.fromhex(syn['bytes_hex']),int(syn['section_rva'],16),int(syn['target_rva'],16))
need(got==syn['independent_matching_opcode_starts']==[3],'Overlap counterexample failed before EXE read')
first=b'\x8d\x05'+(0x20-6).to_bytes(4,'little',signed=True)
need(locate(first,0,0x20)[0]==[0],'First/last possible opcode boundary failed')
before=stamp();need(before==old['stat_before']==old['stat_after'],'Actual EXE identity changed')
s=old['section'];need(s['name']=='.text' and s['raw_size']==71141888,'Exact section')
approved=dict(machine_id=machine,at_utc=datetime.now(timezone.utc).isoformat(),source='Root task message delivered to /root/e04_r08_maintenance_next',scope='One additional same.text71141888B read; every8B/8D opcode independently; only44DB128 target; no new strings/callee/body/hash',cumulative_sections_bytes=176532480,cumulative_reads=8,body_bytes=0,package_ceiling_bytes=131072,old_coverage_defect_preserved=True)
write('SCOPE4-APPROVAL.actual.json',approved)
with E.open('rb') as f:
    f.seek(s['raw_offset']);data=f.read(s['raw_size'])
need(len(data)==71141888 and stamp()==before,'Short read or image changed')
positions,tested=locate(data,s['rva'],TARGET)
sites=[]
for pos in positions[:16]:
    begin=max(0,pos-32);ctx=data[begin:min(len(data),begin+96)]
    previous_rex=pos>0 and 0x40<=data[pos-1]<=0x4f
    sites.append(dict(opcode_rva=f'{s["rva"]+pos:X}',opcode_form='MOV_r_riprel' if data[pos]==0x8b else 'LEA_r_riprel',opcode_bytes=data[pos:pos+6].hex(),opcode_length=6,computed_target_rva=f'{TARGET:X}',preceding_REX_byte=f'{data[pos-1]:02x}' if previous_rex else None,preceding_REX_is_instruction_prefix_unproved=True if previous_rex else None,instruction_boundary_proved=False,function_boundary_proved=False,proof_level='RAW_BYTE_LOCATOR_ONLY',context_rva=f'{s["rva"]+begin:X}',context_bytes=len(ctx),context_hex=ctx.hex(),context_sha256=hashlib.sha256(ctx).hexdigest()))
out=dict(schema='xar.e04.r08.GetCurrency-only-overlap-complete-RIP-locator.v1',machine_id=machine,observed_at_utc=datetime.now(timezone.utc).isoformat(),source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),exe_sha256_reused=SHA,stat_before=before,stat_after=stamp(),old_result_pin=pin('NAMED-RIP.actual.json'),coverage_correction_pin=pin('NAMED-RIP-COVERAGE-CORRECTION.actual.json'),plan_pin=pin('PLAN.before-overlap-complete-RIP.json'),approval_pin=pin('SCOPE4-APPROVAL.actual.json'),target_name='GetCurrency',target_literal_rva='44DB128',section=s,new_scope_read_ledger=[dict(file_offset=s['raw_offset'],bytes=len(data),kind='GetCurrency_only_independent_opcode_RIP_locator')],new_scope_reads=1,new_scope_text_bytes=len(data),new_scope_metadata_bytes=0,body_source_bytes=0,cumulative_sections_bytes=old['cumulative_sections_bytes']+len(data),cumulative_metadata_bytes=old['cumulative_metadata_bytes'],cumulative_reads=old['cumulative_reads']+1,total_tested_mod00_rm101_opcode_starts=tested,total_candidates=len(positions),sites=sites,truncated=len(positions)>len(sites),matcher_scope='Every8B/8D opcode independently tested, ModRMmod00/rm101; opcodeRVA+6+signedDisp32==44DB128; optional precedingREX recorded only as unproved context',negative_limit='Zero covers this raw8B/8D+ModRM family only; other instruction forms, data tables and registration remain open.',whole_EXE_hashes=0,new_game_SDK_desktop_build_actions=0,registration_handler_or_resource_enum_confirmed=False,resource4_business_name=None,paid_military_amount_raw=None,cadence=None)
need(out['cumulative_sections_bytes']==176532480 and out['cumulative_reads']==8,'Cumulative approved budget')
write('NAMED-RIP.overlap-complete.actual.json',out)
package_bytes=sum(p.stat().st_size for p in H.iterdir() if p.is_file())
need(package_bytes<=131072,'Package ceiling')
print(json.dumps(dict(result_pin=pin('NAMED-RIP.overlap-complete.actual.json'),candidate_count=len(positions),tested_starts=tested,sites=sites,new_scope_bytes=len(data),cumulative_sections_bytes=out['cumulative_sections_bytes'],package_bytes=package_bytes)))
