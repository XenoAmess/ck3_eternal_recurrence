"""Third approved scope: one .text read, only GetCurrency named RIP candidates."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,subprocess,sys
R=Path('D:/workspace/ck3_eternal_recurrence');H=Path(__file__).parent
E=Path('C:/SteamLibrary/steamapps/common/Crusader Kings III/binaries/ck3.exe')
SHA='98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518';TARGET=0x44DB128
sys.path.insert(0,str(R/'tools'))
from ck3_live_run_id import current_machine_id
def need(ok,msg):
 if not ok:raise ValueError(msg)
def pin(p):
 b=p.read_bytes();return dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(n,o):
 with (H/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(o,f,indent=2);f.write('\n')
lp=H/'LITERALS.actual.json';qp=H/'QWORD-REFS.actual.json';l=json.loads(lp.read_bytes());q=json.loads(qp.read_bytes());machine=current_machine_id()
need(pin(lp)['sha256']=='af76ea5a7e69ea52048dc6ed80e6c78de7244e19ed02346a8f095cf378e47121','Literal pin changed')
need(pin(qp)['sha256']=='b2903c63f08fcc6d5a3e59e7beae4214c54f54bc3ec273974a058fed3716da79','Second scope pin changed')
need(l['machine_id']==q['machine_id']==machine and l['exe_sha256_reused']==q['exe_sha256_reused']==SHA,'Machine/image pin')
plan=dict(schema='xar.native-research-plan.v1',topic='e04-GetCurrency-only-named-RIP-locator',machine_id=machine,created_at_utc=datetime.now(timezone.utc).isoformat(),question='Which raw .text LEA/MOV RIP-relative byte patterns target exactly the already-held GetCurrency44DB128 literal?',purpose='engine-transition',build=dict(version='1.20.0.4/Steam25734779',exe_sha256=SHA),
 observation=dict(mode='offline-only',actor_kind='engine',owner_scope='Third Root-approved locator only; one.text read, one exact target, no new string or callee/body expansion',identity_kind='definition-key',identity_lifetime='Exact image and same native file identity; preferred offsets not runtime frame',producer_trigger='not-applicable',producer='Raw LEA/MOV candidate site; function/instruction boundaries still unknown',caller='Unknown named registration wrapper; previous .rdata GetCurrencyQWORD refs0',consumer='Potential named GetCurrency registration/handler route, not actual selector mapping',cache_lifetime='Static locator bytes only',expected_signal='<=16sites/96B each with computed RIP target44DB128; no semantic proof from raw candidate',zero_sample_meaning='Zero means no matching retained byte pattern in this one.text scope; not no native registration or absent currency',stop_condition='Single71141888B.text read, one read; cumulative105390592B sections<128MiB; no callee/hash/body expansion; output<=131072B',runtime_window_ref=None),
 evidence=[dict(id='literal',layer='locator',path='LITERALS.actual.json',sha256=pin(lp)['sha256'],exe_sha256=SHA,supports='Unique exact GetCurrency literal44DB128'),dict(id='data',layer='locator',path='QWORD-REFS.actual.json',sha256=pin(qp)['sha256'],exe_sha256=SHA,supports='No same.rdata QWORD data reference for GetCurrency; need explicit named RIP locator')],
 nodes=[dict(id='name',label='GetCurrency44DB128'),dict(id='site',label='Raw RIP LEA/MOV candidate'),dict(id='function',label='Instruction/function boundary UNKNOWN')],
 edges=[dict(id='xref',**{'from':'site','to':'name'},label='Exact computed RIP target byte locator',status='unknown',evidence=['literal','data'],open_question='Any matching target-only LEA/MOV pattern?'),dict(id='boundary',**{'from':'site','to':'function'},label='No source boundary proof yet',status='unknown',evidence=['literal'],open_question='Use genuine site to locate containing.pdata and decode from function entry later')],
 cases=[dict(id='static',question='Named RIP site location',status='pending',evidence=['literal']),dict(id='live',question='Resource/player/payment',status='not-applicable',evidence=[],reason='No game/SDK/desktop/build in this locator')])
write('PLAN.before-named-RIP.json',plan)
argv=[sys.executable,'-B',str(R/'tools/native_research_plan.py'),'check',str(H/'PLAN.before-named-RIP.json')]
run=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8')
write('CHECK.before-named-RIP.actual.json',dict(machine_id=machine,at_utc=datetime.now(timezone.utc).isoformat(),argv=argv,exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr,plan_sha256=pin(H/'PLAN.before-named-RIP.json')['sha256']))
need(run.returncode==0,'Ordinary check failed; no read')
def stamp():
 s=E.stat();return dict(bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,device=s.st_dev,inode=s.st_ino)
before=stamp();need(before==l['stat_before']==l['stat_after']==q['stat_before']==q['stat_after'],'Actual file identity changed')
sections=[s for s in l['sections'] if s['name']=='.text'];need(len(sections)==1 and sections[0]['raw_size']==71141888,'Exact.text dimensions')
s=sections[0]
with E.open('rb') as f:f.seek(s['raw_offset']);data=f.read(s['raw_size'])
need(len(data)==71141888 and stamp()==before,'Short read or changed image')
pattern=re.compile(rb'[\x40-\x4f]?[\x8b\x8d][\x05\x0d\x15\x1d\x25\x2d\x35\x3d][\s\S]{4}')
sites=[];count=0
for match in pattern.finditer(data):
 raw=match.group(0);rva=s['rva']+match.start();computed=rva+len(raw)+int.from_bytes(raw[-4:],'little',signed=True)
 if computed!=TARGET:continue
 count+=1
 if len(sites)>=16:continue
 start=max(0,match.start()-32);ctx=data[start:min(len(data),start+96)]
 sites.append(dict(candidate_rva=f'{rva:X}',candidate_bytes=raw.hex(),candidate_length=len(raw),computed_target_rva=f'{computed:X}',instruction_boundary_proved=False,function_boundary_proved=False,proof_level='RAW_BYTE_LOCATOR_ONLY',context_rva=f'{s["rva"]+start:X}',context_bytes=len(ctx),context_hex=ctx.hex(),context_sha256=hashlib.sha256(ctx).hexdigest()))
out=dict(schema='xar.e04.r08.GetCurrency-only-named-RIP-locator.v1',machine_id=machine,observed_at_utc=datetime.now(timezone.utc).isoformat(),source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),exe_sha256_reused=SHA,literal_pin=pin(lp),previous_data_scope_pin=pin(qp),stat_before=before,stat_after=stamp(),target_literal_rva='44DB128',target_name='GetCurrency',section=s,new_scope_read_ledger=[dict(file_offset=s['raw_offset'],bytes=len(data),kind='GetCurrency_only_RIP_LEA_MOV_byte_locator')],new_scope_text_bytes=len(data),new_scope_metadata_bytes=0,new_scope_reads=1,body_source_bytes=0,cumulative_sections_bytes=q['cumulative_first_and_second_locator_bytes']+len(data),cumulative_metadata_bytes=q['cumulative_metadata_bytes'],cumulative_reads=q['cumulative_reads']+1,total_candidates=count,sites=sites,truncated=count>len(sites),whole_EXE_hashes=0,new_game_SDK_desktop_build_actions=0,registration_handler_or_resource_enum_confirmed=False,resource4_business_name=None,paid_military_amount_raw=None,cadence=None)
need(out['cumulative_sections_bytes']==105390592 and out['cumulative_sections_bytes']<134217728,'Cumulative read budget')
write('NAMED-RIP.actual.json',out)
need(sum(p.stat().st_size for p in H.iterdir() if p.is_file())<=131072,'Package output ceiling')
print(json.dumps(dict(candidates=count,sites=sites,new_scope_bytes=len(data),new_scope_reads=1,cumulative_sections_bytes=out['cumulative_sections_bytes'],boundary_proved=False)))
