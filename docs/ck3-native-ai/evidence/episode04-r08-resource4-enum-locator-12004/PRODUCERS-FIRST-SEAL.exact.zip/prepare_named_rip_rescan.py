"""Prepare/check/render a corrected target-only plan; no EXE access."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, sys
H=Path(__file__).parent
R=Path('D:/workspace/ck3_eternal_recurrence')
def pin(name):
    b=(H/name).read_bytes()
    return dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(name,value):
    with (H/name).open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,indent=2);f.write('\n')
p=json.loads((H/'PLAN.before-named-RIP.json').read_bytes())
p['topic']='e04-GetCurrency-only-overlap-complete-RIP-locator'
p['created_at_utc']=datetime.now(timezone.utc).isoformat()
p['question']='Which independent raw 8B/8D opcode starts in .text target exactly GetCurrency44DB128?'
o=p['observation']
o['owner_scope']='Proposed corrected locator only; requires Root approval of additional71141888B before execution. This preparation does not access EXE.'
o['producer']='Every8B/8D opcode independently tested for RIPrelative mod00/rm101 and exact target; prior optionalREX byte is context. No function/instruction boundary proof.'
o['expected_signal']='At most16rawsites/96B each; duplicate prefixed/unprefixed starts not created; no overlapping opcode skipped.'
o['zero_sample_meaning']='Zero can cover the specified independent8B/8D raw pattern family only, not other instructions/tables/absence of registration.'
o['stop_condition']='Proposed single71141888B .text read; cumulative176532480B sections,608B metadata,8reads; output<=131072B; no callee or new name; not executed by this preparation.'
p['evidence'].append(dict(id='coverage-correction',layer='locator',path='NAMED-RIP-COVERAGE-CORRECTION.actual.json',sha256=pin('NAMED-RIP-COVERAGE-CORRECTION.actual.json')['sha256'],exe_sha256=p['build']['exe_sha256'],supports='Prior matcher cannot prove full negative; synthetic overlapping counterexample without EXE read.'))
p['edges'][0]['evidence'].append('coverage-correction')
p['edges'][0]['label']='Exact target from every independent opcode start, boundary unknown'
write('PLAN.before-overlap-complete-RIP.json',p)
results=[]
for command in ('check','render'):
    argv=[sys.executable,'-B',str(R/'tools/native_research_plan.py'),command,str(H/'PLAN.before-overlap-complete-RIP.json')]
    if command=='render':argv+=['--output',str(H/'GRAPH.overlap-complete-RIP-plan.md')]
    r=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8')
    results.append(dict(argv=argv,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
    if r.returncode:raise ValueError('Ordinary'+command+'failed')
write('CHECK-RENDER.before-overlap-complete-RIP.actual.json',dict(machine_id=p['machine_id'],at_utc=datetime.now(timezone.utc).isoformat(),plan_pin=pin('PLAN.before-overlap-complete-RIP.json'),exe_reads=0,results=results))
print(json.dumps(dict(prepared=True,exe_reads=0,plan=pin('PLAN.before-overlap-complete-RIP.json'),package_bytes=sum(f.stat().st_size for f in H.iterdir() if f.is_file()))))
