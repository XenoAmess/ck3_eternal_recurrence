"""No EXE access: preserve a demonstrated scope-3 matcher coverage defect."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re
H = Path(__file__).parent

def need(ok, msg):
    if not ok:
        raise ValueError(msg)

def pin(name):
    data = (H / name).read_bytes()
    return dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

prior = json.loads((H / 'NAMED-RIP.actual.json').read_bytes())
target, section_rva, real_offset = 0x44DB128, 0x1000, 2
real = b'\x48\x8d\x05' + (target - (section_rva + real_offset + 7)).to_bytes(4, 'little', signed=True)
synthetic = b'\x8b\x05' + real + b'\x90' * 16
pattern = re.compile(rb'[\x40-\x4f]?[\x8b\x8d][\x05\x0d\x15\x1d\x25\x2d\x35\x3d][\s\S]{4}')
old = []
for match in pattern.finditer(synthetic):
    raw = match.group(0)
    if section_rva + match.start() + len(raw) + int.from_bytes(raw[-4:], 'little', signed=True) == target:
        old.append(match.start())
overlapping = []
for pos in range(len(synthetic) - 5):
    if synthetic[pos] not in (0x8b, 0x8d) or synthetic[pos + 1] not in (5, 13, 21, 29, 37, 45, 53, 61):
        continue
    if section_rva + pos + 6 + int.from_bytes(synthetic[pos + 2:pos + 6], 'little', signed=True) == target:
        overlapping.append(pos)
need(old == [], 'Counterexample no longer demonstrates old matcher defect')
need(overlapping == [3], 'Independent opcode-start matcher missed exact synthetic target')
out = dict(schema='xar.e04.r08.named-RIP-coverage-correction.v1', machine_id=prior['machine_id'],
    observed_at_utc=datetime.now(timezone.utc).isoformat(), original_result_pin=pin('NAMED-RIP.actual.json'),
    original_producer_pin=pin('run_named_rip_locator.py'), exe_reads=0, new_exe_bytes=0,
    conclusion='The non-overlapping re.finditer implementation can skip a genuine overlapping raw RIP opcode start. Its zero cannot establish complete absence within .text.',
    retained_original_unchanged=True, corrected_result_from_actual_EXE=None,
    synthetic=dict(bytes_hex=synthetic.hex(), section_rva=hex(section_rva), target_rva=hex(target),
        intended_prefixed_start=2, old_matching_target_starts=old, independent_matching_opcode_starts=overlapping),
    next_algorithm='Inspect every 8B/8D opcode byte independently, check mod00/rm101, compute opcode_RVA+6+signed_disp32; optional previous REX is context, not a reason to skip any opcode start.',
    limits='Synthetic proof only. No new EXE read; original .text section bytes were not retained. Original cumulative section ledger remains105390592B.')
with (H / 'NAMED-RIP-COVERAGE-CORRECTION.actual.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(out, f, indent=2)
    f.write('\n')
print(json.dumps(dict(correction=pin('NAMED-RIP-COVERAGE-CORRECTION.actual.json'), synthetic_old_target_matches=old, synthetic_independent_opcode_matches=overlapping, new_exe_bytes=0)))
