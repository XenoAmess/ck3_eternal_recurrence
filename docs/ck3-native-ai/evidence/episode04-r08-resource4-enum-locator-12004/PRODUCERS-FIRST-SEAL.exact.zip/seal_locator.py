"""Seal small portable locator artifacts; no EXE/game/source-tree access."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
H=Path(__file__).parent
def pin(p):
    b=p.read_bytes();return dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(name,value):
    with (H/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def read(name):return json.loads((H/name).read_bytes())
l=read('LITERALS.actual.json');q=read('QWORD-REFS.actual.json');old=read('NAMED-RIP.actual.json');rip=read('NAMED-RIP.overlap-complete.actual.json');d=read('DATA-QWORD-REFS.actual.json')
source=dict(schema='xar.e04.r08.resource4-name-locator-source.v1',machine_id=l['machine_id'],sealed_at_utc=datetime.now(timezone.utc).isoformat(),source_head=l['source_head'],exe_sha256_reused=l['exe_sha256_reused'],qualification_identity_sha256_reused=l['identity_pin_sha256'],qualification_layer='Previously qualified SHA reused, actual file stat identity compared before/after all scopes; no current whole hash.',
    scope='Only three named UTF8/UTF16 literals in.rdata; two pinned QWORD VAs in.rdata/.data; GetCurrency target-only8B/8D RIP raw locator in.text. No function body or handler/native-enum binding.',
    actual_findings=['Unique standalone GetCurrency44DB128 and barter_goods450BB80 in.rdata. Other barter_goods suffix hits are explicitly labelled.',
    '.rdata contains one QWORD pointer to standalone barter_goods at46FC9F8; adjacent rawQWORD0x3E2D is a token ID observation, not selector4.',
    'Initial non-overlap RIP matcher returned0 but has a proven overlapping coverage defect. Original immutable result and correction retained.',
    'Approved independent-opcode corrected matcher tested693550 candidate8B/8D+mod00/rm101 starts; target44DB128 matches0.',
    'Approved.data8571392B QWORD scan found0 for both pinned literalVAs. No further EXE section or matcher expansion.'],
    limits=['Negative results describe explicitly bounded collector/matcher scopes. Whole sections were not retained; portable verifier verifies small retained bytes/hashes/ledgers and synthetic correction, not fresh full-section absence.',
    'Raw pointer/token/string proximity does not name selector4/context+4A0. Player-wallet same-slot mapping, authoritative enum mapping, paid amount, payer and cadence remain unproved.',
    'No live business claim, game/SDK/desktop/build action, main-tree write or whole-EXE hash in this package. Historical local observations only apply to recorded machine/time.'],
    all_EXE_read_ledger=l['read_ledger']+q['read_ledger']+old['new_scope_read_ledger']+rip['new_scope_read_ledger']+d['read_ledger'],
    sections_read_bytes=185103872,metadata_read_bytes=608,read_calls=9,body_source_bytes=0,
    next_testable_edge='Need independently located named GetCurrency or HasBarterGoods registrar/handler, or another authority binding native rawselector4 to name. Do not assume ten-slotvector ordering or token0x3E2D equals rawselector4.',
    resource4_business_name=None,player_same_wallet_slot_confirmed=False,paid_military_amount_raw=None,payer=None,cadence=None,
    files=[pin(p) for p in sorted(H.iterdir()) if p.is_file()])
write('SOURCE.actual.json',source)
argv=[sys.executable,'-B','-O',str(H/'verify_portable.py'),str(H)]
r=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
write('VERIFY.actual.json',dict(machine_id=l['machine_id'],at_utc=datetime.now(timezone.utc).isoformat(),argv=argv,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr,source_pin=pin(H/'SOURCE.actual.json')))
if r.returncode:raise ValueError('Portable verifier failed')
write('DELIVERY.actual.json',dict(machine_id=l['machine_id'],at_utc=datetime.now(timezone.utc).isoformat(),source=pin(H/'SOURCE.actual.json'),verify=pin(H/'VERIFY.actual.json'),result_scope5=pin(H/'DATA-QWORD-REFS.actual.json'),whole_EXE_hashes=0,body_bytes=0,main_tree_writes=0,closed_business_mapping=False))
size=sum(p.stat().st_size for p in H.iterdir() if p.is_file())
if size>131072:raise ValueError('Output ceiling exceeded:'+str(size))
print(json.dumps(dict(source=pin(H/'SOURCE.actual.json'),delivery=pin(H/'DELIVERY.actual.json'),package_bytes=size,verifier_exit=r.returncode,verifier_stdout=r.stdout)))
