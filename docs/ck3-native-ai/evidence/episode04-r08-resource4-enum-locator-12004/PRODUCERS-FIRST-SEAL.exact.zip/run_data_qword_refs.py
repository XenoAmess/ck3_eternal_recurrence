"""Second explicitly approved scope: same .rdata, only two literal VA QWORDs."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
R=Path('D:/workspace/ck3_eternal_recurrence');H=Path(__file__).parent
E=Path('C:/SteamLibrary/steamapps/common/Crusader Kings III/binaries/ck3.exe')
SHA='98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518'
sys.path.insert(0,str(R/'tools'))
from ck3_live_run_id import current_machine_id
def need(ok,msg):
 if not ok:raise ValueError(msg)
def write(n,o):
 with (H/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(o,f,indent=2);f.write('\n')
def pin(p):
 b=p.read_bytes();return dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
lp=H/'LITERALS.actual.json';lb=lp.read_bytes();l=json.loads(lb)
need(hashlib.sha256(lb).hexdigest()=='af76ea5a7e69ea52048dc6ed80e6c78de7244e19ed02346a8f095cf378e47121','Literal packet changed')
machine=current_machine_id();need(l['machine_id']==machine and l['exe_sha256_reused']==SHA,'Machine/image identity')
targets=[dict(name='GetCurrency',literal_rva=0x44DB128),dict(name='barter_goods',literal_rva=0x450BB80)]
for t in targets:
 matches=[x for x in l['output_hits'] if x['name']==t['name'] and x['literal_rva']==t['literal_rva'] and x['encoding']=='utf-8' and x['preceding_null_or_section_start']]
 need(len(matches)==1,'Exact target literal not held');t['preferred_VA']=l['image_base_preferred']+t['literal_rva']
plan=dict(schema='xar.native-research-plan.v1',topic='e04-resource4-two-literal-data-qword-refs',machine_id=machine,created_at_utc=datetime.now(timezone.utc).isoformat(),question='Does actual .rdata hold preferred-VA QWORD data references to the two established exact literals, allowing a concrete registration row candidate?',purpose='engine-transition',build=dict(version='1.20.0.4/Steam25734779',exe_sha256=SHA),
 observation=dict(mode='offline-only',actor_kind='engine',owner_scope='Second Root-approved target-only data scan; exactly one same.rdata read, no.text/newstrings/callee',identity_kind='definition-key',identity_lifetime='Same exact image/file identity as first literal packet; preferredVA neverruntimeVA',producer_trigger='not-applicable',producer='Only two known QWORD literal references; registration schema unknown',caller='GetCurrency44DB128 and barter_goods450BB80 exact literal locations from prior scope',consumer='Potential native named registration/enum rows, not yet source-confirmed handlers',cache_lifetime='Static bytes only',expected_signal='<=32 raw QWORD-reference rows with<=128Bcontext each; any0/truncation remains explicit',zero_sample_meaning='Zero data references only excludes retained QWORD matches in this one section; codeRIP-relative registrations and other sections/encodings uninspected',stop_condition='Single17124352B.rdata read,1read;2exactQWORDtargets;<=32rows/128Bcontext; body0,no.text/newstrings/callee/hash; totaloutput<=131072B',runtime_window_ref=None),
 evidence=[dict(id='literal',layer='locator',path='LITERALS.actual.json',sha256=hashlib.sha256(lb).hexdigest(),exe_sha256=SHA,supports='Actual two name literal RVAs and static preferredVAs; no handler mapping')],
 nodes=[dict(id='literal',label='Two exact literal preferredVAs'),dict(id='data',label='Named QWORD data references'),dict(id='handler',label='Registration/handler/enum UNKNOWN')],
 edges=[dict(id='refs',**{'from':'literal','to':'data'},label='Exact8B data reference locator',status='unknown',evidence=['literal'],open_question='Any actual data references to the two literalVAs?'),dict(id='meaning',**{'from':'data','to':'handler'},label='Raw row is not a verified handler',status='unknown',evidence=['literal'],open_question='What actual schema/registration/handler does the row encode?')],
 cases=[dict(id='static',question='Two preferredVA data references',status='pending',evidence=['literal']),dict(id='live',question='Payment/business state',status='not-applicable',evidence=[],reason='No SDK/game/desktop/state action')])
write('PLAN.before-qword-refs.json',plan)
argv=[sys.executable,'-B',str(R/'tools/native_research_plan.py'),'check',str(H/'PLAN.before-qword-refs.json')]
run=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8')
write('CHECK.before-qword-refs.actual.json',dict(machine_id=machine,at_utc=datetime.now(timezone.utc).isoformat(),argv=argv,exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr,plan_sha256=pin(H/'PLAN.before-qword-refs.json')['sha256']))
need(run.returncode==0,'Ordinary check failed; no read')
def stamp():
 s=E.stat();return dict(bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,device=s.st_dev,inode=s.st_ino)
before=stamp();need(before==l['stat_before']==l['stat_after'],'Actual image identity changed')
ss=[s for s in l['sections'] if s['name']=='.rdata'];need(len(ss)==1 and ss[0]['raw_size']==17124352,'Exact same section size')
s=ss[0]
with E.open('rb') as f:f.seek(s['raw_offset']);data=f.read(s['raw_size'])
need(len(data)==17124352 and stamp()==before,'Short read or changed image')
rows=[];counts={}
for t in targets:
 pat=t['preferred_VA'].to_bytes(8,'little');cursor=0;count=0
 while True:
  pos=data.find(pat,cursor)
  if pos<0:break
  cursor=pos+1;count+=1
  if len(rows)>=32:continue
  start=max(0,pos-48);end=min(len(data),start+128);ctx=data[start:end]
  rows.append(dict(name=t['name'],literal_rva=f'{t["literal_rva"]:X}',literal_preferredVA=t['preferred_VA'],reference_rva=f'{s["rva"]+pos:X}',reference_file_offset=s['raw_offset']+pos,reference_mod8=(s['rva']+pos)%8,qword_hex=pat.hex(),context_rva=f'{s["rva"]+start:X}',context_hex=ctx.hex(),context_bytes=len(ctx),context_sha256=hashlib.sha256(ctx).hexdigest()))
 counts[t['name']]=count
out=dict(schema='xar.e04.r08.two-literal-rdata-qword-references.v1',machine_id=machine,observed_at_utc=datetime.now(timezone.utc).isoformat(),exe_sha256_reused=SHA,source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),source_literals_pin=pin(lp),stat_before=before,stat_after=stamp(),targets=targets,section=s,read_ledger=[dict(file_offset=s['raw_offset'],bytes=s['raw_size'],kind='literal_pointer_data_locator')],metadata_bytes=0,body_bytes=0,literal_data_bytes=len(data),read_calls=1,counts=counts,rows=rows,output_truncated=sum(counts.values())>len(rows),cumulative_first_and_second_locator_bytes=l['literal_rdata_bytes']+len(data),cumulative_metadata_bytes=l['metadata_bytes'],cumulative_reads=l['read_calls']+1,text_bytes_read=0,whole_EXE_hashes=0,registration_or_handler_confirmed=False,resource4_business_name=None,paid_military_amount_raw=None,cadence=None)
write('QWORD-REFS.actual.json',out)
need(sum(p.stat().st_size for p in H.iterdir() if p.is_file())<=131072,'Total package budget')
print(json.dumps(dict(counts=counts,truncated=out['output_truncated'],rows=[dict(name=r['name'],rva=r['reference_rva'],mod8=r['reference_mod8'],context=r['context_hex']) for r in rows],new_data_bytes=len(data),new_reads=1,cumulative_locator_bytes=out['cumulative_first_and_second_locator_bytes'])))
