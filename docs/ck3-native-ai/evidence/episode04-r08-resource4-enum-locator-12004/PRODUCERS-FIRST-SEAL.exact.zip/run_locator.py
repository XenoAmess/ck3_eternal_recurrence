"""Root-authorized three-name .rdata locator; no .text or game operations."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,struct,subprocess,sys
R=Path('D:/workspace/ck3_eternal_recurrence');H=Path(__file__).parent;B=H.parent
E=Path('C:/SteamLibrary/steamapps/common/Crusader Kings III/binaries/ck3.exe')
I=B/'r08-payment-scalar-2bd3320-a01/CURRENT-EXE-IDENTITY.actual.json'
SHA='98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518'
NAMES=['GetCurrency','barter_goods','government_use_barter_goods']
sys.path.insert(0,str(R/'tools'))
from ck3_live_run_id import current_machine_id
def need(ok,msg):
 if not ok:raise ValueError(msg)
def write(n,o):
 with (H/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(o,f,indent=2);f.write('\n')
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
machine=current_machine_id();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
doc=R/'docs/ck3-native-ai/episode04-r08-rate-resource4-application-12004.md'
plan=dict(schema='xar.native-research-plan.v1',topic='e04-resource4-three-name-rdata-locator',machine_id=machine,created_at_utc=datetime.now(timezone.utc).isoformat(),question='Locate only three named native currency/flag literals for a later explicit registration/handler proof of selector4; no business naming from positions.',purpose='engine-transition',build=dict(version='1.20.0.4/Steam25734779',exe_sha256=SHA),
 observation=dict(mode='offline-only',actor_kind='engine',owner_scope='Root authorized exact file metadata and target-only .rdata literals; no .text, SDK, desktop or build',identity_kind='definition-key',identity_lifetime='Exact image/current same-file identity only; no runtime pointer/session qualification',producer_trigger='not-applicable',producer='Literal registrations not yet located; exact targets GetCurrency/barter_goods/government_use_barter_goods only',caller='Held28B9950 selector4 writes context4A0 via2BAFF30',consumer='Vanilla HUD GetPlayer.GetCurrency(barter_goods); native registration and enum connection unknown',cache_lifetime='Static file bytes; no runtime cache/cadence claim',expected_signal='Exact literal RVA/encoding and <=128B context to nominate a later bounded data-pointer registration proof',zero_sample_meaning='Zero literal hits in this actual .rdata scope does not prove no registration, no currency, zero payment or alternate encoding elsewhere',stop_condition='PE headers/sectionmap<=65536B; literal read<=134217728B/32reads; <=32 output hits,<=128B context each; zero .text/wholehash; output<=131072B',runtime_window_ref=None),
 evidence=[dict(id='held',layer='source-contract',path=str(doc),sha256=pin(doc)['sha256'],exe_sha256=SHA,supports='Existing selector4/context4A0 direct source, with business name explicitly unknown')],
 nodes=[dict(id='held',label='Held selector4 ->context4A0'),dict(id='names',label='Three explicit names'),dict(id='literal',label='Native .rdata literal RVA unknown'),dict(id='semantic',label='Registration/handler/enum mapping unknown')],
 edges=[dict(id='locate',**{'from':'names','to':'literal'},label='Target-only bounded literal locator',status='unknown',evidence=['held'],open_question='Are named literals in actual .rdata?'),dict(id='name',**{'from':'literal','to':'semantic'},label='Name is not handler or selector proof',status='unknown',evidence=['held'],open_question='Which actual registration rows and source handlers connect to selector4?')],
 cases=[dict(id='static',question='Three-name literal locations',status='pending',evidence=['held']),dict(id='live',question='Payment/player wallet result',status='not-applicable',evidence=[],reason='No live action or business qualification')])
write('PLAN.before-locator.json',plan)
argv=[sys.executable,'-B',str(R/'tools/native_research_plan.py'),'check',str(H/'PLAN.before-locator.json')]
run=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8')
write('CHECK.before-locator.actual.json',dict(machine_id=machine,at_utc=datetime.now(timezone.utc).isoformat(),argv=argv,exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr,plan_sha256=pin(H/'PLAN.before-locator.json')['sha256']))
need(run.returncode==0,'Ordinary check failed; no EXE read')
ir=I.read_bytes();ident=json.loads(ir)
need(hashlib.sha256(ir).hexdigest()=='47ff2b7951cc37faf49cd2773382306ea3256aba597a29406f5ff3fc8c3356e9','Existing exact identity pin changed')
need(ident['machine_id']==machine and ident['sha256']==SHA,'Machine/exact4 qualification differs')
def stamp():
 s=E.stat();return dict(bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,device=s.st_dev,inode=s.st_ino)
before=stamp();need(before==ident['stat_before']==ident['stat_after'],'Actual file identity/stamps changed; no rehash fallback')
ledger=[];metadata=literal_bytes=0
try:
 with E.open('rb') as f:
  def read(offset,size,kind):
   global metadata,literal_bytes
   need(len(ledger)<32 and 0<size and offset>=0 and offset+size<=before['bytes'],'Read bounds/count')
   need(metadata+size<=65536 if kind=='metadata' else literal_bytes+size<=134217728,'Per-scope budget')
   f.seek(offset);data=f.read(size);need(len(data)==size,'Short EXE read')
   ledger.append(dict(file_offset=offset,bytes=size,kind=kind,raw_hex=data.hex() if kind=='metadata' else None))
   if kind=='metadata':metadata+=size
   else:literal_bytes+=size
   return data
  dos=read(0,64,'metadata');need(dos[:2]==b'MZ','DOS signature')
  peoff=struct.unpack_from('<I',dos,0x3c)[0];need(peoff<=60000,'PE offset outside authorized header budget')
  coff=read(peoff,24,'metadata');need(coff[:4]==b'PE\0\0','PE signature')
  n=struct.unpack_from('<H',coff,6)[0];osize=struct.unpack_from('<H',coff,20)[0];need(1<=n<=96 and 112<=osize<=4096,'PE header dimensions')
  opt=read(peoff+24,osize,'metadata');need(struct.unpack_from('<H',opt)[0]==0x20b,'Expected PE32+')
  imagebase=struct.unpack_from('<Q',opt,24)[0];image_size=struct.unpack_from('<I',opt,56)[0]
  secraw=read(peoff+24+osize,n*40,'metadata');sections=[]
  for k in range(n):
   q=secraw[k*40:(k+1)*40];vs,va,rs,rp=struct.unpack_from('<IIII',q,8)
   sections.append(dict(name=q[:8].split(b'\0')[0].decode('ascii'),virtual_size=vs,rva=va,raw_size=rs,raw_offset=rp))
  rdata=[s for s in sections if s['name']=='.rdata'];need(len(rdata)==1,'Unique .rdata required')
  s=rdata[0]
  if s['raw_size']>134217728:
   write('SECTION-ONLY.actual.json',dict(machine_id=machine,at_utc=datetime.now(timezone.utc).isoformat(),exe_sha256=SHA,stat_before=before,stat_after=stamp(),sections=sections,read_ledger=ledger,stopped='.rdata exceeds128MiB; no literal body read'))
   raise SystemExit('Scope exceeds locator budget; stop')
  data=read(s['raw_offset'],s['raw_size'],'literal_rdata')
 need(stamp()==before,'EXE changed during metadata/literal scope')
 all_hits=[];counts={}
 for name in NAMES:
  for enc in ('utf-8','utf-16-le'):
   term=b'\0' if enc=='utf-8' else b'\0\0';pat=name.encode(enc)+term;cursor=0;count=0
   while True:
    pos=data.find(pat,cursor)
    if pos<0:break
    cursor=pos+1
    if enc=='utf-16-le' and (s['rva']+pos)%2:continue
    count+=1;boundary=pos==0 or data[max(0,pos-len(term)):pos]==term
    start=max(0,pos-48);end=min(len(data),start+128);window=data[start:end]
    all_hits.append(dict(name=name,encoding=enc,literal_rva=s['rva']+pos,literal_rva_hex=f'{s["rva"]+pos:X}',preferred_VA=imagebase+s['rva']+pos,file_offset=s['raw_offset']+pos,terminated_pattern_hex=pat.hex(),preceding_null_or_section_start=boundary,context_rva=s['rva']+start,context_hex=window.hex(),context_bytes=len(window),context_sha256=hashlib.sha256(window).hexdigest()))
   counts[name+'/'+enc]=count
 priority={'GetCurrency':0,'government_use_barter_goods':1,'barter_goods':2}
 all_hits.sort(key=lambda x:(not x['preceding_null_or_section_start'],priority[x['name']],x['literal_rva']))
 hits=all_hits[:32]
 out=dict(schema='xar.e04.r08.resource4.target-only-rdata-literals.v1',machine_id=machine,observed_at_utc=datetime.now(timezone.utc).isoformat(),source_head=head,exe_sha256_reused=SHA,identity_pin_sha256=hashlib.sha256(ir).hexdigest(),stat_before=before,stat_after=stamp(),image_base_preferred=imagebase,image_size=image_size,sections=sections,targets=NAMES,encodings=['utf-8','utf-16-le'],match_rule='Exact case-sensitive name with null terminator; suffix-sharing hits labelled by preceding-null status',literal_counts=counts,total_matches=len(all_hits),output_hits=hits,output_hits_truncated=len(all_hits)>len(hits),metadata_bytes=metadata,literal_rdata_bytes=literal_bytes,read_calls=len(ledger),read_ledger=ledger,whole_EXE_hashes=0,text_bytes_read=0,registration_or_handler_confirmed=False,resource4_business_name=None,paid_military_amount_raw=None,cadence=None,new_game_SDK_desktop_build_actions=0)
 write('LITERALS.actual.json',out)
 need(sum(p.stat().st_size for p in H.iterdir() if p.is_file())<=131072,'Output package budget')
 print(json.dumps(dict(result='LITERALS_ONLY_NO_SEMANTIC_BINDING',metadata_bytes=metadata,literal_bytes=literal_bytes,reads=len(ledger),counts=counts,truncated=out['output_hits_truncated'],hits=[dict(name=h['name'],encoding=h['encoding'],rva=h['literal_rva_hex'],start=h['preceding_null_or_section_start']) for h in hits])))
except Exception as e:
 write('FAILURE.actual.json',dict(machine_id=machine,at_utc=datetime.now(timezone.utc).isoformat(),error=str(e),read_ledger=ledger,metadata_bytes=metadata,literal_bytes=literal_bytes))
 raise
