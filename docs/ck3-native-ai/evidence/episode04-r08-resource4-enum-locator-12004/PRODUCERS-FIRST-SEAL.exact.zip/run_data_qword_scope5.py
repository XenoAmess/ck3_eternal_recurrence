"""Fifth Root-approved scope: only two pinned literal VAs in .data."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
H=Path(__file__).parent;R=Path('D:/workspace/ck3_eternal_recurrence')
E=Path('C:/SteamLibrary/steamapps/common/Crusader Kings III/binaries/ck3.exe')
sys.path.insert(0,str(R/'tools'))
from ck3_live_run_id import current_machine_id
def need(ok,msg):
    if not ok:raise ValueError(msg)
def pin(name):
    b=(H/name).read_bytes();return dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(name,obj):
    with (H/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,indent=2);f.write('\n')
def stamp():
    s=E.stat();return dict(bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,device=s.st_dev,inode=s.st_ino)
l=json.loads((H/'LITERALS.actual.json').read_bytes());prev=json.loads((H/'NAMED-RIP.overlap-complete.actual.json').read_bytes())
need(pin('LITERALS.actual.json')['sha256']=='af76ea5a7e69ea52048dc6ed80e6c78de7244e19ed02346a8f095cf378e47121','Literal pin')
need(pin('NAMED-RIP.overlap-complete.actual.json')['sha256']=='243302d54fe3bda5f476dcbd61e2ee0892c741f5a727f594c55684778423b4e1','Prior scope pin')
machine=current_machine_id();need(machine==l['machine_id']==prev['machine_id'],'Machine')
targets=[]
for name in ('GetCurrency','barter_goods'):
    items=[h for h in l['output_hits'] if h['name']==name and h['encoding']=='utf-8' and h['preceding_null_or_section_start']]
    need(len(items)==1,'Exact held standalone name')
    h=items[0];need(h['preferred_VA']==l['image_base_preferred']+h['literal_rva'],'Exact VA derivation')
    targets.append(dict(name=name,literal_rva=h['literal_rva'],preferred_VA=h['preferred_VA']))
plan=json.loads((H/'PLAN.before-qword-refs.json').read_bytes())
plan['topic']='e04-two-pinned-literal-QWORD-refs-data'
plan['created_at_utc']=datetime.now(timezone.utc).isoformat()
plan['question']='Does .data contain QWORD preferred-VA references to the two held standalone GetCurrency/barter_goods literals?'
o=plan['observation'];o['owner_scope']='Root-approved fifth scope: only.data8571392B, two exact pinnedVAs; no.rdataRVA32 or new strings/callee/body'
o['producer']='Exact QWORD patterns derived from pinned literal receipt; no instruction boundary or business interpretation'
o['stop_condition']='One.data8571392B read; <=16rows/96B; cumulative185103872B sections/9reads; header608B separate; body0; package<=131072B. Zero/no named handler closes this lane.'
o['zero_sample_meaning']='No QWORD match in .data only, not absence of native name binding or business resource.'
plan['evidence'].append(dict(id='corrected-RIP',layer='locator',path='NAMED-RIP.overlap-complete.actual.json',sha256=pin('NAMED-RIP.overlap-complete.actual.json')['sha256'],exe_sha256=l['exe_sha256_reused'],supports='No named8B/8D RIPcandidate in complete specified matcher; no semantic closure'))
write('PLAN.before-data-qword-scope5.json',plan)
checks=[]
for command in ('check','render'):
    argv=[sys.executable,'-B',str(R/'tools/native_research_plan.py'),command,str(H/'PLAN.before-data-qword-scope5.json')]
    if command=='render':argv+=['--output',str(H/'GRAPH.data-qword-scope5.md')]
    c=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8');checks.append(dict(argv=argv,exit_code=c.returncode,stdout=c.stdout,stderr=c.stderr));need(c.returncode==0,'Ordinary plan check/render failed')
write('CHECK-RENDER.before-data-qword-scope5.actual.json',dict(machine_id=machine,at_utc=datetime.now(timezone.utc).isoformat(),plan_pin=pin('PLAN.before-data-qword-scope5.json'),results=checks))
sections=[s for s in l['sections'] if s['name']=='.data'];need(len(sections)==1 and sections[0]['raw_size']==8571392,'Exact.data section')
s=sections[0];before=stamp();need(before==l['stat_before']==l['stat_after']==prev['stat_before']==prev['stat_after'],'Image identity')
with E.open('rb') as f:f.seek(s['raw_offset']);data=f.read(s['raw_size'])
need(len(data)==8571392 and stamp()==before,'Short read/image changed')
counts={};rows=[]
for t in targets:
    pattern=t['preferred_VA'].to_bytes(8,'little');pos=data.find(pattern);count=0
    while pos!=-1:
        count+=1
        if len(rows)<16:
            a=max(0,pos-32);ctx=data[a:min(len(data),a+96)]
            rows.append(dict(name=t['name'],literal_rva=f'{t["literal_rva"]:X}',literal_preferredVA=t['preferred_VA'],reference_rva=f'{s["rva"]+pos:X}',reference_file_offset=s['raw_offset']+pos,reference_mod8=(s['rva']+pos)%8,qword_hex=pattern.hex(),context_rva=f'{s["rva"]+a:X}',context_bytes=len(ctx),context_hex=ctx.hex(),context_sha256=hashlib.sha256(ctx).hexdigest()))
        pos=data.find(pattern,pos+1)
    counts[t['name']]=count
out=dict(schema='xar.e04.r08.two-literal-data-qword-references.v1',machine_id=machine,observed_at_utc=datetime.now(timezone.utc).isoformat(),source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),exe_sha256_reused=l['exe_sha256_reused'],source_literals_pin=pin('LITERALS.actual.json'),previous_scope_pin=pin('NAMED-RIP.overlap-complete.actual.json'),stat_before=before,stat_after=stamp(),targets=targets,section=s,read_ledger=[dict(file_offset=s['raw_offset'],bytes=len(data),kind='two_pinned_preferredVA_QWORD_data_locator')],new_scope_reads=1,new_scope_data_bytes=len(data),new_scope_metadata_bytes=0,body_source_bytes=0,counts=counts,rows=rows,output_truncated=sum(counts.values())>len(rows),cumulative_sections_bytes=prev['cumulative_sections_bytes']+len(data),cumulative_metadata_bytes=prev['cumulative_metadata_bytes'],cumulative_reads=prev['cumulative_reads']+1,whole_EXE_hashes=0,new_game_SDK_desktop_build_actions=0,registration_handler_or_resource_enum_confirmed=False,resource4_business_name=None,paid_military_amount_raw=None,cadence=None,spoken_VA_correction='Earlier Root message contained incorrect abbreviatedhex values; only pinned decimal5440909608 and5441108864 were scanned. Correct preferredVAs are0x1444DB128 and0x14450BB80.',stop_rule='No further matcher or section expansion without new named candidate; seal portable originals if zero/no handler.')
need(out['cumulative_sections_bytes']==185103872 and out['cumulative_reads']==9,'Cumulative approved ledger')
write('DATA-QWORD-REFS.actual.json',out)
size=sum(p.stat().st_size for p in H.iterdir() if p.is_file());need(size<=131072,'Package ceiling')
print(json.dumps(dict(result_pin=pin('DATA-QWORD-REFS.actual.json'),counts=counts,rows=rows,cumulative_sections_bytes=out['cumulative_sections_bytes'],package_bytes=size)))
