"""Second bounded pass checks named stock objects/decimal strings/display scalars.

The first pass covered exact native raw integer keys only. This pass prevents
that schema assumption from excluding an older saved small record.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,zipfile

HERE=Path(__file__).resolve().parent;REPO=Path('D:/workspace/ck3_eternal_recurrence')
with zipfile.ZipFile(HERE/'TRACKED-METADATA.zip') as z:inv=json.loads(z.read('INVENTORY.actual.json'))
exclude=re.compile(r'capacity|rate|change|gain|budget|elig|minimum|maximum|fraction|loss|tier|state|modifier|count|scale|difference|delta|commander|days|time|level|threshold',re.I)
hits=[];readbytes=0
def num(v):
 if type(v) in (int,float):return v
 if isinstance(v,str) and re.fullmatch(r'-?(?:0|[1-9][0-9]*)',v):return int(v)
 return None
for rel,size in inv['selected']:
 p=REPO/rel
 if p.stat().st_size!=size:raise RuntimeError('file changed before second shape pass')
 raw=p.read_bytes();readbytes+=len(raw)
 if b'supply' not in raw.lower() and b'stock' not in raw.lower():continue
 try:obj=json.loads(raw.decode('utf-8-sig'))
 except (ValueError,UnicodeError):continue
 found=[]
 def walk(x,path=''):
  if isinstance(x,dict):
   for key,value in x.items():
    if ('supply' in key.lower() or 'stock' in key.lower()) and not exclude.search(key):
     n=num(value);kind='raw_or_unscaled_field'
     if isinstance(value,dict):
      for rawkey in ('raw','current_raw','value_raw','current'):
       if rawkey in value:
        n=num(value[rawkey]);kind='stock_object_'+rawkey;break
     display=key.lower() in {'supply','stock','supplies','current_supply','current_stock'} and not isinstance(value,dict)
     limit=10 if display else 1000000
     if n is not None and 0<=n<limit:
      context={k:v for k,v in x.items() if k in ('machine_id','army_id','native_carmy_id','character_id','actor','actor_id','date_raw','current_soldiers','maximum_soldiers','schema','status','proof_layer','synthetic_only') and isinstance(v,(str,int,bool,type(None)))}
      found.append({'pointer':path+'/'+key,'value':value if not isinstance(value,dict) else {k:v for k,v in value.items() if not isinstance(v,(dict,list))},'shape':kind,'display_units_unverified':display,'nearby_context':context})
    walk(value,path+'/'+str(key))
  elif isinstance(x,list):
   for i,value in enumerate(x):walk(value,path+'/'+str(i))
 walk(obj)
 if found:hits.append({'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'hits':found[:8],'hit_count':len(found)})
out={'schema':'xar.r05.small-stock-shape-search.v1','machine_id':'desktop-3fevhd2-1c74096080',
 'at_utc':datetime.now(timezone.utc).isoformat(),'reason_for_second_pass':'exact raw integer key search cannot exclude stock objects, decimal strings or named display supply fields',
 'tracked_small_files':len(inv['selected']),'read_bytes':readbytes,'max_single_file_bytes':131072,
 'matches':hits,'matches_are_not_qualification':True,'large_raw_or_save_or_EXE_reads':0}
raw=(json.dumps(out,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
if len(raw)>32768:raise RuntimeError('bounded shape result needs compaction')
with (HERE/'SHAPE-MATCHES.actual.json').open('xb') as f:f.write(raw)
print(json.dumps({'files':len(inv['selected']),'read_bytes':readbytes,'matching_files':len(hits),'result_bytes':len(raw)}))
for row in hits:print(row['path'],json.dumps(row['hits'][:2]))
