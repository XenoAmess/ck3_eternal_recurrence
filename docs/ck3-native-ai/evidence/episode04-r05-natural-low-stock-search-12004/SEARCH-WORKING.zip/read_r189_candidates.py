from pathlib import Path
from datetime import datetime,timezone
import hashlib,json

HERE=Path(__file__).resolve().parent
P=Path('D:/workspace/ck3_native_war_ai_promo_work/e04-r189-window-capture-a01/desktop-3fevhd2-1c74096080--vanilla--R0189/responses/r189-r01-commander18-a01.json')
if not 0<P.stat().st_size<=131072:raise RuntimeError('named small candidate response only')
raw=P.read_bytes();doc=json.loads(raw.decode('utf-8-sig'))
if doc.get('machine_id')!='desktop-3fevhd2-1c74096080' or doc.get('is_error') is not False:raise RuntimeError('actual source mismatch')
body=doc['body'];matches=[]
def walk(x,path=''):
 if isinstance(x,dict):
  if 'conditional_supply_capacity_v1' in x:
   leaf=x['conditional_supply_capacity_v1']
   matches.append({'pointer':path,'candidate':{k:x.get(k) for k in ('character_id','can_assign','eligibility_available','status')},
    'capacity':{k:leaf.get(k) for k in ('status','source_character_id','scale','conditional_capacity_raw','assignment_applied','unavailable_reason')}})
  for k,v in x.items():walk(v,path+'/'+str(k))
 elif isinstance(x,list):
  for i,v in enumerate(x):walk(v,path+'/'+str(i))
walk(body)
out={'schema':'xar.r05.r189.commander-small.actual.v1','machine_id':doc['machine_id'],
 'observed_at_utc':datetime.now(timezone.utc).isoformat(),'source':{'path':str(P),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},
 'frame':{k:v for k,v in body.items() if k.startswith('queried_')},'body_keys':list(body),
 'capacity_matches':matches,'assignment_executed':False,'R05_positive':False}
encoded=(json.dumps(out,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
if len(encoded)>12288:raise RuntimeError('compact projection needed')
with (HERE/'R189-COMMANDER.actual.json').open('xb') as f:f.write(encoded)
print(encoded.decode('utf-8'))
