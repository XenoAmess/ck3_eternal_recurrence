"""Bounded tracked JSON metadata inventory, then selected small JSON search."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,re

HERE=Path(__file__).resolve().parent
REPO=Path('D:/workspace/ck3_eternal_recurrence')
PREFIXES=('docs/ck3-native-ai/','promo/ck3_native_war_ai/episode-04-march-logistics/')
KEYS={'current_supply_raw','supply_raw','stock_raw','supply_before_raw','supply_after_raw',
      'stock_before_raw','stock_after_raw','stock_at_writer_entry_raw','supply_before_update_raw','supply_after_update_raw'}
out=subprocess.run(['git','ls-files','-z','--',*PREFIXES],cwd=REPO,capture_output=True,check=True)
paths=[p for p in out.stdout.decode('utf-8').split('\0') if p.endswith('.json')]
selected=[]
for rel in paths:
 p=REPO/rel
 if p.is_file() and 0<p.stat().st_size<=131072:
  selected.append((rel,p.stat().st_size))
inventory={'machine_id':'desktop-3fevhd2-1c74096080','at_utc':datetime.now(timezone.utc).isoformat(),
 'tracked_scoped_json_count':len(paths),'small_json_count':len(selected),'small_total_bytes':sum(n for _,n in selected),
 'per_file_limit_bytes':131072,'scope':PREFIXES,'selected':selected}
with (HERE/'INVENTORY.actual.json').open('x',encoding='utf-8') as f:json.dump(inventory,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in inventory.items() if k!='selected'}))
