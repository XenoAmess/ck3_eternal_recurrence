from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile

HERE=Path(__file__).resolve().parent
REPO=Path('D:/workspace/ck3_eternal_recurrence')
invpath=HERE/'INVENTORY.actual.json';rawinv=invpath.read_bytes();inv=json.loads(rawinv)
with zipfile.ZipFile(HERE/'TRACKED-METADATA.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:z.writestr(invpath.name,rawinv)
with zipfile.ZipFile(HERE/'TRACKED-METADATA.zip') as z:
 if z.read(invpath.name)!=rawinv:raise RuntimeError('metadata archive changed bytes')
if invpath.resolve().parent!=HERE.resolve():raise RuntimeError('wrong exact derived metadata path')
invpath.unlink()
keys={'current_supply_raw','supply_raw','stock_raw','supply_before_raw','supply_after_raw',
      'stock_before_raw','stock_after_raw','stock_at_writer_entry_raw','supply_before_update_raw','supply_after_update_raw'}
matches=[];total=0;parsefails=[]
for rel,expected_size in inv['selected']:
 p=REPO/rel
 if p.stat().st_size!=expected_size:raise RuntimeError('scoped metadata changed before read: '+rel)
 raw=p.read_bytes();total+=len(raw)
 if not any(('"'+key+'"').encode('ascii') in raw for key in keys):continue
 try:obj=json.loads(raw.decode('utf-8-sig'))
 except (ValueError,UnicodeError) as e:parsefails.append({'path':rel,'error':str(e)});continue
 hits=[]
 def walk(x,path='',ancestors=()):
  if isinstance(x,dict):
   for k,v in x.items():
    if k in keys and type(v) is int and 0<=v<1000000:
     context={}
     for a in (*ancestors,x):
      for ck,cv in a.items():
       if ck in {'schema','schema_version','proof_layer','machine_id','game_version','executable_sha256','actor','actor_id','actor_character_id','character_id','army_id','native_carmy_id','current_soldiers','maximum_soldiers','date_raw','observed_date_raw','monthly_change_raw','current_monthly_supply_change_raw','synthetic_only','new_live_evidence','session','run_id','pid'} and isinstance(cv,(str,int,bool,type(None))):context[ck]=cv
     hits.append({'pointer':path+'/'+k,'raw':v,'context':context})
    walk(v,path+'/'+str(k),(*ancestors[-3:],x))
  elif isinstance(x,list):
   for i,v in enumerate(x):walk(v,path+'/'+str(i),ancestors)
 walk(obj)
 if hits:
  matches.append({'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'low_scalar_hits':len(hits),'examples':hits[:8]})
out={'schema':'xar.r05.tracked-small-low-stock-search.v1','machine_id':'desktop-3fevhd2-1c74096080',
 'at_utc':datetime.now(timezone.utc).isoformat(),'scoped_tracked_files':len(inv['selected']),'read_bytes':total,
 'per_file_max_bytes':131072,'full_save_EXE_or_large_exports_read':0,'exact_keys':sorted(keys),
 'matched_files':matches,'parse_failures':parsefails,
 'metadata_archive':{'path':'TRACKED-METADATA.zip','sha256':hashlib.sha256((HERE/'TRACKED-METADATA.zip').read_bytes()).hexdigest()},
 'inventory_uncompressed_bytes_before_compaction':len(rawinv),'temporary_oversize_inventory_corrected':len(rawinv)>98304,
 'matches_are_candidates_not_qualified_actual':True}
raw=(json.dumps(out,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
if len(raw)>49152:raise RuntimeError('bounded results need more compaction')
with (HERE/'MATCHES.actual.json').open('xb') as f:f.write(raw)
print(json.dumps({'read_files':len(inv['selected']),'read_bytes':total,'matching_files':len(matches),'result_bytes':len(raw),'inventory_old_bytes':len(rawinv),'package_now_bytes':sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())}))
for m in matches:print(m['path'],m['low_scalar_hits'],json.dumps(m['examples'][:2]))
