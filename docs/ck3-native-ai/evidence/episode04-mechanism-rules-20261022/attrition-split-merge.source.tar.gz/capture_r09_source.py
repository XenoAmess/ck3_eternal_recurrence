"""Finite offline source reading for E04 R09; no game process calls."""
from __future__ import annotations
import argparse
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import importlib
import json
from pathlib import Path
import re
import struct
import sys
from collections.abc import Iterable

LANE = Path(__file__).resolve().parent
ROOT = Path("D:/workspace/ck3_eternal_recurrence")
EXE = Path("C:/SteamLibrary/steamapps/common/Crusader Kings III/binaries/ck3.exe")
MACHINE = "desktop-3fevhd2-1c74096080"
FULL_SHA = "98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518"
RAW_CEILING = 65536
LANE_CEILING = 262144

@dataclass(frozen=True)
class Read:
    file_offset: int
    bytes: int
    purpose: str
    sha256: str

@dataclass(frozen=True)
class Instruction:
    rva: str
    bytes_hex: str
    mnemonic: str
    operands: str

@dataclass(frozen=True)
class Span:
    name: str
    start_rva: str
    end_rva_exclusive: str
    file_offset: int
    bytes: int
    sha256: str
    source_hex: str
    complete_linear_decode: bool
    instructions: list[Instruction]

@dataclass(frozen=True)
class FileIdentity:
    path: str
    bytes: int
    file_id_decimal: str
    mtime_ns_decimal: str
    image_base_decimal: str
    reused_full_sha256: str
    full_sha_rehashed: bool
    anchor_rva: str
    anchor_bytes: int
    anchor_sha256: str

@dataclass(frozen=True)
class Packet:
    schema: str
    machine_id: str
    observed_at_utc: str
    owner: str
    mode: str
    label: str
    purpose: str
    identity: FileIdentity
    previous_scope_exe_read_bytes: int
    new_exe_read_bytes: int
    cumulative_scope_exe_read_bytes: int
    read_ledger: list[Read]
    spans: list[Span]
    Game_SDK_UI_or_build_credit: bool

def require(condition: bool, reason: str) -> None:
    if not condition:
        raise ValueError(reason)

def strict_int(value: object, reason: str) -> int:
    require(type(value) is int, reason)
    if type(value) is not int:
        raise ValueError(reason)
    return value

def existing_bytes() -> int:
    return sum(p.stat().st_size for p in LANE.rglob("*") if p.is_file())

def machine_id() -> str:
    # Narrow dynamic boundary: invoke the existing stable machine-ID tool,
    # then validate its runtime result before using it as an identity.
    module = importlib.import_module("ck3_live_run_id")
    getter: object = getattr(module, "current_machine_id")
    require(callable(getter), "stable machine getter callable")
    if not callable(getter):
        raise ValueError("stable machine getter")
    value: object = getter()
    if not isinstance(value, str):
        raise ValueError("stable machine ID must be string")
    return value

def decode(raw: bytes, start: int) -> list[Instruction]:
    # Capstone has no py.typed/stubs in this environment. Keep it at this
    # private boundary and validate every value entering the typed model.
    module = importlib.import_module("capstone")
    factory: object = getattr(module, "Cs")
    arch = strict_int(getattr(module, "CS_ARCH_X86"), "capstone architecture")
    mode = strict_int(getattr(module, "CS_MODE_64"), "capstone mode")
    if not callable(factory):
        raise ValueError("capstone factory")
    decoder: object = factory(arch, mode)
    disasm: object = getattr(decoder, "disasm")
    if not callable(disasm):
        raise ValueError("capstone decoder")
    rows: object = disasm(raw, start)
    if not isinstance(rows, Iterable):
        raise ValueError("capstone instruction iterable")
    output: list[Instruction] = []
    for item in rows:
        address = strict_int(getattr(item, "address"), "instruction address")
        data: object = getattr(item, "bytes")
        mnemonic: object = getattr(item, "mnemonic")
        operands: object = getattr(item, "op_str")
        if not isinstance(data, (bytes, bytearray)) or not isinstance(mnemonic, str) or not isinstance(operands, str):
            raise ValueError("instruction field types")
        output.append(Instruction(f"{address:X}", bytes(data).hex(), mnemonic, operands))
    return output

def previous_reads() -> int:
    result = 0
    for p in LANE.glob("*.source.json"):
        item: object = json.loads(p.read_bytes())
        require(isinstance(item, dict), "prior packet object")
        if not isinstance(item, dict):
            raise ValueError("prior packet")
        require(item.get("schema") == "xar.e04.R09.finite-source.v1", "prior schema")
        result += strict_int(item.get("new_exe_read_bytes"), "prior raw byte count")
    return result

def capture(label: str, mode: str, selected: list[str], length: int | None) -> int:
    require(bool(re.fullmatch(r"[a-zA-Z0-9-]+", label)), "label")
    output = LANE / (label + ".source.json")
    require(not output.exists(), "immutable output exists")
    require(datetime.now(timezone.utc) < datetime(2026,10,22,8,tzinfo=timezone.utc), "deadline")
    sys.path.insert(0, str(ROOT / "tools"))
    require(machine_id() == MACHINE, "machine")
    prior = previous_reads()
    before = EXE.stat()
    require(before.st_size == 101040248, "exact EXE size")
    ledger: list[Read] = []
    used = 0
    mapped: list[tuple[int,int,int]] = []
    with EXE.open("rb") as stream:
        def read_raw(file_offset: int, amount: int, purpose: str) -> bytes:
            nonlocal used
            require(0 < amount <= 16384, "single read bound")
            require(prior + used + amount <= RAW_CEILING, "aggregate raw bound")
            stream.seek(file_offset)
            raw = stream.read(amount)
            require(len(raw) == amount, "short read")
            used += amount
            ledger.append(Read(file_offset, amount, purpose, hashlib.sha256(raw).hexdigest()))
            return raw

        header = read_raw(0,4096,"bounded PE headers and sections")
        require(header[:2] == b"MZ", "MZ")
        pe = struct.unpack_from("<I",header,0x3C)[0]
        require(pe + 24 <= len(header) and header[pe:pe+4] == b"PE\0\0", "PE")
        section_count = struct.unpack_from("<H",header,pe+6)[0]
        optional_length = struct.unpack_from("<H",header,pe+20)[0]
        opt = pe+24
        require(struct.unpack_from("<H",header,opt)[0] == 0x20B, "PE32+")
        image_base = struct.unpack_from("<Q",header,opt+24)[0]
        require(image_base == 0x140000000, "image base")
        pdata_rva,pdata_size = struct.unpack_from("<II",header,opt+112+3*8)
        table = opt+optional_length
        require(table+section_count*40 <= len(header), "bounded section table")
        for n in range(section_count):
            virtual_size,rva,raw_size,offset = struct.unpack_from("<IIII",header,table+n*40+8)
            mapped.append((rva,min(virtual_size,raw_size),offset))

        def offset_of(rva: int, amount: int) -> int:
            for start,size,offset in mapped:
                if start <= rva and rva+amount <= start+size:
                    return offset+rva-start
            raise ValueError("selected RVA outside raw section")

        def read_rva(rva: int, amount: int, purpose: str) -> bytes:
            return read_raw(offset_of(rva,amount),amount,purpose)

        anchor = read_rva(0x262BE10,660,"reused exact4 identity anchor")
        anchor_sha = hashlib.sha256(anchor).hexdigest()
        require(anchor_sha == "b565d2261e9e4549c7f34ff31c97fd14849756a8e68d10e6fb7c23e9109230ef","exact4 anchor")
        targets: list[tuple[str,int,int]] = []
        if mode == "initial":
            require(not selected and length is None,"initial arguments")
            targets = [("destination-weight-part-a",0x24E0140,306),("destination-weight-part-b",0x24E0280,221)]
        elif mode == "functions":
            require(bool(selected) and length is None,"functions arguments")
            for text in selected:
                require(bool(re.fullmatch(r"[0-9a-fA-F]{1,8}",text)), "target RVA")
                target = int(text,16)
                lo,hi = 0,pdata_size//12
                while lo < hi:
                    middle = (lo+hi)//2
                    begin,end,unwind = struct.unpack("<III",read_rva(pdata_rva+middle*12,12,"bounded exception directory search"))
                    if begin <= target:
                        lo = middle+1
                    else:
                        hi = middle
                require(lo>0,"no earlier pdata row")
                begin,end,unwind = struct.unpack("<III",read_rva(pdata_rva+(lo-1)*12,12,"selected exception-directory row"))
                require(begin == target and begin < end and end-begin <= 8192,"exact callee entry and finite span")
                targets.append(("direct-callee-"+text.lower(),begin,end-begin))
        elif mode == "span":
            require(len(selected)==1 and type(length) is int,"span arguments")
            if type(length) is not int:
                raise ValueError("length")
            require(0 < length <= 16384,"span length")
            require(bool(re.fullmatch(r"[0-9a-fA-F]{1,8}",selected[0])),"span RVA")
            targets=[("explicit-selected-span",int(selected[0],16),length)]
        else:
            raise ValueError("mode")
        spans: list[Span] = []
        for name,start,amount in targets:
            raw = read_rva(start,amount,name)
            instructions = decode(raw,start)
            complete = sum(len(i.bytes_hex)//2 for i in instructions) == len(raw)
            if mode != "span":
                require(complete,"complete decode")
            spans.append(Span(name,f"{start:X}",f"{start+amount:X}",offset_of(start,amount),amount,hashlib.sha256(raw).hexdigest(),raw.hex(),complete,instructions))
    after = EXE.stat()
    require((before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns),"EXE identity stable")
    identity = FileIdentity(str(EXE),after.st_size,str(after.st_ino),str(after.st_mtime_ns),str(image_base),FULL_SHA,False,"262BE10",660,anchor_sha)
    packet = Packet("xar.e04.R09.finite-source.v1",MACHINE,datetime.now(timezone.utc).isoformat(),"/root/mechanism_audit",mode,label,"offline bounded static source; no game process",identity,prior,used,prior+used,ledger,spans,False)
    rendered=(json.dumps(asdict(packet),ensure_ascii=False,separators=(",",":"))+"\n").encode("utf-8")
    require(existing_bytes()+len(rendered) <= LANE_CEILING,"lane storage bound")
    with output.open("xb") as sink:
        sink.write(rendered)
    print(json.dumps({"path":str(output),"bytes":len(rendered),"sha256":hashlib.sha256(rendered).hexdigest(),"new_exe_read_bytes":used,"cumulative_scope_exe_read_bytes":prior+used,"lane_total_bytes":existing_bytes(),"spans":[{"rva":s.start_rva,"bytes":s.bytes,"sha256":s.sha256} for s in spans]}))
    return 0

def main() -> int:
    parser=argparse.ArgumentParser()
    parser.add_argument("--label",required=True)
    parser.add_argument("--mode",choices=("initial","functions","span"),required=True)
    parser.add_argument("--target",action="append",default=[])
    parser.add_argument("--length",type=int)
    args=parser.parse_args()
    return capture(args.label,args.mode,args.target,args.length)

if __name__ == "__main__":
    raise SystemExit(main())
