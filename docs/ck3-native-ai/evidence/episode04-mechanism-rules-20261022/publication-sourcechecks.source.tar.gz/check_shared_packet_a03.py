"""Verify the finite documentation/source-reference closure, without executing it."""
from __future__ import annotations

from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import posixpath
import re
import subprocess
import tarfile
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parent
C = ROOT / "candidate"
BASE = "dac9327cc5db6c3e1075f2bcdfc7c0c81f487965"
W = "C:/ck3-e04-resume-20261020-a01/r06-resume-a02/integration-worktree"
E = "docs/ck3-native-ai/evidence/episode04-mechanism-rules-20261022"
P = "promo/ck3_native_war_ai/episode-04-march-logistics/mechanics-rewrite-20261022-a01"
K = "docs/ck3-native-ai/evidence/episode04-r08-player-parent-opportunity-20261021"
ENV = dict(os.environ, GIT_NO_LAZY_FETCH="1", GIT_OPTIONAL_LOCKS="0", PYTHONDONTWRITEBYTECODE="1", TMP=str(ROOT), TEMP=str(ROOT))
GIT_CACHE: dict[str, bytes] = {}


def sha(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()


def oid(body: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(body)).encode() + b"\0" + body).hexdigest()


def require(condition: bool, reason: str) -> None:
    if not condition:
        raise ValueError(reason)


def git_body(path: str) -> bytes:
    if path not in GIT_CACHE:
        process = subprocess.run(["git", "--no-optional-locks", "--no-lazy-fetch", "-C", W, "show", BASE + ":" + path],
                                 cwd=ROOT, env=ENV, capture_output=True)
        require(process.returncode == 0, "Selected local object unavailable; no fetch: " + path)
        GIT_CACHE[path] = process.stdout
    return GIT_CACHE[path]


def tree_body(path: str) -> bytes:
    return (C / path).read_bytes() if (C / path).is_file() else git_body(path)


def check_pin(row: dict[str, object], body: bytes, label: str) -> None:
    require(len(body) == row["bytes"] and sha(body) == row["sha256"], "Size/SHA differs: " + label)
    if "git_blob_oid" in row:
        require(oid(body) == row["git_blob_oid"], "Git blob OID differs: " + label)


def flatten(project: dict[str, object]) -> dict[str, dict[str, object]]:
    rows = [cue for chapter in project["chapters"] for cue in chapter["cues"]]
    require(len(rows) == 47 and len({r["id"] for r in rows}) == 47, "Cue count/uniqueness differs")
    return {row["id"]: row for row in rows}


def main() -> int:
    index = json.loads((C / E / "source-index.json").read_bytes())
    require(len(index["groups"]) == 12, "Finite producer-group count differs")
    archived: dict[str, dict[str, bytes]] = {}
    source_members = 0
    source_bytes = 0
    for group in index["groups"]:
        packed = (C / group["archive"]["path"]).read_bytes()
        check_pin(group["archive"], packed, group["name"])
        actual: dict[str, bytes] = {}
        with tarfile.open(fileobj=io.BytesIO(gzip.decompress(packed)), mode="r:") as stream:
            for member in stream.getmembers():
                path = PurePosixPath(member.name)
                require(member.isfile() and not path.is_absolute() and ".." not in path.parts,
                        "Unsafe/non-file archive member")
                require(member.name not in actual, "Duplicate archive member")
                source = stream.extractfile(member)
                require(source is not None, "Tar member lacks data")
                actual[member.name] = source.read()
        expected_names = {row["archive_member"] for row in group["members"] if "archive_member" in row}
        require(set(actual) == expected_names, "Archive member set differs")
        require(len(group["members"]) == group["source_files"], "Group member count differs")
        require(sum(row["bytes"] for row in group["members"]) == group["source_bytes"], "Group byte sum differs")
        for row in group["members"]:
            original = Path(row["source_path"]).read_bytes()
            check_pin(row, original, row["source_path"])
            if "archive_member" in row:
                body = actual[row["archive_member"]]
            else:
                body = (C / row["repository_file"]["path"]).read_bytes()
                check_pin(row["repository_file"], body, row["repository_file"]["path"])
            require(body == original, "Portable original bytes differ")
        archived[group["name"]] = actual
        source_members += group["source_files"]
        source_bytes += group["source_bytes"]

    base = json.loads(archived["script-base-a01"]["promo-project.mechanics.source-a01.json"])
    a02 = json.loads((C / P / "promo-project.mechanics.source-a02.json").read_bytes())
    latest = json.loads((C / P / "promo-project.mechanics.terms-a03.json").read_bytes())
    first, second, current = flatten(base), flatten(a02), flatten(latest)
    require(list(first) == list(second) == list(current), "Cue order changed")
    delta_a02 = [key for key in first if first[key] != second[key]]
    delta_a03 = [key for key in second if second[key] != current[key]]
    require(delta_a02 == ["N02-06"] and delta_a03 == ["N01-06"], "Overlay changed extra cues")
    require(second["N01-06"]["subtitles"]["en"] == current["N01-06"]["subtitles"]["en"], "English already-local wording changed")
    require("省份" not in current["N01-06"]["narration"]["zh-CN"], "Latest CN terminology missing")
    readable = (C / P / "SCRIPT.current-reference.md").read_text(encoding="utf-8")
    for cue in current.values():
        require(cue["narration"]["zh-CN"] == cue["subtitles"]["zh-CN"], "Narration/CN subtitle diverged")
        require(cue["narration"]["zh-CN"] in readable and cue["subtitles"]["en"] in readable,
                "Derived readable script omitted exact current cue text")
    require(sum(1 for name in archived["script-base-a01"] if name.lower().endswith(".svg")) == 18, "Original SVG count differs")
    pointer = json.loads((C / P / "CURRENT-SOURCE.json").read_bytes())
    for key in ["project", "readable_script", "source_index"]:
        check_pin(pointer[key], tree_body(pointer[key]["path"]), key)
    require(pointer["current_revision"] == "terms-a03", "CURRENT did not select latest overlay")

    shared = json.loads((ROOT / "SHARED-DOCS-BASELINES.prepared-a04.json").read_bytes())
    links_checked = set()
    for row in shared["rows"]:
        before = git_body(row["path"])
        check_pin(row["before"], before, row["path"])
        at = before.find(b"\n")
        expected = before[:at + 1] + b"\n" + row["added_text"].encode() + b"\n" + before[at + 1:]
        require((C / row["path"]).read_bytes() == expected, "Original shared document body was changed")
        require(row["added_bytes"] == len(expected) - len(before), "Added byte count is stale")
        check_pin(row["after"], expected, row["path"])
    texts = {row["path"]: row["added_text"] for row in shared["rows"]}
    main_path = "docs/ck3-native-ai/episode04-20261022-mechanism-rules-12004.md"
    texts[main_path] = (C / main_path).read_text(encoding="utf-8")
    for path, text in texts.items():
        require("维持费" not in text, "New prose did not use official maintenance term")
        require("尚未生成新旁白" not in text, "Stale media-state sentence in long-lived prose")
        for href in re.findall(r"\]\(([^)]+)\)", text):
            if "://" in href or href.startswith("#"):
                continue
            target = posixpath.normpath(posixpath.join(posixpath.dirname(path), unquote(href.split("#", 1)[0])))
            require(not target.startswith("../"), "Link escaped repository")
            tree_body(target)
            links_checked.add(target)

    closure_path = K + "/knowledge-closure20.json"
    binding_path = K + "/canonical-binding.json"
    old = json.loads(git_body(closure_path))
    closure = json.loads((C / closure_path).read_bytes())
    binding = json.loads((C / binding_path).read_bytes())
    changed = {"docs/ck3-native-ai/episode04-current-execution-map-12004.md", "docs/ck3-native-ai/episode04-gameplay-agent-use-12004.md"}
    require(len(closure["rows"]) == 20, "Knowledge closure is no longer20")
    unchanged = 0
    for previous, row in zip(old["rows"], closure["rows"]):
        require(previous["path"] == row["path"], "Knowledge row order changed")
        check_pin(row, tree_body(row["path"]), row["path"])
        if row["path"] not in changed:
            require(row == previous, "One of18 historical row objects changed")
            unchanged += 1
    require(unchanged == 18, "Historical row count differs")
    require(closure["knowledge_input_bytes"] == sum(r["bytes"] for r in closure["rows"]), "Knowledge byte sum differs")

    bound_pins = 0
    def walk(value: object, location: tuple[str, ...] = ()) -> None:
        nonlocal bound_pins
        if isinstance(value, dict):
            if all(key in value for key in ["path", "bytes", "sha256"]):
                path = value["path"]
                if isinstance(path, str) and not ":" in path and not path.startswith("research-a01/"):
                    if location and location[0] in {"entry_input", "prior_entry_input"}:
                        result = subprocess.run(["git", "--no-optional-locks", "--no-lazy-fetch", "-C", W,
                                                 "cat-file", "blob", value["git_blob_oid"]],
                                                cwd=ROOT, env=ENV, capture_output=True)
                        require(result.returncode == 0, "Historical local input object unavailable")
                        check_pin(value, result.stdout, path + " historical input")
                    else:
                        check_pin(value, tree_body(path), path)
                    bound_pins += 1
            for key, child in value.items():
                walk(child, location + (key,))
        elif isinstance(value, list):
            for child in value:
                walk(child, location)
    walk(binding)
    walk(closure)
    prior_binding = json.loads(git_body(binding_path))
    require(binding["canonical_document"] == prior_binding["canonical_document"], "Canonical11,435B document pin changed")
    require(binding["historical_index_unchanged"] == prior_binding["historical_index_unchanged"], "Historical index pin changed")
    require(binding["reader_contract"]["ordinary_planner_autoload"] is False, "Autoload boundary changed")

    attrs = json.loads((ROOT / "ATTRIBUTES-EXACT-SOURCE.prepared-a03.json").read_bytes())
    require(len(attrs["literal_new_exact_source_aliases"]) == 5, "Exact EOL exception set differs")
    require((C / ".gitattributes").read_bytes() == git_body(".gitattributes") + attrs["added_rules"].encode(), "Existing attributes changed")
    for alias in attrs["literal_new_exact_source_aliases"]:
        require((C / alias).read_bytes().count(b"\r\n") > 0, "Exact-author EOL alias no longer has original CRLF")
    for path in C.rglob("*.json"):
        body = path.read_bytes()
        if path.relative_to(C).as_posix() not in attrs["literal_new_exact_source_aliases"]:
            require(b"\r\n" not in body, "Generated JSON must be LF")
        json.loads(body)

    a04 = json.loads(archived["march-cost-producers-a04"]["context-cost-producers-a04.json"])
    rules = json.loads((C / E / "mechanism-rules.json").read_bytes())
    require(a04["live_qualification_unchanged"]["new_actual_paid_military_amount_raw"] is None,
            "a04 should not grant observed military-payment amount")
    require(rules["financial"]["c_d_producer_successor"]["no_new_same_instance_wallet_or_paid_military_qualification"] is True,
            "Shared rules expanded runtime qualification")
    require(rules["physical_state_creation_and_garrison"]["formal_class3_creator"] is None, "Unknown class3 creator invented")
    require(index["ordinary_planner_autoload"] is False and index["new_Game_SDK_native_build_or_payment_qualification"] is False,
            "Source-only index expanded qualification")
    print(json.dumps({"status": "PASS_FINITE_SOURCE_REFERENCE_CLOSURE", "machine_id": "desktop-3fevhd2-1c74096080",
                      "observed_at_utc": datetime.now(timezone.utc).isoformat(), "source_groups": 12,
                      "original_members_exact": source_members, "original_bytes_exact": source_bytes,
                      "cue_count": 47, "overlay_changed_cues": [delta_a02, delta_a03], "CN_EN_text_verified": True,
                      "formula_SVG_count": 18, "shared_original_bodies_preserved": 5,
                      "new_relative_link_targets_readable": len(links_checked), "knowledge_inputs": 20,
                      "knowledge_plus_binding": 21, "unchanged_old_row_objects": unchanged,
                      "file_backed_binding_pin_occurrences_verified": bound_pins,
                      "local_Git_inputs_read": len(GIT_CACHE), "no_Git_mutation_fetch_or_runtime_execution": True}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
