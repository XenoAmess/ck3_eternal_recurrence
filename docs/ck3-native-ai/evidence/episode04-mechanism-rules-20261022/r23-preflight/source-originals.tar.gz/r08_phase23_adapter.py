"""Direct phase23 source; pending Film intent becomes checked actual inputs once."""
from __future__ import annotations
from collections.abc import Mapping
from datetime import datetime, timezone
from pathlib import Path
from typing import Protocol, runtime_checkable
import hashlib
import importlib
import json
import math
import sys

OLD_ROOT = Path('C:/ck3-e04-resume-20261020-a01/r21-r08-source-prepare-a01/source/normal')
OLD_PATH = OLD_ROOT/'r08_phase22_adapter.py'
OLD_SHA = '0db61be5a3aab712c6d17f40886acf49f9301fb46c66797111f9fc538ef1be7f'
if hashlib.sha256(OLD_PATH.read_bytes()).hexdigest() != OLD_SHA:
    raise ValueError('Frozen preparation source changed')
sys.path.insert(0, str(OLD_ROOT))
import r08_phase22_adapter as old
if Path(str(old.__file__)).resolve() != OLD_PATH.resolve():
    raise ValueError('Actual preparation import differs')

Object = dict[str, object]
sys.path.insert(0,str(Path('C:/ck3-e04-resume-20261020-a01/r21-live-r08-a01/phase23-source-a01/normal')))
import ordinary_phase23_source as source
if Path(str(source.__file__)).resolve()!=Path('C:/ck3-e04-resume-20261020-a01/r21-live-r08-a01/phase23-source-a01/normal/ordinary_phase23_source.py').resolve() or hashlib.sha256(Path(str(source.__file__)).read_bytes()).hexdigest()!='434ca644e8506109a5add526439f7119bfdc51abe4961e8a9ce99f8af3da6d7d':
    raise ValueError('Actual immutable ordinary source verifier differs')
SCENE=Path('C:/ck3-e04-resume-20261020-a01/r23-live-r08-phase23-a01')


def scene(intent: Object) -> Path:
    path=Path(old.text(intent.get('scene_root'),'new scene'))
    old.need(path.is_absolute() and path.resolve()==SCENE.resolve(),'Explicit independent R22 scene root required')
    return path.resolve()


def read(reference: object) -> Object:
    ref = old.Pin.parse(reference)
    ref.verify_small()
    return old.obj(json.loads(ref.path.read_bytes()), 'pinned JSON')


def verify_image(reference: object) -> None:
    ref = old.Pin.parse(reference)
    old.need(0 < ref.bytes <= 20*1024*1024 and ref.path.stat().st_size == ref.bytes, 'Bounded original image required')
    old.need(hashlib.sha256(ref.path.read_bytes()).hexdigest() == ref.sha256, 'Original image changed')


def pin(path: Path) -> Object:
    old.need(path.stat().st_size <= 1048576, 'Small input required')
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def invoke(value: object, name: str, argument: object) -> object:
    method: object = getattr(value, name, None)
    if not callable(method):
        raise ValueError('Existing method unavailable: '+name)
    result: object = method(argument)
    return result


def pending(context: Mapping[str, object]) -> Object:
    seed=old.obj(context.get('saved_campaign'),'direct phase23 saved source')
    old.need(old.Pin.parse({'path':seed.get('save'),'bytes':seed.get('bytes'),'sha256':seed.get('sha256')})==source.SAVE and
             old.integer(seed.get('date_raw'),'source date',0xffffffff)==source.DATE and
             old.integer(seed.get('player_id'),'source actor',0xffffffff)==source.ACTOR,'Exact phase23 ordinary source required')
    inputs = old.obj(context.get('case_inputs'), 'case inputs')
    old.need('r08_continuous_take' not in inputs, 'Prepare uses pending intent, never a placeholder actual Film pin')
    row = old.obj(inputs.get('r08_film_pending_intent'), 'pending Film intent')
    old.need(set(row) == {'schema','checkpoint_name','maximum_wait_seconds','scene_root','ffprobe_pin','sources'},
             'Exact pending intent fields required')
    old.need(row['schema'] == 'xar.e04.r08.pending-film-intent.v1' and row['checkpoint_name'] == 'r08-film-live',
             'Distinct pending intent/checkpoint required')
    old.need(old.integer(row['maximum_wait_seconds'], 'wait') == 600 and
             scene(row).is_absolute(), 'Finite scene/wait differs')
    old.Pin.parse(row['ffprobe_pin'])  # Binary is verified by the original recorder at real Start.
    sources = old.obj(row['sources'], 'recorder sources')
    expected = {'capture_budget_monitor':'b4e925e1a9dd412761fedbd9cc9fd067dba3bd51d82d04d4cb5ba4cb680568e9',
        'capture_recorder':'adc63c498f4ef95e4bd9428cd1ec24cb2cef55c9ae9477431f3d70c5b731214a',
        'window_take':'006d4848374ede10f03be24266f35b67a4ce74004ed9755aeefbc6875f3180a6',
        'recorder_job':'1eb95419ed818209cc6536b02365d815d821dfeff47a8ba4d9d71e138613a92d'}
    old.need(set(sources) == set(expected), 'Finite recorder closure required')
    for name, digest in expected.items():
        ref = old.Pin.parse(sources[name]); ref.verify_small()
        old.need(ref.sha256 == digest and ref.path.name == name+'.py', 'Recorder source differs')
    observed=old.obj(inputs.get('r08_parent_postload_one_day'),'observation settings')
    old.need(old.integer(observed.get('actor_id'),'actor',0xffffffff)==source.ACTOR and
             old.integer(observed.get('expected_start_date_raw'),'observation date',0xffffffff)==source.DATE,
             'Direct observation starts on the selected source date, without preparation')
    return row


def static_actor(context: Mapping[str, object]) -> object:
    """Load the pinned finite actor closure without claiming future Film inputs."""
    pending(context)
    inputs=old.obj(context.get('case_inputs'),'case inputs')
    source.verify_source(inputs.get('ordinary_phase23_source_pin'),hash_file=False)
    selected = old.entry()
    actor = invoke(selected, 'actor', context)
    models = sys.modules.get('ck3_mod_acceptance_cases.postload_public_models')
    old.need(models is not None, 'Pinned public model module missing')
    cfg = invoke(getattr(models, 'Settings', None), 'parse', context)
    bundle = invoke(getattr(models, 'Bundle', None), 'parse', getattr(cfg, 'bundle_index_pin', None))
    verify: object = getattr(bundle, 'verify', None)
    budget: object = getattr(cfg, 'budget', None)
    if not callable(verify) or not callable(budget):
        raise ValueError('Existing bundle/budget interface unavailable')
    verify(); budget()
    invoke(bundle, 'tools', getattr(cfg, 'parent_tools', None))
    files: object = getattr(bundle,'files',None)
    if not isinstance(files,dict):
        raise ValueError('Existing bundle file index unavailable')
    # Preserve the original non-Film initialization and actual-source guards.
    for name in ('ck3_live_run_id','ck3_mod_acceptance_background_types',
                 'xar_autoplayer.bridge.war_payment_observations_v1',
                 'xar_autoplayer.bridge.exact_one_day_postcondition',
                 'ck3_mod_acceptance_cases.r08_parent_postload_controller',
                 'ck3_mod_acceptance_cases.r08_writer_common_adapter',
                 'ck3_mod_acceptance_cases.r08_writer_one_day',
                 'ck3_mod_acceptance_cases.r08_recorded_take'):
        module = importlib.import_module(name)
        runtime_source: object = getattr(module,'__file__',None)
        if not isinstance(runtime_source,str):raise ValueError('Actual runtime module source absent: '+name)
        path = Path(runtime_source).resolve()
        reference: object = files.get(path)
        ref = old.Pin.parse(reference);ref.verify_small()
        old.need(ref.path == path,'Actual runtime import is outside pinned bundle: '+name)
    admission = importlib.import_module('postload_admission')
    qualify: object = getattr(admission, 'validate_qualification', None)
    if not callable(qualify):
        raise ValueError('Existing qualification consumer missing')
    q = read(getattr(cfg, 'qualification_pin', None))
    qualify(q, observer=getattr(cfg, 'observer_pin', None), typed_root=getattr(cfg, 'parent_tools', None))
    return actor


def validate_contract(context: Mapping[str, object]) -> None:
    static_actor(context)


def prepare_case(context: Mapping[str, object]) -> object:
    static_actor(context)
    inputs=old.obj(context.get('case_inputs'),'case inputs')
    qualified=source.verify_source(inputs.get('ordinary_phase23_source_pin'),hash_file=True)
    prepare=importlib.import_module('ck3_mod_acceptance_prepare')
    materialize:object=getattr(prepare,'materialize_product_profile',None)
    finish:object=getattr(prepare,'finish_product_profile',None)
    write_json:object=getattr(prepare,'write_json',None)
    if not callable(materialize) or not callable(finish) or not callable(write_json):
        raise ValueError('Original ordinary profile primitives unavailable')
    profile:object=materialize(context,None,inputs['plain_configuration'])
    finished:object=finish(context,profile,provenance={'kind':'ordinary-phase23-materialization-and-native-bracket',
        'normal_checkpoint':qualified,'driver_history_copied':False,'one_life_identity_proven':False,
        'common_T0_frozen':False,'formal_ABC_arm':False})
    value=old.obj(profile,'ordinary materialized profile')
    seed=old.obj(context.get('saved_campaign'),'selected saved source')
    initial=Path(old.text(context.get('output'),'prepare output'))/'initial-plan.json'
    write_json(initial,{'steps':[]})
    pin_file=pin(initial)
    return {'machine_id':old.MACHINE,'startup':{'mode':'saved_campaign','state_dir':value['state_dir'],
        'saved_campaign':{**seed,'product_inventory':old.obj(value.get('product_inventory'),'inventory')['path']}},
        'initial_plan':pin_file,'profile_preparation':finished,'files':value['files'],'fixture_mounted':False,
        'runtime_status':'NOT_RUN','business_contract_applicable':False,'business_pass':False}


@runtime_checkable
class RuntimeSelection(Protocol):
    runtime_path: Path
    products_path: Path
    prepared_path: Path | None
    context_path: Path | None


@runtime_checkable
class LiveClient(old.Client, Protocol):
    selection: RuntimeSelection
    live: Path
    state: Path
    operator_reviewer: str
    def remaining(self) -> float: ...
    def root_checkpoint(self, name: str, request: object, reserve: float = 90) -> object: ...


def timestamp(value: object) -> datetime:
    result = datetime.fromisoformat(old.text(value, 'UTC').replace('Z', '+00:00'))
    old.need(result.tzinfo is not None, 'Timezone required')
    return result


def runtime_inputs(client: LiveClient) -> Object:
    selection = client.selection
    old.need(selection.prepared_path is not None and selection.context_path is not None, 'Actual prepared/context paths absent')
    result: Object = {}
    for name, path in (('runtime',selection.runtime_path), ('products',selection.products_path),
                       ('prepared',selection.prepared_path), ('context',selection.context_path)):
        if path is None:
            raise ValueError('Actual runtime input absent: '+name)
        result[name] = pin(path)
    return result


def retained_birth(client: object) -> str:
    bridge = sys.modules.get('ck3_mod_acceptance_cases.r08_writer_common_adapter')
    value = invoke(bridge,'retained_creation_filetime',client)
    old.need(type(value) is int and 0 < value < 1 << 64, 'Actual retained FILETIME required')
    return str(value)


def fresh_before_gate(context:Mapping[str,object],client:LiveClient,owner:Object)->Object:
    bridge=sys.modules.get('ck3_mod_acceptance_cases.r08_writer_common_adapter')
    constructor:object=getattr(bridge,'CommonPackets',None)
    if not callable(constructor):raise ValueError('Original same-client CommonPackets missing')
    relay:object=constructor(context,client,client.output/'r08-direct-phase23-inputs',machine=old.MACHINE)
    if not isinstance(relay,old.Relay):raise ValueError('Original same-client packet interface missing')
    client.guard(1165)
    original=relay.request('r08-direct-phase23-before-film','ck3_take_snapshot',{'include_native_command_history':False},timeout=20)
    if not isinstance(original,tuple) or len(original)!=2:raise ValueError('Original independent snapshot response absent')
    body=old.obj(original[0],'actual native pre-Film snapshot')
    frame=old.Frame.parse(body,old.text(context.get('run_id'),'run'))
    old.need(frame.date==source.DATE and frame.pid==owner['pid'],'Loaded source date/retained owner differs before Film gate')
    return {'snapshot':old.Pin.parse(original[1]).wire(),'native_owner':frame.wire()}


def validate_manifest(context: Mapping[str, object], client: LiveClient, intent: Object,
                      manifest: Object, owner: Object, inputs: Object) -> Object:
    fields = {'schema','machine_id','run_id','reviewer','owner','actor_id','date_raw',
              'runtime_inputs','take_config_pin','root_review_pin'}
    old.need(set(manifest) == fields and manifest['schema'] == 'xar.e04.r08.actual-film-manifest.v1', 'Actual Film manifest schema')
    run = old.text(context.get('run_id'), 'run')
    old.need(manifest['machine_id'] == old.MACHINE and manifest['run_id'] == run and
             manifest['reviewer'] == client.operator_reviewer, 'Manifest machine/run/reviewer differs')
    old.need(manifest['owner'] == owner and old.integer(manifest['actor_id'],'actor') == old.ACTOR and
             old.integer(manifest['date_raw'],'date',0xffffffff) == old.OBSERVATION_DATE, 'Actual post-prep owner/date differs')
    old.need(manifest['runtime_inputs'] == inputs == runtime_inputs(client), 'Actual runtime/products/prepared/context changed')
    config = read(manifest['take_config_pin'])
    review = read(manifest['root_review_pin'])
    old.need(config.get('schema') == 'xar.e04.owned-window-take-input.v1' and
             config.get('content_kind') == 'map-context' and config.get('machine_id') == old.MACHINE,
             'Distinct actual map-context TakeConfig required')
    old.need(Path(old.text(config.get('run_dir'),'live')).resolve() == client.live.resolve() and
             client.live.name == run and Path(old.text(config.get('scene_root'),'scene')).resolve() == scene(intent) and
             Path(old.text(config.get('state_dir'),'state')).resolve() == client.state.resolve() and
             Path(old.text(config.get('case_output'),'output')).resolve() == client.output.resolve(), 'Actual Film scene/live/state/output differs')
    for name in ('runtime','products','prepared','context'):
        ref = old.Pin.parse(inputs[name])
        old.need(Path(old.text(config.get(name),name)).resolve() == ref.path, 'TakeConfig actual input path differs: '+name)
    old.need(config.get('camera_awaiting') is None and config.get('camera_signal') is None,
             'Do not borrow another case camera handshake')
    old.need(old.integer(config.get('recording_seconds'),'recording') == 120 and
             old.integer(config.get('normal_close_reserve_seconds'),'GUI') >= 900 and
             old.integer(config.get('cleanup_reserve_seconds'),'cleanup') >= 120, 'Actual Film bounds/reserves differ')
    capacity = read(config.get('capacity'))
    old.need(capacity.get('machine_id') == old.MACHINE and capacity.get('run_id') == run and
             capacity.get('admitted') is True and capacity.get('budget_status') == 'GREEN', 'Actual Film capacity is not current run GREEN')
    old.need(Path(old.text(capacity.get('scene_root'),'capacity scene')).resolve() == scene(intent) and
             capacity.get('source_head') == config.get('source_head'), 'Film capacity source/scene differs')
    old.need(Path(old.text(capacity.get('raw_workdir'),'capacity raw root')).resolve() ==
             Path(old.text(config.get('raw_root'),'raw root')).resolve() and
             Path(old.text(config.get('raw_root'),'raw root')).resolve().parent == scene(intent),
             'Film raw root/capacity differs')
    bounds = old.obj(capacity.get('capture_bounds'),'Film bounds')
    components = old.obj(capacity.get('component_ceiling_bytes'),'Film components')
    old.need(bounds.get('max_recording_seconds') == 120 and bounds.get('client_only') is True and
             bounds.get('recording_hard_stop_seconds') == config.get('hard_terminal_seconds') and
             bounds.get('normal_close_reserve_seconds') == config.get('normal_close_reserve_seconds') and
             bounds.get('cleanup_save_reserve_seconds') == config.get('cleanup_reserve_seconds') and
             components.get('raw') == config.get('raw_budget_bytes') and
             datetime.now(timezone.utc) < timestamp(capacity.get('quota_review_at_utc')), 'Actual Film capacity bounds differ')
    old.need(review.get('schema') == 'xar.e04.owned-client-root-review.v1' and review.get('machine_id') == old.MACHINE and
             review.get('run_id') == run and review.get('reviewer') == '/root' and review.get('content') == 'map-context' and
             review.get('root_reviewed_window_only') is True and review.get('root_reviewed_no_hover') is True and
             0 <= (datetime.now(timezone.utc)-timestamp(review.get('reviewed_at_utc'))).total_seconds() <= 120,
             'Actual fresh Root visual review required')
    frame = read(review.get('capture'))
    source = old.obj(frame.get('source'),'original capture source')
    old.need(frame.get('schema') == 'xar.e04.owned-client-original-frame.v1' and frame.get('machine_id') == old.MACHINE and
             frame.get('run_id') == run and frame.get('pid') == owner['pid'] and
             str(source.get('owned_ck3_create_time')) == owner['legacy_psutil_create_time'] and
             0 <= (datetime.now(timezone.utc)-timestamp(frame.get('observed_at_utc'))).total_seconds() <= 180,
             'Actual capture is not current retained owner')
    verify_image(frame.get('client_original'))
    verify_image(frame.get('desktop_original'))
    # Image/geometry/OS/capacity/FFmpeg checks run again in the unchanged canonical
    # camera.start immediately before its sole real Start. No pixel claim here.
    return {'schema':'xar.e04.r08.continuous-take.v1', 'take_config_pin':manifest['take_config_pin'],
            'root_review_pin':manifest['root_review_pin'], 'ffprobe_pin':intent['ffprobe_pin'], 'sources':intent['sources']}


class LateEntry:
    def __init__(self, context: Mapping[str, object], client: LiveClient, delegate: old.EntryLike) -> None:
        self.context, self.client, self.delegate = context, client, delegate
        self.entered = False

    def validate_contract(self, context: Mapping[str, object]) -> object:
        validate_contract(context)
        return None

    def prepare_case(self, context: Mapping[str, object]) -> object:
        return prepare_case(context)

    def run_case(self, context: Mapping[str, object], client: object) -> Object:
        old.need(client is self.client and context is self.context and not self.entered, 'One same-client Film handoff only')
        self.entered = True
        intent = pending(context)
        name = old.text(intent['checkpoint_name'],'checkpoint')
        response = self.client.output/(name+'-root-result.json')
        claim = self.client.output/(name+'-once-claim.json')
        old.need(not response.exists() and not claim.exists(), 'Pre-existing Film response/claim refused')
        self.client.checkpoint(name+'-once-claim', {'machine_id':old.MACHINE,'run_id':context.get('run_id'),
            'phase':'DIRECT_PHASE23_WAIT', 'maximum_wait_seconds':intent['maximum_wait_seconds']})
        retained = old.obj(self.client.retain_process(),'actual retained owner')
        owner: Object = {'pid':old.integer(retained.get('pid'),'PID',0xffffffff),
                         'created_filetime':retained_birth(self.client),
                         'legacy_psutil_create_time':str(retained.get('create_time'))}
        old.need(owner['legacy_psutil_create_time'] not in ('None','nan','inf'), 'Actual retained legacy birth absent')
        actual_native=fresh_before_gate(context,self.client,owner)
        actual_inputs = runtime_inputs(self.client)
        remaining = self.client.remaining()
        old.need(math.isfinite(remaining) and remaining > 1145, 'Original Film/GUI reserve exhausted')
        reserve = max(1145, math.ceil(remaining-old.integer(intent['maximum_wait_seconds'],'wait')))
        self.client.guard(reserve)
        reply = old.obj(self.client.root_checkpoint(name, {'schema':'xar.e04.r08.awaiting-actual-film.v1',
            'machine_id':old.MACHINE,'owner':owner,'actor_id':old.ACTOR,'date_raw':old.OBSERVATION_DATE,
            'runtime_inputs':actual_inputs,'actual_remaining_seconds':remaining,'actual_wait_reserve_seconds':reserve,
            'actual_native_before_film':actual_native,
            'maximum_wait_seconds':intent['maximum_wait_seconds'], 'actual_manifest_required':True,
            'direct_phase23_no_preparation_day':True}, reserve=reserve),'Root checkpoint response')
        self.client.guard(1145)
        old.need(set(reply) == {'run_id','reviewer','actual_manifest_pin'} and reply['run_id'] == context.get('run_id') and
                 reply['reviewer'] == self.client.operator_reviewer, 'Actual Film reply shape/run/reviewer differs')
        old.need(read(pin(response)) == reply, 'Actual root reply bytes differ from returned original')
        manifest = read(reply['actual_manifest_pin'])
        film = validate_manifest(context,self.client,intent,manifest,owner,actual_inputs)
        current = old.obj(self.client.retain_process(),'current retained owner')
        old.need(current.get('pid') == owner['pid'] and str(current.get('create_time')) == owner['legacy_psutil_create_time'],
                 'Retained owner changed during actual Film gate')
        old.need(retained_birth(self.client) == owner['created_filetime'], 'Same retained handle FILETIME changed')
        derived_inputs = old.obj(context.get('case_inputs'),'case inputs')
        derived_inputs['r08_continuous_take'] = film
        derived: Object = dict(context)
        derived['case_inputs'] = derived_inputs
        self.client.checkpoint(name+'-actual-inputs-bound', {'machine_id':old.MACHINE,'run_id':context.get('run_id'),
            'root_reply':pin(response),'actual_manifest':reply['actual_manifest_pin'],'derived_continuous_take':film,
            'original_prepared_and_context_files_unchanged':True,'same_original_client':True})
        self.delegate.validate_contract(derived)
        return old.obj(self.delegate.run_case(derived,self.client),'Original recorded observation result')


def run_case(context: Mapping[str, object], client: object) -> Object:
    static_actor(context)
    if not isinstance(client,LiveClient):
        raise ValueError('Original public client/live input paths required')
    client.retain_process()
    return LateEntry(context,client,old.entry()).run_case(context,client)


def verify_case(context: Mapping[str, object]) -> Object:
    pending(context)
    return {'case_contract_qualified':False,'business_pass':False,'full_R08_qualified':False,
            'scope':'Direct phase23: no preparation day; actual Film, one observation day and normal close remain unqualified until actual evidence'}
