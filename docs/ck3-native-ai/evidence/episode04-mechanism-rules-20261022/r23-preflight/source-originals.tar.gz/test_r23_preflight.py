"""Four affected pure groups; no Game, input API, native or media processes."""
from __future__ import annotations
from collections.abc import Mapping
from datetime import datetime,timezone
from pathlib import Path
from tempfile import TemporaryDirectory
from types import ModuleType
from typing import cast
from unittest.mock import patch
import importlib
import json
import sys
import unittest

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import r08_phase23_adapter as a
import camera_preframe as camera
import r08_phase22_adapter as old
PARENT=Path('C:/ck3-e04-resume-20261020-a01/r21-live-r08-a01/phase23-source-a01/normal')
parent=old.load_module(old.Pin(PARENT/'test_phase23.py',16148,'f9a076b78f1faf82d1d24871a4d97e64b5cbc828dd0b7d6ae6a261af334c0acc'),'r23_frozen_source_fixture')


def object_call(value:object,name:str,*args:object)->object:
    return camera.call(value,name,*args)


def context(path:Path)->a.Object:
    value=old.obj(object_call(parent,'context',path),'source fixture')
    inputs=old.obj(value['case_inputs'],'inputs');intent=old.obj(inputs['r08_film_pending_intent'],'intent')
    intent['maximum_wait_seconds']=600;intent['scene_root']=str(a.SCENE)
    inputs['r08_film_pending_intent']=intent;value['case_inputs']=inputs
    return value


def loader(value:a.Object)->object:
    tools=old.BASE/'live-scene-a01/source-a01/tools';sys.path.insert(0,str(tools))
    public=importlib.import_module('ck3_mod_acceptance');selection=getattr(public,'Selection')
    selected=object.__new__(selection)
    selected.adapter_path=ROOT/'r08_phase23_adapter.py';selected.locations={'repo_root':tools.parent}
    with patch('subprocess.Popen',side_effect=ValueError('No runtime process in source-only loader')) as process:
        module:object=selected.load_adapter()
        object_call(module,'validate_contract',value)
        if process.call_count:raise ValueError('Unexpected runtime subprocess')
    if Path(str(getattr(module,'__file__'))).resolve()!=(ROOT/'r08_phase23_adapter.py').resolve():raise ValueError('Wrong actual entry')
    return module


class FakeBackend:
    def __init__(self,owner:camera.Object,mode:str='valid')->None:
        self.owner,self.mode=owner,mode;self.events:list[str]=[]

    def identity(self)->camera.Object:
        result={**self.owner,'client_screen_rect':[0,0,1800,1000]}
        if self.mode=='wrong-owner':result['created_filetime']='134371000000000009'
        if self.mode=='wrong-rect':result['client_screen_rect']=[1,0,1801,1000]
        return result
    def dimensions(self)->tuple[int,int]:return (1800,1000)
    def source_dimensions(self,path:Path)->tuple[int,int]:return (1800,1000) if self.mode!='wrong-size' else (1600,900)
    def move(self,mapping:object,reviewed:tuple[float,float,int,int],source:Path,receipt:Path)->camera.Object:
        self.events.append('move');receipt.write_bytes(b'fake-pointer-image')
        return {'status':'pointer-move-readback-matched','failures':[]}
    def wm_mousemove(self,point:tuple[int,int])->camera.Object:
        self.events.append('WM_MOUSEMOVE');return {'message':512,'ack':self.mode!='no-ack','client_point':point}
    def screenshot(self,path:Path)->tuple[int,int]:
        self.events.append(path.name);path.write_bytes(b'fake-independent-image');return self.dimensions()
    def settle(self)->None:self.events.append('settle')
    def prepare_frame(self,path:Path)->object:
        self.events.append('canonical-prepare-frame');return {'source_fixture_only':True,'actual_recording_started':False}


def camera_fixture(root:Path)->tuple[camera.Object,FakeBackend,object]:
    owner:camera.Object={'pid':1234,'hwnd':5678,'created_filetime':'134371000000000001'}
    image=root/'source.png';image.write_bytes(b'fake-reviewed-image')
    def write(path:Path,body:object)->camera.Object:
        camera.write(path,body);return camera.pin(path)
    config=write(root/'config.json',{'machine_id':old.MACHINE,'content_kind':'map-context','scene_root':str(a.SCENE),
        'run_dir':str(a.SCENE/'driver-runs/synthetic-r23-source-only')})
    before=write(root/'source.json',{'schema':'xar.e04.owned-client-original-frame.v1','machine_id':old.MACHINE,
        'run_id':'synthetic-r23-source-only','pid':1234,'source':{'hwnd':5678,'client_screen_rect':[0,0,1800,1000],
            'desktop':[1800,1000]},'desktop_original':camera.pin(image)})
    intent:camera.Object={'schema':'xar.e04.r08.preframe-hover-park.v1','machine_id':old.MACHINE,
        'run_id':'synthetic-r23-source-only','scene_root':str(a.SCENE),'owner':owner,'camera_config_pin':config,
        'before_capture_pin':before,'preview_bounds':[10.,20.,900,400],'observed_point':[460.,220.],
        'reviewed_bounds':[440.,200.,40,40],'reviewed_by':'/root','reviewed_at_utc':datetime.now(timezone.utc).isoformat(),
        'output_root':str(root/'diagnostic'),'frame_output':str(root/'canonical-frame')}
    mapper=old.load_module(old.Pin(camera.MAP_PATH,camera.MAP_PATH.stat().st_size,camera.MAP_SHA),'r23_pure_canonical_mapping')
    return intent,FakeBackend(owner),mapper


class Tests(unittest.TestCase):
    def test_new_scene_pending600_and_actual_new_public_loader(self)->None:
        with TemporaryDirectory(dir=ROOT/'TEMP') as folder:
            value=context(Path(folder));loader(value)
            intent=old.obj(old.obj(value['case_inputs'],'inputs')['r08_film_pending_intent'],'intent')
            self.assertEqual(a.pending(value)['maximum_wait_seconds'],600)
            intent['maximum_wait_seconds']=300
            inputs=old.obj(value['case_inputs'],'inputs');inputs['r08_film_pending_intent']=intent;value['case_inputs']=inputs
            with self.assertRaises(ValueError):a.pending(value)

    def test_same_client_600_dynamic_reserve_and_no_extra_preparation(self)->None:
        for remaining,expected in ((2000.2,1401),(1500.2,1145)):
            with self.subTest(remaining=remaining),TemporaryDirectory(dir=ROOT/'TEMP') as folder:
                output=Path(folder)/'synthetic-r21-source-check'/'case-output';output.mkdir(parents=True)
                value=context(output);module=loader(value)
                fake:object=object_call(parent,'Client',output,value)
                if not isinstance(fake,a.LiveClient):raise ValueError('Real-shape retained fixture missing')
                fake_client=fake
                value['run_dir']=str(fake_client.live)
                original=old.entry();delegate=object_call(parent,'Delegate',original,fake_client)
                if not isinstance(delegate,old.EntryLike):raise ValueError('Original typed entry fixture missing')
                relay=object_call(parent,'Relay',value)
                bridge=sys.modules['ck3_mod_acceptance_cases.r08_writer_common_adapter']
                with patch.object(fake,'remaining',return_value=remaining),patch.object(a,'static_actor',return_value=None),\
                     patch.object(a,'retained_birth',return_value='134371000000000001'),patch.object(bridge,'CommonPackets',return_value=relay):
                    a.LateEntry(value,fake_client,delegate).run_case(value,fake_client)
                self.assertEqual(getattr(fake,'wait_reserve'),expected)
                self.assertEqual(getattr(relay,'tools'),['ck3_take_snapshot'])
                self.assertEqual(getattr(delegate,'calls'),1)
                self.assertIsNotNone(module)

    def test_preframe_nonuniform_coordinates_sequence_and_no_hover_claim(self)->None:
        with TemporaryDirectory(dir=ROOT/'TEMP') as folder:
            root=Path(folder);intent,backend,mapper=camera_fixture(root)
            with patch.object(camera,'SCENE',root),patch.object(a,'SCENE',root):
                intent['scene_root']=str(root)
                config=camera.read(intent['camera_config_pin']);config['scene_root']=str(root)
                config['run_dir']=str(root/'driver-runs/synthetic-r23-source-only')
                camera.write(root/'config-local.json',config);intent['camera_config_pin']=camera.pin(root/'config-local.json')
                result=camera.perform(intent,backend,mapper)
            self.assertEqual(result['screen_point'],(900,500))
            self.assertFalse(result['no_hover_verified'])
            self.assertEqual(backend.events,['before-original.png','move','WM_MOUSEMOVE','settle','after-original.png','canonical-prepare-frame'])

    def test_preframe_wrong_identity_or_size_before_input_and_no_ack_no_prepare(self)->None:
        for mode in ('wrong-owner','wrong-size','wrong-rect','no-ack'):
            with self.subTest(mode=mode),TemporaryDirectory(dir=ROOT/'TEMP') as folder:
                root=Path(folder);intent,backend,mapper=camera_fixture(root);backend.mode=mode
                intent['scene_root']=str(root)
                config=camera.read(intent['camera_config_pin']);config['scene_root']=str(root);config['run_dir']=str(root/'synthetic-r23-source-only')
                camera.write(root/'config-local.json',config);intent['camera_config_pin']=camera.pin(root/'config-local.json')
                with patch.object(camera,'SCENE',root),self.assertRaises(ValueError):camera.perform(intent,backend,mapper)
                self.assertNotIn('canonical-prepare-frame',backend.events)
                if mode!='no-ack':self.assertNotIn('move',backend.events)


if __name__=='__main__':
    (ROOT/'TEMP').mkdir(exist_ok=True)
    if '--loader' in sys.argv:
        with TemporaryDirectory(dir=ROOT/'TEMP') as folder:loader(context(Path(folder)))
    else:unittest.main(verbosity=2)
