"""Actual original harmless Python Popen/wait and immutable source pins."""
from __future__ import annotations
from ctypes import wintypes
from datetime import datetime, timezone
from pathlib import Path
import argparse
import ctypes
import hashlib
import json
import os
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
NAMES=('r08_phase23_adapter.py','camera_preframe.py','test_r23_preflight.py','run_checks.py','derive_sources.py')
PYTHON=Path('D:/workspace/ck3_eternal_recurrence/tools/.venv/Scripts/python.exe')
OLD='C:/ck3-e04-resume-20261020-a01/r21-r08-source-prepare-a01/source/normal'


def pin(path:Path)->dict[str,object]:
    data=path.read_bytes()
    return {'path':str(path.resolve()),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


def check_size(extra:int=0)->None:
    if sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())+extra>163840:
        raise ValueError('Author160KiB exhausted')
    if sum(p.stat().st_size for p in ROOT.parent.rglob('*') if p.is_file())+extra>262144:
        raise ValueError('LiveSource256KiB exhausted')
    if datetime.now(timezone.utc)>=datetime(2026,10,22,8,0,tzinfo=timezone.utc):
        raise ValueError('Finite source deadline')


def creation(process:subprocess.Popen[bytes])->str:
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    fn=kernel.GetProcessTimes
    fn.argtypes=[ctypes.c_void_p]+[ctypes.POINTER(wintypes.FILETIME)]*4
    fn.restype=wintypes.BOOL
    value:object=getattr(process,'_handle',None)
    if not isinstance(value,int) or isinstance(value,bool):raise ValueError('Original handle absent')
    c,e,k,u=(wintypes.FILETIME() for _ in range(4))
    if not fn(value,ctypes.byref(c),ctypes.byref(e),ctypes.byref(k),ctypes.byref(u)):
        raise OSError(ctypes.get_last_error(),'GetProcessTimes harmless original Python')
    return str((int(c.dwHighDateTime)<<32)|int(c.dwLowDateTime))


def main()->int:
    parser=argparse.ArgumentParser()
    parser.add_argument('mode',choices=('strict','focused','loader'))
    parser.add_argument('--leaf',required=True)
    args=parser.parse_args()
    check_size();(ROOT/'TEMP').mkdir(exist_ok=True)
    if Path(args.leaf).name!=args.leaf:raise ValueError('New check leaf required')
    output=ROOT/args.leaf;output.mkdir()
    env=dict(os.environ)
    env.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',TMP=str(ROOT/'TEMP'),TEMP=str(ROOT/'TEMP'))
    if args.mode=='strict':
        env['PYTHONPATH']='C:/ck3-e04-resume-20261020-a01/r08-mypy1201-tools-2115-a01/Lib'
        env['MYPYPATH']=OLD+';C:/ck3-e04-resume-20261020-a01/r21-live-r08-a01/phase23-source-a01/normal;C:/ck3-e04-resume-20261020-a01/r21-live-r08-a01/live-source-a01/normal'
        argv=[str(PYTHON),'-X','utf8','-B','-m','mypy','--strict','--no-incremental','--cache-dir',os.devnull,
              *[str(ROOT/name) for name in NAMES]]
    else:
        argv=[str(PYTHON),'-X','utf8','-B',str(ROOT/'test_r23_preflight.py')]
        if args.mode=='loader':argv.append('--loader')
    before=[pin(ROOT/name) for name in NAMES]
    errors:list[str]=[]
    created:str|None=None
    with (output/'stdout.actual.txt').open('xb') as stdout,(output/'stderr.actual.txt').open('xb') as stderr:
        process:subprocess.Popen[bytes]=subprocess.Popen(argv,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,
            stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        try:created=creation(process)
        except BaseException as error:errors.append(type(error).__name__+': '+str(error))
        finally:code=process.wait()
    after=[pin(ROOT/name) for name in NAMES]
    result={'machine_id':'desktop-3fevhd2-1c74096080','observed_at_utc':datetime.now(timezone.utc).isoformat(),
        'argv':argv,'cwd':str(ROOT),'pid':process.pid,'created':created,'actual_original_Popen_wait':code,
        'errors':errors,'source_before':before,'source_after':after,'source_equal':before==after,
        'stdout':pin(output/'stdout.actual.txt'),'stderr':pin(output/'stderr.actual.txt'),
        'Game_SDK_profilecopy_native_recording_actions':0}
    raw=(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf-8');check_size(len(raw))
    with (output/'ORIGINAL-WAIT.actual.json').open('xb') as stream:stream.write(raw)
    print(json.dumps({'mode':args.mode,'pid':process.pid,'wait':code,'errors':errors,'source_equal':before==after,
        'receipt':pin(output/'ORIGINAL-WAIT.actual.json')}))
    return 0 if code==0 and not errors and before==after else 1


if __name__=='__main__':sys.exit(main())


