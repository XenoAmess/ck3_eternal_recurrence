"""Create-only, exact-parent R23 source derivation; never execute a game."""
from __future__ import annotations
from pathlib import Path
import hashlib

ROOT=Path(__file__).resolve().parent
BASE=Path('C:/ck3-e04-resume-20261020-a01/r21-live-r08-a01/phase23-source-a01/normal')


def derive()->None:
    raw=(BASE/'r08_phase23_adapter.py').read_bytes()
    if len(raw)!=22467 or hashlib.sha256(raw).hexdigest()!='ec014fa2eacbd5e69134e592318e25cd996133e94d54f850befad96faaff1b2b':
        raise ValueError('Exact ec014 parent changed')
    text=raw.decode('utf-8')
    edits=[('r22-live-r08-phase23-a01','r23-live-r08-phase23-a01'),
           ("old.integer(row['maximum_wait_seconds'], 'wait') == 300", "old.integer(row['maximum_wait_seconds'], 'wait') == 600"),
           ('sys.path.insert(0,str(Path(__file__).resolve().parent))',
            "sys.path.insert(0,str(Path('C:/ck3-e04-resume-20261020-a01/r21-live-r08-a01/phase23-source-a01/normal')))"),
           ('import ordinary_phase23_source as source',
            "import ordinary_phase23_source as source\nif Path(str(source.__file__)).resolve()!=Path('C:/ck3-e04-resume-20261020-a01/r21-live-r08-a01/phase23-source-a01/normal/ordinary_phase23_source.py').resolve() or hashlib.sha256(Path(str(source.__file__)).read_bytes()).hexdigest()!='434ca644e8506109a5add526439f7119bfdc51abe4961e8a9ce99f8af3da6d7d':\n    raise ValueError('Actual immutable ordinary source verifier differs')")]
    for before,after in edits:
        if text.count(before)!=1:raise ValueError('Single mechanical edit required: '+before)
        text=text.replace(before,after)
    with (ROOT/'r08_phase23_adapter.py').open('xb') as output:output.write(text.encode('utf-8'))
    parent=BASE/'run_checks.py'
    run=parent.read_text(encoding='utf-8')
    run=run.replace("NAMES=('r08_phase23_adapter.py','ordinary_phase23_source.py','test_phase23.py','run_checks.py','make_adapter.py')",
        "NAMES=('r08_phase23_adapter.py','camera_preframe.py','test_r23_preflight.py','run_checks.py','derive_sources.py')")
    run=run.replace("datetime(2026,10,22,3,45", "datetime(2026,10,22,8,0")
    run=run.replace("'strict','focused','loader','source-metadata'", "'strict','focused','loader'")
    start=run.index("    elif args.mode=='source-metadata':")
    end=run.index('    else:',start)
    run=run[:start]+run[end:]
    run=run.replace("str(ROOT/'test_phase23.py')", "str(ROOT/'test_r23_preflight.py')")
    run=run.replace("env['MYPYPATH']=OLD+';C:/ck3-e04-resume-20261020-a01/r21-live-r08-a01/live-source-a01/normal'",
        "env['MYPYPATH']=OLD+';C:/ck3-e04-resume-20261020-a01/r21-live-r08-a01/phase23-source-a01/normal;C:/ck3-e04-resume-20261020-a01/r21-live-r08-a01/live-source-a01/normal'")
    with (ROOT/'run_checks.py').open('x',encoding='utf-8',newline='\n') as output:output.write(run)


if __name__=='__main__':derive()
