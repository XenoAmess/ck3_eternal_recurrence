# R23 source-only preflight repair

Machine: desktop-3fevhd2-1c74096080. No Game, SDK, desktop input, screenshot, profile copy, recorder Start, native build or SYSTEM action was executed by this source package.

The public entry remains the normal Selection/prepare/run path. Select the final r08_phase23_adapter.py from this folder, use the independent Scene C:/ck3-e04-resume-20261020-a01/r23-live-r08-phase23-a01, and configure the six-key pending Film intent with maximum_wait_seconds=600. It still requires the actual ordinary R0235 source contract and source Save71616553/e044... at date53146872. No preparation day is added. The original hold is never extended. The unchanged formula is max(1145,ceil(actual_remaining-intent.maximum_wait_seconds)); a short remaining hold shortens the actual wait. The pre-Film snapshot still guards1165 and has timeout20. Root review freshness and the later P06/Film/once/DR6/normal GUI contracts remain unchanged.

All fresh Game, Film, loaded DLL, native actor/date, OS3+1, actual RootScope and current capacity/Steam/screen permissions remain later independent inputs. A fresh CaseClient uses a new normal case-output; there is no existing-output workaround and no attempt to revive R0236's expired gate. Root rejected the same-Game route; its old claim, original error and normal closure remain unchanged.

The candidate dispatch date uses H53146872 ->53146896 and D=(H-43800000)/24, residue23 ->24 for unsigned CharacterID31254%30=24. This is a financial dispatch residue, not a day-of-month claim or a predicted positive payment result. The final phase source is referenced separately when available; no new runtime/native collector is introduced.

## Camera preparation sequence for a later admitted new scene

Prepare and pin the Film CFG/capacity assets and source/runtime closure before launch where possible. After actual MapReady, run the unchanged camera_entry_a02.py prepare-frame to obtain a fresh canonical original capture. Root directly views that original desktop image and supplies a reviewed empty region and point. That parking-region review is not the final no-hover review.

Build one immutable intent with schema xar.e04.r08.preframe-hover-park.v1 and exactly these fields:

- schema, machine_id, run_id, scene_root;
- owner={pid,created_filetime,hwnd}, with canonical FILETIME as a decimal string;
- before_capture_pin, from that actual canonical prepare-frame result;
- preview_bounds=[actual_content_left,top,width,height], observed_point=[x,y], reviewed_bounds=[left,top,width,height];
- reviewed_by='/root', reviewed_at_utc, camera_config_pin;
- output_root and frame_output, two distinct, absent direct children of the new Scene root.

No future PID, SHA, rectangle, image or Root approval is filled with a placeholder. The preview content rectangle must describe the actual rendered image, even when either axis is scaled differently. The reviewed point must lie inside the actual target client. Old R0236 points880/880 or240/520 and its2560x1440 desktop are historical and are not defaults.

Only after independent fresh Game/UI authority, the sole desktop owner can invoke camera_preframe.py --intent ACTUAL_JSON --intent-sha256 ACTUAL_SHA --execute. Without --execute it prints a plan and performs no UI operation. The source financial card does not authorize this live invocation.

The wrapper reuses the exact installed canonical coordinate map and the original camera entry/bootstrap/TakeSpec.owner (including current keeper/host/capacity checks). It retains a query-only process handle and compares actual PID, canonical GetProcessTimes FILETIME and HWND around the operation. The source image size, current desktop size and actual client rectangle must agree. The canonical move_pointer checks foreground/focus, mouse buttons and readback, and writes its original PNG/JSON receipt. It then performs ScreenToClient under an explicitly restored physical thread DPI context and posts exactly one WM_MOUSEMOVE with zero mouse buttons. It never clicks, types, activates a window or uses SDK. No keyboard layout is changed because no keyboard input is sent; foreground/focus checks remain active.

Independent before/after originals and binding are saved, then the original window_take.prepare_only produces a new canonical post frame. A message ACK and successful move never claim no-hover. Root must directly inspect the new canonical frame and use the original final review path before the actual Film manifest is released. No second root_checkpoint or new ready-reply schema was added.

The live wrapper makes no recorder Start and never Arms an observer. After Root's accepted actual manifest, the unchanged R18 actor owns the later recorder/observer/day/payment/OFF/Save/GUI order. Unknown input or failed readback is not automatically replayed.

## Source evidence

The four focused groups cover the actual new public loader/pending600, same retained client and both dynamic-reserve cases, independent-axis geometry and operation order, and wrong identity/size/rectangle or unacknowledged message refusals. All desktop/Windows operations are fake seams in these tests. The original focused-a01 and strict-a01 failures are retained; they were fixture mutation/run-label and explicit typing errors, not Game/native/GUI failures. Final focused/loader/strict receipts carry the original harmless Python Popen PID, canonical creation, real wait and before/after/current source pins.

No source-only result grants Game, recording, paid amount, payer, cadence, fullR08 or human visual acceptance.
