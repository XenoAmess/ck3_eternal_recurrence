"""Pointer-only, reviewed park + one WM_MOUSEMOVE, then canonical prepare-frame.

No click, keyboard, SDK or recorder Start. A message ACK never proves no hover.
All live work is behind --execute; source checks use only a fake backend.
"""
from __future__ import annotations
from collections.abc import Mapping as MappingObject
from ctypes import wintypes
from datetime import datetime, timezone
from pathlib import Path
from typing import Protocol
import argparse
import ctypes
import hashlib
import importlib
import json
import math
import sys
import time

UTILITY=Path('C:/ck3-e04-resume-20261020-a01/r21-r08-source-prepare-a01/source/normal')
sys.path.insert(0,str(UTILITY))
import r08_phase22_adapter as old
if Path(str(old.__file__)).resolve()!=UTILITY/'r08_phase22_adapter.py' or hashlib.sha256((UTILITY/'r08_phase22_adapter.py').read_bytes()).hexdigest()!='0db61be5a3aab712c6d17f40886acf49f9301fb46c66797111f9fc538ef1be7f':
    raise ValueError('Existing shared utility changed')
Object=dict[str,object]
SCENE=Path('C:/ck3-e04-resume-20261020-a01/r23-live-r08-phase23-a01')
CAMERA=Path('C:/ck3-e04-resume-20261020-a01/r15-complete-episode04-1030-a01/live-scene-b-a03/camera-source-a01')
MAP_PATH=Path('D:/workspace/ck3_eternal_recurrence/tools/desktop_coordinate_map.py')
MAP_SHA='3ef119ae95ae9c084844bcabecc63223413e3ad06ff64d67789fe320adb70991'
ENTRY_SHA='c9afd631936552dd39b5c26d895cd66ca60daf6e69e0221e2fad66f95e71e399'


def call(value:object,name:str,*args:object,**kwargs:object)->object:
    method:object=getattr(value,name,None)
    if not callable(method):raise ValueError('Existing callable unavailable: '+name)
    result:object=method(*args,**kwargs)
    return result


def pin(path:Path,maximum:int=1048576)->Object:
    old.need(0<path.stat().st_size<=maximum,'Bounded existing input required')
    data=path.read_bytes()
    return {'path':str(path.resolve()),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


def read(reference:object)->Object:
    ref=old.Pin.parse(reference);ref.verify_small()
    return old.obj(json.loads(ref.path.read_bytes()),'pinned JSON')


def write(path:Path,value:object)->None:
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')


def numbers(value:object,count:int)->tuple[float,...]:
    old.need(isinstance(value,(tuple,list)) and len(value)==count,'Explicit geometry required')
    if not isinstance(value,(tuple,list)):raise ValueError('Geometry absent')
    result:list[float]=[]
    for item in value:
        old.need(type(item) in (int,float),'Finite numeric coordinate required')
        if not isinstance(item,(int,float)):raise ValueError('Coordinate absent')
        result.append(float(item))
    old.need(all(math.isfinite(x) for x in result),'Finite geometry required')
    return tuple(result)


def bounds(value:object)->tuple[float,float,int,int]:
    row=numbers(value,4)
    old.need(row[2].is_integer() and row[3].is_integer() and row[2]>0 and row[3]>0,'Positive explicit image region dimensions required')
    return row[0],row[1],int(row[2]),int(row[3])


def size(value:object)->tuple[int,int]:
    row=numbers(value,2)
    old.need(all(x.is_integer() and x>0 for x in row),'Positive physical pixel dimensions required')
    return int(row[0]),int(row[1])


def same_owner(expected:Object,actual:Object)->None:
    old.need(set(expected)=={'pid','created_filetime','hwnd'},'Exact retained owner fields required')
    for key in ('pid','hwnd'):
        old.need(old.integer(expected[key],key)>0 and type(actual.get(key)) is int and actual[key]==expected[key],'Actual target '+key+' differs')
    birth=old.text(expected['created_filetime'],'canonical FILETIME')
    old.need(birth.isdecimal() and str(int(birth))==birth and 0<int(birth)<1<<64 and actual.get('created_filetime')==birth,
             'Actual same-handle FILETIME differs')


class Backend(Protocol):
    def identity(self)->Object: ...
    def dimensions(self)->tuple[int,int]: ...
    def source_dimensions(self,path:Path)->tuple[int,int]: ...
    def move(self,mapping:object,reviewed:tuple[float,float,int,int],source:Path,receipt:Path)->Object: ...
    def wm_mousemove(self,point:tuple[int,int])->Object: ...
    def screenshot(self,path:Path)->tuple[int,int]: ...
    def settle(self)->None: ...
    def prepare_frame(self,path:Path)->object: ...


def perform(intent:Object,backend:Backend,mapper:object)->Object:
    fields={'schema','machine_id','run_id','scene_root','owner','before_capture_pin','preview_bounds',
            'observed_point','reviewed_bounds','reviewed_by','reviewed_at_utc','camera_config_pin','output_root','frame_output'}
    old.need(set(intent)==fields and intent['schema']=='xar.e04.r08.preframe-hover-park.v1' and
             intent['machine_id']==old.MACHINE and Path(old.text(intent['scene_root'],'scene')).resolve()==SCENE.resolve(),
             'New R23 reviewed pointer intent required')
    now=datetime.now(timezone.utc)
    observed=datetime.fromisoformat(old.text(intent['reviewed_at_utc'],'review time').replace('Z','+00:00'))
    old.need(observed.tzinfo is not None and intent['reviewed_by']=='/root' and 0<=(now-observed).total_seconds()<=120,
             'Actual current Root-reviewed parking region required')
    owner=old.obj(intent['owner'],'retained target owner')
    config=read(intent['camera_config_pin'])
    old.need(config.get('machine_id')==old.MACHINE and config.get('content_kind')=='map-context' and
             Path(old.text(config.get('scene_root'),'camera scene')).resolve()==SCENE.resolve() and
             Path(old.text(config.get('run_dir'),'camera run')).name==intent['run_id'],'Actual camera config/run differs')
    original=read(intent['before_capture_pin']);source=old.obj(original.get('source'),'canonical capture source')
    old.need(original.get('schema')=='xar.e04.owned-client-original-frame.v1' and original.get('machine_id')==old.MACHINE and
             original.get('run_id')==intent['run_id'] and original.get('pid')==owner['pid'] and source.get('hwnd')==owner['hwnd'],
             'Original current-run source capture differs')
    image=old.Pin.parse(original.get('desktop_original'))
    old.need(0<image.bytes<=20*1024*1024 and pin(image.path,20*1024*1024)==image.wire(),'Reviewed full desktop original differs')
    live=backend.dimensions();old.need(backend.source_dimensions(image.path)==live,'Source and current desktop dimensions differ')
    preview=bounds(intent['preview_bounds']);observed_point=numbers(intent['observed_point'],2)
    target=call(mapper,'map_point',preview_bounds=preview,observed_point=observed_point,target_size=live)
    point:tuple[int,int]
    old.need(isinstance(target,tuple) and len(target)==2 and all(type(x) is int for x in target),'Canonical mapped integer point required')
    if not isinstance(target,tuple):raise ValueError('Mapped point absent')
    point=(old.integer(target[0],'screen x'),old.integer(target[1],'screen y'))
    mapping=call(mapper,'Mapping',preview,observed_point,live,live,point)
    reviewed=bounds(intent['reviewed_bounds']);call(mapper,'validate_reviewed_region',mapping,reviewed)
    first=backend.identity();same_owner(owner,first)
    old.need(source.get('client_screen_rect')==first.get('client_screen_rect') and size(source.get('desktop'))==live,
             'Current client geometry differs from the reviewed original capture')
    rect=numbers(first.get('client_screen_rect'),4)
    old.need(rect[0]<=point[0]<rect[2] and rect[1]<=point[1]<rect[3],'Reviewed parking point is outside actual target client')
    output=Path(old.text(intent['output_root'],'diagnostic output')).resolve()
    frame_output=Path(old.text(intent['frame_output'],'canonical output')).resolve()
    old.need(output.parent==frame_output.parent==SCENE.resolve() and output!=frame_output and
             not output.exists() and not frame_output.exists(),'Fresh independent scene-local outputs required')
    output.mkdir()
    write(output/'INTENT.actual.json',intent)
    before=output/'before-original.png';old.need(backend.screenshot(before)==live,'Independent pre-image size changed')
    move=backend.move(mapping,reviewed,image.path,output/'pointer-move.png')
    write(output/'POINTER-MOVE.actual.json',move)
    old.need(move.get('status')=='pointer-move-readback-matched' and move.get('failures')==[],'Canonical pointer move failed')
    after_move=backend.identity();same_owner(owner,after_move)
    old.need(after_move.get('client_screen_rect')==first.get('client_screen_rect'),'Target client geometry changed during pointer move')
    message=backend.wm_mousemove(point);write(output/'WM-MOUSEMOVE.actual.json',message)
    old.need(message.get('message')==512 and message.get('ack') is True,'One WM_MOUSEMOVE was not accepted')
    backend.settle()
    after=output/'after-original.png';old.need(backend.screenshot(after)==live and backend.dimensions()==live,'Independent post-image size changed')
    terminal=backend.identity();same_owner(owner,terminal)
    old.need(terminal.get('client_screen_rect')==first.get('client_screen_rect'),'Target client geometry changed during independent post-image')
    binding={'schema':'xar.e04.r08.preframe-hover-park-result.v1','machine_id':old.MACHINE,'run_id':intent['run_id'],
        'observed_at_utc':datetime.now(timezone.utc).isoformat(),'owner_before':first,'owner_after':terminal,
        'reviewed_source':image.wire(),'before_original':pin(before,20*1024*1024),'after_original':pin(after,20*1024*1024),
        'screen_point':point,'WM_MOUSEMOVE':message,'clicks':0,'keyboard_inputs':0,'SDK_calls':0,'recording_Starts':0,
        'no_hover_verified':False,'Root_must_review_actual_canonical_post_frame':True}
    write(output/'BINDING.actual.json',binding)
    result=backend.prepare_frame(frame_output)
    write(output/'CANONICAL-PREPARE-FRAME.actual.json',{'actual_result':result,'recording_approved':False})
    return binding


class WindowsBackend:
    def __init__(self,config:old.Pin,expected:Object,mapper:object)->None:
        entry_path=CAMERA/'camera_entry_a02.py'
        old.need(hashlib.sha256(entry_path.read_bytes()).hexdigest()==ENTRY_SHA,'Original camera entry changed')
        entry=old.load_module(old.Pin(entry_path,entry_path.stat().st_size,ENTRY_SHA),'r23_existing_camera_entry')
        call(entry,'bootstrap')
        self.window:object=importlib.import_module('window_take')
        self.spec=call(self.window,'TakeSpec',config.path)
        self.desktop:object=importlib.import_module('pyautogui')
        self.image:object=importlib.import_module('PIL.Image')
        self.mapper=mapper;self.expected=expected
        self.user=ctypes.WinDLL('user32',use_last_error=True)
        self.kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        self.kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
        self.kernel.OpenProcess.restype=wintypes.HANDLE
        handle:object=self.kernel.OpenProcess(0x1000,False,old.integer(expected.get('pid'),'PID',0xffffffff))
        if not isinstance(handle,int) or isinstance(handle,bool) or not handle:raise OSError(ctypes.get_last_error(),'OpenProcess query-only')
        self.handle=handle
        self.kernel.GetProcessTimes.argtypes=[wintypes.HANDLE]+[ctypes.POINTER(wintypes.FILETIME)]*4
        self.kernel.GetProcessTimes.restype=wintypes.BOOL
        self.kernel.CloseHandle.argtypes=[wintypes.HANDLE]

    def close(self)->None:
        if self.handle:self.kernel.CloseHandle(self.handle);self.handle=0

    def identity(self)->Object:
        row=call(self.window,'owner',self.spec)
        old.need(isinstance(row,tuple) and len(row)==8,'Original public camera owner tuple required')
        if not isinstance(row,tuple):raise ValueError('Original owner source absent')
        source=old.obj(row[7],'actual public camera source')
        c,e,k,u=(wintypes.FILETIME() for _ in range(4))
        if not self.kernel.GetProcessTimes(self.handle,ctypes.byref(c),ctypes.byref(e),ctypes.byref(k),ctypes.byref(u)):
            raise OSError(ctypes.get_last_error(),'GetProcessTimes same readonly handle')
        return {'pid':old.integer(source.get('owned_ck3_pid'),'actual PID',0xffffffff),'hwnd':old.integer(source.get('hwnd'),'actual HWND'),
            'created_filetime':str((int(c.dwHighDateTime)<<32)|int(c.dwLowDateTime)),
            'client_screen_rect':source['client_screen_rect'],'legacy_psutil_create_time':source['owned_ck3_create_time'],
            'birth_source':'GetProcessTimes-same-retained-readonly-handle','original_public_camera_owner_checked':True}

    def dimensions(self)->tuple[int,int]:return size(call(self.desktop,'size'))

    def source_dimensions(self,path:Path)->tuple[int,int]:
        image=call(self.image,'open',path)
        try:return size(getattr(image,'size',None))
        finally:call(image,'close')

    def move(self,mapping:object,reviewed:tuple[float,float,int,int],source:Path,receipt:Path)->Object:
        return old.obj(call(self.mapper,'move_pointer',mapping=mapping,reviewed_bounds=reviewed,source_image=source,
            receipt_path=receipt,desktop=self.desktop,expected_foreground_hwnd=self.expected['hwnd']),'canonical move')

    def wm_mousemove(self,point:tuple[int,int])->Object:
        hwnd=old.integer(self.expected['hwnd'],'HWND')
        self.user.ScreenToClient.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.POINT)]
        self.user.ScreenToClient.restype=wintypes.BOOL
        self.user.GetClientRect.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.RECT)]
        self.user.GetClientRect.restype=wintypes.BOOL
        self.user.PostMessageW.argtypes=[wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM]
        self.user.PostMessageW.restype=wintypes.BOOL
        self.user.SetThreadDpiAwarenessContext.argtypes=[ctypes.c_void_p]
        self.user.SetThreadDpiAwarenessContext.restype=ctypes.c_void_p
        previous=self.user.SetThreadDpiAwarenessContext(ctypes.c_void_p(-4))
        if not previous:raise OSError(ctypes.get_last_error(),'Physical thread DPI context')
        try:
            actual=wintypes.POINT(*point);rect=wintypes.RECT()
            if not self.user.ScreenToClient(hwnd,ctypes.byref(actual)) or not self.user.GetClientRect(hwnd,ctypes.byref(rect)):
                raise OSError(ctypes.get_last_error(),'Actual ScreenToClient/GetClientRect')
            old.need(rect.left<=actual.x<rect.right and rect.top<=actual.y<rect.bottom and
                     0<=actual.x<=32767 and 0<=actual.y<=32767,'Actual client point cannot be encoded as signed WM_MOUSEMOVE coordinates')
            packed=((actual.y&65535)<<16)|(actual.x&65535)
            ack=bool(self.user.PostMessageW(hwnd,0x0200,0,packed))
            return {'message':512,'ack':ack,'screen_point':point,'client_point':[actual.x,actual.y],
                'clicks':0,'SDK_calls':0,'no_hover_claimed_from_ACK':False,'physical_thread_DPI_context':-4}
        finally:self.user.SetThreadDpiAwarenessContext(previous)

    def screenshot(self,path:Path)->tuple[int,int]:return size(getattr(call(self.desktop,'screenshot',str(path)),'size',None))
    def settle(self)->None:time.sleep(1.2)
    def prepare_frame(self,path:Path)->object:return call(self.window,'prepare_only',self.spec,path)


def main()->None:
    parser=argparse.ArgumentParser();parser.add_argument('--intent',type=Path,required=True)
    parser.add_argument('--intent-sha256',required=True);parser.add_argument('--execute',action='store_true')
    args=parser.parse_args();reference=pin(args.intent)
    old.need(reference['sha256']==args.intent_sha256,'Exact reviewed intent differs')
    intent=read(reference)
    if not args.execute:
        print(json.dumps({'schema':'xar.e04.r08.preframe-plan.v1','machine_id':old.MACHINE,'intent':reference,'UI_actions':0,
                          'execute_requires_independent_fresh_Game_and_screen_authority':True}));return
    mapper=old.load_module(old.Pin(MAP_PATH,MAP_PATH.stat().st_size,MAP_SHA),'r23_canonical_coordinate_map')
    backend=WindowsBackend(old.Pin.parse(intent.get('camera_config_pin')),old.obj(intent.get('owner'),'owner'),mapper)
    try:print(json.dumps(perform(intent,backend,mapper)))
    finally:backend.close()


if __name__=='__main__':main()
