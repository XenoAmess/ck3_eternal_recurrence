"""Read retained R196 slices; decode only the small, explicitly derived sample.

No save mutation, world export, Game, SDK, or calculator invocation. The decoder
translates the original binary identifiers; its sample is not a loadable seed.
"""
from __future__ import annotations

import ctypes
from ctypes import wintypes as W
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

Json = None | bool | int | float | str | list["Json"] | dict[str, "Json"]
ROOT = Path(__file__).resolve().parent
CEILING = 524288
MACHINE = "desktop-3fevhd2-1c74096080"
SAVE = Path("D:/workspace/ck3_native_war_ai_promo_work/e04-r196-r07-treatment-a01/state-a01/profile/save games/xar_checkpoint.ck3")
DECODER = Path("D:/workspace/ck3_native_war_ai_promo_work/episode01-effect-save-attempt-008/rakaly-0.8.19-x86_64-pc-windows-msvc/rakaly.exe")
DECODER_SHA = "e154af990aaed2c2f44284946772188c9749ad3f6b641b41f6c23456a6f1633d"


def need(value: bool, why: str) -> None:
    if not value:
        raise ValueError(why)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def put(name: str, raw: bytes) -> dict[str, Json]:
    used = sum(p.stat().st_size for p in ROOT.rglob("*") if p.is_file())
    need(used + len(raw) <= CEILING, "author all-inclusive 512 KiB ceiling")
    path = ROOT / name
    with path.open("xb") as stream:
        stream.write(raw)
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}


def birth(child: subprocess.Popen[bytes]) -> str:
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetProcessTimes.argtypes = [W.HANDLE, ctypes.POINTER(W.FILETIME), ctypes.POINTER(W.FILETIME), ctypes.POINTER(W.FILETIME), ctypes.POINTER(W.FILETIME)]
    kernel.GetProcessTimes.restype = W.BOOL
    created, exited, system, user = W.FILETIME(), W.FILETIME(), W.FILETIME(), W.FILETIME()
    handle = W.HANDLE(int(child._handle))
    if not kernel.GetProcessTimes(handle, ctypes.byref(created), ctypes.byref(exited), ctypes.byref(system), ctypes.byref(user)):
        raise ctypes.WinError(ctypes.get_last_error())
    return str((created.dwHighDateTime << 32) | created.dwLowDateTime)


def one(pattern: str, text: str) -> str:
    found = re.findall(pattern, text, re.M | re.S)
    need(len(found) == 1, "missing/nonunique decoded scalar or block")
    return found[0]


def main() -> None:
    before = SAVE.stat()
    need(before.st_size == 74482297, "R196 final retained save size changed")
    tool_digest = hashlib.sha256()
    with DECODER.open("rb") as stream:
        while part := stream.read(1048576):
            tool_digest.update(part)
    need(tool_digest.hexdigest() == DECODER_SHA, "existing decoder pin changed")
    specs = [("original_header_and_metadata", 0, 34494), ("original_actor_31254_key_and_block", 20861663, 6546), ("original_culture_73_key_and_block", 61588916, 6181)]
    chunks: list[bytes] = []
    spans: list[Json] = []
    with SAVE.open("rb") as stream:
        for role, offset, count in specs:
            stream.seek(offset)
            raw = stream.read(count)
            need(len(raw) == count, "short retained save slice")
            chunks.append(raw)
            spans.append({"role": role, "source_offset": offset, "bytes": count, "sha256": sha(raw)})
    sample = b"".join(chunks)
    need(len(sample) == 47221, "derived sample bound")
    argv = [str(DECODER), "melt", "-c", "--format", "ck3", "--unknown-key", "stringify"]
    child: subprocess.Popen[bytes] = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=0x08000000)
    try:
        created = birth(child)
        out, err = child.communicate(sample)
    finally:
        # The original offline decoder owner is consumed even if birth/read fails.
        if child.poll() is None:
            child.communicate()
        wait_code = child.wait()
    need(wait_code == 0 and not err, "small dictionary decode failed")
    need(len(out) < 131072, "decoder output bound")
    text = out.decode("utf-8")
    actor = one(r"^31254=\{\n(.*?)^\}\n", text)
    culture = one(r"^73=\{\n(.*?)^\}\n?\Z", text)
    need(one(r"^\tculture=(\d+)$", actor) == "73", "actor culture differs")
    need(one(r'^\tculture_template="([^"]+)"$', culture) == "norman", "culture template differs")
    longboats = one(r'\{\n\t\t\ttype="innovation_longboats"\n(.*?)\t\t\}', culture)
    need(one(r"^\t\t\tprogress=([\d.]+)$", longboats) == "100", "longboats not completed")
    named_modifiers = re.findall(r'^\t\t\tmodifier="([^"]+)"$', actor, re.M)
    perks = one(r"^\t\tperk=\{\n(.*?)^\t\t\}", actor).split()
    traditions = one(r"^\ttraditions=\{\n(.*?)^\t\}", culture).split()
    after = SAVE.stat()
    need((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), "save identity stat changed")
    input_pin = put("R196-DECODER-SLICES.derived-a01.bin", sample)
    projection: dict[str, Json] = {
        "schema": "xar.r22.r196-embark.saved-input-small-projection.v1",
        "machine_id": MACHINE,
        "observed_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_save": {"path": str(SAVE), "bytes": before.st_size, "mtime_ns": str(before.st_mtime_ns), "prior_qualified_sha256": "92237e6bee34b1cefac1b6ebe517d40055461c49fcba86cd1f4a2951d0e83f81", "new_whole_save_hash_computed": False},
        "source_spans": spans,
        "derived_dictionary_input": input_pin,
        "derivation": "Byte-exact original header/metadata followed by only the two original numeric-keyed blocks; not a complete world, original whole Save, or game input.",
        "decoder": {"path": str(DECODER), "bytes": DECODER.stat().st_size, "sha256": DECODER_SHA, "argv": list(argv), "original_pid": child.pid, "original_created_filetime": created, "original_wait": wait_code, "stdout_bytes": len(out), "stdout_sha256": sha(out), "stderr_bytes": len(err), "input_in_ram_bytes": len(sample), "stdout_saved_as_world": False},
        "actor": {"full_id": 31254, "first_name": "Robert", "culture_id": 73, "saved_gold_decimal": one(r"gold=\{\n\t\t\tvalue=([\d.]+)", actor), "named_modifiers": list(named_modifiers), "perks": list(perks), "trait_numeric_ids": [69, 51, 67, 19, 31, 158], "native_modifier_0x11B_aggregate_observed": False},
        "culture": {"id": 73, "template": "norman", "longboats_progress": 100, "traditions": list(traditions)},
        "scope": {"Game": False, "SDK": False, "new_native_build": False, "save_mutated": False, "world_exported": False, "same_fee_invocation_atomic_input_capture": False},
        "prior_ram_decoder_attempts": [{"sample_bytes": 12751, "wait": 2, "error": "invalid header", "reason": "omitted the original metadata required by the unchanged header"}, {"sample_bytes": 47221, "wait": 0, "stdout_bytes": 48905, "reason": "same byte-exact original spans as this persisted original-owner capture; earlier PID was not retained"}],
    }
    put("R196-SAVED-DISCOUNT-SOURCE.actual-a01.json", (json.dumps(projection, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    print(json.dumps({"machine_id": MACHINE, "pid": child.pid, "created_filetime": created, "original_wait": wait_code, "actor_culture": 73, "culture": "norman", "longboats": 100, "named_modifiers": named_modifiers, "traditions": traditions}, ensure_ascii=False))


if __name__ == "__main__":
    main()
