"""Freeze exact small research sources; no application or gameplay actions."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MACHINE = "desktop-3fevhd2-1c74096080"
type Pin = dict[str, str | int]


def pin(path: Path) -> Pin:
    data = path.read_bytes()
    return {"path": path.name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def put(name: str, value: object) -> Pin:
    data = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
    used = sum(p.stat().st_size for p in ROOT.rglob("*") if p.is_file())
    if used + len(data) > 524288:
        raise ValueError("author budget")
    with (ROOT / name).open("xb") as stream:
        stream.write(data)
    print(json.dumps({"name": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "lane_bytes": used + len(data)}))
    return pin(ROOT / name)


def main() -> None:
    files = [pin(p) for p in sorted(ROOT.iterdir()) if p.is_file()]
    payload_bytes = sum(p.stat().st_size for p in ROOT.iterdir() if p.is_file())
    index = put("SOURCE-INDEX.candidate-a01.json", {
        "schema": "xar.r22.r07.embark.fee.source-index.v1",
        "machine_id": MACHINE,
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "files": files,
        "file_count": len(files),
        "source_bytes": payload_bytes,
        "roles": {
            "R07-EMBARK-FEE-SOURCE.candidate-a01.md": "source-bound explanation; not published or runtime-loaded",
            "FUNCTION-024E86D0.actual.json": "byte-exact original .4 fee function evidence",
            "FUNCTION-024E8DB0.actual.json": "byte-exact original .4 boarding conversion function evidence",
            "MODIFIER-REGISTRATION-CLOSED.actual-a02.json": "final correct row boundary and actual constructor/parser; supersedes a01 row-ID annotations",
            "R196-DECODER-SLICES.derived-a01.bin": "only original header and two selected key/block spans; derived dictionary input, never a Game Save",
            "R196-SAVED-DISCOUNT-SOURCE.actual-a01.json": "actual original decoder PID/FILETIME/wait and saved culture/innovation inputs",
            "R196-FEE-ARITHMETIC.derived-a01.json": "offline exact arithmetic, not native execution",
            "R196-SOLDIER-COUNT-READER.actual-a01.json": "historical reader source correspondence, not atomic fee input capture",
        },
        "proposed_publication": {
            "status": "CANDIDATE_NOT_PUBLISHED",
            "markdown_target": "docs/ck3-native-ai/episode04-r07-embark-fee-formula-12004.md",
            "evidence_prefix": "docs/ck3-native-ai/evidence/episode04-r07-embark-fee-formula-12004/",
            "mapping": "Selected evidence retains its basename under evidence_prefix; Markdown is mapped separately. This does not claim source files are already in Git.",
        },
        "existing_portable_sources": [
            "docs/ck3-native-ai/episode04-r196-r07-boarding-pair-12004.md",
            "docs/ck3-native-ai/evidence/episode04-r196-r07-boarding-pair-12004/PRODUCTION-PAIR-REPLAY.actual-a01.json",
            "docs/ck3-native-ai/evidence/episode04-r196-r07-boarding-pair-12004/CLOSED-PAIR-ASSESSMENT.actual-a01.json",
            "docs/ck3-native-ai/war-payment-passive-12004.md",
        ],
        "evidence_layers": {
            "ordinary_fee_formula_source_closed": True,
            "current_key_11B_name_registration_closed": True,
            "base_rate_and_minimum_global_registration_closed": True,
            "historical_R196_culture_and_longboats_input_decoded": True,
            "historical_R196_three_gold_actual_payment": True,
            "atomic_R196_full_effective_cache_dump": False,
            "native_aggregate_exclusive_discount_decomposition": False,
            "new_game_or_native_qualification": False,
            "planner_autoload": False,
        },
        "historical_method_corrections": [
            "Metadata row a01 started16B early; final a02 actual row begins at caption-pointer slot and uses u16 row+28 directly. Prior evidence not overwritten.",
            "First tiny decoder sample omitted required metadata and returned2; corrected original-header sample actually returned0. Earlier RAM process identity absence is not backfilled.",
            "persist_primary_sources first copied two exact native sources then failed on an excerpt end beyond file lines. Helper corrected before freeze; exact existing copies verified without rewrite; second execution exited0.",
        ],
        "read_limits": {
            "original_first_rdata_plus_text_scan_bytes": 88266240,
            "additional_rdata_and_data_pointer_pass_bytes": 31987200,
            "selected_table_read_bytes_at_least": 33600,
            "new_authorized_rdata_plus_text_locator_increment_bytes": 88266240,
            "new_locator_increment_ceiling_bytes": 100663296,
            "new_selected_direct_function_bytes": 4716,
            "native_locator_and_retained_native_source_output_bytes": 128343,
            "native_output_ceiling_bytes": 131072,
            "whole_exe_hash_recomputed": False,
            "full_save_hash_recomputed": False,
            "whole_save_exported": False,
            "streams_bounded": True,
            "whole_process_memory_peak_measured": False,
        },
    })
    unchanged = True
    for row in files:
        name = row["path"]
        if not isinstance(name, str):
            raise ValueError("internal pin shape")
        unchanged = unchanged and pin(ROOT / name) == row
    if not unchanged:
        raise ValueError("source changed while freezing")
    freeze = put("SOURCE-FREEZE.actual-a01.json", {
        "schema": "xar.r22.r07.embark.fee.source-freeze.v1",
        "machine_id": MACHINE,
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "source_index": index,
        "file_pins_verified_against_current": unchanged,
        "payload_file_count": len(files),
        "payload_bytes": payload_bytes,
        "deadline_utc": "2026-10-22T08:00:00Z",
        "author_budget_bytes": 524288,
        "scope": "Offline static reads, small historical Save slice decode, and source-bound documentation. No Game/SDK/build/Steam/UI/Git mutation.",
        "notes": "Index excludes itself and later closure metadata. Not a gameplay qualification.",
    })
    put("DELIVERY.actual-a01.json", {
        "schema": "xar.r22.r07.embark.fee.delivery.v1",
        "machine_id": MACHINE,
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "source_freeze": freeze,
        "source_index": index,
        "primary_markdown": pin(ROOT / "R07-EMBARK-FEE-SOURCE.candidate-a01.md"),
        "final_registration": pin(ROOT / "MODIFIER-REGISTRATION-CLOSED.actual-a02.json"),
        "key_result": "round_half_up(1162/100*1*max(1-0.75,0.1))=3, reconciled with original personal wallet debit300000. Current .4 source proves count/rate/modifier/floor/final rounding and transition-to-payment path.",
        "limits": "Effective aggregate not atomically dumped or exclusively decomposed. Historical R196 source package, not Git publication, planner autoload, or new Game qualification.",
        "writer0_after_this_file": True,
        "owned_processes": 0,
    })


if __name__ == "__main__":
    main()
