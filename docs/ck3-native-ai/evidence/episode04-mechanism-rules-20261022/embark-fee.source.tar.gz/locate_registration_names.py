"""One finite, read-only pass over the approved exact .4 PE sections."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parent
EXE = Path("C:/ck3-e04-resume-20261015-a01/frozen-game-12004/ck3.exe")
NAMES = [b"embarkation_cost_mult", b"EMBARK_GOLD_COST_PER_HUNDRED", b"STANDARD_MINIMUM_VALUE"]


def need(value: bool, why: str) -> None:
    if not value:
        raise ValueError(why)


def main() -> None:
    before = EXE.stat()
    need((before.st_size, before.st_mtime_ns) == (101040248, 1792052259095683000), "frozen input stat changed")
    with EXE.open("rb") as stream:
        head = stream.read(1024)
        pe = struct.unpack_from("<I", head, 0x3C)[0]
        count = struct.unpack_from("<H", head, pe + 6)[0]
        optional = struct.unpack_from("<H", head, pe + 20)[0]
        stream.seek(pe + 24 + optional)
        raw_sections = stream.read(count * 40)
        sections: dict[str, tuple[int, int, int, int]] = {}
        for i in range(count):
            row = raw_sections[i * 40:(i + 1) * 40]
            name = row[:8].rstrip(b"\0").decode("ascii")
            virtual_size, virtual_address, raw_size, raw_pointer = struct.unpack_from("<IIII", row, 8)
            sections[name] = virtual_address, virtual_size, raw_pointer, raw_size
        need(sections[".text"][3] + sections[".rdata"][3] <= 90 * 1024 * 1024, "approved two-section read ceiling")
        occurrences: dict[str, list[int]] = {n.decode(): [] for n in NAMES}
        rva, _, offset, size = sections[".rdata"]
        stream.seek(offset)
        done, prior = 0, b""
        while done < size:
            chunk = stream.read(min(1048576, size - done))
            need(bool(chunk), "short rdata")
            data = prior + chunk
            for needle in NAMES:
                start = 0
                while True:
                    found = data.find(needle, start)
                    if found < 0:
                        break
                    where = rva + done - len(prior) + found
                    if where not in occurrences[needle.decode()]:
                        occurrences[needle.decode()].append(where)
                    start = found + 1
            done += len(chunk)
            prior = data[-128:]
        targets = {x for values in occurrences.values() for x in values}
        references: list[dict[str, int | str]] = []
        rva, _, offset, size = sections[".text"]
        stream.seek(offset)
        done, prior = 0, b""
        while done < size:
            chunk = stream.read(min(1048576, size - done))
            need(bool(chunk), "short text")
            data = prior + chunk
            start = 0
            while True:
                found = data.find(b"\x8D", start)
                if found < 0:
                    break
                start = found + 1
                if found + 6 > len(data) or data[found + 1] & 0xC7 != 5:
                    continue
                instruction_next = rva + done - len(prior) + found + 6
                target = instruction_next + struct.unpack_from("<i", data, found + 2)[0]
                if target not in targets:
                    continue
                begin = found - 1 if found and data[found - 1] & 0xF0 == 0x40 else found
                site = rva + done - len(prior) + begin
                row: dict[str, int | str] = {"candidate_lea_rva": site, "target_name_rva": target, "candidate_hex": data[begin:found + 6].hex()}
                if row not in references:
                    references.append(row)
            done += len(chunk)
            prior = data[-16:]
        # Only .pdata rows necessary to locate these candidate references.
        pdata_rva, pdata_virtual, pdata_offset, pdata_size = sections[".pdata"]
        pdata_reads = 0
        for reference in references:
            site = reference["candidate_lea_rva"]
            need(type(site) is int, "internal site shape")
            low, high = 0, min(pdata_virtual, pdata_size) // 12
            while low < high:
                middle = (low + high) // 2
                stream.seek(pdata_offset + middle * 12)
                block = stream.read(12)
                need(len(block) == 12, "short pdata")
                pdata_reads += 1
                begin, end, unwind = struct.unpack("<III", block)
                if site < begin:
                    high = middle
                elif site >= end:
                    low = middle + 1
                else:
                    reference.update({"containing_pdata_begin": begin, "containing_pdata_end": end, "containing_pdata_bytes": end - begin, "unwind_rva": unwind})
                    break
        after = EXE.stat()
        need((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), "frozen input changed")
    result = {
        "schema": "xar.r22.embark.exact4.registration-locator.v1",
        "machine_id": "desktop-3fevhd2-1c74096080",
        "observed_at_utc": datetime.now(timezone.utc).isoformat(),
        "input": {"path": str(EXE), "bytes": before.st_size, "mtime_ns": str(before.st_mtime_ns), "prior_qualified_sha256": "98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518", "new_whole_image_hash": False},
        "section_bytes_read": {".rdata": sections[".rdata"][3], ".text": sections[".text"][3]},
        "metadata_bytes_read": 1024 + count * 40 + pdata_reads * 12,
        "literal_occurrences": occurrences,
        "candidate_rip_lea_references": references,
        "limits": "LEA byte locator only; instruction/context confirmation is separate. Not a Game, SDK, execution, or runtime-aggregate observation.",
    }
    data = (json.dumps(result, indent=2) + "\n").encode()
    need(len(data) <= 65536, "locator output cap")
    used = sum(p.stat().st_size for p in ROOT.rglob("*") if p.is_file())
    need(used + len(data) <= 524288, "author budget")
    with (ROOT / "EXE-REGISTRATION-LOCATOR.actual-a01.json").open("xb") as output:
        output.write(data)
    print(json.dumps({"names": occurrences, "references": references, "output_bytes": len(data), "output_sha256": hashlib.sha256(data).hexdigest()}))


if __name__ == "__main__":
    main()
