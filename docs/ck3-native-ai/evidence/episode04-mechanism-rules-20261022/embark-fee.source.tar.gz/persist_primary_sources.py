"""Persist only exact small sources and bounded read-only projections."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent


def put(name: str, data: bytes) -> None:
    used = sum(p.stat().st_size for p in ROOT.rglob("*") if p.is_file())
    if used + len(data) > 524288:
        raise ValueError("author budget")
    with (ROOT / name).open("xb") as stream:
        stream.write(data)
    print(json.dumps({"name": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "lane_bytes": used + len(data)}))


def main() -> None:
    for name, size, digest in [
        ("FUNCTION-024E86D0.actual.json", 38784, "6c207bf1d5b416e958e5d7b4e7ca17b08249cad586bac585d48a0273ad2ad042"),
        ("FUNCTION-024E8DB0.actual.json", 11885, "0ed8e282205a005768bfe3bdc589c75bbe367c54296baeec5438b5b8172dc52c"),
    ]:
        data = (Path("C:/ck3-e04-resume-20261015-a01/capability-lane/payment-source-a01") / name).read_bytes()
        if len(data) != size or hashlib.sha256(data).hexdigest() != digest:
            raise ValueError("native source pin")
        if (ROOT / name).exists():
            if (ROOT / name).read_bytes() != data:
                raise ValueError("existing native copy differs")
        else:
            put(name, data)
    game = Path("C:/SteamLibrary/steamapps/common/Crusader Kings III/game")
    sources = []
    for relative, digest, windows in [
        ("common/defines/00_defines.txt", "8e430d77eb6e8767030f34b1c53d5dae84277fb354bd73cc42f93dc500be8982", [(695, 705), (1435, 1440), (1186, 1192)]),
        ("common/culture/innovations/00_tribal_innovations.txt", "e878e75efa1dba64557b254a68c4a1f4379ea92209bfb6821d6876db68f1f961", [(391, 406)]),
        ("common/modifiers/00_bookmark_modifiers.txt", "02b29dabace16b9c0c9ab74c6e30959b2bc8bf4e30adee9d08fff657a8bd6c49", [(22, 31)]),
        ("history/cultures/norman.txt", "43928cce3e8cd5250a9b138605e25aa6a74d0e5319ccf7a574eae71d91422df9", [(1, 18)]),
    ]:
        path = game / relative
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != digest:
            raise ValueError("official source changed: " + relative)
        lines = data.decode("utf-8-sig").splitlines()
        sources.append({"source_path": str(path), "relative_game_path": relative, "bytes": len(data), "sha256": digest, "line_excerpts": [{"line": i, "text": lines[i - 1]} for begin, end in windows for i in range(begin, min(end, len(lines)) + 1)]})
    value = {"schema": "xar.r22.embark.official-input-sources.v1", "machine_id": "desktop-3fevhd2-1c74096080", "observed_utc": datetime.now(timezone.utc).isoformat(), "sources": sources, "scope": "Read-only installed script bytes matched prior exact source hashes; no fresh installed-version or Game qualification implied."}
    put("OFFICIAL-FEE-INPUTS.actual-a01.json", (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode())
    history = Path("D:/workspace/ck3_native_war_ai_promo_work/e04-r196-r07-treatment-a01/state-a01/native-session/army-query-history-results/army-query-bc9ba249423c440a98916b001cfd7766.json")
    with history.open("rb") as stream:
        prefix = stream.read(100000)
    text = prefix.decode("utf-8")
    key = text.find('"current_land_supply_rate_inputs_v1"')
    if key < 0:
        raise ValueError("land inputs absent bounded prefix")
    begin = text.index("{", key)
    original, end = json.JSONDecoder().raw_decode(text, begin)
    if original["loaded_divisor_floor_raw"] != 10000:
        raise ValueError("historical floor changed")
    env = os.environ.copy()
    env["GIT_NO_LAZY_FETCH"] = "1"
    command = ["git", "--no-optional-locks", "-C", "D:/workspace/ck3_eternal_recurrence", "show", "611bc:ck3_autonomous_player/native_bridge/src/ck3_12004_army_support.cpp"]
    result = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if result.returncode:
        raise ValueError("historical source object unavailable")
    digest = hashlib.sha256(result.stdout).hexdigest()
    if digest != "7a2a91eec461b2bbf9967a6116d03c40ba6e4d16fa2f1cb85ba20fc048755ba2":
        raise ValueError("historical source pin")
    lines = result.stdout.decode("utf-8").splitlines()
    value = {"schema": "xar.r22.r196.same-session.loaded-floor.v1", "machine_id": "desktop-3fevhd2-1c74096080", "observed_utc": datetime.now(timezone.utc).isoformat(), "history_source": {"path": str(history), "bytes": 11162740, "prior_qualified_sha256": "7519811e382c8a2ea98612aa458fde0e97de200c8c67af844e01bba6adab740e", "new_whole_hash": False, "prefix_bytes_read": len(prefix), "object_start_byte": len(text[:begin].encode()), "object_end_byte": len(text[:end].encode())}, "original_object": original, "reader_source": {"git_revision": "611bc", "path": "ck3_autonomous_player/native_bridge/src/ck3_12004_army_support.cpp", "bytes": len(result.stdout), "sha256": digest, "line_excerpts": [{"line": i, "text": lines[i - 1]} for i in range(170, 182)]}, "adjudication": "The same R196 baseline native query actually loaded 10000 from .4 RVA5C68F68 (Q100000=0.1). This is not an atomic fee-invocation input sample."}
    put("R196-LOADED-MINIMUM.actual-a01.json", (json.dumps(value, indent=2) + "\n").encode())


if __name__ == "__main__":
    main()
