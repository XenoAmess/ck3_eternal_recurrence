"""Bounded static source capture. Never import or call a game process."""
from __future__ import annotations

import argparse
import atexit
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys

from capstone import Cs, CS_ARCH_X86, CS_MODE_64

ROOT = Path('D:/workspace/ck3_eternal_recurrence')
LANE = Path(__file__).resolve().parent
EXE = Path('C:/SteamLibrary/steamapps/common/Crusader Kings III/binaries/ck3.exe')
EXE_SHA = '98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518'
MACHINE = 'desktop-3fevhd2-1c74096080'
RAW_CEILING = 269887  # Prior observed138815 plus Root a04 new-read cap131072.
LANE_CEILING = 786432  # Actual SOURCE2-PARTITION a02; total research pool unchanged.

@dataclass(frozen=True)
class Span:
    name: str
    start: int
    length: int
    sha256: str | None

PRIOR = (
    Span('high_cost', 0x30BD510, 329, '2c04e350884ca804564d2339e2d9fddecd45f354338f829ff3742963c19befcd'),
    Span('low_cost', 0x30BD3C0, 329, 'b2f213c5e9761f51666c71054001ea600abbcbfdb591fd1e3dc8d5902f2a1bcf'),
    Span('cost_quantity_scale', 0x30BD300, 187, '6e74c2b14f624063174dbb51e7034e49d46212cb8cc347be0f67ed557fb4de99'),
    Span('divide_vector_entry', 0x30CF750, 21, 'a04e6c4c4c2446f0ec209291611954ea24f9bd3f145efa287e635aab14973892'),
    Span('divide_vector_loop', 0x30CF765, 310, '2edcd8dae640565234e4b44fdbd1cdcbf008b3057aebaaf789bf9d2f1bddbbd4'),
    Span('divide_vector_tail', 0x30CF89B, 14, '271106b0dadbcab2c160a539516af1aebd6e0422ff6b46ed0b9b5b7246fda741'),
    Span('divide_vector_zero_tail', 0x30CF8A9, 9, 'eec94af356c5ff4d397677c5098e3e4382d90afbb00d5aa2bf932fd4f32a03f7'),
    Span('cost_resource_conversion_1', 0x30BCAF0, 219, '4f32cae53ad5a52aa660e9e9510492faa2c62faefe2a61aa03f62522ff124602'),
    Span('cost_resource_conversion_2', 0x30BCBD0, 258, '03818c9bfe4502abf88770278491897a223685671288f07bf1f236efa935c320'),
    Span('cost_resource_conversion_3', 0x30BCCE0, 284, '675cf4a6022eb6777d9a374c8ce1cc9d1f28b466264c33e3c1cde1638c02ee2a'),
    Span('route_duration_logical_extent', 0x24AAD80, 704, 'ce60c96b74109f03453b2d077c8acd0e5d6a080aa3003b56179614960fabc090'),
    Span('route_edge_duration', 0x2649300, 541, 'efb2b2d0149c3fcfd58aff14365fd39f4cceee54b47aa12c7d018f33deacdb2c'),
    Span('land_speed_logical_extent', 0x24AA920, 703, '2cfdf377b7a2aec418dca423e8b9f5ca7c0615ae1c491dd197af254729a0a1c2'),
    Span('current_edge_speed', 0x24AB5A0, 260, '5898263e1a8d8bd9f2b20c550619464e40b44ac7f797686c3333c6cbd3b20a70'),
    Span('route_builder', 0x2648130, 2429, '2217f4106b0f60370fcc9ce9737dd3a88c72149c5ba642e45a32f0d5f66f5061'),
)

def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)

def lane_bytes() -> int:
    return sum(p.stat().st_size for p in LANE.rglob('*') if p.is_file())

def strict_integer(value: object, name: str) -> int:
    require(type(value) is int, name + ' must be an integer')
    if type(value) is not int:
        raise ValueError(name)
    return value

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('prior', 'functions', 'span', 'data', 'metadata'), required=True)
    parser.add_argument('--label', required=True)
    parser.add_argument('--target', action='append', default=[])
    parser.add_argument('--length', type=int)
    args = parser.parse_args()
    require(args.label.isascii() and args.label.replace('-', '').isalnum(), 'invalid label')
    output = LANE / (args.label + '.a04.json')
    require(not output.exists(), 'immutable capture already exists')
    require(datetime.now(timezone.utc).isoformat() < '2026-10-22T08:00:00', 'deadline')
    prior_usage = 0
    for packet in list(LANE.glob('*.source.json')) + list(LANE.glob('*.a04.json')):
        record = json.loads(packet.read_bytes())
        require(type(record) is dict and record.get('schema') in ('xar.e04.mechanics.static-source.v1', 'xar.e04.mechanics.static-source.a04.v1'), 'packet schema')
        prior_usage += strict_integer(record['new_exe_read_bytes'], 'prior read count')
    require(prior_usage < RAW_CEILING, 'raw read quota already spent')
    sys.path.insert(0, str(ROOT / 'tools'))
    from ck3_live_run_id import current_machine_id
    require(current_machine_id() == MACHINE, 'machine identity mismatch')
    stat_before = EXE.stat()
    require(stat_before.st_size == 101040248, 'EXE size mismatch')
    mapper_path = ROOT / 'ck3_autonomous_player/native_bridge/research/disasm_ck3_bounded_disk.py'
    spec = importlib.util.spec_from_file_location('bounded_mapper', mapper_path)
    require(spec is not None and spec.loader is not None, 'mapper unavailable')
    if spec is None or spec.loader is None:
        raise ValueError('mapper unavailable')
    mapper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mapper)
    reads: list[dict[str, int | str]] = []
    read_bytes = 0
    completed = False

    def preserve_incomplete() -> None:
        if completed or output.exists() or not reads:
            return
        payload = {'schema': 'xar.e04.mechanics.static-source.a04.v1',
                   'machine_id': MACHINE,
                   'observed_at_utc': datetime.now(timezone.utc).isoformat(),
                   'status': 'INCOMPLETE_READ_ATTEMPT_NO_SOURCE_CREDIT',
                   'label': args.label,
                   'planned_targets': args.target,
                   'new_exe_read_bytes': read_bytes,
                   'previous_scope_exe_read_bytes': prior_usage,
                   'cumulative_scope_exe_read_bytes': prior_usage + read_bytes,
                   'read_ledger': reads}
        data = (json.dumps(payload, separators=(',', ':')) + '\n').encode('utf-8')
        if lane_bytes() + len(data) <= LANE_CEILING:
            with output.open('xb') as destination:
                destination.write(data)

    atexit.register(preserve_incomplete)
    with EXE.open('rb') as source:
        def read_raw(offset: int, size: int, purpose: str) -> bytes:
            nonlocal read_bytes
            require(0 < size <= 16384, 'individual read range')
            require(prior_usage + read_bytes + size <= RAW_CEILING, 'cumulative EXE read quota')
            source.seek(offset)
            data = source.read(size)
            require(len(data) == size, 'short source read')
            read_bytes += size
            reads.append({'offset': offset, 'bytes': size, 'purpose': purpose})
            return data

        header = read_raw(0, 1024, 'bounded PE header and section table')
        require(header[:2] == b'MZ', 'DOS header')
        pe = struct.unpack_from('<I', header, 0x3C)[0]
        require(header[pe:pe+4] == b'PE\0\0', 'PE header')
        count = struct.unpack_from('<H', header, pe+6)[0]
        opt_size = struct.unpack_from('<H', header, pe+20)[0]
        opt = pe + 24
        require(struct.unpack_from('<H', header, opt)[0] == 0x20B, 'PE32+')
        image_base = struct.unpack_from('<Q', header, opt+24)[0]
        pdata_rva, pdata_size = struct.unpack_from('<II', header, opt+112+24)
        section_offset = opt + opt_size
        mapped: list[tuple[int, int, int]] = []
        for index in range(count):
            virtual_size, virtual_address, raw_size, raw_pointer = struct.unpack_from('<IIII', header, section_offset+index*40+8)
            mapped.append((virtual_address, min(virtual_size, raw_size), raw_pointer))

        def offset_of(rva: int, size: int) -> int:
            for begin, length, file_offset in mapped:
                if begin <= rva and rva+size <= begin+length:
                    return file_offset+rva-begin
            raise ValueError('source range outside a raw section')

        def read_rva(rva: int, size: int, purpose: str) -> bytes:
            return read_raw(offset_of(rva, size), size, purpose)

        anchor = read_rva(0x262BE10, 660, 'existing exact4 identity anchor')
        require(hashlib.sha256(anchor).hexdigest() == 'b565d2261e9e4549c7f34ff31c97fd14849756a8e68d10e6fb7c23e9109230ef', 'exact4 anchor mismatch')

        selected_pdata_index: int | None = None

        def extent(target: int) -> tuple[int, int, int]:
            nonlocal selected_pdata_index
            lo, hi = 0, pdata_size//12
            while lo < hi:
                middle = (lo+hi)//2
                row = struct.unpack('<III', read_rva(pdata_rva+middle*12,12,'exception-directory binary search'))
                if row[0] <= target:
                    lo = middle+1
                else:
                    hi = middle
            row = struct.unpack('<III', read_rva(pdata_rva+(lo-1)*12,12,'selected exception-directory record'))
            require(row[0] <= target < row[1], 'no containing .pdata record')
            selected_pdata_index = lo - 1
            return row

        spans: list[Span] = []
        metadata_rows: list[tuple[int, int, int]] = []
        if args.mode == 'prior':
            require(not args.target and args.length is None, 'prior mode arguments')
            spans = list(PRIOR)
        elif args.mode == 'metadata':
            require(len(args.target) == 1 and args.length is None, 'metadata mode arguments')
            extent(int(args.target[0], 16))
            require(selected_pdata_index is not None, 'missing .pdata index')
            if selected_pdata_index is None:
                raise ValueError('missing .pdata index')
            for index in range(max(0, selected_pdata_index-3), min(pdata_size//12, selected_pdata_index+4)):
                metadata_rows.append(struct.unpack('<III', read_rva(pdata_rva+index*12, 12, 'local .pdata metadata only')))
        elif args.mode == 'functions':
            require(bool(args.target) and args.length is None, 'functions mode arguments')
            for value in args.target:
                target = int(value,16)
                begin,end,_ = extent(target)
                require(end-begin <= 8192, 'function needs a larger explicit source plan')
                spans.append(Span('function-containing-'+value.lower(),begin,end-begin,None))
        else:
            require(bool(args.target) and type(args.length) is int, 'span mode arguments')
            if type(args.length) is not int:
                raise ValueError('span length')
            require(0 < args.length <= 16384, 'span length limit')
            for value in args.target:
                spans.append(Span('explicit-data-or-code-span',int(value,16),args.length,None))
        decoder = Cs(CS_ARCH_X86,CS_MODE_64)
        captured = []
        for span in spans:
            data=read_rva(span.start,span.length,span.name)
            digest=hashlib.sha256(data).hexdigest()
            require(span.sha256 is None or span.sha256==digest,'prior source changed')
            instructions=list(decoder.disasm(data,span.start)) if args.mode != 'data' else []
            complete=sum(i.size for i in instructions)==len(data)
            if args.mode not in ('span', 'data'):
                require(complete,'incomplete code decode')
            captured.append({'name':span.name,'start_rva':f'{span.start:X}','end_rva_exclusive':f'{span.start+span.length:X}','file_offset':offset_of(span.start,span.length),'bytes':len(data),'sha256':digest,'source_hex':data.hex(),'complete_linear_decode':complete,'instructions':[[f'{i.address:X}',i.bytes.hex(),i.mnemonic,i.op_str] for i in instructions if i.mnemonic in ('lea','call','jmp') or (i.mnemonic.startswith('j')) or ('[' in i.op_str.split(',')[0] and 'rsp' not in i.op_str.split(',')[0] and 'rbp' not in i.op_str.split(',')[0])]})
    stat_after=EXE.stat()
    require((stat_before.st_ino,stat_before.st_size,stat_before.st_mtime_ns)==(stat_after.st_ino,stat_after.st_size,stat_after.st_mtime_ns),'EXE identity changed')
    payload={'schema':'xar.e04.mechanics.static-source.a04.v1','machine_id':MACHINE,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'scope':'bounded offline file source; no Game or SDK calls','exe':{'path':str(EXE),'bytes':stat_after.st_size,'file_id_decimal':str(stat_after.st_ino),'mtime_ns_decimal':str(stat_after.st_mtime_ns),'reused_full_sha256':EXE_SHA,'full_sha_rehashed_this_run':False,'identity_anchor_rva':'262BE10','identity_anchor_bytes':660,'identity_anchor_sha256':hashlib.sha256(anchor).hexdigest(),'image_base_decimal':str(image_base)},'mode':args.mode,'label':args.label,'previous_scope_exe_read_bytes':prior_usage,'new_exe_read_bytes':read_bytes,'cumulative_scope_exe_read_bytes':prior_usage+read_bytes,'scope_exe_read_ceiling_bytes':RAW_CEILING,'read_ledger':reads,'local_exception_directory_records':metadata_rows,'spans':captured,'new_a04_exe_read_bytes_cumulative':prior_usage+read_bytes-138815,'instruction_mode':'selected_only_rawhex_authoritative','runtime_business_credit':False}
    rendered=(json.dumps(payload,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf-8')
    require(lane_bytes()+len(rendered)<=LANE_CEILING,'lane storage ceiling')
    with output.open('xb') as destination:
        destination.write(rendered)
    completed = True
    print(json.dumps({'path':str(output),'bytes':len(rendered),'sha256':hashlib.sha256(rendered).hexdigest(),'new_exe_read_bytes':read_bytes,'cumulative_scope_exe_read_bytes':prior_usage+read_bytes,'lane_total_bytes':lane_bytes(),'functions':[{'rva':p['start_rva'],'bytes':p['bytes'],'sha256':p['sha256']} for p in captured]}))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
