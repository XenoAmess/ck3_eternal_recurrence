"""Seal source-only c/d producer evidence; no executable-image or Game access."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from typing import TypedDict

from capstone import Cs, CS_ARCH_X86, CS_MODE_64

LANE = Path(__file__).resolve().parent
REPO = Path('D:/workspace/ck3_eternal_recurrence')
GAME = Path('C:/SteamLibrary/steamapps/common/Crusader Kings III/game')
MACHINE = 'desktop-3fevhd2-1c74096080'
IMAGE = '98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518'
OLD_LANE_BYTES = 621374


class Pin(TypedDict):
    path: str
    bytes: int
    sha256: str


class Instruction(TypedDict):
    rva: str
    bytes_hex: str
    mnemonic: str
    operands: str


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def fields(value: object) -> dict[str, object]:
    if not isinstance(value, dict):
        raise ValueError('JSON object required')
    result: dict[str, object] = {}
    for key, item in value.items():
        result[string(key)] = item
    return result


def array(value: object) -> list[object]:
    if not isinstance(value, list):
        raise ValueError('JSON array required')
    return list(value)


def string(value: object) -> str:
    if not isinstance(value, str):
        raise ValueError('string required')
    return value


def integer(value: object) -> int:
    if type(value) is not int:
        raise ValueError('exact integer required')
    return value


def load(path: Path) -> dict[str, object]:
    decoded: object = json.loads(path.read_bytes())
    return fields(decoded)


def pin(path: Path) -> Pin:
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def lane_bytes() -> int:
    return sum(path.stat().st_size for path in LANE.rglob('*') if path.is_file())


def write_new(path: Path, record: dict[str, object]) -> Pin:
    require(not path.exists(), 'immutable output exists')
    rendered = (json.dumps(record, ensure_ascii=False, separators=(',', ':')) + '\n').encode()
    require(json.loads(rendered) == record, 'JSON representation roundtrip')
    require(lane_bytes() + len(rendered) <= 786432, 'aggregate lane cap')
    require(lane_bytes() - OLD_LANE_BYTES + len(rendered) <= 131072, 'a04 output cap')
    with path.open('xb') as stream:
        stream.write(rendered)
    return pin(path)


def verify_old_seal() -> None:
    a03 = LANE / 'financial-cadence-a03.json'
    require(pin(a03)['sha256'] == 'ea2915e71b7e07f5fa130e4dfebf0bf23cb0c3125b5dab39b9806a10047b0eca', 'old a03 changed')
    for item in array(load(a03)['source_pins']):
        old = fields(item)
        actual = pin(Path(string(old['path'])))
        require(actual['bytes'] == integer(old['bytes']) and actual['sha256'] == string(old['sha256']), 'old source changed')
    for name, expected in (('rules-a01.json', '72546fb26cc52bd8555d83ec77f0413312050dc3aa5057bc569a718a29267cf8'),
                           ('prior-rules-a01.source.json', 'b217734792566f2957af92e5a6bcc6b2cc27cda15d683d26af802c44be643680'),
                           ('typing-a05.json', '8ed2c6101e49aacb573d73fcb00004a16b2fa32bddd79a485fc9cb7de81a63a9')):
        require(pin(LANE / name)['sha256'] == expected, 'old auxiliary changed')


def get_code(packet: Path, start: int) -> bytes:
    source = load(packet)
    require(source['schema'] == 'xar.e04.mechanics.static-source.a04.v1' and source['machine_id'] == MACHINE, 'source schema/machine')
    require(fields(source['exe'])['reused_full_sha256'] == IMAGE, 'source image')
    span = next(fields(item) for item in array(source['spans']) if int(string(fields(item)['start_rva']), 16) == start)
    raw = bytes.fromhex(string(span['source_hex']))
    require(len(raw) == integer(span['bytes']) and hashlib.sha256(raw).hexdigest() == span['sha256'], 'source raw integrity')
    return raw


def build_rules() -> Pin:
    verify_old_seal()
    decoder = Cs(CS_ARCH_X86, CS_MODE_64)
    character_path = LANE / 'financial-preparation-character-a04.a04.json'
    raw = get_code(character_path, 0x28f6130)
    decoded = list(decoder.disasm(raw, 0x28f6130))
    require(len(raw) == 741 and sum(i.size for i in decoded) == 741 and decoded[-1].mnemonic == 'ret', 'whole Character callback')
    by_address = {i.address: i for i in decoded}
    expected = ((0x28f6178, 'mov', 'rbp, qword ptr [rsi + 0x1c0]'),
                (0x28f6187, 'call', '0x28c43a0'), (0x28f618c, 'mov', 'rbx, qword ptr [rax]'),
                (0x28f619a, 'call', '0x2c142b0'), (0x28f619f, 'mov', 'rcx, qword ptr [rax]'),
                (0x28f61a2, 'add', 'rcx, rbx'), (0x28f61a5, 'mov', 'qword ptr [rbp + 0x28], rcx'),
                (0x28f6221, 'call', '0x2bc2d80'), (0x28f62bc, 'call', '0x2c806d0'),
                (0x28f62e1, 'add', 'rbx, rdi'), (0x28f62f5, 'call', '0x2c576a0'),
                (0x28f62fd, 'add', 'rcx, rbx'), (0x28f6300, 'mov', 'qword ptr [rbp + 0x30], rcx'))
    for address, mnemonic, operand in expected:
        instruction = by_address[address]
        require((instruction.mnemonic, instruction.op_str) == (mnemonic, operand), 'producer instruction mismatch')
    critical: list[Instruction] = [
        {'rva': format(address, 'X'), 'bytes_hex': by_address[address].bytes.hex(),
         'mnemonic': mnemonic, 'operands': operand} for address, mnemonic, operand in expected]
    for packet_path in sorted(LANE.glob('*.a04.json')):
        packet = load(packet_path)
        require(packet['schema'] == 'xar.e04.mechanics.static-source.a04.v1', 'a04 packet schema')
        for span_item in array(packet['spans']):
            span = fields(span_item)
            data = bytes.fromhex(string(span['source_hex']))
            require(len(data) == integer(span['bytes']) and hashlib.sha256(data).hexdigest() == span['sha256'], 'a04 span integrity')
    labels_path = LANE / 'secondary-fee-labels-a04.a04.json'
    legends_path = LANE / 'legend-fee-labels-a04.a04.json'
    label_pairs = ((labels_path, 0x4808048, 'COURT_POSITIONS_SALARY_FOR'),
                   (labels_path, 0x481b430, 'COURT_AMENITIES_EXPENSES_FOR'),
                   (legends_path, 0x4819e30, 'OWNED_LEGEND_EXPENSES'),
                   (legends_path, 0x4819e00, 'PROMOTED_LEGEND_EXPENSES'))
    for path, start, expected_label in label_pairs:
        require(get_code(path, start).split(b'\0', 1)[0].decode('ascii') == expected_label, 'source label')
    a04_packets = sorted(LANE.glob('*.a04.json'))
    new_read_bytes = sum(integer(load(path)['new_exe_read_bytes']) for path in a04_packets)
    require(new_read_bytes <= 131072, 'a04 EXE quota')
    official_paths = [GAME / 'localization/simp_chinese/court_positions_l_simp_chinese.yml',
                      GAME / 'localization/simp_chinese/court_amenities_l_simp_chinese.yml',
                      GAME / 'localization/simp_chinese/dlc/ep1/dlc_ep1_game_concepts_l_simp_chinese.yml',
                      GAME / 'localization/simp_chinese/dlc/ce1/legends_l_simp_chinese.yml']
    reused = [REPO / 'docs/ck3-native-ai/episode04-maintenance-callee-28c43a0-12004.sources.json',
              REPO / 'docs/ck3-native-ai/episode04-maintenance-callee-2c142b0-12004.sources.json',
              REPO / 'docs/ck3-native-ai/acceptance/2026-10-16-r08-cash-getter-inventory/source-index.json']
    record: dict[str, object] = {
        'schema': 'xar.e04.context-cost-producers.a04.v1', 'machine_id': MACHINE,
        'observed_at_utc': datetime.now(timezone.utc).isoformat(), 'exe_sha256': IMAGE,
        'game_version': '1.20.0.4', 'steam_build_id': 25734779,
        'status': 'STATIC_C_AND_D_PRODUCER_SOURCE_CLOSED', 'scope': 'Offline exact-image source only; no Game/SDK/build/test execution and no new paid-wallet observation.',
        'correction_to_old_a03': {'old_pin': pin(LANE / 'financial-cadence-a03.json'),
                                 'old_state_was_correct_at_seal': 'The old21 members did not establish c/d categories. This independent a04 supplies the previously missing producer bridge; old files and historical qualifications are unchanged.'},
        'character_and_context': '28F6130 original RDX is Character, saved RSI. At28F6178 RBP=QWORD[Character+1C0]. Both explicit c/d stores use that same saved context.',
        'static_preparation_chain': ['28F5370:28F57B6->2900C50', '2900C50 constructs wrapper vtable47642E0 and nested task+68 from selected Character-array descriptor',
                                     'vtable47642E0.slot10=29095D0; thunk loads nested task from wrapper+8 and jumps290E560',
                                     '290E560 selects290FEF0;290FEF0 reads selected Character by actual index and tail-jumps28F6130'],
        'cadence_dependency': pin(LANE / 'financial-cadence-a03.json'),
        'c': {'name_zh': '当前军事维护费的金币分量', 'unit': 'gold raw, scale100000; current military rate used as a prepared settlement input',
              'producer': '28F61A5', 'post_pc': '28F61A9', 'formula': 'wrap_i64(28C43A0(Character,out80).slot0 + 2C142B0(out80,Character,null).slot0)',
              'proof': 'The public current-maintenance2C13F60 null-breakdown route adds these same two exact-image vector producers. The new writer loads each returned vector offset0, sums them, and stores into saved context+28.',
              'included_scope': 'First Army/Unit cached vector with its existing three-slot modifier tail plus second persistent/regiment vector. All existing type/resource conversion branches remain inside those producers.',
              'excluded_inference': 'Not the sum of all ten resources; not current+all-raised; not the all-raised alternative; not a new observed cash payment or proof of a same-instance military-only debit.'},
        'd': {'name_zh': '适用的宫廷职位俸禄、宫廷舒适度及传奇费用之和', 'producer': '28F6300', 'post_pc': '28F6304',
              'formula': 'wrap_i64(applicable_court_position_salary + applicable_court_amenity_gold + applicable_legend_gold)',
              'court_position_salary': {'callee': '2BC2D80', 'gate': 'context exists and DWORD[context+3C4]!=0', 'list': 'context+3B8',
                                        'actual_arguments': 'out64,list,R8D0,R9D0,stack factor -100000,label COURT_POSITIONS_SALARY_FOR,optional breakdown null',
                                        'body': 'Enumerates4-byte CourtPosition IDs and adds each2423840 returned amount. Label is selected in the real28F6130 caller.'},
              'court_amenities': {'callee': '2C806D0', 'gate': 'context+458 pointer exists and the actual global object byte+2B0 has bit0x20',
                                  'actual_arguments': 'out64,Character,resource_index0,label COURT_AMENITIES_EXPENSES_FOR,optional breakdown null',
                                  'body': 'Obtains the amenity list from the RoyalCourt-related object+108/count114, calls326D010 for each entry and sums vector slot0.',
                                  'gate_name_limit': 'The raw global bit condition is retained; this source does not assign that global bit a new DLC or game-rule name.'},
              'legend': {'callee': '2C576A0', 'actual_arguments': 'out64,Character,resource_index0,optional breakdown null',
                          'gate': 'Character context+1B0 must resolve a valid FullID with object magic Lege; invalid/missing returns0',
                          'owner_branch': 'Legend+288==Character FullID chooses definition cost+118 and label OWNED_LEGEND_EXPENSES',
                          'promoter_branch': 'Other valid Legend owner chooses definition cost+AF0 and label PROMOTED_LEGEND_EXPENSES',
                          'body': '256E9F0 supplies cost definition context;310D0E0 evaluates the selected resource with the actual Character context.'}},
        'writer_instructions': critical,
        'amount_application': 'Use a03 N=wrap64(a-b-(c+d)). New c/d source names do not change its full-raw positive ADD or two-stage truncated negative allocation. Do not subtract the same c again from the already net wallet amount.',
        'ordinary_worked_examples': [
            {'kind': 'hypothetical source arithmetic', 'field_a_minus_b_gold': 10, 'military_c_gold': 3, 'salary_gold': 1, 'amenity_gold': 0, 'legend_gold': 0, 'd_gold': 1, 'N_gold': 6},
            {'kind': 'hypothetical source arithmetic', 'field_a_minus_b_gold': 10, 'military_c_gold': 3, 'salary_gold': 1, 'amenity_gold': 2, 'legend_gold': 1, 'd_gold': 4, 'N_gold': 3}],
        'player_and_agent_use': ['Budget military maintenance and the three applicable d categories as separate prepared inputs.',
                                 'Changing military state can change c through the current-cost producers; all-raised remains a forecast alternative.',
                                 'Use a03 actor-specific30-day phase; a source formula alone does not certify the actual observed payment, actor account or temporal freshness.'],
        'live_qualification_unchanged': {'production_maintenance_attribution': 'unclosed', 'new_actual_paid_military_amount_raw': None, 'new_native_callback_observed': False,
                                       'required_for_actual_paid_claim': 'Qualified same-instance prepared context/settlement/wallet account and source application evidence; do not backfill old journals.'},
        'new_a04_exe_read_bytes': new_read_bytes, 'prior_scope_exe_read_bytes': 138815,
        'source_pins': [pin(path) for path in a04_packets], 'existing_repo_sources': [pin(path) for path in reused],
        'official_localization_sources': [pin(path) for path in official_paths],
        'official_terminology': {'court_position': '宫廷职位', 'salary': '俸禄', 'court_amenities': '宫廷舒适度', 'owned_legend': '被拥有的传奇', 'promoted_legend': '得到推广的传奇'},
        'capacity_source': pin(LANE.parent.parent / 'capacity-a01/MARCH-A04-EXISTING-GROUP-SOURCE.actual-a01.json'),
        'input_validation': 'Exact types, source hex length/digests, whole741B callback, actual writer/call instructions, source labels, old21 preservation and JSON representation roundtrip checked by this producer; no Game or test suite.'}
    return write_new(LANE / 'context-cost-producers-a04.json', record)


def close() -> Pin:
    verify_old_seal()
    rule_pin = pin(LANE / 'context-cost-producers-a04.json')
    typing = load(LANE / 'typing-a06.json')
    require(integer(typing['exit_code']) == 0, 'typing did not pass')
    names = sorted(path.name for path in LANE.glob('*.a04.json')) + ['capture_a04.py', 'seal_a04.py', 'context-cost-producers-a04.json', 'typing-a06.json']
    members = [pin(LANE / name) for name in names]
    index_pin = write_new(LANE / 'SOURCE-INDEX.a04.json', {
        'schema': 'xar.e04.march.a04.source-index.v1', 'machine_id': MACHINE,
        'observed_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'SEALED_SOURCE_ONLY',
        'member_count_excluding_index_and_owner_close': len(members), 'member_bytes_excluding_index_and_owner_close': sum(item['bytes'] for item in members),
        'members': members, 'rules': rule_pin, 'old21_preserved': True, 'no_new_runtime_or_paid_claim': True})
    owner: dict[str, object] = {'schema': 'xar.e04.march.a04.owner-close.v1', 'machine_id': MACHINE,
                                'observed_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'CLOSED_SOURCE_C_D_PRODUCER',
                                'index': index_pin, 'rules': rule_pin, 'new_source_members_including_index_and_this_close': len(members) + 2,
                                'old_sealed21_unchanged': True, 'writes_and_EXE_reads_complete': True,
                                'new_runtime_claim': False}
    return write_new(LANE / 'OWNER-CLOSE.a04.json', owner)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--close', action='store_true')
    args = parser.parse_args()
    require(datetime.now(timezone.utc).isoformat() < '2026-10-22T08:00:00', 'deadline')
    result = close() if args.close else build_rules()
    print(json.dumps(result))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
