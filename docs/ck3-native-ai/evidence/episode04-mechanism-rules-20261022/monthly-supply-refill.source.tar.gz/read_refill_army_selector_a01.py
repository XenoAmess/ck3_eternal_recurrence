
from __future__ import annotations
from pathlib import Path
import datetime,hashlib,json,capstone
root=Path("C:/ck3-e04-resume-20261020-a01/r22-mechanics-rewrite-a01/research-a01/monthly_rules")
b=(root/"SUPPLY-NEGATIVE-HELPER.actual-a01.json").read_bytes();m=json.loads(b)
if hashlib.sha256(b).hexdigest()!="4558c3a23724ecc9463b5ce91ce909714ca8e671a3be5872bd0bfae5cfef4ab0":raise ValueError("mapping pin")
exe=Path("C:/SteamLibrary/steamapps/common/Crusader Kings III/binaries/ck3.exe")
def identity(p:Path)->dict[str,str]:
 s=p.stat();return {"bytes":str(s.st_size),"mtime_ns":str(s.st_mtime_ns),"ctime_ns":str(s.st_ctime_ns),"file_id_os_stat":str(s.st_ino)}
if identity(exe)!=m["file_identity_after"]:raise ValueError("image changed")
base=int(m["image_base_hex"],16);entry=0x262D030;limit=entry+256
section=next(x for x in m["section_map"] if x["name"]==".text")
md=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64);md.detail=True
cache:dict[int,int]={};instructions:dict[int,dict[str,object]]={};frontiers:list[dict[str,object]]=[];pending=[entry];error=None
try:
 with exe.open("rb") as f:
  while pending:
   pc=pending.pop()
   while pc not in instructions:
    if not entry<=pc<limit:
     frontiers.append({"rva":hex(pc),"reason":"outside256B exact-reached scope"});break
    raw=bytearray();ins=None
    for n in range(15):
     at=pc+n
     if not entry<=at<limit:raise ValueError("instruction crosses scope")
     if at not in cache:
      off=section["raw_offset"]+at-section["rva"];f.seek(off);one=f.read(1)
      if len(one)!=1:raise ValueError("short byte")
      cache[at]=one[0]
     raw.append(cache[at])
     decoded=list(md.disasm(bytes(raw),base+pc,count=1))
     if decoded:ins=decoded[0];break
    if ins is None:raise ValueError("instruction not decoded")
    row={"rva":hex(pc),"bytes":ins.bytes.hex(),"mnemonic":ins.mnemonic,"operands":ins.op_str};instructions[pc]=row
    if ins.mnemonic in ("ret","retf"):break
    if ins.group(capstone.CS_GRP_JUMP):
     if len(ins.operands)!=1 or ins.operands[0].type!=capstone.x86_const.X86_OP_IMM:
      frontiers.append({"rva":hex(pc),"reason":"indirect jump not expanded"});break
     target=int(ins.operands[0].imm)-base
     pending.append(target)
     if ins.mnemonic=="jmp":break
    if ins.mnemonic in ("int3","ud2"):frontiers.append({"rva":hex(pc),"reason":"trap"});break
    pc+=ins.size
except Exception as ex:
 error=type(ex).__name__+": "+str(ex)
if identity(exe)!=m["file_identity_after"]:raise ValueError("image changed during read")
segments=[]
for at in sorted(cache):
 if not segments or at!=segments[-1]["end_rva_exclusive"]:
  segments.append({"begin_rva":at,"end_rva_exclusive":at+1,"hex":bytes([cache[at]]).hex()})
 else:
  segments[-1]["end_rva_exclusive"]=at+1;segments[-1]["hex"]+=bytes([cache[at]]).hex()
obj={"schema":"xar.episode04.reached-leaf-instruction-reader.v1","machine_id":"desktop-3fevhd2-1c74096080","observed_at_utc":datetime.datetime.now(datetime.UTC).isoformat(),"exe_sha256_inherited":m["inherited_executable_sha256"],"file_identity":identity(exe),"entry_rva":hex(entry),"scope_end_exclusive":hex(limit),"method":"Only reached direct control-flow instruction bytes, each new source byte read once. Decode incrementally one byte at a time to stop exactly at instruction/RET boundaries; external calls recorded, not executed or expanded.","segments":segments,"instructions":[instructions[x] for x in sorted(instructions)],"unclosed_control_flow_frontiers":frontiers,"error":error,"new_code_bytes":len(cache),"cumulative_code_bytes":4117+len(cache),"Game_or_SDK":False,"prior_pdata_attempt":{"result":"ValueError: not exact function entry","code_bytes":0,"metadata_bytes_upper_bound":288,"actual_probe_count_recorded":None,"explanation":"Original metadata-only locator failed before writing its planned success receipt. Probes were RAM-only and lost at process exit; do not invent exact source bytes or a containing boundary. This separate actual instruction read does not repeat the metadata search."}}
out=root/"REFILL-ARMY-SELECTOR.actual-a01.json";enc=(json.dumps(obj,separators=(",",":"),allow_nan=False)+"\n").encode()
if sum(p.stat().st_size for p in root.iterdir() if p.is_file())+len(enc)>262144:raise ValueError("lane ceiling")
with out.open("xb") as f:f.write(enc)
print(json.dumps({"path":str(out),"bytes":len(enc),"sha256":hashlib.sha256(enc).hexdigest(),"new_code_bytes":len(cache),"cumulative_code_bytes":4117+len(cache),"frontiers":frontiers,"error":error}))
for x in obj["instructions"]:print(x["rva"],x["mnemonic"],x["operands"])
