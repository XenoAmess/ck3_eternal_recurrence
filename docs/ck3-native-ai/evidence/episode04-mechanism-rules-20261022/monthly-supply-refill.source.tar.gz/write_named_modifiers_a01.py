
from __future__ import annotations
from pathlib import Path
import datetime,hashlib,json,struct
root=Path("C:/ck3-e04-resume-20261020-a01/r22-mechanics-rewrite-a01/research-a01/monthly_rules")
mapping_path=root.parent/"research_next"/"MODIFIER-REGISTRATION-CLOSED.actual-a02.json"
mb=mapping_path.read_bytes()
if hashlib.sha256(mb).hexdigest()!="8b3824075c63833a4df3d56c0be4e42abdfd1488e4cfb5754683130bbc4484cb":raise ValueError("registration pin")
m=json.loads(mb)
if type(m) is not dict or type(m.get("rows")) is not list:raise ValueError("registration shape")
selected=[]
want={0x1A9,0x1D3,0x1D4,0x1D9,0x1DA,0x1DB,0x1DC,0x1DD,0x1DE,0x1DF}
for row in m["rows"]:
    if type(row) is not dict or type(row.get("raw_hex")) is not str or type(row.get("runtime_key_u16_at_28")) is not str:raise ValueError("row shape")
    raw=bytes.fromhex(row["raw_hex"])
    if len(raw)!=56 or hashlib.sha256(raw).hexdigest()!=row["sha256"]:raise ValueError("row content")
    key=struct.unpack_from("<H",raw,0x28)[0]
    if key!=int(row["runtime_key_u16_at_28"],16):raise ValueError("row key")
    if key in want:selected.append({"key_hex":hex(key),"row_rva":row["row_rva"],"caption":row["caption"],"row_sha256":row["sha256"]})
if {int(x["key_hex"],16) for x in selected}!=want:raise ValueError("mapping incomplete")
game=Path("C:/SteamLibrary/steamapps/common/Crusader Kings III/game")
sources=[]
for rel,sha in [("common/traits/00_traits.txt","93ad0316b733aa474d34841bd92fb3fc9336c111e9f06e7910178e74482185aa"),("localization/simp_chinese/traits_l_simp_chinese.yml","4499144a67951fa7c5fba5e0f52de2db94b3b1f85bfee3cc03ab9bf7e46fb554"),("localization/simp_chinese/modifiers/modifiers_l_simp_chinese.yml","c4b669dff52effa52412c52746845d4879f012e22b122e81e10ab19833650ada")]:
    data=(game/rel).read_bytes()
    if hashlib.sha256(data).hexdigest()!=sha:raise ValueError("stock source changed")
    sources.append({"path":str(game/rel),"bytes":len(data),"sha256":sha})
fixed_negative_result=-(500000*100000//140000)
if fixed_negative_result!=-357142:raise ValueError("fixed example")
obj={
"schema":"xar.episode04.named-monthly-modifiers-closed.v1",
"machine_id":"desktop-3fevhd2-1c74096080",
"observed_at_utc":datetime.datetime.now(datetime.UTC).isoformat(),
"version":"1.20.0.4","steam_build":25734779,
"source_repository_head":"bc63851081462413d0cc6ebe62e37490707ee6a9",
"exe_sha256_inherited":"98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518",
"source_only":True,"Game_or_SDK":False,
"registration_source":{"path":str(mapping_path),"bytes":len(mb),"sha256":hashlib.sha256(mb).hexdigest()},
"registration_proof":{"constructor":"2C4DAE0/631B;2C4DC3F LEA table480C2A0;2C4DC4B count0x261;2C4DD42 CALL25F7270","parser":"25F7270/896B;RSI=row+0x2D;25F737E MOVZX word[RSI-5] = u16(row+0x28);25F7382 IMUL index,0xC8;25F7389 ADD runtime registry+0x50","correction":"research_next earlier a01 rows started 16B before actual row; their apparent first IDs were previous row tails. Historical wrong rows retained; this packet uses actual parser offset and complete corrected raw rows. No old index+1 or physical-order inference."},
"mappings":selected,
"stock_sources":sources,
"official_zh":{"MOD_SUPPLY_DURATION":{"line":1154,"text":"[command_modifier_i|E][supply|E]持续时间","plain":"补给持续时间"},"MOD_SUPPLY_CAPACITY_ADD":{"line":834,"text":"[command_modifier_i|E][supply|E]容量","plain":"补给容量"},"MOD_SUPPLY_CAPACITY_MULT":{"line":835,"text":"$MOD_SUPPLY_CAPACITY_ADD$","plain":"补给容量"},"MOD_LEVY_REINFORCEMENT_RATE":{"line":103,"plain":"征召兵补员速率"},"MOD_LEVY_REINFORCEMENT_RATE_EVEN_IF_BARON":{"line":104,"alias_of":"MOD_LEVY_REINFORCEMENT_RATE"},"MOD_LEVY_REINFORCEMENT_RATE_DIFFERENT_FAITH":{"line":105,"plain":"征召兵补员速率（不同信仰）"},"MOD_LEVY_REINFORCEMENT_RATE_DIFFERENT_FAITH_EVEN_IF_BARON":{"line":106,"alias_of":"MOD_LEVY_REINFORCEMENT_RATE_DIFFERENT_FAITH"},"MOD_LEVY_REINFORCEMENT_RATE_SAME_FAITH":{"line":107,"plain":"征召兵补员速率（相同信仰）"},"MOD_LEVY_REINFORCEMENT_RATE_SAME_FAITH_EVEN_IF_BARON":{"line":108,"alias_of":"MOD_LEVY_REINFORCEMENT_RATE_SAME_FAITH"},"MOD_LEVY_REINFORCEMENT_RATE_FRIENDLY_TERRITORY":{"line":109,"plain":"友好领土征召兵补员速率"},"trait_logistician":{"line":911,"plain":"后勤专家"},"trait_logistician_1":{"line":912,"plain":"熟练的后勤官"},"trait_logistician_2":{"line":913,"plain":"军需总管"},"trait_logistician_3":{"line":914,"plain":"后勤大师"}},
"supply_duration":{"native_numeric_source":"SUPPLY-NEGATIVE-HELPER.actual-a01.json;24E6071 key1A9;24E60C5 ADD Q;24E60CB floor;24E60D9..61C5 NativeFixedDiv;24E61C5..61D2 final negative limit","rule":"When the pre-adjustment supply rate component V is negative, divide it by max(loaded_floor,1+commander.supply_duration), using Q100000 native division. This changes the amount of supply consumed per successful check, not the ArmyManager schedule, positive friendly recovery or stock cap.","named_example":{"assumptions":"No other supply-duration modifiers, no trait-track or culture extras, base loss5, floor below1.4.","stock_trait_source":"00_traits.txt13059 logistician;13064 supply_duration=0.4;track33 at13104 adds another0.4, so do not assign total+40% to every actual holder.","base_supply_duration":0.4,"denominator":1.4,"before":-5,"native_after":-3.57142,"wrong_operation":-3,"narration_zh":"后勤专家提高的是补给持续时间。只有这项加成时，原本每轮消耗5点补给，会除以1.4，变成约3.57点；不能拿5点直接减去40%。正数的友领恢复仍按原来的规则计算。"}},
"supply_capacity":{"native_source":"SUPPLY-CAPACITY-HELPER.actual-a01.json;2C53C97 key1D3;2C53D08 key1D4","ordinary_rule":"(loaded FULL_SUPPLY + applicable supply_capacity_add) * (1 + applicable supply_capacity_mult), using native Q100000 arithmetic and actual source-owner/modifier-selection branches.","hypothetical_example":{"base":100,"add":50,"mult":0.2,"result":180,"narration_zh":"军队补给上限先加数值，再乘比例。例如基础100点，加50点，再提高20%，最后是180点。当地补给上限则表示能支持多少士兵，是另一项数值。"}},
"levy_fraction":{"complete_native_source":{"path":"docs/ck3-native-ai/evidence/episode04-persistent-refill-eligibility-12004/fraction262CAB0.instructions.json","bytes_code":1134,"body_sha256":"3d7d4ac7c0d1b5d1c5929a53372dd9384031ec99dfd01027064c55d027cfd725","instructions_sha256":"2699559c1c7f7886782f1744a40f3e22a66fed0eaed1a14dbcf0f23219e180c1"},
"ordinary_province_levy_branch":"persistent+138==0 AND definition+38 !=GDbo AND origin+85C==Prov enables province/holder/religion components. Other classification branches do not automatically acquire these terms.",
"formula":"B is the selected loaded base rate. For the ordinary Province levy branch, A=Q+ContextNumericKey2C23340(origin,1D9)+ContextScalar2C82340(origin+848,1DC)+holder_character_key(selected1DA/1DB)+ContextScalar2C82340(origin+848,selected1DD/1DE). If the selected Army's actual Unit passes24ACAA0, add its resolved commander Character key1DF. Final F=NativeFixedMul(B,A). Source does not insert an extra positive clamp here.",
"native_edges":["262CBC1->2C23340 key1D9 origin context (context+30, CountyData+98, selected holder Character cache contributions under actual child-source rules).","262CBE8->2C82340 key1DC origin CountyData; child traverses relevant title/holder candidates, deduplicates complete Character IDs in first-seen order and sums their same-key modifier values.","262CC95 origin CountyData+384 and262CCD9 holderCharacter+B4 resolve Rite;262CCCD and262CD0A read underlying Faith+4B8 IDs; exact equality selects1DA/1DD, inequality selects1DB/1DE.","262CD68->262D030 selects associated Army;262CDB0->24ACAA0 actual Unit position predicate; if true262CE02 key1DF from Army+120 commander Character cache.","262CE66..262CF12 multiplies selected base B by aggregate A with native fixed-point fast/slow branches."],
"concrete_hypothetical_example":{"assumptions":"An ordinary origin-Province levy with selected base B=0.03, all applicable nonzero rate contributions total+0.34; this is an example, not a reconstruction of individual R0221 modifiers.","aggregate_factor":1.34,"effective_rate":0.0402,"maximum":69,"missing":1,"nominal":2.7738,"integer_added":1,"narration_zh":"征召兵补员先用基础速率乘上适用修正的总系数，再按这部分军团的满员规模算人数，最后受实际缺额限制并舍去小数。假设基础3%，适用修正合计提高34%，有效速率就是4.02%。满员69人时可补2.7738人，但只缺1人就只补1人。"},
"R0221_scope":"Real R0221 establishes preparedF=4020, max69,current68,actualADD1 for the target physical record. Its retained core packet did not capture each producing modifier contribution at preparation time. Exact individual actor/building/council components cannot be inferred from4020 alone; do not label a hypothetical+34% breakdown as the historical observation. Native formula and each key's official names are now closed."
}}
enc=(json.dumps(obj,ensure_ascii=False,separators=(",",":"),allow_nan=False)+"\n").encode()
if json.loads(enc)!=obj:raise ValueError("JSON roundtrip")
used=sum(x.stat().st_size for x in root.iterdir() if x.is_file())
if used+len(enc)>262144:raise ValueError("lane ceiling")
out=root/"NAMED-MODIFIERS-CLOSED.actual-a01.json"
with out.open("xb") as f:f.write(enc)
print(json.dumps({"path":str(out),"bytes":len(enc),"sha256":hashlib.sha256(enc).hexdigest(),"lane_bytes":used+len(enc),"registered_keys":len(selected),"native_duration_after":fixed_negative_result/100000}))
