; machine_id: desktop-3fevhd2-1c74096080
; exact EXE SHA historical 98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518
02C09580 48 89 5c 24 08                   mov      qword ptr [rsp + 8], rbx
02C09585 48 89 74 24 10                   mov      qword ptr [rsp + 0x10], rsi
02C0958A 57                               push     rdi
02C0958B 48 83 ec 20                      sub      rsp, 0x20
02C0958F 8b 42 18                         mov      eax, dword ptr [rdx + 0x18]
02C09592 49 8b f0                         mov      rsi, r8
02C09595 48 8b da                         mov      rbx, rdx
02C09598 48 8b f9                         mov      rdi, rcx
02C0959B 39 41 18                         cmp      dword ptr [rcx + 0x18], eax
02C0959E 74 63                            je       0x2c09603
02C095A0 e8 2b fb ff ff                   call     0x2c090d0
02C095A5 84 c0                            test     al, al
02C095A7 75 5a                            jne      0x2c09603
02C095A9 4c 8b c6                         mov      r8, rsi
02C095AC 48 8b d3                         mov      rdx, rbx
02C095AF 48 8b cf                         mov      rcx, rdi
02C095B2 e8 c9 fc ff ff                   call     0x2c09280
02C095B7 84 c0                            test     al, al
02C095B9 75 36                            jne      0x2c095f1
02C095BB 4c 8b c6                         mov      r8, rsi
02C095BE 48 8b d7                         mov      rdx, rdi
02C095C1 48 8b cb                         mov      rcx, rbx
02C095C4 e8 b7 fc ff ff                   call     0x2c09280
02C095C9 84 c0                            test     al, al
02C095CB 75 24                            jne      0x2c095f1
02C095CD 4c 8b c6                         mov      r8, rsi
02C095D0 48 8b d3                         mov      rdx, rbx
02C095D3 48 8b cf                         mov      rcx, rdi
02C095D6 e8 35 fe ff ff                   call     0x2c09410
02C095DB 84 c0                            test     al, al
02C095DD 75 12                            jne      0x2c095f1
02C095DF 4c 8b c6                         mov      r8, rsi
02C095E2 48 8b d7                         mov      rdx, rdi
02C095E5 48 8b cb                         mov      rcx, rbx
02C095E8 e8 23 fe ff ff                   call     0x2c09410
02C095ED 84 c0                            test     al, al
02C095EF 74 12                            je       0x2c09603
02C095F1 b0 01                            mov      al, 1
02C095F3 48 8b 5c 24 30                   mov      rbx, qword ptr [rsp + 0x30]
02C095F8 48 8b 74 24 38                   mov      rsi, qword ptr [rsp + 0x38]
02C095FD 48 83 c4 20                      add      rsp, 0x20
02C09601 5f                               pop      rdi
02C09602 c3                               ret      
02C09603 48 8b 5c 24 30                   mov      rbx, qword ptr [rsp + 0x30]
02C09608 32 c0                            xor      al, al
02C0960A 48 8b 74 24 38                   mov      rsi, qword ptr [rsp + 0x38]
02C0960F 48 83 c4 20                      add      rsp, 0x20
02C09613 5f                               pop      rdi
02C09614 c3                               ret      
