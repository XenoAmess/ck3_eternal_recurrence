; machine_id: desktop-3fevhd2-1c74096080
; exact EXE SHA historical 98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518
02C09780 48 89 5c 24 08                   mov      qword ptr [rsp + 8], rbx
02C09785 48 89 74 24 10                   mov      qword ptr [rsp + 0x10], rsi
02C0978A 57                               push     rdi
02C0978B 48 83 ec 20                      sub      rsp, 0x20
02C0978F 48 8b da                         mov      rbx, rdx
02C09792 48 8b f9                         mov      rdi, rcx
02C09795 e8 e6 65 cb ff                   call     0x28bfd80
02C0979A 48 8b cb                         mov      rcx, rbx
02C0979D 48 8b f0                         mov      rsi, rax
02C097A0 e8 db 65 cb ff                   call     0x28bfd80
02C097A5 4c 8b c0                         mov      r8, rax
02C097A8 48 8b d3                         mov      rdx, rbx
02C097AB 48 8b cf                         mov      rcx, rdi
02C097AE e8 2d ff ff ff                   call     0x2c096e0
02C097B3 84 c0                            test     al, al
02C097B5 75 22                            jne      0x2c097d9
02C097B7 4c 8b c6                         mov      r8, rsi
02C097BA 48 8b d7                         mov      rdx, rdi
02C097BD 48 8b cb                         mov      rcx, rbx
02C097C0 e8 1b ff ff ff                   call     0x2c096e0
02C097C5 84 c0                            test     al, al
02C097C7 75 10                            jne      0x2c097d9
02C097C9 48 8b 5c 24 30                   mov      rbx, qword ptr [rsp + 0x30]
02C097CE 48 8b 74 24 38                   mov      rsi, qword ptr [rsp + 0x38]
02C097D3 48 83 c4 20                      add      rsp, 0x20
02C097D7 5f                               pop      rdi
02C097D8 c3                               ret      
02C097D9 48 8b 5c 24 30                   mov      rbx, qword ptr [rsp + 0x30]
02C097DE b0 01                            mov      al, 1
02C097E0 48 8b 74 24 38                   mov      rsi, qword ptr [rsp + 0x38]
02C097E5 48 83 c4 20                      add      rsp, 0x20
02C097E9 5f                               pop      rdi
02C097EA c3                               ret      
