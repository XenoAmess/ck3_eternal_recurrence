; machine_id: desktop-3fevhd2-1c74096080
; preserved partial read, offline decode only
02C096E0 48 89 5c 24 10                   mov      qword ptr [rsp + 0x10], rbx
02C096E5 48 89 74 24 18                   mov      qword ptr [rsp + 0x18], rsi
02C096EA 57                               push     rdi
02C096EB 48 83 ec 20                      sub      rsp, 0x20
02C096EF 8b 42 18                         mov      eax, dword ptr [rdx + 0x18]
02C096F2 49 8b f0                         mov      rsi, r8
02C096F5 48 8b fa                         mov      rdi, rdx
02C096F8 48 8b d9                         mov      rbx, rcx
02C096FB 39 41 18                         cmp      dword ptr [rcx + 0x18], eax
02C096FE 74 63                            je       0x2c09763
02C09700 e8 cb 86 d0 ff                   call     0x2911dd0
02C09705 84 c0                            test     al, al
02C09707 75 5a                            jne      0x2c09763
02C09709 48 8b d3                         mov      rdx, rbx
02C0970C 48 8b cf                         mov      rcx, rdi
02C0970F e8 ac 9a d0 ff                   call     0x29131c0
02C09714 84 c0                            test     al, al
02C09716 75 4b                            jne      0x2c09763
02C09718 48 8b cb                         mov      rcx, rbx
02C0971B e8 a0 c1 03 00                   call     0x2c458c0
02C09720 84 c0                            test     al, al
02C09722 74 1e                            je       0x2c09742
02C09724 48 8b cf                         mov      rcx, rdi
02C09727 e8 f4 25 04 00                   call     0x2c4bd20
02C0972C 84 c0                            test     al, al
02C0972E 74 12                            je       0x2c09742
02C09730 b0 01                            mov      al, 1
02C09732 48 8b 5c 24 38                   mov      rbx, qword ptr [rsp + 0x38]
02C09737 48 8b 74 24 40                   mov      rsi, qword ptr [rsp + 0x40]
02C0973C 48 83 c4 20                      add      rsp, 0x20
02C09740 5f                               pop      rdi
02C09741 c3                               ret      
02C09742 48 8d 54 24 30                   lea      rdx, [rsp + 0x30]
02C09747 48 89 74 24 30                   mov      qword ptr [rsp + 0x30], rsi
02C0974C 48 8b cb                         mov      rcx, rbx
02C0974F e8 cc 68 00 00                   call     0x2c10020
02C09754 81 78 1c 72 61 68 43             cmp      dword ptr [rax + 0x1c], 0x43686172
02C0975B 75 06                            jne      0x2c09763
02C0975D 83 78 18 ff                      cmp      dword ptr [rax + 0x18], -1
02C09761 75 cd                            jne      0x2c09730
02C09763 48 8b 5c 24 38                   mov      rbx, qword ptr [rsp + 0x38]
02C09768 32 c0                            xor      al, al
02C0976A 48 8b 74 24 40                   mov      rsi, qword ptr [rsp + 0x40]
02C0976F 48 83 c4 20                      add      rsp, 0x20
02C09773 5f                               pop      rdi
02C09774 c3                               ret      
