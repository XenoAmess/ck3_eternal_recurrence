; machine_id: desktop-3fevhd2-1c74096080
; preserved partial read, offline decode only
02C090D0 48 89 5c 24 08                   mov      qword ptr [rsp + 8], rbx
02C090D5 48 89 6c 24 10                   mov      qword ptr [rsp + 0x10], rbp
02C090DA 48 89 74 24 18                   mov      qword ptr [rsp + 0x18], rsi
02C090DF 57                               push     rdi
02C090E0 41 54                            push     r12
02C090E2 41 55                            push     r13
02C090E4 41 56                            push     r14
02C090E6 41 57                            push     r15
02C090E8 48 83 ec 20                      sub      rsp, 0x20
02C090EC 8b 42 18                         mov      eax, dword ptr [rdx + 0x18]
02C090EF 4d 8b f8                         mov      r15, r8
02C090F2 4c 8b e2                         mov      r12, rdx
02C090F5 4c 8b e9                         mov      r13, rcx
02C090F8 39 41 18                         cmp      dword ptr [rcx + 0x18], eax
02C090FB 0f 84 d6 00 00 00                je       0x2c091d7
02C09101 48 8b 81 c0 01 00 00             mov      rax, qword ptr [rcx + 0x1c0]
02C09108 48 85 c0                         test     rax, rax
02C0910B 74 08                            je       0x2c09115
02C0910D 48 05 18 03 00 00                add      rax, 0x318
02C09113 eb 07                            jmp      0x2c0911c
02C09115 48 8d 05 1c 0c 85 02             lea      rax, [rip + 0x2850c1c]
02C0911C 48 8b 18                         mov      rbx, qword ptr [rax]
02C0911F 48 63 40 0c                      movsxd   rax, dword ptr [rax + 0xc]
02C09123 48 8d 34 83                      lea      rsi, [rbx + rax*4]
02C09127 48 3b de                         cmp      rbx, rsi
02C0912A 0f 84 a7 00 00 00                je       0x2c091d7
02C09130 48 8b 15 21 4d 11 03             mov      rdx, qword ptr [rip + 0x3114d21]
02C09137 4c 8b 0d 02 4d 11 03             mov      r9, qword ptr [rip + 0x3114d02]
02C0913E 66 90                            nop      
02C09140 48 85 d2                         test     rdx, rdx
02C09143 74 29                            je       0x2c0916e
02C09145 44 8b 03                         mov      r8d, dword ptr [rbx]
02C09148 41 8b c0                         mov      eax, r8d
02C0914B 25 ff ff ff 00                   and      eax, 0xffffff
02C09150 3b 42 2c                         cmp      eax, dword ptr [rdx + 0x2c]
02C09153 73 19                            jae      0x2c0916e
02C09155 8b c8                            mov      ecx, eax
02C09157 48 8b 42 20                      mov      rax, qword ptr [rdx + 0x20]
02C0915B 48 03 c9                         add      rcx, rcx
02C0915E 48 8b 6c c8 08                   mov      rbp, qword ptr [rax + rcx*8 + 8]
02C09163 48 85 ed                         test     rbp, rbp
02C09166 74 06                            je       0x2c0916e
02C09168 44 39 45 08                      cmp      dword ptr [rbp + 8], r8d
02C0916C 74 03                            je       0x2c09171
02C0916E 49 8b e9                         mov      rbp, r9
02C09171 4d 85 ff                         test     r15, r15
02C09174 74 05                            je       0x2c0917b
02C09176 49 3b ef                         cmp      rbp, r15
02C09179 75 4f                            jne      0x2c091ca
02C0917B 41 8b 7d 18                      mov      edi, dword ptr [r13 + 0x18]
02C0917F 4c 8d 75 20                      lea      r14, [rbp + 0x20]
02C09183 49 8b ce                         mov      rcx, r14
02C09186 8b d7                            mov      edx, edi
02C09188 e8 b3 b9 88 ff                   call     0x2494b40
02C0918D 84 c0                            test     al, al
02C0918F 75 15                            jne      0x2c091a6
02C09191 4c 8d b5 80 00 00 00             lea      r14, [rbp + 0x80]
02C09198 8b d7                            mov      edx, edi
02C0919A 49 8b ce                         mov      rcx, r14
02C0919D e8 9e b9 88 ff                   call     0x2494b40
02C091A2 84 c0                            test     al, al
02C091A4 74 16                            je       0x2c091bc
02C091A6 4d 85 f6                         test     r14, r14
02C091A9 74 11                            je       0x2c091bc
02C091AB 41 8b 54 24 18                   mov      edx, dword ptr [r12 + 0x18]
02C091B0 49 8b ce                         mov      rcx, r14
02C091B3 e8 88 b9 88 ff                   call     0x2494b40
02C091B8 84 c0                            test     al, al
02C091BA 75 3a                            jne      0x2c091f6
02C091BC 48 8b 15 95 4c 11 03             mov      rdx, qword ptr [rip + 0x3114c95]
02C091C3 4c 8b 0d 76 4c 11 03             mov      r9, qword ptr [rip + 0x3114c76]
02C091CA 48 83 c3 04                      add      rbx, 4
02C091CE 48 3b de                         cmp      rbx, rsi
02C091D1 0f 85 69 ff ff ff                jne      0x2c09140
02C091D7 32 c0                            xor      al, al
02C091D9 48 8b 5c 24 50                   mov      rbx, qword ptr [rsp + 0x50]
02C091DE 48 8b 6c 24 58                   mov      rbp, qword ptr [rsp + 0x58]
02C091E3 48 8b 74 24 60                   mov      rsi, qword ptr [rsp + 0x60]
02C091E8 48 83 c4 20                      add      rsp, 0x20
02C091EC 41 5f                            pop      r15
02C091EE 41 5e                            pop      r14
02C091F0 41 5d                            pop      r13
02C091F2 41 5c                            pop      r12
02C091F4 5f                               pop      rdi
02C091F5 c3                               ret      
02C091F6 b0 01                            mov      al, 1
02C091F8 eb df                            jmp      0x2c091d9
