; machine_id: desktop-3fevhd2-1c74096080
; independent exact-build body, reachable CFG extent; no exact .pdata row
028BFD80 4c 8b 0d e9 77 3a 03             mov      r9, qword ptr [rip + 0x33a77e9]
028BFD87 4c 3b c9                         cmp      r9, rcx
028BFD8A 0f 84 84 00 00 00                je       0x28bfe14
028BFD90 4c 8b 15 d1 77 3a 03             mov      r10, qword ptr [rip + 0x33a77d1]
028BFD97 66 0f 1f 84 00 00 00 00 00       nop      word ptr [rax + rax]
028BFDA0 48 8b 81 c0 01 00 00             mov      rax, qword ptr [rcx + 0x1c0]
028BFDA7 48 8b d1                         mov      rdx, rcx
028BFDAA 48 85 c0                         test     rax, rax
028BFDAD 74 1c                            je       0x28bfdcb
028BFDAF 48 8b 88 c0 01 00 00             mov      rcx, qword ptr [rax + 0x1c0]
028BFDB6 48 8b 49 28                      mov      rcx, qword ptr [rcx + 0x28]
028BFDBA 81 79 1c 72 61 68 43             cmp      dword ptr [rcx + 0x1c], 0x43686172
028BFDC1 75 4d                            jne      0x28bfe10
028BFDC3 83 79 18 ff                      cmp      dword ptr [rcx + 0x18], -1
028BFDC7 74 47                            je       0x28bfe10
028BFDC9 eb 40                            jmp      0x28bfe0b
028BFDCB 48 8b 81 b8 01 00 00             mov      rax, qword ptr [rcx + 0x1b8]
028BFDD2 48 85 c0                         test     rax, rax
028BFDD5 74 39                            je       0x28bfe10
028BFDD7 4d 85 d2                         test     r10, r10
028BFDDA 74 2c                            je       0x28bfe08
028BFDDC 44 8b 80 c8 00 00 00             mov      r8d, dword ptr [rax + 0xc8]
028BFDE3 41 8b c0                         mov      eax, r8d
028BFDE6 25 ff ff ff 00                   and      eax, 0xffffff
028BFDEB 41 3b 42 2c                      cmp      eax, dword ptr [r10 + 0x2c]
028BFDEF 73 17                            jae      0x28bfe08
028BFDF1 49 8b 4a 20                      mov      rcx, qword ptr [r10 + 0x20]
028BFDF5 48 03 c0                         add      rax, rax
028BFDF8 48 8b 4c c1 08                   mov      rcx, qword ptr [rcx + rax*8 + 8]
028BFDFD 48 85 c9                         test     rcx, rcx
028BFE00 74 06                            je       0x28bfe08
028BFE02 44 39 41 18                      cmp      dword ptr [rcx + 0x18], r8d
028BFE06 74 03                            je       0x28bfe0b
028BFE08 49 8b c9                         mov      rcx, r9
028BFE0B 48 3b d1                         cmp      rdx, rcx
028BFE0E 75 90                            jne      0x28bfda0
028BFE10 48 8b c2                         mov      rax, rdx
028BFE13 c3                               ret      
028BFE14 49 8b c1                         mov      rax, r9
028BFE17 c3                               ret      
