"""Root-handoff R194 immutable small endpoints; no full Driver/SDK access."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,types,zipfile,shutil
L=Path(__file__).resolve().parent;R=Path('D:/workspace/ck3_eternal_recurrence');S=Path('D:/workspace/ck3_native_war_ai_promo_work/e04-r194-r09-forward-a01');T=S/'r09-root-controller-a01';C=S/'r09-split-merge-relay-a01/r09-forward-a01'
H='d7135ca3bf40c33c2d5416242ce844077f1e8cbe';M='desktop-3fevhd2-1c74096080';RUN=M+'--vanilla--R0194';inputpins={};cache={}
def need(v,s):
 if not v:raise ValueError(s)
def enc(v):return (json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def wire(v):return json.loads(json.dumps(v,ensure_ascii=False))
def read(p,expected=None):
 p=Path(p);key=str(p.resolve())
 if key not in cache:
  need(p.is_file() and not p.is_symlink() and p.stat().st_size<=1024*1024,'Only named small immutable JSON inputs')
  b=p.read_bytes();cache[key]=b;inputpins[key]={'path':key,'bytes':len(b),'sha256':sha(b)}
 b=cache[key]
 if expected:need(len(b)==expected['bytes'] and sha(b)==expected['sha256'],'Exact actual pin changed '+key)
 return json.loads(b)
def pinned(p):return read(p['path'],p)
def module(rel,name):
 b=subprocess.check_output(['git','show',H+':'+rel],cwd=R);m=types.ModuleType(name);m.__file__=str(R/rel);sys.modules[name]=m;exec(compile(b,m.__file__,'exec'),m.__dict__);return m,{'repo_path':rel,'source_head':H,'bytes':len(b),'sha256':sha(b)}
def rows(p):return [r for r in p['query']['army_strengths'] if r['status']=='available']
def save(n,v):
 b=enc(v);p=L/n;need(not p.exists(),'Create-only result');need(sum(x.stat().st_size for x in L.rglob('*') if x.is_file())+len(b)<=1024*1024,'1MiB lane budget')
 with p.open('xb') as f:f.write(b)
 return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def main():
 need(shutil.disk_usage(L).free>20*1024**3,'System free floor');sys.path.insert(0,str(R/'ck3_autonomous_player/src'))
 from xar_autoplayer.bridge import army_split_merge_observation_12004 as obs
 root='promo/ck3_native_war_ai/episode-04-march-logistics/tools/review02/split_merge/'
 relay,rp=module(root+'root_relay.py','r194_historical_relay');transfer,tp=module(root+'army_split_transfer_assertions_12004.py','r194_historical_transfer');policy,pp=module('ck3_autonomous_player/src/xar_autoplayer/bridge/army_split_unrelated_role_transfer_12004.py','r194_historical_role_policy')
 config=read(T/'controller-input.actual.json');proof=read(S/'runtime-actor-identity.actual-a01.json')
 need(config['source_head']==proof['source_head']==H and proof['run_id']==config['run_id']==RUN and proof['pid']==30444 and config['direction']=='source','Actual source/run/direction')
 binding=relay.admission(pinned(config['context']),proof,run_id=RUN,source=H,sequence=194,machine=M,minimum_sequence=1)
 pins=read(L/'FINAL-ENDPOINT-PINS.actual-a01.json');names=['baseline-ENDPOINT.actual.json','post-split-ENDPOINT.actual.json','post-merge-ENDPOINT.actual.json'];endpoints=[pinned(pins[n]) for n in names];stored=[pinned(e['packet']) for e in endpoints];packets=[v['packet'] for v in stored]
 film=pinned(pins['FILM-CONTROLLER.actual.json']);need(film.get('error') is None and film['action_and_endpoint_chain_complete'] is True and film['recorder_finish']['state']=='NORMAL_TREE_EMPTY' and film['recorder_finish']['job']['returncode']==0 and film['recorder_finish']['job']['job_active_processes']==0,'Root finished actual controller/recorder contract')
 for e,p,saved in zip(endpoints,packets,stored):
  need(e['source_head']==saved['source_head']==H and e['run_id']==saved['run_id']==RUN and saved['binding']==binding,'Own endpoint runtime/source')
  relay.validate_frame(p['frame'],binding);q=p['query'];need(q['accepted'] is True and [q[k] for k in ('queried_snapshot_id','queried_revision','queried_native_revision')]==[p['frame'][k] for k in ('snapshot_id','revision','native_revision')],'Query own frame')
 need(len({p['frame']['date_raw'] for p in packets})==1,'Paused experiment game date changed')
 f0,f1,f2=packets;child=obs.identify_split_sibling(f0['frame'],f1['frame'],source_army_id=93,pre_strengths=f0['query'],post_strengths=f1['query'])['sibling_army_id'];maps=[{r['army_id']:r for r in p['query']['army_strengths']} for p in packets]
 need(93 in relay.roster(f2['frame']) and child not in relay.roster(f2['frame']),'Actual forward merge survivor/removal')
 split=transfer.assert_fresh_split_transfer_12004(f0['frame'],f1['frame'],source_army_id=93,pre_strengths=f0['query'],post_strengths=f1['query'],pre_commander=f0['commanders']['93'],post_commanders={int(k):v for k,v in f1['commanders'].items()})
 role=policy.qualify_unrelated_role_removal(f0,f1,source_army_id=93);merge=relay.compare_data_roles(transfer,[maps[1][93],maps[1][child]],[maps[2][93]]);supply=relay.compare_merge_supply(f1,f2,[93,child]);unrelated=obs.compare_split_merge_cohorts([maps[1][i] for i in (18,94,95)],[maps[2][i] for i in (18,94,95)])
 commanders=[]
 for p,ids in zip(packets,[(93,),(93,child),(93,)]):
  commanders.append({str(i):obs.read_bound_current_commander(p['commanders'][str(i)],p['frame'],army_id=i,native_carmy_id=next(a['native_carmy_id'] for a in rows(p) if a['army_id']==i)) for i in ids})
 for i in (18,94,95):
  need(relay.roster(f1['frame'])[i]==relay.roster(f2['frame'])[i],'Merge unrelated roster changed')
  for key in ('current_supply_raw','current_supply_capacity_raw','merge_supply_destination_weight_raw','native_carmy_id'):need(maps[1][i][key]==maps[2][i][key],'Merge unrelated scalar changed')
  need(obs.read_bound_current_commander(f1['commanders'][str(i)],f1['frame'],army_id=i,native_carmy_id=maps[1][i]['native_carmy_id'])==obs.read_bound_current_commander(f2['commanders'][str(i)],f2['frame'],army_id=i,native_carmy_id=maps[2][i]['native_carmy_id']),'Merge unrelated actual commander changed')
 observed=[transfer._observe(rows(p)) for p in packets];physical_equal=observed[0][1]==observed[1][1]==observed[2][1];aliases_equal=observed[0][2]==observed[1][2]==observed[2][2]
 totals=[{'unique_physical_slots':len(v[1]),'physical_current_max':[sum(a[i] for a in v[1].values()) for i in (0,1)],'cached_current_max':[sum(r[k] for r in rows(p)) for k in ('current_soldiers','maximum_soldiers')]} for p,v in zip(packets,observed)]
 selected=[]
 for n,(p,ids) in enumerate(zip(packets,[(93,),(93,child),(93,)])):
  stage=[]
  for aid in ids:
   a=next(r for r in rows(p) if r['army_id']==aid);_,phys,_=transfer._observe([a]);stage.append({'public_army_id':aid,'native_carmy_id':a['native_carmy_id'],'cached_current_max':[a['current_soldiers'],a['maximum_soldiers']],'physical_current_max':[sum(v[i] for v in phys.values()) for i in (0,1)],'physical_keys':[list(k) for k in sorted(phys)],'stock_cap_weight_raw':[a['current_supply_raw'],a['current_supply_capacity_raw'],a['merge_supply_destination_weight_raw']],'current_refill_classification':endpoints[n]['current_refill_classification'][str(aid)]})
  selected.append({'stage':'F'+str(n),'armies':stage})
 claim=read(C/'merge.once.claim.json');ack=read(C/'merge.submission.actual.json');splitclaim=read(C/'split.once.claim.json');splitack=read(C/'split.submission.actual.json');need(claim['army_ids']==[93,child] and ack['body']['accepted'] is True and ack['body']['war_action']['postcondition_verified'] is True and splitack['body']['accepted'] is True,'Actual unique action ACK/merge postcondition')
 ui=pinned(pins['SURVIVOR-UI.actual-a05.json']);need(ui['survivor_army_window_visible_verified'] is True and ui['survivor_public_cunit_id']==93 and ui['survivor_native_carmy_id']==maps[2][93]['native_carmy_id'] and ui['no_new_split_or_merge'] is True,'Actual survivor UI proof')
 forwardpath=Path('C:/ck3-e04-resume-20261015-a01/r193-r09-reverse-analysis-a01/canonical-a01/patch-root/docs/ck3-native-ai/evidence/episode04-r193-reverse-pair-12004/r193-reverse-pair-evidence.zip');need(forwardpath.stat().st_size==269701,'Sealed R192/R193 portable bound');b=forwardpath.read_bytes();need(sha(b)=='bf4b295bb55a0441a0d909a373fced8f252b9d832e51742b5bc0aa041aef7972','Existing pair archive exact pin')
 with zipfile.ZipFile(forwardpath) as z:oldendpoint=json.loads(z.read('original/baseline-ENDPOINT.actual.json'));oldproof=json.loads(z.read('original/runtime-actor-identity.actual-a01.json'))
 sameS0=endpoints[0]['normal_save_sha256']==oldendpoint['normal_save_sha256']==config['source_checkpoint']['save']['sha256'];sameF0=endpoints[0]['frozen_observable']==oldendpoint['frozen_observable'];separate=(proof['pid'],proof['process_creation_filetime_100ns'])!=(oldproof['pid'],oldproof['process_creation_filetime_100ns'])
 numeric=all([split['accepted'],role['role_aware_physical_guard_pass'],merge['accepted'],unrelated['frozen_exact_cohort_pass'],supply['weighted_supply_match'],physical_equal,aliases_equal,sameS0,sameF0,separate]);need(numeric,'Actual R194 numeric qualification failed')
 result={'schema':'xar.e04.r194-forward-independent-small-endpoint-analysis.v1','machine_id':M,'source_head':H,'run_id':RUN,'observed_at_utc':datetime.now(timezone.utc).isoformat(),'same_normal_S0':sameS0,'full_F0_observable_equals_R193':sameF0,'independent_actual_cold_process_lifetime':separate,'paused_date_raw':f0['frame']['date_raw'],'actual_binding':binding,'source_public_native':[93,maps[0][93]['native_carmy_id']],'child_public_native':[child,maps[1][child]['native_carmy_id']], 'ordered_merge_army_ids':claim['army_ids'],'split_assertion_recomputed':wire(split),'finite_split_unrelated_policy':wire(role),'merge_DATA_roles':wire(merge),'merge_unrelated_strict':wire(unrelated),'merge_supply':supply,'global_physical_and_cached_F0_F1_F2':totals,'all_available_global_physical_values_and_aliases_equal':physical_equal and aliases_equal,'selected_three_frames':selected,'actual_current_commanders':commanders,'numeric_forward_sameS0_reconfirmation':numeric,'actual_action_and_endpoint_chain_complete':True,'survivor_UI_visible_verified':True,'survivor_UI_additional_select_count':ui['additional_UI_Select_count'],'original_action_claim_count':{'split':1,'merge':1},'time_advanced':film['time_advanced'],'unique_finished_recorder':True,'recorded_chain_timeline':film['timeline'],'source_observed_native_birth_or_write_PC':False,'all_roster_strengths_qualified':False,'excluded_unavailable_cohorts':f2['excluded_unavailable_cohorts'],'strict_legacy_unrelated_false_preserved':role['frozen_exact_cohort_pass'] is False,'distinct_stock_observed':supply['distinct_pre_stock_observed'],'upper_clamp_positive':supply['upper_clamp_observed'],'candidate_R09_business_close':True,'R09_closed_or_7of14_automatically_counted':False,'dynamic_clean_human_media_review_pending':True,'normal_close_pending':True,'full_Driver_body_read_counts':{'F0':0,'F1':0,'F2':0},'SDK_game_desktop_main_actions':0,'production_source_pins':[rp,tp,pp],'actual_input_pins':list(inputpins.values()),'existing_pair_portable_reference':{'path':str(forwardpath),'bytes':269701,'sha256':sha(b)},'original_value_pointers':{'complete_packets':'Each ENDPOINT /packet exact pin; saved packet /packet/query/army_strengths','current_flags':'Each ENDPOINT /current_refill_classification/<actualArmy>','typed_current':'Saved packet /packet/commanders/<actualArmy>/army_commander_candidates/current_commander','supply':'Saved packet /packet/query/army_strengths/*/current_supply_raw, current_supply_capacity_raw, merge_supply_destination_weight_raw','GUI':'SURVIVOR-UI.actual-a05.json with its own independent native readbacks'},'python':{'executable':sys.executable,'version':sys.version,'argv':sys.argv}}
 resultpin=save('NUMERIC-ANALYSIS.actual-a01.json',result);print(json.dumps({'result':resultpin,'numeric':numeric,'global_totals':totals,'selected_totals':[[{k:v for k,v in a.items() if k!='current_refill_classification'} for a in s['armies']] for s in selected],'supply':supply,'business_candidate':True,'whole_card_not_counted_automatically':True,'full_Driver_reads':0}))
if __name__=='__main__':main()
