"""Root-only R09 source/preparer/controller over existing typed file relay.

Import, source, prepare, compare and --help do not contact SDK/desktop. Only
baseline/film with --execute-live may publish to an already owned Root relay.
No launch, time advance, close/exit, SDK client, write-memory or new native API.
"""
from __future__ import annotations
import argparse, ast, hashlib, importlib.util, json, re, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
PACKAGE_ROOT=Path(__file__).resolve().parent
REPO=Path('D:/workspace/ck3_eternal_recurrence')
MACHINE='desktop-3fevhd2-1c74096080'
PY=REPO/'tools/.venv/Scripts/python.exe'
BASE=Path('C:/ck3-e04-resume-20261015-a01/live12004-r13-normal-a01')
RUN176=MACHINE+'--vanilla--R0176'
RELAY=REPO/'promo/ck3_native_war_ai/episode-04-march-logistics/tools/review02/split_merge/root_relay.py'
GUARD=RELAY.parent.parent/'runtime_binding.py'
SAVE={'path':str(BASE/'state-a01/profile/save games/xar_checkpoint.ck3'), 'bytes':71305933,
      'sha256':'31c57bc0032f0af4dcb90b4f00567cd68638e71856bbd570ee847aa644c26378'}
RESPONSE={'path':str(BASE/RUN176/'responses/022b-terminal-normal-checkpoint.json'), 'bytes':20139,
          'sha256':'2402e49d649a09dc3ed1c053d3e03f78e73b8cdd9b039561b19f4a3749720ad8'}
def need(ok,why):
    if not ok:raise ValueError(why)
def now():return datetime.now(timezone.utc)
def read(p,limit=1024*1024):
    p=Path(p);need(p.is_file() and not p.is_symlink() and p.stat().st_size<=limit,'bounded real input required '+str(p))
    raw=p.read_bytes();need(len(raw)<=limit,'input grew');return json.loads(raw.decode('utf-8-sig'))
def pin(p,limit=4*1024*1024):
    p=Path(p).resolve(strict=True);need(p.is_file() and not p.is_symlink() and p.stat().st_size<=limit,'bounded pin required '+str(p))
    raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def same(a,b):
    return isinstance(a,dict) and isinstance(b,dict) and a.get('bytes')==b.get('bytes') and a.get('sha256')==b.get('sha256') and Path(a.get('path','')).resolve()==Path(b.get('path','')).resolve()
def load(p,limit=1024*1024):
    need(same(pin(p['path'],limit),p),'exact pin changed '+str(p.get('path')));return read(p['path'],limit)
def write(p,row):
    p=Path(p);raw=(json.dumps(row,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    need(len(raw)<=1024*1024,'small receipt limit');p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(raw)
    return pin(p)
def module(p,name):
    s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
def machine():
    return subprocess.check_output([str(PY),'-B',str(REPO/'tools/ck3_live_run_id.py'),'machine'],text=True).strip()
def frozen(source_head):
    need(type(source_head) is str and re.fullmatch('[0-9a-f]{40}',source_head) is not None,'actual40hex source_head required')
    need(subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()==source_head,'actual source HEAD changed')
    need(not subprocess.check_output(['git','-C',str(REPO),'--no-optional-locks','status','--porcelain']).strip(),'actual source checkout is dirty')
    need(machine()==MACHINE,'current execution machine differs')
def normal_source():
    """Validate small original source/close packets; only stat the 71MB save."""
    closed_pin=pin(BASE/'CLOSED.actual-a01.json');closed=load(closed_pin)
    need(closed.get('machine_id')==MACHINE and closed.get('run_id')==RUN176 and closed.get('normal_exit_code')==0
         and closed.get('game_recorder_SDK_keeper_closed') is True,'R176 normal closure wrapper differs')
    evidence=closed['evidence'];need(same(evidence['terminal_normal_save'],RESPONSE),'R176 save receipt is not exact admitted source')
    body=load(RESPONSE);saved=body['body']['checkpoint'];boot=load(evidence['bootstrap']);release=load(evidence['screen_release'])
    lifecycle=saved.get('succession_lifecycle') or {}
    need(body.get('machine_id')==MACHINE and body.get('is_error') is False and body['request']['tool']=='ck3_save_checkpoint'
         and body['body'].get('accepted') is True and saved.get('status')=='saved' and saved.get('date_raw')==53146632
         and saved.get('episode_character_id')==31254 and saved.get('sha256')==SAVE['sha256'] and saved.get('size')==SAVE['bytes']
         and Path(saved['path']).resolve()==Path(SAVE['path']).resolve(),'R176 native normal checkpoint differs')
    need(lifecycle.get('lifecycle')=='ordinary_campaign_succession' and lifecycle.get('xar_enabled')=='xar_off'
         and lifecycle.get('source')=='pure-vanilla-enabled-mods-empty','source is not pure vanilla ordinary campaign')
    session=boot['session'];shutdown=session['shutdown'];lease=boot['screen_lease']
    need(boot.get('machine_id')==MACHINE and session.get('ok') is True and session.get('pid')==4992
         and session.get('exit_reason')=='process_exit' and session.get('process_exit_code')==0
         and shutdown.get('tree_gone') is True and shutdown.get('cleanup_proven') is True and shutdown.get('job_active_processes_final')==0
         and boot.get('sdk_thread_exited') is True and boot.get('sdk_error') is None and boot.get('supervisor_error') is None
         and lease.get('thread_exited') is True and lease.get('failure') is None and boot['recorder']['state']=='NORMAL_TREE_EMPTY',
         'source did not normal-exit0 with game/recorder/SDK/keeper empty')
    bus=json.loads(release['stdout'])
    need(release.get('machine_id')==MACHINE and release.get('exit_code')==0 and bus.get('ok') is True
         and bus['task']['state']=='done' and bus['task']['resources']==[] and bus['task']['task_id']==lease['task_id'],
         'source screen release did not actually finish')
    prepared_pin=pin(BASE/'prepared-a01/prepared.json');prepared=load(prepared_pin)
    need(prepared.get('machine_id')==MACHINE and prepared.get('target_build',{}).get('version')=='1.20.0.4'
         and Path(saved['path']).parent.resolve()==(Path(prepared['profile_dir'])/'save games').resolve(), 'source prepared/profile differs')
    save=Path(SAVE['path']);st=save.stat();need(save.is_file() and not save.is_symlink() and st.st_size==SAVE['bytes'],'source save stat differs')
    return {'machine_id':MACHINE,'observed_at_utc':now().isoformat(),'source_run_id':RUN176,
      'save':SAVE,'save_response':RESPONSE,'prepared':prepared_pin,
      'normal_close':{'closed':closed_pin,'bootstrap_result':evidence['bootstrap'],'screen_release':evidence['screen_release']},
      'expected_start_date_raw':53146632,'actor_id':31254,'source_small_normal_closure_validated':True,
      'source_is_old_postmerge_not_old_F0':True,'both_new_arms_required':True,
      'current_save_stat':{'bytes':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns,'is_symlink':False},
      'large_save_bytes_read':0,'current_save_full_sha_recomputed':False,'fresh_U_owner_control_special_and_native_validate':'not_observed'}
def source(source_head):
    frozen(source_head);result=normal_source();out=write(PACKAGE_ROOT/'R0176-POSTMERGE-SOURCE.actual-a01.json',result);print(json.dumps(out))
def transport_source(scene,context):
    return '''"""Root-owned existing relay; no SDK client and no work at import."""
from pathlib import Path
import json,time
ASSETS=Path(%r)
CONTEXT=json.loads(Path(%r).read_text(encoding='utf-8-sig'))
RUN=ASSETS/CONTEXT['identity']['run_id']
def request(identifier,tool,arguments,timeout=55):
 p=RUN/'requests'/(identifier+'.json');r=RUN/'responses'/p.name
 if p.exists() or r.exists():raise RuntimeError('Original exists; inspect, never replay '+identifier)
 t=p.with_suffix('.pending')
 with t.open('x',encoding='utf-8') as f:json.dump({'request_id':identifier,'tool':tool,'arguments':arguments},f)
 t.rename(p);end=time.monotonic()+timeout
 while time.monotonic()<end:
  if r.exists():
   try:
    value=json.loads(r.read_text(encoding='utf-8-sig'))
    if value.get('request',{}).get('request_id')!=identifier:raise RuntimeError('Response identity differs')
    return value
   except json.JSONDecodeError:pass
  time.sleep(.025)
 raise TimeoutError('Original pending; never replay '+identifier)
'''%(str(scene),str(context))
ROLE_POLICY_REL='ck3_autonomous_player/src/xar_autoplayer/bridge/army_split_unrelated_role_transfer_12004.py'
def native_qualification_contract(c,prepared,qualification):
    """Pure pin/semantic coupling; actual q and output paths come from Root."""
    head=c.get('source_head');schema=c.get('native_qualification_schema')
    need(type(head) is str and re.fullmatch('[0-9a-f]{40}',head) is not None,'actual40hex source_head required')
    match=re.fullmatch(r'xar\.e04\.a([0-9]+)-production-bytes-focused-cold-qualification\.v1',schema or '')
    need(match is not None and int(match.group(1))>=32,'actual a32-or-later focused native qualification schema required')
    need(qualification.get('schema')==schema and qualification.get('machine_id')==MACHINE
      and qualification.get('source_head')==qualification.get('runtime_source_head')==qualification.get('native_build_source_head')==head
      and qualification.get('status')=='PRODUCTION_BYTES_AND_AFFECTED_COLD_FIXTURES_VERIFIED'
      and qualification.get('production_bytes_qualified') is True and qualification.get('fixtures_once') is True,
      'actual native production qualification/source/machine/focused status differs')
    values=qualification.get('outputs');need(type(values) is list and values,'actual qualified outputs required')
    names=[Path(v['path']).name for v in values]
    need(len(set(names))==len(names),'duplicate qualified native output names')
    outputs=dict(zip(names,values))
    for field,name in (('bridge_dll','xar_ck3_bridge.dll'),('bridge_injector','xar_ck3_bridge_injector.exe'),('bridge_host','xar_ck3_bridge_host.exe')):
        value=outputs.get(name)
        need(type(value) is dict and type(value.get('bytes')) is int and value['bytes']>0
          and re.fullmatch('[0-9a-f]{64}',value.get('sha256','')) is not None
          and same(prepared.get(field),value),'actual normal prepared native path/size/SHA not from current qualified outputs: '+name)
    return {'source_head':head,'native_qualification_schema':schema,'qualified_native_output_count':len(values),
      'prepared_native_outputs_exact_to_qualification':True,'qualification_is_not_live_gameplay_or_capture':True}

def production_packet_destination_contract(path=RELAY):
    """Read current production source; refuse the known reverse-F2 fixed93 bug."""
    path=Path(path);data=path.read_bytes();need(len(data)<=256*1024,'bounded production Relay source required')
    tree=ast.parse(data.decode('utf-8-sig'))
    classes=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Relay']
    need(len(classes)==1,'production Relay class unavailable')
    methods={n.name:n for n in classes[0].body if isinstance(n,ast.FunctionDef)}
    packet=methods.get('packet');post=methods.get('post_merge')
    need(packet is not None and post is not None and 'required_army_id' in [a.arg for a in packet.args.kwonlyargs],
      'production packet lacks reviewed reverse survivor parameter')
    expected=ast.dump(ast.parse("claim['army_ids'][0]",mode='eval').body,include_attributes=False)
    calls=[n for n in ast.walk(post) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)
      and isinstance(n.func.value,ast.Name) and n.func.value.id=='self' and n.func.attr=='packet'
      and n.args and isinstance(n.args[0],ast.Constant) and n.args[0].value=='post-merge']
    need(len(calls)==1 and any(k.arg=='required_army_id' and ast.dump(k.value,include_attributes=False)==expected
      for k in calls[0].keywords),'production post_merge does not pass actual ordered Merge claim destination')
    selectors=[n for n in ast.walk(packet) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)
      and n.func.id=='selected_available_cohorts']
    expected_selector=ast.dump(ast.parse('self.a.army_id if required_army_id is None else required_army_id',mode='eval').body,include_attributes=False)
    need(len(selectors)==1 and len(selectors[0].args)==3
      and ast.dump(selectors[0].args[2],include_attributes=False)==expected_selector,
      'production packet selected-cohort guard does not use reviewed explicit/default target')
    return {'production_relay':pin(path),'packet_required_army_id_supported':True,
      'post_merge_required_army_id_source':"actual current Merge claim['army_ids'][0]",
      'F0_F1_default_target_preserved':True,'old_external_packet_subclass_used':False}

def canonical_role_policy(c):
    policy=c.get('split_unrelated_policy')
    need(type(policy) is dict and Path(policy.get('path','')).resolve()==(REPO/ROLE_POLICY_REL).resolve(),
      'current committed canonical split role policy exactpin required')
    need(same(pin(policy['path']),policy),'current canonical role policy bytes changed')
    return policy


def prepare(config):
    """Root invokes after real normal cold-load, sealed identity and capacity."""
    c=read(config);frozen(c.get('source_head'));source=normal_source();scene=Path(c['scene_root']).resolve(strict=True)
    need(c.get('army_id')==93 and c.get('direction') in ('source','sibling'),'current selected93 and explicit direction required')
    context=load(c['context']);proof=load(c['runtime_proof']);capacity=load(c['capacity']);prepared=load(c['prepared']);qualification=load(c['native_qualification'])
    native_contract=native_qualification_contract(c,prepared,qualification)
    packet_contract=production_packet_destination_contract();canonical_role_policy(c)
    run=context['identity']['run_id'];need(scene==Path(c['context']['path']).resolve().parent and (scene/run/'requests').is_dir(),'actual allocated launched relay required')
    need(proof.get('initial_date_raw')==53146632 and proof.get('actual_runtime_character_full_id')==31254
         and proof.get('machine_id')==MACHINE and proof.get('source_head')==c['source_head'] and proof.get('run_id')==run,'new normal R09 identity differs')
    loaded=prepared.get('checkpoint',{}).get('source',{})
    need(same(loaded.get('save'),SAVE) and same(loaded.get('receipt'),RESPONSE)
         and same(loaded.get('build_receipt'),source['prepared']) and loaded.get('driver_history_copied') is False
         and prepared.get('machine_id')==MACHINE and prepared.get('target_build',{}).get('version')=='1.20.0.4',
         'Root normal prepare must actually copy/check the exact R176 source, without old Driver JSON')
    copied=prepared.get('checkpoint',{}).get('profile_copy',{})
    need(copied.get('bytes')==SAVE['bytes'] and copied.get('sha256')==SAVE['sha256'],'Root full-byte prepared save check absent')
    need(re.fullmatch('[A-Za-z][A-Za-z0-9_-]{0,25}',c['case_id']) is not None
         and re.fullmatch('[A-Za-z][A-Za-z0-9_-]{0,47}',c['raw_directory_name']) is not None,'bounded simple case/raw directory names required')
    need(type(c.get('seconds')) is int and 60<=c['seconds']<=180,'recording budget must explicitly cover60..180s; target action span45..60s')
    need(c.get('expected_client_size')==[1280,720] and c.get('fps')==30,'exact1280x720 client30fps required')
    guard=module(GUARD,'r09_guard_prepare');runtime=guard.proof_runtime(proof)
    binding={'schema':guard.SCHEMA,'operation_id':c['case_id'],'machine_id':MACHINE,'source_head':c['source_head'],
      'scene_root':str(scene),'run_id':run,'run_sequence':context['identity']['sequence'],'runtime':runtime,
      'normal_save_sha256':SAVE['sha256'],'max_runtime_total_bytes':c['max_runtime_total_bytes'],
      'created_at_utc':now().isoformat(),'deadline_utc':capacity['quota_review_at_utc'],
      'capacity_admission':c['capacity'],'guard_sha256':pin(GUARD)['sha256']}
    guard.validate_operation(binding,capacity,context,runtime,scene_root=scene,source_head=c['source_head'],machine_id=MACHINE,run_id=run,
      max_runtime_total_bytes=c['max_runtime_total_bytes'],now_utc=now(),normal_save_sha256=SAVE['sha256'])
    need((guard.timestamp(binding['deadline_utc'])-now()).total_seconds()>=c['seconds']+180+30,'fresh capacity must cover recorder and normal close reserve')
    out=scene/'r09-root-controller-a01';need(not out.exists(),'fresh controller output required');out.mkdir()
    binding_pin=write(out/'live-operation.actual.json',binding)
    old=read(RELAY.with_name('MODULES.pins.json'))
    modulepins={'schema':old['schema'],'source_head':c['source_head'],'repository_files':{k:pin(REPO/k)['sha256'] for k in old['repository_files']},
      'split_consumer_sha256':pin(RELAY.with_name('army_split_transfer_assertions_12004.py'))['sha256'],
      'split_consumer_source':'current reviewed normal source, unchanged existing consumer semantics'}
    pins=write(out/'MODULES.current.pins.json',modulepins)
    t=out/'root_transport.py';t.write_text(transport_source(scene,c['context']['path']),encoding='utf-8')
    final={**c,'machine_id':MACHINE,'run_id':run,'source_checkpoint':source,'live_binding':binding_pin,
      'request_helper':pin(t),'module_pins':pins,'relay':pin(RELAY),'guard':pin(GUARD),'controller':pin(Path(__file__)),
      'normal_input_fully_verified_by_existing_prepare':True,'source_current_large_read_bytes_by_this_preparer':0,
      'split_unrelated_policy':c['split_unrelated_policy'],'native_qualification_contract':native_contract,'production_packet_destination_contract':packet_contract,'legacy_strict_false_is_preserved_for_role_transfer':True}
    configpin=write(out/'controller-input.actual.json',final)
    argv={'machine_id':MACHINE,'source_head':c['source_head'],'SDK_calls':0,'desktop_calls':0,'live_executed':False,'input':configpin,
      'baseline':[str(PY),'-B','-X','utf8',str(Path(__file__)),'baseline','--config',configpin['path'],'--execute-live'],
      'film':[str(PY),'-B','-X','utf8',str(Path(__file__)),'film','--config',configpin['path'],'--frame-review','ACTUAL_PATH','ACTUAL_BYTES','ACTUAL_SHA','--execute-live'],
      'normal_close':'Use Root actual normal-save/exit0/screen-release adapter after film; this helper never exits or restarts CK3.'}
    write(out/'ROOT-ARGV.actual.json',argv);print(json.dumps({'controller_input':configpin,'argv':argv},ensure_ascii=False))
def configured(path):
    c=read(path);need(c['machine_id']==MACHINE,'controller machine differs');frozen(c.get('source_head'))
    for k in ('controller','relay','guard','context','runtime_proof','capacity','prepared','native_qualification','request_helper','module_pins','live_binding','split_unrelated_policy'):load(c[k]) if k in ('context','runtime_proof','capacity','prepared','native_qualification','module_pins','live_binding') else need(same(pin(c[k]['path']),c[k]),'source input changed '+k)
    native_qualification_contract(c,load(c['prepared']),load(c['native_qualification']));canonical_role_policy(c)
    need(production_packet_destination_contract()==c['production_packet_destination_contract'],'current production packet destination contract differs')
    return c
def relay_args(c,stage):
    return SimpleNamespace(stage=stage,repo=REPO,context=Path(c['context']['path']),context_sha256=c['context']['sha256'],
      runtime_proof=Path(c['runtime_proof']['path']),runtime_proof_sha256=c['runtime_proof']['sha256'],
      request_helper=Path(c['request_helper']['path']),request_helper_sha256=c['request_helper']['sha256'],
      self_sha256=c['relay']['sha256'],run_id=c['run_id'],case_id=c['case_id'],attempt=c['case_id']+'-'+stage,
      army_id=c['army_id'],source_head=c['source_head'],run_sequence=load(c['context'])['identity']['sequence'],
      module_pins=Path(c['module_pins']['path']),module_pins_sha256=c['module_pins']['sha256'],
      live_binding=Path(c['live_binding']['path']),live_binding_sha256=c['live_binding']['sha256'],
      max_runtime_total_bytes=c['max_runtime_total_bytes'],merge_destination=c['direction'],merge_source_army_id=None,
      resume_baseline_strength_response=None)
def split_role_relay(c,base):
    policy=canonical_role_policy(c)
    sys.path.insert(0,str(REPO/'ck3_autonomous_player/src'))
    return module(policy['path'],'r09_current_committed_split_role_policy').relay_class(base)

def stage(c,name):
    m=module(RELAY,'r09_existing_relay_'+name.replace('-','_'));r=split_role_relay(c,m.Relay)(relay_args(c,name))
    dispatch={'baseline':r.baseline,'split-once':lambda:r.submit_once('split'),'post-split':r.post_split,
      'merge-once':lambda:r.submit_once('merge'),'post-merge':r.post_merge,'supply-clamp':r.supply_clamp}
    result=dispatch[name]();m.write_new(r.attempt/'RESULT.actual.json',{**r.meta,'result':result});return r
def endpoint(c,name):
    m=module(RELAY,'r09_endpoint_module');scene=Path(c['scene_root']);case=scene/'r09-split-merge-relay-a01'/c['case_id']
    saved=read(case/(name+'.actual.json'),2*1024*1024);p=saved['packet'];rawpin=p['refs']['strength_raw']
    need(same(m.driver_raw_pin(rawpin['path']),rawpin),'raw endpoint pin changed');q=m.load(rawpin['path'],64*1024*1024)
    sys.path.insert(0,str(REPO/'ck3_autonomous_player/src'))
    from xar_autoplayer.bridge.army_persistent_refill_eligibility_12004 import classify_army_persistent_refill_eligibility_12004
    selected=[c['army_id']] if name=='baseline' else [a['army_id'] for a in q['army_strengths'] if a['status']=='available']
    eligibility={str(i):classify_army_persistent_refill_eligibility_12004(p['frame'],q,army_id=i) for i in selected}
    frame=load(p['refs']['snapshot']['response'])['body']
    rows=[]
    for army in p['query']['army_strengths']:
        if army['status']!='available':continue
        data=[]
        for row in army['regiment_replenishment_records_v1']:
            data.append({'army_regiment_id':row['army_regiment_id'],'native_data_record_count':row['native_data_record_count'],
              'native_loss_writer_skipped':row.get('native_loss_writer_skipped'),'records':[{k:v for k,v in r.items() if k in
              ('record_index','persistent_regiment_id','chunk_index','chunk_army_regiment_id','current_soldiers','maximum_soldiers','state_raw')}
               for r in row['records']], 'role':{k:v for k,v in (row.get('native_character_role_v1') or {}).items() if k in
               ('native_carmy_id','arrg_army_id_140','character_raw_id_148','resolved_character_id','native_character_predicate','extension_army_id_f4','extension_arrg_id_f8')}})
        current=m.module(REPO/'ck3_autonomous_player/src/xar_autoplayer/bridge/army_split_merge_observation_12004.py','r09_ep_observation').read_bound_current_commander(
          p['commanders'][str(army['army_id'])],p['frame'],army_id=army['army_id'],native_carmy_id=army['native_carmy_id'])
        rows.append({'army':{k:v for k,v in army.items() if k not in ('regiment_replenishment_records_v1','unavailable_reason')},'DATA':data,'commander':current})
    frozen_observable={'date_raw':p['frame']['date_raw'],'roster':p['frame']['player_armies'],'armies':rows,'active_wars':frame.get('active_wars'),
      'current_refill_inputs':{i:{'physical_chunks':v['physical_chunks'],'empty_ArRg_rows':v['empty_ArRg_rows']} for i,v in eligibility.items()}}
    fingerprint=hashlib.sha256(json.dumps(frozen_observable,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    out={'machine_id':MACHINE,'source_head':c['source_head'],'run_id':c['run_id'],'stage':name,'normal_save_sha256':SAVE['sha256'],
      'packet':pin(case/(name+'.actual.json')),'strength_raw':rawpin,'frozen_observable':frozen_observable,'F0_observable_sha256':fingerprint,
      'current_refill_classification':eligibility,'all_roster_strengths_qualified':False,'birth_producer_observed':False,'dynamic_qualified':False,'R09_full_card_closed':False}
    return write(scene/'r09-root-controller-a01'/(name+'-ENDPOINT.actual.json'),out)
def baseline(path):
    c=configured(path);stage(c,'baseline');ep=endpoint(c,'baseline');p=load(ep)
    roster={a['army_id']:a for a in p['frozen_observable']['roster']};need(93 in roster,'selected93 absent; no split')
    eligibility=p['current_refill_classification']['93'];chunks=eligibility['physical_chunks']
    need(chunks and all(row['containing_guard_138_raw']==1 for row in chunks),'R09 selected special raw1381 cohort not currently confirmed; no split')
    ready=write(Path(c['scene_root'])/'r09-root-controller-a01/BASELINE-READY.actual.json',{'machine_id':MACHINE,'source_head':c['source_head'],
      'run_id':c['run_id'],'controller_input':pin(path),'F0':ep,'selected_special_raw1381_confirmed':True,
      'split_legality':'advertisement plus eventual single native Validate, not a read-only CanExecute result'})
    print(json.dumps({'F0':ep,'ready':ready}))
def finish_owned_recorder_once(transport, *, prefix, proof, process_probe):
    """Only cleanup: exact prior Start, owned lifetime and original relay.

    Capacity/deadline guards admit new business work, not cleanup of an already
    published Start. Never call OperationGuard.check here and never replay an
    existing Finish. Original request/response files remain the authority.
    """
    start_id=prefix+'-start-once';finish_id=prefix+'-finish-once'
    start=Path(transport.RUN)/'requests'/(start_id+'.json')
    if not start.exists():
        return {'state':'NOT_STARTED','start_request_published':False,'finish_request_published':False,
          'reason':'this controller never published its unique Start request; no recorder-empty claim'}
    request=read(start)
    need(request.get('request_id')==start_id and request.get('tool')=='gameplay_recorder'
         and request.get('arguments',{}).get('operation')=='start'
         and request.get('arguments',{}).get('target_pid')==proof['pid'],
         'cleanup Start request does not belong to this exact controller/owner')
    need(transport.CONTEXT.get('machine_id')==MACHINE and Path(transport.RUN).name==proof['run_id'],
         'cleanup original relay machine/run differs')
    need(process_probe(proof['pid'])==proof['process_creation_filetime_100ns'],
         'cleanup owned CK3 process lifetime differs; preserve truthful partial state')
    finish_request=Path(transport.RUN)/'requests'/(finish_id+'.json')
    finish_response=Path(transport.RUN)/'responses'/(finish_id+'.json')
    need(not finish_request.exists() and not finish_response.exists(),
         'original Finish already exists; inspect exact original, never replay')
    row=transport.request(finish_id,'gameplay_recorder',{'operation':'finish'},timeout=40)
    need(row.get('machine_id')==MACHINE and row.get('request',{}).get('request_id')==finish_id
         and row.get('is_error') is False and isinstance(row.get('body'),dict),
         'original cleanup Finish pending/error; never replay')
    return row['body']

def finish_and_preserve(result, primary, *, finish, persist):
    """Finish precedes report I/O; preserve the first business exception."""
    try:
        result['recorder_finish']=finish()
    except BaseException as error:
        result['finish_error']=repr(error)
        if primary is None:primary=error
    try:
        persist(result)
    except BaseException as error:
        result['result_receipt_error']=repr(error)
        if primary is None:primary=error
        else:
            try:primary.add_note('Film result receipt failed after cleanup: '+repr(error))
            except AttributeError:pass
        print('R09 film result receipt failed after unique cleanup attempt; original request/response evidence retained: '+repr(error),file=sys.stderr)
    return primary

def survivor_window_matches(body,before,after,*,army_id,native_id,binding):
    """Keep public CUnit subject separate from the actual mapped CArmy ID."""
    return (body.get('accepted') is True and body.get('available') is True
      and body.get('effective_visible') is True and body.get('window_kind')=='army'
      and body.get('current_subject_id')==army_id and body.get('native_army_id')==native_id
      and body.get('owner_character_id')==body.get('played_character_id')==binding['actor']
      and body.get('paused') is True and body.get('date_raw')==before['date_raw']
      and body.get('queried_connection_generation')==binding['generation']
      and body.get('episode_run_id')==binding['episode']
      and body.get('queried_revision')==before['revision']==after['revision']
      and body.get('queried_snapshot_id')==before['snapshot_id']==after['snapshot_id']
      and body.get('native_revision')==body.get('queried_native_revision')==before['native_revision']==after['native_revision'])

def ensure_survivor_ui(r,relay_module,*,started,seconds,timeline):
    """After the one Merge, read first; at most one UI Select; no new business action."""
    claim,original=r.original('merge')
    ids=claim.get('army_ids');need(type(ids) is list and len(ids)==2 and ids[0]!=ids[1]
      and all(type(i) is int and i>0 for i in ids),'actual ordered Merge claim IDs required')
    post_path=r.case/'post-merge.actual.json';post=read(post_path,2*1024*1024)
    need(post.get('binding')==r.binding and post.get('source_army_id')==ids[0]
      and post.get('merge_DATA_roles',{}).get('accepted') is True
      and post['merge_DATA_roles'].get('exact_source_removal_observed') is True,
      'actual accepted post-Merge destination/removal packet required before presentation')
    packet=post['packet'];rows=[a for a in packet['query']['army_strengths'] if a.get('army_id')==ids[0]]
    need(len(rows)==1 and rows[0].get('status')=='available'
      and type(rows[0].get('native_carmy_id')) is int and rows[0]['native_carmy_id']>0,
      'actual survivor CUnit-to-CArmy mapping unavailable')
    native=rows[0]['native_carmy_id'];events=[]
    def remaining():
        need((time.monotonic_ns()-started)/1e9<seconds-3,
          'recorded survivor UI tail exhausted; no new presentation request')
    def frame(label):
        remaining();a=time.monotonic_ns();body,refs=r.snapshot(label);b=time.monotonic_ns()
        need(body['date_raw']==packet['frame']['date_raw']
          and body['revision']>=packet['frame']['revision']
          and body['native_revision']>=packet['frame']['native_revision'],
          'survivor presentation date/revision predates accepted post-Merge')
        need(body['player_armies']==packet['frame']['player_armies'],
          'survivor presentation roster differs from accepted post-Merge')
        roster={a['army_id']:a for a in body['player_armies']}
        need(ids[0] in roster and ids[1] not in roster
          and roster[ids[0]].get('owner_character_id')==r.binding['actor']
          and roster[ids[0]].get('controllable') is True,'actual Merge survivor no longer owned/controllable')
        event={'stage':label,'tool':'ck3_take_snapshot','from_start_seconds':[(a-started)/1e9,(b-started)/1e9],**refs}
        timeline.append(event);events.append(event);return body,refs
    def request(label,tool,args):
        remaining();a=time.monotonic_ns();row,refs=r.request(label,tool,args);b=time.monotonic_ns()
        need(row.get('request',{}).get('tool')==tool and row['request'].get('arguments')==args,
          'actual survivor UI response request differs')
        event={'stage':label,'tool':tool,'from_start_seconds':[(a-started)/1e9,(b-started)/1e9],**refs}
        timeline.append(event);events.append(event);return row['body'],refs
    def observe(stem):
        before,bref=frame(stem+'-before')
        body,wref=request(stem+'-window','ck3_query_ingame_ui_window_v1',
          {'window_kind':'army','expected_revision':before['revision']})
        after,aref=frame(stem+'-after');relay_module.same_frame(before,after)
        # Native SelectUnit explicitly admits an uncreated panel. The current
        # native ReadWindow does not distinguish null from bad RTTI, so retain
        # the exact diagnostic rather than claiming the window was absent.
        # Only these two target-window diagnostics can enter one independently
        # guarded Select; owner/modal/frame or unstable-read failures cannot.
        target_unavailable=(body.get('accepted') is False and body.get('available') is False
          and body.get('status')=='unavailable' and body.get('unavailable_reason') in
              ('window_object_type_unverified','fixed_window_root_unavailable')
          and body.get('application_owner_thread_verified') is True
          and body.get('gui_owner_binding_verified') is True
          and body.get('dispatch_invoked') is False and body.get('verification_pending') is False)
        need((body.get('accepted') is True or target_unavailable)
          and body.get('window_kind')=='army' and body.get('paused') is True
          and body.get('date_raw')==before['date_raw']
          and body.get('native_revision')==before['native_revision']
          and body.get('played_character_id')==r.binding['actor']
          and body.get('queried_snapshot_id')==before['snapshot_id']
          and body.get('queried_revision')==before['revision']
          and body.get('queried_native_revision')==before['native_revision']
          and body.get('queried_connection_generation')==r.binding['generation']
          and body.get('episode_run_id')==r.binding['episode'],
          'survivor UI independent query rejected or not bound to current frame')
        return before,body,after,{'before':bref,'window':wref,'after':aref}
    before,body,after,initial=observe('survivor-ui-initial')
    already=survivor_window_matches(body,before,after,army_id=ids[0],native_id=native,binding=r.binding)
    selection=None;final=initial
    if not already:
        # The after snapshot is independently current; only this unique Select
        # may use its revision. Unknown/rejected dispatch is never repeated.
        path=r.case/'survivor-ui-select.once.claim.json'
        selection_claim=write(path,{**r.meta,'kind':'survivor-ui-select','subject_army_id':ids[0],
          'native_carmy_id_from_actual_post_merge':native,'expected_revision':after['revision'],
          'ordered_merge_claim':pin(r.case/'merge.once.claim.json'),
          'post_merge_packet':pin(post_path),'initial_independent_window':initial,
          'no_replay_even_if_rejected_or_timeout':True})
        selected,srefs=request('survivor-ui-select-once','ck3_select_army_ui_v1',
          {'subject_army_id':ids[0],'expected_revision':after['revision']})
        need(selected.get('dispatch_invoked') is True,'unique survivor UI Select was not dispatched; never replay')
        selection={'claim':selection_claim,'response':srefs,'dispatch_invoked':True}
        before,body,after,final=observe('survivor-ui-independent')
    need(survivor_window_matches(body,before,after,army_id=ids[0],native_id=native,binding=r.binding),
      'survivor UI independent CUnit/CArmy/owner/frame readback mismatch; never repeat Select')
    receipt={**r.meta,'observed_at_utc':now().isoformat(),'ordered_merge_ids':ids,
      'merge_claim':pin(r.case/'merge.once.claim.json'),'original_merge':original,'post_merge_packet':pin(post_path),
      'survivor_public_cunit_id':ids[0],'survivor_native_carmy_id':native,
      'CUnit_CArmy_mapping_source':'actual accepted post-merge packet query.army_strengths by army_id',
      'already_selected_after_merge_observed':already,'additional_UI_Select_count':0 if already else 1,
      'selection':selection,'initial_independent_readback':initial,'final_independent_readback':final,
      'survivor_army_window_visible_verified':True,'events':events,'no_new_split_or_merge':True,
      'native_merge_automatic_selection_cause_proven':False,
      'time_advanced':False,'dynamic_qualified':False,'human_signoff':False,'R09_full_card_closed':False}
    return write(r.case/'SURVIVOR-UI.actual-a05.json',receipt)

def film(path,review_pin):
    c=configured(path);scene=Path(c['scene_root']);proof=load(c['runtime_proof']);review=load(review_pin)
    need(review.get('machine_id')==MACHINE and review.get('run_id')==c['run_id'] and review.get('source_head')==c['source_head']
         and review.get('current_ck3_foreground') is True and review.get('paused_visible') is True and review.get('selected_army_id')==93
         and 0<=(now()-datetime.fromisoformat(review['observed_at_utc'].replace('Z','+00:00'))).total_seconds()<=180,'fresh Root reviewed paused93 original required')
    rect=review['client_screen_rect'];need([rect[2]-rect[0],rect[3]-rect[1]]==[1280,720],'reviewed client not1280x720')
    need(same(pin(review['screenshot']['path'],32*1024*1024),review['screenshot']),'reviewed screenshot changed')
    baseline_ready=read(scene/'r09-root-controller-a01/BASELINE-READY.actual.json')
    need(baseline_ready.get('selected_special_raw1381_confirmed') is True and same(baseline_ready.get('controller_input'),pin(path)),
      'same controller has no accepted current special baseline; do not split')
    base=load(baseline_ready['F0']);need(base['normal_save_sha256']==SAVE['sha256'],'F0 source differs')
    guard=module(GUARD,'r09_film_guard');context=load(c['context']);op=guard.OperationGuard(c['live_binding']['path'],c['live_binding']['sha256'],
      context=context,runtime=guard.proof_runtime(proof),scene_root=scene,source_head=c['source_head'],machine_id=MACHINE,
      run_id=c['run_id'],max_runtime_total_bytes=c['max_runtime_total_bytes'],normal_save_sha256=SAVE['sha256'])
    m=module(RELAY,'r09_film_relay');need(m.process_time(proof['pid'])==proof['process_creation_filetime_100ns'],'actual process lifetime differs')
    # Rehash/check baseline references and FFmpeg before recorder, never after start.
    baseline_saved=read(scene/'r09-split-merge-relay-a01'/c['case_id']/'baseline.actual.json',2*1024*1024)
    need(same(m.driver_raw_pin(baseline_saved['packet']['refs']['strength_raw']['path']),baseline_saved['packet']['refs']['strength_raw']),'F0 complete raw changed')
    need(same(pin(c['ffmpeg']['path'],256*1024*1024),c['ffmpeg']),'FFmpeg changed')
    transport=module(c['request_helper']['path'],'r09_film_transport');prefix=c['case_id']+'-record';raw=scene/c['raw_directory_name']
    need(not raw.exists(),'fresh raw directory required')
    claim=scene/'r09-root-controller-a01/record.once.claim.json';write(claim,{'machine_id':MACHINE,'at_utc':now().isoformat(),'config':pin(path),
      'frame_review':review_pin,'normal_save_sha256':SAVE['sha256'],'start_replay_forbidden':True})
    timeline=[];started=None;primary=None;result={'machine_id':MACHINE,'source_head':c['source_head'],'run_id':c['run_id'],'SDK_controller_exclusive':True,
      'time_advanced':False,'dynamic_qualified':False,'human_signoff':False,'R09_full_card_closed':False}
    def request(label,tool,args,timeout=30):
        op.check();need(m.process_time(proof['pid'])==proof['process_creation_filetime_100ns'],'owned PID changed')
        row=transport.request(prefix+'-'+label,tool,args,timeout=timeout)
        need(row.get('machine_id')==MACHINE and row.get('is_error') is False,'original relay error; never replay '+label);return row['body']
    try:
        ready=request('start-once','gameplay_recorder',{'operation':'start','workdir':str(raw),'ffmpeg':c['ffmpeg']['path'],
          'ffmpeg_sha256':c['ffmpeg']['sha256'],'target_pid':proof['pid'],'source_image':review['screenshot']['path'],'seconds':c['seconds']},30)
        need(ready.get('state')=='RECORDING' and type(ready.get('monotonic_ns')) is int,'recorder readiness absent')
        started=ready['monotonic_ns'];capture=ready['capture_source'];bounds=capture['client_screen_rect']
        need([bounds[2]-bounds[0],bounds[3]-bounds[1]]==[1280,720],'actual capture source not1280client')
        argv=ready['argv'];need(argv[argv.index('-framerate')+1]=='30' and argv[argv.index('-video_size')+1]=='1280x720','actual recorder format differs')
        for name in ('split-once','post-split','merge-once','post-merge'):
            op.check();elapsed=(time.monotonic_ns()-started)/1e9
            need(elapsed<c['seconds']-10,'recording tail insufficient; preserve partial arm without new action')
            before=time.monotonic_ns();last_relay=stage(c,name);after=time.monotonic_ns()
            timeline.append({'stage':name,'from_start_seconds':[(before-started)/1e9,(after-started)/1e9]})
        result['action_and_endpoint_chain_complete']=True
        result['survivor_UI']=ensure_survivor_ui(last_relay,m,started=started,seconds=c['seconds'],timeline=timeline)
        result['survivor_UI_visible_verified']=True
        # Finish at the admitted wall duration. Any paused tail stays labelled.
        while (time.monotonic_ns()-started)/1e9<c['seconds']-1:op.check();time.sleep(.5)
    except BaseException as error:
        primary=error;result['error']=repr(error)
    finally:
        result['timeline']=timeline;result['record_started_monotonic_ns']=started;result['completed_at_utc']=now().isoformat()
        primary=finish_and_preserve(result,primary,
          finish=lambda:finish_owned_recorder_once(transport,prefix=prefix,proof=proof,process_probe=m.process_time),
          persist=lambda value:write(scene/'r09-root-controller-a01/FILM-CONTROLLER.actual.json',value))
    if primary:raise primary
    # Complete saved endpoints and formula replay after recording, no new query.
    ep1=endpoint(c,'post-split');ep2=endpoint(c,'post-merge');stage(c,'supply-clamp')
    print(json.dumps({'post_split':ep1,'post_merge':ep2,'next':'Root normal save/stock UI exit/process_exit0/screen release now; no automatic launch or close here'}))
def compare(a,b):
    ca=configured(a);cb=configured(b);need(ca['direction']=='source' and cb['direction']=='sibling','forward then reverse configs required')
    need(ca['run_id']!=cb['run_id'],'independent allocated cold-load arms required')
    pa=read(Path(ca['scene_root'])/'r09-root-controller-a01/baseline-ENDPOINT.actual.json')
    pb=read(Path(cb['scene_root'])/'r09-root-controller-a01/baseline-ENDPOINT.actual.json')
    fa,fb=load(ca['runtime_proof']),load(cb['runtime_proof'])
    need((fa['pid'],fa['process_creation_filetime_100ns'])!=(fb['pid'],fb['process_creation_filetime_100ns']),'same process is not independent cold load')
    need(pa['normal_save_sha256']==pb['normal_save_sha256']==SAVE['sha256'] and pa['frozen_observable']==pb['frozen_observable'],
      'two new F0 observable baselines differ; never substitute old forward')
    print(json.dumps({'same_normal_S0_and_F0_observable':True,'forward_run':ca['run_id'],'reverse_run':cb['run_id'],
      'new_business_or_dynamic_qualification':False,'next':'Independent F1/F2, supply formulas, exact raw review/clean remain separate'}))
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('stage',choices=('source','prepare','baseline','film','compare'))
    p.add_argument('--config',type=Path);p.add_argument('--frame-review',nargs=3);p.add_argument('--reverse-config',type=Path);p.add_argument('--execute-live',action='store_true')
    p.add_argument('--source-head',help='source-only exact current40hex HEAD; other stages consume config.source_head')
    a=p.parse_args()
    if a.stage=='source':source(a.source_head)
    elif a.stage=='prepare':prepare(a.config)
    elif a.stage=='compare':compare(a.config,a.reverse_config)
    else:
        need(a.execute_live,'only Root may explicitly execute already owned normal relay')
        if a.stage=='baseline':baseline(a.config)
        else:
            need(a.frame_review,'fresh exact reviewed frame pin required')
            film(a.config,{'path':a.frame_review[0],'bytes':int(a.frame_review[1]),'sha256':a.frame_review[2]})
if __name__=='__main__':main()
