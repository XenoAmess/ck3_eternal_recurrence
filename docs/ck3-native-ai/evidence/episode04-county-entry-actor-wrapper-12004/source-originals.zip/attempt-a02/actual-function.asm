; machine_id: desktop-3fevhd2-1c74096080
; actual1.20.0.4 98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518
02C09DF0 40 53                            push     rbx
02C09DF2 48 83 ec 20                      sub      rsp, 0x20
02C09DF6 81 ba e0 03 00 00 61 44 6f 43    cmp      dword ptr [rdx + 0x3e0], 0x436f4461
02C09E00 48 8b d9                         mov      rbx, rcx
02C09E03 75 66                            jne      0x2c09e6b
02C09E05 48 8b 05 ec 3c 11 03             mov      rax, qword ptr [rip + 0x3113cec]
02C09E0C 48 85 c0                         test     rax, rax
02C09E0F 74 29                            je       0x2c09e3a
02C09E11 44 8b 42 18                      mov      r8d, dword ptr [rdx + 0x18]
02C09E15 41 8b c8                         mov      ecx, r8d
02C09E18 81 e1 ff ff ff 00                and      ecx, 0xffffff
02C09E1E 3b 48 2c                         cmp      ecx, dword ptr [rax + 0x2c]
02C09E21 73 17                            jae      0x2c09e3a
02C09E23 48 8b 40 20                      mov      rax, qword ptr [rax + 0x20]
02C09E27 48 03 c9                         add      rcx, rcx
02C09E2A 48 8b 44 c8 08                   mov      rax, qword ptr [rax + rcx*8 + 8]
02C09E2F 48 85 c0                         test     rax, rax
02C09E32 74 06                            je       0x2c09e3a
02C09E34 44 39 40 10                      cmp      dword ptr [rax + 0x10], r8d
02C09E38 74 07                            je       0x2c09e41
02C09E3A 48 8b 05 9f 3c 11 03             mov      rax, qword ptr [rip + 0x3113c9f]
02C09E41 81 78 14 64 6e 61 4c             cmp      dword ptr [rax + 0x14], 0x4c616e64
02C09E48 75 21                            jne      0x2c09e6b
02C09E4A 83 78 10 ff                      cmp      dword ptr [rax + 0x10], -1
02C09E4E 74 1b                            je       0x2c09e6b
02C09E50 48 8b ca                         mov      rcx, rdx
02C09E53 e8 78 b0 8c ff                   call     0x24d4ed0
02C09E58 45 33 c0                         xor      r8d, r8d
02C09E5B 48 8b d3                         mov      rdx, rbx
02C09E5E 48 8b c8                         mov      rcx, rax
02C09E61 48 83 c4 20                      add      rsp, 0x20
02C09E65 5b                               pop      rbx
02C09E66 e9 b5 f7 ff ff                   jmp      0x2c09620
02C09E6B 32 c0                            xor      al, al
02C09E6D 48 83 c4 20                      add      rsp, 0x20
02C09E71 5b                               pop      rbx
02C09E72 c3                               ret      
