"""Only existing metadata rows: expose exact continuation extents, no EXE read."""
from pathlib import Path
import json,struct
H=Path(__file__).parent
r=json.loads((H/'CAPTURE.physical.actual.json').read_bytes())
out=[]
for x in r['read_ledger']:
    if x['kind']=='metadata' and x['bytes']==12:
        b,e,u=struct.unpack('<III',bytes.fromhex(x['hex']))
        if b<=0x29592b1<e or b<=0x2959214<e or b==0x29591e0:
            out.append(dict(begin_rva=f'{b:X}',end_exclusive=f'{e:X}',unwind_rva=f'{u:X}',bytes=e-b,metadata_source_rva=x['rva'],raw_hex=x['hex']))
print(json.dumps(dict(machine_id=r['machine_id'],existing_rows_for_continuation=out,new_EXE_bytes=0)))
