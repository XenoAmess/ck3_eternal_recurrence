"""Approved one2KiB body: metadata binary-search only; no callee expansion."""
from pathlib import Path
from datetime import datetime,timezone
import capstone,gzip,hashlib,json,struct,sys,time
from capstone.x86 import X86_OP_IMM
H=Path(__file__).parent
E=Path('C:/SteamLibrary/steamapps/common/Crusader Kings III/binaries/ck3.exe')
def need(ok,msg):
    if not ok:raise ValueError(msg)
def load(n):return json.loads((H/n).read_bytes())
def write(n,o):
    with (H/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(o,f,indent=2);f.write('\n')
def stamp():
    s=E.stat();return dict(bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,device=s.st_dev,inode=s.st_ino)
checks=load('CHECK-RENDER.before-read.corrected-a03.actual.json');plan=load('PLAN.before-read.corrected-a03.json')
need(all(x['exit_code']==0 for x in checks['results']),'Ordinarycheck/render first')
need(hashlib.sha256((H/'PLAN.before-read.corrected-a03.json').read_bytes()).hexdigest()==checks['plan_sha256'],'Plan pin')
layout=load('PE-MAP.held.actual.json');identity=load('IDENTITY.reused.actual.json')
need(identity['sha256']==layout['exe_sha256_reused']==plan['build']['exe_sha256'],'Exact image pin')
before=stamp();need(before==identity['stat_before']==identity['stat_after']==layout['current_observed_stat'],'Actual native file identity')
ledger=[];metadata=0;code=0;start=time.monotonic();target=0x29591e0
try:
    with E.open('rb') as f:
        def read(rva,count,kind):
            global metadata,code
            need(len(ledger)<48 and time.monotonic()-start<30,'Read/time limit')
            if kind=='metadata':need(metadata+count<=512,'Metadata limit');metadata+=count
            else:need(code+count<=2048,'Code limit');code+=count
            ss=[s for s in layout['sections'] if s['rva']<=rva<rva+count<=s['rva']+s['raw_size']];need(len(ss)==1,'One mapped raw section')
            off=ss[0]['raw_offset']+rva-ss[0]['rva'];f.seek(off);b=f.read(count);need(len(b)==count,'Short read')
            ledger.append(dict(rva=rva,file_offset=off,bytes=count,kind=kind,hex=b.hex() if kind=='metadata' else None,sha256=hashlib.sha256(b).hexdigest()))
            return b
        ex=layout['exception_directory'];rows={}
        def row(index):
            need(0<=index<ex['entries'],'Pdata index')
            if index not in rows:rows[index]=struct.unpack('<III',read(ex['rva']+index*12,12,'metadata'))
            return rows[index]
        lo,hi=0,ex['entries']
        while lo<hi:
            mid=(lo+hi)//2
            if row(mid)[0]<=target:lo=mid+1
            else:hi=mid
        index=lo-1;begin,end,unwind=row(index)
        need(begin==target and target<end,'Unique entry-aligned targetextent required')
        h=read(unwind,4,'metadata');flags=h[0]>>3;chain=None
        if flags&4:chain=struct.unpack('<III',read(unwind+4+((h[2]+1)//2)*4,12,'metadata'))
        extent=dict(begin_rva=begin,end_exclusive=end,bytes=end-begin,pdata_index=index,unwind_rva=unwind,flags=flags,chained_runtime_function=chain)
        write('EXTENT.actual.json',dict(machine_id=plan['machine_id'],at_utc=datetime.now(timezone.utc).isoformat(),extent=extent,metadata_bytes=metadata,read_calls=len(ledger),code_bytes=0,read_ledger=ledger,stat_before=before,stat_after=stamp()))
        need(chain is None,'Chained extent: stop, no prefix asfullbody')
        need(0<end-begin<=2048,'Body exceeds2KiB; stop beforecode')
        body=read(begin,end-begin,'code')
        with (H/'function.bin').open('xb') as o:o.write(body)
    need(stamp()==before,'Actual native image changed')
    write('CAPTURE.physical.actual.json',dict(machine_id=plan['machine_id'],at_utc=datetime.now(timezone.utc).isoformat(),exe_sha256_reused=identity['sha256'],stat_before=before,stat_after=stamp(),extent=extent,read_ledger=ledger,code_bytes=code,metadata_bytes=metadata,read_calls=len(ledger),raw_sha256=hashlib.sha256(body).hexdigest(),whole_EXE_hashes=0,callee_reads=0))
    dis=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64);dis.detail=True;ins=list(dis.disasm(body,begin))
    need(sum(i.size for i in ins)==len(body),'Complete entry-rooted decode')
    asm='\n'.join(f'{i.address:08X}  {i.bytes.hex(" "):<44} {i.mnemonic} {i.op_str}' for i in ins)+'\n'
    with (H/'function.asm.gz').open('xb') as o:o.write(gzip.compress(asm.encode(),mtime=0))
    direct=[];branches=[]
    starts={i.address for i in ins}
    for i in ins:
        if i.mnemonic=='call' and i.operands and i.operands[0].type==X86_OP_IMM:direct.append(dict(at_rva=i.address,target_rva=i.operands[0].imm,hex=i.bytes.hex()))
        if i.group(capstone.CS_GRP_JUMP) and i.operands and i.operands[0].type==X86_OP_IMM:
            to=i.operands[0].imm;branches.append(dict(at_rva=i.address,target_rva=to,hex=i.bytes.hex(),target_in_ownbody=to in starts))
    write('DECODE.actual.json',dict(machine_id=plan['machine_id'],at_utc=datetime.now(timezone.utc).isoformat(),capstone_version=capstone.__version__,extent=extent,instruction_count=len(ins),complete_bytes_decoded=len(body),direct_calls=direct,branches=branches,RET_RVAs=[i.address for i in ins if i.mnemonic=='ret'],external_jumps=[b for b in branches if not b['target_in_ownbody']],raw_sha256=hashlib.sha256(body).hexdigest(),assembly_sha256=hashlib.sha256(asm.encode()).hexdigest(),proof_layer='Exact bodybytes+entry-rooted disassembly; semantics not yet sealed',paid_military_amount_raw=None,payer=None,cadence=None))
    print(json.dumps(dict(extent=extent,code=code,metadata=metadata,reads=len(ledger),instructions=len(ins),direct_calls=direct,external_jumps=[b for b in branches if not b['target_in_ownbody']],package_bytes=sum(p.stat().st_size for p in H.iterdir() if p.is_file()))))
except Exception as e:
    write('STOPPED.actual.json',dict(machine_id=plan['machine_id'],at_utc=datetime.now(timezone.utc).isoformat(),error=repr(e),ledger=ledger,code_bytes=code,metadata_bytes=metadata,read_calls=len(ledger),no_further_reads=True,scope_not_expanded=True))
    raise
