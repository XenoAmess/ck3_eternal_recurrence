"""Held-source intake and ordinary static plan; no EXE access."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,shutil,struct,subprocess,sys,zipfile
R=Path('D:/workspace/ck3_eternal_recurrence');H=Path(__file__).parent
sys.path.insert(0,str(R/'tools'))
from ck3_live_run_id import current_machine_id
def need(ok,msg):
    if not ok:raise ValueError(msg)
def pin(p):
    p=Path(p);b=p.read_bytes();return dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(name,obj):
    with (H/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,indent=2);f.write('\n')
machine=current_machine_id();now=datetime.now(timezone.utc).isoformat();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
zpath=R/'docs/ck3-native-ai/acceptance/2026-10-16-r0178-maintenance-writers/originals.zip'
with zipfile.ZipFile(zpath) as z:
    body=z.read('function/actual-function.bin');asm=z.read('function/actual-function.asm')
need(len(body)==695 and hashlib.sha256(body).hexdigest()=='ffebf7d960edb76b71d2456b7f8722cc09092952b41c565f648410b42a47dede','Caller raw pin')
rows=[]
for line in asm.decode('utf-8').splitlines():
    m=re.fullmatch(r'([0-9A-Fa-f]{8})\s+((?:[0-9A-Fa-f]{2} )*[0-9A-Fa-f]{2})\s+(.*)',line)
    if m:rows.append(dict(rva=int(m[1],16),hex=m[2].replace(' ',''),asm=m[3]))
need(len(rows)==147 and b''.join(bytes.fromhex(x['hex']) for x in rows)==body,'Caller complete saved ASM bytes')
need(body[0x28A65BE-0x28A63E0:0x28A65BE-0x28A63E0+5].hex()=='e81d2c0b00','Actual direct CALL bytes')
need(0x28A65BE+5+int.from_bytes(bytes.fromhex('1d2c0b00'),'little',signed=True)==0x29591E0,'Actual CALL target')
with (H/'caller28A63E0.bin').open('xb') as f:f.write(body)
with (H/'caller28A63E0.asm').open('xb') as f:f.write(asm)
write('CALLER.held.actual.json',dict(machine_id=machine,observed_at_utc=now,source_head=head,canonical_source=str(zpath.relative_to(R)),source_zip_pin=pin(zpath),source_zip_git_blob=subprocess.check_output(['git','hash-object','--',str(zpath)],cwd=R,text=True).strip(),raw_pin=pin(H/'caller28A63E0.bin'),asm_pin=pin(H/'caller28A63E0.asm'),begin_rva=0x28A63E0,end_exclusive=0x28A6697,rows=rows,
    selected_call=dict(at_rva=0x28A65BE,target_rva=0x29591E0,bytes='e81d2c0b00',RCX='RBX=*(Character+1C0), held at28A653A',RDX='&local descriptor[RSP20], initialized via indirect calls28A6592/28A65B2',consumer='Caller iterates returned8B pointer slots, invokes2468AC0, copies returnedfirstQWORD to entryRDX-derived indexed destination'),
    causal_boundary='All selected calls occur after the two+18->2C0/+20->2C8 stores. A later write cannot produce an earlier value in this same invocation. Cross-invocation effects and aliasing remain open.',new_EXE_bytes=0,runtime_call_proved=False))
lp=Path('C:/ck3-e04-resume-20261015-a01/r08-resource4-enum-literal-locator-a01/LITERALS.actual.json');l=json.loads(lp.read_bytes())
need(pin(lp)['sha256']=='af76ea5a7e69ea52048dc6ed80e6c78de7244e19ed02346a8f095cf378e47121','Held PE source pin')
opt=bytes.fromhex(l['read_ledger'][2]['raw_hex']);exrva,exbytes=struct.unpack_from('<II',opt,112+3*8)
need(exrva==98316288 and exbytes==2933220 and exbytes%12==0,'Held exception directory')
write('PE-MAP.held.actual.json',dict(machine_id=machine,at_utc=now,provenance=pin(lp),image_base=l['image_base_preferred'],sections=l['sections'],exception_directory=dict(rva=exrva,bytes=exbytes,entries=exbytes//12),current_observed_stat=l['stat_before'],exe_sha256_reused=l['exe_sha256_reused']))
ip=Path('C:/ck3-e04-resume-20261015-a01/r08-payment-scalar-2bd3320-a01/CURRENT-EXE-IDENTITY.actual.json');ib=ip.read_bytes()
need(hashlib.sha256(ib).hexdigest()=='47ff2b7951cc37faf49cd2773382306ea3256aba597a29406f5ff3fc8c3356e9','Qualified identity receipt')
with (H/'IDENTITY.reused.actual.json').open('xb') as f:f.write(ib)
du=shutil.disk_usage(H);write('START-CAPACITY.actual.json',dict(machine_id=machine,at_utc=now,policy_version='1.0.0',source='Current Root task grants this small96KiB lane within existing shared128MiB pool; historical R188 capacity deadline not extended by this receipt',total_bytes=du.total,free_bytes=du.free,write_ceiling_bytes=98304,shared_pool_bytes=134217728,heavy_write=False,automatic_global_reservation_claimed=False,delete_actions=0,review_after_hours=168))
sha=l['exe_sha256_reused']
plan=dict(schema='xar.native-research-plan.v1',topic='e04-R08-context-owner-29591E0',machine_id=machine,created_at_utc=now,question='Does actual context-taking callee29591E0 write the four source fields18/20/28/30, expose their owner, or only enumerate cache entries?',purpose='engine-transition',build=dict(version='1.20.0.4/Steam25734779',exe_sha256=sha),
 observation=dict(mode='offline-only',actor_kind='engine',owner_scope='Root-approved one exact29591E0 body<=2048B, metadata<=512B/read48; no other callee or global scan',identity_kind='definition-key',identity_lifetime='Exact static build only, no live identity or payer qualification',producer_trigger='not-applicable',producer='Candidate context-taking native function29591E0; writer/owner role unknown before read',caller='Held full695B28A63E0 actual sourceCALL28A65BE',consumer='Caller iterates outputpointerarray then2468AC0 values->entryRDX indexed output, not confirmed wallet',cache_lifetime='Static body; refresh/invalidation/cadence unknown',expected_signal='Full unique ordinary functionextent and receiver dataflow; direct18/20/28/30 writes or bounded enumeration semantics',zero_sample_meaning='No direct fixedreceiver store means own-body fact only; aliases/callees remain unknown; no zero cost inference',stop_condition='One full unchained extent<=2048B or stop beforecode; metadata<=512B/read48; output<=98304B; no2468AC0/25FB1D0/callee reads,SDK,game,desktop,build,mainwrite',runtime_window_ref=None),
 evidence=[dict(id='caller',layer='instruction-cache',path='CALLER.held.actual.json',sha256=pin(H/'CALLER.held.actual.json')['sha256'],exe_sha256=sha,supports='Actual sourceCALL and same context receiver, source+18/+20 snapshots precede it'),dict(id='map',layer='locator',path='PE-MAP.held.actual.json',sha256=pin(H/'PE-MAP.held.actual.json')['sha256'],exe_sha256=sha,supports='Held PE section map and exception directory; no new sweep')],
 nodes=[dict(id='ctx',label='C=Character1C0; raw18/20/28/30'),dict(id='copy',label='28A6454/645F copies18->2C0,20->2C8'),dict(id='next',label='28A65BE calls29591E0(C,&localDescriptor)'),dict(id='list',label='local8Bpointerarray->2468AC0->indexedoutput'),dict(id='settlement',label='Separate28A6D10 consumes2C0/2C8/28/30'),dict(id='wallet',label='Same-invocation military paid/payer/cadenceUNKNOWN')],
 edges=[dict(id='copy-edge',**{'from':'ctx','to':'copy'},label='Held raw source copies only',status='known',evidence=['caller']),dict(id='caller-edge',**{'from':'copy','to':'next'},label='Later conditional call in same function, not runtime proof',status='known',evidence=['caller']),dict(id='output',**{'from':'next','to':'list'},label='Candidate output consumed by caller; business role unknown',status='known',evidence=['caller']),dict(id='producer',**{'from':'next','to':'ctx'},label='Does bodywrite raw fields or revealowner?',status='unknown',evidence=['caller'],open_question='Only this callee extent will be read'),dict(id='apply',**{'from':'ctx','to':'settlement'},label='Consumer known separately, current producer linkage unknown',status='unknown',evidence=['caller'],open_question='No same refresh/application invocation proved'),dict(id='paid',**{'from':'settlement','to':'wallet'},label='Militarycategory+sameapplication+payer+cadence remain unknown',status='unknown',evidence=['caller'],open_question='No rate/cache->paid upgrade')],
 cases=[dict(id='static',question='One context-owner candidatebody',status='pending',evidence=['caller']),dict(id='live',question='Actualpaid/payer/cadence',status='not-applicable',evidence=[],reason='No runtime actionauthorized in this lane')])
write('PLAN.before-read.json',plan);out=[]
for cmd in ('check','render'):
    argv=[sys.executable,'-B',str(R/'tools/native_research_plan.py'),cmd,str(H/'PLAN.before-read.json')]
    if cmd=='render':argv+=['--output',str(H/'GRAPH.before-read.md')]
    r=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8');out.append(dict(argv=argv,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));need(r.returncode==0,'Ordinary plan '+cmd)
write('CHECK-RENDER.before-read.actual.json',dict(machine_id=machine,at_utc=datetime.now(timezone.utc).isoformat(),plan=pin(H/'PLAN.before-read.json'),results=out,new_EXE_bytes=0))
print(json.dumps(dict(ordinary_check_render=True,package_bytes=sum(p.stat().st_size for p in H.iterdir() if p.is_file()),new_EXE_bytes=0,callsite='28A65BE',target='29591E0')))
