"""Preserve a02 schema rejection; static-confirmed source edges, no EXE access."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
H=Path(__file__).parent;R=Path('D:/workspace/ck3_eternal_recurrence')
def write(n,o):
    with (H/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(o,f,indent=2);f.write('\n')
old=H/'PLAN.before-read.corrected-a02.json';p=json.loads(old.read_bytes())
argv=[sys.executable,'-B',str(R/'tools/native_research_plan.py'),'check',str(old)]
r=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8')
write('PLAN-CHECK.rejected-a02.actual.json',dict(machine_id=p['machine_id'],at_utc=datetime.now(timezone.utc).isoformat(),argv=argv,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr,new_EXE_bytes=0))
if r.returncode!=2:raise ValueError('Unexpected prior result')
for e in p['edges']:
    if e['status']=='known':e['status']='static-confirmed'
p['created_at_utc']=datetime.now(timezone.utc).isoformat()
write('PLAN.before-read.corrected-a03.json',p)
out=[]
for cmd in ('check','render'):
    argv=[sys.executable,'-B',str(R/'tools/native_research_plan.py'),cmd,str(H/'PLAN.before-read.corrected-a03.json')]
    if cmd=='render':argv+=['--output',str(H/'GRAPH.before-read.corrected-a03.md')]
    r=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8');out.append(dict(argv=argv,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
    if r.returncode:raise ValueError(r.stderr or r.stdout)
write('CHECK-RENDER.before-read.corrected-a03.actual.json',dict(machine_id=p['machine_id'],at_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=hashlib.sha256((H/'PLAN.before-read.corrected-a03.json').read_bytes()).hexdigest(),results=out,new_EXE_bytes=0))
print(json.dumps(dict(check_render=True,new_EXE_bytes=0,package_bytes=sum(p.stat().st_size for p in H.iterdir() if p.is_file()))))
