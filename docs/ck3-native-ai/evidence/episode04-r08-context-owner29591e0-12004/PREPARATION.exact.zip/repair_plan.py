"""Preserve rejected layer enum; correct source-contract, no EXE access."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
H=Path(__file__).parent;R=Path('D:/workspace/ck3_eternal_recurrence')
def pin(p):
    b=p.read_bytes();return dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(n,o):
    with (H/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(o,f,indent=2);f.write('\n')
old=H/'PLAN.before-read.json';p=json.loads(old.read_bytes())
argv=[sys.executable,'-B',str(R/'tools/native_research_plan.py'),'check',str(old)]
r=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8')
write('PLAN-CHECK.rejected-a01.actual.json',dict(machine_id=p['machine_id'],at_utc=datetime.now(timezone.utc).isoformat(),plan=pin(old),argv=argv,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr,new_EXE_bytes=0,reason='Caller layer instruction-cache is not an allowed schema value; actual held source belongs to source-contract. Original rejected plan preserved.'))
if r.returncode!=2:raise ValueError('Unexpected first failure outcome')
p['evidence'][0]['layer']='source-contract';p['created_at_utc']=datetime.now(timezone.utc).isoformat()
write('PLAN.before-read.corrected-a02.json',p)
out=[]
for cmd in ('check','render'):
    argv=[sys.executable,'-B',str(R/'tools/native_research_plan.py'),cmd,str(H/'PLAN.before-read.corrected-a02.json')]
    if cmd=='render':argv+=['--output',str(H/'GRAPH.before-read.corrected-a02.md')]
    r=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8');out.append(dict(argv=argv,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
    if r.returncode:raise ValueError(r.stderr or r.stdout)
write('CHECK-RENDER.before-read.corrected-a02.actual.json',dict(machine_id=p['machine_id'],at_utc=datetime.now(timezone.utc).isoformat(),plan=pin(H/'PLAN.before-read.corrected-a02.json'),results=out,new_EXE_bytes=0))
print(json.dumps(dict(ordinary_check_render=True,new_EXE_bytes=0,plan=pin(H/'PLAN.before-read.corrected-a02.json'))))
