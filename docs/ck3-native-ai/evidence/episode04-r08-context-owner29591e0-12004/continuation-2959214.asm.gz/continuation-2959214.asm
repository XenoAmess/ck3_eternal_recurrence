02959214  48 89 74 24 38                               mov qword ptr [rsp + 0x38], rsi
02959219  48 8b 35 c0 48 3c 03                         mov rsi, qword ptr [rip + 0x33c48c0]
02959220  4d 85 db                                     test r11, r11
02959223  74 26                                        je 0x295924b
02959225  8b 0b                                        mov ecx, dword ptr [rbx]
02959227  8b c1                                        mov eax, ecx
02959229  25 ff ff ff 00                               and eax, 0xffffff
0295922E  41 3b 43 2c                                  cmp eax, dword ptr [r11 + 0x2c]
02959232  73 17                                        jae 0x295924b
02959234  4d 8b 53 20                                  mov r10, qword ptr [r11 + 0x20]
02959238  48 03 c0                                     add rax, rax
0295923B  4d 8b 54 c2 08                               mov r10, qword ptr [r10 + rax*8 + 8]
02959240  4d 85 d2                                     test r10, r10
02959243  74 06                                        je 0x295924b
02959245  41 39 4a 10                                  cmp dword ptr [r10 + 0x10], ecx
02959249  74 03                                        je 0x295924e
0295924B  4c 8b d6                                     mov r10, rsi
0295924E  49 8b ca                                     mov rcx, r10
02959251  e8 8a 66 9b ff                               call 0x230f8e0
02959256  81 b8 5c 08 00 00 76 6f 72 50                cmp dword ptr [rax + 0x85c], 0x50726f76
02959260  75 3d                                        jne 0x295929f
02959262  49 8b 42 48                                  mov rax, qword ptr [r10 + 0x48]
02959266  83 78 64 01                                  cmp dword ptr [rax + 0x64], 1
0295926A  7f 33                                        jg 0x295929f
0295926C  49 8b 82 38 03 00 00                         mov rax, qword ptr [r10 + 0x338]
02959273  48 05 20 06 00 00                            add rax, 0x620
02959279  80 78 08 00                                  cmp byte ptr [rax + 8], 0
0295927D  74 20                                        je 0x295929f
0295927F  48 8d 54 24 30                               lea rdx, [rsp + 0x30]
02959284  48 89 44 24 30                               mov qword ptr [rsp + 0x30], rax
02959289  48 8b cd                                     mov rcx, rbp
0295928C  e8 af 70 f2 fd                               call 0x880340
02959291  4c 8b 1d 60 48 3c 03                         mov r11, qword ptr [rip + 0x33c4860]
02959298  48 8b 35 41 48 3c 03                         mov rsi, qword ptr [rip + 0x33c4841]
0295929F  48 83 c3 04                                  add rbx, 4
029592A3  48 3b df                                     cmp rbx, rdi
029592A6  0f 85 74 ff ff ff                            jne 0x2959220
029592AC  48 8b 74 24 38                               mov rsi, qword ptr [rsp + 0x38]
