# Research plan: e04-R08-context-owner-29591E0

GENERATED from the supplied research plan; no native semantics are inferred.

Question: Does actual context-taking callee29591E0 write the four source fields18/20/28/30, expose their owner, or only enumerate cache entries?

```mermaid
flowchart TD
    n0["C=Character1C0; raw18/20/28/30"]
    n1["28A6454/645F copies18-&gt;2C0,20-&gt;2C8"]
    n2["28A65BE calls29591E0(C,&amp;localDescriptor)"]
    n3["local8Bpointerarray-&gt;2468AC0-&gt;indexedoutput"]
    n4["Separate28A6D10 consumes2C0/2C8/28/30"]
    n5["Same-invocation military paid/payer/cadenceUNKNOWN"]
    n0 -->|"copy-edge [static-confirmed] Held raw source copies only"| n1
    n1 -->|"caller-edge [static-confirmed] Later conditional call in same function, not runtime proof"| n2
    n2 -->|"output [static-confirmed] Candidate output consumed by caller; business role unknown"| n3
    n2 -. "producer [unknown] Does bodywrite raw fields or revealowner?" .-> n0
    n0 -. "apply [unknown] Consumer known separately, current producer linkage unknown" .-> n4
    n4 -. "paid [unknown] Militarycategory+sameapplication+payer+cadence remain unknown" .-> n5
```

| Edge | Declared status | Evidence IDs | Open question |
|---|---|---|---|
| copy-edge | static-confirmed | caller |  |
| caller-edge | static-confirmed | caller |  |
| output | static-confirmed | caller |  |
| producer | unknown | caller | Only this callee extent will be read |
| apply | unknown | caller | No same refresh/application invocation proved |
| paid | unknown | caller | No rate/cache-&gt;paid upgrade |

| Observation design | Value |
|---|---|
| mode | offline-only |
| actor_kind | engine |
| owner_scope | Root-approved one exact29591E0 body&lt;=2048B, metadata&lt;=512B/read48; no other callee or global scan |
| identity_kind | definition-key |
| identity_lifetime | Exact static build only, no live identity or payer qualification |
| producer_trigger | not-applicable |
| producer | Candidate context-taking native function29591E0; writer/owner role unknown before read |
| caller | Held full695B28A63E0 actual sourceCALL28A65BE |
| consumer | Caller iterates outputpointerarray then2468AC0 values-&gt;entryRDX indexed output, not confirmed wallet |
| cache_lifetime | Static body; refresh/invalidation/cadence unknown |
| expected_signal | Full unique ordinary functionextent and receiver dataflow; direct18/20/28/30 writes or bounded enumeration semantics |
| zero_sample_meaning | No direct fixedreceiver store means own-body fact only; aliases/callees remain unknown; no zero cost inference |
| stop_condition | One full unchained extent&lt;=2048B or stop beforecode; metadata&lt;=512B/read48; output&lt;=98304B; no2468AC0/25FB1D0/callee reads,SDK,game,desktop,build,mainwrite |
| runtime_window_ref | None |

| Evidence ID | Declared layer | File | SHA-256 | Supports |
|---|---|---|---|---|
| caller | source-contract | CALLER.held.actual.json | 6d3999ba41fef0deeb08027d631082974dcec3e3cb9808d593d2e7d999d5c758 | Actual sourceCALL and same context receiver, source+18/+20 snapshots precede it |
| map | locator | PE-MAP.held.actual.json | 283930c9f99cd6522f350545f224b1bce3b4aaf3ecddd34ff8de83b5fc47670a | Held PE section map and exception directory; no new sweep |

Check result (file integrity and declarations only):

```json
{
  "schema": "xar.native-research-plan-check.v1",
  "result": "plan-consistent",
  "proof_layer": "record-structure-and-file-integrity",
  "semantic_correctness_verified": false,
  "live_execution_performed": false,
  "observation_plan_issues": [
    "offline-only plan does not define a live observation window",
    "the real producer trigger must be located before live sampling"
  ],
  "declared_edges_by_status": {
    "counter-policy": 0,
    "inference": 0,
    "live-confirmed": 0,
    "static-confirmed": 3,
    "unknown": 3
  },
  "enumerated_native_edges": 6,
  "declared_cases_by_status": {
    "pending": 1,
    "observed": 0,
    "not-applicable": 1
  },
  "checked_evidence_files": 2,
  "limitations": [
    "Evidence layers and conclusions are author declarations; hashes bind bytes, not their truth.",
    "Counts cover this enumerated graph only, not all CK3 branches.",
    "A consistent observation plan is not authorization to run or manipulate CK3."
  ],
  "plan_sha256": "98b7cf6ca8ede0711bef9efeeb23938c4d8ff130644dd4419b8a0bf2a14f122e"
}
```
