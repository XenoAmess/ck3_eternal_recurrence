"""Seal bounded owner candidate and typed causal boundary; no new EXE reads."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json,shutil,subprocess,sys,zipfile
H=Path(__file__).parent
def pin(p):
    b=p.read_bytes();return dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(n,o):
    with (H/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(o,f,indent=2);f.write('\n')
with zipfile.ZipFile(H/'CALLER-DETAILS.exact.zip') as z:caller=json.loads(z.read('CALLER.held.actual.json'))
original=json.loads((H/'CAPTURE.physical.actual.json').read_bytes());cont=json.loads((H/'CONTINUATION.actual.json').read_bytes())
machine=original['machine_id'];now=datetime.now(timezone.utc)
graph='''# R08 context-owner candidate29591E0: actual source result

machine_id: desktop-3fevhd2-1c74096080. Static exact4 source only; no game action.

```mermaid
flowchart TD
 C[Character1C0 context C] --> A[C18 to C2C0 / C20 to C2C8 copies]
 A --> D[28A6535 to held28D6170 ID cleanup]
 D --> G{C byte1D8 nonzero?}
 G -->|yes; clearbyte beforecall| E[28A65BE to29591E0 C and localdescriptor]
 C --> I[C1E0 pointer / signedDWORD1EC count:4B FullID sequence]
 I --> E
 E --> L[Generationchecked registrylookup/fallback]
 L --> U[230F8E0 opaque call]
 U --> T{rawDWORD return85C equals50726F76?}
 T --> Q{postcallR10 plus48 DWORD64 signed lessorequal1?}
 Q --> B{candidate equals QWORD postcallR10plus338 plus620; byte8 nonzero?}
 B --> O[880340 localdescriptor and address oflocalcandidate; opaquecall]
 O --> X[Caller pointerlist;2468AC0; indexedoutput from entryRDX]
 C -. producerunknown .-> CD[C28 / C30]
 CD -. sourceconsumerknown; sameoccurrenceunbound .-> N[28A6D10 signed NET application]
 N -. militarycategory plus sameapplication plus payer plus triggerunknown .-> P[paid amount / payer / cadence NULL]
 X -. indexedoutput is not provedwallet .-> P
```

Only the snapshot copies are proved context writes here. The225B source has stack stores but no direct nonstack store; its two opaquecalls remain opaque. The53? no: exactly54 saved instructions span three genuine extents; both continuations explicitly CHAININFO to29591E0. All saved ordinary branches resolve within the225B union, ending RET29592C0. This does not expand callee/exception effects or infer runtime execution.

The1D8 gate is a raw source branch, not a proved business dirtyflag or payment trigger. A helper running later in this invocation cannot produce the already-completed earlier copies; cross-invocation effects remain unknown.
'''.replace('The53? no: exactly54','Exactly54')
with (H/'GRAPH.result.md').open('x',encoding='utf-8',newline='\n') as f:f.write(graph)
source=dict(schema='xar.e04.r08.context-owner29591E0.source.v1',machine_id=machine,sealed_at_utc=now.isoformat(),source_head=caller['source_head'],exe_sha256_reused=original['exe_sha256_reused'],machine_state_scope='Historical actual file stat before/after only; source knowledge portable, no new runtime qualification.',
 question='Find a narrow next producer/owner edge separating cached estimates from actual military paid settlement.',
 result=dict(candidate_entry='29591E0',actual_source_caller='28A65BE in held complete28A63E0',runtime_call_observed=False,input_receiver='C=*(Character+1C0)',output_receiver='Caller stack localdescriptor, later consumed into entryRDX-derived indexed output',source_extents=[dict(begin='29591E0',end='2959214',bytes=52),dict(begin='2959214',end='29592B1',bytes=157),dict(begin='29592B1',end='29592C1',bytes=16)],instructions=54,RET='29592C0',ordinary_branches_within_saved_union=True,opaque_direct_calls=['2959251->230F8E0','295928C->880340'],new_callee_bodies_read=0,
    body_role='Enumerates4B FullID occurrences from C+1E0/count+1EC; filters via raw returnedtag and postcallreceiver fields; passes candidatepointer via outputhelper. Not a proved financial writer.',
    ownbody_direct_nonstack_store=False,ownbody_direct_context18_20_28_30_store=False,transitive_or_alias_effects='unknown',
    raw_filters=['Return of230F8E0 DWORD+85C==0x50726F76','PostcallR10 QWORD+48 points to object whose DWORD+64<=1 signed','Candidate=QWORD[postcallR10+338]+620; candidateBYTE8!=0'],
    postcall_receiver_caveat='The source usesR10 after opaque230F8E0. No independent proof of its register-preservation contract; do not silently assume Win64 volatileR10 retained the same pointer.',
    no_new_writer_PC_or_owner_binding_obtained=True),
 causal_boundaries=['C18->C2C0 andC20->C2C8 copies precede selected helper in same invocation; latercall is not directproducer of those earlierstores. Cross-cycle effects unproved.',
    'C28/C30 producer and category still unidentified. No directstore in one body cannot prove the wholecalltree is read-only.',
    'Caller branchCbyte1D8!=0 clearsbyte then computes indexedoutput; rawgate is not proof of militarybudget refresh or paymentcadence.',
    'Separate current2C13F60/current-vectors are rate/query outputs; they are not shown entering C28/C30 or an actual payerwallet in this lane.'],
 decision=dict(schema='xar.e04.r08.typed-payment-boundary.v1',maintenance_attribution='unclosed',candidate_status='ELIMINATED_AS_DIRECT_CONTEXT_WRITER; OUTPUT_ENUMERATION_SOURCE_ONLY',known_cache_copy_fields=['18->2C0','20->2C8'],context_c_writer_PC=None,context_d_writer_PC=None,military_component_resource_slot=None,paid_military_amount_raw=None,payer=None,cadence=None,
    reason_codes=['NO_C_D_PRODUCER_BINDING','NO_MILITARY_CATEGORY','NO_SAME_APPLICATION_TOKEN','NO_PAYER_STORE_BINDING','NO_NATIVE_WRITER_DATE_OR_TRIGGER_PROOF'],
    allowed_use='Use held current/allraised rates only under their independent estimatecontracts; preserve actual wallet NET as its own observed transaction.',
    prohibited_upgrades=['Indexedcacheoutput is not walletpayment','Do not subtract estimate again from netwalletactual','No trap/no directstore/unchangedcache do not mean zerocharge','No actor-as-payer inference from copyframe']),
 next_observation=dict(kind='NEW_QUALIFIED_RAW_C_OR_D_WRITE',existing_observer_contract='Current frozen four slots2C0/2C8/28/30; prioritize an actual retained C+28 or C+30 write, no unauthorized18/20 argvredirect.',
    required=['Fresh machine/process/create/generation/actor/session/window/epoch/context and exactaddress','TruepostPC, fullregisters, thread lifecycle, rawwrittenvalue and recovery/loss status','Then limited containing-function source proving exactstore/inputproducer','Before paidclaim: sameapplication sourcecomponent+settlementparent+walletchild and actualpayer identity','Cadence needs actualnative date/trigger linkage; admission/querydate is insufficient'],
    current_writer_native_date=None,current_same_copy_caller=None,
    stop='One Root-admitted finitewindow. Timeout or no qualifiedC/D trap staysunknown; do not extend untilhit or follow these enumerationcallees.'),
 read_budget=dict(code_bytes=225,metadata_bytes=252,read_calls=26,whole_EXE_hashes=0,section_sweeps=0,game_SDK_desktop_build_mainwrite_actions=0),
 semantic_layer='Human source-dataflow analysis separately labelled from retainedbytes/branch/CHAININFO verifier. No live or business completion.',
 files=[pin(p) for p in sorted(H.iterdir()) if p.is_file()])
write('SOURCE.actual.json',source)
argv=[sys.executable,'-I','-B','-O',str(H/'verify_portable.py'),str(H)]
r=subprocess.run(argv,cwd=Path('C:/Users/1/AppData/Local/Temp'),capture_output=True,text=True,encoding='utf-8')
write('VERIFY.actual.json',dict(machine_id=machine,at_utc=datetime.now(timezone.utc).isoformat(),argv=argv,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr,source=pin(H/'SOURCE.actual.json')))
if r.returncode:raise ValueError(r.stderr or r.stdout)
du=shutil.disk_usage(H)
write('DELIVERY.actual.json',dict(machine_id=machine,at_utc=datetime.now(timezone.utc).isoformat(),source=pin(H/'SOURCE.actual.json'),verify=pin(H/'VERIFY.actual.json'),raws=[pin(H/n) for n in ('function.bin','continuation-2959214.bin','continuation-29592B1.bin')],graph=pin(H/'GRAPH.result.md'),free_bytes_at_close=du.free,package_ceiling_bytes=98304,storage_review_at_utc=(datetime.now(timezone.utc)+timedelta(hours=168)).isoformat(),new_EXE_reads_during_seal=0,paid_payer_cadence_confirmed=False))
size=sum(p.stat().st_size for p in H.iterdir() if p.is_file())
if size>98304:raise ValueError('Output ceiling:'+str(size))
print(json.dumps(dict(source=pin(H/'SOURCE.actual.json'),delivery=pin(H/'DELIVERY.actual.json'),package_bytes=size,verifier_exit=r.returncode,verifier_stdout=r.stdout)))
