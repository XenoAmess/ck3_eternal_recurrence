029591E0  48 89 5c 24 18                               mov qword ptr [rsp + 0x18], rbx
029591E5  48 89 6c 24 20                               mov qword ptr [rsp + 0x20], rbp
029591EA  57                                           push rdi
029591EB  48 83 ec 20                                  sub rsp, 0x20
029591EF  48 8b 99 e0 01 00 00                         mov rbx, qword ptr [rcx + 0x1e0]
029591F6  48 8b ea                                     mov rbp, rdx
029591F9  48 63 81 ec 01 00 00                         movsxd rax, dword ptr [rcx + 0x1ec]
02959200  48 8d 3c 83                                  lea rdi, [rbx + rax*4]
02959204  48 3b df                                     cmp rbx, rdi
02959207  0f 84 a4 00 00 00                            je 0x29592b1
0295920D  4c 8b 1d e4 48 3c 03                         mov r11, qword ptr [rip + 0x33c48e4]
