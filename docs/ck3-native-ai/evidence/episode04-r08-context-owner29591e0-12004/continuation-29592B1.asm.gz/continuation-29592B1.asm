029592B1  48 8b 5c 24 40                               mov rbx, qword ptr [rsp + 0x40]
029592B6  48 8b 6c 24 48                               mov rbp, qword ptr [rsp + 0x48]
029592BB  48 83 c4 20                                  add rsp, 0x20
029592BF  5f                                           pop rdi
029592C0  c3                                           ret 
