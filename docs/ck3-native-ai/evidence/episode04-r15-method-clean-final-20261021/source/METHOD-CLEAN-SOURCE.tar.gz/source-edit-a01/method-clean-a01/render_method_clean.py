"""Repair all affected method templates, then the SAME 67-cue full film.

Public render/concat/native-CAS APIs are reused.  Five context inputs are the
already encoded CAS movies, never the game raw; their obscured HUD is not
recovered or certified.  The eight accepted player scenes are reused unchanged.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass, replace
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from full_episode04_composer import Asset, FullEdit, integer, mapping, require, sequence, text
from render_full_workingcut import pin, process_birth, saved, total
from xar_promo.audio import AudioMixSpec, AudioStem
from xar_promo.operations import preserve_artifact, start_run
from xar_promo.process import CommandResult, CommandSpec, run_command
from xar_promo.project import artifact_path
from xar_promo.render import GeneratedTextFile, RenderOptions, RenderPlan, execute_render_plan, plan_render
from xar_promo.runlog import append_phase_record

MACHINE = "desktop-3fevhd2-1c74096080"
LIMIT = 536870912
SEGMENTS_MAX = 83886080
UNCHANGED_EIGHT_BYTES = 26755565
CONCAT_OVERHEAD = 8388608
FINAL_MAX = SEGMENTS_MAX + UNCHANGED_EIGHT_BYTES + CONCAT_OVERHEAD
PNG_MAX = 33554432
QA_MAX = 33554432
CONTROL_MAX = 8388608
CONTEXT = {"C01-01", "C02-09", "C03-01", "C04-10", "C05-06"}


@dataclass(frozen=True)
class MethodCue:
    cue: str
    frames: int
    kind: str
    old: Asset
    voice: Asset
    subtitle: Path
    card: str | None


def new_asset(path: Path) -> dict[str, object]:
    st = path.stat()
    return {"path": str(path), "bytes": st.st_size, "retained_sha256": pin(path)["sha256"],
            "identity": {"mtime_ns": str(st.st_mtime_ns), "st_dev": str(st.st_dev), "st_ino": str(st.st_ino)}}


def checked_small(value: object) -> Path:
    ref = mapping(value)
    p = Path(text(ref["path"]))
    require(pin(p) == ref, "Small source changed: " + str(p))
    return p


def parse_rows(value: object) -> list[MethodCue]:
    rows: list[MethodCue] = []
    for item in sequence(value):
        row = mapping(item)
        cue = text(row["cue_id"])
        kind = text(row["kind"])
        require(kind in {"static", "context"} and (kind == "context") == (cue in CONTEXT), "Context set changed")
        old = Asset.parse(row["old_segment"])
        voice = Asset.parse(row["voice"])
        old.verify_stat()
        voice.verify_stat()
        card = None if kind == "context" else text(row["card_id"])
        frames = integer(row["frames"])
        require(frames > 0 and row["voice_unchanged"] is True, "Method frame/voice contract changed")
        rows.append(MethodCue(cue, frames, kind, old, voice, checked_small(row["subtitle"]), card))
    require(len(rows) == 59 and len({r.cue for r in rows}) == 59, "Exactly59 distinct method cues required")
    require(sum(r.frames for r in rows) == 49447, "Method clock changed")
    return rows


def context_caption(cue: str) -> str:
    standard = "场景示意 · 非本主题验收镜头"
    if cue == "C02-09":
        standard = "开关示意 · 不代表实际补员已经发生"
    prefix = "Dialogue: 4,0:00:00.00,9:59:59.99,Chinese,context,0,0,0,,{\\an7\\pos(52,48)\\fs30}"
    if cue == "C01-01":
        return prefix.replace("9:59:59.99", "0:00:19.50") + standard + "\n" + prefix.replace("0:00:00.00", "0:00:19.50") + "场景示意 · 最后0.9秒为定格\n"
    return prefix + standard + "\n"


def method_plan(row: MethodCue, visual: Path, music: Path, *, work: Path, ffmpeg: Path) -> RenderPlan:
    output = work / (row.cue + ".mp4")
    ass = work / (row.cue + ".ass")
    duration = row.frames / 30
    plan = plan_render(ffmpeg=ffmpeg, video_input=visual, partial_output=output.with_suffix(".partial.mp4"),
        final_output=output, audit_directory=work / "audit" / row.cue,
        options=RenderOptions(1920, 1080, 30, duration, preset="veryfast", crf=21,
                              audio_bitrate="192k", pad_color="0x211813"),
        ass_path=ass, start_seconds=0.0, working_directory=work,
        audio_mix=AudioMixSpec((AudioStem("narration", row.voice.path),
            AudioStem("music", music, gain_db=-24, fade_in_seconds=1, fade_out_seconds=2)), duration_seconds=duration))
    require(len(plan.commands) == 1, "Expected one public encoder per affected cue")
    command = plan.commands[0]
    argv = list(command.spec.argv)
    graph_i = argv.index("-filter_complex") + 1
    graph = str(argv[graph_i])
    if row.kind == "static":
        replacements = {
            "scale=1920:1080:force_original_aspect_ratio=decrease:flags=lanczos": "scale=1536:864:force_original_aspect_ratio=decrease:flags=lanczos",
            "pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=0x211813": "pad=1920:1080:192:0:color=0x211813",
        }
        for old, new in replacements.items():
            require(graph.count(old) == 1, "Public geometry seam changed")
            graph = graph.replace(old, new, 1)
    else:
        seam = "pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=0x211813"
        require(graph.count(seam) == 1, "Encoded context seam changed")
        # Existing context CAS contains a 1536x864 game viewport at x192,y0;
        # y864..1080 is its original black subtitle band.  The old top caption
        # is already baked over HUD pixels.  We do not claim those pixels back.
        graph = graph.replace(seam, seam + ",drawbox=x=32:y=30:w=1888:h=112:color=0x211813:t=fill,drawbox=x=0:y=864:w=1920:h=216:color=0x211813:t=fill", 1)
    argv[graph_i] = graph
    argv[1:1] = ["-threads", "1", "-filter_complex_threads", "1"]
    argv[-1:-1] = ["-threads:v", "1", "-frames:v", str(row.frames), "-profile:v", "high", "-level:v", "4.0",
                   "-video_track_timescale", "15360", "-maxrate", "4M", "-bufsize", "8M"]
    content = row.subtitle.read_text(encoding="utf-8")
    if row.kind == "context":
        content += context_caption(row.cue)
    return replace(plan, commands=(replace(command, spec=replace(command.spec, argv=tuple(argv))),),
                   generated_files=(GeneratedTextFile(ass, content),))


def raster_cards(inputs: dict[str, object], root: Path, run: Path) -> dict[str, Path]:
    renderer = checked_small(inputs["rasterizer"])
    spec = importlib.util.spec_from_file_location("e04_retained_svg_rasterizer", renderer)
    if spec is None or spec.loader is None:
        raise ValueError("Retained rasterizer cannot load")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    regular = Path(text(inputs["font_regular"]))
    bold = Path(text(inputs["font_bold"]))
    result: dict[str, Path] = {}
    for value in sequence(inputs["cards"]):
        row = mapping(value)
        key = text(row["card_id"])
        source = checked_small(row["clean_svg"])
        preserve_artifact(run, source, artifact_id="clean.svg." + key, collection="derived",
            role="production-input", label=key + " edited source SVG", media_type="image/svg+xml")
        # Retained inspected rasterizer is an unchanged, separately pinned
        # historical dependency.  New layout/guards here have explicit types.
        image: Image.Image = module.raster_image(source.read_bytes(), regular, bold, review_label=False)
        image = image.resize((1920, 1080), Image.Resampling.LANCZOS)
        draw = ImageDraw.Draw(image)
        draw.rectangle((0, 0, 1920, 42), fill="#211813")
        label = "工作版 · 三方案实测待补" if key in {"D17", "D18", "D19", "D20", "D21", "D22"} else "机制图解 · 假设与实拍分别标明"
        if key == "D23":
            label = "历史观察 · 不用于新版三方案胜负"
        draw.text((36, 7), label, font=ImageFont.truetype(str(regular), 27), fill="#CBA56A")
        output = root / "cards" / (key + ".png")
        with output.open("xb") as f:
            image.save(f, format="PNG")
        require(total(root) < LIMIT and sum(p.stat().st_size for p in (root / "cards").glob("*.png")) * 2 <= PNG_MAX,
                "PNG originals plus immutable CAS exceed32MiB")
        record = preserve_artifact(run, output, artifact_id="clean.card." + key, collection="derived",
            role="visual-input", label=key + " player method explanation", media_type="image/png")
        result[key] = artifact_path(record, run.parent)
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--inputs", required=True, type=Path)
    parser.add_argument("--ffmpeg", required=True, type=Path)
    parser.add_argument("--admission", required=True, type=Path)
    parser.add_argument("--admission-sha", required=True)
    args = parser.parse_args()
    root: Path = args.root.resolve()
    inputs_path: Path = args.inputs
    admission: Path = args.admission
    ffmpeg: Path = args.ffmpeg
    card = mapping(json.loads(admission.read_text()))
    require(pin(admission)["sha256"] == args.admission_sha, "Execution card changed")
    require(card["machine_id"] == MACHINE and card["budget_status"] == "GREEN" and
            card["method_clean_render_execution_admitted"] is True and card["full_future_held_until_closed"] is True,
            "Method-clean execution not admitted")
    require(Path(text(card["aggregate_root"])).resolve() == root and integer(card["aggregate_ceiling_bytes"]) == LIMIT,
            "Wrong output root/ceiling")
    require(card["input_manifest_sha256"] == pin(inputs_path)["sha256"] and card["producer_sha256"] == pin(Path(__file__))["sha256"],
            "Frozen source differs")
    deadline = dt.datetime.fromisoformat(text(card["hard_deadline_utc"]).replace("Z", "+00:00"))
    require(dt.datetime.now(dt.UTC) < deadline and not (root / "ONCE-METHOD-CLEAN.json").exists(), "Expired or unknown prior attempt")
    inputs = mapping(json.loads(inputs_path.read_text()))
    project_path = checked_small(inputs["project"])
    timeline_path = checked_small(inputs["timeline"])
    project = mapping(json.loads(project_path.read_text()))
    timeline = mapping(json.loads(timeline_path.read_text()))
    edit = FullEdit.parse(project, timeline)
    rows = parse_rows(inputs["rows"])
    require([r.cue for r in rows] == [e.cue for e in edit.entries if e.theme is None], "Method cue order changed")
    for e in edit.entries:
        e.asset.verify_stat()
    require(sum(e.asset.size for e in edit.entries if e.theme is not None) == UNCHANGED_EIGHT_BYTES, "Eight player input set changed")
    music = Asset.parse(inputs["music"])
    music.verify_stat()
    for name in ("work", "work/segments", "temp", "native", "cards"):
        (root / name).mkdir()
    os.environ.update(TMP=str(root / "temp"), TEMP=str(root / "temp"), PYTHONDONTWRITEBYTECODE="1")
    saved(root / "ONCE-METHOD-CLEAN.json", {"machine_id": MACHINE, "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(),
        "admission": pin(admission), "inputs": pin(inputs_path), "producer": pin(Path(__file__)), "no_retry": True,
        "old_raw_read": False, "new_TTS": False})
    config = root / "native/promo-project.json"
    with config.open("xb") as f:
        f.write(project_path.read_bytes())
    run = start_run(config, run_id="method-clean-full-a01", run_directory=root / "native/runs/method-clean-full-a01")
    preserve_artifact(run, inputs_path, artifact_id="method.clean.inputs", collection="derived", role="production-input",
        label="Actual59 method repairs with eight unchanged player scenes", media_type="application/json")
    preserve_artifact(run, Path(__file__), artifact_id="method.clean.producer", collection="derived", role="production-input",
        label="Actual public API producer source", media_type="text/x-python")
    cards = raster_cards(inputs, root, run)
    phase = "segments"

    def bounded(spec: CommandSpec, *, audit_directory: Path) -> CommandResult:
        def owned_run(argv: list[str], *, cwd: str | None, env: dict[str, str] | None, shell: bool,
                      check: bool, stdout: int, stderr: int, text: bool, encoding: str, errors: str) -> subprocess.CompletedProcess[str]:
            require(not shell and not check and text, "Public runner protocol changed")
            process = subprocess.Popen(argv, cwd=cwd, env=env, shell=False, stdout=stdout, stderr=stderr,
                text=True, encoding=encoding, errors=errors, creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
            stopped = False
            birth: str | None = None
            out = ""
            err = ""
            try:
                birth = process_birth(process.pid)
                while True:
                    produced = sum(p.stat().st_size for p in (root / "work/segments").glob("*.mp4"))
                    active = sum(p.stat().st_size for p in spec.partial_artifacts if p.is_file())
                    if (dt.datetime.now(dt.UTC) >= deadline or total(root) >= LIMIT - QA_MAX or
                            (phase == "segments" and produced > SEGMENTS_MAX) or (phase == "concat" and active > FINAL_MAX)):
                        stopped = True
                        process.terminate()
                    try:
                        out, err = process.communicate(timeout=5 if stopped else 0.25)
                        break
                    except subprocess.TimeoutExpired:
                        if stopped:
                            process.kill()
                            out, err = process.communicate()
                            break
            finally:
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                saved(audit_directory / "original-popen.json", {"machine_id": MACHINE, "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(),
                    "pid": process.pid, "process_birth_filetime": birth, "original_wait": process.wait(), "guard_stopped": stopped, "phase": phase, "no_retry": True})
            return subprocess.CompletedProcess(argv, -1 if stopped else process.returncode, out, err)
        return run_command(spec, audit_directory=audit_directory, environment=dict(os.environ), run=owned_run)

    replacements: dict[str, dict[str, object]] = {}
    for row in rows:
        require(dt.datetime.now(dt.UTC) < deadline, "Deadline before next cue")
        preserve_artifact(run, row.subtitle, artifact_id="clean.subtitle." + row.cue, collection="derived",
            role="subtitle", label=row.cue + " repaired full-phrase subtitles", media_type="text/x-ass")
        visual = row.old.path if row.kind == "context" else cards[text(row.card)]
        plan = method_plan(row, visual, music.path, work=root / "work/segments", ffmpeg=ffmpeg)
        execute_render_plan(plan, command_runner=bounded)
        require(sum(p.stat().st_size for p in (root / "work/segments").glob("*.mp4")) <= SEGMENTS_MAX, "Conditional80MiB exceeded")
        plan.final_output.chmod(stat.S_IREAD)
        record = preserve_artifact(run, plan.final_output, artifact_id="clean.segment." + row.cue, collection="derived",
            role="intermediate-segment", label=row.cue + " method template repaired", media_type="video/mp4")
        replacements[row.cue] = new_asset(artifact_path(record, run.parent))
        saved(root / ("CLOSED-" + row.cue + ".json"), {"machine_id": MACHINE, "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(),
            "cue": row.cue, "frames": row.frames, "movie_CAS": replacements[row.cue],
            "voice_reused": True, "raw_decoded": False, "formal_credit": 0})
        print("CLOSED", row.cue, replacements[row.cue]["bytes"], flush=True)
    entries: list[object] = []
    for value in sequence(timeline["entries"]):
        entry_mapping = dict(mapping(value))
        key = text(entry_mapping["cue_id"])
        if key in replacements:
            entry_mapping["review_cas"] = replacements[key]
            entry_mapping["player_picture_status"] = "ACTUALLY_RENDERED_METHOD_TEMPLATE_CLEAN;59voice unchanged"
        entries.append(entry_mapping)
    timeline["entries"] = entries
    timeline["method_template_clean_actual"] = True
    timeline["observed_at_utc"] = dt.datetime.now(dt.UTC).isoformat()
    saved(root / "full-edit.method-clean.actual.json", timeline)
    final_edit = FullEdit.parse(project, timeline)
    phase = "concat"
    composition = final_edit.plan(ffmpeg=ffmpeg, future_root=root)
    execute_render_plan(composition, command_runner=bounded)
    movie = composition.final_output
    require(movie.stat().st_size <= FINAL_MAX and total(root) + movie.stat().st_size + QA_MAX <= LIMIT, "Final CAS/QA peak does not fit")
    movie.chmod(stat.S_IREAD)
    record = preserve_artifact(run, movie, artifact_id="e04.full.method-clean", collection="derived", role="deliverable",
        label="Full six-chapter workingcut with repaired method templates", media_type="video/mp4")
    native = artifact_path(record, run.parent)
    native.chmod(stat.S_IREAD)
    preserve_artifact(run, root / "full-edit.method-clean.actual.json", artifact_id="method.clean.actual.timeline",
        collection="derived", role="production-result", label="67 actual CAS references", media_type="application/json")
    append_phase_record(run, phase_id="method.clean.full", status="succeeded", detail="59 repaired methods and8 unchanged evidence scenes in same full film; unique new movie QA pending.")
    saved(root / "FULL-MOVIE-CLOSED.actual.json", {"machine_id": MACHINE, "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(),
        "work_movie": pin(movie), "native_CAS_movie": pin(native), "native_run": pin(run), "nominal_frames": 57547,
        "repaired_method_cues": 59, "unchanged_player_evidence_cues": 8, "new_TTS": False, "old_raw_decode": False,
        "context_HUD_not_recovered_or_evidence_certified": True, "new_movie_AV_QA": "pending", "aggregate_actual_bytes": total(root),
        "owned_media_processes": 0, "formal_themes": "8/11", "pending": ["R05", "R08", "R10", "ABC"], "whole_episode_finished": False,
        "human_1x": False, "signoff": False})
    print(str(movie), flush=True)


if __name__ == "__main__":
    main()
