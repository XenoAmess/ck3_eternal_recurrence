"""Focused guards for the actual template defects; never execute media."""
from __future__ import annotations

import json
from pathlib import Path
import re
import unittest
import xml.etree.ElementTree as ET

import prepare_method_clean as prepare
from render_method_clean import MethodCue, method_plan, parse_rows
from full_episode04_composer import Asset, mapping, sequence, text


class MethodCleanTests(unittest.TestCase):
    def test_locked_route_translation_preserves_limits(self) -> None:
        data = mapping(json.loads(prepare.RASTER.read_text()))
        cards = [mapping(v) for v in sequence(data["cards"])]
        card = next(c for c in cards if c["card_id"] == "D11")
        source = Path(text(mapping(card["source_svg"])["path"]))
        root = ET.fromstring(prepare.clean_svg(source.read_bytes(), "D11"))
        visible = "\n".join(e.text or "" for e in root.iter() if e.tag.endswith("text"))
        for limit in ["严格大于", "两场起算日不同", "录像之外到达", "只保留正在走的首段", "不能直接比快慢"]:
            self.assertIn(limit, visible)
        self.assertNotRegex(visible, r"R017[56]|Q100000|8653|8645|96666|95108")

    def test_comparison_subtitle_preserves_full_words_and_voice_text(self) -> None:
        project = mapping(json.loads((prepare.BASE / "player-integrated-a01/promo-project.player-actual.json").read_text()))
        cue = next(mapping(q) for ch in sequence(project["chapters"]) for q in sequence(mapping(ch)["cues"]) if mapping(q)["id"] == "C05-15")
        zh = text(mapping(cue["narration"])["zh-CN"])
        en = text(mapping(cue["subtitles"])["en"])
        old = "[Script Info]\n[Events]\nDialogue: 2,0:00:00.10,0:00:23.89,Chinese,zh,0,0,0,,old\nDialogue: 1,0:00:00.10,0:00:23.98,English,en,0,0,0,,old\nDialogue: 9,0:00:00.00,9:59:59.99,English,review,0,0,0,,PARTIAL METHOD REVIEW\n"
        cleaned = prepare.clean_ass(old, zh, en, "C05-15")
        chunks = [line.split(",", 9)[9].removeprefix(r"{\q2}") for line in cleaned.splitlines() if line.startswith("Dialogue: 2,")]
        self.assertEqual("".join(chunks), zh)
        self.assertIn("抵达表先列各方案自己的到场时间和到场状态；", chunks)
        self.assertIn("同日表再列第七、第十四、第二十一和第二十八天的实际读数。", chunks)
        self.assertNotIn("PARTIAL METHOD REVIEW", cleaned)
        self.assertFalse(any(chunk.endswith(("和到", "的一部", "第")) for chunk in chunks))

    def plan_fixture(self, kind: str) -> tuple[MethodCue, Path]:
        timeline = mapping(json.loads((prepare.BASE / "player-integrated-a01/full-edit.player-actual.timeline.json").read_text()))
        old = Asset.parse(mapping(sequence(timeline["entries"])[0])["review_cas"])
        row = MethodCue("C01-01" if kind == "context" else "C05-15", 612, kind, old, old,
                        prepare.HERE / "ass/C01-01.ass", None if kind == "context" else "D22")
        return row, prepare.HERE / "pure-plan-no-directory"

    def test_context_reuses_encoded_input_not_raw_and_keeps_caption_band(self) -> None:
        row, work = self.plan_fixture("context")
        plan = method_plan(row, row.old.path, row.voice.path, work=work, ffmpeg=Path("C:/FFmpeg.exe"))
        argv = list(plan.commands[0].spec.argv)
        self.assertEqual(Path(argv[argv.index("-i") + 1]), row.old.path)
        self.assertTrue(str(row.old.path).endswith(".mp4"))
        graph = str(argv[argv.index("-filter_complex") + 1])
        self.assertIn("drawbox=x=0:y=864:w=1920:h=216", graph)
        self.assertIn("drawbox=x=32:y=30:w=1888:h=112", graph)
        self.assertIn("最后0.9秒为定格", plan.generated_files[0].content)
        self.assertFalse(work.exists())

    def test_static_graph_separates_card_and_captions(self) -> None:
        row, work = self.plan_fixture("static")
        plan = method_plan(row, Path("C:/new-card.png"), row.voice.path, work=work, ffmpeg=Path("C:/FFmpeg.exe"))
        argv = list(plan.commands[0].spec.argv)
        graph = str(argv[argv.index("-filter_complex") + 1])
        self.assertIn("scale=1536:864", graph)
        self.assertIn("pad=1920:1080:192:0", graph)
        self.assertNotIn("drawbox", graph)
        self.assertFalse(work.exists())

    def test_numeric_alias_is_not_a_frame_count(self) -> None:
        inputs = mapping(json.loads((prepare.HERE / "METHOD-CLEAN-INPUTS.source.json").read_text()))
        rows = sequence(inputs["rows"])
        for wrong in [True, 612.0, -1]:
            altered = dict(mapping(rows[0]))
            altered["frames"] = wrong
            with self.subTest(wrong=wrong), self.assertRaises(ValueError):
                parse_rows([altered] + rows[1:])

    def test_qa_changes_only_scope_limit_and_deadline(self) -> None:
        old = (prepare.BASE / "qa_full_workingcut.py").read_bytes()
        expected = old.replace(b"LIMIT = 268435456", b"LIMIT = 536870912").replace(
            b"dt.datetime(2026, 10, 21, 10, 30,", b"dt.datetime(2026, 10, 21, 12, 30,")
        self.assertEqual((prepare.HERE / "qa_method_clean.py").read_bytes(), expected)


if __name__ == "__main__":
    unittest.main()
