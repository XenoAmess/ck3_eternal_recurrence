"""Create-only player wording and subtitle repairs; no media process or raster."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import sys
import textwrap
import xml.etree.ElementTree as ET

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from full_episode04_composer import Asset, FullEdit, integer, mapping, require, sequence, text
from render_full_workingcut import pin, saved

BASE = Path(__file__).resolve().parent.parent
HERE = Path(__file__).resolve().parent
OLD = Path("D:/workspace/ck3_native_war_ai_promo_work/e04-review02-full69-typo-repair-a02/runs/review02-full69-typography-a02")
METHOD = Path("C:/ck3-e04-resume-20261015-a01/review02-composer-candidate-a01/input-config.methodology.json")
RASTER = Path("C:/ck3-e04-resume-20261015-a01/review02-static-raster-production-a01/raster-manifest.actual.json")
MACHINE = "desktop-3fevhd2-1c74096080"
CONTEXT = {"C01-01", "C02-09", "C03-01", "C04-10", "C05-06"}

REWORDS: dict[str, str] = {
    "0 + 负变化 → 0": "负更新后的库存仍为零",
    "02 ADD后floor": "02 本次库存更新后",
    "当前 fresh、已存 prepared、实际新增人数分别读；角色1/1不计入实体兵员": "当前许可、之前的准备与真正补进的人数分别核对；角色记录另列",
    "普通路径不把每个持久兵槽切半": "普通拆分会迁移整条兵团，不逐名士兵平分",
    "新Army的stock字段复制原值；后续容量与实际库存独立读取。": "新军先复制原来的库存值；之后分别看两军实际库存和容量。",
    "两边UI人数不保证严格各半，实际DATA与统帅仍须读回。": "两边人数不保证严格各半；各军的实际兵员和统帅仍需分别确认。",
    "角色叶 + 完整ID": "核对同一个角色",
    "DATA与predicate": "分清记录类别",
    "独立typed readback": "实际确认现任统帅",
    "不由F8猜任命": "不从界面布局猜任命",
    "完整combat Knights": "展开完整骑士名单",
    "另核membership": "单独核对成员身份",
    "实际DATA兵槽": "查看实际兵员数据",
    "构造时空DATA不代表所有角色记录永远无DATA；不授实际新生。": "有些角色记录不带普通兵员；不能据此认定新生了一个士兵。",
    "处理旧角色 → 构造空DATA记录 → 关联角色 → 刷新1/1缓存": "关联角色 → 创建角色记录 → 界面可显示一人满员一人",
    "人；缓存行完整核对，实体DATA另核": "单位是人；界面记录与实际兵员分别核对",
    "仅说明单位；不是Robert/.4本场读数": "只说明单位，不是这次实拍读数",
    "R0173登船：本次实际personal SUB": "这次登船：实际扣款",
    "gross − 完整expenses；不重复扣军事月率": "总收入减完整支出；不要重复扣军费",
    "归因/cadence仍unknown；R07对照仍缺": "完整军费归因和结算时点仍待确认",
    "3金币只授本次登船，不是通用费率；本卡不授maintenance或ABC结果": "三金币只代表这次登船；不是通用费率，也不是三方案比较结果",
    "合军：角色权重与实际库存分开核": "合军：别只看两边库存的平均数",
    "SOURCE / 实际完整stock-cap-weights pair尚缺": "机制说明 · 完整合并数值仍待实测",
    "角色权重 wD / wS": "两军各自的权重",
    "读取native D权重；S用其当时native current": "以当时实际兵力权重为准",
    "share_i = trunc0(w_i × 100000 / W)": "各军权重除以总权重，再向零取整",
    "term_i = trunc0(share_i × 原stock_i / 100000)": "各自按份额折算库存，再向零取整",
    "先选将/刷新再读cap；大值保护分支HOLD": "更新统帅后重新看容量；不能跳过异常保护",
    "R0176 selected93已确认范围": "已有拆合观察只确认的范围",
    "实体250守恒；不是stock/cap/weights实测": "实际兵员守恒；不是完整库存合并实测",
    "两侧与合后stock/cap/weights完整pair": "两军与合后库存、容量、权重要一起记录",
    "不移用旧 .3 B数值，不授R09全卡、补给合并实测或ABC胜负": "不借用旧版本数字，也不预先宣称库存合并或三方案胜负",
    "当前许可 / 当前 fresh 比例": "现在是否允许、现在的准备比例",
    "依分支准备 → 保存 prepared 比例": "符合条件才准备，并保存比例",
    "读取已保存比例 + 各物理槽当前条件": "结合之前的准备和各兵团当前条件",
    "请求可能拒绝或整数为0 → 独立核实际ADD": "请求可能被拒绝或取整为零；最后看实际增加人数",
    "R0176 / selected93 / 同帧实际": "一次独立观察的实际读数",
    "4条 unique physical DATA；250/250": "四条实际兵员记录；共二百五十人",
    "当前两许可均 false；已存 prepared 均 0": "当时两项许可均关闭，之前保存的准备均为零",
    "当前许可 false 不等于旧正缓存已清零": "现在不允许，不等于之前的准备一定已清除",
    "这不是本次实际补兵结果": "这种可能不能直接说成本次已经补兵",
    "本卡只是安全整数域的假设输入，不是本场modifier或损失。": "本卡是假设算例，不是本场修正或实际损失。",
    "1/1变化不记作实体补员、死亡、Character出生或Knight资格；库存/容量/权重未在此卡证明": "角色记录的变化不算实际补兵或死亡；本卡不证明库存合并结果",
}

D11 = ["行军与后勤", "锁定后：首段保留，后程可改", "两场独立观察 · 分开解释", "停止移动的这次观察",
       "原先还有多个后续路段", "停止后只保留正在走的首段", "到达首段终点后，下一天仍无后续路线", "改道的另一次观察",
       "首段未改，后程转向新的终点", "先走完原首段，再转向新终点", "新的终点是在录像之外到达", "锁定条件：首段进度超过一半",
       "两次观察都已经超过一半", "源码为严格大于；恰好一半未在这两场实测", "两场起算日不同，不能直接比快慢",
       "一项从原始观察起点计时", "另一项从发出改道命令时计时", "停止和改道属于独立场次；录像与片外读回分别记录",
       "首段进度不是整条路线进度；两种起算方式不构成方案胜负"]
D12 = ["行军与后勤", "兵员、角色与统帅要分开看", "独立拆合观察 · 限定正例", "拆分以前", "实际兵员：二百五十人", "跟踪原来的四条兵团记录", "当时未发现统帅",
       "拆分以后", "原队列实际兵员合计不变", "另行发现新军", "独立确认新军统帅", "合并以后", "原四条兵团合计仍不变", "新军消失，原军继续存在", "重新确认存续军的统帅",
       "角色关联另看", "原来的一人记录消失，同一角色随后成为新军及合军后的统帅", "三次读回发生在同一游戏日期；只说明这次拆合，不代表所有合军结果",
       "角色记录的变化不算实际补兵或死亡；本卡不证明库存合并结果"]


def asset_ref(path: Path, size: int, sha: str) -> dict[str, object]:
    st = path.stat()
    require(st.st_size == size, "Historical input length changed")
    return {"path": str(path), "bytes": size, "retained_sha256": sha.lower(),
            "identity": {"mtime_ns": str(st.st_mtime_ns), "st_dev": str(st.st_dev), "st_ino": str(st.st_ino)}}


def clean_svg(raw: bytes, card: str) -> bytes:
    root = ET.fromstring(raw)
    elements = [e for e in root.iter() if e.tag.rsplit("}", 1)[-1] == "text"]
    special = D11 if card == "D11" else D12 if card == "D12" else None
    if special is not None:
        require(len(elements) == len(special), "Source card text shape changed: " + card)
    for i, element in enumerate(elements):
        old = element.text or ""
        value = special[i] if special is not None else REWORDS.get(old, old)
        if special is None:
            if old.startswith(("SOURCE", "SOURCE ", "ACTUAL source", "段号：")):
                value = "机制说明 · 具体来源及数值留在随片资料"
            elif re.fullmatch(r"D\d\d(?:\s*/\s*MARCH LOGISTICS)?", old):
                value = "行军与后勤"
            value = value.replace("SOURCE + ACTUAL LIMITED", "机制与限定实拍分开说明")
            value = value.replace("SOURCE / 假设示例明确标注", "机制图解 · 假设算例已标明")
            value = value.replace("SOURCE + R0173 BOARDING ACTUAL", "机制说明与一次实际登船观察")
            value = value.replace("R0176 SELECTED93 ACTUAL", "独立拆合观察 · 限定正例")
            value = value.replace("ADD后floor", "更新后归零").replace("角色叶", "角色记录")
        element.text = value
    texts = "\n".join(e.text or "" for e in elements)
    require(re.search(r"R0\d{3}|Q100000|\b(?:DATA|Core|raw|callback|fresh|prepared|native|unknown)\b|24E[0-9A-F]{4}", texts) is None,
            "Internal source label remains: " + card)
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def centiseconds(value: str) -> int:
    h, m, sec = value.split(":")
    return int(h) * 360000 + int(m) * 6000 + round(float(sec) * 100)


def ass_time(value: int) -> str:
    return f"{value // 360000}:{value // 6000 % 60:02d}:{value // 100 % 60:02d}.{value % 100:02d}"


def phrases(value: str, *, chinese: bool) -> list[str]:
    if chinese:
        pieces = [p for p in re.split(r"(?<=[，。；！？])", value) if p]
        require(all(len(p) <= 46 for p in pieces), "An authored Chinese phrase needs a manual line decision")
        return pieces
    sentences = [p.strip() for p in re.split(r"(?<=[.!?;])\s+", value) if p.strip()]
    return [part for sentence in sentences for part in textwrap.wrap(sentence, width=140, break_long_words=False, break_on_hyphens=False)]


def clean_ass(raw: str, zh: str, en: str, cue: str) -> str:
    header = raw.split("[Events]", 1)[0]
    events = [line.split(",", 9) for line in raw.splitlines() if line.startswith("Dialogue:")]
    result = header + "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    for style, value, chinese, layer in [("Chinese", zh, True, 2), ("English", en, False, 1)]:
        relevant = [row for row in events if row[3] == style and row[0] == "Dialogue: " + str(layer)]
        require(bool(relevant), "Missing original narration timing")
        start = min(centiseconds(row[1]) for row in relevant)
        stop = max(centiseconds(row[2]) for row in relevant)
        parts = phrases(value, chinese=chinese)
        if chinese:
            require("".join(parts) == value, "Spoken Chinese text changed")
        weights = [len(p) for p in parts]
        cursor = 0
        for i, part in enumerate(parts):
            left = start + round((stop - start) * cursor / sum(weights))
            cursor += weights[i]
            right = start + round((stop - start) * cursor / sum(weights))
            visible = part if chinese else r"\N".join(textwrap.wrap(part, width=86, break_long_words=False, break_on_hyphens=False))
            result += f"Dialogue: {layer},{ass_time(left)},{ass_time(right)},{style},phrase-{i},0,0,0,,{{\\q2}}{visible}\n"
    corrections: dict[str, str] = {
        "C05-09": "一人满员一人只是这条记录的界面显示，不代表实际兵员。",
        "C05-10": "方法示意：途中会合与合并按钮瞬间尚未拍到。",
        "C05-14": "这里新增的是角色记录，本场实际兵员没有因此增加。",
    }
    if cue in corrections:
        result += "Dialogue: 3,0:00:00.00,9:59:59.99,Chinese,scope,0,0,0,,{\\an7\\pos(72,1130)\\fs32}说明：" + corrections[cue] + "\n"
    return result


def main() -> None:
    project_path = BASE / "player-integrated-a01/promo-project.player-actual.json"
    timeline_path = BASE / "player-integrated-a01/full-edit.player-actual.timeline.json"
    project = mapping(json.loads(project_path.read_text()))
    timeline = mapping(json.loads(timeline_path.read_text()))
    edit = FullEdit.parse(project, timeline)
    manifest = mapping(json.loads((OLD / "run-manifest.json").read_text()))
    artifacts = {text((a := mapping(v))["id"]): a for v in sequence(manifest["artifacts"])}
    method = mapping(json.loads(METHOD.read_text()))
    card_for = {text((a := mapping(v))["id"]): text(a["card_id"]) for v in sequence(method["cues"])}
    raster = mapping(json.loads(RASTER.read_text()))
    cards = {text((a := mapping(v))["card_id"]): a for v in sequence(raster["cards"])}
    cue_text: dict[str, tuple[str, str]] = {}
    for ch_value in sequence(project["chapters"]):
        for cue_value in sequence(mapping(ch_value)["cues"]):
            q = mapping(cue_value)
            cue_text[text(q["id"])] = (text(mapping(q["narration"])["zh-CN"]), text(mapping(q["subtitles"])["en"]))
    (HERE / "svg").mkdir()
    (HERE / "ass").mkdir()
    rows: list[dict[str, object]] = []
    used: dict[str, dict[str, object]] = {}
    for entry in edit.entries:
        if entry.theme is not None:
            continue
        cue = entry.cue
        audio = artifacts["narration." + cue]
        sub = artifacts["subtitle." + cue]
        subtitle = OLD / text(sub["path"])
        old = subtitle.read_bytes()
        require(hashlib.sha256(old).hexdigest() == text(sub["sha256"]).lower(), "Old subtitle differs")
        zh, en = cue_text[cue]
        require(re.search(r"R0\d{3}|Q\d{4,}|PTS|DATA|Core|callback", zh) is None, "This voice requires a real replacement")
        ass = HERE / "ass" / (cue + ".ass")
        with ass.open("x", encoding="utf-8", newline="\n") as f:
            f.write(clean_ass(old.decode("utf-8-sig"), zh, en, cue))
        row: dict[str, object] = {"cue_id": cue, "frames": entry.frames, "kind": "context" if cue in CONTEXT else "static",
            "old_segment": mapping(sequence(timeline["entries"])[list(e.cue for e in edit.entries).index(cue)])["review_cas"],
            "voice": asset_ref(OLD / text(audio["path"]), integer(audio["bytes"]), text(audio["sha256"])),
            "subtitle": pin(ass), "original_subtitle": pin(subtitle), "voice_unchanged": True}
        if cue not in CONTEXT:
            card_id = card_for[cue]
            if card_id not in used:
                source = mapping(cards[card_id]["source_svg"])
                source_path = Path(text(source["path"]))
                b = source_path.read_bytes()
                require(hashlib.sha256(b).hexdigest() == text(source["sha256"]).lower(), "Original SVG differs")
                svg = HERE / "svg" / (card_id + ".svg")
                with svg.open("xb") as f:
                    f.write(clean_svg(b, card_id))
                used[card_id] = {"card_id": card_id, "source": pin(source_path), "clean_svg": pin(svg)}
            row["card_id"] = card_id
        rows.append(row)
    require(len(rows) == 59 and sum(row["kind"] == "context" for row in rows) == 5, "Actual method scope changed")
    player_inputs = mapping(json.loads((BASE / "PLAYER-EIGHT-INPUTS.source-a03.json").read_text()))
    result: dict[str, object] = {"schema": "xar.e04.method-clean.v1", "machine_id": MACHINE,
        "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(), "project": pin(project_path), "timeline": pin(timeline_path),
        "rows": rows, "cards": list(used.values()), "music": player_inputs["music"],
        "rasterizer": pin(Path("C:/ck3-e04-resume-20261015-a01/review02-composer-candidate-a01/svg_card_stills.py")),
        "font_regular": "C:/Windows/Fonts/msyh.ttc", "font_bold": "C:/Windows/Fonts/msyhbd.ttc",
        "context_policy": "Only existing encoded CAS; top baked-caption region replaced, bottom existing black caption band replaced. Obscured source HUD is not restored or certified. Context has zero formal evidence credit.",
        "formal_themes": "8/11", "pending": ["R05", "R08", "R10", "ABC"], "new_TTS": False,
        "raw_body_read": False, "whole_episode_finished": False, "human_1x": False, "signoff": False}
    saved(HERE / "METHOD-CLEAN-INPUTS.source.json", result)
    print(json.dumps({"method_cues": len(rows), "context": 5, "static": 54, "unique_cards": len(used), "new_TTS": 0}))


if __name__ == "__main__":
    main()
