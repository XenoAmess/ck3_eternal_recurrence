"""Episode 04: assemble the existing six-chapter project, not an appendix film.

The executable public plan uses existing immutable encoded CAS inputs.  This
module does not start a process, copy media, or create a run.  An execution
owner can pass its returned RenderPlan to the existing public executor after
the separately funded full-film run is adopted.  Player-facing rewrites remain
authoring intent until their changed narration and pictures are produced.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
import json
import re

from xar_promo.model import ProjectConfig
from xar_promo.render import RenderPlan, plan_concat

FPS = 30
ORIGINAL_METHOD_FRAMES = 58406
REMOVED_METHOD_FRAMES = 8959
METHOD_FRAMES = ORIGINAL_METHOD_FRAMES - REMOVED_METHOD_FRAMES
EVIDENCE_FRAMES = 8100
TOTAL_FRAMES = METHOD_FRAMES + EVIDENCE_FRAMES
ACCEPTED = frozenset(("R03", "R04", "R06", "R07", "R09", "R11", "R12", "R13"))
PENDING = frozenset(("R05", "R08", "R10"))
MACHINE = "desktop-3fevhd2-1c74096080"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def mapping(value: object) -> dict[str, object]:
    require(isinstance(value, dict), "Expected an object")
    if not isinstance(value, dict):
        raise ValueError("Expected an object")
    result: dict[str, object] = {}
    for key, item in value.items():
        require(isinstance(key, str), "Expected string keys")
        if isinstance(key, str):
            result[key] = item
    return result


def sequence(value: object) -> list[object]:
    if not isinstance(value, list):
        raise ValueError("Expected an array")
    return list(value)


def text(value: object) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError("Expected nonempty text")
    return value


def integer(value: object) -> int:
    if not isinstance(value, int) or isinstance(value, bool):
        raise ValueError("Expected an integer, excluding bool/float aliases")
    return value


def decimal(value: object) -> str:
    result = text(value)
    require(re.fullmatch(r"0|[1-9][0-9]*", result) is not None,
            "Expected canonical decimal-string identity")
    return result


@dataclass(frozen=True)
class Asset:
    path: Path
    size: int
    retained_sha256: str
    mtime_ns: str
    device: str
    inode: str

    @classmethod
    def parse(cls, value: object) -> Asset:
        row = mapping(value)
        identity = mapping(row["identity"])
        sha = text(row["retained_sha256"])
        require(re.fullmatch(r"[0-9a-f]{64}", sha) is not None,
                "Invalid retained SHA256")
        size = integer(row["bytes"])
        require(size > 0, "Empty media input")
        return cls(Path(text(row["path"])), size, sha,
                   decimal(identity["mtime_ns"]), decimal(identity["st_dev"]),
                   decimal(identity["st_ino"]))

    def verify_stat(self) -> None:
        actual = self.path.stat()
        require(self.path.is_file(), "Input is not a file")
        require((actual.st_size, str(actual.st_mtime_ns), str(actual.st_dev),
                 str(actual.st_ino)) ==
                (self.size, self.mtime_ns, self.device, self.inode),
                "Input identity changed: " + str(self.path))


@dataclass(frozen=True)
class Entry:
    cue: str
    chapter: str
    frames: int
    start: int
    theme: str | None
    asset: Asset

    @classmethod
    def parse(cls, value: object) -> Entry:
        row = mapping(value)
        theme_value = row["formal_theme"]
        theme = None if theme_value is None else text(theme_value)
        require(theme is None or theme in ACCEPTED,
                "A pending theme cannot become an encoded formal source")
        frames = integer(row["frames"])
        start = integer(row["timeline_start_frame"])
        require(frames > 0 and start >= 0, "Invalid frame interval")
        return cls(text(row["cue_id"]), text(row["chapter_id"]), frames,
                   start, theme, Asset.parse(row["review_cas"]))


@dataclass(frozen=True)
class FullEdit:
    entries: tuple[Entry, ...]
    project: ProjectConfig

    @classmethod
    def parse(cls, project_value: object, timeline_value: object) -> FullEdit:
        timeline = mapping(timeline_value)
        require(timeline["schema"] == "xar.e04.six-chapter-full-edit.v1", "Wrong schema")
        require(timeline["machine_id"] == MACHINE, "Wrong source machine")
        require(integer(timeline["frame_rate"]) == FPS, "Frame-rate alias/change")
        require(integer(timeline["total_frames"]) == TOTAL_FRAMES, "Full-film clock changed")
        pending = {text(value) for value in sequence(timeline["pending_formal_themes"])}
        require(pending == PENDING, "Pending themes must remain explicit")
        project = ProjectConfig.from_mapping(project_value)
        entries = tuple(Entry.parse(value) for value in sequence(timeline["entries"]))
        cue_ids = [cue.cue_id for chapter in project.chapters for cue in chapter.cues]
        chapter_ids = [chapter.chapter_id for chapter in project.chapters for cue in chapter.cues]
        require(len(project.chapters) == 6, "Six editorial chapters required")
        require(len(entries) == len(cue_ids) == 67, "Expected 59 retained method cues and 8 examples")
        require([entry.cue for entry in entries] == cue_ids, "Config/timeline cue order differs")
        require([entry.chapter for entry in entries] == chapter_ids, "Config/timeline chapter mapping differs")
        require(len(set(cue_ids)) == len(cue_ids), "Duplicate cue")
        require({entry.theme for entry in entries if entry.theme is not None} == ACCEPTED,
                "Accepted-theme coverage differs")
        require(sum(entry.theme is not None for entry in entries) == 8,
                "No duplicated or substituted formal source")
        cursor = 0
        for entry in entries:
            require(entry.start == cursor, "Gap or overlap in full-film clock")
            cursor += entry.frames
        require(cursor == TOTAL_FRAMES, "Incomplete full film")
        require(sum(entry.frames for entry in entries if entry.theme is None) == METHOD_FRAMES,
                "Existing method clock changed")
        require(sum(entry.frames for entry in entries if entry.theme is not None) == EVIDENCE_FRAMES,
                "Accepted source/card clock changed")
        return cls(entries, project)

    def plan(self, *, ffmpeg: Path, future_root: Path) -> RenderPlan:
        """Return the existing engine's stream-copy plan without running it."""
        for entry in self.entries:
            entry.asset.verify_stat()
        work = future_root / "work"
        return plan_concat(
            ffmpeg=ffmpeg,
            segment_paths=[entry.asset.path for entry in self.entries],
            concat_path=work / "full-episode.concat.txt",
            partial_output=work / "E04-FULL-SIX-CHAPTER-REVIEW.partial.mp4",
            final_output=work / "E04-FULL-SIX-CHAPTER-REVIEW.mp4",
            audit_directory=future_root / "audit" / "concat",
            working_directory=work,
        )


def describe(plan: RenderPlan) -> dict[str, object]:
    return {
        "partial_output": str(plan.partial_output),
        "final_output": str(plan.final_output),
        "commands": [
            {"argv": list(command.spec.argv),
             "cwd": str(command.spec.cwd),
             "audit_directory": str(command.audit_directory)}
            for command in plan.commands
        ],
        "generated_text_files": [
            {"path": str(item.path), "content": item.content}
            for item in plan.generated_files
        ],
        "media_execution": False,
        "new_narration_prepared": False,
        "human_1x": False,
        "signoff": False,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--timeline", required=True, type=Path)
    parser.add_argument("--future-root", required=True, type=Path)
    parser.add_argument("--ffmpeg", required=True, type=Path)
    parser.add_argument("--plan-only", required=True, action="store_true")
    args = parser.parse_args()
    project_path: Path = args.project
    timeline_path: Path = args.timeline
    future_root: Path = args.future_root
    ffmpeg: Path = args.ffmpeg
    project_value: object = json.loads(project_path.read_text(encoding="utf-8"))
    timeline_value: object = json.loads(timeline_path.read_text(encoding="utf-8"))
    edit = FullEdit.parse(project_value, timeline_value)
    print(json.dumps(describe(edit.plan(ffmpeg=ffmpeg, future_root=future_root)),
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
