"""One new-full-workingcut AV decode plus compact packet timestamps. No old source decode."""
from __future__ import annotations
import argparse
import csv
import datetime as dt
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

MACHINE = "desktop-3fevhd2-1c74096080"
LIMIT = 268435456
PATTERN = re.compile(r"\bn:\s*(\d+)\s+pts:\s*(-?\d+)\s+pts_time:([0-9.eE+-]+)")


def total(root: Path) -> int:
    return sum(p.stat().st_size for p in root.rglob("*") if p.is_file())


def identity(path: Path) -> dict[str, object]:
    st = path.stat()
    return {"bytes": st.st_size, "mtime_ns": str(st.st_mtime_ns),
            "st_dev": str(st.st_dev), "st_ino": str(st.st_ino)}


def saved(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)


def wait_original(process: subprocess.Popen[bytes]) -> int:
    if process.poll() is None:
        process.terminate()
        try:
            return process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
    return process.wait()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--movie", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--ffmpeg", type=Path, required=True)
    parser.add_argument("--ffprobe", type=Path, required=True)
    args = parser.parse_args()
    root: Path = args.root.resolve()
    movie: Path = args.movie.resolve()
    assert movie.is_relative_to(root), "QA only accepts this new aggregate's movie"
    assert len(args.sha256) == 64
    qa = root / "qa"
    qa.mkdir()
    before = identity(movie)
    environment = dict(os.environ)
    environment.update(TMP=str(root / "temp"), TEMP=str(root / "temp"), PYTHONDONTWRITEBYTECODE="1")
    deadline = dt.datetime(2026, 10, 21, 12, 30, tzinfo=dt.timezone.utc)
    saved(qa / "ONCE.json", {"machine_id": MACHINE, "movie": str(movie),
        "retained_closed_sha256": args.sha256, "before": before,
        "observed_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "complete_AV_decode_attempts_admitted": 1, "no_retry": True})
    # Small exact stream/container bound probe; does not request frames.
    argv = [str(args.ffprobe), "-v", "error", "-show_streams", "-show_format",
            "-of", "json", str(movie)]
    probe = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=environment)
    out, err = probe.communicate()
    saved(qa / "BOUND-PROBE.original.json", {"argv": argv, "pid": probe.pid,
        "original_wait": probe.wait(), "stdout_sha256": hashlib.sha256(out).hexdigest(),
        "stderr_sha256": hashlib.sha256(err).hexdigest()})
    (qa / "bound-probe.json").write_bytes(out)
    (qa / "bound-probe.stderr").write_bytes(err)
    assert probe.returncode == 0, "exact bound probe failed"

    # B-frame packet PTS may reorder; per-stream DTS must increase.
    argv = [str(args.ffprobe), "-v", "error", "-show_packets", "-show_entries",
            "packet=stream_index,pts,pts_time,dts,dts_time,duration,duration_time,flags:packet_side_data=",
            "-of", "compact=p=0:nk=0", str(movie)]
    count: dict[str, int] = {}
    previous_dts: dict[str, int] = {}
    dts_non_increasing: dict[str, int] = {}
    packet_hash = hashlib.sha256()
    with (qa / "packets.stderr").open("xb") as stderr:
        packet = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=stderr, env=environment)
        assert packet.stdout is not None
        try:
            with gzip.open(qa / "packets.compact.gz", "xb") as log:
                for raw in packet.stdout:
                    log.write(raw); packet_hash.update(raw)
                    parts = dict(part.split("=", 1) for part in raw.decode("ascii", "replace").strip().split("|") if "=" in part)
                    stream = parts.get("stream_index")
                    if stream is None:
                        continue
                    count[stream] = count.get(stream, 0) + 1
                    dts = parts.get("dts", "N/A")
                    if dts != "N/A":
                        tick = int(dts)
                        if stream in previous_dts and tick <= previous_dts[stream]:
                            dts_non_increasing[stream] = dts_non_increasing.get(stream, 0) + 1
                        previous_dts[stream] = tick
                    if sum(count.values()) % 128 == 0:
                        assert total(root) < LIMIT - 1048576, "aggregate guard"
                    assert dt.datetime.now(dt.timezone.utc) < deadline, "hard deadline"
            packet_rc = packet.wait()
        finally:
            packet_rc = wait_original(packet)
            saved(qa / "PACKETS.original.json", {"argv": argv, "pid": packet.pid,
                "original_wait": packet_rc, "packet_count_by_stream": count,
                "dts_non_increasing_by_stream": dts_non_increasing,
                "uncompressed_sha256": packet_hash.hexdigest(),
                "packet_PTS_may_reorder_for_B_frames": True})
    assert packet_rc == 0

    # One decode feeds both complete AV timestamp audit and twelve sparse images.
    frames = [0, 10257, 13662, 18579, 22169, 29966, 33103, 35125, 36608, 38939, 48143, 57546]
    select = "+".join("eq(n," + str(n) + ")" for n in frames)
    graph = ("[0:v]split=2[vq][vs];[vq]showinfo[v];[vs]select='" + select +
             "',scale=1920:1080[s];[0:a]ashowinfo[a]")
    argv = [str(args.ffmpeg), "-hide_banner", "-nostdin", "-threads", "1",
        "-filter_complex_threads", "1", "-v", "info", "-xerror", "-err_detect",
        "explode", "-i", str(movie), "-filter_complex", graph,
        "-map", "[v]", "-map", "[a]", "-fps_mode", "passthrough", "-f", "null", "NUL",
        "-map", "[s]", "-an", "-fps_mode", "vfr", "-c:v", "mjpeg", "-threads:v", "1", "-q:v", "4",
        str(qa / "boundary-%02d.jpg")]
    video_n = 0
    audio_n = 0
    previous_v: int | None = None
    previous_a: int | None = None
    v_first: str | None = None
    v_last: str | None = None
    a_first: str | None = None
    a_last: str | None = None
    raw_hash = hashlib.sha256()
    raw_bytes = 0
    decode = subprocess.Popen(argv, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
        creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS, env=environment)
    assert decode.stderr is not None
    try:
        with gzip.open(qa / "av-decode.stderr.gz", "xb") as log, \
             (qa / "video-PTS.csv").open("x", newline="", encoding="ascii") as vf, \
             (qa / "audio-PTS.csv").open("x", newline="", encoding="ascii") as af:
            vw = csv.writer(vf); aw = csv.writer(af)
            vw.writerow(["n", "pts", "pts_time"]); aw.writerow(["n", "pts", "pts_time"])
            for raw in decode.stderr:
                log.write(raw); raw_hash.update(raw); raw_bytes += len(raw)
                line = raw.decode("utf-8", "replace")
                match = PATTERN.search(line)
                if match and "ashowinfo" in line:
                    n, pts, seconds = match.groups()
                    assert int(n) == audio_n
                    tick = int(pts)
                    assert previous_a is None or tick > previous_a
                    previous_a = tick; audio_n += 1
                    a_first = seconds if a_first is None else a_first; a_last = seconds
                    aw.writerow([n, pts, seconds])
                elif match and "showinfo" in line:
                    n, pts, seconds = match.groups()
                    assert int(n) == video_n
                    tick = int(pts)
                    assert previous_v is None or tick > previous_v
                    previous_v = tick; video_n += 1
                    v_first = seconds if v_first is None else v_first; v_last = seconds
                    vw.writerow([n, pts, seconds])
                if (video_n + audio_n) % 128 == 0:
                    assert total(root) < LIMIT - 1048576, "aggregate guard"
                assert dt.datetime.now(dt.timezone.utc) < deadline, "hard deadline"
            decode_rc = decode.wait()
    finally:
        decode_rc = wait_original(decode)
        saved(qa / "AV-DECODE.original.json", {"argv": argv, "pid": decode.pid,
            "original_wait": decode_rc, "complete_AV_decode_attempts": 1,
            "video_frames": video_n, "audio_frames": audio_n,
            "video_first_last_pts_time": [v_first, v_last],
            "audio_first_last_pts_time": [a_first, a_last],
            "stderr_uncompressed_bytes": raw_bytes, "stderr_uncompressed_sha256": raw_hash.hexdigest()})
    assert decode_rc == 0 and video_n == 57547 and audio_n > 0
    assert not dts_non_increasing, "packet DTS disorder"
    for name, expected in [("packets.compact.gz", packet_hash.hexdigest()),
                           ("av-decode.stderr.gz", raw_hash.hexdigest())]:
        digest = hashlib.sha256()
        with gzip.open(qa / name, "rb") as checksum_stream:
            while chunk := checksum_stream.read(65536):
                digest.update(chunk)
        assert digest.hexdigest() == expected, "lossless gzip CRC/SHA mismatch"
    assert identity(movie) == before, "new movie changed during QA"
    images = sorted(qa.glob("boundary-*.jpg"))
    assert len(images) == len(frames)
    saved(qa / "QA.actual.json", {"machine_id": MACHINE,
        "observed_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "movie": str(movie), "retained_closed_sha256": args.sha256,
        "before_after_identity": before, "video_frames": video_n,
        "decoded_presentation_PTS_strict_increasing": True,
        "packet_DTS_strict_increasing_per_stream": True,
        "AV_decode_original_wait": decode_rc, "complete_decode_attempts": 1,
        "boundary_image_source_frame_indices": frames,
        "boundary_image_bytes": sum(p.stat().st_size for p in images),
        "gzip_CRC_and_exact_uncompressed_SHA_verified": True,
        "image_visual_review": "pending actual reviewer",
        "human1x": False, "signoff": False, "no_old_input_decode": True})
    print("NEW FULL WORKINGCUT TECHNICAL QA PASS:57547 frames; image review pending")


if __name__ == "__main__":
    main()
