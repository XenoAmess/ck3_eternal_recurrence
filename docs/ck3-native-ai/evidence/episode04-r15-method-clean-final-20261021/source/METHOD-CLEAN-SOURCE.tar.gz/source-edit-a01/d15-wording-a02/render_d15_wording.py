"""Exact D15 wording and original positive-weight limit; three static segments."""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE))
sys.path.insert(0, str(BASE / "method-clean-a01"))
from full_episode04_composer import Asset, integer, mapping, require, sequence, text
from render_full_workingcut import pin, process_birth, saved, total
from render_method_clean import MethodCue, checked_small, method_plan, new_asset, raster_cards
from xar_promo.operations import preserve_artifact, start_run
from xar_promo.process import CommandResult, CommandSpec, run_command
from xar_promo.project import artifact_path
from xar_promo.render import execute_render_plan
from xar_promo.runlog import append_phase_record

MACHINE = "desktop-3fevhd2-1c74096080"
LIMIT = 33554432
S_MAX = 8388608
EXPECTED = {"C02-12": 1051, "C05-08": 645, "C05-10": 832}


def selected_rows(inputs: dict[str, object]) -> list[MethodCue]:
    require(inputs["schema"] == "xar.e04.d15-wording-three.v2" and inputs["machine_id"] == MACHINE, "Wrong correction input")
    rows: list[MethodCue] = []
    for value in sequence(inputs["rows"]):
        row = mapping(value)
        key = text(row["cue_id"])
        frames = integer(row["frames"])
        require(key in EXPECTED and frames == EXPECTED[key] and row["card_id"] == "D15" and row["kind"] == "static", "Correction extends beyond its three cues")
        old = Asset.parse(row["old_segment"])
        voice = Asset.parse(row["voice"])
        voice.verify_stat()
        require(row["voice_unchanged"] is True, "Correction cannot regenerate narration")
        rows.append(MethodCue(key, frames, "static", old, voice, checked_small(row["subtitle"]), "D15"))
    require([r.cue for r in rows] == list(EXPECTED), "Three exact correction cues/order required")
    cards = sequence(inputs["cards"])
    require(len(cards) == 1 and mapping(cards[0])["card_id"] == "D15", "Only D15 graphic can change")
    svg = checked_small(mapping(cards[0])["clean_svg"])
    old_svg = checked_small(inputs["source_wording_original"])
    before = text(inputs["wording_before"]).encode()
    after = text(inputs["wording_after"]).encode()
    original = old_svg.read_bytes()
    scope_before = text(inputs["scope_before"]).encode()
    scope_after = text(inputs["scope_after"]).encode()
    require(original.count(before) == 1 and original.count(scope_before) == 2,
            "Original two text fields no longer match")
    require(svg.read_bytes() == original.replace(before, after, 1).replace(scope_before, scope_after, 1),
            "SVG has changes beyond the exact wording and original-domain restoration")
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--inputs", required=True, type=Path)
    parser.add_argument("--ffmpeg", required=True, type=Path)
    parser.add_argument("--admission", required=True, type=Path)
    parser.add_argument("--admission-sha", required=True)
    args = parser.parse_args()
    root: Path = args.root.resolve()
    inputs_path: Path = args.inputs
    admission: Path = args.admission
    ffmpeg: Path = args.ffmpeg
    card = mapping(json.loads(admission.read_text()))
    require(pin(admission)["sha256"] == args.admission_sha and card["machine_id"] == MACHINE and card["budget_status"] == "GREEN", "Invalid actual card")
    require(card["d15_wording_render_execution_admitted"] is True and card["full_future_held_until_closed"] is True,
            "Three-cue correction not admitted")
    require(Path(text(card["aggregate_root"])).resolve() == root and integer(card["aggregate_ceiling_bytes"]) == LIMIT, "Wrong32MiB root")
    require(card["input_manifest_sha256"] == pin(inputs_path)["sha256"] and card["producer_sha256"] == pin(Path(__file__))["sha256"], "Correction source changed")
    deadline = dt.datetime.fromisoformat(text(card["hard_deadline_utc"]).replace("Z", "+00:00"))
    require(dt.datetime.now(dt.UTC) < deadline and not (root / "ONCE-D15-WORDING.json").exists(), "Expired/unknown prior attempt")
    inputs = mapping(json.loads(inputs_path.read_text()))
    rows = selected_rows(inputs)
    project = checked_small(inputs["project"])
    music = Asset.parse(inputs["music"])
    music.verify_stat()
    for name in ("work", "work/segments", "native", "temp", "cards"):
        (root / name).mkdir()
    os.environ.update(TMP=str(root / "temp"), TEMP=str(root / "temp"), PYTHONDONTWRITEBYTECODE="1")
    saved(root / "ONCE-D15-WORDING.json", {"machine_id": MACHINE, "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(),
        "admission": pin(admission), "producer": pin(Path(__file__)), "no_retry": True, "new_TTS": False, "raw_decode": False})
    config = root / "native/promo-project.json"
    with config.open("xb") as f:
        f.write(project.read_bytes())
    run = start_run(config, run_id="d15-wording-a02", run_directory=root / "native/runs/d15-wording-a02")
    preserve_artifact(run, inputs_path, artifact_id="d15.wording.inputs", collection="derived", role="production-input", label="Exact two-text-field/three-cue correction", media_type="application/json")
    cards = raster_cards(inputs, root, run)
    require(total(root) < LIMIT and sum(p.stat().st_size for p in (root / "cards").glob("*.png")) * 2 <= 1048576, "Single PNG/CAS exceeds1MiB")

    def bounded(spec: CommandSpec, *, audit_directory: Path) -> CommandResult:
        def owned_run(argv: list[str], *, cwd: str | None, env: dict[str, str] | None, shell: bool, check: bool,
                      stdout: int, stderr: int, text: bool, encoding: str, errors: str) -> subprocess.CompletedProcess[str]:
            require(not shell and not check and text, "Public runner protocol changed")
            process = subprocess.Popen(argv, cwd=cwd, env=env, stdout=stdout, stderr=stderr, text=True,
                encoding=encoding, errors=errors, creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
            birth: str | None = None
            stopped = False
            out = ""
            err = ""
            try:
                birth = process_birth(process.pid)
                while True:
                    produced = sum(p.stat().st_size for p in (root / "work/segments").glob("*.mp4"))
                    if dt.datetime.now(dt.UTC) >= deadline or produced > S_MAX or total(root) > LIMIT - 4194304:
                        stopped = True
                        process.terminate()
                    try:
                        out, err = process.communicate(timeout=5 if stopped else 0.25)
                        break
                    except subprocess.TimeoutExpired:
                        if stopped:
                            process.kill()
                            out, err = process.communicate()
                            break
            finally:
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                saved(audit_directory / "original-popen.json", {"machine_id": MACHINE, "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(),
                    "pid": process.pid, "process_birth_filetime": birth, "original_wait": process.wait(), "guard_stopped": stopped, "no_retry": True})
            return subprocess.CompletedProcess(argv, -1 if stopped else process.returncode, out, err)
        return run_command(spec, audit_directory=audit_directory, environment=dict(os.environ), run=owned_run)

    results: list[dict[str, object]] = []
    for row in rows:
        require(dt.datetime.now(dt.UTC) < deadline, "Deadline before next corrected cue")
        preserve_artifact(run, row.subtitle, artifact_id="d15.subtitle." + row.cue, collection="derived", role="subtitle", label="Unchanged repaired subtitle", media_type="text/x-ass")
        plan = method_plan(row, cards["D15"], music.path, work=root / "work/segments", ffmpeg=ffmpeg)
        execute_render_plan(plan, command_runner=bounded)
        require(sum(p.stat().st_size for p in (root / "work/segments").glob("*.mp4")) <= S_MAX, "Conditional8MiB exceeded")
        plan.final_output.chmod(stat.S_IREAD)
        record = preserve_artifact(run, plan.final_output, artifact_id="d15.corrected." + row.cue, collection="derived", role="intermediate-segment",
            label=row.cue + " D15 wording accurate", media_type="video/mp4")
        stored = artifact_path(record, run.parent)
        stored.chmod(stat.S_IREAD)
        result: dict[str, object] = {"cue_id": row.cue, "frames": row.frames, "movie_CAS": new_asset(stored), "voice_unchanged": True, "ASS_unchanged": True}
        results.append(result)
        print("CLOSED", row.cue, stored.stat().st_size, flush=True)
    append_phase_record(run, phase_id="d15.wording.correction", status="succeeded", detail="ExactD15 wording and original positive-weight limit in3cues; integrate only these CAS in the same full67cue film.")
    saved(root / "D15-WORDING-CLOSED.actual.json", {"machine_id": MACHINE, "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(),
        "segments": results, "changed_cues": list(EXPECTED), "total_frames": 2528, "new_TTS": False, "raw_decode": False,
        "native_run": pin(run), "aggregate_actual_bytes": total(root), "owned_media_processes": 0,
        "full_movie": "next replace these3CAS, keep64others; final newmovie QA pending", "human_1x": False, "signoff": False})


if __name__ == "__main__":
    main()
