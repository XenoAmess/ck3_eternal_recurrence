"""Replace only the three corrected CAS in the completed 67-cue clean edit."""
from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE))
from full_episode04_composer import FullEdit, integer, mapping, require, sequence, text
from render_full_workingcut import FINAL_MAX, QA_AND_CONTROL, pin, saved
from render_d15_wording import EXPECTED, MACHINE


def replace_three(project: object, timeline_value: object, closed_value: object) -> dict[str, object]:
    timeline = dict(mapping(timeline_value))
    old = FullEdit.parse(project, timeline)
    closed = mapping(closed_value)
    require(closed["machine_id"] == MACHINE and integer(closed["total_frames"]) == 2528, "Wrong correction result")
    replacements = {text((row := mapping(v))["cue_id"]): row for v in sequence(closed["segments"])}
    require(set(replacements) == set(EXPECTED) and len(sequence(closed["segments"])) == 3, "Only three distinct D15 cues can change")
    entries: list[object] = []
    for value in sequence(timeline["entries"]):
        row = dict(mapping(value))
        key = text(row["cue_id"])
        if key in replacements:
            replacement = replacements[key]
            require(row["formal_theme"] is None and integer(row["frames"]) == integer(replacement["frames"]) == EXPECTED[key], "Correction changes a formal example or its duration")
            require(replacement["voice_unchanged"] is True and replacement["ASS_unchanged"] is True, "Voice/subtitle cannot silently change")
            row["review_cas"] = replacement["movie_CAS"]
            row["D15_wording_corrected_actual"] = True
        entries.append(row)
    timeline["entries"] = entries
    timeline["D15_wording_corrected_actual"] = True
    timeline["observed_at_utc"] = dt.datetime.now(dt.UTC).isoformat()
    new = FullEdit.parse(project, timeline)
    require([e.cue for e in old.entries] == [e.cue for e in new.entries], "Full cue order changed")
    require(sum(e.asset.size for e in new.entries) + 8388608 <= FINAL_MAX, "Real source bytes do not fit unchanged256MiB producer bound")
    return timeline


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--timeline", required=True, type=Path)
    parser.add_argument("--correction-closed", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--future-root", required=True, type=Path)
    parser.add_argument("--ffmpeg", required=True, type=Path)
    args = parser.parse_args()
    project_path: Path = args.project
    timeline_path: Path = args.timeline
    closed_path: Path = args.correction_closed
    output: Path = args.output
    future_root: Path = args.future_root
    ffmpeg: Path = args.ffmpeg
    project: object = json.loads(project_path.read_text())
    result = replace_three(project, json.loads(timeline_path.read_text()), json.loads(closed_path.read_text()))
    result["D15_correction_closed"] = pin(closed_path)
    saved(output, result)
    edit = FullEdit.parse(project, result)
    edit.plan(ffmpeg=ffmpeg, future_root=future_root)
    actual_input_sum = sum(e.asset.size for e in edit.entries)
    producer = BASE / "render_full_workingcut.py"
    qa = Path(__file__).parent / "qa_d15_final_full_a03.py"
    recipe: dict[str, object] = {"schema": "xar.e04.d15-final-full256.recipe.v1", "machine_id": MACHINE,
        "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(), "aggregate_root": str(future_root),
        "aggregate_ceiling_bytes": 268435456, "full_future_held_until_closed": True,
        "hard_deadline_utc": "2026-10-21T12:30:00Z", "review_due_utc": "2026-10-22T12:30:00Z",
        "project": pin(project_path), "timeline": pin(output), "producer": pin(producer), "QA_source": pin(qa),
        "actual_encoded_input_bytes": actual_input_sum, "unchanged64_reference_count": 64,
        "only_changed_cues": list(EXPECTED), "total_cues": 67, "frames": 57547,
        "peak_bytes": {"single_movie_bound": FINAL_MAX, "work_and_native_CAS": 2 * FINAL_MAX,
            "QA_control_TEMP": QA_AND_CONTROL, "allinclusive": 2 * FINAL_MAX + QA_AND_CONTROL},
        "required_consumer_fields": {"machine_id": MACHINE, "budget_status": "GREEN",
            "media_render_execution_admitted": True, "source_bound_media_execution_admitted": True,
            "full_future_held_until_closed": True, "aggregate_root": str(future_root), "aggregate_ceiling_bytes": 268435456,
            "project_sha256": pin(project_path)["sha256"], "timeline_sha256": pin(output)["sha256"],
            "producer_sha256": pin(producer)["sha256"], "hard_deadline_utc": "2026-10-21T12:30:00Z"},
        "render_argv_template": [sys.executable, "-B", "-X", "utf8", str(producer), "--root", str(future_root),
            "--project", str(project_path), "--timeline", str(output), "--ffmpeg", str(ffmpeg),
            "--admission", "ACTUAL_SOURCE_BOUND_CARD", "--admission-sha", "ACTUAL_CARD_SHA256"],
        "unique_final_movie_QA": "Two compact probes; one complete AV decode;12JPEG;publicAPI/config/runCLI; no intermediate full decode",
        "old_media_reencoded_or_rehashed": False, "new_TTS": False,
        "formal_themes": "8/11", "pending": ["R05", "R08", "R10", "ABC"], "human_1x": False, "whole_episode_finished": False}
    saved(output.parent / "FULL-D15-FINAL-RECIPE.source.json", recipe)
    print(json.dumps({"actual_input_sum": actual_input_sum, "allinclusive_peak": 2 * FINAL_MAX + QA_AND_CONTROL,
                      "frames": 57547, "new_rendered_cues_in_this_full_stage": 0}))


if __name__ == "__main__":
    main()
