"""Scope/wording guards, metadata and public plans only; no media process."""
from __future__ import annotations

import json
from pathlib import Path
import unittest

from render_d15_fixedpoint_a04 import BASE, EXPECTED, MACHINE, selected_rows
from integrate_d15_final import replace_three
from full_episode04_composer import mapping, sequence, text

HERE = Path(__file__).resolve().parent


class D15Tests(unittest.TestCase):
    def test_exact_wording_domain_and_three_cue_scope(self) -> None:
        inputs = mapping(json.loads((HERE / "D15-WORDING-INPUTS.source-a04.json").read_text()))
        rows = selected_rows(inputs)
        self.assertEqual([r.cue for r in rows], list(EXPECTED))
        self.assertEqual(sum(r.frames for r in rows), 2528)
        self.assertEqual(inputs["wording_after"], "以两军当时的实际权重为准")
        original = Path(text(mapping(inputs["source_wording_original"])["path"])).read_bytes()
        new_svg = Path(text(mapping(mapping(sequence(inputs["cards"])[0])["clean_svg"])["path"])).read_bytes()
        expected = original.replace(text(inputs["wording_before"]).encode(), text(inputs["wording_after"]).encode(), 1).replace(
            text(inputs["scope_before"]).encode(), text(inputs["scope_after"]).encode(), 1).replace(text(inputs["fraction_before"]).encode(), text(inputs["fraction_after"]).encode(), 1).replace(text(inputs["stock_before"]).encode(), text(inputs["stock_after"]).encode(), 1)
        self.assertEqual(new_svg, expected)
        self.assertEqual(inputs["scope_after"], "机制说明 · 仅限已确认的正权重路径")

    def test_numeric_alias_and_other_cue_rejected(self) -> None:
        for field, bad in [("frames", 1051.0), ("frames", True), ("cue_id", "C06-10")]:
            inputs = mapping(json.loads((HERE / "D15-WORDING-INPUTS.source-a04.json").read_text()))
            rows = list(sequence(inputs["rows"]))
            altered = dict(mapping(rows[0]))
            altered[field] = bad
            inputs["rows"] = [altered] + rows[1:]
            with self.subTest(field=field, bad=bad), self.assertRaises(ValueError):
                selected_rows(inputs)

    def test_other64_timeline_entries_remain_exact(self) -> None:
        project: object = json.loads((BASE / "player-integrated-a01/promo-project.player-actual.json").read_text())
        old = mapping(json.loads((BASE / "player-integrated-a01/full-edit.player-actual.timeline.json").read_text()))
        entries = [mapping(v) for v in sequence(old["entries"])]
        replacements: list[dict[str, object]] = [
            {"cue_id": r["cue_id"], "frames": r["frames"], "movie_CAS": r["review_cas"], "voice_unchanged": True, "ASS_unchanged": True}
            for r in entries if r["cue_id"] in EXPECTED]
        new = replace_three(project, old, {"machine_id": MACHINE, "total_frames": 2528, "segments": replacements})
        unchanged = 0
        for before, after in zip(entries, sequence(new["entries"]), strict=True):
            if before["cue_id"] not in EXPECTED:
                self.assertEqual(before, after)
                unchanged += 1
        self.assertEqual(unchanged, 64)
        self.assertEqual(new["total_frames"], 57547)
        replacements[0]["cue_id"] = "R13"
        with self.assertRaises(ValueError):
            replace_three(project, old, {"machine_id": MACHINE, "total_frames": 2528, "segments": replacements})

    def test_QA_only_deadline_and_D15_sample_delta(self) -> None:
        source = (BASE / "qa_full_workingcut.py").read_bytes()
        expected = source.replace(b"dt.datetime(2026, 10, 21, 10, 30,", b"dt.datetime(2026, 10, 21, 12, 30,").replace(b"13512", b"13662")
        self.assertEqual((HERE / "qa_d15_final_full_a03.py").read_bytes(), expected)


if __name__ == "__main__":
    unittest.main()
