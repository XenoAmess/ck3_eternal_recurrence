"""One admitted full working-cut concat, then the standard native CAS preserve.

Reuses immutable 59+8 inputs through public xar-promo APIs.  This is a narrow
execution owner, not a second render engine.  A create-only WAL prevents an
unknown attempt from being silently replayed.
"""
from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

from full_episode04_composer import FullEdit, integer, mapping, require, text
from xar_promo.operations import preserve_artifact, start_run
from xar_promo.project import artifact_path
from xar_promo.render import execute_render_plan
from xar_promo.process import CommandResult, CommandSpec, run_command
from xar_promo.runlog import append_phase_record

MACHINE = "desktop-3fevhd2-1c74096080"
LIMIT = 268435456
FINAL_MAX = 110550602
QA_AND_CONTROL = 33554432


def total(root: Path) -> int:
    return sum(path.stat().st_size for path in root.rglob("*") if path.is_file())


def pin(path: Path) -> dict[str, object]:
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest}


def saved(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)


def process_birth(pid: int) -> str:
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
    kernel.GetProcessTimes.restype = wintypes.BOOL
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel.CloseHandle.restype = wintypes.BOOL
    handle = kernel.OpenProcess(0x1000, False, pid)
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        creation, exit_time, kernel_time, user_time = (wintypes.FILETIME() for _ in range(4))
        if not kernel.GetProcessTimes(handle, ctypes.byref(creation), ctypes.byref(exit_time),
                                      ctypes.byref(kernel_time), ctypes.byref(user_time)):
            raise ctypes.WinError(ctypes.get_last_error())
        return str((int(creation.dwHighDateTime) << 32) | int(creation.dwLowDateTime))
    finally:
        kernel.CloseHandle(handle)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--timeline", required=True, type=Path)
    parser.add_argument("--ffmpeg", required=True, type=Path)
    parser.add_argument("--admission", required=True, type=Path)
    parser.add_argument("--admission-sha", required=True)
    args = parser.parse_args()
    root: Path = args.root.resolve()
    project: Path = args.project
    timeline: Path = args.timeline
    ffmpeg: Path = args.ffmpeg
    card_path: Path = args.admission
    card_sha: str = args.admission_sha
    require(pin(card_path)["sha256"] == card_sha, "Admission changed")
    card = mapping(json.loads(card_path.read_text(encoding="utf-8")))
    require(card["machine_id"] == MACHINE and card["budget_status"] == "GREEN", "No fresh actual GREEN")
    require(card["media_render_execution_admitted"] is True, "Source-only admission")
    require(card["source_bound_media_execution_admitted"] is True, "No source-bound execution")
    require(card["full_future_held_until_closed"] is True, "Future must remain held")
    require(Path(text(card["aggregate_root"])).resolve() == root, "Wrong output root")
    require(integer(card["aggregate_ceiling_bytes"]) == LIMIT, "Wrong all-inclusive limit")
    require(card["project_sha256"] == pin(project)["sha256"] and
            card["timeline_sha256"] == pin(timeline)["sha256"] and
            card["producer_sha256"] == pin(Path(__file__))["sha256"], "Source pin mismatch")
    deadline = dt.datetime.fromisoformat(text(card["hard_deadline_utc"]).replace("Z", "+00:00"))
    require(dt.datetime.now(dt.UTC) < deadline, "Expired card")
    require(not (root / "ONCE-FULL.json").exists(), "Prior or unknown attempt; no replay")
    edit = FullEdit.parse(json.loads(project.read_text(encoding="utf-8")),
                          json.loads(timeline.read_text(encoding="utf-8")))
    composition = edit.plan(ffmpeg=ffmpeg, future_root=root)
    require(total(root) + 2 * FINAL_MAX + QA_AND_CONTROL <= LIMIT,
            "Complete concat/CAS/QA peak does not fit")
    root.mkdir(parents=True, exist_ok=True)
    saved(root / "ONCE-FULL.json", {"machine_id": MACHINE,
        "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(), "admission": pin(card_path),
        "project": pin(project), "timeline": pin(timeline), "producer": pin(Path(__file__)),
        "quota_exception": card.get("quota_exception"), "no_replay": True})
    for name in ("work", "temp", "native"):
        (root / name).mkdir()
    config = root / "native" / "promo-project.json"
    with config.open("xb") as output:
        output.write(project.read_bytes())
    run = start_run(config, run_id="full-workingcut-a01",
                    run_directory=root / "native" / "runs" / "full-workingcut-a01")
    preserve_artifact(run, timeline, artifact_id="full.edit.timeline", collection="derived",
                      role="timeline-intent", label="Six-chapter full working edit", media_type="application/json")

    def bounded_command(spec: CommandSpec, *, audit_directory: Path) -> CommandResult:
        def owned_run(argv: list[str], *, cwd: str | None, env: dict[str, str] | None,
                      shell: bool, check: bool, stdout: int, stderr: int, text: bool,
                      encoding: str, errors: str) -> subprocess.CompletedProcess[str]:
            require(not shell and not check and text, "Unexpected public process protocol")
            process = subprocess.Popen(argv, cwd=cwd, env=env, shell=False,
                stdout=stdout, stderr=stderr, text=True, encoding=encoding, errors=errors,
                creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
            stopped = False
            out = ""
            err = ""
            birth: str | None = None
            try:
                birth = process_birth(process.pid)
                while True:
                    active = sum(path.stat().st_size for path in spec.partial_artifacts if path.is_file())
                    if (dt.datetime.now(dt.UTC) >= deadline or active > FINAL_MAX or
                            total(root) >= LIMIT - QA_AND_CONTROL - FINAL_MAX):
                        stopped = True
                        process.terminate()
                    try:
                        out, err = process.communicate(timeout=5 if stopped else 0.25)
                        break
                    except subprocess.TimeoutExpired:
                        if stopped:
                            process.kill()
                            out, err = process.communicate()
                            break
            finally:
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                saved(audit_directory / "original-popen.json", {"machine_id": MACHINE,
                    "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(),
                    "argv": argv, "pid": process.pid, "process_birth_filetime": birth,
                    "original_wait": process.wait(),
                    "guard_stopped": stopped, "stdout_sha256": hashlib.sha256(out.encode("utf-8")).hexdigest(),
                    "stderr_sha256": hashlib.sha256(err.encode("utf-8")).hexdigest(), "no_retry": True})
            return subprocess.CompletedProcess(argv, -1 if stopped else process.returncode, out, err)

        environment = dict(os.environ)
        environment.update(TMP=str(root / "temp"), TEMP=str(root / "temp"), PYTHONDONTWRITEBYTECODE="1")
        return run_command(spec, audit_directory=audit_directory, environment=environment, run=owned_run)

    execute_render_plan(composition, command_runner=bounded_command)
    final = composition.final_output
    require(final.stat().st_size <= FINAL_MAX, "Closed movie exceeds adopted bound")
    final.chmod(stat.S_IREAD)
    require(total(root) + final.stat().st_size + QA_AND_CONTROL <= LIMIT, "Final CAS/QA peak does not fit")
    record = preserve_artifact(run, final, artifact_id="e04.full.workingcut",
        collection="derived", role="deliverable", label="E04 full six-chapter working cut, eight themes",
        media_type="video/mp4")
    native = artifact_path(record, run.parent)
    native.chmod(stat.S_IREAD)
    append_phase_record(run, phase_id="full.workingcut.concat-and-CAS", status="succeeded",
                        detail="Existing encoded CAS inputs integrated in six chapters; new movie QA pending.")
    saved(root / "FULL-MOVIE-CLOSED.actual.json", {"machine_id": MACHINE,
        "observed_at_utc": dt.datetime.now(dt.UTC).isoformat(), "work_movie": pin(final),
        "native_CAS_movie": pin(native), "native_run": pin(run), "nominal_frames": 57547,
        "aggregate_actual_bytes": total(root), "remaining_owned_media_processes": 0,
        "new_movie_AV_PTS_QA": "pending", "player_narration_generation": "separate affected eight segments",
        "whole_episode_finished": False, "pending": ["R05", "R08", "R10", "ABC"],
        "human_1x": False, "signoff": False})
    print(str(final))


if __name__ == "__main__":
    main()
