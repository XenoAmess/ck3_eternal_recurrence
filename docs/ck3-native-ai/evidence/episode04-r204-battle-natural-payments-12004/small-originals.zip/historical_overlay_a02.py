"""RAM-only request-suffix correction; a01 token/filenames unchanged, no arm."""
import hashlib,json,sys,time
from pathlib import Path
from types import ModuleType,SimpleNamespace
sys.dont_write_bytecode=True
BASE=Path('C:/ck3-e04-resume-20261015-a01/r204-inline-observer-a01/r204_inline_observer.py')
SHA='8b7840238efa4fc74bd98800946835ad7a4b940d4f88047b8e256af8aa6ade8a'
def build():
 b=BASE.read_bytes()
 if BASE.is_symlink() or len(b)!=32305 or hashlib.sha256(b).hexdigest()!=SHA:raise RuntimeError('sealed a01 differs')
 t=b.decode();old="self.ownership();name=self.prefix+'-'+suffix"
 if t.count(old)!=1:raise RuntimeError('exact call seam differs')
 t=t.replace(old,old+'.lower()')
 t=t.replace("'strict_owner':self.p,'actor':self.actor_pin,'arm_token':self.token_pin", "'strict_owner':self.p,'arm_actor':self.actor_pin,'execution_overlay':OVERLAY,'arm_token':self.token_pin")
 t=t.replace("'actual_arm_success':self.armed_success", "'execution_overlay':OVERLAY,'actual_arm_success':self.armed_success")
 p=Path(__file__).resolve();r=p.read_bytes()
 overlay={'path':str(p),'bytes':len(r),'sha256':hashlib.sha256(r).hexdigest(),'base_sha256':SHA,'effective_source_sha256':hashlib.sha256(t.encode()).hexdigest()}
 m=ModuleType('r204_request_suffix_a02');m.__file__=str(BASE);m.OVERLAY=overlay;exec(compile(t,str(BASE)+'#a02','exec'),m.__dict__)
 return m,overlay
def main():
 m,overlay=build();a=m.parser().parse_args()
 if a.operation=='arm':raise RuntimeError('a02 only advance/collect of existing a01 token; never re-arm')
 if a.operation=='source-check':
  f,pins=m.load_film(a);suite,q=f.suite_from(a);seen=[];args={}
  actor=object.__new__(m.Actor);actor.a=SimpleNamespace(operation='advance-window');actor.deadline=time.monotonic()+200
  actor.ownership=lambda:None;actor.prefix='r204-check';actor.trace=[];actor.unknown=[];actor.run=Path('synthetic-no-sdk');actor.f=f
  actor.s=SimpleNamespace(request=lambda run,name,tool,arguments,timeout:seen.append(name) or {})
  m.read=lambda p:{'is_error':False,'request':{'request_id':'r204-check-d01-natural','tool':'ck3_query_army_observer_research_sampling_v1','arguments':args}}
  m.pin=lambda *args,**kw:{'in_memory_check_only':True}
  actor.call('D01-natural','ck3_query_army_observer_research_sampling_v1',args)
  assert seen==['r204-check-d01-natural']
  print(json.dumps({'source_check':'PASS','SDK_calls':0,'fixture':'RAM queue only; uppercase suffix through real call+existing regex','overlay':overlay},indent=2));return
 m.main()
if __name__=='__main__':main()
