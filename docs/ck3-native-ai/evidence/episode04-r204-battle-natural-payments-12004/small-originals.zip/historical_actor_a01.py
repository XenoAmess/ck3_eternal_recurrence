"""Root-only R204 natural window: source-check(default), arm, advance-window, collect-cleanup.

Arm/collect budget120s; advance takes explicit actual-deadline bounded budget. Completion/cleanup are measured,
not promised: unresolved operations/insufficient cleanup room remain PENDING.
Arm/advance preserve their actual window; Root must collect-cleanup before exit.
"""
from __future__ import annotations
import argparse,datetime,hashlib,importlib.util,json,re,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
ENTRY=Path('C:/ck3-e04-resume-20261015-a01/r204-runtime-prep-a01/root_research.py')
ENTRY_BYTES=6855
ENTRY_SHA='bfbf7fdf7e8b5ad33ffdd35c888d0393da8e63ad0b53c170a52a8dab26e26c61'
VALIDATOR_BYTES=9439
VALIDATOR_SHA='625e8cbf9f78ba1deff82c834ef45f8b5c7d955ecf1031c466c48958336fe52e'
CONTRACT=Path('C:/ck3-e04-resume-20261015-a01/r203-runtime-prep-a01/r203_postcondition_contract.py')
CONTRACT_BYTES=3079
CONTRACT_SHA='3533bda07e3d47a4807edd8cd103afb6bca2194e0c485b7e68e5a2d66cead762'
MACHINE='desktop-3fevhd2-1c74096080'
HEAD='19024b4d79d818a88709c9932ca4eb364d81ef33'
S0=53148888
SCENE=Path('D:/workspace/ck3_native_war_ai_promo_work/e04-r204-battle-natural-payments-a01')
SESSION_KEYS=('pid','process_create_time_100ns','connection_generation','loaded_game_epoch',
 'controlled_window_id','same_owned_process_no_load_window','game_state_identity_witness','player_character_full_id')
LIVE_SECONDS=120
OP_SECONDS=20
# Five normal cleanup requests can each consume20s. Work yields early; if any
# unknown step needs extra Pause/snapshot, cleanup can remain honestly pending.
CLEANUP_NORMAL_RESERVE=100
WRITE_MARGIN=1
TOOLS={'ck3_take_snapshot','ck3_query_army_observer_research_sampling_v1',
 'ck3_set_army_observer_research_sampling_v1','ck3_query_war_cash_current_resources_private_v1','ck3_execute_step',
 'ck3_query_current_event_window_context_v1','ck3_query_pending_character_interaction_context_v1'}
def need(ok,why):
 if not ok:raise RuntimeError(why)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin(path,limit=1024*1024):
 p=Path(path).resolve(strict=True);need(p.is_file() and not p.is_symlink() and 0<p.stat().st_size<=limit,'bounded regular source/original required')
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(path):
 pin(path,8*1024*1024);j=json.loads(Path(path).read_text(encoding='utf-8-sig'));need(isinstance(j,dict),'JSON object required');return j
def write(path,value):
 b=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8');need(len(b)<=192*1024,'small actor output exceeded')
 with Path(path).open('xb') as f:f.write(b)
 return pin(path,192*1024)
def load_film(a):
 ep=pin(a.entry,65536);vp=pin(a.qualification_validator,65536);cp=pin(CONTRACT,8192)
 need(Path(ep['path'])==ENTRY.resolve() and ep['bytes']==a.entry_bytes==ENTRY_BYTES and ep['sha256']==a.entry_sha256==ENTRY_SHA,'sealed R204 entry differs')
 need(vp['bytes']==a.validator_bytes==VALIDATOR_BYTES and vp['sha256']==a.validator_sha256==VALIDATOR_SHA,'actual public qualifier differs')
 need(cp['bytes']==CONTRACT_BYTES and cp['sha256']==CONTRACT_SHA,'sealed composite contract differs')
 spec=importlib.util.spec_from_file_location('r204_inline_owned_entry',ENTRY);entry=importlib.util.module_from_spec(spec);spec.loader.exec_module(entry)
 spec=importlib.util.spec_from_file_location('r204_inline_day_contract',CONTRACT);contract=importlib.util.module_from_spec(spec);spec.loader.exec_module(contract)
 class ExistingQueue:
  day_contract=staticmethod(contract.exact_day_postcondition)
  @staticmethod
  def suite_from(a):return entry.build([a.qualification_validator,a.validator_bytes,a.validator_sha256])
  @staticmethod
  def request(s,run,name,tool,arguments,timeout=20):
   need(re.fullmatch(r'r204-[a-z0-9-]{1,75}',name) is not None,'bounded existing request ID required')
   need(not (run/'requests'/(name+'.json')).exists() and not (run/'responses'/(name+'.json')).exists(),'request exists; never replay unknown')
   return s.request(run,name,tool,arguments,timeout)
 return ExistingQueue,{'entry':ep,'validator':vp,'day_contract':cp}
def frame(snapshot,c,p,creation):
 d=snapshot.get('diagnostics') or {};actor=snapshot.get('played_character') or {}
 need(snapshot.get('paused') is True and snapshot.get('map_ready') is True and actor.get('alive') is True,'actual paused living map frame required')
 need(d.get('bridge_pid')==p['pid'] and d.get('connection_generation')==p['connection_generation']
  and snapshot.get('episode_run_id')==p['episode_run_id'] and actor.get('character_id')==c['actor_id']==31254,'PID/generation/episode/actor differs')
 need(creation(p['pid'])==p['process_creation_filetime_100ns'],'owned PID creation time differs')
 need(type(snapshot.get('date_raw')) is int and S0<=snapshot['date_raw']<=S0+40*24,'R204 S0+40day bound differs')
 need(type(snapshot.get('revision')) is int and snapshot['revision']>0 and type(snapshot.get('native_revision')) is int,'actual public/native revisions absent')
 return snapshot
def natural_row(body):
 rows=body.get('army_observer_research_sampling_v1') or {};r=rows.get('natural_phase')
 need(isinstance(r,dict),'natural_phase actual row absent');return r
def is_off(row):
 return row.get('capture_enabled') is False and row.get('busy') is False and row.get('active_captures')==0 and row.get('clear_completed') is True and row.get('retained_records')==0
def enabled(row):
 return row.get('available') is True and row.get('capture_enabled') is True and row.get('busy') is False and row.get('active_captures')==0 and type(row.get('epoch')) is int and row['epoch']>0
def cash_journal(body):
 j=body.get('war_payment_observations_v1');need(isinstance(j,dict),'actual payment journal absent');return j
def session_key(j,p):
 c=j['current_session'];key={k:c[k] for k in SESSION_KEYS}
 need(c['pid']==p['pid'] and c['process_create_time_100ns']==p['process_creation_filetime_100ns']
  and c['connection_generation']==p['connection_generation'] and c['player_character_full_id']==31254,'payment session owner differs')
 need(j['controlled_window_admitted'] is True and c['same_owned_process_no_load_window'] is True
  and c['controlled_window_id']>0 and c['game_state_identity_witness']>0,'actual controlled window absent')
 return key
def window_key(n,j,p):
 need(n.get('installed') is True and enabled(n) and j.get('installed') is True and j.get('install_failure_flags')==0
  and enabled(j['sampling']),'actual natural/payment ON idle readback required')
 return {'natural_epoch':n['epoch'],'payment_epoch':j['sampling']['epoch'],'session':session_key(j,p)}
class BudgetStop(RuntimeError):pass
class Actor:
 def __init__(self,a,f,suite,source_pins):
  self.a=a;self.f=f;self.suite=suite;self.s=suite['scope'];self.n=suite['neutral']
  self.c,self.repo,self.scene,self.run,self.raw,self.p=self.n.context(a.config,self.s)
  need(self.c['source_head']==HEAD and self.c['native_build_source_head']==HEAD and self.c['machine_id']==MACHINE,'R204 exact source/machine differs')
  need(self.scene==SCENE.resolve() and self.run.parent==self.scene and self.raw.parent==self.scene
   and self.c['actor_id']==31254 and self.c['expected_start_date_raw']==S0,'actual R204 scene/start/actor differs')
  need(self.run.name==MACHINE+'--vanilla--R0204' and self.c['maximum_days']==40 and self.c['seconds']==180 and self.c['session_timeout_seconds']==5400,'actual R204 session scope differs')
  need(self.c.get('pre_resume_hook') is None,'inline manual companion must not relabel a pre_resume_hook')
  self.scope_pin=pin(a.config);self.source_pins=source_pins;self.actor_pin=pin(__file__,65536)
  self.cap=self.s.load_pin(self.c['capacity']);self.policy()
  self.close=self.n.close_engine(self.s,suite['record'].recording_evidence)
  self.session_room=self.close.deadline_room(self.c,self.run,OP_SECONDS+1)
  if a.operation=='advance-window':
   need(type(a.max_days) is int and 1<=a.max_days<=32 and type(a.seconds_budget) is int and 100<=a.seconds_budget<=5400,'explicit advance bounds required')
  self.prefix='r204-inline-'+a.operation+'-'+a.attempt;self.out=self.scene/('R204-INLINE-'+a.operation+'-'+a.attempt)
  need(not self.out.exists(),'new scene-local attempt required; never overwrite')
  self.out.mkdir();self.start=time.monotonic()
  self.phase_budget=min(a.seconds_budget if a.operation=='advance-window' else LIVE_SECONDS,self.session_room['remaining_seconds']-1)
  self.deadline=self.start+self.phase_budget
  self.trace=[];self.snap=None;self.snap_pin=None;self.natural_attempted=False;self.payment_attempted=False
  self.day_attempted=False;self.unknown=[];self.primary=None;self.after_result=None
  self.initial_off_confirmed=False;self.token=None;self.token_pin=None;self.armed_success=False;self.collect_window_verified=False
  self.daily=[];self.day_contracts=0;self.preserve_window=a.operation=='advance-window'
  self.clean={'payment_disabled':False,'payment_independent_clear':False,'natural_disabled':False,'natural_independent_off':False,'pending':[]}
  sys.path[:0]=[str(self.repo/'ck3_autonomous_player'/'src'),str(self.repo)]
 def policy(self):
  expected={'initial_sampling_enabled':False,'inline_natural_phase_allowed':True,'inline_war_payment_window_allowed':True,'external_debugger_allowed':False}
  need(self.cap.get('capture_bounds',{}).get('noobserver') is False and self.cap.get('observer_policy')==expected,'actual top inline-only policy differs')
  need(self.s.instant(self.cap['quota_review_at_utc'])>self.s.now(),'actual capacity review expired')
 def ownership(self):
  need(pin(self.a.config)==self.scope_pin,'actual IDENTITY_SCOPE bytes changed')
  self.n.owned(self.c,self.p,self.run,self.s,live=True);self.policy()
  self.close.deadline_room(self.c,self.run,OP_SECONDS+1)
 def call(self,suffix,tool,args,*,cleanup=False,mutation=False):
  need(tool in TOOLS,'tool not in this actor')
  if tool=='ck3_execute_step':need(args.get('step') in ('life-advance-one-day','pause-map'),'only existing day/pause parameters allowed')
  remaining=self.deadline-time.monotonic()-WRITE_MARGIN
  need(remaining>0,'observed phase dispatch budget exhausted')
  reserve=OP_SECONDS if self.a.operation=='advance-window' else CLEANUP_NORMAL_RESERVE
  if not cleanup and remaining<reserve:raise BudgetStop('dispatch yielded to observed phase time room')
  # Budget20s per operation. Never claim a shorter relay wait cancels the SDK
  # operation. Insufficient room creates PENDING rather than dispatching again.
  if cleanup and remaining<OP_SECONDS:raise BudgetStop('less than one20s cleanup operation remains')
  self.ownership();name=self.prefix+'-'+suffix
  if mutation:
   write(self.out/(suffix+'.once.json'),{'machine_id':MACHINE,'at_utc':now(),'request_id':name,'tool':tool,'arguments':args,'original_result_unknown_until_response':True})
  began=time.monotonic();entry={'name':name,'tool':tool,'arguments':args,'mutation':mutation,'at_utc':now()};self.trace.append(entry)
  try:
   body=self.f.request(self.s,self.run,name,tool,args,OP_SECONDS)
   packet=self.run/'responses'/(name+'.json');row=read(packet)
   need(row.get('is_error') is False and row.get('request')=={'request_id':name,'tool':tool,'arguments':args},'actual response request differs')
   # Original queue envelopes do not promise machine_id. Identity comes from
   # actual scope/FT/snapshot and the production journal, not an invented key.
   entry['response']=pin(packet,8*1024*1024);entry['status']='RETURNED';return body
  except BaseException as e:
   entry['status']='UNRESOLVED_OR_ERROR';entry['error']=type(e).__name__+': '+str(e)
   if mutation:self.unknown.append(name)
   raise
  finally:entry['elapsed_seconds']=time.monotonic()-began
 def snapshot(self,suffix,*,cleanup=False,allow_running=False):
  b=self.call(suffix,'ck3_take_snapshot',{'include_native_command_history':False},cleanup=cleanup)
  if allow_running and b.get('paused') is not True:
   d=b.get('diagnostics') or {};actor=b.get('played_character') or {}
   need(d.get('bridge_pid')==self.p['pid'] and d.get('connection_generation')==self.p['connection_generation']
    and b.get('episode_run_id')==self.p['episode_run_id'] and actor.get('character_id')==31254,'running cleanup identity differs')
  else:frame(b,self.c,self.p,self.s.creation_filetime)
  self.snap=b;self.snap_pin=self.trace[-1]['response'];return b
 def natural(self,suffix,enabled=None,*,cleanup=False):
  need(self.snap is not None and self.snap.get('paused') is True,'actual paused snapshot required')
  args={'observer_family':'natural_phase','expected_revision':self.snap['revision']}
  tool='ck3_query_army_observer_research_sampling_v1'
  if enabled is not None:tool='ck3_set_army_observer_research_sampling_v1';args['enabled']=enabled
  return natural_row(self.call(suffix,tool,args,cleanup=cleanup,mutation=enabled is not None))
 def cash(self,suffix,mode,*,cleanup=False):
  need(self.snap is not None and self.snap.get('paused') is True,'actual paused snapshot required')
  args={'expected_revision':self.snap['revision'],'payment_sampling':mode}
  if mode=='enable':args['payment_window_contract']='same_owned_process_no_load_v1'
  b=self.call(suffix,'ck3_query_war_cash_current_resources_private_v1',args,cleanup=cleanup,mutation=mode!='query')
  return b,cash_journal(b)
 def modal(self,snapshot,label):
  if snapshot.get('active_event') or snapshot.get('pending_character_interaction'):
   write(self.out/(label+'-MODAL.actual.json'),{'machine_id':MACHINE,'at_utc':now(),
    'active_event':snapshot.get('active_event'),'pending_character_interaction':snapshot.get('pending_character_interaction'),
    'actual_snapshot_response':self.snap_pin,'action_submitted':False,'Root_collect_native_context_and_apply_first_or_left_policy':True})
   event=snapshot.get('active_event');interaction=snapshot.get('pending_character_interaction')
   try:
    if event and type(event.get('instance_id')) is int:
     self.call(label+'-event-context','ck3_query_current_event_window_context_v1',{'event_instance_id':event['instance_id'],'expected_revision':snapshot['revision']},cleanup=True)
    elif interaction and type(interaction.get('instance_id')) is int:
     self.call(label+'-interaction-context','ck3_query_pending_character_interaction_context_v1',{'pending_interaction_id':interaction['instance_id'],'expected_revision':snapshot['revision']},cleanup=True)
    else:raise RuntimeError('native modal instance ID absent; Root query required')
    write(self.out/(label+'-CONTEXT.actual.json'),{'machine_id':MACHINE,'at_utc':now(),
     'native_context_response':self.trace[-1]['response'],'native_display_order_and_options_in_original':True,
     'action_submitted':False,'Root_native_first_displayed_or_left_policy_required':True})
   except BaseException as e:write(self.out/(label+'-CONTEXT-PENDING.actual.json'),{'machine_id':MACHINE,'at_utc':now(),'error':repr(e),'Root_native_context_required':True})
   return True
  return False
 def consume(self,body,label):
  from xar_autoplayer.bridge.war_payment_resource4_wallet_v1 import consume_resource4_wallet_contexts
  from xar_autoplayer.bridge.war_payment_raw4_getter_v1 import qualified_reads
  j=cash_journal(body);result=consume_resource4_wallet_contexts(j,snapshot=self.snap,machine_id=MACHINE)
  slim={'machine_id':MACHINE,'at_utc':now(),'snapshot_response':self.snap_pin,'cash_response':self.trace[-1]['response'],
   'current_session':j['current_session'],'sampling':j['sampling'],'journal_read_complete':j['read_complete'],
   'overwritten':j['overwritten'],'publication_failures':j['publication_failures'],
   'resource4_records_literal':[r for r in result['journal']['records'] if r['kind']==1 and r['resource_kind_raw']==4],
   'qualified_resource4_boundaries':result['qualified_resource4_boundaries'],
   'raw4_getter_present':'raw_resource4_getter_v1' in j,
   'raw4_getter_records':len((j.get('raw_resource4_getter_v1') or {}).get('records',[])),
   'qualified_raw4_getter_reads':qualified_reads(result['journal']),
   'resource_name':'unknown','maintenance_attribution':'unclosed',
   'zero_rows_not_zero_payment':True,'military_paid_raw':None,'payer':None,'cadence':None,'settlement_token':None}
  return write(self.out/(label+'-CONSUMED.actual.json'),slim)
 def arm(self):
  self.snapshot('01-initial-snapshot');need(not self.modal(self.snap,'initial'),'initial modal: Root policy required')
  n=self.natural('02-initial-natural-query');need(n.get('installed') is True and n.get('available') is True and is_off(n),'natural sampling not initially cleanOFF; do not reset prior journal')
  self.snapshot('03-initial-cash-before');b,j=self.cash('04-initial-payment-query','query')
  need(j.get('installed') is True and j.get('install_failure_flags')==0 and j.get('controlled_window_admitted') is False and is_off(j['sampling']),'payment not initially cleanOFF; do not reset prior journal')
  self.initial_off_confirmed=True;self.consume(b,'INITIAL')
  claim=self.scene/'R204-INLINE-ARM.once.json'
  write(claim,{'machine_id':MACHINE,'at_utc':now(),'scope':self.scope_pin,'actor':pin(__file__,65536),'attempt':self.a.attempt,
   'strict_owner':self.p,'actual_initial_off_confirmed':True,'no_reset_of_old_journal':True,'no_unknown_mutation_replay':True})
  self.snapshot('05-natural-arm-before');self.natural_attempted=True
  n=self.natural('06-natural-arm-once',True);need(n.get('capture_enabled') is True,'natural arm refused')
  self.snapshot('07-natural-readback-before');n=self.natural('08-natural-independent-query');need(n.get('capture_enabled') is True and not n.get('busy') and n.get('epoch',0)>0,'natural independent arm readback incomplete')
  self.snapshot('09-payment-arm-before');self.payment_attempted=True
  b,j=self.cash('10-payment-arm-once','enable');control=b.get('war_payment_control_v1') or {}
  need(control.get('accepted') is True and j.get('controlled_window_admitted') is True and j['sampling'].get('capture_enabled') is True,'payment arm refused/incomplete')
  self.snapshot('11-baseline-before');b,j=self.cash('12-baseline-independent-query','query')
  need(j['sampling'].get('busy') is False and j['sampling'].get('epoch',0)>0 and j.get('controlled_window_admitted') is True,'baseline window/epoch incomplete')
  self.after_result=self.consume(b,'BASELINE');key=window_key(n,j,self.p)
  self.token={'schema':'xar.e04.r204-inline-actual-arm.v1','machine_id':MACHINE,'observed_at_utc':now(),'run_id':self.run.name,
   'scope':self.scope_pin,'actor':self.actor_pin,'source_pins':self.source_pins,'strict_owner':self.p,'window':key,'armed_date_raw':self.snap['date_raw'],
   'actual_initial_off_confirmed':True,'actual_arm_readback_complete':True,'baseline_consumed':self.after_result,
   'baseline_snapshot_response':self.snap_pin,'baseline_cash_response':self.trace[-1]['response'],
   'sampling_intentionally_left_enabled_for_Root_film':True,'actual_cleanup_complete':False,'cleanup_required':True,
   'pre_resume_hook_configured':False,'normal_close_observer_cleanup_remains':'NOT_CONFIGURED','trace':self.trace}
  self.token_pin=write(self.out/'ARM-TOKEN.actual.json',self.token)
  self.armed_success=True;return 'actual_arm_readback_complete_Root_collect_cleanup_required'
 def load_token(self):
  need(self.a.arm_token is not None,'collect requires explicit actual arm token pin')
  p=pin(self.a.arm_token,192*1024)
  need(p['bytes']==self.a.arm_token_bytes and p['sha256']==self.a.arm_token_sha256,'actual arm token pin differs')
  need(Path(p['path']).parent.parent==self.scene and Path(p['path']).name=='ARM-TOKEN.actual.json','actual scene arm token required')
  t=read(p['path'])
  need(t.get('schema')=='xar.e04.r204-inline-actual-arm.v1' and t.get('machine_id')==MACHINE and t.get('run_id')==self.run.name
   and t.get('scope')==self.scope_pin and t.get('strict_owner')==self.p and t.get('actor')==self.actor_pin
   and t.get('source_pins')==self.source_pins and t.get('actual_arm_readback_complete') is True
   and t.get('actual_initial_off_confirmed') is True,'arm token actual owner/source/scope differs')
  need(type(t.get('armed_date_raw')) is int and S0<=t['armed_date_raw']<=S0+40*24,'actual token arm date absent')
  self.token=t;self.token_pin=p
 def collect(self):
  self.load_token();self.snapshot('01-collect-before')
  n=self.natural('02-natural-window-query');b,j=self.cash('03-payment-window-query','query')
  need(window_key(n,j,self.p)==self.token['window'],'actual window/epochs changed: do not disable another window')
  self.collect_window_verified=True;self.natural_attempted=True;self.payment_attempted=True
  self.after_result=self.consume(b,'COLLECT')
  write(self.out/'COLLECT-WINDOW.actual.json',{'machine_id':MACHINE,'observed_at_utc':now(),'arm_token':self.token_pin,
   'actual_same_owned_window_epochs':True,'snapshot_response':self.snap_pin,'cash_response':self.trace[-1]['response'],
   'actual_date_raw':self.snap['date_raw'],'default_additional_day_actions':0})
  if self.modal(self.snap,'collect'):return 'modal_saved_no_day_Root_policy_required'
  return 'collected_existing_window_no_new_day'
 def checkpoint(self,label,n=None,body=None):
  if n is None:n=self.natural(label+'-natural')
  if body is None:body,j=self.cash(label+'-cash','query')
  else:j=cash_journal(body)
  need(window_key(n,j,self.p)==self.token['window'],'actual owner/window/epoch changed; no action replay')
  consumed=self.consume(body,label)
  raw4=j.get('raw_resource4_getter_v1') or {}
  counters={'payment':{k:j[k] for k in ('latest_sequence','oldest_sequence','overwritten','publication_failures','read_complete')},
   'natural':j['natural_journal_status'],
   'raw4_getter':{k:raw4.get(k) for k in ('latest_sequence','oldest_sequence','overwritten','publication_failures','read_complete')},
   'natural_sampling':n}
  # Full daily originals precede any subsequent day. A counter anomaly stops
  # this attempt; snapshots/cash are retained, never silently called zero.
  complete=(j['read_complete'] is True and j['overwritten']==0 and j['publication_failures']==0
   and j['natural_journal_status']['read_complete'] is True and j['natural_journal_status']['overwritten_records']==0
   and j['natural_journal_status']['failed_appends']==0 and (not raw4 or raw4.get('read_complete') is True
   and raw4.get('overwritten')==0 and raw4.get('publication_failures')==0))
  packet={'machine_id':MACHINE,'observed_at_utc':now(),'arm_token':self.token_pin,'snapshot_response':self.snap_pin,
   'cash_response':self.trace[-1]['response'],'consumer':consumed,'actual_date_raw':self.snap['date_raw'],
   'counter_read_complete_without_overwrite':complete,'counters':counters}
  out=write(self.out/(label+'-CHECKPOINT.actual.json'),packet)
  self.daily.append(out);self.after_result=consumed
  return complete
 def advance(self):
  self.load_token();self.snapshot('01-window-before')
  if self.modal(self.snap,'start'):return 'modal_handoff_window_preserved'
  n=self.natural('02-window-natural');body,j=self.cash('03-window-cash','query')
  need(window_key(n,j,self.p)==self.token['window'],'actual token window/epochs changed')
  self.collect_window_verified=True
  if not self.checkpoint('START',n,body):return 'journal_counter_anomaly_Root_review'
  requested=max(0,min(self.a.max_days,32,(min(S0+40*24,self.token['armed_date_raw']+32*24)-self.snap['date_raw'])//24))
  for day in range(1,requested+1):
   # Existing session/cap deadline, not configured5400 or a guessed calendar.
   self.session_room=self.close.deadline_room(self.c,self.run,101)
   if self.deadline-time.monotonic()<101:return 'explicit_time_headroom_reached_window_preserved'
   before=self.snap;step=None;step_error=None;contract=None
   self.day_attempted=True
   try:step=self.call(f'd{day:02d}-day-once','ck3_execute_step',{'step':'life-advance-one-day','expected_revision':None},mutation=True)
   except BaseException as e:step_error=type(e).__name__+': '+str(e)
   finally:self.snapshot(f'd{day:02d}-independent-after',cleanup=True)
   interrupted=bool(self.snap.get('active_event') or self.snap.get('pending_character_interaction'))
   try:contract=self.f.day_contract(step,before,self.snap)
   except ValueError as e:step_error=step_error or str(e)
   if contract:self.day_contracts+=1
   day_pin=write(self.out/f'DAY-{day:02d}.actual.json',{'machine_id':MACHINE,'observed_at_utc':now(),
    'requested_attempt_day':day,'before_date_raw':before['date_raw'],'after_date_raw':self.snap['date_raw'],
    'composite_plus_independent_postcondition':contract,'step_error':step_error,'modal':interrupted,
    'snapshot_response':self.snap_pin,'day_submissions_at_most_once':1,'unknown_never_replayed':True})
   if interrupted:
    self.modal(self.snap,f'd{day:02d}')
   complete=self.checkpoint(f'D{day:02d}')
   if interrupted:return 'modal_handoff_window_preserved'
   if step_error:raise RuntimeError('day unqualified; Root inspect original, no replay: '+step_error)
   if not complete:return 'journal_counter_anomaly_Root_review'
  return 'requested_day_headroom_complete_window_preserved'
 def cleanup(self):
  if not (self.natural_attempted or self.payment_attempted):
   self.clean['no_actor_arm_mutation_submitted']=True
   if self.a.operation=='collect-cleanup':self.clean['pending'].append('token window not independently verified; no other window disabled')
   elif not self.initial_off_confirmed:self.clean['pending'].append('initial actual OFF unconfirmed; no prior journal reset')
   return
  try:
   self.snapshot('90-cleanup-snapshot',cleanup=True,allow_running=True)
   if self.snap.get('paused') is not True:
    self.call('91-cleanup-pause-once','ck3_execute_step',{'step':'pause-map','expected_revision':None},cleanup=True,mutation=True)
    self.snapshot('92-cleanup-paused-readback',cleanup=True)
  except BaseException as e:self.clean['pending'].append('cleanup owned paused snapshot: '+repr(e));return
  if self.payment_attempted:
   try:
    b,j=self.cash('93-payment-disable-once','disable',cleanup=True)
    self.clean['payment_disabled']=(b.get('war_payment_control_v1') or {}).get('accepted') is True and is_off(j['sampling'])
   except BaseException as e:self.clean['pending'].append('payment disable: '+repr(e))
   try:
    b,j=self.cash('94-payment-independent-clear-query','query',cleanup=True)
    self.clean['payment_independent_clear']=is_off(j['sampling']) and j.get('controlled_window_admitted') is False
   except BaseException as e:self.clean['pending'].append('payment independent readback: '+repr(e))
  else:self.clean['payment_not_armed']=True
  if self.natural_attempted:
   try:
    n=self.natural('95-natural-disable-once',False,cleanup=True);self.clean['natural_disabled']=is_off(n)
   except BaseException as e:self.clean['pending'].append('natural disable: '+repr(e))
   try:
    n=self.natural('96-natural-independent-off-query',cleanup=True);self.clean['natural_independent_off']=is_off(n)
   except BaseException as e:self.clean['pending'].append('natural independent readback: '+repr(e))
  # Query never claims to trigger a drain/clear. Unknown or incomplete disable
  # stays pending for Root; no second disable action is silently submitted.
 def run_actor(self):
  reason=None
  try:reason=self.arm() if self.a.operation=='arm' else self.advance() if self.a.operation=='advance-window' else self.collect()
  except BaseException as e:self.primary=type(e).__name__+': '+str(e)
  finally:
   if not self.armed_success and not self.preserve_window:self.cleanup()
  clean_ok=(not self.armed_success and not self.preserve_window and not self.clean['pending'] and not self.unknown
   and (self.initial_off_confirmed or self.collect_window_verified)
   and (not self.natural_attempted or self.clean['natural_disabled'] and self.clean['natural_independent_off'])
   and (not self.payment_attempted or self.clean['payment_disabled'] and self.clean['payment_independent_clear']))
  elapsed=time.monotonic()-self.start
  companion={'machine_id':MACHINE,'observed_at_utc':now(),'run_id':self.run.name,'source_head':HEAD,'scope':self.scope_pin,
   'strict_owner':self.p,'actor':self.actor_pin,'arm_token':self.token_pin,'source_pins':self.source_pins,'sampling_initial_policy_is_not_observed_proof':True,
   'pre_resume_hook_configured':False,'normal_close_observer_cleanup_remains':'NOT_CONFIGURED',
   'explicit_Root_inline_actor_cleanup':self.clean,'actual_cleanup_complete':bool(clean_ok),
   'manual_followup_required':not clean_ok or bool(self.unknown),'unknown_mutation_request_ids':self.unknown,
   'actual_live_elapsed_seconds':elapsed,'within_phase_budget_observed':elapsed<=self.phase_budget,
   'worst_case_all_operations_complete_in120s_guaranteed':False,'trace':self.trace}
  cleanup_pin=None
  if not self.armed_success and not self.preserve_window:cleanup_pin=write(self.scene/('R204-INLINE-MANUAL-CLEANUP.'+self.a.operation+'-'+self.a.attempt+'.json'),companion)
  result={'machine_id':MACHINE,'observed_at_utc':now(),'run_id':self.run.name,'operation':self.a.operation,'scope':self.scope_pin,'reason':reason,'primary_error':self.primary,
   'actual_arm_success':self.armed_success,'actual_arm_token':self.token_pin,
   'sampling_window_preserved_for_Root':self.armed_success or self.preserve_window,
   'actual_qualified_new_days':self.day_contracts,'daily_checkpoint_pins':self.daily,
   'actual_phase_budget_seconds':self.phase_budget,'actual_session_headroom':self.session_room,
   'cleanup_required':self.armed_success or not clean_ok,
   'cleanup':cleanup_pin,'actual_cleanup_complete':bool(clean_ok),'unknown_mutation_request_ids':self.unknown,
   'natural_arm_attempted':self.natural_attempted,'payment_arm_attempted':self.payment_attempted,'day_action_attempted_once':self.day_attempted,
   'after_consumed':self.after_result,'new_game_value_edits':0,'external_debugger_started':False,'R06_or_full_R07_or_paid_claim':False,
   'all_original_requests_and_responses':str(self.run),'within_phase_budget_observed':elapsed<=self.phase_budget}
  write(self.out/'RESULT.actual.json',result)
  return result
def parser():
 p=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
 p.add_argument('operation',choices=('source-check','arm','advance-window','collect-cleanup'),nargs='?',default='source-check')
 p.add_argument('--entry',required=True,type=Path);p.add_argument('--entry-bytes',required=True,type=int);p.add_argument('--entry-sha256',required=True)
 p.add_argument('--qualification-validator',required=True);p.add_argument('--validator-bytes',required=True,type=int);p.add_argument('--validator-sha256',required=True)
 p.add_argument('--config',type=Path);p.add_argument('--attempt',default='a01');p.add_argument('--execute-live',action='store_true')
 p.add_argument('--max-days',type=int);p.add_argument('--seconds-budget',type=int)
 p.add_argument('--arm-token',type=Path);p.add_argument('--arm-token-bytes',type=int);p.add_argument('--arm-token-sha256')
 return p
def main():
 a=parser().parse_args();need(a.execute_live==(a.operation!='source-check'),'live phase requires explicit --execute-live')
 need(re.fullmatch('a[0-9]{2}',a.attempt) is not None,'bounded unique attempt required')
 need(a.operation!='advance-window' or (type(a.max_days) is int and 1<=a.max_days<=32 and type(a.seconds_budget) is int and 100<=a.seconds_budget<=5400),'advance needs explicit day/time bounds')
 f,pins=load_film(a);suite,q=f.suite_from(a)
 if a.operation=='source-check':
  print(json.dumps({'source_only':True,'SDK_calls':0,'desktop_calls':0,'future_q_read':False,'source_pins':pins,
   'suite_keys':sorted(suite),'scope_request_callable':callable(suite['scope'].request),'Root_actual_config_required_for_live':True},indent=2));return
 need(a.config is not None,'actual future-generated R204 IDENTITY_SCOPE is required; no prefilled scope/q')
 need(a.operation=='arm' or (a.arm_token is not None and a.arm_token_bytes and a.arm_token_sha256),'actual arm token CLI pin required')
 actor=Actor(a,f,suite,pins);result=actor.run_actor();print(json.dumps(result,ensure_ascii=False,indent=2))
 okay=result['actual_arm_success'] if a.operation=='arm' else not result['primary_error'] if a.operation=='advance-window' else result['actual_cleanup_complete']
 if result['primary_error'] or not okay or result['unknown_mutation_request_ids'] or not result['within_phase_budget_observed']:raise SystemExit(2)
if __name__=='__main__':main()
