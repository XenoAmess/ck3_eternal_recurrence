"""Small dcda filming delta over the SHA-frozen a02 staged Root helper.

No SDK, recorder or import-time game actions. Root explicitly supplies each
actual context/runtime proof. Speed3 watched bursts use existing native steps.
"""
from pathlib import Path
import argparse,importlib.util,json,sys,time

HERE=Path(__file__).resolve().parent
SEALED=HERE.parent/'locked_routes_root.py'
SEALED_SHA='01b2370c9ce0da52b2d6cb75e6a5405e0889f05a4026328c08530a9aab15fbf6'
SOURCE='dcda9fde1afa1effb75d46fe99bba4bcd9aeabcb'

def read_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value

base=read_module(SEALED,'sha_frozen_locked_routes_a02')
base.need(base.pin(SEALED)['sha256']==SEALED_SHA,'sealed a02 helper bytes changed')
clock_delta=read_module(HERE/'validate_burst.py','locked_film_clock_delta')

class Live(base.Live):
    def __init__(self,args):
        # Exact code pin above is preserved; only these reviewed configuration
        # globals adapt old1463 to dcda and the explicit actual Root profile.
        base.SOURCE=SOURCE
        base.TARGET_ASSETS=args.context.resolve().parent.name
        super().__init__(args)
        self.meta['filming_delta']=base.pin(Path(__file__),1024*1024)
        self.meta['sealed_configuration_delta']={'source_head':SOURCE,'actual_assets':str(self.assets)}
        self._refs={}
        sys.path[:0]=[str(self.repo),str(self.repo/'ck3_autonomous_player/src')]
        from xar_autoplayer.bridge import native_driver
        self.nd=native_driver
        base.need(self.nd._noncombat_sentinel_scope_speed_live_ready('committed_route',3),
                  'existing speed3 readiness unavailable; never substitute speed4/5')
        base.write_new(self.attempt/'FILMING-DELTA.actual.json',{**self.meta,'clock_consumer':base.pin(HERE/'validate_burst.py'),
            'recorder_started_by_delta':False,'raw_duration_assertion':False})
    def frame(self,name):
        o,refs=super().frame(name);self._refs[o['snapshot']['snapshot_id']]=refs;return o,refs
    def from_refs(self,refs):
        for ref in refs.values():
            actual=base.pin(ref['path']);base.need(actual['bytes']==ref['bytes'] and actual['sha256']==ref['sha256'],'pinned frame changed')
        return self.v.frame(base.load(refs['snapshot']['path'])['body'],base.load(refs['strength']['path']),self.binding)
    def strength_at(self,s,sref,name):
        row,_,_=self.request(name,'ck3_query_army_strengths',{'army_ids':[self.binding['army_id']],
            'expected_revision':s['revision'],'profile':'ordinary_core_v1'})
        ev=row.get('army_history_evidence');base.need(type(ev) is dict,'response-local scoped reference missing')
        ref=ev['raw_result_reference'];p=Path(ref['path'])
        base.need(p.is_absolute() and p.parent.resolve()==(self.assets/'state-a01/native-session/army-query-history-results').resolve()
                  and ref.get('kind')=='complete-driver-army-query-result-json-v1' and ref.get('wire_bytes_preserved') is False,'scoped raw reference differs')
        actual=base.pin(p);base.need(actual['bytes']==ref['bytes'] and actual['sha256']==ref['sha256'],'raw result pin differs')
        q=base.load(p)
        base.need(ev.get('machine_id')==self.machine and ev.get('request_id')==row['request']['request_id']
                  and q.get('query_sequence')==ev.get('query_sequence') and q.get('army_strengths_profile')=='ordinary_core_v1'
                  and (q.get('army_strengths_query_scope') or {}).get('army_ids')==[self.binding['army_id']]
                  and len(q.get('army_strengths',[]))==1,'response-local profile/query/scope differs')
        o=self.v.frame(s,q,self.binding);refs={'snapshot':sref,'strength':actual}
        self._refs[s['snapshot_id']]=refs;return o,refs
    def coherent_stop_core(self,stopped,name,stopped_ref=None):
        # Status can publish a newer public revision while the same native
        # day/Province remains paused. Never reuse the pre-status revision.
        original=next(a for a in stopped['player_armies'] if a['army_id']==self.binding['army_id'])
        for attempt in range(2):
            fresh,ref=(stopped,stopped_ref) if attempt==0 and stopped_ref is not None else self.snap(name+'-fresh-'+str(attempt))
            current=next(a for a in fresh['player_armies'] if a['army_id']==self.binding['army_id'])
            base.need(fresh['date_raw']==stopped['date_raw'] and all(current.get(k)==original.get(k) for k in
                ('army_id','owner_character_id','controllable','current_province_id','route_province_ids','route_read_status','route_source_count','in_combat','retreating')),
                'fresh post-status owned Army/date differs from original paused stop')
            try:return self.strength_at(fresh,ref,name+'-core-'+str(attempt))
            except RuntimeError as error:
                if attempt or self.pending or 'revision mismatch' not in str(error).lower():raise
        raise RuntimeError('unreachable readonly retry')
    def recover_day53145576(self):
        base.need(self.run.name=='desktop-3fevhd2-1c74096080--vanilla--R0175' and self.args.card=='R12',
                  'this readonly repair only consumes the concrete R0175 R12 completed day')
        start=53145576;end=53145600
        target=self.case/f'day-{start}.clock-complete.actual.json'
        base.need(not target.exists(),'completed day already sealed; never overwrite or replay')
        claim=base.load(self.case/f'day-{start}.once.claim.json',1024*1024)
        base.need(claim['binding']==self.binding and claim['starting_date_raw']==start and claim['target_date_raw']==end,
                  'original day claim is not this runtime/date')
        prior=base.load(self.case/'day-53145552.clock-complete.actual.json',1024*1024)
        before=self.from_refs(prior['after']);base.need(before['date']==start,'original pre-arm frame date differs')
        def original(tail,tool):
            p=self.run/'responses'/('r12-lock-window-a01-'+tail+'.json');e=base.load(p)
            base.need(e.get('machine_id')==self.machine and e.get('is_error') is False
                      and e.get('request',{}).get('tool')==tool,'original completed response differs: '+tail)
            return e,p
        arm,arm_path=original('026-arm-watch-first','ck3_execute_step')
        resume,resume_path=original('027-resume-once','ck3_execute_step')
        stop,stop_path=original('029-watch-pause','ck3_take_snapshot')
        status,status_path=original('030-watch-status','ck3_execute_step')
        base.need(resume['request']['arguments']['step']=='resume-map' and resume['body'].get('accepted') is True,
                  'original resume not positively acknowledged')
        checked=clock_delta.check(self.nd,before=before['snapshot'],after=stop['body'],arm_body=arm['body'],
            status_body=status['body'],watch_army_id=self.binding['army_id'],speed=3)
        base.need(checked['starting_date_raw']==start and checked['actual_ending_date_raw']==end,
                  'original arm/status do not complete the concrete second day')
        failed=self.run/'responses/r12-lock-window-a01-031-watched-stop-core.json'
        f=base.load(failed);base.need(f.get('is_error') is True and 'revision mismatch' in str(f).lower(),
                                    'original readonly failure does not match the observed defect')
        after,refs=self.coherent_stop_core(stop['body'],'recover-day53145576')
        value={**self.meta,'before':prior['after'],'after':refs,'arm_response':base.pin(arm_path),
            'status_response':base.pin(status_path),'original_resume_response':base.pin(resume_path),
            'original_paused_stop':base.pin(stop_path),'original_failed_readonly':base.pin(failed),
            'starting_date_raw':start,'date_raw':after['date'],'validated_burst':checked,
            'readonly_recovery':True,'Arm_Resume_status_reissued':False}
        base.write_new(target,value);return {'status':'ORIGINAL-DAY-SEALED-BY-READONLY-RECOVERY','clock_complete':base.pin(target),
            'actual_ending_date_raw':after['date'],'no_Arm_Resume_status_reissued':True}
    def recover_pending_status_day(self):
        # Only the explicitly supplied, conclusively admission-refused readonly
        # status may be newly queried. Original Arm/Resume are never reissued.
        plan=discover_pending_status_recovery(self.case,self.run,self.binding,self.machine,self.args.failed_status_response)
        before=self.from_refs(plan['prior']['after'])
        base.need(before['date']==plan['start'],'last complete clock is not original pre-arm frame')
        status,_,status_ref=self.request('recover-watch-status','ck3_execute_step',
            {'step':'research-query-tactical-daily-sentinel-v1','expected_revision':None})
        fresh,fresh_ref=self.snap('recover-post-status-fresh-0')
        after,refs=self.coherent_stop_core(fresh,'recover-post-status',fresh_ref)
        checked=clock_delta.check(self.nd,before=before['snapshot'],after=after['snapshot'],
            arm_body=plan['arm']['body'],status_body=status['body'],watch_army_id=self.binding['army_id'],speed=3)
        base.need(checked['starting_date_raw']==plan['start'] and checked['actual_ending_date_raw']==plan['end'],
                  'actual status/fresh stop did not complete the original one-day claim')
        value={**self.meta,'before':plan['prior']['after'],'after':refs,'arm_response':base.pin(plan['arm_path']),
            'status_response':status_ref,'original_resume_response':base.pin(plan['resume_path']),
            'original_paused_poll':base.pin(plan['stop_path']),'original_refused_status':base.pin(plan['failed_path']),
            'prior_clock_complete':base.pin(plan['prior_path']),'original_claim':base.pin(plan['claim_path']),
            'starting_date_raw':plan['start'],'date_raw':after['date'],'validated_burst':checked,
            'readonly_recovery':True,'Arm_Resume_reissued':False,'status_query_expected_revision':None,
            'original_poll_date_raw':plan['stop']['body']['date_raw'],'original_poll_is_not_completion_proof':True}
        target=self.case/f"day-{plan['start']}.clock-complete.actual.json"
        base.write_new(target,value)
        return {'status':'ORIGINAL-DAY-SEALED-BY-READONLY-STATUS-RECOVERY','clock_complete':base.pin(target),
            'starting_date_raw':plan['start'],'actual_ending_date_raw':after['date'],'no_Arm_Resume_reissued':True}
    def lock_wait(self):
        b=self.base();o,refs=self.frame('lock-film-position-start')
        for day in range(self.args.max_days+1):
            base.need(o['province']==b['original_province'] and o['route']==b['original_route'],
                      'original first edge ended before strict/remaining<=1day filming window; no automatic new Move')
            lock=self.current_lock(o)
            if lock['strict_native_locked']:
                strict_path=self.case/'lock.admission.actual.json'
                if not strict_path.exists():
                    base.write_new(strict_path,{**self.meta,'binding':self.binding,'locked':refs,'actual':lock,
                        'status':'FIRST-STRICT-LOCK-OBSERVED','days_advanced_this_stage':day})
                if 0<lock['first_edge_remaining_q100000']<=100000:
                    result={**self.meta,'binding':self.binding,'locked':refs,'actual':lock,
                        'status':'STRICT-LOCKED-AND-ACTUAL-REMAINING-LE1DAY','days_advanced_this_stage':day,
                        'first_strict_admission_preserved':base.pin(strict_path)}
                    base.write_new(self.case/'capture-lock.admission.actual.json',result);return result
            base.need(day<self.args.max_days,'finite film-position days exhausted; no recorder start or automatic reroute')
            # This stage remains a one-day watch, preserving each real clock;
            # it cannot deliberately run past the original front and reuse it.
            o,refs=self.day(o)
    def capture_ready(self):
        b=self.base();o,refs=self.frame('capture-ready');lock=self.current_lock(o)
        base.need(lock['strict_native_locked'] and 0<lock['first_edge_remaining_q100000']<=100000,
                  'start recording only at strict locked multi-hop first edge with actual remaining in(0,1day]')
        base.need(o['province']==b['original_province'] and o['route']==b['original_route'],'independent new normal Move first edge differs')
        base.need(o['snapshot'].get('speed')==3,'Root must observe set-speed-3 before capture-ready')
        base.need(self.args.checkpoint_receipt is not None,'preserve actual normal checkpoint receipt before recording')
        checkpoint=base.load(self.args.checkpoint_receipt);saved=(checkpoint.get('body') or {}).get('checkpoint') or {}
        base.need(checkpoint.get('machine_id')==self.machine and checkpoint.get('is_error') is False
                  and saved.get('status')=='saved' and saved.get('date_raw')==o['date']
                  and saved.get('episode_character_id')==self.binding['actor'],'actual same-date normal checkpoint receipt differs')
        result={**self.meta,'binding':self.binding,'locked':refs,'actual':lock,'normal_checkpoint_receipt':base.pin(self.args.checkpoint_receipt),
                'recording_has_not_started':True,'no_new_raw_credit':True}
        if self.args.card=='R13':
            base.need(self.args.preview_response is not None,'R13 capture-ready requires actual Root legal alternate preview')
            alt,route,preview,source=self.preview(o,self.args.preview_response)
            base.need(alt not in {o['province'],lock['front'],lock['tail']} and len(route)==2 and route[0]==lock['front']
                      and lock['tail'] not in route[1:],'film candidate must be actual two-edge alternate preserving front and avoiding old tail')
            result.update(alternate_target=alt,expected_route=route,alternate_preview=preview,preview_source=source)
        base.write_new(self.case/'capture-ready.actual.json',result);return result
    def film_action(self,kind):
        ready=base.load(self.case/'capture-ready.actual.json',1024*1024)
        base.need(ready['binding']==self.binding and ready['case']==self.args.card,'capture-ready not this actual scene/case')
        o=self.from_refs(ready['locked']);s,_=self.snap('film-before-action')
        base.need(all(s.get(k)==o['snapshot'].get(k) for k in ('snapshot_id','revision','native_revision','date_raw')),
                  'paused native frame changed since capture-ready; no guessed numeric reuse or automatic action')
        base.need(s.get('player_armies')==o['snapshot'].get('player_armies'),'Army route/state changed since capture-ready')
        details={'locked':ready['locked'],'actual':ready['actual'],'original_route':o['route'],
                 'original_province':o['province'],'locked_date':o['date'],'normal_checkpoint_receipt':ready['normal_checkpoint_receipt']}
        if kind=='halt':
            base.need(self.args.card=='R12','Halt scene must be independent R12')
            return self.action('halt','ck3_execute_step',{'step':f"halt-army-{self.binding['army_id']}",'expected_revision':s['revision']},details)
        base.need(self.args.card=='R13','typed alternate scene must be independent R13')
        details.update({k:ready[k] for k in ('alternate_target','expected_route','alternate_preview','preview_source')})
        return self.action('alt-move','ck3_move_army',{'army_id':self.binding['army_id'],
            'target_province_id':ready['alternate_target'],'expected_revision':s['revision']},details)
    def day(self,o):
        # Lock search stays exactly one day and outside raw. During filmed
        # readback, one existing sentinel spans a short first-edge window and
        # pauses at the first actual watched Province change or deadline.
        days=1
        if self.args.stage in ('postHalt-readback','postMove-readback') and o['route']:
            remaining=self.v.amount(o['movement'].get('first_route_edge_remaining_duration'),'actual remaining')
            base.need(remaining>=0,'negative remaining')
            days=min(self.args.burst_days,(remaining+99999)//100000+2)
        return self.burst(o,days)
    def burst(self,o,days):
        base.need(o['snapshot'].get('speed')==3,'existing speed3 must be observed before burst')
        start=o['date'];target=start+24*days
        before_ref=self._refs[o['snapshot']['snapshot_id']]
        key='day-'+str(start);self.claim(key,{'starting_date_raw':start,'target_date_raw':target,'watch_army_id':self.binding['army_id'],'speed':3})
        step=f"research-arm-tactical-daily-sentinel-v1-{start}-to-{target}-speed-3-mode-terminal-a-1-{self.binding['army_id']}"
        arm,_,arm_ref=self.request('arm-watch-first','ck3_execute_step',{'step':step,'expected_revision':o['snapshot']['revision']})
        armed=self.nd._normalize_tactical_daily_sentinel_status(arm['body']['tactical_daily_sentinel'])
        self.nd._validate_tactical_daily_sentinel_arm(arm['body'],armed,arm_step=step,starting_date_raw=start,
            target_date_raw=target,speed=3,mode='terminal_or_sentinel',watch_army_ids=(self.binding['army_id'],),sentinel_scope='committed_route')
        # The existing producer composite also submits resume-map with no
        # fixed revision after its successful native arm (native_driver.py).
        self.request('resume-once','ck3_execute_step',{'step':'resume-map','expected_revision':None})
        for _ in range(60):
            time.sleep(.15);s,sref=self.snap('watch-pause',paused=False)
            if s.get('paused') is True and s['date_raw']>start:break
        base.need(s.get('paused') is True and s['date_raw']>start,
                  'watched burst has not independently paused after actual date advancement; no action replay')
        status,_,status_ref=self.request('watch-status','ck3_execute_step',{'step':'research-query-tactical-daily-sentinel-v1','expected_revision':None})
        fresh,fresh_ref=self.snap('post-status-stop-fresh-0')
        after,after_ref=self.coherent_stop_core(fresh,'post-status-stop',fresh_ref)
        checked=clock_delta.check(self.nd,before=o['snapshot'],after=after['snapshot'],arm_body=arm['body'],
            status_body=status['body'],watch_army_id=self.binding['army_id'],speed=3)
        base.write_new(self.case/(key+'.clock-complete.actual.json'),{**self.meta,'before':before_ref,'after':after_ref,
            'arm_response':arm_ref,'status_response':status_ref,'starting_date_raw':start,'date_raw':after['date'],'validated_burst':checked})
        return after,after_ref
    def next_day(self):
        base.need(self.args.card=='R12','next-day stationary followup belongs to R12')
        final=base.load(self.case/'halt.arrival.actual.json',1024*1024)
        o,_=self.frame('front-before-nextday');self.v.stationary(o)
        arrival=self.from_refs(final['arrival'])
        base.need(o['date']==arrival['date'] and o['province']==arrival['province'],'followup no longer begins at observed front arrival')
        after,refs=self.burst(o,1);self.v.stationary(after)
        base.need(after['date']==arrival['date']+24 and after['province']==arrival['province'],'nextday actually moved from original front')
        value={**self.meta,'status':'ACTUAL-FRONT-ARRIVAL-PLUS-NEXTDAY-STATIONARY','frame':refs}
        base.write_new(self.case/'halt.nextday.actual.json',value);return value
    def report(self):
        b=self.base();kind='halt' if self.args.card=='R12' else 'alt-move';a=self.action_original(kind)
        final=base.load(self.case/(kind+'.arrival.actual.json'),1024*1024)
        seed=self.from_refs(b['baseline']);started=self.from_refs(b['new_move_post']);locked=self.from_refs(a['locked'])
        post=self.from_refs(final['post']);arrival=self.from_refs(final['arrival'])
        self.v.stationary(seed)
        self.v.action_once(base.load(b['initial_move_request']['path']),base.load(b['initial_move_response']['path'])['body'],
            f"move-army-{self.binding['army_id']}-to-{b['initial_target']}",seed)
        self.v.same_paused_applied(seed,started)
        preview=self.v.preview_path(base.load(b['initial_preview']['path'])['body'],seed,b['initial_target'])
        base.need(started['route']==preview and locked['route']==started['route'] and locked['province']==started['province'],
                  'normal initial Move/locked first edge differs')
        request=base.load(a['request']['path']);response=base.load(a['response']['path'])['body']
        if self.args.card=='R12':
            result=self.v.r12(locked,post,arrival,request,response)
            extra=base.load(self.case/'halt.nextday.actual.json',1024*1024);nextday=self.from_refs(extra['frame']);self.v.stationary(nextday)
            base.need(nextday['date']==arrival['date']+24 and nextday['province']==arrival['province'],'R12 nextday positive followup missing')
        else:
            result=self.v.r13(locked,post,self.from_refs(final['first_arrival']),arrival,
                base.load(a['alternate_preview']['path'])['body'],request,response,a['alternate_target'])
        clocks=sorted((base.load(p,1024*1024) for p in self.case.glob('day-*.clock-complete.actual.json')),key=lambda x:x['starting_date_raw'])
        expected=started['date'];end=arrival['date']+(24 if self.args.card=='R12' else 0);checked=[]
        for row in clocks:
            base.need(row['starting_date_raw']==expected,'actual burst clock gap or duplicate')
            before=self.from_refs(row['before']);after=self.from_refs(row['after'])
            value=clock_delta.check(self.nd,before=before['snapshot'],after=after['snapshot'],
                arm_body=base.load(row['arm_response']['path'])['body'],status_body=base.load(row['status_response']['path'])['body'],
                watch_army_id=self.binding['army_id'],speed=3)
            expected=after['date'];checked.append(value)
        base.need(expected==end,'actual burst chain does not reach final business endpoint')
        return {**self.meta,'result':result,'burst_checks':checked,'exact_one_day_manifest_not_reused':True,
            'R12_nextday_observed':self.args.card=='R12','raw_coverage_not_inferred_from_business_reads':True,'human_video_approval':False}

def discover_pending_status_recovery(case,run,binding,machine,failed_path):
    base.need(failed_path is not None,'explicit original refused status response required')
    failed_path=Path(failed_path).resolve();base.need(failed_path.parent==(run/'responses').resolve(), 'refused status not in actual run')
    pending=[]
    for p in case.glob('day-*.once.claim.json'):
        row=base.load(p,1024*1024)
        if not (case/f"day-{row['starting_date_raw']}.clock-complete.actual.json").exists():pending.append((p,row))
    base.need(len(pending)==1,'exactly one unfinished original day required')
    claim_path,claim=pending[0];start=claim['starting_date_raw'];end=claim['target_date_raw']
    base.need(claim['binding']==binding and claim['machine_id']==machine and end==start+24
              and claim['watch_army_id']==binding['army_id'] and claim['speed']==3,'original pending one-day binding differs')
    clocks=[(p,base.load(p,1024*1024)) for p in case.glob('day-*.clock-complete.actual.json')]
    base.need(bool(clocks),'original pre-arm complete clock absent')
    prior_path,prior=max(clocks,key=lambda pair:pair[1]['date_raw'])
    base.need(prior['date_raw']==start and prior.get('machine_id')==machine
              and all(prior.get(k)==claim.get(k) for k in ('run_id','runtime_proof','case_id')),
              'pending claim not contiguous with last complete clock in this runtime')
    failed=base.load(failed_path);req=failed.get('request') or {};args=req.get('arguments') or {}
    text=str(failed).lower()
    base.need(failed.get('machine_id')==machine and failed.get('is_error') is True and failed.get('body') is None
              and req.get('tool')=='ck3_execute_step' and args.get('step')=='research-query-tactical-daily-sentinel-v1'
              and type(args.get('expected_revision')) is int and 'native gameplay revision mismatch' in text,
              'only explicit status revision admission refusal is recoverable')
    rid=req['request_id']
    # Request name has two words: split by the exact suffix, not by guessing IDs.
    base.need(rid.endswith('-watch-status'),'original status request name differs')
    head=rid[:-len('-watch-status')];prefix,seq=head.rsplit('-',1);seq=int(seq)
    rows=[]
    for p in (run/'responses').glob(prefix+'-*.json'):
        e=base.load(p);r=e.get('request') or {};i=r.get('request_id','')
        try:n=int(i[len(prefix)+1:].split('-',1)[0])
        except (ValueError,TypeError):continue
        if n<seq:rows.append((n,p,e))
    step=f"research-arm-tactical-daily-sentinel-v1-{start}-to-{end}-speed-3-mode-terminal-a-1-{binding['army_id']}"
    arms=[x for x in rows if (x[2].get('request',{}).get('arguments') or {}).get('step')==step]
    base.need(len(arms)==1,'exact original Arm response not unique')
    arm_n,arm_path,arm=arms[0]
    resumes=[x for x in rows if x[0]>arm_n and (x[2].get('request',{}).get('arguments') or {}).get('step')=='resume-map']
    base.need(len(resumes)==1,'exact original Resume response not unique')
    resume_n,resume_path,resume=resumes[0]
    polls=[x for x in rows if x[0]>resume_n and x[2].get('request',{}).get('tool')=='ck3_take_snapshot']
    base.need(bool(polls),'original paused poll missing');_,stop_path,stop=max(polls,key=lambda x:x[0])
    for e in (arm,resume,stop):base.need(e.get('machine_id')==machine and e.get('is_error') is False,'original response unsuccessful/wrong machine')
    base.need(arm['body'].get('accepted') is True and resume['body'].get('accepted') is True
              and stop['body'].get('paused') is True,'original Arm/Resume ACK or paused poll missing')
    base.need(resume['request']['arguments'].get('expected_revision') is None,'original Resume mode differs')
    base.need(start<=stop['body']['date_raw']<=end,'original paused poll outside claimed day')
    return dict(claim_path=claim_path,prior_path=prior_path,prior=prior,start=start,end=end,arm_path=arm_path,arm=arm,
                resume_path=resume_path,stop_path=stop_path,stop=stop,failed_path=failed_path)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage',choices=('baseline','lock-wait','capture-ready','recover-day53145576','recover-pending-status-day','Halt-once','postHalt-readback','postHalt-nextday','Move-alt-once','postMove-readback','report'))
    for name in ('repo','context','runtime-proof','request-helper'):p.add_argument('--'+name,type=Path,required=True)
    for name in ('runtime-proof-sha256','request-helper-sha256','case-id','attempt','deadline-utc'):p.add_argument('--'+name,required=True)
    p.add_argument('--card',choices=('R12','R13'),required=True);p.add_argument('--army-id',type=int,default=18)
    p.add_argument('--max-days',type=int,default=12);p.add_argument('--burst-days',type=int,default=3)
    p.add_argument('--failed-status-response',type=Path);p.add_argument('--preview-response',type=Path);p.add_argument('--checkpoint-receipt',type=Path)
    args=p.parse_args();base.need(1<=args.max_days<=30 and 1<=args.burst_days<=3,'original finite natural-day bounds')
    live=None
    try:
        live=Live(args)
        methods={'baseline':live.baseline,'lock-wait':live.lock_wait,'capture-ready':live.capture_ready,'recover-day53145576':live.recover_day53145576,'recover-pending-status-day':live.recover_pending_status_day,
            'Halt-once':lambda:live.film_action('halt'),'postHalt-readback':lambda:live.readback('halt'),
            'postHalt-nextday':live.next_day,'Move-alt-once':lambda:live.film_action('alt-move'),
            'postMove-readback':lambda:live.readback('alt-move'),'report':live.report}
        result=methods[args.stage]();path=base.write_new(live.attempt/'RESULT.actual.json',{**live.meta,'result':result})
        print(json.dumps({'created':str(path),'source_head':SOURCE,'phases_chained':False}));return 0
    except BaseException as error:
        if live is not None:
            base.write_new(live.attempt/'FAILURE.actual.json',{**live.meta,'error_type':type(error).__name__,'error':str(error)[:4000],
                'pending_original_response':live.pending,'replay_forbidden':True,
                'capture_coverage':'Recorder45s expiry is independent; later business reads do not acquire raw credit.'})
        raise
if __name__=='__main__':raise SystemExit(main())
