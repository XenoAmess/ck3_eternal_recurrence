"""Offline delta: reuse existing producer validators for one watched multi-day stop.

No SDK, state file, executor or replacement card protocol. The caller preserves
the exact original arm/status/snapshots and uses the existing R12/R13 frame and
consequence functions. This does not forge one-day receipts for a multi-day arm.
"""
def require(ok,message):
    if not ok:raise ValueError(message)

def check(native_driver,*,before,after,arm_body,status_body,watch_army_id,speed=3):
    require(native_driver._noncombat_sentinel_scope_speed_live_ready('committed_route',speed),
            'existing scope-specific speed readiness is closed')
    require(before.get('paused') is True and after.get('paused') is True
            and before.get('map_ready') is True and after.get('map_ready') is True,'actual paused map boundaries missing')
    require(before.get('episode_run_id')==after.get('episode_run_id'),'owned campaign boundary changed')
    actor_before=before.get('played_character') or {};actor_after=after.get('played_character') or {}
    require(actor_before.get('character_id')==actor_after.get('character_id')
            and actor_before.get('alive') is True and actor_after.get('alive') is True,'owned living actor changed')
    for key in ('bridge_pid','connection_generation'):
        require(before.get('diagnostics',{}).get(key)==after.get('diagnostics',{}).get(key),'owned process boundary changed')
    require(not after.get('active_event') and not after.get('pending_character_interaction'),'modal boundary needs Root normal handling')
    arm=native_driver._normalize_tactical_daily_sentinel_status(arm_body['tactical_daily_sentinel'])
    stop=native_driver._normalize_tactical_daily_sentinel_status(status_body['tactical_daily_sentinel'])
    start=before['date_raw'];end=after['date_raw'];target=arm['target_date_raw']
    native_driver._validate_tactical_daily_sentinel_arm(arm_body,arm,arm_step=arm_body['step'],
        starting_date_raw=start,target_date_raw=target,speed=speed,mode='terminal_or_sentinel',
        watch_army_ids=(watch_army_id,),sentinel_scope='committed_route')
    native_driver._validate_tactical_daily_sentinel_stop(stop,arm_status=arm,starting_date_raw=start,
        target_date_raw=target,ending_date_raw=end,elapsed_days=(end-start)//24,speed=speed,
        mode='terminal_or_sentinel',watch_army_ids=(watch_army_id,))
    require(set(stop['trigger_reasons'])<={'date_deadline','army_position_changed','route_target_changed'},
            'unexpected combat/modal/identity stop; preserve actual result')
    return {'state':stop['state'],'generation':stop['generation'],'starting_date_raw':start,
            'actual_ending_date_raw':end,'declared_deadline_date_raw':target,
            'completed_daily_ticks':stop['completed_daily_ticks'],'trigger_reasons':stop['trigger_reasons'],
            'one_day_sampling_claim':False,'actual_arrival_requires_independent_card_frames':True}
