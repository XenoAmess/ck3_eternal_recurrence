from pathlib import Path
from datetime import datetime,timezone
import json,time
ASSETS=Path(__file__).parent/'live12004-locked-route-a01'
CONTEXT=json.loads((ASSETS/'allocated-context.actual-a01.json').read_text(encoding='utf-8'))
RUN=ASSETS/CONTEXT['identity']['run_id']
def request(identifier,tool,arguments,timeout=120):
 p=RUN/'requests'/(identifier+'.json');answer=RUN/'responses'/p.name
 if p.exists():raise RuntimeError('Request already exists; inspect result, never replay: '+identifier)
 temp=p.with_suffix('.pending')
 with temp.open('x',encoding='utf-8') as f:json.dump({'request_id':identifier,'tool':tool,'arguments':arguments},f,ensure_ascii=False,indent=2)
 temp.rename(p);deadline=time.monotonic()+timeout;incomplete=0
 while True:
  if time.monotonic()>deadline:raise TimeoutError('Same response pending/incomplete; do not replay '+identifier)
  if not answer.exists():time.sleep(.1);continue
  try:
   before=answer.stat();raw=answer.read_bytes();after=answer.stat()
   if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):incomplete+=1;time.sleep(.05);continue
   row=json.loads(raw.decode('utf-8'));break
  except json.JSONDecodeError:incomplete+=1;time.sleep(.05)
 if incomplete:
  with (ASSETS/'same-response-read-events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps({'machine_id':CONTEXT['machine_id'],'at_utc':datetime.now(timezone.utc).isoformat(),'request_id':identifier,'incomplete_reads':incomplete,'tool_requeued':False})+'\n')
 if row.get('request',{}).get('request_id')!=identifier:raise RuntimeError('Response request mismatch')
 if row.get('is_error'):raise RuntimeError(json.dumps({'id':identifier,'error':row.get('error'),'body':row.get('body'),'content':row.get('content')},ensure_ascii=False))
 return row
def snapshot(identifier):return request(identifier,'ck3_take_snapshot',{})['body']
