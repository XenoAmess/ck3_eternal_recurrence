# R19 exact push CI 实际结果

Exact HEAD `465595b67efa8f72dfc97bc0de218302c75e3bfd`；只记录此 naturally triggered push 的实际 CI。

| Workflow | Run / ref | Final result |
| --- | --- | --- |
| Official Runner CI | [37566880803](https://github.com/XenoAmess/ck3_eternal_recurrence/actions/runs/37566880803) attempt 1；push/refs/heads/master | completed/success |
| Li Yu Dao static checks | exact HEAD 无实际 run；changed files 未命中既有 workflow paths | NOT_TRIGGERED，不能记 GREEN |

实际 API/jobs/receipts 与必要 RED 日志保存在 `C:/workspace/ck3_lyd_runtime_20261004/r19-exact-ci-20261007-001/snapshot-004`。
旧 dbaf 失败与 3475 成功保留，不能外推到此 HEAD。CI 结果不授予 native compile 或 CK3 live 业务信用。
无 dispatch/rerun、主树写入、旧测试、SDK、bus、游戏或 native compile 操作。
