from pathlib import Path
ROOT=Path('D:/workspace/ck3_eternal_recurrence')
for rel,spans in {
 'ck3_autonomous_player/native_bridge/src/bridge.cpp':[(29455,29529)],
 'ck3_autonomous_player/native_bridge/src/ck3_12002_adapter.cpp':[(305,336)],
 'ck3_autonomous_player/native_bridge/src/ck3_12002_semantic_adapter.cpp':[(630,652)],
 'ck3_autonomous_player/native_bridge/src/ck3_12002_military.cpp':[(353,575)],
 'ck3_autonomous_player/native_bridge/include/xar_bridge/game_contract.hpp':[(2384,2408),(2430,2450)],
 'ck3_autonomous_player/native_bridge/src/ck3_12002_military_test.cpp':[(120,175)],
}.items():
 lines=(ROOT/rel).read_text(encoding='utf-8-sig').splitlines()
 for first,last in spans:
  print(rel,first,last)
  for i in range(first-1,min(last,len(lines))): print(f'{i+1}: {lines[i]}')
