from pathlib import Path
from datetime import datetime, timezone
import hashlib,json

HERE=Path(__file__).resolve().parent
ASSETS=Path('D:/workspace/ck3_native_war_ai_promo_work/e04-r189-window-capture-a01')
RUN=ASSETS/'desktop-3fevhd2-1c74096080--vanilla--R0189'
def read(p,limit):
 if not 0<p.stat().st_size<=limit:raise RuntimeError('bounded named input required')
 raw=p.read_bytes();return json.loads(raw.decode('utf-8-sig')),{'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
s,sp=read(RUN/'responses/r189-preview-context-a02.json',262144)
d,dp=read(ASSETS/'state-a01/native-session/driver-state.json',524288)
needles=('preview-move-army-18-to-2644','preview-move-army-18-to-2610')
hits=[]
def find(x,path=''):
 if isinstance(x,dict):
  if x.get('command') in needles or x.get('step') in needles:
   hits.append({'json_pointer':path,'value':x})
   return
  for k,v in x.items():find(v,path+'/'+str(k))
 elif isinstance(x,list):
  for i,v in enumerate(x):find(v,path+'/'+str(i))
find(d)
body=s['body'];a=next(r for r in body['player_armies'] if r['army_id']==18)
out={'schema':'xar.r189.preview-native-failure-extract.v1','machine_id':'desktop-3fevhd2-1c74096080',
 'at_utc':datetime.now(timezone.utc).isoformat(),'sources':[sp,dp],
 'context':{k:body.get(k) for k in ('snapshot_id','revision','native_revision','date_raw','paused','episode_run_id')},
 'army18':{k:a.get(k) for k in ('army_id','army_state','army_state_code','current_province_id','route_province_ids','route_read_status','in_combat','retreating')},
 'native_history_matches':hits,'metadata_outbox_empty_at_read':True,'SDK_calls':0,'large_Driver_query_reads':0}
raw=(json.dumps(out,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
if len(raw)>12288:raise RuntimeError('failure extract too large; do not copy whole ledger')
with (HERE/'FAILURES.actual.json').open('xb') as f:f.write(raw)
print(raw.decode('utf-8'))
