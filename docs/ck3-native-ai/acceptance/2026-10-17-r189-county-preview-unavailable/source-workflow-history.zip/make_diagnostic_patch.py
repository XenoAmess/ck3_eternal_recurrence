from pathlib import Path
import difflib, hashlib, json

HERE=Path(__file__).resolve().parent
ROOT=Path('D:/workspace/ck3_eternal_recurrence')
changed={}
def source(rel):
 p=ROOT/rel; raw=p.read_bytes()
 return raw.decode('utf-8').replace('\r\n','\n'),{'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def edit(text,old,new):
 if text.count(old)!=1:raise RuntimeError('unique source anchor missing: '+old[:80])
 return text.replace(old,new)
def save(rel,old,new,pin):changed[rel]=(old,new,pin)

rel='ck3_autonomous_player/native_bridge/include/xar_bridge/game_contract.hpp'
old,pin=source(rel)
reason='''enum class PreviewMoveArmyUnavailableReason {
  unspecified,
  military_bindings_incomplete,
  military_snapshot_unavailable,
  path_constructor_return_mismatch,
  worker_pre_snapshot_unavailable,
  worker_frame_not_ready,
  worker_submit_failed,
  worker_wait_failed,
  worker_reclaim_failed,
  worker_frame_unstable,
  worker_exception,
};

'''
new=edit(old,'struct PreviewMoveArmyResult {',reason+'struct PreviewMoveArmyResult {')
new=edit(new,'  std::optional<ArmyCountyEntryPreviewConditionV1> county_entry_condition_v1;',
 '''  std::optional<ArmyCountyEntryPreviewConditionV1> county_entry_condition_v1;
  PreviewMoveArmyUnavailableReason unavailable_reason =
      PreviewMoveArmyUnavailableReason::unspecified;''')
save(rel,old,new,pin)

rel='ck3_autonomous_player/native_bridge/src/ck3_12002_military.cpp'
old,pin=source(rel);start=old.index('PreviewMoveArmyResult PreviewMoveArmy(');end=old.index('\nDisbandArmyResult SubmitDisbandArmy',start)
part=old[start:end]
part=edit(part,'''      bindings.move_primary == 0 || bindings.move_secondary == 0) {
    return result;''','''      bindings.move_primary == 0 || bindings.move_secondary == 0) {
    result.unavailable_reason = game::PreviewMoveArmyUnavailableReason::military_bindings_incomplete;
    return result;''')
part=edit(part,'''  if (!ReadCurrent(world, current)) {
    return result;''','''  if (!ReadCurrent(world, current)) {
    result.unavailable_reason = game::PreviewMoveArmyUnavailableReason::military_snapshot_unavailable;
    return result;''')
part=edit(part,'''  if (bindings.construct_move_path(command.path.data()) != command.path.data()) {
    return result;''','''  if (bindings.construct_move_path(command.path.data()) != command.path.data()) {
    result.unavailable_reason = game::PreviewMoveArmyUnavailableReason::path_constructor_return_mismatch;
    return result;''')
new=old[:start]+part+old[end:];save(rel,old,new,pin)

rel='ck3_autonomous_player/native_bridge/src/ck3_12002_semantic_adapter.cpp'
old,pin=source(rel);start=old.index('bool WorkerAdapter::Run(SemanticRequest &request) const noexcept {');end=old.index('\nbool ExecuteSemanticAdapter12002',start)
part=old[start:end]
part=edit(part,'  try {','''  const auto fail_preview = [&](game::PreviewMoveArmyUnavailableReason reason) noexcept {
    if (request.operation == SemanticOperation::preview)
      request.preview.unavailable_reason = reason;
    return false;
  };
  try {''')
part=edit(part,'''    if (!pre_snapshot || !request.envelope.expected_snapshot.paused ||
        !request.envelope.expected_snapshot.map_ready) return false;''','''    if (!pre_snapshot)
      return fail_preview(game::PreviewMoveArmyUnavailableReason::worker_pre_snapshot_unavailable);
    if (!request.envelope.expected_snapshot.paused ||
        !request.envelope.expected_snapshot.map_ready)
      return fail_preview(game::PreviewMoveArmyUnavailableReason::worker_frame_not_ready);''')
part=edit(part,'''    if (submitted != ck3_11906::MainThreadQuerySubmitResultV1::submitted) return false;''','''    if (submitted != ck3_11906::MainThreadQuerySubmitResultV1::submitted)
      return fail_preview(game::PreviewMoveArmyUnavailableReason::worker_submit_failed);''')
part=edit(part,'''    return success;''','''    if (!success) {
      const auto reason = wait != ck3_11906::MainThreadQueryWaitResultV1::completed
          ? game::PreviewMoveArmyUnavailableReason::worker_wait_failed
          : reclaimed != ck3_11906::MainThreadQueryReclaimResultV1::reclaimed
              ? game::PreviewMoveArmyUnavailableReason::worker_reclaim_failed
              : game::PreviewMoveArmyUnavailableReason::worker_frame_unstable;
      return fail_preview(reason);
    }
    return true;''')
part=edit(part,'''    return false;
  }
}''','''    return fail_preview(game::PreviewMoveArmyUnavailableReason::worker_exception);
  }
}''')
new=old[:start]+part+old[end:]
new=edit(new,'''  return Run(request) ? request.preview : game::PreviewMoveArmyResult{};''','''  if (Run(request)) return request.preview;
  const auto reason = request.preview.unavailable_reason;
  // A failed mailbox transaction must still discard any route/P result.
  request.preview = {};
  request.preview.unavailable_reason = reason;
  return request.preview;''')
save(rel,old,new,pin)

rel='ck3_autonomous_player/native_bridge/include/xar_bridge/preview_move_army_unavailable_reason_v1.hpp'
header='''#pragma once
#include "xar_bridge/game_contract.hpp"

namespace xar::game {
inline const char *PreviewMoveArmyUnavailableReasonTagV1(
    PreviewMoveArmyUnavailableReason reason) noexcept {
  switch (reason) {
'''
for tag in ('unspecified','military_bindings_incomplete','military_snapshot_unavailable',
 'path_constructor_return_mismatch','worker_pre_snapshot_unavailable','worker_frame_not_ready',
 'worker_submit_failed','worker_wait_failed','worker_reclaim_failed','worker_frame_unstable','worker_exception'):
 header+=f'    case PreviewMoveArmyUnavailableReason::{tag}: return "{tag}";\n'
header+='''  }
  return "unknown_reason_enum";
}
} // namespace xar::game
'''
save(rel,'',header,None)

rel='ck3_autonomous_player/native_bridge/src/bridge.cpp'
old,pin=source(rel)
new=edit(old,'#include "xar_bridge/army_strength_query_diagnostic_v1.hpp"',
 '#include "xar_bridge/army_strength_query_diagnostic_v1.hpp"\n#include "xar_bridge/preview_move_army_unavailable_reason_v1.hpp"')
start=new.index('        } else if (step.starts_with("preview-move-army-")) {');end=new.index('        } else if (step.starts_with("move-army-")) {',start)
part=new[start:end]
part=edit(part,'              std::string_view error =','              std::string error =')
part=edit(part,'''              connected = write_frame(
                  pipe, CommandResultFrame(request_id, step, false, error));''','''              if (preview.status == xar::game::PreviewMoveArmyStatus::unavailable) {
                error += " [native_preview_status=";
                error += SignedNumber(static_cast<std::int32_t>(preview.status));
                error += ";reason=";
                error += xar::game::PreviewMoveArmyUnavailableReasonTagV1(preview.unavailable_reason);
                error += "]";
              }
              connected = write_frame(
                  pipe, CommandResultFrame(request_id, step, false, error));''')
new=new[:start]+part+new[end:];save(rel,old,new,pin)

rel='ck3_autonomous_player/native_bridge/src/ck3_12002_military_test.cpp'
old,pin=source(rel)
test='''void CheckPreviewUnavailableReasonsOnly() {
  using Reason = xar::game::PreviewMoveArmyUnavailableReason;
  Fixture f;
  auto world = World(f);
  auto missing = f.bindings;
  missing.enabled = false;
  const auto binding_failure = PreviewMoveArmy(missing, world, kUnit, 3);
  Require(binding_failure.status == PreviewMoveArmyStatus::unavailable &&
          binding_failure.unavailable_reason == Reason::military_bindings_incomplete &&
          f.validations == 0 && f.submissions == 0,
          "preview binding reason precedes all original validators");
  auto no_snapshot = world;
  no_snapshot.read_snapshot = nullptr;
  const auto snapshot_failure = PreviewMoveArmy(f.bindings, no_snapshot, kUnit, 3);
  Require(snapshot_failure.status == PreviewMoveArmyStatus::unavailable &&
          snapshot_failure.unavailable_reason == Reason::military_snapshot_unavailable &&
          f.validations == 0 && f.submissions == 0,
          "preview snapshot reason is distinct without added calls");
  auto wrong_constructor = f.bindings;
  wrong_constructor.construct_move_path = [](void *) noexcept -> void * { return nullptr; };
  const auto constructor_failure = PreviewMoveArmy(wrong_constructor, world, kUnit, 3);
  Require(constructor_failure.status == PreviewMoveArmyStatus::unavailable &&
          constructor_failure.unavailable_reason == Reason::path_constructor_return_mismatch &&
          f.validations == 1 && f.submissions == 0 && f.move_destroyed == 0,
          "preview mismatch preserves one validator and no action or invented cleanup");
}
'''
new=edit(old,'} // namespace\n\nint main() {',test+'''} // namespace

int main(int argc, char **argv) {
  if (argc == 2 && std::strcmp(argv[1], "--preview-unavailable-reasons-only") == 0) {
    CheckPreviewUnavailableReasonsOnly();
    std::cout << "PASS new preview unavailable reason cases only\\n";
    return 0;
  }''')
save(rel,old,new,pin)

patch=''
for rel,(old,new,pin) in changed.items():
 patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),
   fromfile='a/'+rel if old else '/dev/null',tofile='b/'+rel))
with (HERE/'preview-unavailable-reasons-a02.relative.patch').open('x',encoding='utf-8',newline='\n') as f:f.write(patch)
meta={'schema':'xar.preview-unavailable.source-candidate.v1','machine_id':'desktop-3fevhd2-1c74096080',
 'proof_layer':'source_candidate_only','native_build_or_execution':'NOTRUN',
 'source_pins':[pin for old,new,pin in changed.values() if pin],
 'post_pins':[{'path':rel,'bytes':len(new.encode('utf-8')),'sha256':hashlib.sha256(new.encode('utf-8')).hexdigest()}
  for rel,(old,new,pin) in changed.items()],
 'old_tests_rerun':0,'native_calls_added':0,'guard_relaxations':0,
 'future_new_fixture_only_argument':'--preview-unavailable-reasons-only',
 'worker_failure_fixture':'not authored/run; requires coherent mailbox fixture qualification',
 'actual_cause_identified':False,'current_wire_numeric_status_observed':False}
with (HERE/'CANDIDATE.SOURCE-a02.json').open('x',encoding='utf-8') as f:json.dump(meta,f,indent=2);f.write('\n')
print(json.dumps({'patch_bytes':len(patch.encode('utf-8')),'files':len(changed),'native_build':'NOTRUN'}))
