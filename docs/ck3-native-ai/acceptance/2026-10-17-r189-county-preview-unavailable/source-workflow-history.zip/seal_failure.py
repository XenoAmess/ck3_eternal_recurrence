from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile

HERE=Path(__file__).resolve().parent
RUN=Path('D:/workspace/ck3_native_war_ai_promo_work/e04-r189-window-capture-a01/desktop-3fevhd2-1c74096080--vanilla--R0189')
def pin(p):
 raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
failurepins=[]
for name in ('r189-preview-2644-once-a01.json','r189-preview-2610-once-a01.json'):
 p=RUN/'responses'/name
 if p.stat().st_size>8192:raise RuntimeError('only named small failures allowed')
 raw=p.read_bytes();row=json.loads(raw.decode('utf-8-sig'))
 if row.get('machine_id')!='desktop-3fevhd2-1c74096080' or row.get('is_error') is not True:raise RuntimeError('wrong actual failure')
 failurepins.append({'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
finalpatch=HERE/'preview-unavailable-reasons-a02.relative.patch'
keep={'preview-unavailable-reasons-a02.relative.patch','CANDIDATE.SOURCE-a02.json','FAILURES.actual.json','ROOT-NATIVE-FAILURE.md'}
derived=[p for p in HERE.iterdir() if p.is_file() and p.name not in keep]
manifest=[pin(p) for p in sorted(derived)]
archive=HERE/'SOURCE-WORKFLOW-HISTORY.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(derived):z.write(p,p.name)
# Reclaim only these exact unsealed derived workflow files, after byte-equal
# archive verification. No recursive deletion and no sibling/main paths.
with zipfile.ZipFile(archive) as z:
 for p in derived:
  if p.resolve().parent!=HERE.resolve() or z.read(p.name)!=p.read_bytes():raise RuntimeError('archive verification failed')
for p in derived:p.unlink()
out={'schema':'xar.r189.preview-unavailable.actual-delivery.v1','machine_id':'desktop-3fevhd2-1c74096080',
 'sealed_at_utc':datetime.now(timezone.utc).isoformat(),'status':'READY_SOURCE_CANDIDATE_NATIVE_NOTRUN',
 'actual_preview_attempts':2,'attempt_limit':5,'stop_current_preview_batch':True,
 'actual_county_condition_result':None,'raw_numeric_native_status_observed':False,
 'source_conditioned_default_enum':'unavailable','source_enum_ordinal_NOT_raw':11,
 'actual_failure_receipts':failurepins,'failure_extract':pin(HERE/'FAILURES.actual.json'),
 'final_patch':pin(finalpatch),'final_source_contract':pin(HERE/'CANDIDATE.SOURCE-a02.json'),
 'knowledge':pin(HERE/'ROOT-NATIVE-FAILURE.md'),'workflow_history':pin(archive),'archived_exact_derived_files':manifest,
 'validation':{'final_git_apply_check_exit':0,'native_build_or_execution':'NOTRUN','new_native_fixture_cases_authored':3,
  'future_fixture_only_arg':'--preview-unavailable-reasons-only','old_tests_rerun':0,'SDK_calls':0,'new_EXE_bytes':0,
  'large_army_query_or_save_reads':0,'main_writes':0},
 'Root_next':'keep R189 stopped for R04; finish current lawful filming/close. Review/rebuild this coherent candidate later; qualify only new failure cases and one fresh bound native preview before resuming county search.',
 'credit_added':False,'canonical_copyplan':[
  {'from':'ROOT-NATIVE-FAILURE.md','to':'docs/ck3-native-ai/episode04-r189-county-preview-unavailable-12004.md'},
  {'from':'DELIVERY.actual.json','to':'docs/ck3-native-ai/acceptance/2026-10-17-r189-county-preview-unavailable/DELIVERY.actual.json'},
  {'from':'SOURCE-WORKFLOW-HISTORY.zip','to':'docs/ck3-native-ai/acceptance/2026-10-17-r189-county-preview-unavailable/source-workflow-history.zip'}],
 'storage':{'derived_files_archived_then_removed_exactly':True,'kept_final_patch_uncompressed':True,
 'package_limit_bytes':65536,'review_at_utc':'2026-10-19T00:00:00Z'}}
for _ in range(4):
 raw=(json.dumps(out,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
 out['total_package_bytes']=sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())+len(raw)
raw=(json.dumps(out,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
if sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())+len(raw)>65536:raise RuntimeError('package over small limit')
with (HERE/'DELIVERY.actual.json').open('xb') as f:f.write(raw)
print(json.dumps(pin(HERE/'DELIVERY.actual.json')))
print(json.dumps({'patch':pin(finalpatch),'package_bytes':sum(p.stat().st_size for p in HERE.iterdir() if p.is_file())}))
