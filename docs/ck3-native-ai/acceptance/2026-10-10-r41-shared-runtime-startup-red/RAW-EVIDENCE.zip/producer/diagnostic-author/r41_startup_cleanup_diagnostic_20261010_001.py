"""R41 existing-file diagnosis and current read-only process enumeration only."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import psutil

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
RUN = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0041')
STATE = Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-003/state')
SOURCE = Path('C:/csr4')
OUT = BASE / 'r41-startup-and-cleanup-diagnostic-20261010-001'

def now():
    return datetime.now(timezone.utc).isoformat()

def ref(path):
    raw = path.read_bytes()
    return {'path':str(path.resolve()), 'bytes':len(raw), 'sha256':hashlib.sha256(raw).hexdigest()}

def put(name, value):
    path = OUT / name
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')
    return ref(path)

def main():
    OUT.mkdir()
    report_path = RUN / 'native-report.json'
    original = json.loads(report_path.read_bytes())
    restore = original['saved_campaign_restore']
    startup = restore.get('startup_observations', [])
    frames = restore.get('observations', [])
    controls = sorted((STATE / 'control').iterdir())
    watchdog_path = next(path for path in controls if path.name.endswith('.watchdog_start.json'))
    watchdog = json.loads(watchdog_path.read_bytes())
    exit_path = RUN / 'host-original-process-exit.json'
    host_exit = json.loads(exit_path.read_bytes())
    known = {watchdog[key] for key in ('parent_pid', 'watchdog_pid', 'watchdog_parent_pid')}
    known.add(json.loads((RUN / 'host-supervisor-started.json').read_bytes())['pid'])
    census = {'started_at_utc':now(), 'method':'psutil.process_iter current process enumeration',
        'known_pids':sorted(known), 'processes':[], 'errors':[], 'signals':0,
        'handles_reopened':False, 'historical_original_handle_exit_proven':False}
    known_rows = {}
    for process in psutil.process_iter(['pid', 'name', 'create_time'], ad_value=None):
        row = process.info
        name = (row.get('name') or '').casefold()
        if row['pid'] in known:
            known_rows[str(row['pid'])] = dict(row)
        if name in {'ck3.exe', 'ffmpeg.exe', 'obs64.exe', 'obs32.exe'}:
            census['processes'].append(dict(row))
        elif row.get('name') is None:
            census['errors'].append({'pid':row['pid'], 'reason':'process name unavailable during enumeration'})
    census.update(finished_at_utc=now(), known_pid_current_rows={str(pid):known_rows.get(str(pid)) for pid in sorted(known)})
    census['ck3_and_named_recorders_absent_now'] = not census['processes'] and not census['errors']
    census_ref = put('CURRENT-PROCESS-CENSUS.actual.json', census)
    cuts = []
    for filename in ('debug.log', 'game.log', 'error.log'):
        path = STATE / 'profile/logs' / filename
        lines = path.read_text(encoding='utf-8-sig', errors='replace').splitlines()
        literals = ('LoadSave', 'Start loading of history', 'End loading of history',
            'Setup powerful vassals', 'Setup completion (history loaded)', 'InGame',
            'Checksum Wait For Job Done')
        matches = [{'line':index, 'text':line} for index,line in enumerate(lines,1)
            if any(literal in line for literal in literals)]
        cuts.append({'source':ref(path), 'line_count':len(lines), 'matches':matches,
            'literal_counts':{literal:sum(literal in line for line in lines) for literal in literals},
            'last_lines':[{'line':index, 'text':line} for index,line in enumerate(lines,1)][-8:]})
    log_ref = put('LOG-CUTS.actual.json', cuts)
    source_cuts = []
    selections = {
        'ck3_autonomous_player/src/xar_autoplayer/runtime.py':[(1939,1980),(2708,2775),(2860,2888),(3093,3159)],
        'ck3_autonomous_player/src/xar_autoplayer/native_session.py':[(985,1005),(1452,1464),(1499,1511),(1561,1607)],
        'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py':[(3221,3238),(3645,3663)],
    }
    for relative, ranges in selections.items():
        path = SOURCE / relative
        lines = path.read_text(encoding='utf-8-sig').splitlines()
        source_cuts.append({'source':ref(path), 'cuts':[{'first_line':start, 'last_line':end,
            'lines':[{'line':index,'text':lines[index-1]} for index in range(start,end+1)]} for start,end in ranges]})
    source_ref = put('SOURCE-CUTS.actual.json', source_cuts)
    small_names = ('host-original-process-exit.json','host-started.json','host-supervisor-started.json',
        'launch-intent.json','host-stdout.log','host-stderr.log','native-report.session.log')
    inputs = [ref(report_path), ref(watchdog_path), *[ref(RUN/name) for name in small_names]]
    result = {
        'schema':'lyd.r41.startup-and-cleanup-readonly-diagnostic.v1', 'observed_at_utc':now(),
        'status':'STARTUP_RED_WITH_SOURCE_QUALIFIED_FAILURE_CLEANUP_AND_CURRENT_ABSENCE',
        'source_root':str(SOURCE), 'run_directory':str(RUN), 'state_directory':str(STATE),
        'original_status':original['status'], 'original_error':original['error'],
        'original_cleanup_ok':original['cleanup_ok'], 'original_session':original['session'],
        'original_managed_thread_finished':original['managed_session_thread_finished'],
        'started_at':original['started_at'], 'finished_at':original['finished_at'],
        'startup_observation_count':len(startup),
        'startup_status_counts':dict(Counter(row.get('status') for row in startup)),
        'startup_first_last':[startup[0],startup[-1]] if startup else [],
        'saved_native_frame_count':len(frames), 'steps':original['steps'],
        'injector_attempt_directory_exists':(STATE/'injector-attempts').exists(),
        'native_wire_exists':Path(original['native_wire']).exists(),
        'control_directory_rows':[ref(path) for path in controls if path.is_file()],
        'control_absence':{name:not (STATE/'control'/name).exists() for name in (
            'ck3.json','unsafe-cleanup.json', f"watchdog-{watchdog['nonce']}.ready.json")},
        'launch_failed_receipt_present':False,
        'host_original_popen_exit':host_exit,
        'cleanup_findings':{
            'runtime_exception_is_after_cleanup_checks':True,
            'source_path':'runtime.py:3109-3143',
            'source_contract':['retained process no longer alive','resumed Job active count zero',
                'injector cleanup attestation required if injected','job and original process handles closed',
                'authenticated watchdog absent or pinned/waited exit','unsafe/ready/pid markers removed'],
            'host_summary_gap':'launch throws before returning SessionHandle; native_session raises instead of returning its local report; host session.report remains null and cleanup_ok only accepts report.shutdown.',
            'historical_job_count_raw_receipt':None, 'historical_game_exit_code':None,
            'normal_game_exit_zero':False, 'typed_normal_exit':False,
            'current_census_is_not_original_handle_exit_evidence':True,
        },
        'start_minimized':False, 'minimized_cause_claimed':False,
        'early_injection_interference_cause':None,
        'interpretation':'No Setup completion marker reached before the same 600s deadline; delayed injection was never admitted. This does not prove or disprove early-injection interference.',
        'minimal_future_evidence_supplement':'Persist launch-failure cleanup operands after existing checks and attach that honest failure cleanup receipt to the raised exception/host error path. Preserve startup RED and native/game success false; do not synthesize shutdown or normal0.',
        'inputs':inputs, 'current_census':census_ref, 'log_cuts':log_ref, 'source_cuts':source_ref,
        'game_actions':0, 'sdk_calls':0, 'bus_calls':0, 'process_signals':0, 'repository_edits':0,
        'budget_changed':False, 'business_pass':False,
    }
    result_ref = put('REPORT.actual.json',result)
    index = put('INDEX.json',{'schema':'lyd.readonly-diagnostic-index.v1','author':ref(Path(__file__)),
        'files':[result_ref,census_ref,log_ref,source_ref], 'large_raw_files_referenced_only':inputs})
    print(json.dumps({'index':index,'report':result_ref,'census':census_ref,
        'startup_observations':len(startup),'saved_native_frames':len(frames),
        'current_ck3_recorders':census['processes'],'known_current':census['known_pid_current_rows'],
        'enumeration_errors':census['errors']},ensure_ascii=False))

if __name__ == '__main__':
    main()
