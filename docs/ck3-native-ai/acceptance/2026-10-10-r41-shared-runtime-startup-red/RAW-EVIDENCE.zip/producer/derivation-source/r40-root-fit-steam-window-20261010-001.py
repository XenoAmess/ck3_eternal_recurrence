"""Restore/fit the official Steam window so the fresh-frame probe can move it."""
from pathlib import Path
from datetime import datetime,timezone
import json
import hashlib
import ctypes
import psutil
import pyautogui
import win32gui
import win32process
from pywinauto import Desktop

B=Path('C:/workspace/ck3_lyd_runtime_20261004')
out=Path('C:\\workspace\\ck3-common-runtime\\runs\\bf-202609141645-5434332d4d--li-yu-dao--R0040\\steam-window-fit-002')
if out.exists():
    assert out.is_dir() and not any(out.iterdir())
else:
    out.mkdir()
hwnd=263104
assert win32gui.IsWindowVisible(hwnd)
pid=win32process.GetWindowThreadProcessId(hwnd)[1]
assert pid==7216
exe=Path(psutil.Process(pid).exe()).resolve()
assert str(exe).lower().startswith('c:\\program files (x86)\\steam\\')
before={'rect':list(win32gui.GetWindowRect(hwnd)),'placement':win32gui.GetWindowPlacement(hwnd),'zoomed':bool(ctypes.windll.user32.IsZoomed(hwnd))}
win32gui.ShowWindow(hwnd,9)
width,height=pyautogui.size()
rect=win32gui.GetWindowRect(hwnd)
if rect[0]<20 or rect[1]<20 or rect[2]>width-20 or rect[3]>height-20:
    win32gui.SetWindowPos(hwnd,0,40,40,min(1600,width-80),min(1000,height-80),0x0004|0x0010)
element=Desktop(backend='uia').window(handle=hwnd).wrapper_object().element_info.element
assert element.CurrentProcessId==pid
element.SetFocus()
assert win32gui.GetForegroundWindow()==hwnd
image=out/'steam-restored.png'
pyautogui.screenshot().save(image)
obj={'utc':datetime.now(timezone.utc).isoformat(),'hwnd':hwnd,'pid':pid,'before':before,'after_rect':list(win32gui.GetWindowRect(hwnd)),'screen_size':[width,height],'image_sha256':hashlib.sha256(image.read_bytes()).hexdigest(),'method':'Win32 ShowWindow SW_RESTORE and fit; UIA SetFocus','keyboard_or_mouse_input_sent':False,'steam_mode_mutation_requested':False,'offline_visual_confirmed':None}
with (out/'RECEIPT.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,indent=2);f.write('\n')
print(json.dumps(obj))
