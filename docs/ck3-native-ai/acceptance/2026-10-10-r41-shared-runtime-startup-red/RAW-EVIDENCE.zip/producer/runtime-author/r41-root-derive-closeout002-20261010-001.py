from pathlib import Path
import hashlib
import json
import subprocess
import sys

base = Path('C:/workspace/ck3_lyd_runtime_20261004')
old = base / 'r41-root-closeout-20261010-001.py'
new = base / 'r41-root-closeout-20261010-002.py'
text = old.read_text(encoding='utf-8')
text = text.replace('matches = []\nerrors = []', 'matches = []\nexpected_allocation_supervision = []\nerrors = []')
text = text.replace("        args = ' '.join(row.get('cmdline') or []).lower()", "        argv = row.get('cmdline') or []\n        args = ' '.join(argv).lower()\n        if 'allocate' in argv and 'tools/ck3_mod_acceptance.py' in argv:\n            expected_allocation_supervision.append(row)\n            continue")
text = text.replace("'case_processes': matches, 'process_read_errors': errors,", "'case_processes': matches, 'expected_allocation_supervision': expected_allocation_supervision, 'process_read_errors': errors,")
with new.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(text)
with (base / 'r41-root-closeout002-derivation-20261010-001.json').open('x', encoding='utf-8') as stream:
    json.dump({'source': str(old), 'source_sha256': hashlib.sha256(old.read_bytes()).hexdigest(),
        'new': str(new), 'new_sha256': hashlib.sha256(new.read_bytes()).hexdigest(),
        'reason': 'Original census matched the expected still-running public allocate parent and recorder. Classify and preserve them as keeper supervision; do not treat them as game/MCP processes.',
        'old_failed_before_mutating_display_or_STOP': True}, stream, indent=2)
raise SystemExit(subprocess.run([sys.executable, '-B', '-X', 'utf8', str(new)]).returncode)
