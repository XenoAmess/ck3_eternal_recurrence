from pathlib import Path
from datetime import datetime,timezone
import subprocess,sys,json,hashlib
output=Path(sys.argv[1]);argv=sys.argv[2:]
assert argv and not output.exists();output.mkdir(parents=True)
started=datetime.now(timezone.utc).isoformat()
with (output/'stdout.log').open('xb') as stdout,(output/'stderr.log').open('xb') as stderr:
 result=subprocess.run(argv,cwd='C:/workspace/ck3_eternal_recurrence',stdout=stdout,stderr=stderr)
def pin(p):
 raw=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
packet={'schema':'ck3-recorded-actual-command-v1','argv':argv,'cwd':'C:/workspace/ck3_eternal_recurrence',
 'started_at_utc':started,'finished_at_utc':datetime.now(timezone.utc).isoformat(),'exit_code':result.returncode,
 'stdout':pin(output/'stdout.log'),'stderr':pin(output/'stderr.log')}
with (output/'RESULT.actual.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(packet,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(packet))
raise SystemExit(result.returncode)
