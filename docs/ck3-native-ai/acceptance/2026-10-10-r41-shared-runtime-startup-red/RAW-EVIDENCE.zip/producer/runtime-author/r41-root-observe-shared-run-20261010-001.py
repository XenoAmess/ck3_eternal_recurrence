from pathlib import Path
from datetime import datetime, timezone
import json
import hashlib

run = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0041')
logs = Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-003/state/profile/logs')
out = {'at_utc': datetime.now(timezone.utc).isoformat()}
for relative in ('host-original-process-exit.json', 'case-output/case-error-preserved.json',
    'case-output/transaction-control-case-result.json', 'case-output/normal-close-result.json', 'native-report.json'):
    path = run / relative
    if not path.exists():
        out[relative] = None
        continue
    raw = path.read_bytes()
    value = json.loads(raw)
    item = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    if relative == 'native-report.json':
        item.update({key: value.get(key) for key in ('status', 'phase', 'error', 'finished_at',
            'managed_session_done', 'managed_session_thread_finished', 'cleanup_ok')})
        saved = value.get('saved_campaign_restore') or {}
        observations = saved.get('observations') or []
        item.update(step_count=len(value.get('steps') or []), saved_status=saved.get('status'),
            observation_count=len(observations), startup_observation_count=len(saved.get('startup_observations') or []),
            last_frame=(observations[-1].get('frame') if observations else None),
            saved_launch=value.get('saved_campaign_launch'),
            shutdown=((value.get('session') or {}).get('report') or {}).get('shutdown'))
    else:
        item.update({key: value.get(key) for key in ('status', 'error', 'exit_code', 'returncode',
            'transaction_control_pass', 'business_actions_submitted', 'saved', 'normal_close_qualified',
            'ck3_exit_code', 'business_pass', 'product_release_pass')})
    out[relative] = item
for name in ('debug.log', 'error.log'):
    path = logs / name
    if path.exists():
        with path.open('rb') as stream:
            stream.seek(max(0, path.stat().st_size - 16000))
            lines = stream.read().decode('utf-8', 'replace').splitlines()
        out[name] = {'bytes': path.stat().st_size, 'tail': lines[-4:]}
dest = run / 'root-observations'
dest.mkdir(exist_ok=True)
stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
with (dest / (stamp + '.json')).open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(out, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps(out, ensure_ascii=False, indent=2))
