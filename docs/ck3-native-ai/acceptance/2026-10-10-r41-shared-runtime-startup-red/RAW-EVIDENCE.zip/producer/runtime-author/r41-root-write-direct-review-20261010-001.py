from pathlib import Path
from datetime import datetime, timezone
import json
import hashlib

run = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0041')
def pin(path):
    raw = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
def put(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

path = run / 'direct-review-001/challenge.json'
challenge = json.loads(path.read_bytes())
observed = 'e6eaeb46d021d6e992b2fcf2bd86d202'
if observed != challenge['nonce']:
    raise SystemExit('Visual nonce does not match challenge')
proof = {'schema': 'ck3-mod-acceptance-direct-review-v1',
    'reviewed_at_utc': datetime.now(timezone.utc).isoformat(), 'reviewer': '/root',
    'direct_image_review': True, 'steam_offline_confirmed': True, 'observed_nonce': observed,
    'run_id': challenge['run_id'], 'screen_task': challenge['screen_task'], 'challenge': pin(path),
    **{key: challenge[key] for key in ('frozen_argv', 'image', 'review_image')},
    'observed_text': 'Root directly viewed original moved Steam pixels and nonce image: 离线模式; taskbar 5:48 2026/10/10. Actual movement and 1920x1080 current desktop pixels observed.',
    'business_pass': False}
out = run / 'direct-review-001/operator-review.json'
put(out, proof)
context = json.loads((run / 'ready-context.json').read_bytes())
context.update(proof=str(out), challenge=str(path), observed_nonce=observed, reviewer='/root')
put(run / 'reviewed-context.json', context)
print(json.dumps({'proof': pin(out), 'context': pin(run / 'reviewed-context.json')}))
