from pathlib import Path
import hashlib,json
b=Path('C:/workspace/ck3_lyd_runtime_20261004');old=b/'r41-root-closeout-20261010-002.py';new=b/'r42-root-closeout-20261010-001.py'
text=old.read_text(encoding='utf-8')
changes=[('--R0041','--R0042'),('20261010-a03','20261010-a04'),
    ('lyd-transaction-control-20261010-003','lyd-transaction-control-20261010-004'),('C:/csr4/','C:/csr5/'),
    ('7:01 2026/10/10','8:37 2026/10/10'),('R41 pre-injection startup timeout','R42 debug-only pre-injection startup timeout'),
    ("host_exit = json.loads((run / 'host-original-process-exit.json').read_bytes())", "host_exit = json.loads((run / 'host-original-process-exit.json').read_bytes())\nobserver_exit = json.loads((run / 'observer-retained-handle-exit.json').read_bytes())\nassert observer_exit['pid'] == 9988 and observer_exit['actual_exit_code'] == 1 and observer_exit['original_createprocess_handle'] is False"),
    ("'historical_host_cleanup_ok': report.get('cleanup_ok'), 'historical_ck3_exit_code': None,", "'independent_observer_handle_exit': observer_exit, 'historical_host_cleanup_ok': report.get('cleanup_ok'), 'historical_ck3_exit_code': None,"),
    ('Fresh empty process/control census permits scene release; it does not replace missing historical native shutdown evidence.',
     'Independent observer handle proves actual CK3 exit1; fresh census permits release. Original CreateProcess-handle and Job shutdown records are still missing; cleanup_ok=false and no typed normal0 remain unchanged.')]
for before,after in changes:
    assert before in text,before;text=text.replace(before,after)
compile(text,str(new),'exec')
with new.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
with (b/'r42-root-closeout-derivation-20261010-001.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'original_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'derived_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'changes':changes},f,indent=2);f.write('\n')
print(str(new))
