from datetime import datetime,timezone,timedelta
from pathlib import Path
import hashlib,json
root=Path('C:/workspace/ck3_eternal_recurrence')
now=datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M CST')
paragraphs=(
    'R41失败证据与failed-launch前驱分配修正已通过rebase普通推送至0c0e36e21164d55cd9f47d2d8ab9ae7a5cbf3f63。'
    '它保留原cleanup_ok=false、session.report=null及原CK3/Job退出未知；新分支只允许已安全结束、当前进程和控制文件为空且原keeper/CAS已释放的失败启动作为后继，不授normal0或业务信用。原八项边界测试PASS；远端整合后26项关闭/审核/poll测试及一项initial-plan-failure测试PASS。最初组合调用漏传--host-source退出2，分开按正式CLI执行后通过，原失败保留。\n\n'
    'Source05固定为27644fdc18e693990e43794af62ebf13db523aef，单父Source04 919bae0f4，只应用作者3704561725e583d9c9fc10f4c47c1523bb1d9643相对其父0c0e36e的五路径Python增量。'
    '共享-debug_mode默认关闭，由单一manifest显式启用；同PID/Job、一次loadsave、600秒绝对deadline、加载完成后注入及严格native守卫不变。主仓相关93项首跑有一旧测试mtime失败，固定测试marker时间后14项PASS，另79项原PASS；不把首跑写成全绿。冻结Source05另14项生命周期、4项global路由及host help通过。全native目录仅host Python变化，C++/CMake输入逐文件相同后复用原Source02的cbr2产物，没有声称编译当前master全部native功能。\n\n'
    '本机新全局runtime为C:/workspace/ck3-common-runtime/20261010-004/runtime.local.json；R42冷输入prepare/preflight已实际0，71正式文件+6 overlay、原91MB seed与预算保持。'
    '缺失C:/workspace/ck3-upgrade-20261008不再是任何依赖。精确0c0e Official38006953109 FAILURE、Linear38006953137 SUCCESS、LiYu NOT_TRIGGERED；实际错误是一个Workshop cache测试缺失审核上下文context_path，测试夹具窄修与证据独立交付，不改生产resolver或追认旧head成功。\n\n'
    '当前R42尚未分配/启动，后续先完成上述夹具修复的普通发布，再获取当次新鲜Steam离线图与独占现场执行唯一debug变量对照。归档可在外置目录与实机等待并行，冻结现场期间不改跟踪文件。正式I3b/C3/I4及一期仍NOT_GREEN，75%仅工作量估计，未新增实机业务PASS；启动窗口仍最多600秒，产品完成日期待能力恢复后的实际业务结果。\n'
)
paths=['docs/ck3-native-ai/2026-10-10-local-common-runtime-rebuild.md',
    'docs/li-yu-dao/2026-10-09-progress.md','docs/autonomous-agent-progress/daily/2026-10-10.md',
    'docs/autonomous-agent-progress/weekly/2026-W41.md']
rows=[]
for name in paths:
    p=root/name;before=p.read_bytes()
    with p.open('a',encoding='utf-8',newline='\n') as f:
        f.write('\n\n## '+now+'：本机Source05与R42单变量对照准备\n\n'+paragraphs)
    after=p.read_bytes();rows.append({'path':name,'before_sha256':hashlib.sha256(before).hexdigest(),
        'after_sha256':hashlib.sha256(after).hexdigest(),'after_bytes':len(after)})
out=Path('C:/workspace/ck3_lyd_runtime_20261004/r42-root-progress-before-launch-20261010-001.json')
with out.open('x',encoding='utf-8',newline='\n') as f:json.dump({'at_cst':now,'files':rows},f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'receipt':str(out),'files':paths}))
