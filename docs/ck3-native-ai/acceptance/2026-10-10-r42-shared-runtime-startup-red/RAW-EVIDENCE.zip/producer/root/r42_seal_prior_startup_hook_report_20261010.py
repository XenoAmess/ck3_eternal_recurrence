from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

base = Path('C:/workspace/ck3_lyd_runtime_20261004')
out = base / 'r42-prior-fixture-startup-hook-sourceonly-20261010-001'
graph = json.loads((out / 'CALLGRAPH.actual.json').read_text(encoding='utf-8'))
classes = json.loads((out / 'SOURCE-CLASSES.reused.json').read_text(encoding='utf-8'))
extra_roles = {'entry', 'observer', 'i4_single_event', 'charter'}


def ref(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def create(name, value):
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    with (out / name).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
    return ref(out / name)


def source(variant, role, relative):
    return next(row for row in graph['source_refs'] if
        (row['variant'], row['role'], row['relative']) == (variant, role, relative))


def normalized_block(row, name):
    text = Path(row['raw_copy']).read_text(encoding='utf-8-sig')
    lexer = re.compile(r'\#[^\n]*|"(?:\\.|[^"\\])*"|[^\s{}=<>!#"]+|[{}=<>!]')
    tokens = [match.group() for match in lexer.finditer(text) if not match.group().startswith('#')]
    start = next(n for n in range(len(tokens) - 2) if tokens[n:n + 3] == [name, '=', '{'])
    depth = 1
    end = start + 3
    while depth:
        depth += (tokens[end] == '{') - (tokens[end] == '}')
        end += 1
    return tokens[start:end]


effect_relative = 'common/scripted_effects/lyd_i3b_commit_effects.txt'
event_relative = 'events/lyd_factory_operation_diagnostic.txt'
R38_effect = source('R38', 'diagnostic_stage', effect_relative)
R41_effect = source('R41', 'diagnostic_stage', effect_relative)
R38_event = source('R38', 'diagnostic_stage', event_relative)
R41_event = source('R41', 'diagnostic_stage', event_relative)
business_collisions = [row for row in graph['cross_role_definition_collisions'] if row['name'] != 'tags']
collisions = []
for row in business_collisions:
    old = normalized_block(R38_effect, row['name'])
    new = normalized_block(R41_effect, row['name'])
    assert old == new
    collisions.append({'name': row['name'], 'R38_R41_diagnostic_tokens_equal': True,
        'definitions': row['definitions'], 'R38_source': R38_effect['source'], 'R41_source': R41_effect['source']})
extra_names = {row['name'] for row in graph['definitions'] if row['role'] in extra_roles and row['relative'] != 'descriptor.mod'}
references = []
lexer = re.compile(r'(?P<comment>\#[^\n]*)|(?P<string>"(?:\\.|[^"\\])*")|(?P<word>[^\s{}=<>!#"]+)|[{}=<>!]')
for row in graph['source_refs']:
    if row['role'] != 'production' or row['relative'] == 'descriptor.mod':
        continue
    text = Path(row['raw_copy']).read_text(encoding='utf-8-sig')
    for match in lexer.finditer(text):
        if match.lastgroup == 'comment':
            continue
        value = match.group().strip('"')
        if value in extra_names:
            references.append({'name': value, 'source': row['source'], 'relative': row['relative'],
                'line': text.count('\n', 0, match.start()) + 1})
assert not references
assert not graph['extra_on_action_definitions']
assert not graph['descriptor_replace_path_assignments']


def line(row, pattern):
    return [{'line': n, 'text': text} for n, text in enumerate(Path(row['raw_copy']).read_text(encoding='utf-8-sig').splitlines(), 1)
        if re.search(pattern, text)]


decision_names = {row['name'] for row in graph['extra_decision_entrypoints']}
decision_entries = []
for definition in graph['extra_decision_entrypoints']:
    decision_entries.append({'definition': definition,
        'calls': [edge for edge in graph['explicit_edges'] if edge['from'] == definition['name'] and edge['role'] == definition['role']],
        'AI_fields': [row for row in graph['startup_or_AI_or_immediate_assignments'] if row['owner'] == definition['name'] and row['key'] in ('ai_check_interval', 'base')]})
summary = {
    'schema': 'lyd.r42.prior-startup-hook-source-summary.v1',
    'proof_layer': 'frozen-script-callgraph-only',
    'old_topology_reused': ref(base / 'r41-engine-load-callchain-diagnostic-20261010-001/CONTENT-DIFFERENCES.actual.json'),
    'extra_startup_hook_definitions': [],
    'production_name_references_to_extra_business_definitions': references,
    'extra_GUI_files': [row for row in classes if row['role'] in extra_roles and row['relative'].startswith('gui/')],
    'replace_path': [],
    'extra_business_definition_collisions_with_production': [],
    'common_overlay_business_collisions': collisions,
    'explicit_decision_entrypoints': decision_entries,
    'extra_event_immediate_fields': [row for row in graph['startup_or_AI_or_immediate_assignments'] if row['role'] in extra_roles and row['key'] == 'immediate'],
    'overlay_script_delta': {
        'D2_effect_new_variable_assignment': line(R41_effect, r'lyd_factory_diag_d2_effect\s*=|empty_transaction_completed'),
        'R38_diag2_entry': line(R38_event, r'^lyd_factory_diag\.2\s*='),
        'R41_diag2_entry_and_guard': line(R41_event, r'^lyd_factory_diag\.2\s*=|empty_transaction_completed'),
        'R38_effect_source': R38_effect['source'], 'R41_effect_source': R41_effect['source'],
        'R38_event_source': R38_event['source'], 'R41_event_source': R41_event['source'],
        'changed_behavior': 'diag.2 event and option require the new completed=1 marker and unheld-title predicate; R41 no longer advances to D3 from that option.',
    },
    'no_startup_script_edge_classes': ['localization .yml text', 'descriptor tags metadata without replace_path', 'fixture definitions lacking production inbound references or startup registration'],
    'known_limitations': ['No claim that additional database definitions have zero loading cost.',
        'Fixture event immediate blocks are event-trigger contexts; saved active-event reconstruction is not qualified here.',
        'No saved body was inspected, so seed marker presence and all existing pending fixture scopes remain UNKNOWN.',
        'The explicit token graph does not close dynamic engine scheduling or a native pre-InGame wait.'],
    'minimal_next_content_candidate': {
        'status': 'CONDITIONAL_SOURCE_ONLY_NOT_IMPLEMENTED',
        'condition': 'Only if ROOT retained STATE facts already prove the restored diag.2 event has no completed marker, and only after R42 actual outcome.',
        'candidate': 'Change only the completed-marker guard in diag.2 event/option admission; keep current unheld-title predicate, no D3 hidden-effect restoration, no 52-file mounting, no localization change.',
        'reason': 'This is a single saved-event admission variable. It is not evidence that this guard blocks the engine startup phase.',
        'future_patch': None, 'future_execution': None,
    },
    'runtime_cause': None, 'R42_observation': None,
    'actions': {'SDK': 0, 'game': 0, 'save_body': 0, 'native_RVA_read': 0, 'tests': 0, 'main_mutation': 0},
}
assert not summary['extra_GUI_files']
create('SUMMARY.actual.json', summary)
start_line = summary['overlay_script_delta']['R41_diag2_entry_and_guard'][0]['line']
marker_lines = ', '.join(str(row['line']) for row in summary['overlay_script_delta']['R41_diag2_entry_and_guard'][1:])
report = f'''# R38→R41 fixture 启动调用面（R42期间只读）

复用既有拓扑清单，只新增静态调用面。已读冻结的fixture/overlay及正式脚本定义；没有读91MB存档、当前R42文件、EXE或SDK，没有改主仓。

额外fixture没有发现on_actions文件、GUI替换或descriptor replace_path。正式production脚本中没有额外fixture业务定义名的token引用；额外fixture没有与production业务定义重名。descriptor的tags同名只是元数据，未作为脚本碰撞。其明确入口为decision→fixture effects/events，decision源码均有ai_check_interval=0及ai_will_do base=0。四组代表入口是lyd_r3_fixture_initialize_decision、lyd_r4_setup_decision、lyd_im_open_matrix_decision和lyd_cp_construct_decision；精确行号与后续调用保存在SUMMARY/CALLGRAPH中。

fixture反向会调用formal效果/事件：charter构造最终调用lyd_c3_create_owned_temporal_head_effect；I4准备器调用各学派adopt效果及lyd.10x/12x等事件；observer读回使用formal C2谓词。这些是被fixture入口引用的调用，未发现生产启动自动调用这些fixture定义的边。事件中的immediate仍可能在该事件被触发时运行；已保存活动事件如何重建不由本源图证明。

真正的业务重名来自两边共同挂载的diagnostic overlay：lyd_i3b_capture_authority_receipt_effect、lyd_i3b_commit_effect、lyd_i3b_show_result_effect。这三个overlay block在R38/R41 token序列逐字相同，没有新的全局initializer替换。两项localization差异只改变文本，不新增脚本入口或触发边；不声称任何新增数据库文件的实际加载成本为零。

最小非文本差异是diag.2准入：R41事件定义在events/lyd_factory_operation_diagnostic.txt第{start_line}行，新增completed marker检查位于第{marker_lines}行，同时改用unheld-title谓词；D2 effect新写入lyd_factory_diag_empty_transaction_completed=1。R41还删去该选项原来的hidden_effect→D3。这能改变活动事件显示/选项合法性和后续业务路径；是否影响pre-InGame加载、seed是否有该marker都为UNKNOWN。

若R42实际结果之后仍需内容单变量对照，优先只在**ROOT已经保全的STATE证明该marker缺失**时，考虑diag.2 event/option中的completed门槛本身。保留unheld谓词、现有无D3效果的选项，不恢复52个额外文件，也无需改localization。此处只有待选候选，没有patch、执行或根因结论。当前游戏不变。

原源SHA、行号、definition碰撞及调用图：SUMMARY.actual.json、CALLGRAPH.actual.json、source-cuts。首次R41数量/路径结论引用旧CONTENT-DIFFERENCES原件，未重新盘点。R42实际结果、C3/产品信用、下一轮执行均为NULL。
'''
create('REPORT.zh.md', report)
index = {'schema': 'lyd.r42.prior-startup-hook-source-index.v1',
    'artifacts': [ref(out / name) for name in ['BOUNDARY.json', 'REPORT.zh.md', 'SUMMARY.actual.json',
        'CALLGRAPH.actual.json', 'SCRIPT-CONTENTS.actual.json', 'SOURCE-CLASSES.reused.json',
        'lyd_i3b_commit_effects.txt.R38-R41.diff.txt', 'lyd_factory_operation_diagnostic.txt.R38-R41.diff.txt']],
    'authors': [ref(base / name) for name in ['r42_collect_prior_startup_sources_20261010.py',
        'r42_read_prior_script_entrypoints_20261010.py', 'r42_map_prior_startup_callgraph_20261010.py',
        'r42_seal_prior_startup_hook_report_20261010.py']],
    'original_topology': summary['old_topology_reused'], 'future_execution': None}
create('INDEX.json', index)
print(json.dumps({'INDEX': ref(out / 'INDEX.json'), 'REPORT': ref(out / 'REPORT.zh.md'),
    'SUMMARY': ref(out / 'SUMMARY.actual.json'), 'common_overlay_collisions_unchanged': [row['name'] for row in collisions],
    'R41_diag2_lines': summary['overlay_script_delta']['R41_diag2_entry_and_guard'],
    'extra_immediate_owner_names': sorted({row['owner'] for row in summary['extra_event_immediate_fields']})}, ensure_ascii=False, indent=2))
