import hashlib
import json
from pathlib import Path

OLD = Path('C:/workspace/ck3-common-runtime/20261010-003')
OUT = Path('C:/workspace/ck3-common-runtime/20261010-004')
SOURCE = Path('C:/csr5')

def pin(path):
    raw = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def put(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

reuse = json.loads((OUT / 'SOURCE05-NATIVE-REUSE.actual.json').read_bytes())
if reuse['native_compiled_inputs_unchanged'] is not True:
    raise SystemExit('Native byte equality required before reusing compiled artifacts')
manifest = json.loads((OLD / 'manifest.json').read_bytes())
runtime = json.loads((OLD / 'runtime.local.json').read_bytes())
paths = runtime['paths']
paths.update(source_root=str(SOURCE), host=str(SOURCE / 'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py'),
    source_index=str(OUT / 'source05-index.json'), native_source_index=str(OUT / 'native-source05-index.json'))
for key in ('dll', 'injector'):
    actual = pin(Path(paths[key]))
    if any(actual[field] != manifest['native'][key][field] for field in ('bytes', 'sha256')):
        raise SystemExit('Original compiled artifact changed: ' + key)
for key in ('host', 'source_index', 'native_source_index'):
    actual = pin(Path(paths[key]))
    manifest[key] = {'path_key': key, 'bytes': actual['bytes'], 'sha256': actual['sha256']}
manifest['runtime_id'] = 'machine-common-12004-source' + reuse['source05_commit'][:9] + '-nativeaf2045521-20261010-004'
manifest['host_features']['saved_campaign_inject_after_load'] = True
manifest['host_features']['saved_campaign_debug_mode'] = True
manifest['provenance'].update(source_commit=reuse['source05_commit'],
    python_successor_native_equality=pin(OUT / 'SOURCE05-NATIVE-REUSE.actual.json'),
    mcp_source=pin(SOURCE / 'ck3_autonomous_player/src/xar_autoplayer/bridge/mcp_server.py'))
manifest['qualification'] = 'PYTHON_FIX_NATIVE_INPUTS_EQUAL_NOT_LIVE_NOT_PRODUCT_PASS'
put(OUT / 'manifest.json', manifest)
runtime['manifest'] = pin(OUT / 'manifest.json')
runtime['reviewed_launcher'] = pin(SOURCE / 'tools/ck3_mod_acceptance_launcher.py')
runtime['control_queue'] = pin(SOURCE / 'tools/ck3_mod_acceptance_queue.py')
runtime['allocation']['screen_keeper'] = pin(SOURCE / 'tools/ck3_mod_acceptance_keeper.py')
put(OUT / 'runtime.local.json', runtime)
print(json.dumps({'manifest': pin(OUT / 'manifest.json'), 'runtime': pin(OUT / 'runtime.local.json'),
    'host_features': manifest['host_features'], 'actual_live_qualified': False}))
