from pathlib import Path
from datetime import datetime,timezone,timedelta
import json,hashlib,subprocess
root=Path('C:/workspace/ck3_eternal_recurrence');now=datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M CST')
text=(
    '\n\n## '+now+'：R42调试单变量仍RED，现场已释放\n\n'
    'Source05/debug公共修正、缓存测试夹具及准备记录已普通推送b0e5119ccc023e99509f2d33001f7a9372cd436b；'
    '该精确提交Official38007787292与Linear38007787307均SUCCESS，共享acceptance步骤也有原jobs实际success，LiYu工作流未触发，不计通过。'
    '[Source05永久证据](../../ck3-native-ai/2026-10-10-shared-saved-debug-source05.md)中的未实机状态是冻结当时事实；本段记录随后R42真实结果。\n\n'
    'R42沿previous-shared-failed-launch分支实际分配，未重复bootstrap；正式71+overlay6和4项配置逐文件与R41一致，seed/budgets/baseline/actor/date相同，'
    '规范化路径后唯一argv差异为-debug_mode。实际CK3 PID9988原进程命令行确有此参数和一次-loadsave。'
    'run退出2（00:11:11.944Z→00:21:16.034Z），host原Popen1，native报告00:21:29.148Z终态RED：1022次startup均disconnected/native帧0/steps0，'
    '600秒内无Setup completion，故没有注入或业务动作、SAVE/day。日志最后08:16:21强力封臣初始化，error.log0B；单独debug未解决加载阻点，不把该最后一行当成已定位函数根因。\n\n'
    '原cleanup_ok=false/session.report=null及原CreateProcess句柄/Job关闭结构化回执缺失继续保留。独立只读观察句柄在游戏仍活着时用raw GetProcessTimes FILETIME核同PID（相差-2tick），'
    '实际观察CK3于00:21:28.739Z退出1；它不是原CreateProcess句柄或typed normal0。首次PyWin32 datetime精度断言失败保留，002改用raw FILETIME成功；'
    '后到的三次进程活动采样均NoSuchProcess，无CPU/IO数值，不回填0或据此判断死锁。\n\n'
    '最终当前CK3/录制/控制文件空、Steam新原图8:37离线亲审、桌面恢复原1024×768，keeper joined且原allocate Popen0；CAS4302→4303已释放，verify仍退出2。'
    'Source05归档、R42归档和exact CI记录并行落地；后续先核已有STATE中的活动事件/marker与夹具定义，不能凭源码推测改存档或恢复全部额外夹具。'
    '缺失ck3-upgrade-20261008仍非依赖。I3b/C3/I4及一期NOT_GREEN，75%仅工作量估计，无新增业务PASS，不承诺未经实机支持的完成日期。\n')
paths=['docs/ck3-native-ai/2026-10-10-local-common-runtime-rebuild.md','docs/li-yu-dao/2026-10-09-progress.md',
    'docs/autonomous-agent-progress/daily/2026-10-10.md','docs/autonomous-agent-progress/weekly/2026-W41.md']
rows=[]
for name in paths:
    p=root/name;before=p.read_bytes();local=text
    if name.startswith('docs/ck3-native-ai/') or name.startswith('docs/li-yu-dao/'):
        local=local.replace('../../ck3-native-ai/','../ck3-native-ai/')
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(local)
    after=p.read_bytes();rows.append({'path':name,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest()})
with Path('C:/workspace/ck3_lyd_runtime_20261004/r42-root-progress-after-close-20261010-001.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'at_cst':now,'files':rows},f,indent=2);f.write('\n')
subprocess.run(['git','diff','--check','--',*paths],cwd=root,check=True)
subprocess.run(['git','commit','--only','-m','Record R42 debug startup failure and actual closed boundary','--',*paths],cwd=root,check=True)
