from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
run=Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0042')
def pin(p):
    raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def put(p,value):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
path=run/'direct-review-001/challenge.json';challenge=json.loads(path.read_bytes())
observed='06c327d1c3a4543806544cdd95110b48'
assert observed==challenge['nonce']
out=run/'direct-review-001/operator-review.json'
put(out,{'schema':'ck3-mod-acceptance-direct-review-v1','reviewed_at_utc':datetime.now(timezone.utc).isoformat(),
    'reviewer':'/root','direct_image_review':True,'steam_offline_confirmed':True,'observed_nonce':observed,
    'run_id':challenge['run_id'],'screen_task':challenge['screen_task'],'challenge':pin(path),
    **{key:challenge[key] for key in ('frozen_argv','image','review_image')},
    'observed_text':'Root directly reviewed original moved Steam screenshot and nonce image: 离线模式; taskbar 8:10 2026/10/10. Current 1920x1080 pixels and window movement reviewed.',
    'business_pass':False})
context=json.loads((run/'ready-context.json').read_bytes())
context.update(proof=str(out),challenge=str(path),observed_nonce=observed,reviewer='/root')
put(run/'reviewed-context.json',context)
print(json.dumps({'proof':pin(out),'context':pin(run/'reviewed-context.json')}))
