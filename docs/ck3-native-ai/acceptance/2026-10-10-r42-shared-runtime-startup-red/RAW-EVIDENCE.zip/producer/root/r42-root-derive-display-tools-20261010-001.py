from pathlib import Path
import hashlib,json
base=Path('C:/workspace/ck3_lyd_runtime_20261004');rows=[]
for kind in ('desktop','steam-window'):
    old=base/('r41-root-fit-'+kind+'-20261010-001.py')
    new=base/('r42-root-fit-'+kind+'-20261010-001.py')
    text=old.read_text(encoding='utf-8');assert text.count('--R0041')==1
    with new.open('x',encoding='utf-8',newline='\n') as f:f.write(text.replace('--R0041','--R0042'))
    rows.append({'original':str(old),'original_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),
        'derived':str(new),'derived_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),
        'only_change':'Allocated run directory R0041 to R0042; original Win32 PID/HWND checks remain.'})
with (base/'r42-root-display-tools-derivation-20261010-001.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'derivations':rows,'desktop_actions_executed':False},f,indent=2);f.write('\n')
print(json.dumps(rows))
