from pathlib import Path
import hashlib,json
b=Path('C:/workspace/ck3_lyd_runtime_20261004');old=b/'r42-root-observe-retained-process-20261010-001.py';new=b/'r42-root-observe-retained-process-20261010-002.py'
text=old.read_text(encoding='utf-8')
before="    created=times['CreationTime'].timestamp()\n    assert abs(created-before['create_time'])<0.00001"
after="""    import ctypes
    from ctypes import wintypes
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.GetProcessTimes.argtypes=[wintypes.HANDLE,*([ctypes.POINTER(wintypes.FILETIME)]*4)]
    kernel.GetProcessTimes.restype=wintypes.BOOL
    stamps=[wintypes.FILETIME() for _ in range(4)]
    if not kernel.GetProcessTimes(int(handle),*[ctypes.byref(stamp) for stamp in stamps]):
        raise ctypes.WinError(ctypes.get_last_error())
    ticks=(stamps[0].dwHighDateTime<<32)|stamps[0].dwLowDateTime
    expected_ticks=round((before['create_time']+11644473600)*10000000)
    delta=ticks-expected_ticks
    assert abs(delta)<=32
    created=times['CreationTime'].timestamp()"""
assert text.count(before)==1;text=text.replace(before,after)
before="'handle_creation_time_utc':times['CreationTime'].isoformat(),'handle_identity_matches':True,"
after="'handle_creation_time_utc':times['CreationTime'].isoformat(),'handle_identity_matches':True,\n        'handle_creation_filetime_100ns':ticks,'psutil_to_raw_filetime_delta_100ns':delta,\n        'pywin32_datetime_delta_seconds':created-before['create_time'],"
assert text.count(before)==1;text=text.replace(before,after)
compile(text,str(new),'exec')
with new.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
with (b/'r42-retained-observer002-derivation-20261010-001.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'original_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'derived_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),
        'reason':'First read-only observer failed before ready because the pywin32 datetime conversion did not meet the floating timestamp tolerance. Use raw GetProcessTimes FILETIME for exact live identity; preserve first failure.',
        'process_signals_sent':False},f,indent=2);f.write('\n')
print(str(new))
