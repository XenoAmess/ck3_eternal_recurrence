from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys
from pathlib import Path
source=Path('C:/csr5');out=Path('C:/workspace/ck3-common-runtime/20261010-004/frozen-python-checks-001')
out.mkdir()
reuse=json.loads((out.parent/'SOURCE05-NATIVE-REUSE.actual.json').read_bytes())
env=os.environ.copy()
env['PYTHONPATH']=os.pathsep.join(str(source/p) for p in ['ck3_autonomous_player/src','ck3_workshop_mcp/src','tools'])
tests=['test_saved_debug_mode_global_default_off_and_single_flag',
    'test_saved_debug_mode_is_not_routed_to_other_startup_modes',
    'test_saved_debug_mode_rejects_non_boolean_and_unknown_global_features',
    'test_product_or_case_cannot_choose_saved_debug_mode']
rows=[]
for name,tail in [
    ('saved-lifecycle',['-m','unittest','discover','-s','ck3_autonomous_player/tests/unit','-p','test_saved_campaign_delayed_injection.py']),
    ('global-routing',['tools/test_ck3_mod_acceptance.py',*['SharedEntryTests.'+test for test in tests]]),
    ('host-help',['ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py','--help']),
]:
    argv=[sys.executable,'-B','-X','utf8',*tail];start=datetime.now(timezone.utc).isoformat()
    result=subprocess.run(argv,cwd=source,env=env,capture_output=True)
    row={'name':name,'argv':argv,'cwd':str(source),'started_at_utc':start,
        'finished_at_utc':datetime.now(timezone.utc).isoformat(),'exit_code':result.returncode}
    for channel in ['stdout','stderr']:
        p=out/(name+'.'+channel+'.log');raw=getattr(result,channel);p.write_bytes(raw)
        row[channel]={'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    rows.append(row)
    if result.returncode:break
with (out/'RESULT.actual.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'source_commit':reuse['source05_commit'],'commands':rows,
        'scope':'Frozen saved lifecycle suite, four new global routing boundaries, host help; no CK3 launch.',
        'live_qualified':False,'business_pass':False},f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(rows))
raise SystemExit(any(row['exit_code'] for row in rows))
