from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

base = Path('C:/workspace/ck3_lyd_runtime_20261004')
out = base / 'r42-prior-fixture-startup-hook-sourceonly-20261010-001'
prior = json.loads((base / 'r41-engine-load-callchain-diagnostic-20261010-001/CONTENT-DIFFERENCES.actual.json').read_text(encoding='utf-8'))
cold = json.loads(Path(prior['R38_cold_source']['path']).read_text(encoding='utf-8'))
sources = json.loads((out / 'SCRIPT-CONTENTS.actual.json').read_text(encoding='utf-8'))
present = {(row['variant'], row['role'], row['relative']) for row in sources}


def ref(path):
    raw = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


for row in cold['content']:
    if row['role'] not in ('production', 'diagnostic_stage'):
        continue
    frozen = row['copy']
    path = Path(frozen['path'])
    relative = path.relative_to(base / 'live-attempt-038/content' / row['role']).as_posix()
    identity = ('R38', row['role'], relative)
    if identity in present or path.suffix.casefold() not in ('.txt', '.gui', '.mod'):
        continue
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == frozen['sha256']
    copy = out / 'source-cuts/R38' / row['role'] / relative
    copy.parent.mkdir(parents=True, exist_ok=True)
    with copy.open('xb') as stream:
        stream.write(raw)
    lines = raw.decode('utf-8-sig').splitlines()
    numbered = copy.with_name(copy.name + '.numbered.txt')
    numbered.write_text('\n'.join(str(n) + ': ' + line for n, line in enumerate(lines, 1)) + '\n', encoding='utf-8')
    sources.append({'variant': 'R38', 'role': row['role'], 'relative': relative,
        'source': frozen, 'raw_copy': str(copy), 'numbered_copy': str(numbered), 'text': '\n'.join(lines)})

# The lexer retains only explicit source-token edges. It is not an engine evaluator.
lexer = re.compile(r'(?P<comment>\#[^\n]*)|(?P<string>"(?:\\.|[^"\\])*")|(?P<word>[^\s{}=<>!#"]+)|(?P<op>[{}=<>!])')
definitions = []
all_tokens = []
for file_id, row in enumerate(sources):
    tokens = []
    for match in lexer.finditer(row['text']):
        if match.lastgroup == 'comment':
            continue
        tokens.append({'value': match.group(), 'kind': match.lastgroup,
            'line': row['text'].count('\n', 0, match.start()) + 1})
    all_tokens.append(tokens)
    depth = 0
    for n, token in enumerate(tokens):
        if depth == 0 and n + 2 < len(tokens) and tokens[n + 1]['value'] == '=' and tokens[n + 2]['value'] == '{':
            end = n + 3
            level = 1
            while end < len(tokens) and level:
                level += (tokens[end]['value'] == '{') - (tokens[end]['value'] == '}')
                end += 1
            assert level == 0, row['relative']
            definitions.append({'name': token['value'], 'line': token['line'],
                'file_id': file_id, 'start': n, 'end': end,
                'role': row['role'], 'variant': row['variant'], 'relative': row['relative']})
        depth += (token['value'] == '{') - (token['value'] == '}')
    assert depth == 0, row['relative']

by_variant = {}
for definition in definitions:
    by_variant.setdefault(definition['variant'], {}).setdefault(definition['name'], []).append(definition)
R38 = by_variant['R38']
extra_roles = {'entry', 'observer', 'i4_single_event', 'charter'}
extra_names = {name for name, rows in R38.items() if any(row['role'] in extra_roles for row in rows)}
production_names = {name for name, rows in R38.items() if any(row['role'] == 'production' for row in rows)}
collisions = [{'name': name, 'definitions': rows} for name, rows in R38.items()
    if len({row['role'] for row in rows}) > 1]
edges = []
assignments = []
for definition in definitions:
    tokens = all_tokens[definition['file_id']]
    names = set(by_variant[definition['variant']]) | (production_names if definition['variant'] == 'R41' else set())
    for n in range(definition['start'] + 3, definition['end'] - 2):
        key = tokens[n]['value']
        if tokens[n + 1]['value'] != '=':
            continue
        value = tokens[n + 2]['value']
        if key in names:
            edges.append({'from': definition['name'], 'to': key, 'kind': 'explicit-script-key-call',
                'line': tokens[n]['line'], 'role': definition['role'], 'variant': definition['variant'],
                'relative': definition['relative']})
        if key == 'trigger_event':
            target = value
            if value == '{':
                target = None
                for k in range(n + 3, min(n + 30, definition['end'] - 2)):
                    if tokens[k]['value'] == 'id' and tokens[k + 1]['value'] == '=':
                        target = tokens[k + 2]['value']
                        break
            edges.append({'from': definition['name'], 'to': target, 'kind': 'explicit-trigger_event',
                'line': tokens[n]['line'], 'role': definition['role'], 'variant': definition['variant'],
                'relative': definition['relative']})
        if key in ('on_game_start', 'on_game_load', 'on_load', 'on_startup', 'on_game_initialize',
                   'ai_check_interval', 'base', 'immediate', 'on_action', 'on_actions', 'replace_path'):
            assignments.append({'owner': definition['name'], 'key': key, 'value': value,
                'line': tokens[n]['line'], 'role': definition['role'], 'variant': definition['variant'],
                'relative': definition['relative']})

file_level_replacements = []
for file_id, row in enumerate(sources):
    for n, token in enumerate(all_tokens[file_id][:-2]):
        if token['value'] == 'replace_path' and all_tokens[file_id][n + 1]['value'] == '=':
            file_level_replacements.append({'source': row['source'], 'role': row['role'],
                'relative': row['relative'], 'line': token['line'], 'value': all_tokens[file_id][n + 2]['value']})
production_to_extra = [edge for edge in edges if edge['role'] == 'production' and edge['to'] in extra_names]
extra_to_production = [edge for edge in edges if edge['role'] in extra_roles and edge['to'] in production_names]
extra_decisions = [definition for definition in definitions if definition['role'] in extra_roles and '/decisions/' in definition['relative']]
extra_hooks = [definition for definition in definitions if definition['role'] in extra_roles and '/on_actions/' in definition['relative']]
production_hooks = [definition for definition in definitions if definition['role'] == 'production' and '/on_actions/' in definition['relative']]
result = {'schema': 'lyd.r42.prior-fixture-explicit-script-callgraph.v1',
    'proof_layer': 'explicit-frozen-source-token-edges-only',
    'source_refs': [{key: row[key] for key in ('variant', 'role', 'relative', 'source', 'raw_copy', 'numbered_copy')} for row in sources],
    'definitions': definitions, 'explicit_edges': edges, 'cross_role_definition_collisions': collisions,
    'production_to_extra_explicit_calls': production_to_extra,
    'extra_to_production_explicit_calls': extra_to_production,
    'extra_decision_entrypoints': extra_decisions,
    'extra_on_action_definitions': extra_hooks,
    'production_on_action_definitions': production_hooks,
    'startup_or_AI_or_immediate_assignments': assignments,
    'descriptor_replace_path_assignments': file_level_replacements,
    'limitations': ['No save body or loaded-event reconstruction inspected.',
        'Source edges do not prove engine scheduling, decision execution, or restored immediate behavior.',
        'No current R42 observation, game call, native scan, tests, or main mutation.'],
    'future_execution': None, 'runtime_cause': None}
(out / 'CALLGRAPH.actual.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'collisions': [{'name': row['name'], 'roles': sorted({d['role'] for d in row['definitions']})} for row in collisions],
    'production_to_extra': production_to_extra,
    'extra_on_actions': extra_hooks,
    'production_on_actions': production_hooks,
    'replace_paths': file_level_replacements,
    'extra_to_production_named_edges': sorted({(edge['from'], edge['to']) for edge in extra_to_production})}, ensure_ascii=False, indent=2))
