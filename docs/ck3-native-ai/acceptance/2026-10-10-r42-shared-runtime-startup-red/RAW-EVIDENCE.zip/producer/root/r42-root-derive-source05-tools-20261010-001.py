from pathlib import Path
import hashlib, json

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
def pin(path):
    raw=path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
rows=[]
for original, output, replacements in [
    ('r41-root-freeze-source04-20261010-001.py', 'r42-root-freeze-source05-20261010-001.py', [
        ("OLD = Path('C:/workspace/ck3-common-runtime/20261010-002')", "OLD = Path('C:/workspace/ck3-common-runtime/20261010-003')"),
        ("OUT = Path('C:/workspace/ck3-common-runtime/20261010-003')", "OUT = Path('C:/workspace/ck3-common-runtime/20261010-004')"),
        ("SOURCE = Path('C:/csr4')", "SOURCE = Path('C:/csr5')"),
        ("BASE = '13d063c81ff706d8bc3f9a8bf81f60c283338042'", "BASE = '919bae0f42def04e6398eb2de4b4afe20dcfc106'"),
        ("if sorted(changed) != sorted(PATHS):", "if not set(PATHS) <= set(changed) or any(not path.startswith('docs/') for path in set(changed) - set(PATHS)):"),
        ('shared-delayed-injection-author.patch', 'shared-saved-debug-author.patch'),
        ('Freeze shared same-process saved-load injection policy', 'Freeze shared saved-campaign debug opt-in'),
        ('source04', 'source05'),
        ('SOURCE04', 'SOURCE05'),
        ('source03', 'source04'),
        ("'C:/csr3'", "'C:/csr4'"),
    ]),
    ('r41-root-bind-runtime-20261010-001.py', 'r42-root-bind-runtime-20261010-001.py', [
        ("OLD = Path('C:/workspace/ck3-common-runtime/20261010-002')", "OLD = Path('C:/workspace/ck3-common-runtime/20261010-003')"),
        ("OUT = Path('C:/workspace/ck3-common-runtime/20261010-003')", "OUT = Path('C:/workspace/ck3-common-runtime/20261010-004')"),
        ("SOURCE = Path('C:/csr4')", "SOURCE = Path('C:/csr5')"),
        ('source04', 'source05'),
        ('SOURCE04', 'SOURCE05'),
        ("-nativeaf2045521-20261010-003'", "-nativeaf2045521-20261010-004'"),
        ("manifest['host_features']['saved_campaign_inject_after_load'] = True", "manifest['host_features']['saved_campaign_inject_after_load'] = True\nmanifest['host_features']['saved_campaign_debug_mode'] = True"),
    ]),
]:
    old=BASE/original;new=BASE/output
    text=old.read_text(encoding='utf-8')
    for before, after in replacements:
        assert before in text, (original,before)
        text=text.replace(before,after)
    compile(text,str(new),'exec')
    with new.open('x',encoding='utf-8',newline='\n') as stream:stream.write(text)
    rows.append({'original':pin(old),'derived':pin(new),'replacements':replacements})
out=BASE/'r42-root-source05-tools-derivation-20261010-001.json'
with out.open('x',encoding='utf-8',newline='\n') as stream:
    json.dump({'schema':'ck3-shared-source05-tool-derivation-v1','changes':rows,
        'not_executed':['source05-freeze','runtime-binding','live-launch']},stream,ensure_ascii=False,indent=2)
    stream.write('\n')
print(json.dumps({'derivation':pin(out),'tools':[row['derived'] for row in rows]}))
