from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,psutil
run=Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0042')
logs=Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-004/state/profile/logs')
out={'at_utc':datetime.now(timezone.utc).isoformat(),'actual_ck3_processes':[],'process_read_errors':[]}
for p in psutil.process_iter(['pid','name','exe','cmdline','create_time']):
    try:
        if (p.info['name'] or '').lower()=='ck3.exe':out['actual_ck3_processes'].append(p.info)
    except (psutil.NoSuchProcess,psutil.AccessDenied) as e:out['process_read_errors'].append(str(e))
for relative in ['host-original-process-exit.json','native-report.json',
    'case-output/case-error-preserved.json','case-output/transaction-control-case-result.json','case-output/normal-close-result.json']:
    path=run/relative
    if not path.exists():out[relative]=None;continue
    raw=path.read_bytes();value=json.loads(raw);row={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    if relative=='native-report.json':
        row.update({k:value.get(k) for k in ['status','phase','error','finished_at','managed_session_thread_finished','cleanup_ok']})
        saved=value.get('saved_campaign_restore') or {};observations=saved.get('observations') or []
        startup=saved.get('startup_observations') or []
        row.update(step_count=len(value.get('steps') or []),observation_count=len(observations),startup_count=len(startup),
            last_startup=startup[-1] if startup else None,last_saved=observations[-1] if observations else None,
            saved_launch=value.get('saved_campaign_launch'),session_error=(value.get('session') or {}).get('error'),
            shutdown=((value.get('session') or {}).get('report') or {}).get('shutdown'))
    else:row.update(value)
    out[relative]=row
for name in ['debug.log','error.log']:
    p=logs/name
    if p.exists():
        raw=p.read_bytes();lines=raw.decode('utf-8','replace').splitlines()
        out[name]={'bytes':len(raw),'tail':lines[-4:],
            'loading_markers':[line for line in lines if any(s in line for s in ['Setup completion','Setup powerful vassals','InGame','Map mesh generation'])][-8:]}
dest=run/'root-observations';dest.mkdir(exist_ok=True)
with (dest/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.json')).open('x',encoding='utf-8',newline='\n') as f:
    json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(out,ensure_ascii=False,indent=2))
