from pathlib import Path
import hashlib,json
base=Path('C:/workspace/ck3_lyd_runtime_20261004')
old=base/'r42-root-freeze-source05-20261010-001.py'
new=base/'r42-root-freeze-source05-20261010-002.py'
before="'artifact_build_result': pin(OLD / 'BUILD-RESULT.actual.json'),"
after="'artifact_build_result': json.loads((OLD / 'SOURCE04-NATIVE-REUSE.actual.json').read_bytes())['artifact_build_result'],"
raw=old.read_bytes();text=raw.decode('utf-8');assert text.count(before)==1
updated=text.replace(before,after);compile(updated,str(new),'exec')
with new.open('x',encoding='utf-8',newline='\n') as stream:stream.write(updated)
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
record=base/'r42-root-freezer002-derivation-20261010-001.json'
with record.open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'original':pin(old),'derived':pin(new),'replacement':[before,after],
        'reason':'Source04 reused the original Source02 build; no new Source04 BUILD-RESULT exists.',
        'source05_freeze_executed':False},f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'derivation':pin(record),'freezer':pin(new)}))
