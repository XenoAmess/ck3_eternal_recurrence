import subprocess
paths=['docs/ck3-native-ai/2026-10-10-local-common-runtime-rebuild.md',
    'docs/li-yu-dao/2026-10-09-progress.md','docs/autonomous-agent-progress/daily/2026-10-10.md',
    'docs/autonomous-agent-progress/weekly/2026-W41.md']
subprocess.run(['git','commit','--only','-m','Record local Source05 preparation and exact CI limits','--',*paths],
    cwd='C:/workspace/ck3_eternal_recurrence',check=True)
