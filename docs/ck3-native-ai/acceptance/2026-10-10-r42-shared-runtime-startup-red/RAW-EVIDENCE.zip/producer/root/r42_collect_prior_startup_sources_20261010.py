import hashlib
import json
from pathlib import Path

base = Path('C:/workspace/ck3_lyd_runtime_20261004')
previous = base / 'r41-engine-load-callchain-diagnostic-20261010-001/CONTENT-DIFFERENCES.actual.json'
out = base / 'r42-prior-fixture-startup-hook-sourceonly-20261010-001'
out.mkdir(exist_ok=False)
raw = previous.read_bytes()
data = json.loads(raw)
def ref(path):
    content = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}
boundary = {'schema': 'lyd.r42.prior-startup-hook-boundary.v1',
    'purpose': 'New source callgraph surface only; previously sealed topology/counts reused without recomputation.',
    'topology_source': ref(previous),
    'allowed': 'Previously indexed R38 extra fixtures, diagnostic overlay differences and their calls/collisions with formal production sources only.',
    'forbidden': ['game', 'SDK', 'save body', 'native RVA scan', 'main changes', 'live R42 file writes'],
    'future_cell': None, 'runtime_cause': None}
(out / 'BOUNDARY.json').write_text(json.dumps(boundary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'keys': list(data), 'extra_fixture_keys': list(data.get('R38_extra_fixtures', {}))}, indent=2))
# Dump only existing role/relative mappings, not fresh inventories or save bodies.
for key, value in data.items():
    if key not in ('R38_cold_source', 'comparisons'):
        (out / ('REUSED-' + key + '.json')).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        if isinstance(value, dict):
            print(json.dumps({'reused_key': key, 'keys': list(value)}, indent=2))
