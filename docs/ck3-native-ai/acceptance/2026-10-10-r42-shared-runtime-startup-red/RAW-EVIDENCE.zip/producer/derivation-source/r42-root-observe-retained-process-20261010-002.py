from pathlib import Path
from datetime import datetime,timezone
import json,time,psutil,win32api,win32con,win32event,win32process
run=Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0042')
expected_profile='-userdir=C:\\workspace\\ck3-common-runtime\\cases\\lyd-transaction-control-20261010-004\\state\\profile'
def put(p,obj):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,indent=2);f.write('\n')
original=psutil.Process(9988);before=original.as_dict(attrs=['pid','name','exe','cmdline','create_time'])
assert before['name'].lower()=='ck3.exe' and before['cmdline'].count(expected_profile)==1
assert before['cmdline'].count('-debug_mode')==1 and before['cmdline'].count('-loadsave=restored_campaign')==1
handle=win32api.OpenProcess(win32con.SYNCHRONIZE|win32con.PROCESS_QUERY_LIMITED_INFORMATION,False,before['pid'])
try:
    times=win32process.GetProcessTimes(handle)
    import ctypes
    from ctypes import wintypes
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.GetProcessTimes.argtypes=[wintypes.HANDLE,*([ctypes.POINTER(wintypes.FILETIME)]*4)]
    kernel.GetProcessTimes.restype=wintypes.BOOL
    stamps=[wintypes.FILETIME() for _ in range(4)]
    if not kernel.GetProcessTimes(int(handle),*[ctypes.byref(stamp) for stamp in stamps]):
        raise ctypes.WinError(ctypes.get_last_error())
    ticks=(stamps[0].dwHighDateTime<<32)|stamps[0].dwLowDateTime
    expected_ticks=round((before['create_time']+11644473600)*10000000)
    delta=ticks-expected_ticks
    assert abs(delta)<=32
    created=times['CreationTime'].timestamp()
    assert original.create_time()==before['create_time']
    ready={'at_utc':datetime.now(timezone.utc).isoformat(),'process':before,
        'handle_creation_time_utc':times['CreationTime'].isoformat(),'handle_identity_matches':True,
        'handle_creation_filetime_100ns':ticks,'psutil_to_raw_filetime_delta_100ns':delta,
        'pywin32_datetime_delta_seconds':created-before['create_time'],
        'kind':'independent observer handle opened while original CK3 was alive; not its CreateProcess handle',
        'rights':['SYNCHRONIZE','PROCESS_QUERY_LIMITED_INFORMATION'],'process_signals_sent':False}
    put(run/'observer-retained-handle-ready.json',ready)
    deadline=time.monotonic()+1800
    while True:
        wait=win32event.WaitForSingleObject(handle,500)
        if wait==win32event.WAIT_OBJECT_0:
            code=win32process.GetExitCodeProcess(handle)
            put(run/'observer-retained-handle-exit.json',{'at_utc':datetime.now(timezone.utc).isoformat(),
                'pid':before['pid'],'process_create_time':before['create_time'],'wait_result':wait,
                'actual_exit_code':code,'independent_observer_handle':True,'original_createprocess_handle':False,
                'process_signals_sent':False,'typed_normal_exit_inferred':False,'business_pass':False})
            print(json.dumps({'pid':before['pid'],'actual_observed_exit_code':code}));break
        if wait!=win32event.WAIT_TIMEOUT or time.monotonic()>=deadline:
            raise RuntimeError('Observer wait did not observe an exit within its bound: '+str(wait))
finally:win32api.CloseHandle(handle)
