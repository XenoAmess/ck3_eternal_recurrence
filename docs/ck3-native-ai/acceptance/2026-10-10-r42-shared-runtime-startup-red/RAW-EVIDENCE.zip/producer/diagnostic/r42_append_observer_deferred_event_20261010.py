from pathlib import Path
import hashlib
import json

ROOT = Path('C:/workspace/ck3_lyd_runtime_20261004/r42-prior-fixture-startup-hook-sourceonly-20261010-001')

def ref(path):
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def write_new(name, value):
    path = ROOT / name
    body = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    with path.open('xb') as stream:
        stream.write(body)
    return ref(path)

original = ref(ROOT / 'INDEX.json')
if original['sha256'] != '8667d93f8e3c62dbf35a7dee664885e728f27e400bf18ca5691d7651454347b6':
    raise ValueError('Original sealed INDEX differs')
event = ROOT / 'source-cuts/R38/observer/events/lyd_r4_fixture_events.txt'
effect = ROOT / 'source-cuts/R38/observer/common/scripted_effects/lyd_r4_fixture_effects.txt'
event_lines = event.read_text(encoding='utf-8-sig').splitlines()
effect_lines = effect.read_text(encoding='utf-8-sig').splitlines()
if 'lyd_r4_fixture.6 = {' not in event_lines[29]:
    raise ValueError('Deferred event declaration differs')
if 'has_character_flag = lyd_r4_qualification_pending' not in event_lines[32]:
    raise ValueError('Deferred event trigger differs')
if 'lyd_r4_finish_qualification_effect = yes' not in event_lines[33]:
    raise ValueError('Deferred event immediate differs')
if 'trigger_event = { id = lyd_r4_fixture.6 days = 2 }' not in effect_lines[82]:
    raise ValueError('Deferred event explicit schedule differs')
owner = None
for number, line in enumerate(effect_lines[:83], 1):
    if line and not line[0].isspace() and '= {' in line:
        owner = {'name': line.split('=', 1)[0].strip(), 'line': number}
if not owner or 'qualification' not in owner['name']:
    raise ValueError('Qualification owner not closed')
value = {
    'schema': 'lyd.r42.prior-fixture-observer-deferred-event.source-only.v1',
    'original_sealed_index': original,
    'source_refs': [ref(event), ref(effect)],
    'explicit_schedule': {'caller': owner, 'schedule_line': 83, 'event': 'lyd_r4_fixture.6', 'days': 2},
    'event_body': {'declaration_line': 30, 'pending_flag_trigger_line': 33, 'immediate_finish_effect_line': 34},
    'cleanup': {'effect': 'lyd_r4_finish_qualification_effect', 'declaration_line': 86, 'pending_guard_line': 89, 'remove_pending_line': 90},
    'finding': 'Deferred observer event is explicitly scheduled from the qualification effect and guarded by a pending flag; it is not an unconditional startup hook.',
    'saved_pending_event_presence': 'UNKNOWN',
    'restored_event_delivery_effect_on_loading': 'UNKNOWN',
    'runtime_root_cause': 'UNKNOWN',
    'current_R42_reads_or_actions': [],
    'save_body_reads': 0,
    'tests_or_game_calls': [],
}
appendix = write_new('OBSERVER-DEFERRED-EVENT.appendix.json', value)
index = write_new('APPEND-INDEX.json', {'schema': 'lyd.r42.prior-fixture-startup-hook.append-only-index.v1', 'original_sealed_index': original, 'appendix': appendix, 'author': ref(Path(__file__))})
print(json.dumps({'appendix': appendix, 'append_index': index}, ensure_ascii=False))
