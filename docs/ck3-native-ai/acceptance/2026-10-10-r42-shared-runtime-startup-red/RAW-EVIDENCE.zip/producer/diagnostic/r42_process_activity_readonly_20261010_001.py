import datetime
import hashlib
import json
from pathlib import Path
import time

import psutil

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r42-process-activity-readonly-20261010-001'
FROZEN = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0042/frozen-argv.json')
PID = 9988
CREATED = 1791591087.9328783


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def put(name, value):
    p = OUT / name
    with p.open('xb') as stream:
        stream.write((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    return ref(p)


def ref(p):
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def norm(s):
    return str(s).replace('\\', '/').rstrip('/').casefold()


def error(exc):
    return {'type': type(exc).__name__, 'message': str(exc), 'errno': getattr(exc, 'errno', None), 'winerror': getattr(exc, 'winerror', None)}


def main():
    OUT.mkdir(exist_ok=False)
    frozen = json.loads(FROZEN.read_bytes())
    profile = str(Path(frozen['state_dir']) / 'profile')
    rows = []
    initial_cmd = None
    started = time.monotonic()
    for index in range(3):
        if index:
            time.sleep(max(0.0, started + index * 5.0 - time.monotonic()))
        row = {'sample': index + 1, 'observed_at_utc': utc(), 'elapsed_seconds': time.monotonic() - started, 'pid': PID, 'errors': []}
        try:
            process = psutil.Process(PID)
            name = process.name()
            created = process.create_time()
            cmd = process.cmdline()
            if initial_cmd is None:
                initial_cmd = cmd
            profile_matches = [arg for arg in cmd if norm(arg) == norm(profile) or ('=' in arg and norm(arg.split('=', 1)[1]) == norm(profile))]
            row['identity'] = {'name': name, 'create_time': created, 'cmdline': cmd, 'expected_profile': profile, 'profile_arguments': profile_matches, 'name_matches': name.casefold() == 'ck3.exe', 'create_time_matches': abs(created - CREATED) < 0.000001, 'profile_argument_matches': bool(profile_matches), 'cmdline_unchanged': cmd == initial_cmd}
            row['identity_verified'] = all(row['identity'][key] for key in ('name_matches', 'create_time_matches', 'profile_argument_matches', 'cmdline_unchanged'))
            if not row['identity_verified']:
                row['errors'].append({'type': 'IdentityMismatch', 'message': 'Activity reads skipped because an original identity pin differs.'})
            else:
                for field, getter in (('cpu_times', process.cpu_times), ('io_counters', process.io_counters), ('memory_info', process.memory_info)):
                    try:
                        row[field] = getter()._asdict()
                    except Exception as exc:
                        row['errors'].append({'field': field, **error(exc)})
                try:
                    row['thread_count'] = process.num_threads()
                    row['threads'] = [value._asdict() for value in process.threads()]
                except Exception as exc:
                    row['errors'].append({'field': 'threads', **error(exc)})
                try:
                    row['identity_end_create_time'] = process.create_time()
                    row['identity_end_matches'] = abs(row['identity_end_create_time'] - CREATED) < 0.000001
                except Exception as exc:
                    row['errors'].append({'field': 'identity_end', **error(exc)})
        except Exception as exc:
            row['errors'].append(error(exc))
        rows.append(row)
    raw_ref = put('SAMPLES.actual.json', rows)
    compact = []
    for row in rows:
        compact.append({key: row.get(key) for key in ('sample', 'observed_at_utc', 'elapsed_seconds', 'pid', 'identity_verified', 'identity_end_matches', 'cpu_times', 'thread_count', 'io_counters', 'memory_info', 'errors')})
        threads = row.get('threads', [])
        compact[-1]['threads_returned'] = len(threads)
        compact[-1]['thread_cpu_totals'] = {'user_time': sum(t['user_time'] for t in threads), 'system_time': sum(t['system_time'] for t in threads)}
        compact[-1]['top_threads_by_total_cpu'] = sorted(threads, key=lambda t: t['user_time'] + t['system_time'], reverse=True)[:10]
    deltas = []
    for first, last in zip(rows, rows[1:]):
        delta = {'from_sample': first['sample'], 'to_sample': last['sample'], 'seconds': last['elapsed_seconds'] - first['elapsed_seconds']}
        for field in ('cpu_times', 'io_counters'):
            if field in first and field in last:
                delta[field] = {key: last[field][key] - first[field][key] for key in first[field]}
        first_threads = {t['id']: t for t in first.get('threads', [])}
        changes = []
        for thread in last.get('threads', []):
            if thread['id'] in first_threads:
                before = first_threads[thread['id']]
                changes.append({'id': thread['id'], 'user_seconds': thread['user_time'] - before['user_time'], 'system_seconds': thread['system_time'] - before['system_time']})
        delta['top_same_thread_cpu_deltas'] = sorted(changes, key=lambda t: t['user_seconds'] + t['system_seconds'], reverse=True)[:10]
        deltas.append(delta)
    report = {'schema': 'lyd.r42.readonly-original-process-activity-samples.v1', 'expected_pid': PID, 'expected_create_time': CREATED, 'expected_profile': profile, 'frozen_argv': ref(FROZEN), 'samples': compact, 'interval_deltas': deltas, 'raw_samples': raw_ref, 'duration_seconds': time.monotonic() - started, 'observations_only': True, 'deadlock_inference': None, 'signals': 0, 'debugger_attaches': 0, 'memory_dumps': 0, 'sdk_calls': 0, 'business_pass': False}
    report_ref = put('REPORT.actual.json', report)
    index_ref = put('INDEX.json', {'producer': ref(Path(__file__)), 'files': [raw_ref, report_ref]})
    print(json.dumps({'index': index_ref, 'report': report_ref, 'all_identity_verified': all(r.get('identity_verified') and r.get('identity_end_matches') for r in rows), 'error_count': sum(len(r['errors']) for r in rows), 'duration_seconds': report['duration_seconds'], 'interval_deltas': deltas}, ensure_ascii=False))


if __name__ == '__main__':
    main()
