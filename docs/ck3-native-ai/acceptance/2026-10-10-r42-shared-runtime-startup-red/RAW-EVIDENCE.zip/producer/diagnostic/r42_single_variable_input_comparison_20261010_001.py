"""Existing input bytes and Selection argv only; no preflight or seed reads."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
ROOT=Path('C:/workspace/ck3_eternal_recurrence')
COMMON=Path('C:/workspace/ck3-common-runtime')
OLD_RUN=COMMON/'runs/bf-202609141645-5434332d4d--li-yu-dao--R0041'
OLD_CASE=COMMON/'cases/lyd-transaction-control-20261010-003'
NEW_CASE=COMMON/'cases/lyd-transaction-control-20261010-004'
OUT=BASE/'r42-single-variable-input-comparison-20261010-001'

def ref(path):
    raw=path.read_bytes()
    return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def put(name,value):
    path=OUT/name
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,separators=(',',':'))
        stream.write('\n')
    return ref(path)

def main():
    OUT.mkdir()
    old=json.loads((OLD_CASE/'prepared/prepared-case.json').read_bytes())
    new=json.loads((NEW_CASE/'prepared/prepared-case.json').read_bytes())
    freeze_path=OLD_RUN/'frozen-argv.json'
    freeze=json.loads(freeze_path.read_bytes())
    rows=[]
    groups={'production':('mod-content/product/',71),'overlay':('mod-content/transaction_control/',6),
        'configuration':(None,4)}
    configs={'pdx_settings.txt','tutorial.txt','presets.txt','player/game_rules/presets.txt'}
    for label,(prefix,expected_count) in groups.items():
        names={key for key in new['preparation']['files'] if key.startswith(prefix)} if prefix else configs
        assert len(names)==expected_count
        for relative in sorted(names):
            # R41's allocator froze these original before-launch bytes. Its
            # subsequently played profile is not used as an input substitute.
            first=OLD_RUN/'input-snapshots/profile'/relative
            second=NEW_CASE/'state/profile'/relative
            oldref,newref=ref(first),ref(second)
            declared_old=old['preparation']['files'][relative]
            declared_new=new['preparation']['files'][relative]
            frozen=freeze['files'][str(first.resolve())]
            same=oldref['sha256']==newref['sha256']==declared_old['sha256']==declared_new['sha256']==frozen['sha256']
            size_same=oldref['bytes']==newref['bytes']==declared_old['bytes']==declared_new['bytes']==frozen['bytes']
            rows.append({'group':label,'path':relative,'sha256':oldref['sha256'],
                'new_sha256':newref['sha256'],'bytes':oldref['bytes'],'match':same and size_same})
    files_ref=put('FILE-SHA-COMPARISON.actual.json',rows)
    sys.path.insert(0,str(ROOT/'tools'))
    from ck3_mod_acceptance import Selection
    runtime=COMMON/'20261010-004/runtime.local.json'
    products=ROOT/'tools/ck3_mod_acceptance_products.json'
    selected=Selection(runtime,products,'li-yu-dao','transaction-only-control',
        prepared_path=NEW_CASE/'prepared/prepared-case.json')
    oldargv,newargv=freeze['argv'],selected.argv
    def normalized(argv):
        result=[]
        for value in argv:
            value=value.replace('\\','/')
            for actual,replacement in ((str(OLD_CASE).replace('\\','/'),'<CASE_ROOT>'),
                (str(NEW_CASE).replace('\\','/'),'<CASE_ROOT>'),('C:/csr4','<SOURCE_ROOT>'),
                ('C:/csr5','<SOURCE_ROOT>'),(freeze['run_id'],'<RUN_ID>'),('<allocated-run-id>','<RUN_ID>')):
                value=value.replace(actual,replacement)
            result.append(value)
        return result
    debug='--saved-campaign-debug-mode'
    argv_equal=normalized(oldargv)==normalized([arg for arg in newargv if arg!=debug])
    arg_ref=put('ARGV-COMPARISON.actual.json',{'r41':oldargv,'r42_selection':newargv,
        'normalizations':['case C3/C4 root','source csr4/csr5 root','allocated/template run ID'],
        'normalized_equal_excluding_new_debug_flag':argv_equal,
        'debug_flag_counts':[oldargv.count(debug),newargv.count(debug)],
        'delayed_injection_flag_counts':[oldargv.count('--saved-campaign-inject-after-load'),
            newargv.count('--saved-campaign-inject-after-load')]})
    old_contract_path=Path(old['startup']['saved_campaign_startup_case_contract'])
    new_contract_path=Path(new['startup']['saved_campaign_startup_case_contract'])
    old_contract=json.loads(old_contract_path.read_bytes());new_contract=json.loads(new_contract_path.read_bytes())
    old_contract.pop('state_dir');new_contract.pop('state_dir')
    old_seed={k:v for k,v in old['startup']['saved_campaign'].items() if k!='product_inventory'}
    new_seed={k:v for k,v in new['startup']['saved_campaign'].items() if k!='product_inventory'}
    contract_path=Path(new['contract']['path']);contract=json.loads(contract_path.read_bytes())
    baseline_pin_equal=ref(contract_path)['sha256']==old['contract']['sha256']==new['contract']['sha256']
    def option(argv,flag):return argv[argv.index(flag)+1]
    budget_flags=['--command-timeout','--readiness-timeout','--timeout','--hold-seconds','--poll-interval']
    budgets={flag:[option(oldargv,flag),option(newargv,flag)] for flag in budget_flags}
    packet={'schema':'lyd.r41-r42.file-only-single-variable-comparison.v1',
        'observed_at_utc':datetime.now(timezone.utc).isoformat(),
        'status':'MATCH_EXCEPT_EXPLICIT_SHARED_DEBUG_MODE' if all(row['match'] for row in rows) and argv_equal
            and old_contract==new_contract and old_seed==new_seed and baseline_pin_equal else 'RED',
        'r41_original_input_profile':str(OLD_RUN/'input-snapshots/profile'),
        'r42_actual_prepared_profile':str(NEW_CASE/'state/profile'),
        'file_counts':{label:sum(row['group']==label for row in rows) for label in groups},
        'all_file_hashes_match':all(row['match'] for row in rows),
        'mismatches':[row for row in rows if not row['match']],
        'seed_pin_equal':old_seed==new_seed,'seed':new_seed,'seed_body_reads':0,
        'seed_path_exists':Path(new_seed['save']).is_file(),'seed_stat_bytes':Path(new_seed['save']).stat().st_size,
        'budgets':budgets,'budgets_equal':all(first==second for first,second in budgets.values()),
        'product_contract_pin_equal':baseline_pin_equal,'product_contract':ref(contract_path),
        'baseline_cache_count':len(contract['baseline_cached_succession']),
        'political_AST_baseline_count':len(contract['political_title_ast_sha256']),
        'saved_startup_contract_equal_ignoring_state_path':old_contract==new_contract,
        'expected':new_contract['expected'],'startup_handler':new_contract['handler'],
        'debug_flag_counts':[oldargv.count(debug),newargv.count(debug)],
        'delayed_injection_flag_counts':[oldargv.count('--saved-campaign-inject-after-load'),
            newargv.count('--saved-campaign-inject-after-load')],
        'normalized_other_argv_equal':argv_equal,'r42_allocation_id':None,
        'inputs':[ref(OLD_CASE/'prepared/prepared-case.json'),ref(NEW_CASE/'prepared/prepared-case.json'),
            ref(freeze_path),ref(runtime),ref(old_contract_path),ref(new_contract_path)],
        'file_comparison':files_ref,'argv_comparison':arg_ref,'preflights_executed':0,
        'tests_executed':0,'id_allocations':0,'launches':0,'sdk_calls':0,'repository_edits':0,'business_pass':False}
    report_ref=put('REPORT.actual.json',packet)
    index=put('INDEX.json',{'author':ref(Path(__file__)),'files':[report_ref,files_ref,arg_ref]})
    print(json.dumps({'index':index,'report':report_ref,'status':packet['status'],
        'file_counts':packet['file_counts'],'all_hashes_match':packet['all_file_hashes_match'],
        'other_argv_equal':argv_equal,'debug_count':packet['debug_flag_counts'],
        'delayed_count':packet['delayed_injection_flag_counts']}))

if __name__=='__main__':
    main()
