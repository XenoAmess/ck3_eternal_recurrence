import difflib
import hashlib
import json
from pathlib import Path

base = Path('C:/workspace/ck3_lyd_runtime_20261004')
prior = base / 'r41-engine-load-callchain-diagnostic-20261010-001/CONTENT-DIFFERENCES.actual.json'
out = base / 'r42-prior-fixture-startup-hook-sourceonly-20261010-001'
data = json.loads(prior.read_text(encoding='utf-8'))
code = []
classes = []


def preserve(role, relative, frozen, variant='R38'):
    suffix = Path(relative).suffix.casefold()
    kind = 'localization-no-script-entry' if suffix == '.yml' else 'visual-asset-no-script-entry' if suffix in ('.dds', '.png', '.jpg', '.asset') else 'script-or-definition' if suffix in ('.txt', '.gui', '.mod') else 'other'
    classes.append({'role': role, 'relative': relative, 'source': frozen, 'kind': kind, 'variant': variant})
    if kind != 'script-or-definition':
        return
    raw = Path(frozen['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == frozen['sha256']
    path = out / 'source-cuts' / variant / role / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)
    lines = raw.decode('utf-8-sig').splitlines()
    numbered = path.with_name(path.name + '.numbered.txt')
    numbered.write_text('\n'.join(str(n) + ': ' + line for n, line in enumerate(lines, 1)) + '\n', encoding='utf-8')
    code.append({'role': role, 'relative': relative, 'source': frozen, 'variant': variant,
        'raw_copy': str(path), 'numbered_copy': str(numbered), 'text': '\n'.join(lines)})


for role, rows in data['R38_additional_roles_not_enabled_in_public_profiles'].items():
    for row in rows:
        preserve(role, row['relative'], row['frozen'])
for row in data['comparisons'][-1]['diagnostic_stage']['changed']:
    preserve('diagnostic_stage', row['relative'], row['R38'])
    preserve('diagnostic_stage', row['relative'], row['current'], variant='R41')
    if Path(row['relative']).suffix == '.txt':
        old = Path(row['R38']['path']).read_text(encoding='utf-8-sig').splitlines()
        new = Path(row['current']['path']).read_text(encoding='utf-8-sig').splitlines()
        name = Path(row['relative']).name + '.R38-R41.diff.txt'
        (out / name).write_text('\n'.join(difflib.unified_diff(old, new, fromfile='R38/' + row['relative'], tofile='R41/' + row['relative'])) + '\n', encoding='utf-8')
(out / 'SOURCE-CLASSES.reused.json').write_text(json.dumps(classes, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(out / 'SCRIPT-CONTENTS.actual.json').write_text(json.dumps(code, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
cold = json.loads(Path(data['R38_cold_source']['path']).read_text(encoding='utf-8'))
print(json.dumps({'production_content_shape': type(cold['content']).__name__,
    'content_first_row_shape': list(cold['content'][0]) if isinstance(cold['content'], list) else list(cold['content'])[:3],
    'script_entries': [{'role': row['role'], 'relative': row['relative'], 'variant': row['variant']} for row in code]}, ensure_ascii=False, indent=2))
