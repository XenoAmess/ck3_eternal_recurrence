024E1E80  48895c2408 mov qword ptr [rsp + 8], rbx
024E1E85  48896c2410 mov qword ptr [rsp + 0x10], rbp
024E1E8A  4889742418 mov qword ptr [rsp + 0x18], rsi
024E1E8F  57 push rdi
024E1E90  4154 push r12
024E1E92  4155 push r13
024E1E94  4156 push r14
024E1E96  4157 push r15
024E1E98  4883ec30 sub rsp, 0x30
024E1E9C  488bd9 mov rbx, rcx
024E1E9F  498be8 mov rbp, r8
024E1EA2  488bca mov rcx, rdx
024E1EA5  e8161c3e00 call 0x28c3ac0
024E1EAA  4533ed xor r13d, r13d
024E1EAD  488bf8 mov rdi, rax
024E1EB0  bea0860100 mov esi, 0x186a0
024E1EB5  41beae000000 mov r14d, 0xae
024E1EBB  4885ed test rbp, rbp
024E1EBE  7416 je 0x24e1ed6
024E1EC0  458bc6 mov r8d, r14d
024E1EC3  44896c2420 mov dword ptr [rsp + 0x20], r13d
024E1EC8  448bce mov r9d, esi
024E1ECB  488bd0 mov rdx, rax
024E1ECE  488bcd mov rcx, rbp
024E1ED1  e89aa4f4ff call 0x242c370
024E1ED6  4c634f74 movsxd r9, dword ptr [rdi + 0x74]
024E1EDA  4c8b5768 mov r10, qword ptr [rdi + 0x68]
024E1EDE  4d8bc2 mov r8, r10
024E1EE1  4f8d1c4a lea r11, [r10 + r9*2]
024E1EE5  4d85c9 test r9, r9
024E1EE8  7e24 jle 0x24e1f0e
024E1EEA  660f1f440000 nop word ptr [rax + rax]
024E1EF0  498bd1 mov rdx, r9
024E1EF3  48d1ea shr rdx, 1
024E1EF6  4c2bca sub r9, rdx
024E1EF9  6645393450 cmp word ptr [r8 + rdx*2], r14w
024E1EFE  4b8d0c48 lea rcx, [r8 + r9*2]
024E1F02  4c8bca mov r9, rdx
024E1F05  4c0f42c1 cmovb r8, rcx
024E1F09  4885d2 test rdx, rdx
024E1F0C  75e2 jne 0x24e1ef0
024E1F0E  48bd66e6096a01000000 movabs rbp, 0x16a09e666
024E1F18  49bf09e1d1c6116bf129 movabs r15, 0x29f16b11c6d1e109
024E1F22  41bc33f304b5 mov r12d, 0xb504f333
024E1F28  4d3bc3 cmp r8, r11
024E1F2B  7478 je 0x24e1fa5
024E1F2D  66453b30 cmp r14w, word ptr [r8]
024E1F31  7272 jb 0x24e1fa5
024E1F33  4d2bc2 sub r8, r10
024E1F36  49d1f8 sar r8, 1
024E1F39  4585c0 test r8d, r8d
024E1F3C  7867 js 0x24e1fa5
024E1F3E  488b87d0000000 mov rax, qword ptr [rdi + 0xd0]
024E1F45  4963c8 movsxd rcx, r8d
024E1F48  4c8b14c8 mov r10, qword ptr [rax + rcx*8]
024E1F4C  4b8d0422 lea rax, [r10 + r12]
024E1F50  483bc5 cmp rax, rbp
024E1F53  7653 jbe 0x24e1fa8
024E1F55  4c3bd6 cmp r10, rsi
024E1F58  4c8bc6 mov r8, rsi
024E1F5B  498bc7 mov rax, r15
024E1F5E  4d0f4fc2 cmovg r8, r10
024E1F62  490f4cf2 cmovl rsi, r10
024E1F66  49f7e8 imul r8
024E1F69  488bca mov rcx, rdx
024E1F6C  48c1f90e sar rcx, 0xe
024E1F70  488bc1 mov rax, rcx
024E1F73  48c1e83f shr rax, 0x3f
024E1F77  4803c8 add rcx, rax
024E1F7A  4869c1a0860100 imul rax, rcx, 0x186a0
024E1F81  480fafce imul rcx, rsi
024E1F85  4c2bc0 sub r8, rax
024E1F88  498bc7 mov rax, r15
024E1F8B  4c0fafc6 imul r8, rsi
024E1F8F  49f7e8 imul r8
024E1F92  48c1fa0e sar rdx, 0xe
024E1F96  4c8bd2 mov r10, rdx
024E1F99  49c1ea3f shr r10, 0x3f
024E1F9D  4c03d2 add r10, rdx
024E1FA0  4c03d1 add r10, rcx
024E1FA3  eb03 jmp 0x24e1fa8
024E1FA5  4d8bd5 mov r10, r13
024E1FA8  488b13 mov rdx, qword ptr [rbx]
024E1FAB  4981c2a0860100 add r10, 0x186a0
024E1FB2  4d0f48d5 cmovs r10, r13
024E1FB6  4a8d0422 lea rax, [rdx + r12]
024E1FBA  4f8d1c22 lea r11, [r10 + r12]
024E1FBE  483bc5 cmp rax, rbp
024E1FC1  7722 ja 0x24e1fe5
024E1FC3  4c3bdd cmp r11, rbp
024E1FC6  771d ja 0x24e1fe5
024E1FC8  498bca mov rcx, r10
024E1FCB  498bc7 mov rax, r15
024E1FCE  480fafca imul rcx, rdx
024E1FD2  48f7e9 imul rcx
024E1FD5  48c1fa0e sar rdx, 0xe
024E1FD9  488bc2 mov rax, rdx
024E1FDC  48c1e83f shr rax, 0x3f
024E1FE0  4803d0 add rdx, rax
024E1FE3  eb51 jmp 0x24e2036
024E1FE5  4c3bd2 cmp r10, rdx
024E1FE8  4d8bc2 mov r8, r10
024E1FEB  4d8bca mov r9, r10
024E1FEE  498bc7 mov rax, r15
024E1FF1  4c0f4cc2 cmovl r8, rdx
024E1FF5  4c0f4fca cmovg r9, rdx
024E1FF9  49f7e8 imul r8
024E1FFC  488bca mov rcx, rdx
024E1FFF  48c1f90e sar rcx, 0xe
024E2003  488bc1 mov rax, rcx
024E2006  48c1e83f shr rax, 0x3f
024E200A  4803c8 add rcx, rax
024E200D  4869c1a0860100 imul rax, rcx, 0x186a0
024E2014  4c2bc0 sub r8, rax
024E2017  498bc7 mov rax, r15
024E201A  4d0fafc1 imul r8, r9
024E201E  4c0fafc9 imul r9, rcx
024E2022  49f7e8 imul r8
024E2025  48c1fa0e sar rdx, 0xe
024E2029  488bc2 mov rax, rdx
024E202C  48c1e83f shr rax, 0x3f
024E2030  4803d0 add rdx, rax
024E2033  4903d1 add rdx, r9
024E2036  488913 mov qword ptr [rbx], rdx
024E2039  488b5330 mov rdx, qword ptr [rbx + 0x30]
024E203D  4a8d0422 lea rax, [rdx + r12]
024E2041  483bc5 cmp rax, rbp
024E2044  7722 ja 0x24e2068
024E2046  4c3bdd cmp r11, rbp
024E2049  771d ja 0x24e2068
024E204B  498bca mov rcx, r10
024E204E  498bc7 mov rax, r15
024E2051  480fafca imul rcx, rdx
024E2055  48f7e9 imul rcx
024E2058  48c1fa0e sar rdx, 0xe
024E205C  488bc2 mov rax, rdx
024E205F  48c1e83f shr rax, 0x3f
024E2063  4803d0 add rdx, rax
024E2066  eb51 jmp 0x24e20b9
024E2068  4c3bd2 cmp r10, rdx
024E206B  4d8bc2 mov r8, r10
024E206E  4d8bca mov r9, r10
024E2071  498bc7 mov rax, r15
024E2074  4c0f4cc2 cmovl r8, rdx
024E2078  4c0f4fca cmovg r9, rdx
024E207C  49f7e8 imul r8
024E207F  488bca mov rcx, rdx
024E2082  48c1f90e sar rcx, 0xe
024E2086  488bc1 mov rax, rcx
024E2089  48c1e83f shr rax, 0x3f
024E208D  4803c8 add rcx, rax
024E2090  4869c1a0860100 imul rax, rcx, 0x186a0
024E2097  4c2bc0 sub r8, rax
024E209A  498bc7 mov rax, r15
024E209D  4d0fafc1 imul r8, r9
024E20A1  4c0fafc9 imul r9, rcx
024E20A5  49f7e8 imul r8
024E20A8  48c1fa0e sar rdx, 0xe
024E20AC  488bc2 mov rax, rdx
024E20AF  48c1e83f shr rax, 0x3f
024E20B3  4803d0 add rdx, rax
024E20B6  4903d1 add rdx, r9
024E20B9  48895330 mov qword ptr [rbx + 0x30], rdx
024E20BD  488b5338 mov rdx, qword ptr [rbx + 0x38]
024E20C1  4a8d0c22 lea rcx, [rdx + r12]
024E20C5  483bcd cmp rcx, rbp
024E20C8  7723 ja 0x24e20ed
024E20CA  4c3bdd cmp r11, rbp
024E20CD  771e ja 0x24e20ed
024E20CF  4c0fafd2 imul r10, rdx
024E20D3  498bc7 mov rax, r15
024E20D6  49f7ea imul r10
024E20D9  48c1fa0e sar rdx, 0xe
024E20DD  488bc2 mov rax, rdx
024E20E0  48c1e83f shr rax, 0x3f
024E20E4  4803d0 add rdx, rax
024E20E7  48895338 mov qword ptr [rbx + 0x38], rdx
024E20EB  eb52 jmp 0x24e213f
024E20ED  4c3bd2 cmp r10, rdx
024E20F0  4d8bc2 mov r8, r10
024E20F3  498bc7 mov rax, r15
024E20F6  4c0f4cc2 cmovl r8, rdx
024E20FA  4c0f4fd2 cmovg r10, rdx
024E20FE  49f7e8 imul r8
024E2101  488bca mov rcx, rdx
024E2104  48c1f90e sar rcx, 0xe
024E2108  488bc1 mov rax, rcx
024E210B  48c1e83f shr rax, 0x3f
024E210F  4803c8 add rcx, rax
024E2112  4869c1a0860100 imul rax, rcx, 0x186a0
024E2119  4c2bc0 sub r8, rax
024E211C  498bc7 mov rax, r15
024E211F  4d0fafc2 imul r8, r10
024E2123  4c0fafd1 imul r10, rcx
024E2127  49f7e8 imul r8
024E212A  48c1fa0e sar rdx, 0xe
024E212E  488bc2 mov rax, rdx
024E2131  48c1e83f shr rax, 0x3f
024E2135  4803c2 add rax, rdx
024E2138  4903c2 add rax, r10
024E213B  48894338 mov qword ptr [rbx + 0x38], rax
024E213F  488b5c2460 mov rbx, qword ptr [rsp + 0x60]
024E2144  488b6c2468 mov rbp, qword ptr [rsp + 0x68]
024E2149  488b742470 mov rsi, qword ptr [rsp + 0x70]
024E214E  4883c430 add rsp, 0x30
024E2152  415f pop r15
024E2154  415e pop r14
024E2156  415d pop r13
024E2158  415c pop r12
024E215A  5f pop rdi
024E215B  c3 ret 
