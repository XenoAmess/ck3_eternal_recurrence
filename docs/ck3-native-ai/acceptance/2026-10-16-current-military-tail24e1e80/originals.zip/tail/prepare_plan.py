from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess

R=Path(__file__).resolve().parent
BASE=R.parent
OLD=BASE/'maintenance-current-vector28C43A0-source-a02'
def need(ok,m):
    if not ok:raise ValueError(m)
def main():
    p=json.loads((OLD/'plan-a01.json').read_bytes())
    p.update(topic='Exact4-current-vector-tail24E1E80',question='What are all branches, input roles and80B vector effects of the unique source-reached24E1E80? Is any explicit settlementterm or wallet edge present?',created_utc=dt.datetime.now(dt.timezone.utc).isoformat())
    p['observation'].update(producer='Complete402B28C43A0 source direct CALL28C451A-to-24E1E80',caller='RCX=output80B,RDX=originalCharacter,R8=0 in known currentrate query path',consumer='Known caller returns original output pointer after tail processing',expected_signal='Full unique function and every branch, concrete80B vector operations and explicit context28/30/wallet edges only',stop_condition='Only .pdata exact24E1E80,metadata<=512B/read<=48,unique unchained entry extent<=8192B otherwise stop. No recursivecallee,neighbor,globalxref,wholeEXEhash,SDK,desktop,EXEexecution,build or main action.',runtime_window_ref='Offline exact source only; no runtime sample or new observation qualification')
    p['evidence']=[x for x in p['evidence'] if x['id'] in ('identity','layout')]
    source=OLD/'SOURCE-CONTRACT.actual.json'
    p['evidence'].append(dict(id='caller402',layer='source-contract',path=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),exe_sha256=p['build']['exe_sha256'],supports='Full402B source proves unique direct call28C451A and input roles; no tail or military semantics presumed'))
    p['nodes']=[dict(id='caller',label='Known output80B tail call'),dict(id='tail',label='Unknown24E1E80 body'),dict(id='terms',label='c/d and wallet link unknown')]
    p['edges']=[dict(id='body',**{'from':'caller','to':'tail'},label='Unique complete body/all branches',status='unknown',evidence=['caller402'],open_question='Exact vector operations and input conditions'),dict(id='relation',**{'from':'tail','to':'terms'},label='Only explicit source relationship',status='unknown',evidence=[],open_question='Do concrete addresses/typed inputs connect to settlement fields or wallet?')]
    p['cases']=[dict(id='vector-impact',question='All explicit80B output modifications and residual callees',status='pending',evidence=[])]
    path=R/'plan-a01.json'
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(p,f,indent=2);f.write('\n')
    s=(OLD/'read_actual_vector.py').read_text().replace('28C43A0','24E1E80')
    anchor="        new('actual-function.asm',asm)\n"
    need(anchor in s,'Exact disassembly seam missing')
    s=s.replace("{i.bytes.hex(\" \"):<44}","{i.bytes.hex()}")
    branches="""        starts={i.address for i in ins}
        branches=[]
        for i in ins:
            if not i.group(capstone.CS_GRP_JUMP):continue
            direct=bool(i.operands and i.operands[0].type==X86_OP_IMM)
            target=i.operands[0].imm if direct else None
            internal=direct and begin<=target<end
            need(not internal or target in starts,'Internal branch target not an instruction boundary')
            branches.append(dict(at_rva=i.address,mnemonic=i.mnemonic,bytes_hex=i.bytes.hex(),target_rva=target,internal=internal,target_instruction_boundary=target in starts if direct else None,fallthrough_rva=i.address+i.size if i.mnemonic!='jmp' else None))
"""
    s=s.replace(anchor,anchor+branches)
    old='instruction_count=len(ins),direct_calls_and_jumps=calls)'
    need(old in s,'Exact receipt seam missing')
    s=s.replace(old,'instruction_count=len(ins),direct_calls_and_jumps=calls,branches=branches,unique_branch_targets=sorted({x["target_rva"] for x in branches if x["target_rva"] is not None}))')
    with (R/'read_actual_tail.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    argv=['D:/workspace/ck3_eternal_recurrence/tools/.venv/Scripts/python.exe','-B','-O','D:/workspace/ck3_eternal_recurrence/tools/native_research_plan.py','check',str(path)]
    with (R/'plan-check.stdout').open('xb') as out,(R/'plan-check.stderr').open('xb') as err:r=subprocess.run(argv,stdout=out,stderr=err,check=False)
    with (R/'PLAN-CHECK.actual.json').open('x',encoding='utf-8') as f:json.dump(dict(argv=argv,returncode=r.returncode,at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),plan_sha256=hashlib.sha256(path.read_bytes()).hexdigest()),f,indent=2)
    need(r.returncode==0,'Finite plan failed')
    print(json.dumps(dict(plan=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),new_EXE_bytes=0)))
    return 0
if __name__=='__main__':raise SystemExit(main())
