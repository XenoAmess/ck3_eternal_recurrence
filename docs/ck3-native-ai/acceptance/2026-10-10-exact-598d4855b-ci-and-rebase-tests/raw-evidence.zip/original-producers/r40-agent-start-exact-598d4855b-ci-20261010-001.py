"""Preserve the old watcher and create an exact-head observation for R40."""
from pathlib import Path
import subprocess
import sys

base=Path('C:/workspace/ck3_lyd_runtime_20261004')
original=base/'r39-agent-watch-exact-00b88fc4d-ci-20261010-001.py'
source=original.read_text(encoding='utf-8')
old_sha='00b88fc4df0b8b4cea8b15ff85de8f244825a329'
new_sha='598d4855b1a5e7678fa2253e5664acb991c0c825'
old_directory='r39-exact-00b88fc4d-ci-20261010-001'
new_directory='r40-exact-598d4855b-ci-20261010-001'
if source.count(old_sha)!=1 or source.count(old_directory)!=1:
    raise RuntimeError('Original watcher shape changed; refuse an ambiguous retarget')
source=source.replace(old_sha,new_sha).replace(old_directory,new_directory)
watcher=base/'r40-agent-watch-exact-598d4855b-ci-20261010-001.py'
with watcher.open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(source)
raise SystemExit(subprocess.run([sys.executable,'-B','-X','utf8',str(watcher)],cwd=base).returncode)
