"""Package existing terminal CI and rebase test receipts; never run commands/API."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import zipfile


PACKAGE = Path(__file__).resolve().parent
CI = PACKAGE.parent / 'r40-exact-598d4855b-ci-20261010-001'
CHECKS = Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-002')
HEAD = '598d4855b1a5e7678fa2253e5664acb991c0c825'
RELATIVE = Path('docs/ck3-native-ai/acceptance/2026-10-10-exact-598d4855b-ci-and-rebase-tests')
OUT = PACKAGE / 'candidate' / RELATIVE
EXPECTED = [
    ('001', 'test_ck3_mod_acceptance_adapters.py', 9),
    ('002', 'test_ck3_mod_acceptance_bootstrap.py', 10),
    ('003', 'test_ck3_mod_acceptance.py', 15),
    ('004', 'test_ck3_mod_acceptance_operator_quit.py', 16),
    ('005', 'test_ck3_mod_acceptance_normal_close.py', 4),
]


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


final = read(CI / 'FINAL.actual.json')
terminal = read(CI / 'TERMINAL-EVIDENCE.actual.json')
require(final['head_sha'] == terminal['head_sha'] == HEAD, 'Exact CI head differs')
require(final['triggered_workflows_terminal'] is True, 'CI is not terminal')
for name in ('Official Runner CI', 'Linear history'):
    workflow = terminal['workflow_status'][name]
    require(workflow['head_sha'] == HEAD and workflow['status'] == 'completed' and
            workflow['conclusion'] == 'success', 'Actual official/linear CI is not successful')
    archive = workflow['full_log_archive']
    raw = (CI / archive['file']).read_bytes()
    require(digest(raw) == {key: archive[key] for key in ('bytes', 'sha256')}, 'Official raw logs ZIP changed')
    with zipfile.ZipFile(CI / archive['file']) as zipped:
        require(zipped.testzip() is None, 'Original official log ZIP CRC failed')
        require(set(zipped.namelist()) == {row['path'] for row in archive['entries']}, 'Official logs entry set changed')
        for row in archive['entries']:
            require(digest(zipped.read(row['path'])) == {key: row[key] for key in ('bytes', 'sha256')},
                    'Original official logs entry bytes changed')
require(terminal['workflow_status']['Li Yu Dao static checks']['status'] == 'NOT_TRIGGERED',
        'Li Yu Dao workflow observation changed')
verified_queries = []
for label in terminal['verified_query_labels']:
    metadata = read(CI / (label + '.actual.json'))
    stdouts = list(CI.glob(label + '.stdout.*'))
    require(len(stdouts) == 1, 'Ambiguous actual API stdout')
    for path, key in ((stdouts[0], 'stdout'), (CI / (label + '.stderr.log'), 'stderr')):
        actual = digest(path.read_bytes())
        require(actual['sha256'] == metadata[key + '_sha256'], 'Original API bytes changed')
        if key + '_bytes' in metadata:
            require(actual['bytes'] == metadata[key + '_bytes'], 'Original API byte count changed')
    verified_queries.append(label)
require(len(verified_queries) == terminal['original_query_pairs_byte_hash_verified'] == 50,
        'Expected original 50 actual API/query groups')

rebase = []
for suffix, test_file, count in EXPECTED:
    root = CHECKS / ('rebase-check-' + suffix)
    result = read(root / 'RESULT.actual.json')
    require(result['schema'] == 'ck3-recorded-actual-command-v1' and result['exit_code'] == 0,
            'Original local test command is not PASS')
    argv = result['argv']
    require(argv[argv.index('-p') + 1] == test_file and '-B' in argv and 'utf8' in argv,
            'Original local test command differs')
    for stream in ('stdout', 'stderr'):
        actual = digest((root / (stream + '.log')).read_bytes())
        require(actual == {key: result[stream][key] for key in ('bytes', 'sha256')},
                'Original local test log changed')
    lines = (root / 'stderr.log').read_text(encoding='utf-8-sig').splitlines()
    summaries = [re.fullmatch(r'Ran (\d+) tests? in .+', line) for line in lines]
    counts = [int(match.group(1)) for match in summaries if match]
    require(counts == [count] and [line for line in lines if line.strip()][-1] == 'OK',
            'Original unittest count/OK differs')
    rebase.append({'source_directory': str(root), 'test_file': test_file, 'tests': count,
                   'exit_code': result['exit_code'], 'argv': argv,
                   'started_at_utc': result['started_at_utc'], 'finished_at_utc': result['finished_at_utc'],
                   'original_receipt_has_head_sha': 'head_sha' in result,
                   'original_receipt_has_source_pins': 'source_pins' in result,
                   'result_pin': digest((root / 'RESULT.actual.json').read_bytes())})
require(sum(row['tests'] for row in rebase) == 54, 'Local regression total differs')

payloads = {}
origins = {}
for path in sorted(CI.iterdir()):
    require(path.is_file(), 'Unexpected CI nested directory; bound packaging scope explicitly')
    relative = 'exact-ci/' + path.name
    payloads[relative] = path.read_bytes()
    origins[relative] = str(path)
for suffix, _, _ in EXPECTED:
    root = CHECKS / ('rebase-check-' + suffix)
    require({path.name for path in root.iterdir()} == {'RESULT.actual.json', 'stdout.log', 'stderr.log'},
            'Unexpected local regression contents')
    for path in sorted(root.iterdir()):
        relative = 'local-rebase-tests/' + root.name + '/' + path.name
        payloads[relative] = path.read_bytes()
        origins[relative] = str(path)
for name in ('r40-agent-start-exact-598d4855b-ci-20261010-001.py',
             'r40-agent-watch-exact-598d4855b-ci-20261010-001.py',
             'r40-agent-complete-exact-598d4855b-ci-20261010-001.py'):
    path = PACKAGE.parent / name
    relative = 'original-producers/' + name
    payloads[relative] = path.read_bytes()
    origins[relative] = str(path)
relative = 'package-producer/produce-package.py'
payloads[relative] = Path(__file__).read_bytes()
origins[relative] = str(Path(__file__).resolve())

OUT.mkdir(parents=True, exist_ok=False)
archive_path = OUT / 'raw-evidence.zip'
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, raw in sorted(payloads.items()):
        info = zipfile.ZipInfo(name)
        info.compress_type = zipfile.ZIP_DEFLATED
        zipped.writestr(info, raw, compresslevel=9)
with zipfile.ZipFile(archive_path) as zipped:
    require(zipped.testzip() is None, 'Package ZIP CRC failed')
    require(set(zipped.namelist()) == set(payloads), 'Package ZIP entry inventory changed')
    for name, raw in payloads.items():
        require(zipped.read(name) == raw, 'Package ZIP did not retain exact original bytes')
archive_pin = {'path': archive_path.name, **digest(archive_path.read_bytes())}
index = {'schema': 'ck3.exact-ci-and-rebase-regression-archive.v1',
         'created_at_utc': datetime.now(timezone.utc).isoformat(),
         'suggested_repository_directory': RELATIVE.as_posix(), 'exact_ci_head': HEAD,
         'archive': archive_pin,
         'entries': [{'path': name, 'source_path': origins[name], **digest(raw)}
                     for name, raw in sorted(payloads.items())]}
write(OUT / 'INDEX.json', index)
result = {'schema': 'ck3.exact-ci-and-rebase-regression-result.v1',
          'exact_ci_head': HEAD, 'official_ci': 'success', 'linear_history': 'success',
          'li_yu_dao_static_checks': 'NOT_TRIGGERED', 'not_triggered_counted_as_success': False,
          'original_ci_query_groups_verified': len(verified_queries),
          'terminal_workflow_evidence': terminal['workflow_status'],
          'local_rebase_regressions': rebase, 'total_local_passed_tests': 54,
          'local_receipt_provenance_limit': 'Original local command receipts do not record HEAD/source pins; preserve this omission and keep them separate from exact-SHA official CI.',
          'raw_evidence': archive_pin, 'tests_rerun_during_packaging': False,
          'ci_api_queries_during_packaging': False, 'repository_modified_during_packaging': False,
          'live_acceptance_or_business_green_claimed': False}
write(OUT / 'RESULT.actual.json', result)
write(OUT / 'ARCHIVE-VALIDATION.actual.json', {
    'schema': 'ck3.raw-evidence-archive-validation.v1', 'archive': archive_pin,
    'verified_at_utc': datetime.now(timezone.utc).isoformat(),
    'entries_verified': len(payloads), 'all_entries_byte_exact': True, 'zip_crc_ok': True,
    'original_api_query_groups_verified': 50, 'original_rebase_test_log_pairs_verified': 5,
    'original_official_complete_log_archives_verified': 2})

report = f'''# 精确 598d4855b 官方 CI 与 rebase 回归证据（2026-10-10）

精确提交 `{HEAD}` 的 Official Runner CI 与 Linear history 均已实际完成并成功。
Li Yu Dao static checks 为 **NOT_TRIGGERED**，不计为成功。

| 工作流 | 实际终态 | 原始运行 |
| --- | --- | --- |
| Official Runner CI | completed / success | [37988052013](https://github.com/XenoAmess/ck3_eternal_recurrence/actions/runs/37988052013) |
| Linear history | completed / success | [37988052148](https://github.com/XenoAmess/ck3_eternal_recurrence/actions/runs/37988052148) |
| Li Yu Dao static checks | NOT_TRIGGERED | 精确 HEAD 的真实 API 无对应 run |

官方共享 `Test shared CK3 acceptance without installed CK3` 步骤明确成功。
两份完整官方日志 ZIP、terminal jobs、FINAL、TERMINAL-EVIDENCE 及全部 50 组实际
API/query stdout、stderr、metadata 均保留原字节；查询中短暂失败的 jobs 回执也原样保留。
Official 日志 ZIP 为 119776 bytes，SHA-256
`ff2f14cf2f678ae9487c5fcdef336c0cf00c7eda4199f64e821725bd135b38e8`；
Linear 日志 ZIP 为 16390 bytes，SHA-256
`6b56ad13ff1290d07b1a27d5a3aaede10895e5f695c4a3c07dedd7fedae0d68f`。

Root rebase 后的五份本地实际命令回执另行保全，共 **54 项 PASS**：

| 原目录 | 测试集 | 实际结果 |
| --- | --- | --- |
| rebase-check-001 | adapters | 9 / 9 |
| rebase-check-002 | bootstrap | 10 / 10 |
| rebase-check-003 | entry | 15 / 15 |
| rebase-check-004 | operator quit | 16 / 16 |
| rebase-check-005 | normal close | 4 / 4 |

五份原始 RESULT 的退出码均为 0，stdout/stderr pins 与原件相同，unittest 原日志的数量及 OK
均已核对；命令与 UTC 时间见 [RESULT.actual.json](RESULT.actual.json)。原本地回执没有
HEAD/source pins，本包保留该原始边界，不补造精确源码绑定；精确 SHA 的通过结论来自上述官方 CI。

封存 [raw-evidence.zip](raw-evidence.zip)：{archive_pin['bytes']} bytes，SHA-256
`{archive_pin['sha256']}`。全部 {len(payloads)} 项原件的源路径、大小与 SHA 见
[INDEX.json](INDEX.json)，[ARCHIVE-VALIDATION.actual.json](ARCHIVE-VALIDATION.actual.json)
记录 ZIP CRC 与逐项 byte-exact 读回。生产脚本在 ZIP 的 `package-producer/produce-package.py`；
它只读取既有回执，不调用测试、GitHub API 或仓库写入。

旧 `00b88fc4d` 官方失败与修复前复现继续保留于
[公共 allocator CI 夹具修复](../../2026-10-10-common-allocator-ci-fixture.md)，本记录是另一精确来源的成功结果。
本次只是既有证据封存，没有重跑测试/CI，没有修改冻结 checkout；CI 成功与静态回归不授予
共享 runtime 资格、R40 实机通过或产品业务 GREEN。
'''
with (OUT / 'REPORT.md').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(report)
manifest = {'schema': 'ck3.external-repository-candidate-package.v1',
            'created_at_utc': datetime.now(timezone.utc).isoformat(),
            'status': 'EXTERNAL_CANDIDATE_NOT_APPLIED_NOT_COMMITTED',
            'suggested_repository_directory': RELATIVE.as_posix(),
            'files': [{'candidate_path': str(path.relative_to(PACKAGE)).replace('\\', '/'),
                       'suggested_repository_path': (RELATIVE / path.name).as_posix(),
                       **digest(path.read_bytes())} for path in sorted(OUT.iterdir())],
            'producer': {'path': 'produce-package.py', **digest(Path(__file__).read_bytes())}}
write(PACKAGE / 'PACKAGE.actual.json', manifest)
print(json.dumps({'output': str(PACKAGE), 'candidate': str(OUT), 'archive': archive_pin,
                  'raw_entries': len(payloads), 'local_tests': 54,
                  'package_manifest': digest((PACKAGE / 'PACKAGE.actual.json').read_bytes())}), flush=True)
