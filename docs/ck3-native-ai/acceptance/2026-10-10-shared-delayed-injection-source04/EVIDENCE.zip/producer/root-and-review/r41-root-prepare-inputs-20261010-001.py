from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

previous = Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-002/prepare-inputs.json')
target = Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-003')
original = previous.read_bytes()
data = json.loads(original)
prior_state = data['state_dir']
data['state_dir'] = str(target / 'state')
if target.exists():
    raise SystemExit('Preserve existing case; require a new destination')
target.mkdir()
for name, value in [
    ('prepare-inputs.json', data),
    ('INPUT-PROVENANCE.actual.json', {
        'at_utc': datetime.now(timezone.utc).isoformat(),
        'original': {'path': str(previous), 'bytes': len(original), 'sha256': hashlib.sha256(original).hexdigest()},
        'only_case_input_change': {'field': 'state_dir', 'before': prior_state, 'after': data['state_dir']},
        'same_fixed_saved_campaign': True, 'same_formal_product_and_overlay': True,
        'old_runs_and_profiles_preserved': True, 'shared_manifest': 'C:/workspace/ck3-common-runtime/20261010-003/manifest.json',
        'startup_readiness_seconds': 600, 'machine_bootstrap_repeat_allowed': False,
        'business_credit': False, 'game_started': False,
    }),
]:
    with (target / name).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
print(json.dumps({'case_inputs': str(target / 'prepare-inputs.json'), 'state_dir': data['state_dir']}))
