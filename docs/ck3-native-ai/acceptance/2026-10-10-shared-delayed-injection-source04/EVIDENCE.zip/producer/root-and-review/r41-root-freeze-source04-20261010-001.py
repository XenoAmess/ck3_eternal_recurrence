import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

REPO = Path('C:/workspace/ck3_eternal_recurrence')
OLD = Path('C:/workspace/ck3-common-runtime/20261010-002')
OUT = Path('C:/workspace/ck3-common-runtime/20261010-003')
SOURCE = Path('C:/csr4')
BASE = '13d063c81ff706d8bc3f9a8bf81f60c283338042'
AUTHOR = sys.argv[1]
PATHS = [
    'ck3_autonomous_player/src/xar_autoplayer/runtime.py',
    'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py',
    'tools/ck3_mod_acceptance.py',
    'tools/test_ck3_mod_acceptance.py',
    'ck3_autonomous_player/tests/unit/test_saved_campaign_delayed_injection.py',
]

def git(*args, env=None, data=None):
    result = subprocess.run(['git', *args], cwd=REPO, env=env, input=data, capture_output=True)
    if result.returncode:
        raise RuntimeError(json.dumps({'argv': args, 'returncode': result.returncode,
            'stdout': result.stdout.decode('utf-8', 'replace'), 'stderr': result.stderr.decode('utf-8', 'replace')}))
    return result.stdout

def pin(path):
    raw = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def put(path, obj):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(obj, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

if OUT.exists() or SOURCE.exists():
    raise SystemExit('New source/runtime destinations must not already exist')
author = git('rev-parse', '--verify', AUTHOR + '^{commit}').decode().strip()
parent = git('rev-parse', author + '^').decode().strip()
changed = git('diff-tree', '--no-commit-id', '--name-only', '-r', author).decode().splitlines()
if sorted(changed) != sorted(PATHS):
    raise SystemExit('Authored commit contains unexpected paths: ' + repr(changed))
OUT.mkdir()
patch = git('diff', '--binary', parent, author, '--', *PATHS)
(OUT / 'shared-delayed-injection-author.patch').write_bytes(patch)
environment = os.environ.copy()
environment['GIT_INDEX_FILE'] = str(OUT / 'freeze.index')
git('read-tree', BASE, env=environment)
git('apply', '--cached', '--whitespace=error', str(OUT / 'shared-delayed-injection-author.patch'), env=environment)
tree = git('write-tree', env=environment).decode().strip()
message = ('Freeze shared same-process saved-load injection policy\n\n'
    f'Apply only the shared Python change from {author} to fixed common source {BASE}.\n'
    'This archive revision preserves native build inputs; it is not a product-selected runtime.\n')
frozen = git('commit-tree', tree, '-p', BASE, data=message.encode()).decode().strip()
tag = 'archive/common-runtime-source04-20261010'
git('tag', tag, frozen)
archive = OUT / 'shared-source04.zip'
git('archive', '--format=zip', '--output', str(archive), frozen,
    'tools', 'ck3_autonomous_player', 'ck3_workshop_mcp', 'promo/ck3_native_war_ai/integration')
SOURCE.mkdir()
with zipfile.ZipFile(archive) as stream:
    for name in stream.namelist():
        if Path(name).is_absolute() or '..' in Path(name).parts:
            raise RuntimeError('Unsafe archive entry: ' + name)
    stream.extractall(SOURCE)

def inventory(root):
    return {path.relative_to(root).as_posix(): {key: value for key, value in pin(path).items() if key != 'path'}
        for path in sorted(root.rglob('*')) if path.is_file()}

old = json.loads((OLD / 'source03-index.json').read_bytes())['files']
current = inventory(SOURCE)
changes = [path for path in sorted(set(old) | set(current)) if old.get(path) != current.get(path)]
if sorted(changes) != sorted(PATHS):
    raise RuntimeError('Frozen source has unintended changes: ' + repr(changes))
native_changes = [path for path in changes if path.startswith('ck3_autonomous_player/native_bridge/')]
expected_host = 'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py'
if native_changes != [expected_host]:
    raise RuntimeError('Native compiled inputs changed: ' + repr(native_changes))
put(OUT / 'source04-index.json', {'schema': 'ck3-common-source-index-v1', 'source_commit': frozen, 'files': current})
put(OUT / 'native-source04-index.json', {'schema': 'ck3-common-native-source-index-v1', 'source_commit': frozen,
    'files': {key: value for key, value in current.items() if key.startswith('ck3_autonomous_player/native_bridge/')}})
put(OUT / 'SOURCE04-NATIVE-REUSE.actual.json', {
    'schema': 'ck3-common-runtime-python-successor-v1', 'source03_commit': BASE, 'source04_commit': frozen,
    'author_commit': author, 'author_parent': parent, 'archive_tag': tag,
    'source03_root': 'C:/csr3', 'source04_root': str(SOURCE), 'source04_archive': pin(archive),
    'minimal_authored_patch': pin(OUT / 'shared-delayed-injection-author.patch'),
    'source03_index': pin(OLD / 'source03-index.json'), 'source04_index': pin(OUT / 'source04-index.json'),
    'all_changed_paths': changes, 'changed_native_directory_paths': native_changes,
    'every_other_native_directory_file_byte_equal': True, 'native_compiled_inputs_unchanged': True,
    'artifact_build_result': pin(OLD / 'BUILD-RESULT.actual.json'),
    'source04_host': pin(SOURCE / expected_host), 'live_qualification': 'NOT_RUN',
    'product_qualification': 'NOT_ASSESSED',
    'scope': 'One machine-global common runtime for all products; fixed predecessor plus this shared Python fix only.',
})
print(json.dumps({'frozen_commit': frozen, 'archive_tag': tag, 'author_commit': author,
    'all_changed_paths': changes, 'native_changes': native_changes,
    'receipt': pin(OUT / 'SOURCE04-NATIVE-REUSE.actual.json')}, ensure_ascii=False))
