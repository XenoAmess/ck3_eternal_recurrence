"""Close a source-only review of the author's exact committed delayed-injection delta."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,subprocess

REPO=Path('C:/workspace/ck3_eternal_recurrence')
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT=BASE/'r41-delayed-injection-independent-review-20261010-001'
AUTHOR=BASE/'r40-delayed-saved-injection-author-handoff-20261010-001/INDEX.json'
COMMIT='1d4468fc35361be5126acd84402ef27b87d71254'
author=json.loads(AUTHOR.read_text(encoding='utf-8-sig'))
probe=json.loads((OUT/'PROBE.actual.json').read_text(encoding='utf-8-sig'))

def require(value,message):
    if not value:raise RuntimeError(message)

def digest(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')

require(author['author_commit']==COMMIT,'Author final commit changed')
(OUT/'AUTHOR-INDEX.original.json').write_bytes(AUTHOR.read_bytes())
files=[];sources={}
for row in author['files']:
    relative=Path(row['path']).relative_to(REPO).as_posix()
    argv=['git','show',COMMIT+':'+relative]
    result=subprocess.run(argv,cwd=REPO,capture_output=True,check=True)
    require(digest(result.stdout)=={key:row[key] for key in ('bytes','sha256')},'Committed author file differs from final INDEX')
    path=OUT/'author-final-source'/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(result.stdout)
    sources[relative]=result.stdout
    files.append({'relative_path':relative,**digest(result.stdout)})
for row in probe['source_pins']:
    relative=row['relative_path']
    if relative in sources and '/tests/' not in relative and not Path(relative).name.startswith('test_'):
        require(digest(sources[relative])=={key:row[key] for key in ('bytes','sha256')},
                'Production source changed after the independent remainder probe')
runtime_path='ck3_autonomous_player/src/xar_autoplayer/runtime.py'
host_path='ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py'
runtime=ast.parse(sources[runtime_path].decode('utf-8-sig'))
old_runtime=ast.parse((OUT/'runtime.py.baseline.stdout.source').read_text(encoding='utf-8-sig'))
host=ast.parse(sources[host_path].decode('utf-8-sig'))

def function(tree,name):return next(node for node in tree.body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name==name)

def calls(node,name):return [part for part in ast.walk(node) if isinstance(part,ast.Call) and isinstance(part.func,ast.Name) and part.func.id==name]

def launch_try(tree):return next(node for node in function(tree,'launch').body if isinstance(node,ast.Try) and calls(node,'_create_kill_on_close_job'))

require(ast.dump(ast.Module(body=launch_try(runtime).handlers,type_ignores=[]))==
        ast.dump(ast.Module(body=launch_try(old_runtime).handlers,type_ignores=[])),
        'Original launch failure cleanup changed')
launch=function(runtime,'launch')
index=next(i for i,arg in enumerate(launch.args.kwonlyargs) if arg.arg=='native_bridge_after_saved_load')
require(isinstance(launch.args.kw_defaults[index],ast.Constant) and launch.args.kw_defaults[index].value is False,
        'Runtime delayed-injection flag is not default OFF')
flag=next(call for call in ast.walk(function(host,'parser')) if isinstance(call,ast.Call) and call.args and
    isinstance(call.args[0],ast.Constant) and call.args[0].value=='--saved-campaign-inject-after-load')
require(any(keyword.arg=='action' and isinstance(keyword.value,ast.Constant) and keyword.value.value=='store_true'
            for keyword in flag.keywords) and not any(keyword.arg=='default' and
            isinstance(keyword.value,ast.Constant) and keyword.value.value is True for keyword in flag.keywords),
        'Host delayed-injection CLI flag is not default OFF')
helper=function(runtime,'_resume_then_inject_after_saved_load')
resume=calls(helper,'_resume_with_native_bridge')
inject=calls(helper,'_inject_native_bridge')
require(len(resume)==len(inject)==1 and isinstance(resume[0].args[0],ast.Name) and
        resume[0].args[0].id=='process' and isinstance(resume[0].args[1],ast.Constant) and
        resume[0].args[1].value is None and isinstance(inject[0].args[0],ast.Name) and inject[0].args[0].id=='process',
        'Delayed helper no longer uses one original-process resume and one injection call site')
require(len(calls(launch,'_create_kill_on_close_job'))==1 and len(calls(launch,'_create_suspended_process'))==1,
        'Launch now creates a second game or Job')
facts={
    'schema':'ck3.delayed-injection-independent-source-review.v1',
    'status':'STATIC_REVIEW_PASS_LIVE_UNPROVEN','reviewed_at_utc':datetime.now(timezone.utc).isoformat(),
    'author_commit':COMMIT,'author_parent':author['author_parent'],'author_index_pin':digest(AUTHOR.read_bytes()),
    'author_final_committed_files':files,
    'independent_probe_production_source_unchanged_at_author_commit':True,
    'runtime_and_host_default_off':True,'shared_manifest_only_admission':True,
    'one_original_process_and_one_original_job_create_call_site':True,
    'one_original_process_resume_and_one_inject_call_site':True,
    'original_process_handle_wrapper_unchanged':True,'original_launch_cleanup_handler_ast_unchanged':True,
    'original_native_session_supervisor_unchanged':True,
    'current_cleared_log_epoch_setup_completion_marker_required':True,
    'marker_is_native_identity_or_business_proof':False,
    'original_native_frame_root_event_admission_ast_unchanged':True,
    'positive_readiness_remainder_probe':{'loading_consumed_seconds':599,'total_readiness_seconds':600,
        'connection_waits_seconds':[1.0,.5],'refused_at_monotonic':600.0,'status':'PASS'},
    'runtime_fix_causality_or_live_success_claimed':False,'findings_requiring_code_change':[],
    'existing_owner_test_suites_rerun':False,'actual_game_injector_or_screen_actions':0,
    'repository_modified':False,'new_ci_or_full_matrix_requested':False,
    'source04_boundary':'Review binds the author delta, not a future reconstructed source file hash; root freezes the same delta on Source03 and preserves source/native byte comparisons separately.',
}
write(OUT/'RESULT.actual.json',facts)
report=f'''# Same-PID after-load 独立只读复核

结论：**STATIC_REVIEW_PASS / LIVE_UNPROVEN**。复核精确作者提交
`{COMMIT}`（parent `{author['author_parent']}`）的五文件最小改动，未发现本范围内需要再改代码的问题。
生产三文件与独立探针时的字节一致，最终五文件 SHA 见 [RESULT.actual.json](RESULT.actual.json)，
原作者 [INDEX](AUTHOR-INDEX.original.json) 与作者提交 blobs 已逐字节核对。
公共入口测试末次仅更新了新 manifest feature 之后的 fixture pin；保留探针时与作者最终版本两份来源，不追改旧快照。

本复核只针对 R39 无就绪 map/actor 与 R40 后50帧 pump 固定27770的实际启动故障，
不把“早期注入造成停滞”假说写成已证实因果。

| 要点 | 源码核对 |
| --- | --- |
| 默认 OFF | runtime 默认 False；host 为 store_true；仅全局 manifest 的显式布尔开关用于 saved_campaign，产品不能选择公共 runtime。 |
| 同 PID / Job / 原句柄 | 原 launch 只创建一次 suspended CK3 和一次 kill-on-close Job；先 assign，再调用新 helper。helper 收到并注入原 process，仍返回原 SessionHandle 和持有原 Windows handle 的 wrapper。没有第二次 game launch/restore。 |
| resume / inject 各一次 | helper 只通过原 resume 路径以 config=None 恢复一次，之后同一 process 在当前 Setup completion 标记后调用原 contained injector 一次。原单次 launch guard、injector 原始回执与 Job 清理验证仍在。 |
| 当前日志 epoch | 原 isolated log clear 未改；只消费该 profile 新 debug.log，mtime 不早于 log_epoch_ns，匹配正式带来源头的 Setup completion (history loaded)。它只选择注入时点，不授 native 身份或业务结论。 |
| 总 readiness 600 | supervisor.start 前建立一个绝对截止时点，传入 log 等待和 native 连接/两帧等待；不重置加载后预算。独立新增剩余时间探针验证599秒已耗后只获得1.0/.5秒，在600秒拒绝，无 native frame。 |
| 超时 / exit / stop | helper 在循环及注入前按原 process.poll、stop callback 和原截止拒绝；launch 的原 exception cleanup handler AST完全相同，仍走原 exact terminate/wait、Job active proof、injector proof、watchdog/handle清理。既有 injector/清理短预算是清理等待，不授新的600秒readiness。 |
| 严格 native 与业务 | saved frame/root/event admission AST未变；wait函数除了deadline参数/赋值外全部AST相同。第二个相等owner帧仍必须pump严格推进；R40重复27770不能因此获准，R39空map/actor也不会由日志补造。产品handler/option/save/业务谓词未改。 |

[PROBE.actual.json](PROBE.actual.json) 是唯一新增执行观察面：实际生产 host 函数 AST、可控时钟599→600、
原始诊断DTO与真实 asyncio.wait_for；没有 CK3、injector、Steam、屏幕操作，没有重跑r13已有测试或CI。
现有实现和原守卫源码副本、只读git-show回执均在本外置目录。清理路径、原句柄class、原日志清空和原native supervisor
亦与作者parent做了直接AST/字节对比。

Source04由Root另行以Source03单父应用作者delta；本报告绑定作者精确来源，不猜测未来完整host/source SHA，
也不混入远端856bd0c19的其他host/C++更新。Source04的原C++/CMake字节比较及native产物复用由Root冻结证据记录。
下一场实际是否产生Setup completion、完成同PID注入并取得严格推进两帧，仍只能由新的真实现场证明。
本报告不授共享runtime资格、R41产品通过或业务GREEN。
'''
with (OUT/'REPORT.zh.md').open('x',encoding='utf-8',newline='\n') as stream:stream.write(report)
write(OUT/'REVIEW-INDEX.actual.json',{'schema':'ck3.independent-review-output-index.v1',
    'created_at_utc':datetime.now(timezone.utc).isoformat(),
    'files':[{'path':path.relative_to(OUT).as_posix(),**digest(path.read_bytes())}
             for path in sorted(OUT.rglob('*')) if path.is_file()]})
print(json.dumps({'status':facts['status'],'author_commit':COMMIT,'output':str(OUT),
    'result_pin':digest((OUT/'RESULT.actual.json').read_bytes()),
    'report_pin':digest((OUT/'REPORT.zh.md').read_bytes())}),flush=True)
