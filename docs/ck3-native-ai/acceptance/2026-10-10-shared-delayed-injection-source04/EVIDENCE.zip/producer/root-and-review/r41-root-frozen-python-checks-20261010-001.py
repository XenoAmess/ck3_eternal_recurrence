import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone
import hashlib

source = Path('C:/csr4')
output = Path('C:/workspace/ck3-common-runtime/20261010-003/frozen-python-checks-001')
output.mkdir()
env = os.environ.copy()
env['PYTHONPATH'] = os.pathsep.join(str(source / item) for item in ['ck3_autonomous_player/src', 'ck3_workshop_mcp/src', 'tools'])
rows = []
for name, tail in [
    ('lifecycle', ['-m', 'unittest', 'discover', '-s', 'ck3_autonomous_player/tests/unit', '-p', 'test_saved_campaign_delayed_injection.py']),
    ('entry', ['-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_ck3_mod_acceptance.py']),
    ('host-help', ['ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py', '--help']),
]:
    started = datetime.now(timezone.utc).isoformat()
    argv = [sys.executable, '-B', '-X', 'utf8', *tail]
    result = subprocess.run(argv, cwd=source, env=env, capture_output=True)
    item = {'name': name, 'argv': argv, 'cwd': str(source), 'started_at_utc': started,
        'finished_at_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': result.returncode}
    for key in ['stdout', 'stderr']:
        raw = getattr(result, key)
        path = output / (name + '.' + key + '.log')
        path.write_bytes(raw)
        item[key] = {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    rows.append(item)
    if result.returncode:
        break
with (output / 'RESULT.actual.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump({'source_commit': '919bae0f42def04e6398eb2de4b4afe20dcfc106', 'commands': rows,
        'live_qualified': False, 'business_pass': False}, stream, indent=2)
    stream.write('\n')
print(json.dumps(rows))
raise SystemExit(any(item['exit_code'] for item in rows))
