"""One new observation: loading consumes 599s of the original 600s readiness."""
from pathlib import Path
from datetime import datetime,timezone
import __future__
import ast,asyncio,copy,hashlib,json,subprocess
from types import SimpleNamespace

REPO=Path('C:/workspace/ck3_eternal_recurrence')
OUT=Path('C:/workspace/ck3_lyd_runtime_20261004/r41-delayed-injection-independent-review-20261010-001')
OUT.mkdir(exist_ok=False)
HOST='ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py'
RUNTIME='ck3_autonomous_player/src/xar_autoplayer/runtime.py'
BASE='4c874cfaf45007c1b4d043011b90e9724a4aeb46'
FILES=[HOST,RUNTIME,'tools/ck3_mod_acceptance.py','tools/test_ck3_mod_acceptance.py',
       'ck3_autonomous_player/tests/unit/test_saved_campaign_delayed_injection.py',
       'ck3_autonomous_player/src/xar_autoplayer/native_session.py']
started=datetime.now(timezone.utc).isoformat()

def require(condition,message):
    if not condition:raise RuntimeError(message)

def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')

pins=[];payloads={}
for relative in FILES:
    raw=(REPO/relative).read_bytes();payloads[relative]=raw
    target=OUT/'reviewed-source'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    pins.append({'path':str(REPO/relative),'relative_path':relative,**pin(raw)})
trees={relative:ast.parse(payload.decode('utf-8-sig'),filename=relative) for relative,payload in payloads.items()}

def function(tree,name):
    return next(node for node in tree.body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and node.name==name)

baselines={}
for relative in (HOST,RUNTIME,'ck3_autonomous_player/src/xar_autoplayer/native_session.py'):
    argv=['git','show',BASE+':'+relative]
    command=subprocess.run(argv,cwd=REPO,capture_output=True,check=True)
    label=Path(relative).name+'.baseline'
    (OUT/(label+'.stdout.source')).write_bytes(command.stdout)
    (OUT/(label+'.stderr.log')).write_bytes(command.stderr)
    write(OUT/(label+'.actual.json'),{'argv':argv,'exit_code':command.returncode,
        'stdout':pin(command.stdout),'stderr':pin(command.stderr)})
    baselines[relative]=ast.parse(command.stdout.decode('utf-8-sig'),filename=relative)
unchanged=[]
for relative,names in ((HOST,('saved_campaign_admission_frame','saved_campaign_root_binding','admit_saved_startup_event')),
                       (RUNTIME,('_clear_isolated_runtime_logs','_create_suspended_process','_SuspendedWindowsProcess'))):
    for name in names:
        require(ast.dump(function(trees[relative],name))==ast.dump(function(baselines[relative],name)),
                'Original relevant native/lifecycle guard changed: '+name)
        unchanged.append(name)
require(payloads['ck3_autonomous_player/src/xar_autoplayer/native_session.py']==
        (OUT/'native_session.py.baseline.stdout.source').read_bytes(),'Original native supervisor changed')
original=function(baselines[HOST],'wait_for_saved_campaign')
normalized=copy.deepcopy(function(trees[HOST],'wait_for_saved_campaign'))
require(normalized.args.kwonlyargs[-1].arg=='readiness_deadline','Shared deadline argument missing')
normalized.args.kwonlyargs.pop();normalized.args.kw_defaults.pop()
for node in normalized.body:
    if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='deadline' for target in node.targets):
        node.value=copy.deepcopy(next(old for old in original.body if isinstance(old,ast.Assign) and
            any(isinstance(target,ast.Name) and target.id=='deadline' for target in old.targets)).value)
require(ast.dump(normalized)==ast.dump(original),'Saved admission changed beyond sharing its original deadline')
unchanged.append('wait_for_saved_campaign_except_deadline_parameter_and_assignment')

clock=SimpleNamespace(now=599.0)
wait_limits=[];calls=[];sleeps=[]
async def wait_for(awaitable,timeout):
    wait_limits.append(timeout)
    return await asyncio.wait_for(awaitable,timeout=timeout)
async def sleep(seconds):
    sleeps.append(seconds);clock.now+=seconds
async def call(tool):
    require(len(calls)<3,'Readiness was restarted instead of using one remaining second')
    calls.append({'tool':tool,'at_monotonic':clock.now})
    return {'pipe':'synthetic-readiness-remainder','transport_error':None,'diagnostics':{
        'pipe_name':'synthetic-readiness-remainder','protocol_version':1,'transport_fatal_error':None,
        'last_error':None,'connected':False,'semantic_state_available':False,'rejected_state_snapshot_count':0,
        'hello':None,'bridge_pid':None,'connection_generation':0}}
async def fresh():raise RuntimeError('No native frame should be queried without initial semantic connection')
namespace={'time':SimpleNamespace(monotonic=lambda:clock.now),
           'asyncio':SimpleNamespace(wait_for=wait_for,sleep=sleep),'now':lambda:'synthetic-time',
           'copy':copy}
nodes=[copy.deepcopy(function(trees[HOST],name)) for name in
       ('saved_campaign_initial_snapshot_state','wait_for_saved_campaign')]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(REPO/HOST),'exec',
             flags=__future__.annotations.compiler_flag),namespace)
report={'pipe':'synthetic-readiness-remainder'}
async def probe():
    try:
        await namespace['wait_for_saved_campaign'](SimpleNamespace(call=call,fresh=fresh),
            {'actor_character_id':31254},report=report,write=lambda:None,timeout=600,
            managed_done=None,poll_interval=.5,readiness_deadline=600.0)
    except TimeoutError as error:
        return {'type':type(error).__name__,'message':str(error)}
    raise RuntimeError('Absent native initial connection was incorrectly admitted')
error=asyncio.run(probe())
require(clock.now==600 and wait_limits==[1.0,.5] and sleeps==[.5,.5],
        '600-second readiness is not shared across loading and native connection')
require(report['saved_campaign_restore']['observations']==[], 'Unavailable native state granted a frame')
for relative,raw in payloads.items():
    require((REPO/relative).read_bytes()==raw,'Review source changed while probing: '+relative)
write(OUT/'PROBE.actual.json',{'schema':'ck3.delayed-injection-independent-remainder-observation.v1',
    'started_at_utc':started,'finished_at_utc':datetime.now(timezone.utc).isoformat(),
    'status':'PASS_STATIC_NEW_REMAINDER_OBSERVATION','source_pins':pins,'original_guard_comparison_base':BASE,
    'unchanged_relevant_guards':unchanged,'unchanged_native_session_supervisor':True,
    'clock_start':599.0,'original_readiness_deadline':600.0,'nominal_readiness_timeout':600,
    'actual_connection_wait_limits':wait_limits,'actual_poll_sleeps':sleeps,'clock_at_refusal':clock.now,
    'original_production_timeout':error,'calls':calls,'native_observations':[],
    'new_observation':'Positive remaining-budget case, distinct from expired-at-entry unit test; no reset to a new 600-second budget.',
    'actual_ck3_or_injector_launched':False,'steam_or_screen_accessed':False,'repository_modified':False,
    'existing_test_suites_rerun':False,'live_fix_or_business_green_proven':False})
print(json.dumps({'status':'PASS_STATIC_NEW_REMAINDER_OBSERVATION','output':str(OUT),
                  'remaining_limits':wait_limits,'clock_at_refusal':clock.now,
                  'source_count':len(pins),'unchanged_guards':unchanged}),flush=True)
