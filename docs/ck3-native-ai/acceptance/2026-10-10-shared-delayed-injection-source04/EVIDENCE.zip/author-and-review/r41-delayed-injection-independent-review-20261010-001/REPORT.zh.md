# Same-PID after-load 独立只读复核

结论：**STATIC_REVIEW_PASS / LIVE_UNPROVEN**。复核精确作者提交
`1d4468fc35361be5126acd84402ef27b87d71254`（parent `4c874cfaf45007c1b4d043011b90e9724a4aeb46`）的五文件最小改动，未发现本范围内需要再改代码的问题。
生产三文件与独立探针时的字节一致，最终五文件 SHA 见 [RESULT.actual.json](RESULT.actual.json)，
原作者 [INDEX](AUTHOR-INDEX.original.json) 与作者提交 blobs 已逐字节核对。
公共入口测试末次仅更新了新 manifest feature 之后的 fixture pin；保留探针时与作者最终版本两份来源，不追改旧快照。

本复核只针对 R39 无就绪 map/actor 与 R40 后50帧 pump 固定27770的实际启动故障，
不把“早期注入造成停滞”假说写成已证实因果。

| 要点 | 源码核对 |
| --- | --- |
| 默认 OFF | runtime 默认 False；host 为 store_true；仅全局 manifest 的显式布尔开关用于 saved_campaign，产品不能选择公共 runtime。 |
| 同 PID / Job / 原句柄 | 原 launch 只创建一次 suspended CK3 和一次 kill-on-close Job；先 assign，再调用新 helper。helper 收到并注入原 process，仍返回原 SessionHandle 和持有原 Windows handle 的 wrapper。没有第二次 game launch/restore。 |
| resume / inject 各一次 | helper 只通过原 resume 路径以 config=None 恢复一次，之后同一 process 在当前 Setup completion 标记后调用原 contained injector 一次。原单次 launch guard、injector 原始回执与 Job 清理验证仍在。 |
| 当前日志 epoch | 原 isolated log clear 未改；只消费该 profile 新 debug.log，mtime 不早于 log_epoch_ns，匹配正式带来源头的 Setup completion (history loaded)。它只选择注入时点，不授 native 身份或业务结论。 |
| 总 readiness 600 | supervisor.start 前建立一个绝对截止时点，传入 log 等待和 native 连接/两帧等待；不重置加载后预算。独立新增剩余时间探针验证599秒已耗后只获得1.0/.5秒，在600秒拒绝，无 native frame。 |
| 超时 / exit / stop | helper 在循环及注入前按原 process.poll、stop callback 和原截止拒绝；launch 的原 exception cleanup handler AST完全相同，仍走原 exact terminate/wait、Job active proof、injector proof、watchdog/handle清理。既有 injector/清理短预算是清理等待，不授新的600秒readiness。 |
| 严格 native 与业务 | saved frame/root/event admission AST未变；wait函数除了deadline参数/赋值外全部AST相同。第二个相等owner帧仍必须pump严格推进；R40重复27770不能因此获准，R39空map/actor也不会由日志补造。产品handler/option/save/业务谓词未改。 |

[PROBE.actual.json](PROBE.actual.json) 是唯一新增执行观察面：实际生产 host 函数 AST、可控时钟599→600、
原始诊断DTO与真实 asyncio.wait_for；没有 CK3、injector、Steam、屏幕操作，没有重跑r13已有测试或CI。
现有实现和原守卫源码副本、只读git-show回执均在本外置目录。清理路径、原句柄class、原日志清空和原native supervisor
亦与作者parent做了直接AST/字节对比。

Source04由Root另行以Source03单父应用作者delta；本报告绑定作者精确来源，不猜测未来完整host/source SHA，
也不混入远端856bd0c19的其他host/C++更新。Source04的原C++/CMake字节比较及native产物复用由Root冻结证据记录。
下一场实际是否产生Setup completion、完成同PID注入并取得严格推进两帧，仍只能由新的真实现场证明。
本报告不授共享runtime资格、R41产品通过或业务GREEN。
