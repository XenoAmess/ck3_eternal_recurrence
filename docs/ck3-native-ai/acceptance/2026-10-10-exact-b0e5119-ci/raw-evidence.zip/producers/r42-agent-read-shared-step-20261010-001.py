import json
from pathlib import Path

root=Path('C:/workspace/ck3_lyd_runtime_20261004/r42-exact-b0e5119cc-ci-20261010-001')
path=sorted(root.glob('poll-*-jobs-38007787292.stdout.json'))[-1]
packet=json.loads(path.read_bytes())
for job in packet['jobs']:
    for step in job.get('steps',[]):
        if step['name']=='Test shared CK3 acceptance without installed CK3':
            print(json.dumps({'source':path.name,'step':step}))
