from pathlib import Path
import subprocess
import sys

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
SHA='b0e5119ccc023e99509f2d33001f7a9372cd436b'
OUTPUT='r42-exact-b0e5119cc-ci-20261010-001'
OLD_SHA='0c0e36e21164d55cd9f47d2d8ab9ae7a5cbf3f63'
OLD_OUTPUT='r41-exact-0c0e36e21-ci-20261010-001'
templates=[('r41-agent-watch-exact-0c0e36e21-ci-20261010-001.py','r42-agent-watch-exact-b0e5119cc-ci-20261010-001.py'),
           ('r41-agent-complete-exact-0c0e36e21-ci-20261010-001.py','r42-agent-complete-exact-b0e5119cc-ci-20261010-001.py')]
for original,target in templates:
    source=(BASE/original).read_text(encoding='utf-8')
    if source.count(OLD_SHA)!=1 or source.count(OLD_OUTPUT)!=1:
        raise RuntimeError('Observer source no longer permits unambiguous exact retarget')
    source=source.replace(OLD_SHA,SHA).replace(OLD_OUTPUT,OUTPUT)
    with (BASE/target).open('x',encoding='utf-8',newline='\n') as stream:stream.write(source)
raise SystemExit(subprocess.run([sys.executable,'-B','-X','utf8',str(BASE/templates[0][1])],cwd=BASE).returncode)
