from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
REPO=Path('C:/workspace/ck3_eternal_recurrence')
SOURCE=BASE/'r42-exact-b0e5119cc-ci-20261010-001'
KEY='2026-10-10-exact-b0e5119-ci'
OUT=REPO/'docs/ck3-native-ai/acceptance'/KEY
SHA='b0e5119ccc023e99509f2d33001f7a9372cd436b'


def digest(data):return hashlib.sha256(data).hexdigest()
def load(path):return json.loads(path.read_text(encoding='utf-8'))
def pin(path):
    data=path.read_bytes()
    return {'bytes':len(data),'sha256':digest(data)}
def write_json(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')


final=load(SOURCE/'FINAL.actual.json')
terminal=load(SOURCE/'TERMINAL-EVIDENCE.actual.json')
remote=load(SOURCE/'REMOTE-PIN.actual.json')
if final['head_sha']!=SHA or terminal['head_sha']!=SHA or not final['triggered_workflows_terminal']:
    raise RuntimeError('exact terminal HEAD differs')
if final['api_total_count']!=final['returned_count'] or final['returned_count']!=2:
    raise RuntimeError('actual exact-head run inventory incomplete')
if remote['exact_commit_api_sha']!=SHA or remote['observed_master_sha']!=SHA or not remote['master_matches_requested_head']:
    raise RuntimeError('captured remote master binding differs')
for name in ('Official Runner CI','Linear history'):
    row=terminal['workflow_status'][name]
    if row['head_sha']!=SHA or row['status']!='completed' or row['conclusion']!='success':
        raise RuntimeError('actual workflow terminal differs')
    if not row['terminal_jobs'] or any(job['status']!='completed' or job['conclusion']!='success' or job['failed_steps'] for job in row['terminal_jobs']):
        raise RuntimeError('terminal jobs not complete success')
if terminal['workflow_status']['Li Yu Dao static checks']['status']!='NOT_TRIGGERED':
    raise RuntimeError('NOT_TRIGGERED boundary differs')
shared=[step for job in terminal['workflow_status']['Official Runner CI']['terminal_jobs']
    for step in job['shared_acceptance_steps']]
if len(shared)!=1 or shared[0]['status']!='completed' or shared[0]['conclusion']!='success':
    raise RuntimeError('shared acceptance terminal success missing')

queries=[]
for path in sorted(SOURCE.glob('*.actual.json')):
    actual=load(path)
    if 'argv' not in actual or 'stdout_sha256' not in actual:continue
    stem=path.name.removesuffix('.actual.json')
    stdout=list(SOURCE.glob(stem+'.stdout.*'))
    stderr=SOURCE/(stem+'.stderr.log')
    if len(stdout)!=1 or not stderr.is_file():raise RuntimeError('query original output pair missing')
    for item,label in ((stdout[0],'stdout'),(stderr,'stderr')):
        data=item.read_bytes()
        if len(data)!=actual[label+'_bytes'] or digest(data)!=actual[label+'_sha256']:
            raise RuntimeError('query stdout/stderr bytes differ')
    if actual['exit_code']!=0:raise RuntimeError('unexpected failed recorded query')
    queries.append(path.name)
if len(queries)!=52:raise RuntimeError('expected all 52 raw query groups')

log_zips=[]
for name in ('Official Runner CI','Linear history'):
    declared=terminal['workflow_status'][name]['full_log_archive']
    path=SOURCE/declared['file']
    if pin(path)!={key:declared[key] for key in ('bytes','sha256')}:raise RuntimeError('complete logs ZIP pin differs')
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:raise RuntimeError('complete workflow logs ZIP CRC failure')
        if set(archive.namelist())!={row['path'] for row in declared['entries']}:raise RuntimeError('complete logs inventory differs')
        for row in declared['entries']:
            data=archive.read(row['path'])
            if len(data)!=row['bytes'] or digest(data)!=row['sha256']:raise RuntimeError('complete logs entry differs')
    log_zips.append({'workflow':name,'file':declared['file'],'bytes':declared['bytes'],
        'sha256':declared['sha256'],'entries':len(declared['entries']),'crc':'PASS'})

inputs=[('exact-ci/'+path.relative_to(SOURCE).as_posix(),path) for path in sorted(SOURCE.rglob('*')) if path.is_file()]
for filename in ('r42-agent-start-exact-b0e5119cc-ci-20261010-001.py',
    'r42-agent-watch-exact-b0e5119cc-ci-20261010-001.py','r42-agent-complete-exact-b0e5119cc-ci-20261010-001.py',
    'r42-agent-read-shared-step-20261010-001.py','r42-agent-terminal-ci-summary-20261010-001.py',Path(__file__).name):
    inputs.append(('producers/'+filename,BASE/filename))
OUT.mkdir(exist_ok=False)
entries=[]
archive_path=OUT/'raw-evidence.zip'
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,path in sorted(inputs):
        data=path.read_bytes()
        info=zipfile.ZipInfo(name,date_time=(2026,10,10,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o100644<<16
        archive.writestr(info,data)
        entries.append({'path':name,'source_path':str(path),'bytes':len(data),'sha256':digest(data)})
archive_pin={'path':'raw-evidence.zip',**pin(archive_path)}
with zipfile.ZipFile(archive_path) as archive:
    if archive.testzip() is not None or set(archive.namelist())!={row['path'] for row in entries}:
        raise RuntimeError('new ZIP CRC or inventory differs')
    for row in entries:
        data=archive.read(row['path'])
        if len(data)!=row['bytes'] or digest(data)!=row['sha256'] or data!=Path(row['source_path']).read_bytes():
            raise RuntimeError('new ZIP differs from source bytes')

write_json(OUT/'INDEX.json',{'schema':'ck3.exact-b0e5119-ci-archive.v1',
    'archived_at_utc':datetime.now(timezone.utc).isoformat(),'source_ci_head':SHA,'archive':archive_pin,'entries':entries})
write_json(OUT/'ARCHIVE-VALIDATION.actual.json',{'schema':'ck3.raw-evidence-archive-validation.v1',
    'status':'PASS','archive':archive_pin,'checked_entries':len(entries),'crc':'PASS',
    'all_source_and_archived_bytes_match':True,'all_source_and_archived_sha256_match':True,
    'verified_actual_query_pairs':52,'query_receipts':queries,'original_complete_workflow_logs':log_zips,
    'new_api_queries_during_packaging':0,'tests_rerun_during_packaging':0})
result={'schema':'ck3.exact-b0e5119-ci-result.v1','head_sha':SHA,
    'observed_at_utc':final['observed_at_utc'],'actual_remote_master_at_watch_start':remote['observed_master_sha'],
    'official':{'run_id':38007787292,'status':'completed','conclusion':'success','job_id':114080491381,
        'shared_acceptance_conclusion':'success'},
    'linear_history':{'run_id':38007787307,'status':'completed','conclusion':'success','job_id':114080491155},
    'li_yu_dao_static_checks':{'status':'NOT_TRIGGERED','not_counted_as_success':True},
    'actual_exact_head_api_total_count':2,'actual_exact_head_api_returned_count':2,
    'triggered_workflows_terminal':True,'triggered_workflows_success':True,
    'original_all_required_workflows_success':final['all_required_workflows_success'],
    'not_triggered_workflows_are_not_passed':True,
    'terminal_evidence_pin':pin(SOURCE/'TERMINAL-EVIDENCE.actual.json'),
    'verified_original_query_groups':52,'complete_workflow_logs':log_zips,
    'new_api_queries_during_packaging':0,'tests_rerun_during_packaging':0,
    'old_6a3_and_0c0e_failures_reclassified':False,'common_runtime_live_qualification_claimed':False,
    'product_business_or_release_pass_claimed':False,'workflow_dispatch_performed':False,'raw_evidence':archive_pin}
write_json(OUT/'RESULT.actual.json',result)
report=f'''# 精确 b0e5119 官方 CI 终态（2026-10-10）

精确提交 `{SHA}` 的实际 GitHub API 与终态 jobs 确认：

| Workflow | 实际 run | 终态 |
| --- | --- | --- |
| Official Runner CI | [38007787292](https://github.com/XenoAmess/ck3_eternal_recurrence/actions/runs/38007787292) | success；共享 CK3 acceptance 步骤亦 success |
| Linear history | [38007787307](https://github.com/XenoAmess/ck3_eternal_recurrence/actions/runs/38007787307) | success |
| Li Yu Dao static checks | 精确 head API 未返回该 workflow | **NOT_TRIGGERED**，不计成功 |

Official 于 2026-10-10 00:18:25 UTC 完成，Linear 于 00:09:50 UTC 完成。
开始监看时，实际远端 commit 与 master branch API 均精确指向该 SHA。
终态 exact-head API 返回完整 2/2 runs；没有 workflow dispatch。
原 `FINAL.actual.json` 的 `all_required_workflows_success=false` 保留，反映未触发边界；
这里仅确认已触发的两个 workflow 成功。

全部 52 组原始查询 stdout/stderr、16 轮 runs/jobs、终态 jobs、两份完整日志 ZIP 与生产脚本见
[证据索引](acceptance/{KEY}/INDEX.json) 和 [实际结果](acceptance/{KEY}/RESULT.actual.json)。
原始字节封存 ZIP 共 {len(entries)} 项、{archive_pin['bytes']} bytes，SHA-256
`{archive_pin['sha256']}`；[读回复验](acceptance/{KEY}/ARCHIVE-VALIDATION.actual.json)
确认 byte-exact / CRC PASS，并逐项核对双 workflow 日志 ZIP 内文件 SHA。
本次只封存既有终态证据，无新 API 查询或测试重跑。

这份结果不追认 `6a3affdb8`、`0c0e36e21` 的旧 CI 失败，不授 Source05/R42 实机资格或产品业务 GREEN。
旧失败报告与日志保持原样，实机结果由各自 run 报告记录。
'''
report_path=REPO/'docs/ck3-native-ai'/(KEY+'.md')
with report_path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(report)
print(json.dumps({'report':str(report_path),'archive':archive_pin,'entries':len(entries),'query_groups':52}))
