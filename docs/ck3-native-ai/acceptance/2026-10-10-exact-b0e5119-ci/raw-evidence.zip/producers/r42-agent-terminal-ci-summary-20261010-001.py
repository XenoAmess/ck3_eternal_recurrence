import hashlib
import json
from pathlib import Path

root=Path('C:/workspace/ck3_lyd_runtime_20261004/r42-exact-b0e5119cc-ci-20261010-001')
path=root/'TERMINAL-EVIDENCE.actual.json'
data=path.read_bytes()
packet=json.loads(data)
rows={}
for name,row in packet['workflow_status'].items():
    rows[name]={key:row.get(key) for key in ('id','status','conclusion')}
    archive=row.get('full_log_archive')
    if archive:rows[name]['log_zip']={key:archive[key] for key in ('file','bytes','sha256')}
print(json.dumps({'head_sha':packet['head_sha'],'workflows':rows,
    'terminal_evidence':{'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}}))
