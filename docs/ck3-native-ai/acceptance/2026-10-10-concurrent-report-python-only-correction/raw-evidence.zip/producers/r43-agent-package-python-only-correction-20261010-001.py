from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
REPO=Path('C:/workspace/ck3_eternal_recurrence')
CI=BASE/'r43-exact-6baf0b73e-ci-20261010-001'
PACKAGE=BASE/'r43-concurrent-report-python-only-correction-package-20261010-001'
KEY='2026-10-10-concurrent-report-python-only-correction'
OUT=PACKAGE/'candidate/docs/ck3-native-ai/acceptance'/KEY
SHA='6baf0b73ecad9bcf9940144093293b6a1d80de4d'


def digest(data):return hashlib.sha256(data).hexdigest()
def load(path):return json.loads(path.read_text(encoding='utf-8'))
def pin(path):
    data=path.read_bytes()
    return {'bytes':len(data),'sha256':digest(data)}
def write_json(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')


final=load(CI/'FINAL.actual.json')
terminal=load(CI/'TERMINAL-EVIDENCE.actual.json')
if final['head_sha']!=SHA or terminal['head_sha']!=SHA or not final['triggered_workflows_terminal']:
    raise RuntimeError('original exact-head terminal differs')
official=terminal['workflow_status']['Official Runner CI']
linear=terminal['workflow_status']['Linear history']
liyu=terminal['workflow_status']['Li Yu Dao static checks']
if official['conclusion']!='failure' or linear['conclusion']!='success' or liyu['status']!='NOT_TRIGGERED':
    raise RuntimeError('original workflow conclusions differ')
failed=[step for job in official['terminal_jobs'] for step in job['failed_steps']]
if failed!=['Enforce Python-only Windows automation']:raise RuntimeError('original failed step differs')
shared=[step for job in official['terminal_jobs'] for step in job['shared_acceptance_steps']]
if len(shared)!=1 or shared[0]['conclusion']!='success':raise RuntimeError('actual shared acceptance result differs')
raw_failure=CI/'failure-38010875810-attempt-1-log-failed.stdout.log'
failure=raw_failure.read_text(encoding='utf-8-sig')
if 'Ran 9 tests' not in failure or 'PYTHON-ONLY RED: 3 violation(s)' not in failure:
    raise RuntimeError('actual nine-test/validator result differs')
queries=[]
for path in sorted(CI.glob('*.actual.json')):
    actual=load(path)
    if 'argv' not in actual or 'stdout_sha256' not in actual:continue
    stem=path.name.removesuffix('.actual.json')
    stdout=list(CI.glob(stem+'.stdout.*'))
    stderr=CI/(stem+'.stderr.log')
    if len(stdout)!=1 or not stderr.is_file():raise RuntimeError('query raw pair missing')
    for item,label in ((stdout[0],'stdout'),(stderr,'stderr')):
        data=item.read_bytes()
        if len(data)!=actual[label+'_bytes'] or digest(data)!=actual[label+'_sha256']:
            raise RuntimeError('query actual bytes/hash mismatch')
    if actual['exit_code']!=0:raise RuntimeError('unexpected failed recorded query')
    queries.append(path.name)
if len(queries)!=12:raise RuntimeError('expected all twelve original query groups')
zip_receipts=[]
for workflow,row in (('Official Runner CI',official),('Linear history',linear)):
    declared=row['full_log_archive'];path=CI/declared['file']
    if pin(path)!={key:declared[key] for key in ('bytes','sha256')}:raise RuntimeError('complete logs ZIP pin differs')
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None or set(archive.namelist())!={item['path'] for item in declared['entries']}:
            raise RuntimeError('complete logs CRC/inventory differs')
        for item in declared['entries']:
            data=archive.read(item['path'])
            if len(data)!=item['bytes'] or digest(data)!=item['sha256']:raise RuntimeError('complete log entry differs')
    zip_receipts.append({'workflow':workflow,'file':path.name,**pin(path),'crc':'PASS'})

PACKAGE.mkdir(exist_ok=False)
trigger_rows=[]
trigger_token='power'+'shell'
for relative in ('docs/autonomous-agent-progress/daily/2026-10-10.md',
                 'docs/autonomous-agent-progress/weekly/2026-W41.md','docs/testing-workflow.md'):
    command=['git','show',SHA+':'+relative]
    result=subprocess.run(command,cwd=REPO,capture_output=True,timeout=45,check=True)
    raw=result.stdout
    hits=[{'line':index,'text':line} for index,line in enumerate(raw.decode('utf-8-sig').splitlines(),1)
          if trigger_token in line.lower()]
    if len(hits)!=1:raise RuntimeError('original exact-source trigger shape differs')
    trigger_rows.append({'path':relative,'source_head':SHA,'source_bytes':len(raw),
        'source_sha256':digest(raw),'git_show_argv':command,'git_show_exit_code':result.returncode,
        'hits':hits})
write_json(PACKAGE/'ORIGINAL-TRIGGER-LINES.actual.json',{'schema':'ck3.exact-ci-source-trigger-lines.v1',
    'source_head':SHA,'files':trigger_rows,'source_query_read_only':True})
inputs=[('exact-ci/'+path.relative_to(CI).as_posix(),path) for path in sorted(CI.rglob('*')) if path.is_file()]
inputs.append(('source-lines/ORIGINAL-TRIGGER-LINES.actual.json',PACKAGE/'ORIGINAL-TRIGGER-LINES.actual.json'))
for filename in ('r43-agent-start-exact-6baf0b73e-ci-20261010-001.py',
    'r43-agent-watch-exact-6baf0b73e-ci-20261010-001.py','r43-agent-complete-exact-6baf0b73e-ci-20261010-001.py',
    Path(__file__).name):inputs.append(('producers/'+filename,BASE/filename))
OUT.mkdir(parents=True,exist_ok=False)
entries=[];archive_path=OUT/'raw-evidence.zip'
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,path in sorted(inputs):
        data=path.read_bytes();info=zipfile.ZipInfo(name,date_time=(2026,10,10,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        archive.writestr(info,data)
        entries.append({'path':name,'source_path':str(path),'bytes':len(data),'sha256':digest(data)})
archive_pin={'path':'raw-evidence.zip',**pin(archive_path)}
with zipfile.ZipFile(archive_path) as archive:
    if archive.testzip() is not None or set(archive.namelist())!={row['path'] for row in entries}:
        raise RuntimeError('new archive CRC/inventory differs')
    for row in entries:
        data=archive.read(row['path'])
        if len(data)!=row['bytes'] or digest(data)!=row['sha256'] or data!=Path(row['source_path']).read_bytes():
            raise RuntimeError('new archive bytes differ')
write_json(OUT/'INDEX.json',{'schema':'ck3.concurrent-report-python-only-failure-archive.v1',
    'archived_at_utc':datetime.now(timezone.utc).isoformat(),'source_ci_head':SHA,'archive':archive_pin,'entries':entries})
write_json(OUT/'ARCHIVE-VALIDATION.actual.json',{'schema':'ck3.raw-evidence-archive-validation.v1','status':'PASS',
    'archive':archive_pin,'checked_entries':len(entries),'crc':'PASS','all_source_and_archived_bytes_match':True,
    'all_source_and_archived_sha256_match':True,'verified_actual_query_pairs':12,'query_receipts':queries,
    'original_complete_workflow_logs':zip_receipts,'new_ci_api_queries_during_packaging':0,'tests_rerun_during_packaging':0})
write_json(OUT/'RESULT.actual.json',{'schema':'ck3.concurrent-report-python-only-ci-failure.v1','head_sha':SHA,
    'official':{'run_id':38010875810,'conclusion':'failure','failed_step':failed[0],'shared_acceptance_conclusion':'success'},
    'linear_history':{'run_id':38010875847,'conclusion':'success'},
    'li_yu_dao_static_checks':{'status':'NOT_TRIGGERED','not_counted_as_success':True},
    'python_only_unit_tests':{'tests':9,'conclusion':'success'},
    'python_only_repository_validation':{'exit_code':1,'violations':3},
    'exact_source_triggers':[{'path':row['path'],'line':row['hits'][0]['line'],
        'source_bytes':row['source_bytes'],'source_sha256':row['source_sha256']} for row in trigger_rows],
    'failure_is_descriptive_document_text_not_runtime_execution':True,
    'correction_scope':'Only historical shell/cmdlet wording in three documents; preserve PID, RAM numbers, cancellation facts and original receipt link.',
    'validator_policy_relaxed':False,'production_runtime_modified_by_package':False,
    'correction_validation_result_included':False,'new_ci_success_claimed':False,
    'new_ci_api_queries_during_packaging':0,'tests_rerun_during_packaging':0,
    'root_repository_files_modified_by_packaging':False,'raw_evidence':archive_pin})
lines='、'.join(f"`{row['path']}:{row['hits'][0]['line']}`" for row in trigger_rows)
report=f'''# 并行报告的 Python-only 文本勘误（2026-10-10）

精确 `{SHA}` 的 [Official CI 38010875810](https://github.com/XenoAmess/ck3_eternal_recurrence/actions/runs/38010875810)
在 `Enforce Python-only Windows automation` 失败。校验器自身 **9 项测试通过**；
仓库扫描随后报告 **3 violation(s)**、exit 1。三处均为同一历史内存恢复叙述中的禁止 shell 名称：
{lines}。精确源文件 SHA、原行文和原失败输出均封存于证据 ZIP。

同一精确提交的共享 CK3 acceptance 步骤 success，
[Linear history 38010875847](https://github.com/XenoAmess/ck3_eternal_recurrence/actions/runs/38010875847) success；
Li Yu Dao static checks **NOT_TRIGGERED**，不计成功。本次失败不归因于运行时或缓存测试回退。

最小更正范围是三处历史叙述的 shell/旧命令字样，以明确的历史禁止 shell / 只读文件读取措辞替换；
PID 22976、86.46 GB RSS、99% 内存负载、取消行为及原始回执链接保留，校验规则不放宽。
本包只保全更正前的失败，不包含更正后的校验结果，也不声称新 CI 已通过。

[结果](acceptance/{KEY}/RESULT.actual.json)及[索引](acceptance/{KEY}/INDEX.json)
保存原终态、12 组查询回执、失败原 step、终态 jobs、双 workflow 完整日志和精确原文行号。
ZIP {archive_pin['bytes']} bytes、{len(entries)} 项，SHA-256 `{archive_pin['sha256']}`；
[读回复验](acceptance/{KEY}/ARCHIVE-VALIDATION.actual.json)确认 byte-exact / CRC PASS。
打包未新增 API 查询、测试或主树写入，旧 `b0e5119` 成功与 `6a3` / `0c0e` 失败保持各自来源事实。
'''
topic=PACKAGE/'candidate/docs/ck3-native-ai'/(KEY+'.md')
with topic.open('x',encoding='utf-8',newline='\n') as stream:stream.write(report)
manifest={'schema':'ck3.external-permanent-doc-candidate.v1','status':'READY_NOT_APPLIED',
    'source_ci_head':SHA,'files':[{'relative_path':path.relative_to(PACKAGE/'candidate').as_posix(),**pin(path)}
        for path in sorted((PACKAGE/'candidate').rglob('*')) if path.is_file()],
    'root_repo_not_modified':True,'new_ci_api_queries':0,'tests_rerun':0}
write_json(PACKAGE/'PACKAGE.actual.json',manifest)
print(json.dumps({'output':str(PACKAGE),'candidate_files':len(manifest['files']),'archive':archive_pin,
    'entries':len(entries),'package_manifest':pin(PACKAGE/'PACKAGE.actual.json')}))
