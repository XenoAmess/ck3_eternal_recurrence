from pathlib import Path
import subprocess
import sys

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
SHA='6baf0b73ecad9bcf9940144093293b6a1d80de4d'
OUTPUT='r43-exact-6baf0b73e-ci-20261010-001'
OLD_SHA='b0e5119ccc023e99509f2d33001f7a9372cd436b'
OLD_OUTPUT='r42-exact-b0e5119cc-ci-20261010-001'
templates=[('r42-agent-watch-exact-b0e5119cc-ci-20261010-001.py','r43-agent-watch-exact-6baf0b73e-ci-20261010-001.py'),
           ('r42-agent-complete-exact-b0e5119cc-ci-20261010-001.py','r43-agent-complete-exact-6baf0b73e-ci-20261010-001.py')]
for original,target in templates:
    source=(BASE/original).read_text(encoding='utf-8')
    if source.count(OLD_SHA)!=1 or source.count(OLD_OUTPUT)!=1:
        raise RuntimeError('Observer source no longer permits unambiguous exact retarget')
    source=source.replace(OLD_SHA,SHA).replace(OLD_OUTPUT,OUTPUT)
    with (BASE/target).open('x',encoding='utf-8',newline='\n') as stream:stream.write(source)
raise SystemExit(subprocess.run([sys.executable,'-B','-X','utf8',str(BASE/templates[0][1])],cwd=BASE).returncode)
