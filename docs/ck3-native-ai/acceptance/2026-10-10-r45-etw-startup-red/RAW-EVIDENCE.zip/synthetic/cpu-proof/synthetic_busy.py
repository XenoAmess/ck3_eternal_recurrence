import hashlib,json,os,time
start=time.monotonic();count=0;raw=b"synthetic-only-cpu"*4096
while time.monotonic()-start<10:
 hashlib.sha256(raw).digest();count+=1
print(json.dumps({"pid":os.getpid(),"elapsed":time.monotonic()-start,"iterations":count,"synthetic_only":True}))
