# R45 synthetic 离线地址核对

现有 ETL 只执行一次 `stack -pid 6564 -butterfly 1`，exit 0。报告为 HTML，10574 stack hits；libcrypto-3.dll exclusive 9852（93.17%）。未解 symbols 的 function 为 unknown，报告内部 href/id 不是原始 IP。

因此执行唯一一次必要 dumper（`-stacktimeshifting -add_rawdata`），exit 0，55.107 秒；CSV 1092354095 字节，其原始 SampledProfile.PrgrmCtr 和 Stack.Address 已实际存在。由原 process.txt 的同 PID、同时间段 Image 基址/末端做包含检查，再计算 RVA=IP-base；精确行与结果见 ADDRESS-PROOF.actual.json。无需 PDB 即可保全可复查地址/模块/RVA；函数含义仍 UNKNOWN。

未调用 WPR 或新开 trace；未重复 profile/process/tracestats 三份已有导出；未重新读取/计算 254MB ETL 的哈希。1GB CSV 保留外置，不需复制入库。这里只验证 synthetic 工具链，未来 R45 的 CK3 热点/根因没有信用。
