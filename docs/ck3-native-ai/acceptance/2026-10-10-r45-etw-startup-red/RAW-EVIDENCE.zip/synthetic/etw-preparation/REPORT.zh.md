# R45 ETW CPU 采样准备（只读）

Kit WPR/xperf 均为 10.0.26100；本轮未启动、停止或取消 trace。顺序 WPR status/profiles/profiledetails 全部 exit 0，status 为 `WPR is not recording`。初次并发只读 WPR 的 `0xc5580601` 原件保留，不视作别人正在录制。

xperf `-Loggers` exit 0，共 25 个既有会话，未见 WPR 命名会话。两个 SystemLogger 的 flags 分别是 `LOADER+HARD_FAULTS+DPC+INTERRUPT`、`PROC_THREAD+LOADER`，未见系统 CPU `PROFILE`。不能写成全机没有 trace，也未逐个认定其 owner；全部保持不动。

当前 token elevated=true/Default，SeSystemProfilePrivilege 与 SeDebugPrivilege 均 present/disabled。本轮没有调整 privilege。CPU.Verbose.File 实际含 Loader、ProcessThread、SampledProfile，及 SampledProfile/CSwitch/ReadyThread stacks。唯一 instance 参数必须最后；本机 help 明示后续 session 命令应沿用同名 instance。

`PLAN.source-only.json` 给出精确 argv 数组。ROOT 先以 fresh 外置目录进行 10 秒 synthetic；成功采集后，R45 仍为 900 秒总预算，仅在既有加载计时 600 秒后采 60 秒。start/stop 只控制本轮唯一 instance，不使用 generic stop/cancel。实际 PID、create time、加载模块身份与 R45 产物仍 NULL。

离线命令均来自本机 help：profile -detail 在未启用 symbols 时按 process/module 统计；process -thread -image；stack -pid 实际PID -butterfly 1；dumper -stacktimeshifting -add_rawdata；tracestats。不需要 PDB 才能保全 IP/模块基址并按有效模块区间计算 RVA=IP-base；实际 CSV 字段、目标样本/栈是否充分须由 synthetic/实采回执确认，当前不授成功采样或引擎根因信用。

未注入、未 suspend/signal 游戏、未改 profile/budget/系统设置/MAIN。权限与 CLI 帮助仅说明已有施工入口，成功与开销由 ROOT 的实际短测验证。
