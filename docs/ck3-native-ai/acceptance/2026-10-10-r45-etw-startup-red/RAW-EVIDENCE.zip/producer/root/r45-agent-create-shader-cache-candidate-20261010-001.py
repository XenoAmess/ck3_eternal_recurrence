from pathlib import Path
import hashlib
import json
import shutil
import subprocess

repo = Path('C:/workspace/ck3_eternal_recurrence')
root = Path('C:/workspace/ck3_lyd_runtime_20261004/r45-shared-shader-cache-candidate-20261010-001')
root.mkdir(exist_ok=False)
head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=repo, capture_output=True, check=True).stdout.decode().strip()
rows = {}
for relative in ('tools/ck3_mod_acceptance.py', 'tools/ck3_mod_acceptance_allocate.py'):
    source = repo / relative
    raw = source.read_bytes()
    rows[relative] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    for directory in ('baseline', 'candidate'):
        target = root / directory / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
(root / 'BASELINE.actual.json').write_text(json.dumps({'head': head, 'files': rows,
    'writes_only_external': True, 'actual_cache_bodies_read': False}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'candidate': str(root), 'head': head, 'files': rows}))
