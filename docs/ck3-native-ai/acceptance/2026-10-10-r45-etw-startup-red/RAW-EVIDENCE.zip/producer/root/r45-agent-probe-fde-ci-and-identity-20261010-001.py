"""Bounded read-only discovery before exact CI capture."""
from pathlib import Path
import json

base = Path('C:/workspace/ck3_lyd_runtime_20261004')
sha = 'fde5fb0a03d24ba00b8a09ce0a52462a50882671'
matches = sorted(set(base.glob('*fde*')) | {p for p in base.glob('*ci*') if p.is_dir()})
print(json.dumps({'bounded_base': str(base), 'top_level_matches': [str(p) for p in matches]}))
for path in matches:
    if not path.is_dir():
        continue
    for name in ('FINAL.actual.json', 'TERMINAL-EVIDENCE.actual.json'):
        receipt = path / name
        if receipt.is_file():
            value = json.loads(receipt.read_bytes())
            if value.get('head_sha') != sha:
                continue
            print(json.dumps({'path': str(receipt), 'head_sha': value.get('head_sha'),
                'matches_requested_head': value.get('head_sha') == sha,
                'triggered_workflows_terminal': value.get('triggered_workflows_terminal'),
                'workflows': {key: {field: row.get(field) for field in ('id', 'status', 'conclusion')}
                    for key, row in value.get('workflow_status', {}).items()}}))
