"""One bounded external CPU trace after the existing observer records 600s."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import time
import psutil

run=Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0045')
samples=run/'startup-observer-001'
out=run/'etw-cpu-001'
out.mkdir(exist_ok=False)
wpr=Path('C:/Program Files (x86)/Windows Kits/10/Windows Performance Toolkit/wpr.exe')
xperf=wpr.with_name('xperf.exe')
instance='xar-lyd-R0045-cpu-20261010-001'
records=[]
def utc():return datetime.now(timezone.utc).isoformat()
def put(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def pin(path):
    raw=path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def record(label,argv):
    directory=out/label;directory.mkdir()
    started=utc()
    with (directory/'stdout.bin').open('xb') as stdout,(directory/'stderr.bin').open('xb') as stderr:
        process=subprocess.Popen([str(v) for v in argv],stdout=stdout,stderr=stderr)
        code=process.wait()
    result={'argv':[str(v) for v in argv],'pid':process.pid,'started_at_utc':started,'finished_at_utc':utc(),'returncode':code,
        'stdout':pin(directory/'stdout.bin'),'stderr':pin(directory/'stderr.bin')}
    put(directory/'RESULT.actual.json',result);records.append(result)
    return result
put(out/'ARMED.actual.json',{'at_utc':utc(),'source':pin(Path(__file__)),'threshold_elapsed_seconds':600,'wait_bound_seconds':960,
    'capture_seconds_after_start_returns':60,'instance':instance,'game_budget_changed':False,'signals_to_game':False,'foreground_changes':False})
end=time.monotonic()+960
selected=None
while time.monotonic()<end:
    if (samples/'EXIT.actual.json').exists():
        put(out/'SKIPPED.actual.json',{'at_utc':utc(),'reason':'Actual CK3 observer exit arrived before capture','trace_started':False})
        raise SystemExit(0)
    paths=sorted(samples.glob('sample-*.actual.json'))
    if paths:
        try:row=json.loads(paths[-1].read_bytes())
        except (json.JSONDecodeError, OSError):
            time.sleep(0.5);continue
        if row.get('elapsed_seconds',0)>=600:
            if 'Setup completion (history loaded)' in row.get('debug_log_tail',''):
                put(out/'SKIPPED.actual.json',{'at_utc':utc(),'reason':'Load completion already observed; no pre-load trace needed','sample':pin(paths[-1]),'trace_started':False})
                raise SystemExit(0)
            selected={'path':paths[-1],'row':row};break
    time.sleep(0.5)
if selected is None:raise RuntimeError('No eligible written startup sample before diagnostic bound; game untouched')
identity_path=samples/'HANDLE-READY.actual.json'
identity=json.loads(identity_path.read_bytes())['process']
actual=psutil.Process(identity['pid'])
if abs(actual.create_time()-identity['create_time'])>0.001 or actual.name().lower()!='ck3.exe':
    raise RuntimeError('Actual CK3 creation identity changed before trace')
expected_profile='-userdir=C:\\workspace\\ck3-common-runtime\\cases\\lyd-transaction-control-20261010-007\\state\\profile'
if expected_profile not in actual.cmdline():raise RuntimeError('CK3 profile differs before trace')
put(out/'TARGET.actual.json',{'at_utc':utc(),'identity':pin(identity_path),'process':identity,'sample':pin(selected['path']),
    'elapsed_seconds':selected['row']['elapsed_seconds'],'original_game_deadline_extended':False})
for label,argv in [('001-status-default',[wpr,'-status']),('002-status-own',[wpr,'-status','-instancename',instance])]:
    result=record(label,argv)
    if result['returncode']!=0 or b'WPR is not recording' not in Path(result['stdout']['path']).read_bytes():
        raise RuntimeError('WPR status not idle; no trace or other-owner stop requested')
temp=out/'temp';temp.mkdir()
try:
    start=record('003-start-own',[wpr,'-start','CPU.Verbose','-filemode','-recordtempto',temp,'-instancename',instance])
    if start['returncode']!=0:raise RuntimeError('Own trace start failed; only this previously idle unique instance may be stopped')
    capture_end=time.monotonic()+60
    while time.monotonic()<capture_end:
        if (samples/'EXIT.actual.json').exists():break
        time.sleep(0.5)
finally:
    stop=record('004-stop-own',[wpr,'-stop',out/'cpu.etl','R0045 CPU samples during delayed loading','-skipPdbGen','-instancename',instance])
if stop['returncode']!=0:raise RuntimeError('Own stop failed; retained temporary trace')
etl_pin=pin(out/'cpu.etl')
put(out/'CAPTURED.actual.json',{'at_utc':utc(),'target_pid':identity['pid'],'etl':etl_pin,'own_trace_stop_returncode':stop['returncode'],
    'records':records,'game_budget_changed':False,'game_input_sent':False})
# The heavy text export follows the actual game exit, or this diagnostic-only bound.
# Neither bound alters the host's original 900s readiness deadline.
while not (samples/'EXIT.actual.json').exists() and time.monotonic()<end+240:
    time.sleep(0.5)
for label,action,extra in [('005-profile','profile',['-detail']),('006-process','process',['-thread','-image']),
    ('007-tracestats','tracestats',[]),('008-stack','stack',['-pid',str(identity['pid']),'-butterfly','1']),
    ('009-dumper','dumper',['-stacktimeshifting','-add_rawdata'])]:
    result=record(label,[xperf,'-i',out/'cpu.etl','-o',out/(action+'.txt'),'-a',action,*extra])
    if result['returncode']!=0:raise RuntimeError('Offline export failed: '+label)
final=record('010-status-own',[wpr,'-status','-instancename',instance])
put(out/'SUMMARY.actual.json',{'at_utc':utc(),'instance':instance,'target_pid':identity['pid'],'etl':etl_pin,
    'records':records,'final_status_returncode':final['returncode'],'symbols_requested':False,'game_input_sent':False,
    'game_budget_changed':False,'other_trace_stopped':False,'semantic_or_business_credit':False})
print(json.dumps({'target_pid':identity['pid'],'out':str(out),'trace_stopped':True,'exports_completed':True}))
