from pathlib import Path
import hashlib, json, subprocess, time

OUT = Path('C:/workspace/ck3_lyd_runtime_20261004/r45-etw-cpu-observation-preparation-20261010-001')
WPR = 'C:/Program Files (x86)/Windows Kits/10/Windows Performance Toolkit/wpr.exe'
XPERF = 'C:/Program Files (x86)/Windows Kits/10/Windows Performance Toolkit/xperf.exe'

def pin(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

receipts = []
commands = [
    ('0013-kit-wpr-status-sequential', [WPR, '-status']),
    ('0014-kit-wpr-profiles-sequential', [WPR, '-profiles']),
    ('0015-kit-wpr-cpu-profiledetails', [WPR, '-profiledetails', 'CPU.Verbose', '-filemode']),
    ('0016-xperf-help-query', [XPERF, '-help', 'query']),
    ('0017-xperf-help-processing', [XPERF, '-help', 'processing']),
    ('0018-xperf-help-stackwalk', [XPERF, '-help', 'stackwalk']),
]
for name, argv in commands:
    d = OUT / name
    d.mkdir()
    started = time.time_ns()
    p = subprocess.run(argv, capture_output=True, timeout=30)
    (d / 'stdout.bin').write_bytes(p.stdout)
    (d / 'stderr.bin').write_bytes(p.stderr)
    r = {'argv': argv, 'started_at_unix_ns': started, 'returncode': p.returncode,
         'stdout': pin(d / 'stdout.bin'), 'stderr': pin(d / 'stderr.bin'), 'read_only': True,
         'execution': 'strictly sequential'}
    (d / 'RESULT.actual.json').write_text(json.dumps(r, indent=2) + '\n', encoding='utf-8')
    receipts.append(r)
    print(name, p.returncode)
    print((p.stdout + p.stderr).decode('utf-8', errors='replace'))
(OUT / 'SEQUENTIAL-DETAILS.actual.json').write_text(json.dumps({'source': pin(Path(__file__)), 'receipts': receipts}, indent=2) + '\n', encoding='utf-8')
