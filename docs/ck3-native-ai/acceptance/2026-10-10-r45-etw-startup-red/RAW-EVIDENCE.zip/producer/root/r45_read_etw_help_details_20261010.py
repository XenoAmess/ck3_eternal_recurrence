from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import subprocess
import time

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT=BASE/'r45-etw-cpu-observation-preparation-20261010-001'
KIT=Path('C:/Program Files (x86)/Windows Kits/10/Windows Performance Toolkit')
def decode(body):
    return body.decode('utf-16' if body.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8',errors='replace')
def ref(path):
    body=path.read_bytes()
    return {'path':str(path),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
for name in ('0001-wpr-status','0005-xperf-help'):
    print(json.dumps({'prior':name,'stdout':decode((OUT/name/'stdout.bin').read_bytes()),'stderr':decode((OUT/name/'stderr.bin').read_bytes())},ensure_ascii=False))
commands=[('0006-kit-wpr-help-start',[str(KIT/'wpr.exe'),'-help','start']),('0007-kit-wpr-help-stop',[str(KIT/'wpr.exe'),'-help','stop']),('0008-kit-wpr-help-status',[str(KIT/'wpr.exe'),'-help','status']),('0009-kit-wpr-help-profiles',[str(KIT/'wpr.exe'),'-help','profiles']),('0010-kit-wpr-help-advanced',[str(KIT/'wpr.exe'),'-help','advanced']),('0011-kit-wpr-status',[str(KIT/'wpr.exe'),'-status']),('0012-kit-wpr-profiles',[str(KIT/'wpr.exe'),'-profiles'])]
def run(row):
    name,argv=row
    target=OUT/name
    target.mkdir(exist_ok=False)
    started=time.time_ns()
    result=subprocess.run(argv,capture_output=True,timeout=30,check=False)
    for suffix,body in (('stdout.bin',result.stdout),('stderr.bin',result.stderr)):
        with (target/suffix).open('xb') as stream:stream.write(body)
    value={'argv':argv,'started_at_unix_ns':started,'returncode':result.returncode,'stdout':ref(target/'stdout.bin'),'stderr':ref(target/'stderr.bin'),'read_only':True}
    with (target/'RESULT.actual.json').open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
    return value
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,commands))
for value in results:
    print(json.dumps({'argv':value['argv'],'returncode':value['returncode'],'stdout':decode(Path(value['stdout']['path']).read_bytes()),'stderr':decode(Path(value['stderr']['path']).read_bytes())},ensure_ascii=False))
with (OUT/'HELP-DETAILS.actual.json').open('x',encoding='utf-8',newline='\n') as stream:json.dump(results,stream,ensure_ascii=False,indent=2);stream.write('\n')
