from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from ctypes import wintypes
import ctypes
import hashlib
import json
import subprocess
import time

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT=BASE/'r45-etw-cpu-observation-preparation-20261010-001'
OUT.mkdir(exist_ok=False)
WPR=Path('C:/Windows/System32/wpr.exe')
KIT=Path('C:/Program Files (x86)/Windows Kits/10/Windows Performance Toolkit')
XPERF=KIT/'xperf.exe'

def ref(path):
    body=path.read_bytes()
    return {'path':str(path),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}

def json_new(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2)
        stream.write('\n')

commands=[('0001-wpr-status',[str(WPR),'-status']),('0002-wpr-profiles',[str(WPR),'-profiles']),('0003-wpr-help',[str(WPR),'-help']),('0004-kit-wpr-help',[str(KIT/'wpr.exe'),'-help']),('0005-xperf-help',[str(XPERF),'-help'])]
def run(row):
    name,argv=row
    target=OUT/name
    target.mkdir(exist_ok=False)
    started=datetime.now(timezone.utc).isoformat()
    tick=time.monotonic()
    result=subprocess.run(argv,capture_output=True,timeout=45,check=False)
    for suffix,body in (('stdout.bin',result.stdout),('stderr.bin',result.stderr)):
        with (target/suffix).open('xb') as stream:stream.write(body)
    receipt={'argv':argv,'started_at_utc':started,'elapsed_seconds':time.monotonic()-tick,'returncode':result.returncode,'stdout':ref(target/'stdout.bin'),'stderr':ref(target/'stderr.bin'),'read_only_intent':True}
    json_new(target/'RESULT.actual.json',receipt)
    return receipt
with ThreadPoolExecutor(max_workers=5) as pool:results=list(pool.map(run,commands))

adv=ctypes.WinDLL('advapi32',use_last_error=True)
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.GetCurrentProcess.restype=wintypes.HANDLE
kernel.CloseHandle.argtypes=[wintypes.HANDLE]
adv.OpenProcessToken.argtypes=[wintypes.HANDLE,wintypes.DWORD,ctypes.POINTER(wintypes.HANDLE)]
adv.OpenProcessToken.restype=wintypes.BOOL
adv.GetTokenInformation.argtypes=[wintypes.HANDLE,ctypes.c_int,wintypes.LPVOID,wintypes.DWORD,ctypes.POINTER(wintypes.DWORD)]
adv.GetTokenInformation.restype=wintypes.BOOL
class LUID(ctypes.Structure):
    _fields_=[('LowPart',wintypes.DWORD),('HighPart',wintypes.LONG)]
class LUID_AND_ATTRIBUTES(ctypes.Structure):
    _fields_=[('Luid',LUID),('Attributes',wintypes.DWORD)]
adv.LookupPrivilegeNameW.argtypes=[wintypes.LPCWSTR,ctypes.POINTER(LUID),wintypes.LPWSTR,ctypes.POINTER(wintypes.DWORD)]
adv.LookupPrivilegeNameW.restype=wintypes.BOOL
token=wintypes.HANDLE()
if not adv.OpenProcessToken(kernel.GetCurrentProcess(),8,ctypes.byref(token)):
    raise ctypes.WinError(ctypes.get_last_error())
def info(kind):
    size=wintypes.DWORD()
    adv.GetTokenInformation(token,kind,None,0,ctypes.byref(size))
    buffer=ctypes.create_string_buffer(size.value)
    if not adv.GetTokenInformation(token,kind,buffer,size.value,ctypes.byref(size)):
        raise ctypes.WinError(ctypes.get_last_error())
    return buffer
try:
    privileges=info(3)
    count=wintypes.DWORD.from_buffer(privileges).value
    rows=[]
    for i in range(count):
        entry=LUID_AND_ATTRIBUTES.from_buffer(privileges,4+i*ctypes.sizeof(LUID_AND_ATTRIBUTES))
        size=wintypes.DWORD(128)
        name=ctypes.create_unicode_buffer(size.value)
        if not adv.LookupPrivilegeNameW(None,ctypes.byref(entry.Luid),name,ctypes.byref(size)):
            raise ctypes.WinError(ctypes.get_last_error())
        rows.append({'name':name.value,'attributes':entry.Attributes,'enabled':bool(entry.Attributes&2),'enabled_by_default':bool(entry.Attributes&1)})
    elevation=wintypes.DWORD.from_buffer(info(20)).value
    elevation_type=wintypes.DWORD.from_buffer(info(18)).value
    result={'schema':'lyd.r45.etw-current-token-readonly.v1','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'elevated':bool(elevation),'elevation_type':elevation_type,'elevation_type_label':{1:'Default',2:'Full',3:'Limited'}.get(elevation_type,'Unknown'),'privileges':rows,'SeSystemProfilePrivilege':next((row for row in rows if row['name']=='SeSystemProfilePrivilege'),None),'SeDebugPrivilege':next((row for row in rows if row['name']=='SeDebugPrivilege'),None),'privilege_adjustment_attempted':False,'game_process_opened':False}
    json_new(OUT/'TOKEN.actual.json',result)
finally:
    kernel.CloseHandle(token)
inventory={'schema':'lyd.r45.etw-readonly-cli-inventory.v1','tools':[ref(path) for path in (WPR,KIT/'wpr.exe',XPERF)],'commands':results,'token':ref(OUT/'TOKEN.actual.json'),'trace_start_stop_cancel_attempted':False,'source_author':ref(Path(__file__))}
json_new(OUT/'READONLY-COMMANDS.actual.json',inventory)
for row in results:
    path=Path(row['stdout']['path'])
    text=path.read_bytes().decode('utf-8',errors='replace')
    print(json.dumps({'argv':row['argv'],'returncode':row['returncode'],'stdout_head':text[:4500]},ensure_ascii=False))
print(json.dumps({'token':{key:value for key,value in result.items() if key!='privileges'},'inventory':ref(OUT/'READONLY-COMMANDS.actual.json')},ensure_ascii=False))
