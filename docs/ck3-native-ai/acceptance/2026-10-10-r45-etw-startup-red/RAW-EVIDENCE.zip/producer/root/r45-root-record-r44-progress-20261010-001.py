from pathlib import Path
import hashlib
import json
import subprocess
root=Path('C:/workspace/ck3_eternal_recurrence')
base=Path('C:/workspace/ck3_lyd_runtime_20261004')
paths=['docs/ck3-native-ai/2026-10-10-local-common-runtime-rebuild.md','docs/li-yu-dao/2026-10-09-progress.md','docs/autonomous-agent-progress/daily/2026-10-10.md','docs/autonomous-agent-progress/weekly/2026-W41.md']
paragraph='''

## 2026-10-10 11:04 CST：R44 原900秒仍未完成加载，已实际清场

R43归档与未来900秒预算已通过无冲突rebase、远端新增的独立宗教日志验证测试PASS后普通推送为 `97d16f9b1f3c91887549c987291c2435087e1025`。该精确提交 Official `38018072981`、Linear `38018072962` 均实际SUCCESS，共享acceptance和Python-only步骤也成功；LiYu NOT_TRIGGERED不计通过。51组查询及两完整日志归档在 `C:/workspace/ck3_lyd_runtime_20261004/r44-exact-97d16f9b1-ci-20261010-001`，包括TLS超时原件与恢复后的真实终态，terminal evidence SHA-256 `0a09745ea78ea7bd209cc6603bb79ffe4f67606183a11101e89a88b2228878c3`。没有dispatch或重复本机全套测试。

新 C6公共prepare/preflight均实际exit0，常规 R43 failed-launch 前驱/CAS4327准入分配 `bf-202609141645-5434332d4d--li-yu-dao--R0044`；未重复bootstrap。实际冻结输入只读对照确认，规范化运行路径/执行ID后唯一调用参数差异为readiness600→900；正式71+overlay6、4配置、原seed/actor/date、Source05/EXE/DLL/injector、typed handler、45有序缓存/政治7 AST、终点60/退出reserve90保持。全量provenance另包含rebase接入的无关XQOL adapter pin变化，不能声称全部来源仅改registry；两个outer descriptor仅profile路径不同。对照位于 `C:/workspace/ck3_lyd_runtime_20261004/r44-actual-frozen-input-comparison-20261010-001`。

公共run实际 `02:47:16.746746Z→03:02:21.541348Z exit2`，verify仍exit2。原host Popen于03:02:39.080492Z实际返回1。native终态RED，原900秒内没有Setup completion，所以未注入、native frames0/steps0，handler及业务选项/SAVE/day均0。不能据此授事务对照或正式业务信用，也不把powerful vassals最后日志行当作已定位阻塞函数。[R44原件及闭场报告](../ck3-native-ai/2026-10-10-r44-900s-startup-red.md)单独保全。

30次只读样本中，9个完整CPU区间处于600秒之后；最后约873.873秒仍CPU347.81%（单核100%口径）、read+26331485B/write+3770124B，RSS7894478848B、127线程。独立只读句柄以raw FILETIME核身份，03:02:38.247809Z、elapsed902.849849秒实际取得CK3 exit1；最后活动样本至退出约28.977秒不外推。29次SDL观测全部visible且未最小化，本场前台自然为游戏，与R43前台Steam不同；没有向游戏发送focus/输入，不认预算或前台因果。CPU活动也不能排除局部死锁。原cleanup_ok=false/session.report=null、原CreateProcess退出及Job最终count未知保持，不补造normal0。

当前CK3/case进程及控制文件清点为空，最终新鲜原图11:02 Steam离线亲审，桌面恢复1024×768；keeper原allocate Popen0/thread joined，原FINAL sequence4339，实际CAS4339→4340释放done/resources=[]。当前现场已释放，允许主树写入。本轮900秒已失败，下一步不再仅增加加载预算：本机已找到WPR/xperf，先只读核现有trace、可用CLI和权限，准备有界CPU热点/模块RVA观察以定位加载消耗；未开始新trace或新游戏，不改变系统设置或占用他人trace。

并行调整：R44原件紧凑归档、只读CPU采样工具准备、root进度与线性发布收尾；CI和固定输入对照已完成。正式I3b/C3/I4与一期仍 **NOT_GREEN**，75%仅工作量估计，无新增业务通过项。下一节点是加载热点观察方案的本机可执行性确认，之后才安排新实机；一期完成日期仍无可靠依据。缺失 `C:/workspace/ck3-upgrade-20261008` 继续不是依赖。
'''
records=[]
for rel in paths:
    p=root/rel;raw=p.read_bytes()
    if '11:04 CST：R44 原900秒' in raw.decode('utf-8-sig'):raise RuntimeError('Duplicate append')
    addition=paragraph
    if rel.startswith('docs/ck3-native-ai/'):
        addition=addition.replace('../ck3-native-ai/','')
    elif '/daily/' in rel or '/weekly/' in rel:
        addition=addition.replace('../ck3-native-ai/','../../ck3-native-ai/')
    p.write_bytes(raw+addition.encode('utf-8'))
    records.append({'path':rel,'before_sha256':hashlib.sha256(raw).hexdigest(),'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).splitlines()
if sorted(staged)!=sorted(paths):raise RuntimeError('Unexpected staged paths: '+repr(staged))
subprocess.run(['git','commit','-m','Record the R44 startup timeout and next loading diagnosis'],cwd=root,check=True)
with (base/'r45-root-record-r44-progress-20261010-001.actual.json').open('x',encoding='utf-8') as f:
    json.dump({'files':records,'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'validation':'diff --check and exact scoped staged path set'},f,indent=2)
