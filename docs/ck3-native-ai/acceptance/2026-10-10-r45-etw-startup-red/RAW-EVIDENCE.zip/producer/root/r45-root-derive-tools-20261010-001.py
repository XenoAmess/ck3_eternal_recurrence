from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

base = Path('C:/workspace/ck3_lyd_runtime_20261004')
items = [
    ('r44-root-read-latest-observation-20261010-001.py', 'r45-root-read-latest-observation-20261010-001.py', [('R0044', 'R0045')]),
    ('r44-root-closeout-20261010-001.py', 'r45-root-closeout-20261010-001.py', [('R0044', 'R0045'), ('R44', 'R45'), ('20261010-a06', '20261010-a07'), ('20261010-006', '20261010-007'), ('== 14012', '== 16528')]),
]
records = []
for old, new, replacements in items:
    src, dst = base / old, base / new
    raw = src.read_bytes()
    content = raw.decode('utf-8')
    for before, after in replacements:
        if before not in content:
            raise RuntimeError('Missing replacement: ' + before)
        content = content.replace(before, after)
    compile(content, str(dst), 'exec')
    with dst.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(content)
    records.append({'source': str(src), 'source_sha256': hashlib.sha256(raw).hexdigest(), 'target': str(dst), 'target_sha256': hashlib.sha256(dst.read_bytes()).hexdigest(), 'replacements': replacements, 'executed': False})
with (base / 'r45-root-tools-derivation-20261010-001.actual.json').open('x', encoding='utf-8') as stream:
    json.dump({'at_utc': datetime.now(timezone.utc).isoformat(), 'records': records, 'note': 'External preparation only; closeout requires actual completed RED, original host1 and independent CK3exit1; final offline image clock must be directly reviewed before executing.'}, stream, indent=2)
print(json.dumps(records))
