from pathlib import Path
import ast
import subprocess

base = Path("C:/workspace/ck3_lyd_runtime_20261004")
previous = base / "r45_run_actual_etw_analyzer_corrected_once_20261010.py"
source = previous.read_text(encoding="utf-8")
source = source.replace("OUT=BASE/'r45-actual-etw-offline-analysis-original-exec-20261010-002'", "OUT=BASE/'r45-actual-etw-offline-analysis-original-exec-20261010-003'")
source = source.replace("SOURCE=BASE/'r45-actual-etw-offline-analyzer-sourceonly-20261010-003/analyze_r45_exports.py'", "SOURCE=BASE/'r45-actual-etw-offline-analyzer-sourceonly-20261010-004/analyze_r45_exports.py'")
source = source.replace("952cb9760a4f2e67ddee06c1053d528cb344f6fb13b183403d480640d03f7e68", "f6a85c143762950c3484fbd56406336981cf0734f12f43f2feb58e04e9de28ae")
source = source.replace("'preserved_first_failure':pin(BASE/'r45-actual-etw-offline-analysis-original-exec-20261010-001/RESULT.actual.json')}", "'preserved_first_failure':pin(BASE/'r45-actual-etw-offline-analysis-original-exec-20261010-001/RESULT.actual.json'),\n         'preserved_second_failure':pin(BASE/'r45-actual-etw-offline-analysis-original-exec-20261010-002/RESULT.actual.json')}")
ast.parse(source)
path = base / "r45_run_actual_etw_analyzer_focused004_once_20261010.py"
with path.open("x", encoding="utf-8", newline="\n") as stream:
    stream.write(source)
assert not (base / "r45-actual-etw-offline-analysis-20261010-001").exists()
raise SystemExit(subprocess.call(["C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe", "-B", "-X", "utf8", str(path)], shell=False))
