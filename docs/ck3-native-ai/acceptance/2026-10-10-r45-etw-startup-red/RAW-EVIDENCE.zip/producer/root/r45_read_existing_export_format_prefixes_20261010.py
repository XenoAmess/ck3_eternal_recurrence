from pathlib import Path
root=Path('C:/workspace/ck3_lyd_runtime_20261004/r45-root-etw-synthetic-20261010-001')
for name in ['profile.txt','process.txt']:
    print(name)
    with (root/name).open('r',encoding='utf-8',errors='replace') as f:
        for n,line in enumerate(f,1):
            if n<=14 or (name=='profile.txt' and 'python.exe (6564)' in line):print(n,line.rstrip()[:1200])
            if name=='process.txt' and n>=14:break
