import hashlib
import importlib.util
import json
from pathlib import Path

base = Path("C:/workspace/ck3_lyd_runtime_20261004")
source = base / "r45-actual-etw-offline-analyzer-sourceonly-20261010-003/analyze_r45_exports.py"
spec = importlib.util.spec_from_file_location("r45_analyzer003", source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
path = module.EXPORT_ROOT / "process.txt"
body = path.read_bytes()
processes, threads, images, _ = module.parse_process(body.decode("utf-8-sig"))
out = base / "r45-actual-etw-offline-analyzer-thread-boundary-diagnostic-20261010-001"
out.mkdir(exist_ok=False)
result = {"schema": "lyd.r45.small-process-thread-lifetime-diagnostic.v1", "process_input": {"path": str(path), "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}, "target_process_rows": processes, "thread_count": len(threads), "thread_record_count": sum(map(len, threads.values())), "threads": threads, "unmatched_sample_identity": "UNKNOWN; original analyzer exception omitted actual TID/timestamp", "large_dumper_opened": False, "trace_etl_opened": False}
(out / "PROCESS-LIFETIMES.actual.json").write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n", encoding="utf-8", newline="\n")
print(json.dumps({"output": str(out), "process_input": result["process_input"], "process_rows": processes, "thread_count": len(threads), "finite_start_thread_count": sum(any(t["start_us"] is not None for t in rows) for rows in threads.values()), "finite_end_thread_count": sum(any(t["end_us"] is not None for t in rows) for rows in threads.values()), "finite_thread_rows": [t for rows in threads.values() for t in rows if t["start_us"] is not None or t["end_us"] is not None]}, ensure_ascii=False))
