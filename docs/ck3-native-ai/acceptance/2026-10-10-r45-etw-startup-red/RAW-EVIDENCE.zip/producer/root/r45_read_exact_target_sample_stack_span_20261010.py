from pathlib import Path
p=Path('C:/workspace/ck3_lyd_runtime_20261004/r45-root-etw-synthetic-20261010-001/offline-stack-001/one-dumper/events.csv')
with p.open('r',encoding='utf-8',errors='replace') as f:
    for n,line in enumerate(f,1):
        if 453780<=n<=453810 or 486625<=n<=486650:print(n,line.rstrip()[:1800])
        if n>486650:break
