import ast
import difflib
import hashlib
import json
from pathlib import Path

base = Path("C:/workspace/ck3_lyd_runtime_20261004")
old = base / "r45-actual-etw-offline-analyzer-sourceonly-20261010-003/analyze_r45_exports.py"
body = old.read_bytes()
assert hashlib.sha256(body).hexdigest() == "952cb9760a4f2e67ddee06c1053d528cb344f6fb13b183403d480640d03f7e68"
before = body.decode("utf-8")
text = before
start = text.index("    official_profile = []\n")
end = text.index("    result = {", start)
small_validation = text[start:end]
text = text[:start] + text[end:]
insert = text.index("    dumper_stat_before =")
text = text[:insert] + small_validation + text[insert:]
text = text.replace("    sample_stack_keys = set(); pending = None; current_example = None\n", "    quarantined = []; quarantined_sample_events = 0; quarantined_sample_count = 0\n")
text = text.replace("            # xperf contains opaque non-UTF8 metadata bytes.", "            # CPU-hotspot scope: hash every raw line, parse only SampledProfile rows.\n            if not raw_line.lstrip().startswith(b\"SampledProfile,\"): continue\n            # xperf contains opaque non-UTF8 metadata bytes.")
text = text.replace("                pending = None; current_example = None\n", "")
needle = '                if tid not in threads or not any(inside_time(ts,t) for t in threads[tid]): raise ValueError("Sample outside declared target thread lifetime")\n                if count < 1: raise ValueError("Invalid SampledProfile Count")\n'
replacement = '''                if count < 1: raise ValueError("Invalid SampledProfile Count")
                if tid not in threads or not any(inside_time(ts,t) for t in threads[tid]):
                    quarantined_sample_events += 1; quarantined_sample_count += count
                    if len(quarantined) < 64:
                        quarantined.append({"line_number":n,"timestamp_us":ts,"tid":tid,"ip":hex(ip),"count":count,
                            "qualification":"UNKNOWN; excluded from module/IP/RVA/thread hotspots",
                            "reason":"target_thread_not_declared" if tid not in threads else "outside_declared_target_thread_lifetime",
                            "declared_windows":threads.get(tid,[]),"raw_line":line.rstrip()})
                    continue
'''
assert text.count(needle) == 1
text = text.replace(needle, replacement)
text = text.replace("                pending = (ts,tid)\n", "")
start = text.index('            elif stripped.startswith("Stack,"):')
end = text.index("    dumper_stat_after =", start)
text = text[:start] + text[end:]
needle = '        "sample_events_with_attached_stack_observed":len(sample_stack_keys),"target_thread_stack_frame_modules":frame_modules,\n        "raw_sample_examples":raw_examples,"raw_sample_stack_examples":raw_stacks,\n'
replacement = '''        "sample_events_with_attached_stack_observed":None,"target_thread_stack_frame_modules":None,
        "raw_sample_examples":raw_examples,"raw_sample_stack_examples":None,"raw_stack_analysis_skipped":True,
        "raw_stack_boundary":"Raw Stack body census omitted; official stack.txt statistics remain separately preserved",
        "quarantined_target_sample_events":quarantined_sample_events,"quarantined_target_sample_count":quarantined_sample_count,
        "quarantined_target_sample_examples":quarantined,"quarantined_examples_limit":64,
        "all_target_sample_event_count":sample_events+quarantined_sample_events,
'''
assert text.count(needle) == 1
text = text.replace(needle, replacement)
text = text.replace('           "样本量、官方 profile Weight 与 stack hits 分列。模块/IP/RVA 均由实际导出匹配；无匹配区间保持 UNMAPPED。未解析函数语义，热点不单独证明加载原因。", "",', '           f"未匹配线程生命周期的目标样本 {quarantined_sample_events} 行（Count {quarantined_sample_count}）单列 UNKNOWN，不进入热点。", "",\n           "样本量与官方 profile Weight 分列。模块/IP/RVA 均由实际导出匹配；无匹配区间保持 UNMAPPED。未解析函数语义，热点不单独证明加载原因。原始 Stack 正文未逐行解析，附带栈覆盖率 UNKNOWN；官方 stack.txt 统计独立保留。", "",')
text = text.replace('    sample_stack_keys = set(); pending = None; current_example = None\n', '')
ast.parse(text)
out = base / "r45-actual-etw-offline-analyzer-sourceonly-20261010-004"
out.mkdir(exist_ok=False)
(out / "analyze_r45_exports.py").write_text(text, encoding="utf-8", newline="\n")
(out / "003-to-004.incremental.patch").write_text("".join(difflib.unified_diff(before.splitlines(True), text.splitlines(True), fromfile="003/analyze_r45_exports.py", tofile="004/analyze_r45_exports.py")), encoding="utf-8", newline="\n")
def pin(path):
    data = path.read_bytes()
    return {"path":str(path),"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()}
index = {"schema":"lyd.r45.etw-cpu-analyzer004-sourceonly.v1","source":pin(out/"analyze_r45_exports.py"),"parent_source":pin(old),"patch":pin(out/"003-to-004.incremental.patch"),"preserved_red_results":[pin(base/f"r45-actual-etw-offline-analysis-original-exec-20261010-{seq}/RESULT.actual.json") for seq in ("001","002")],"thread_boundary_diagnostic":pin(base/"r45-actual-etw-offline-analyzer-thread-boundary-diagnostic-20261010-001/PROCESS-LIFETIMES.actual.json"),"scope":"Only SampledProfile rows are decoded/parsed; original bytes of all rows still hashed during one complete pass. Unmatched target thread/time rows are UNKNOWN and excluded, with raw examples and declared windows. Raw Stack body skipped; attached stack coverage UNKNOWN. Official stack.txt independently authenticated. Small export schema validation precedes the large read.","source_ast_parse_exit0":True,"future_actual_analysis":None,"game_or_trace_actions":False}
(out/"SOURCE-INDEX.json").write_text(json.dumps(index,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps({"source":pin(out/"analyze_r45_exports.py"),"index":pin(out/"SOURCE-INDEX.json"),"preserved_red":index["preserved_red_results"]},ensure_ascii=False))
