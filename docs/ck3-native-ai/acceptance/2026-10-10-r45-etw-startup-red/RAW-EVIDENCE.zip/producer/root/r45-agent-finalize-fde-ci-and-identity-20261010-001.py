"""Summarize captured CI and retain narrow, read-only Git identity evidence."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

repo = Path('C:/workspace/ck3_eternal_recurrence')
out = Path('C:/workspace/ck3_lyd_runtime_20261004/r45-exact-fde5fb0a0-ci-20261010-001')
identity = out / 'identity-policy-readonly-001'
identity.mkdir(exist_ok=False)

def write(name, value):
    with (identity / name).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')

commands = [
    ('repo-local-identity', ['git', 'config', '--show-origin', '--get-regexp', r'^user\.(name|email)$']),
    ('effective-author', ['git', 'var', 'GIT_AUTHOR_IDENT']),
    ('effective-committer', ['git', 'var', 'GIT_COMMITTER_IDENT']),
    ('own-f3a-commit', ['git', 'show', '-s', '--format=fuller', 'f3a564b502b8a36f626b00efccf79f00d907f5ee']),
    ('synced-fde-commit', ['git', 'show', '-s', '--format=fuller', 'fde5fb0a03d24ba00b8a09ce0a52462a50882671']),
]
for label, argv in commands:
    started = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=repo, capture_output=True, timeout=20)
    (identity / (label + '.stdout.log')).write_bytes(result.stdout)
    (identity / (label + '.stderr.log')).write_bytes(result.stderr)
    write(label + '.actual.json', {'argv': argv, 'cwd': str(repo), 'started_at_utc': started,
        'finished_at_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': result.returncode,
        'stdout_bytes': len(result.stdout), 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
        'stderr_bytes': len(result.stderr), 'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()})
    print(json.dumps({'identity_read': label, 'exit_code': result.returncode,
        'stdout': result.stdout.decode('utf-8', errors='replace')}))

sources = []
for relative, first, last in [
    ('docs/autonomous-agent-progress/daily/2026-09-10.md', 223, 227),
    ('docs/git-operator.md', 10, 15),
    ('tools/setup_git_operator.py', 180, 192),
]:
    raw = (repo / relative).read_bytes()
    lines = raw.decode('utf-8-sig').splitlines()
    sources.append({'repo_relative_path': relative, 'file_bytes': len(raw),
        'file_sha256': hashlib.sha256(raw).hexdigest(), 'first_line': first, 'last_line': last,
        'excerpt': '\n'.join(lines[first - 1:last])})
write('SOURCE-EXCERPTS.actual.json', {'sources': sources, 'read_only': True,
    'config_mutation_performed': False, 'history_rewrite_performed': False})

for name in ('FINAL.actual.json', 'TERMINAL-EVIDENCE.actual.json'):
    raw = (out / name).read_bytes()
    value = json.loads(raw)
    workflows = {}
    for workflow_name, row in value['workflow_status'].items():
        compact = {key: row[key] for key in ('id', 'status', 'conclusion', 'html_url', 'head_sha', 'terminal_jobs') if key in row}
        archive = row.get('full_log_archive')
        if archive:
            compact['full_log_archive'] = {key: archive[key] for key in ('file', 'bytes', 'sha256')}
            compact['full_log_archive']['entry_count'] = len(archive['entries'])
        workflows[workflow_name] = compact
    print(json.dumps({'file': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
        'head_sha': value['head_sha'], 'workflow_status': workflows,
        'verified_query_pairs': value.get('original_query_pairs_byte_hash_verified')}))
