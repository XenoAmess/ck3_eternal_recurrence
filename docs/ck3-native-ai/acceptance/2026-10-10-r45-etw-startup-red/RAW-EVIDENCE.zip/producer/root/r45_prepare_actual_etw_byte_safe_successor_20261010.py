from pathlib import Path
import ctypes,ast,difflib,hashlib,json,base64
base=Path('C:/workspace/ck3_lyd_runtime_20261004')
old=base/'r45-actual-etw-offline-analyzer-sourceonly-20261010-002'
out=base/'r45-actual-etw-offline-analyzer-sourceonly-20261010-003'
out.mkdir()
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
before=(old/'analyze_r45_exports.py').read_text(encoding='utf-8')
assert pin(old/'analyze_r45_exports.py')['sha256']=='793643d409833fa194d1fb4c9c591163ae1387868f5fa3b625950a20d38e5d4e'
previous='''            line = raw_line.decode("utf-8-sig" if n == 1 else "utf-8", errors="strict")
'''
replacement='''            # xperf contains opaque non-UTF8 metadata bytes. Required event/numeric
            # tokens are ASCII; render other bytes as explicit \\xNN escapes in excerpts.
            # This does not replace bytes in the original hash or guess a text codec.
            line = raw_line.decode("ascii", errors="backslashreplace")
'''
assert before.count(previous)==1
source=before.replace(previous,replacement)
previous2='''        "dumper_hash_computed_during_single_pass":True,"dumper_hash_passes":1,"actual_dumper_command_provenance":dumper_commands,
'''
replacement2=previous2+'''        "dumper_text_policy":"Required event/PID/TID/timestamp/IP/count tokens are ASCII; informational non-ASCII bytes are shown as explicit byte escapes. Original hash uses unchanged bytes.",
'''
assert source.count(previous2)==1
source=source.replace(previous2,replacement2)
ast.parse(source)
(out/'analyze_r45_exports.py').write_text(source,encoding='utf-8',newline='\n')
(out/'002-to-003.incremental.patch').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),source.splitlines(keepends=True),fromfile='source002/analyze_r45_exports.py',tofile='source003/analyze_r45_exports.py')),encoding='utf-8',newline='\n')
kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.GetACP.restype=ctypes.c_uint
encoding={'Windows_GetACP_actual':kernel.GetACP(),'read_budget_bytes':1048576,'prefix_bytes_read':0,
          'global_dumper_text_encoding':'UNKNOWN','full_dumper_read_or_hash':False,'etl_opened':False}
path=Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0045/etw-cpu-001/dumper.txt')
with path.open('rb') as f:
    for n,line in enumerate(f,1):
        if encoding['prefix_bytes_read']+len(line)>encoding['read_budget_bytes']:break
        encoding['prefix_bytes_read']+=len(line)
        try:line.decode('utf-8',errors='strict')
        except UnicodeDecodeError as error:
            encoding.update(line_number=n,event_prefix_ascii=line.split(b',',1)[0].strip().decode('ascii',errors='backslashreplace'),
                invalid_utf8_byte_hex=line[error.start:error.end].hex(),raw_line_base64=base64.b64encode(line).decode('ascii'))
            try:line.decode('mbcs',errors='strict');encoding['mbcs_strict_success']=True
            except UnicodeDecodeError:encoding['mbcs_strict_success']=False
            break
assert 'invalid_utf8_byte_hex' in encoding
(out/'ENCODING-BOUNDARY.actual.json').write_text(json.dumps(encoding,indent=2)+'\n',encoding='utf-8',newline='\n')
template=json.loads((old/'COMMAND.template.json').read_text(encoding='utf-8'))
template['argv'][4]=str(out/'analyze_r45_exports.py')
(out/'COMMAND.template.json').write_text(json.dumps(template,indent=2)+'\n',encoding='utf-8',newline='\n')
readme='''# R45 actual analyzer 003：字节呈现修正

002 首次 actual 执行 return1，在 CSV 开头非UTF8字节0xae处终止，没有完成CSV读取或生成SHA。失败 RESULT/stdout/stderr 保留在 original-exec001。后续限定1MiB的编码读取也证实不能直接假定 Windows ACP/mbcs；首次诊断的原失败脚本保留，当前原始证据在 ENCODING-BOUNDARY.actual.json，不给全文件编码命名。

003 只把 CSV 的文本呈现改为 ASCII + 明确反斜杠字节转义。被解析的 event/PID/TID/time/IP/count 合同均为原ASCII；数字转换仍严格，非ASCII数字不会通过。其余非ASCII元数据不参与资格，excerpt按\\xNN显示，不猜UTF8或ANSI、不替换底层bytes。SHA仍同步更新原始raw_line；没有第二个大文件hash pass，ETL不打开。

最终 AST parse0；不重复help/tests。001/002与失败原件均保留。首次完整CSV pass随后执行；本包本身尚无实际模块热点资格。
'''
(out/'README.zh.md').write_text(readme,encoding='utf-8',newline='\n')
index={'schema':'lyd.r45.actual-etw-analyzer-sourceonly-index.v3','previous_source_index':pin(old/'SOURCE-INDEX.json'),
 'files':[pin(out/n) for n in ['analyze_r45_exports.py','002-to-003.incremental.patch','ENCODING-BOUNDARY.actual.json','COMMAND.template.json','README.zh.md']],
 'source_author':pin(Path(__file__)),'original_failed_exec':pin(base/'r45-actual-etw-offline-analysis-original-exec-20261010-001/RESULT.actual.json'),
 'initial_failed_encoding_author':pin(base/'r45_read_dumper_encoding_bounded_20261010.py'),
 'syntax_ast_parse':True,'completed_dumper_hash_or_analysis':False,'etl_opened':False}
(out/'SOURCE-INDEX.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['analyze_r45_exports.py','SOURCE-INDEX.json','ENCODING-BOUNDARY.actual.json']:print(json.dumps(pin(out/name)))
print(json.dumps({k:encoding[k] for k in ['Windows_GetACP_actual','prefix_bytes_read','event_prefix_ascii','mbcs_strict_success']}))
