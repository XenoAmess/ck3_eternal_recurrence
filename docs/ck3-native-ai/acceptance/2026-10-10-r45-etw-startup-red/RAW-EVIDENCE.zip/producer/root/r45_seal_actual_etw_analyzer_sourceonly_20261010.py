from pathlib import Path
import hashlib,json,ast
out=Path('C:/workspace/ck3_lyd_runtime_20261004/r45-actual-etw-offline-analyzer-sourceonly-20261010-001')
source=out/'analyze_r45_exports.py'
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def new(name,value):
    with (out/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2,ensure_ascii=False);f.write('\n')
ast.parse(source.read_text(encoding='utf-8'),filename=str(source))
argv=['C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe','-B','-X','utf8',str(source)]
for key in ['profile','process','stack','dumper','tracestats']:
    argv+=['--'+key,'<actual-R45-'+key+'-export-path>']
argv+=['--receipt','<actual-ROOT-export-receipt-containing-dumper-pin>',
       '--output','C:/workspace/ck3_lyd_runtime_20261004/r45-actual-etw-offline-analysis-20261010-001']
new('COMMAND.template.json',{'schema':'lyd.r45.actual-etw-analyzer-command.source-only.v1','argv':argv,'executed':False,
    'mandatory_late_inputs':['five completed actual R45 text exports','ROOT actual dumper bytes/SHA receipt'],
    'analysis_result':None,'game_hotspots':None,'loss_statistics':None,'root_ready_signal_received':False})
report='''# R45 离线分析器（仅源码准备）

固定 ROOT 本轮 PID16528/create1791603219.1009781/FILETIME134360768191009782/sourceHEADfde5fb0a03d24ba00b8a09ce0a52462a50882671。ROOT 报告的创建身份与 ETL 的 process/thread/image 核对分列，不把 MIN 时间映射成新进程出生时间。

入口为 analyze_r45_exports.py，完整参数见 COMMAND.template.json。只读五份已完成导出，严格限制为 R0045/etw-cpu-001 内文件；必须由 ROOT 原实际回执提供 dumper path/bytes/SHA。CSV 只做一次流式分析，不重算其哈希，不打开/重算 ETL，也不运行 xperf/WPR/任何外部命令。

复用 synthetic 已实证的 SampledProfile.PrgrmCtr、Stack.Address 和 Image BaseAddr/EndAddr 合同；新增当前游戏必要的 MIN/MAX、同PID线程时间边界、重复相同 image interval 处理。按实际采样时间及有效模块区间计算 RVA，未匹配为 UNMAPPED；模块加载冲突拒绝。目标线程总数、出现 CPU 样本的线程及全部线程采样量分列，官方 profile Weight、SampledProfile 行数/Count、官方 stack hits 分列，loss 字段缺失保持 UNKNOWN。提取前三个真正随 target sample 的原始栈，缺失不伪造。

将生成 ANALYSIS.actual.json、HOTSPOTS.csv、THREADS.csv、REPORT.zh.md、INDEX.json。源码 CLI help 已实际 exit0，最终源码 AST parse0；当前没有读取 R45 导出或执行分析。等待 ROOT 的 final-exports-ready 信号；实际热点、loss、函数含义与原因均未获信用。synthetic 地址不会写入 actual 结果。
'''
(out/'README.zh.md').write_text(report,encoding='utf-8',newline='\n')
new('SOURCE-INDEX.json',{'schema':'lyd.r45.actual-etw-analyzer-sourceonly-index.v1',
    'source':pin(source),'files':[pin(out/n) for n in ['COMMAND.template.json','README.zh.md']],
    'author':pin(Path(__file__)),'syntax_ast_parse':True,'prior_help_original_exec_chunk':'4b5244','prior_help_exit_code':0,
    'actual_exports_consumed':False,'actual_results':None,
    'synthetic_reference':pin(Path('C:/workspace/ck3_lyd_runtime_20261004/r45-root-etw-synthetic-20261010-001/offline-stack-001/ADDRESS-PROOF.actual.json'))})
for name in ['analyze_r45_exports.py','SOURCE-INDEX.json','COMMAND.template.json']:print(json.dumps(pin(out/name)))
