import json
import psutil

rows = []
for proc in psutil.process_iter(["pid", "create_time", "cmdline"]):
    argv = proc.info["cmdline"] or []
    if not any("r45-actual-etw-offline-analyzer-sourceonly-20261010-003" in arg for arg in argv):
        continue
    rows.append({"pid": proc.pid, "create_time": proc.create_time(), "cpu": proc.cpu_times()._asdict(), "io": proc.io_counters()._asdict(), "status": proc.status()})
print(json.dumps(rows, ensure_ascii=True))
