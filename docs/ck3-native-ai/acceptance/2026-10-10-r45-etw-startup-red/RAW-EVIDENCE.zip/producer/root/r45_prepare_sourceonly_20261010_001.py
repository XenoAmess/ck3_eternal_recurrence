from pathlib import Path
import ast
import copy
from datetime import datetime, timezone
import difflib
import hashlib
import json
import re

B = Path('C:/workspace/ck3_lyd_runtime_20261004')
ROOT = Path('C:/workspace/ck3_eternal_recurrence')
OLD = B / 'r44-transaction-control-prepare-sourceonly-20261010-001'
OUT = B / 'r45-transaction-control-prepare-sourceonly-20261010-001'
COMMON = Path('C:/workspace/ck3-common-runtime')
L44 = COMMON / 'runs/bf-202609141645-5434332d4d--li-yu-dao--R0044'
L45 = L44.with_name(L44.name.replace('R0044', 'R0045'))
CASE = COMMON / 'cases/lyd-transaction-control-20261010-007'
KEEPER = 'C:/workspace/ck3-common-runtime/keepers/20261010-a07'

def ref(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def load(path):
    return json.loads(Path(path).read_bytes())

def write(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    return ref(path)

def textwrite(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(value)

def changes(old, new, prefix=''):
    if isinstance(old, dict) and isinstance(new, dict):
        assert old.keys() == new.keys()
        return [item for key in old for item in changes(old[key], new[key], prefix + '/' + key)]
    if isinstance(old, list) and isinstance(new, list):
        assert len(old) == len(new)
        return [item for index in range(len(old)) for item in changes(old[index], new[index], prefix + '/' + str(index))]
    return [] if old == new else [{'path': prefix, 'old': old, 'new': new}]

def derive(argv, updates):
    result = list(argv)
    for key, value in updates.items():
        assert result.count(key) == 1, key
        result[result.index(key) + 1] = value
    assert [item for item in argv if item.startswith('--')] == [item for item in result if item.startswith('--')]
    return result

assert not OUT.exists(), OUT
index = load(OLD / 'INDEX.json')
assert ref(OLD / 'INDEX.json')['sha256'] == 'f3a25f2fa3536790d0dd770e83eb05bee0449ec1e4df28d4e22c0aee4b3629cb'
oldpins = {Path(item['path']).name: item for item in index['files']}
needed = ['prepare-inputs.candidate.json', 'PREPARE-ARGV.actual.json', 'PREFLIGHT-ARGV.actual.json', 'REGISTRY-DIFF.actual.json', 'CONTENT-PIN-CHECKS.actual.json', 'DERIVATION.actual.json']
scripts = sorted((OLD / 'scripts').glob('*.py'))
assert len(scripts) == 5
sources = []
for path in [OLD / name for name in needed] + scripts:
    actual = ref(path)
    assert actual == oldpins[path.name], (path, actual)
    sources.append(actual)

inputs = load(OLD / 'prepare-inputs.candidate.json')
newinputs = copy.deepcopy(inputs)
newinputs['state_dir'] = str(CASE / 'state').replace('\\', '/')
assert changes(inputs, newinputs) == [{'path': '/state_dir', 'old': inputs['state_dir'], 'new': newinputs['state_dir']}]
assert inputs['saved_campaign']['player_id'] == 31254
assert inputs['saved_campaign']['date_raw'] == 53144712
seedstat = Path(inputs['saved_campaign']['save']).stat()
assert seedstat.st_size == inputs['saved_campaign']['bytes'] == 91711686

previous_result = L44 / 'release-command-001/RESULT.actual.json'
previous_stdout = L44 / 'release-command-001/stdout.log'
release_command = load(previous_result)
release = load(previous_stdout)
assert release_command['exit_code'] == 0
assert release['ok'] is True
assert release['task']['state'] == 'done'
assert release['task']['resources'] == []
assert release['task']['last_sequence'] == release['event']['sequence'] == 4340
assert release['task']['task_id'] == 'common-acceptance-12004-20261010-a06'

content = load(OLD / 'CONTENT-PIN-CHECKS.actual.json')
assert (content['production_count'], content['overlay_count'], content['plain_configuration_count']) == (71, 6, 4)
fresh = {}
for key in ['adapter', 'config', 'runtime_manifest']:
    fresh[key] = ref(content[key]['path'])
    assert fresh[key] == content[key], (key, fresh[key], content[key])
registry_path = ROOT / 'tools/ck3_mod_acceptance_products.json'
registry = load(registry_path)
target = next(item for item in registry['products']['li-yu-dao']['cases'] if item['id'] == 'transaction-only-control')
oldregistry = load(OLD / 'REGISTRY-DIFF.actual.json')
assert target['budgets'] == oldregistry['new_budgets']
assert target['budgets']['readiness_timeout'] == 900
assert target['normal_close'] == oldregistry['normal_close']
assert target['normal_close']['reserve_seconds'] == 90
baseline = load(OLD / 'DERIVATION.actual.json')
assert baseline['terminal_observation_seconds'] == 60

replacement_map = {
    'R0044': 'R0045', 'R0043': 'R0044', 'r44-': 'r45-',
    'r43-root-case-allocate-': 'r44-root-case-allocate-',
    'lyd-transaction-control-20261010-006': 'lyd-transaction-control-20261010-007',
    '20261010-a06': '20261010-a07', "'a06'": "'a07'", "'a05'": "'a06'",
}
pattern = re.compile('|'.join(re.escape(key) for key in sorted(replacement_map, key=len, reverse=True)))
def transform(value):
    return pattern.sub(lambda match: replacement_map[match.group(0)], value)

prepared = str(CASE / 'prepared/prepared-case.json').replace('\\', '/')
argvs = {}
argvdiffs = {}
actual_sources = []
for phase in ['prepare', 'preflight']:
    source = load(OLD / (phase.upper() + '-ARGV.actual.json'))
    updates = {'--case-inputs': str(OUT / 'prepare-inputs.candidate.json').replace('\\', '/'), '--prepare-output': str(CASE / 'prepared').replace('\\', '/')} if phase == 'prepare' else {'--prepared-case': prepared}
    argvs[phase] = derive(source['argv'], updates)
    argvdiffs[phase] = changes(source['argv'], argvs[phase])
for phase in ['allocate', 'run', 'verify']:
    path = B / 'r44-root-case-allocate-20261010-001/RESULT.actual.json' if phase == 'allocate' else L44 / (phase + '-command-001/RESULT.actual.json')
    source = load(path)
    actual_sources.append(ref(path))
    updates = {'--prepared-case': prepared}
    if phase == 'allocate':
        assert source['exit_code'] == 0
        updates.update({'--attempt': 'a07', '--keeper-output': KEEPER, '--previous-live': str(L44), '--previous-keeper': KEEPER.replace('a07', 'a06'), '--previous-release': str(previous_stdout)})
    else:
        updates['--run-context'] = str(L45 / 'reviewed-context.json')
    argvs[phase] = derive(source['argv'], updates)
    argvdiffs[phase] = changes(source['argv'], argvs[phase])

derived_scripts = []
for source in scripts:
    original = source.read_text(encoding='utf-8')
    candidate = transform(original)
    filename = source.name.replace('r44-', 'r45-')
    compile(candidate, str(OUT / 'scripts' / filename), 'exec')
    beforetree = ast.parse(original)
    aftertree = ast.parse(candidate)
    # Every changed AST leaf must be a string. All numeric limits, calls and branches remain exact.
    before_nodes = list(ast.walk(beforetree))
    after_nodes = list(ast.walk(aftertree))
    assert len(before_nodes) == len(after_nodes)
    for left, right in zip(before_nodes, after_nodes):
        assert type(left) is type(right)
        if isinstance(left, ast.Constant) and left.value != right.value:
            assert isinstance(left.value, str) and isinstance(right.value, str)
    derived_scripts.append((source, filename, original, candidate))
observer = next(item[3] for item in derived_scripts if 'startup-observer' in item[1])
assert '1200' in observer
driver = next(item[3] for item in derived_scripts if 'command-driver' in item[1])
assert "run.name.replace('R0045', 'R0044')" in driver
assert "keeper.replace('a07', 'a06')" in driver
assert 'r44-root-case-allocate-20261010-001/RESULT.actual.json' in driver
assert OUT.as_posix() + '/scripts' in driver

OUT.mkdir()
(OUT / 'scripts').mkdir()
write('prepare-inputs.candidate.json', newinputs)
for phase, argv in argvs.items():
    suffix = 'actual' if phase in ('prepare', 'preflight') else 'candidate'
    write(phase.upper() + '-ARGV.' + suffix + '.json', {'cwd': str(ROOT), 'argv': argv, 'executed': False})
script_records = []
for source, filename, original, candidate in derived_scripts:
    output = OUT / 'scripts' / filename
    textwrite(output, candidate)
    diffpath = output.with_name(output.name + '.diff')
    textwrite(diffpath, ''.join(difflib.unified_diff(original.splitlines(True), candidate.splitlines(True), fromfile=str(source), tofile=str(output))))
    script_records.append({'source': ref(source), 'candidate': ref(output), 'diff': ref(diffpath), 'compile': 'PASS', 'AST_changed_leaves': 'string paths/identities only; numeric constants unchanged', 'executed': False})
write('SCRIPT-DERIVATIONS.actual.json', script_records)
write('INHERITED-PINS.actual.json', {
    'r44_content_pin_receipt': ref(OLD / 'CONTENT-PIN-CHECKS.actual.json'),
    'historically_verified_production_count': 71, 'historically_verified_overlay_count': 6,
    'historically_verified_plain_configuration_count': 4,
    'r45_content_body_rehashes': 0, 'r45_plain_configuration_body_rehashes': 0,
    'fresh_small_file_checks': fresh, 'registry': ref(registry_path),
    'registry_budgets': target['budgets'], 'normal_close': target['normal_close'],
    'seed': {'path': inputs['saved_campaign']['save'], 'actual_stat_bytes': seedstat.st_size, 'inherited_sha256': inputs['saved_campaign']['sha256'], 'body_reads': 0},
})
write('DERIVATION.actual.json', {
    'schema': 'lyd.r45.prepare-sourceonly.v1', 'at_utc': datetime.now(timezone.utc).isoformat(),
    'original_index': ref(OLD / 'INDEX.json'), 'verified_small_sources': sources,
    'actual_r44_command_sources': actual_sources, 'input_differences': changes(inputs, newinputs),
    'argv_differences': argvdiffs, 'replacement_map': replacement_map,
    'previous_release': {'recorded_command': ref(previous_result), 'actual_stdout': ref(previous_stdout), 'actual_release_sequence': 4340},
    'budgets': target['budgets'], 'terminal_observation_seconds': 60, 'normal_close_reserve_seconds': 90,
    'observer_seconds': 1200, 'observer_discovery_seconds': 120, 'observer_sample_interval_seconds': 30,
    'product_overlay_plain_config_pins': 'exactly inherited from R44; no repeated 77+4 body hashing',
    'actor': 31254, 'date_raw': 53144712, 'runtime': content['runtime_manifest'],
    'new_CLI_flags': 0, 'runtime_changes': 0, 'new_loop_deadlines': 0,
    'seed_body_reads': 0, 'public_entry_invocations': 0, 'game_launches': 0, 'SDK_calls': 0,
    'repo_writes': 0, 'Git_commands': 0, 'candidate_execution': False, 'business_pass': False,
    'WPR': 'not integrated or executed; separately owned by root',
    'case007_exists_at_authoring': CASE.exists(), 'runR0045_exists_at_authoring': L45.exists(),
    'task_bus_update': 'not invoked because its status path calls git_identity; current task expressly forbids Git',
})
write('INDEX.json', {
    'schema': 'lyd.r45.sourceonly-candidates-index.v1', 'producer': ref(__file__),
    'original_r44_index': ref(OLD / 'INDEX.json'),
    'files': [ref(path) for path in sorted(OUT.rglob('*')) if path.is_file()],
    'candidate_compile_checks': '5 PASS; none executed', 'source_pin_checks': 'PASS; existing R44 77+4 verification reused',
})
for item in load(OUT / 'INDEX.json')['files']:
    assert ref(item['path']) == item
print(json.dumps({'output': str(OUT), 'index': ref(OUT / 'INDEX.json'), 'inputs': ref(OUT / 'prepare-inputs.candidate.json'), 'driver': ref(OUT / 'scripts/r45-root-command-driver-20261010-001.py'), 'compile': '5 PASS', 'executed': False}, ensure_ascii=False, indent=2))
