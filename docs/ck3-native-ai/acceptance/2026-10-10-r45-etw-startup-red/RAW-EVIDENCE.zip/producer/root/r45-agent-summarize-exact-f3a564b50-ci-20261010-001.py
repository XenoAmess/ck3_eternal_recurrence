"""Read already captured terminal receipts; no API requests or tests."""
from pathlib import Path
import hashlib
import json

out = Path('C:/workspace/ck3_lyd_runtime_20261004/r45-exact-f3a564b50-ci-20261010-001')
for name in ('FINAL.actual.json', 'TERMINAL-EVIDENCE.actual.json'):
    raw = (out / name).read_bytes()
    value = json.loads(raw)
    workflows = {}
    for workflow_name, row in value['workflow_status'].items():
        compact = {key: row[key] for key in ('id', 'status', 'conclusion', 'html_url', 'head_sha', 'terminal_jobs') if key in row}
        archive = row.get('full_log_archive')
        if archive:
            compact['full_log_archive'] = {key: archive[key] for key in ('file', 'bytes', 'sha256')}
            compact['full_log_archive']['entry_count'] = len(archive['entries'])
        workflows[workflow_name] = compact
    print(json.dumps({'file': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
        'head_sha': value['head_sha'], 'workflow_status': workflows,
        'verified_query_pairs': value.get('original_query_pairs_byte_hash_verified')}))
jobs_file = sorted(out.glob('poll-*-jobs-38019680093.stdout.json'))[-1]
jobs = json.loads(jobs_file.read_bytes())
print(json.dumps({'focused_steps_source': jobs_file.name, 'focused_steps': [
    step for job in jobs['jobs'] for step in job.get('steps', [])
    if 'Python-only' in step['name'] or 'shared CK3 acceptance' in step['name']
]}))
