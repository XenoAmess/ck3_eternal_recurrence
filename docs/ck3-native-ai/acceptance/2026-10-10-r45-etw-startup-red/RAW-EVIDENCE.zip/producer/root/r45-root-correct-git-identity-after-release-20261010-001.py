from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys

base = Path('C:/workspace/ck3_lyd_runtime_20261004')
root = Path('C:/workspace/ck3_eternal_recurrence')
run = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0045')
release = json.loads((run / 'release-command-001/RESULT.actual.json').read_bytes())
if release['exit_code'] != 0:
    raise SystemExit('Actual R45 lease release did not succeed')
lease = json.loads((run / 'release-command-001/stdout.log').read_bytes())
if not lease.get('ok') or lease.get('task', {}).get('task_id') != 'common-acceptance-12004-20261010-a07' or lease.get('task', {}).get('state') != 'done' or lease.get('task', {}).get('resources') != []:
    raise SystemExit('Actual R45 release identity mismatch')
out = base / 'r45-root-git-identity-correction-20261010-001'
out.mkdir()
py = sys.executable
recorder = str(base / 'root-record-command-20261010-001.py')
commands = [
    ('001-before', ['git', 'config', '--show-origin', '--get-regexp', '^user\\.']),
    ('002-set-name', ['git', 'config', '--local', 'user.name', 'XenoAmess']),
    ('003-set-email', ['git', 'config', '--local', 'user.email', 'xenoamess@gmail.com']),
    ('004-after', ['git', 'config', '--show-origin', '--get-regexp', '^user\\.']),
]
results = []
for label, argv in commands:
    code = subprocess.call([py, '-B', '-X', 'utf8', recorder, str(out / label), *argv], cwd=root)
    results.append({'label': label, 'returncode': code})
    if code != 0:
        raise SystemExit(code)
name = subprocess.check_output(['git', 'config', '--local', '--get', 'user.name'], cwd=root).decode().strip()
email = subprocess.check_output(['git', 'config', '--local', '--get', 'user.email'], cwd=root).decode().strip()
if name != 'XenoAmess' or email != 'xenoamess@gmail.com':
    raise SystemExit('Actual identity readback differs')
value = {'at_utc': datetime.now(timezone.utc).isoformat(), 'name': name, 'email': email,
    'scope': 'repository local configuration', 'results': results,
    'release_receipt_sha256': hashlib.sha256((run / 'release-command-001/RESULT.actual.json').read_bytes()).hexdigest(),
    'existing_commits_rewritten': False, 'force_push_used': False}
with (out / 'VERIFIED.actual.json').open('x', encoding='utf-8') as stream:
    json.dump(value, stream, indent=2)
print(json.dumps(value))
