from pathlib import Path
import ctypes,json,hashlib,base64
BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
out=BASE/'r45-actual-etw-offline-analyzer-encoding-diagnostic-20261010-001'
out.mkdir()
path=Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0045/etw-cpu-001/dumper.txt')
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.GetACP.restype=ctypes.c_uint
codepage=kernel.GetACP();read_bytes=0;invalid=None
with path.open('rb') as f:
    for n,line in enumerate(f,1):
        if read_bytes+len(line)>1024*1024:break
        read_bytes+=len(line)
        try:line.decode('utf-8-sig' if n==1 else 'utf-8',errors='strict')
        except UnicodeDecodeError as error:
            decoded=line.decode('mbcs',errors='strict')
            invalid={'line_number':n,'byte_position_in_line':error.start,'invalid_bytes_hex':line[error.start:error.end].hex(),
                     'raw_line_base64':base64.b64encode(line).decode('ascii'),'windows_mbcs_decoded_text':decoded.rstrip(),
                     'windows_mbcs_strict_decode_succeeded':True}
            break
assert invalid is not None,'No invalid UTF8 in bounded prefix'
result={'schema':'lyd.r45.dumper-actual-text-encoding-readonly.v1','source_file':str(path),'read_budget_bytes':1024*1024,
        'prefix_bytes_read':read_bytes,'full_dumper_read_or_hashed':False,'Windows_GetACP_actual':codepage,'decoder':'mbcs (actual Windows ACP)',
        'first_non_utf8_line':invalid,'etl_opened':False,'wpr_or_exports_called':False,
        'original_failed_exec':str(BASE/'r45-actual-etw-offline-analysis-original-exec-20261010-001/RESULT.actual.json')}
(out/'ENCODING.actual.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
for p in [out/'ENCODING.actual.json',Path(__file__)]:
    b=p.read_bytes();print(json.dumps({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}))
print(json.dumps({k:result[k] for k in ['prefix_bytes_read','Windows_GetACP_actual','decoder']}))
