"""Observe the frozen synced head without changing the shared checkout."""
from pathlib import Path
import subprocess
import sys

base = Path('C:/workspace/ck3_lyd_runtime_20261004')
old_sha = 'f3a564b502b8a36f626b00efccf79f00d907f5ee'
sha = 'fde5fb0a03d24ba00b8a09ce0a52462a50882671'
old_output = 'r45-exact-f3a564b50-ci-20261010-001'
output = 'r45-exact-fde5fb0a0-ci-20261010-001'
targets = []
for operation in ('watch', 'complete'):
    original = base / f'r45-agent-{operation}-exact-f3a564b50-ci-20261010-001.py'
    target = base / f'r45-agent-{operation}-exact-fde5fb0a0-ci-20261010-001.py'
    source = original.read_text(encoding='utf-8')
    if source.count(old_sha) != 1 or source.count(old_output) != 1:
        raise RuntimeError('Observer no longer permits an unambiguous exact retarget')
    source = source.replace(old_sha, sha).replace(old_output, output)
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(source)
    targets.append(target)
for target in targets:
    result = subprocess.run([sys.executable, '-B', '-X', 'utf8', str(target)], cwd=base)
    if result.returncode:
        raise SystemExit(result.returncode)
