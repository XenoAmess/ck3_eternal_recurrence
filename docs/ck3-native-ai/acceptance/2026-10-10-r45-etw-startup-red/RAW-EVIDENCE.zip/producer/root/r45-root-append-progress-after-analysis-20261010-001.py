from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import json
import os
import sys

base = Path('C:/workspace/ck3_lyd_runtime_20261004')
root = Path('C:/workspace/ck3_eternal_recurrence')
analysis_path = Path(sys.argv[1])
analysis = json.loads(analysis_path.read_bytes())
if analysis['root_reported_game_identity']['pid'] != 16528 or not analysis['sample_event_count']:
    raise SystemExit('Actual R45 analysis identity or CPU sample count mismatch')
release_path = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0045/release-command-001/stdout.log')
release = json.loads(release_path.read_bytes())
if release['task']['state'] != 'done' or release['task']['resources'] != [] or release['task']['last_sequence'] != 4359:
    raise SystemExit('R45 release differs from actual reviewed closure')
identity = json.loads((base / 'r45-root-git-identity-correction-20261010-001/VERIFIED.actual.json').read_bytes())
if identity['email'] != 'xenoamess@gmail.com' or identity['name'] != 'XenoAmess':
    raise SystemExit('Identity correction not actually verified')
files = [root / name for name in (
    'docs/autonomous-agent-progress/daily/2026-10-10.md',
    'docs/autonomous-agent-progress/weekly/2026-W41.md',
    'docs/ck3-native-ai/2026-10-10-local-common-runtime-rebuild.md',
    'docs/li-yu-dao/2026-10-09-progress.md')]
report = root / 'docs/ck3-native-ai/2026-10-10-r45-etw-startup-red.md'
stamp = datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M CST')
heading = 'R45 实际 CPU 观察、缓存时间与提交身份纠正'
records = []
for path in files:
    raw = path.read_bytes()
    if heading.encode('utf-8') in raw:
        raise SystemExit('Append already exists: ' + str(path))
    link = os.path.relpath(report, path.parent).replace('\\', '/')
    block = f'''

## {stamp}：{heading}

R45 在精确 `fde5fb0a03d24ba00b8a09ce0a52462a50882671`、同一 Source05、正式71+overlay6、四份配置和固定 D2a seed 下运行，readiness仍900秒。公共run/verify均exit2，原host Popen1；未出现Setup completion，未注入，native语义帧/steps/业务选项/SAVE/day均0。独立句柄观测CK3 PID16528于03:48:44.263007Z退出1，elapsed904.963866秒；原cleanup_ok=false/session.report=null及原CreateProcess句柄、Job最终计数未知继续保留，不授normal0。ROOT实际进程/控制文件空、11:49新鲜Steam离线亲审、桌面恢复1024×768、原allocate/keeper0、CAS4358→4359实际DONE/resources[]。[本轮报告与原始证据]({link})。

本轮首次取得实际CK3 CPU trace：ETL1,103,101,952B，SHA `378766bd00d2a39065619b7dd45c3f3723e8c6d79f176fb13eec20dbc29c432e`；实际记录89.1057403秒、lost buffers/events均0。采样等待60秒与实际trace时长分列，own stop/save实际95.507秒；未终止其他trace、未改变游戏预算或发送游戏输入。五项离线导出及最终own status实际0，大ETL和文本保留在外置目录。第一次分析因无关FileVersion元数据含非UTF-8字节而解码失败，原失败保留；本机ACP936严格解码也失败，因此不猜全局编码，改为显示文字保留byte escapes、数值字段严格ASCII、SHA取原始bytes。003又遇到线程lifetime不匹配而中止，004保留原失败，将不匹配样本隔离UNKNOWN，只有匹配样本进入热点，原时序规则未放宽；本次不采集完整raw stack frame统计，官方stack导出仍保留。修正后实际分析取得{analysis['sample_event_count']}条时序匹配目标CPU sample事件，{analysis['threads_with_cpu_samples']}个线程有匹配样本；IP/模块/RVA由同PID、同时间Image区间匹配，未映射者保持未知。游戏本体、Windows内核和D3DCompiler均有实际活动；Weight、sample Count、官方stack hits分别记录，函数语义与加载根因仍UNKNOWN。

新一次只读shadercache元数据比较：R45为3523文件/135,508,874B，R44为3687/143,124,020B，复用R38既有清单为3740/146,942,067B。R45有804个现存文件birth/mtime落在600–900秒窗口，最晚892.7068074秒，最后一分钟109个；与R38有3511个同名同size文件，不能当正文一致或编译完成。它与实际编译器CPU活动共同说明超时前仍有缓存产出，不能证明唯一根因或把R38说成预热缓存启动。公共prepare/Source05尚无已支持的shadercache复用键，旧宣传入口不能借用为公共能力；后续只按共享层最小显式绑定评估，不能靠元数据改写旧失败或盲增预算。

用户指出此前提交署名异常后，实际读回本机repo-local `Codex <codex@openai.com>`，与9月10日已记载的 `XenoAmess <xenoamess@gmail.com>` 约定不符；ROOT此前未检查配置。是谁何时改变配置仍UNKNOWN。现场释放后03:49:45Z已实际恢复姓名、邮箱并读回，两项git ident也确认XenoAmess；既有公开提交未改写、未force push。原件在 `BASE/r45-root-git-identity-correction-20261010-001`，随本轮归档保全。后续提交使用正确身份并继续fetch/rebase/普通push。

冻结fde的Official38020302422、Linear38020302413实际SUCCESS，共享acceptance成功；LiYuNOT_TRIGGERED不计通过。并行完成实际ETW离线观察、缓存元数据、证据归档准备和身份纠正，未增加正式业务信用。I3b/C3/I4及一期仍NOT_GREEN，75%仅工作量估计；一期完成日期待恢复业务实机后的结果，不给无证据日期。
'''
    content = raw + block.encode('utf-8')
    records.append({'path': str(path), 'before_sha256': hashlib.sha256(raw).hexdigest(), 'after_sha256': hashlib.sha256(content).hexdigest(), 'content': content})
for row in records:
    Path(row['path']).write_bytes(row.pop('content'))
with (base / 'r45-root-progress-append-20261010-001.actual.json').open('x', encoding='utf-8') as stream:
    json.dump({'at_cst': stamp, 'analysis_path': str(analysis_path), 'records': records}, stream, indent=2)
print(json.dumps({'updated_files': [r['path'] for r in records], 'at_cst': stamp}))
