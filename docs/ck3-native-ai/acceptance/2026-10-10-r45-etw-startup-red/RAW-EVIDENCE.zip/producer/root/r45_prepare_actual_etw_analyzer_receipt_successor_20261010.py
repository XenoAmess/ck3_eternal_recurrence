from pathlib import Path
import ast,difflib,hashlib,json
base=Path('C:/workspace/ck3_lyd_runtime_20261004')
old=base/'r45-actual-etw-offline-analyzer-sourceonly-20261010-001'
out=base/'r45-actual-etw-offline-analyzer-sourceonly-20261010-002'
body=(old/'analyze_r45_exports.py').read_bytes()
assert hashlib.sha256(body).hexdigest()=='5da63c6e228c7f803f6e8ae7b13cd71867946d7b33d69990242fe446942a95ca'
before=body.decode('utf-8'); source=before
changes=[(
'''def file_refs(value):
    if isinstance(value, dict):
        if all(k in value for k in ("path", "bytes", "sha256")):
            yield value
        for child in value.values():
            yield from file_refs(child)
    elif isinstance(value, list):
        for child in value:
            yield from file_refs(child)
''',
'''def command_receipts(value):
    if isinstance(value, dict):
        if isinstance(value.get("argv"), list) and "returncode" in value:
            yield value
        for child in value.values():
            yield from command_receipts(child)
    elif isinstance(value, list):
        for child in value:
            yield from command_receipts(child)
'''),(
'''    small, pins, receipts, refs = {}, {}, [], []
''',
'''    small, pins, receipts, commands = {}, {}, [], []
'''),(
'''        receipts.append(pin); refs.extend(file_refs(json.loads(text)))
    # ROOT already hashes its large dumper export. Match that actual receipt; do not rehash CSV or ETL.
    dumper_refs = [r for r in refs if Path(r["path"]).resolve() == paths["dumper"]]
    if not dumper_refs or any(r["bytes"] != paths["dumper"].stat().st_size or not re.fullmatch(r"[0-9a-fA-F]{64}",r["sha256"]) for r in dumper_refs):
        raise ValueError("Missing/mismatched ROOT actual dumper bytes/SHA receipt")
    if len({(r["bytes"], r["sha256"].lower()) for r in dumper_refs}) != 1: raise ValueError("Conflicting dumper receipts")
    pins["dumper"] = dumper_refs[0]
''',
'''        receipts.append(pin); commands.extend(command_receipts(json.loads(text)))
    # Actual ROOT command receipts pin stdout/stderr, not the output CSV. Authenticate
    # the successful exact producer argv, then hash the CSV during its only read pass.
    dumper_commands = []
    for command in commands:
        argv = command["argv"]
        if command["returncode"] != 0 or not all(isinstance(a,str) for a in argv): continue
        if not argv or Path(argv[0]).name.lower() != "xperf.exe": continue
        try:
            output = Path(argv[argv.index("-o")+1]).resolve()
            trace = Path(argv[argv.index("-i")+1]).resolve()
            action = argv[argv.index("-a")+1]
        except (ValueError,IndexError): continue
        if output == paths["dumper"] and action == "dumper" and trace.is_relative_to(root):
            dumper_commands.append(command)
    if not dumper_commands: raise ValueError("Missing successful ROOT xperf dumper command with exact output path")
    dumper_stat_before = paths["dumper"].stat()
    dumper_hasher = hashlib.sha256(); dumper_bytes = 0
'''),(
'''    with paths["dumper"].open("r", encoding="utf-8-sig", errors="strict") as f:
        for n, line in enumerate(f,1):
            stripped = line.lstrip()
''',
'''    with paths["dumper"].open("rb") as f:
        for n, raw_line in enumerate(f,1):
            dumper_hasher.update(raw_line); dumper_bytes += len(raw_line)
            line = raw_line.decode("utf-8-sig" if n == 1 else "utf-8", errors="strict")
            stripped = line.lstrip()
'''),(
'''    if not sample_events or "SampledProfile" not in headers: raise ValueError("No actual target CPU samples or header")
''',
'''    dumper_stat_after = paths["dumper"].stat()
    if dumper_bytes != dumper_stat_before.st_size or (dumper_stat_before.st_size,dumper_stat_before.st_mtime_ns) != (dumper_stat_after.st_size,dumper_stat_after.st_mtime_ns):
        raise ValueError("Dumper export changed or was truncated during the single analysis pass")
    pins["dumper"] = {"path":str(paths["dumper"]),"bytes":dumper_bytes,"sha256":dumper_hasher.hexdigest(),
        "hash_origin":"first honest output pin, computed during the same one-pass binary analysis"}
    if not sample_events or "SampledProfile" not in headers: raise ValueError("No actual target CPU samples or header")
'''),(
'''        "new_trace_wpr_exports":False,"etl_opened_or_rehashed":False,"dumper_rehashed":False,
''',
'''        "new_trace_wpr_exports":False,"etl_opened_or_rehashed":False,"dumper_rehashed":False,
        "dumper_hash_computed_during_single_pass":True,"dumper_hash_passes":1,"actual_dumper_command_provenance":dumper_commands,
'''),(
'''"large_dumper_ref_without_second_hash":pins["dumper"]''',
'''"large_dumper_first_pin_from_single_analysis_pass":pins["dumper"]'''),(
'''help="ROOT actual export receipt(s) containing dumper path/bytes/SHA"''',
'''help="ROOT actual export command receipt(s): returncode0 and exact xperf dumper argv"''')]
for previous,replacement in changes:
    assert source.count(previous)==1,previous[:100]
    source=source.replace(previous,replacement)
ast.parse(source,filename='analyze_r45_exports.py')
out.mkdir()
(out/'analyze_r45_exports.py').write_text(source,encoding='utf-8',newline='\n')
(out/'001-to-002.incremental.patch').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),source.splitlines(keepends=True),fromfile='source001/analyze_r45_exports.py',tofile='source002/analyze_r45_exports.py')),encoding='utf-8',newline='\n')
template=json.loads((old/'COMMAND.template.json').read_text(encoding='utf-8'))
template['argv'][4]=str(out/'analyze_r45_exports.py')
template['argv'][template['argv'].index('--receipt')+1]='<actual-009-dumper-RESULT.actual.json>'
template['mandatory_late_inputs']=['five completed actual R45 text exports','ROOT actual successful dumper command receipt with exact output argv']
template['dumper_hash_policy']='First SHA/bytes computed while reading the binary CSV once for analysis; no second hash pass.'
(out/'COMMAND.template.json').write_text(json.dumps(template,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
readme='''# R45 离线分析器 002：适配实际 command receipt

001 原件保留。ROOT 已明确实际 helper 只在 command RESULT 中记录 argv/returncode/stdout/stderr；没有预存 dumper output SHA。002 仅修这一输入合同：--receipt 消费实际 009-dumper/RESULT.actual.json，核 returncode0、xperf -i 位于本轮 ETW root、-o 精确等于传入 CSV、-a dumper。

同一次 rb 逐行分析同步 SHA256.update(raw_line) 与 byte count，真实生成第一份 dumper output pin；不声称存在旧 pin，不第二次读/哈希 CSV，也不打开 ETL。小导出在其初次读取时生成实际 pin。读取前后 size/mtime 和流式 bytes 不一致则拒绝混用未完成输出。

PID16528/create1791603219.1009781/FILETIME134360768191009782/fde5fb0a 固定；MIN/MAX、同采样时刻 image interval、modules/IP/RVA/threads/loss 以及计数分列逻辑保持。AST parse0；按 ROOT 指令不重复 help/tests。不曾消费 actual exports，等待 ROOT final-ready。
'''
(out/'README.zh.md').write_text(readme,encoding='utf-8',newline='\n')
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
index={'schema':'lyd.r45.actual-etw-analyzer-sourceonly-index.v2','previous_source_index':pin(old/'SOURCE-INDEX.json'),
 'files':[pin(out/n) for n in ['analyze_r45_exports.py','001-to-002.incremental.patch','COMMAND.template.json','README.zh.md']],
 'source_author':pin(Path(__file__)),'syntax_ast_parse':True,'help_or_tests_repeated':False,'actual_exports_consumed':False,'actual_results':None}
(out/'SOURCE-INDEX.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
for name in ['analyze_r45_exports.py','SOURCE-INDEX.json','001-to-002.incremental.patch']:print(json.dumps(pin(out/name)))
