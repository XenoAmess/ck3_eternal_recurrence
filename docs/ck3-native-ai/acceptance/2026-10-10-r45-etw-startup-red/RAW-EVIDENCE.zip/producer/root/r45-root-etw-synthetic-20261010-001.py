from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math
import subprocess
import sys
import time

base=Path('C:/workspace/ck3_lyd_runtime_20261004')
out=base/'r45-root-etw-synthetic-20261010-001'
out.mkdir(exist_ok=False)
wpr=Path('C:/Program Files (x86)/Windows Kits/10/Windows Performance Toolkit/wpr.exe')
xperf=wpr.with_name('xperf.exe')
instance='xar-lyd-cpu-synthetic-20261010-001'
records=[]
def utc():return datetime.now(timezone.utc).isoformat()
def pin(path):
    raw=path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def record(label,argv):
    directory=out/label;directory.mkdir()
    started=utc()
    with (directory/'stdout.bin').open('xb') as stdout,(directory/'stderr.bin').open('xb') as stderr:
        process=subprocess.Popen([str(v) for v in argv],stdout=stdout,stderr=stderr)
        code=process.wait()
    result={'argv':[str(v) for v in argv],'pid':process.pid,'started_at_utc':started,'finished_at_utc':utc(),'returncode':code,
        'stdout':pin(directory/'stdout.bin'),'stderr':pin(directory/'stderr.bin')}
    (directory/'RESULT.actual.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    records.append(result)
    return result
status=record('001-status-own',[wpr,'-status','-instancename',instance])
if status['returncode']!=0 or b'WPR is not recording' not in (out/'001-status-own/stdout.bin').read_bytes():
    raise RuntimeError('Own instance status not confirmed idle; no recording started')
temp=out/'temp';temp.mkdir()
start=record('002-start',[wpr,'-start','CPU.Verbose','-filemode','-recordtempto',temp,'-instancename',instance])
if start['returncode']!=0:raise RuntimeError('Start failed; other trace owners untouched')
child=out/'synthetic_busy.py'
child.write_text('import hashlib,json,os,time\nstart=time.monotonic();count=0;raw=b"synthetic-only-cpu"*4096\nwhile time.monotonic()-start<10:\n hashlib.sha256(raw).digest();count+=1\nprint(json.dumps({"pid":os.getpid(),"elapsed":time.monotonic()-start,"iterations":count,"synthetic_only":True}))\n',encoding='utf-8')
try:
    busy=record('003-busy',[sys.executable,'-B','-X','utf8',child])
finally:
    stopped=record('004-stop-own',[wpr,'-stop',out/'cpu.etl','Synthetic CPU sampling validation','-skipPdbGen','-instancename',instance])
if stopped['returncode']!=0:raise RuntimeError('Own trace stop failed; retained all temporary output')
for label,action,extra in [('005-profile','profile',['-detail']),('006-process','process',['-thread','-image']),('007-tracestats','tracestats',[])]:
    result=record(label,[xperf,'-i',out/'cpu.etl','-o',out/(action+'.txt'),'-a',action,*extra])
    if result['returncode']!=0:raise RuntimeError('Offline export failed: '+label)
final=record('008-status-own',[wpr,'-status','-instancename',instance])
summary={'schema':'lyd.synthetic-cpu-trace-actual.v1','instance':instance,'synthetic_pid':busy['pid'],'busy_returncode':busy['returncode'],
    'etl':pin(out/'cpu.etl'),'source':pin(Path(__file__)),'child_source':pin(child),'records':records,'final_status_returncode':final['returncode'],
    'game_started':False,'game_input_sent':False,'other_trace_cancelled':False,'symbols_requested':False,'semantic_or_business_credit':False}
(out/'SUMMARY.actual.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'out':str(out),'synthetic_pid':busy['pid'],'etl':summary['etl'],'busy_returncode':busy['returncode']}))
