from pathlib import Path
from datetime import datetime, timezone
import json
import psutil

out = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0045/etw-cpu-001')
files = [{'path': str(p.relative_to(out)), 'bytes': p.stat().st_size} for p in out.rglob('*') if p.is_file()]
tools = []
for process in psutil.process_iter(['pid', 'name', 'cmdline', 'create_time']):
    try:
        if (process.info.get('name') or '').lower() in ('wpr.exe', 'xperf.exe'):
            tools.append(process.info)
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        pass
print(json.dumps({'at_utc': datetime.now(timezone.utc).isoformat(), 'files': files, 'diagnostic_processes': tools}, indent=2))
