from pathlib import Path
import hashlib, json, subprocess, time

OUT = Path('C:/workspace/ck3_lyd_runtime_20261004/r45-etw-cpu-observation-preparation-20261010-001')
XPERF = 'C:/Program Files (x86)/Windows Kits/10/Windows Performance Toolkit/xperf.exe'
def pin(p):
    b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
receipts=[]
for name, argv in [
    ('0019-xperf-active-loggers', [XPERF, '-Loggers']),
    ('0020-xperf-help-offline-actions', [XPERF, '-help', 'profile', 'process', 'stack', 'dumper', 'tracestats']),
]:
    d=OUT/name; d.mkdir()
    started=time.time_ns()
    p=subprocess.run(argv,capture_output=True,timeout=30)
    (d/'stdout.bin').write_bytes(p.stdout); (d/'stderr.bin').write_bytes(p.stderr)
    r={'argv':argv,'started_at_unix_ns':started,'returncode':p.returncode,'stdout':pin(d/'stdout.bin'),'stderr':pin(d/'stderr.bin'),'read_only':True}
    (d/'RESULT.actual.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
    receipts.append(r)
    print(name,p.returncode)
    print((p.stdout+p.stderr).decode('utf-8',errors='replace'))
(OUT/'LOGGERS-EXPORT-HELP.actual.json').write_text(json.dumps({'source':pin(Path(__file__)),'receipts':receipts},indent=2)+'\n',encoding='utf-8')
