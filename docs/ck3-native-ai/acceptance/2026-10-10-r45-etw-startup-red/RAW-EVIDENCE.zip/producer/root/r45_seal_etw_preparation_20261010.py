from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

OUT=Path('C:/workspace/ck3_lyd_runtime_20261004/r45-etw-cpu-observation-preparation-20261010-001')
BASE=OUT.parent
WPR='C:/Program Files (x86)/Windows Kits/10/Windows Performance Toolkit/wpr.exe'
XPERF='C:/Program Files (x86)/Windows Kits/10/Windows Performance Toolkit/xperf.exe'
def pin(p):
    b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def new(name, value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,ensure_ascii=False,indent=2); f.write('\n')

summary=json.loads((OUT/'LOGGER-SUMMARY.actual.json').read_text(encoding='utf-8'))
system=[r for r in summary['loggers'] if r['system_logger']]
interpretation={
    'schema':'lyd.r45.etw-session-readonly-interpretation.v1',
    'sequential_wpr_status':pin(OUT/'0013-kit-wpr-status-sequential/RESULT.actual.json'),
    'wpr_recording_observed':False,
    'active_etw_session_count':summary['active_count'],
    'no_wpr_named_session_observed':not summary['wpr_named_sessions'],
    'system_loggers':system,
    'system_profile_flag_observed':any('PROFILE' in r['system_trace_flags'].split('+') for r in system),
    'all_etw_owners_identified':False,
    'existing_sessions_changed':False,
    'lexical_note':'The earlier generic text scan finds PROFILE inside the NetCore provider name Microsoft-Windows-NetworkProfile; that is not a CPU PROFILE system flag.',
    'initial_duplicate_instance_error':'Read-only WPR commands overlapped and returned 0xc5580601. Original receipts preserved; sequential status/profiles then exited 0.',
}
new('SESSION-INTERPRETATION.actual.json',interpretation)

def commands(temp,etl,instance,stem,pid):
    return {
        'pre_status_argv':[WPR,'-status'],
        'pre_loggers_argv':[XPERF,'-Loggers'],
        'start_argv':[WPR,'-start','CPU.Verbose','-filemode','-recordtempto',temp,'-instancename',instance],
        'stop_argv':[WPR,'-stop',etl,'Bounded CPU sampling','-skipPdbGen','-instancename',instance],
        'post_status_argv':[WPR,'-status','-instancename',instance],
        'post_loggers_argv':[XPERF,'-Loggers'],
        'offline_profile_argv':[XPERF,'-i',etl,'-o',stem+'-profile.csv','-a','profile','-detail'],
        'offline_process_argv':[XPERF,'-i',etl,'-o',stem+'-process.csv','-a','process','-thread','-image'],
        'offline_stacks_argv':[XPERF,'-i',etl,'-o',stem+'-stacks.csv','-a','stack','-pid',pid,'-butterfly','1'],
        'offline_dump_argv':[XPERF,'-i',etl,'-o',stem+'-events.csv','-a','dumper','-stacktimeshifting','-add_rawdata'],
        'offline_tracestats_argv':[XPERF,'-i',etl,'-o',stem+'-tracestats.txt','-a','tracestats'],
    }
synthetic_root='C:/workspace/ck3_lyd_runtime_20261004/r45-root-etw-synthetic-20261010-001'
plan={
    'schema':'lyd.r45.bounded-cpu-sampling-plan.source-only.v1',
    'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
    'executed':False,
    'profile':'CPU.Verbose.File',
    'profile_evidence':pin(OUT/'0015-kit-wpr-cpu-profiledetails/RESULT.actual.json'),
    'tools':json.loads((OUT/'READONLY-COMMANDS.actual.json').read_text(encoding='utf-8'))['tools'],
    'session_observation':pin(OUT/'SESSION-INTERPRETATION.actual.json'),
    'synthetic':{
        'root_execute_only':True,'duration_seconds':10,
        'output_directory_to_create_fresh':synthetic_root,
        'temp_directory_to_create_fresh':synthetic_root+'/temp',
        'target_pid':None,'actual_result':None,
        'argv_templates':commands(synthetic_root+'/temp',synthetic_root+'/cpu.etl','lyd-r45-synthetic-cpu-20261010-001',synthetic_root+'/cpu','<actual-synthetic-pid>'),
    },
    'future_game':{
        'root_execute_only':True,'game_budget_seconds':900,
        'start_at_existing_loading_elapsed_seconds':600,'duration_seconds':60,
        'pid':None,'create_time':None,'module_identity':None,'output_directory':None,'instance_name':None,'actual_result':None,
        'argv_templates':commands('<fresh-temp-directory>','<fresh-cpu.etl>','<unique-r45-instance>','<fresh-offline-prefix>','<actual-ck3-pid>'),
    },
    'execution_notes':[
        'All WPR commands sequential. Instance name is the last argument and is identical for start/stop/status of our session.',
        'Re-read status/loggers immediately before ROOT starts. Existing 25-session observation is historical. Do not cancel, stop, modify or take over any existing owner.',
        'Only stop our instance after its actual start returns success. If start fails, preserve failure; do not issue generic stop/cancel.',
        'Built-in profile samples the whole machine. Filter offline by actual PID/create-time/time interval and preserve module load address/path/size.',
        'No -symbols is requested. CLI guarantees process/module bucket output without symbols. Raw dump/stack address presence and useful ck3 samples must be established by the actual synthetic/real receipt.',
        'Use loader image range at the sample timestamp: RVA = instruction_pointer - module_load_base, only when inside that module range. Function names remain UNKNOWN without an exact matching symbol or bounded disassembly mapping.',
        'Record start/stop return codes, raw stdout/stderr, ETL hash/bytes, elapsed time, trace stats/lost events, sample count and target PID. Valid help/token do not prove successful sampling.',
        'No CK3 injection, SuspendThread, game signal, profile edit, Steam change or extension of the 900-second game budget.',
    ],
    'current_task_trace_actions_attempted':False,
}
new('PLAN.source-only.json',plan)
report='''# R45 ETW CPU 采样准备（只读）

Kit WPR/xperf 均为 10.0.26100；本轮未启动、停止或取消 trace。顺序 WPR status/profiles/profiledetails 全部 exit 0，status 为 `WPR is not recording`。初次并发只读 WPR 的 `0xc5580601` 原件保留，不视作别人正在录制。

xperf `-Loggers` exit 0，共 25 个既有会话，未见 WPR 命名会话。两个 SystemLogger 的 flags 分别是 `LOADER+HARD_FAULTS+DPC+INTERRUPT`、`PROC_THREAD+LOADER`，未见系统 CPU `PROFILE`。不能写成全机没有 trace，也未逐个认定其 owner；全部保持不动。

当前 token elevated=true/Default，SeSystemProfilePrivilege 与 SeDebugPrivilege 均 present/disabled。本轮没有调整 privilege。CPU.Verbose.File 实际含 Loader、ProcessThread、SampledProfile，及 SampledProfile/CSwitch/ReadyThread stacks。唯一 instance 参数必须最后；本机 help 明示后续 session 命令应沿用同名 instance。

`PLAN.source-only.json` 给出精确 argv 数组。ROOT 先以 fresh 外置目录进行 10 秒 synthetic；成功采集后，R45 仍为 900 秒总预算，仅在既有加载计时 600 秒后采 60 秒。start/stop 只控制本轮唯一 instance，不使用 generic stop/cancel。实际 PID、create time、加载模块身份与 R45 产物仍 NULL。

离线命令均来自本机 help：profile -detail 在未启用 symbols 时按 process/module 统计；process -thread -image；stack -pid 实际PID -butterfly 1；dumper -stacktimeshifting -add_rawdata；tracestats。不需要 PDB 才能保全 IP/模块基址并按有效模块区间计算 RVA=IP-base；实际 CSV 字段、目标样本/栈是否充分须由 synthetic/实采回执确认，当前不授成功采样或引擎根因信用。

未注入、未 suspend/signal 游戏、未改 profile/budget/系统设置/MAIN。权限与 CLI 帮助仅说明已有施工入口，成功与开销由 ROOT 的实际短测验证。
'''
with (OUT/'REPORT.zh.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)

sources=[BASE/name for name in [
    'r45_read_etw_help_status_token_20261010.py',
    'r45_read_etw_help_details_20261010.py',
    'r45_read_etw_sequential_details_20261010.py',
    'r45_read_etw_loggers_export_help_20261010.py',
    'r45_summarize_etw_loggers_20261010.py',
    'r45_seal_etw_preparation_20261010.py',
]]
new('INDEX.json',{'schema':'lyd.r45.etw-readonly-preparation-index.v1','current_task_trace_actions_attempted':False,
    'files':[pin(p) for p in sorted(OUT.rglob('*')) if p.is_file()],
    'source_authors':[pin(p) for p in sources],
    'future_actual_trace_result':None})
for name in ['PLAN.source-only.json','REPORT.zh.md','SESSION-INTERPRETATION.actual.json','INDEX.json']:
    print(json.dumps(pin(OUT/name),ensure_ascii=False))
