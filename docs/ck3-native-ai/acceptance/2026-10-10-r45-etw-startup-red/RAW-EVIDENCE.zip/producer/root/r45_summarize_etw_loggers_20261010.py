from pathlib import Path
import json, re, hashlib
out=Path('C:/workspace/ck3_lyd_runtime_20261004/r45-etw-cpu-observation-preparation-20261010-001')
p=out/'0019-xperf-active-loggers/stdout.bin'
b=p.read_bytes()
s=b.decode('utf-8',errors='replace').replace('\r','')
rows=[]
for chunk in s.split('Logger Name'):
    if not chunk.strip(): continue
    lines=chunk.splitlines()
    name=lines[0].split(':',1)[1].strip()
    fields={}
    for line in lines[1:]:
        if ':' in line:
            key,value=line.split(':',1); fields[key.strip()]=value.strip()
    flags=fields.get('Trace Flags','')
    row={'name':name,'id':fields.get('Logger Id'),'mode':fields.get('Log File Mode'),'filename':fields.get('Log Filename'),
         'profile_flag_text_present': bool(re.search(r'\bPROFILE\b|SampledProfile',flags,re.I)),
         'system_logger': 'SystemLogger' in fields.get('Log File Mode','')}
    if row['system_logger']: row['system_trace_flags']=flags
    rows.append(row)
r={'raw':{'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'active_count':len(rows),'loggers':rows,
   'wpr_named_sessions':[r['name'] for r in rows if 'wpr' in r['name'].lower()],
   'profile_flag_text_sessions':[r['name'] for r in rows if r['profile_flag_text_present']],
   'note':'Names/flags are query observations. Existing sessions remain active and untouched; this does not prove every session owner identity.'}
(out/'LOGGER-SUMMARY.actual.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print(json.dumps(r,indent=2))
