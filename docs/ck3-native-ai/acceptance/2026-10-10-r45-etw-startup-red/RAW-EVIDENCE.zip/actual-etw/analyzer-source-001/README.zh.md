# R45 离线分析器（仅源码准备）

固定 ROOT 本轮 PID16528/create1791603219.1009781/FILETIME134360768191009782/sourceHEADfde5fb0a03d24ba00b8a09ce0a52462a50882671。ROOT 报告的创建身份与 ETL 的 process/thread/image 核对分列，不把 MIN 时间映射成新进程出生时间。

入口为 analyze_r45_exports.py，完整参数见 COMMAND.template.json。只读五份已完成导出，严格限制为 R0045/etw-cpu-001 内文件；必须由 ROOT 原实际回执提供 dumper path/bytes/SHA。CSV 只做一次流式分析，不重算其哈希，不打开/重算 ETL，也不运行 xperf/WPR/任何外部命令。

复用 synthetic 已实证的 SampledProfile.PrgrmCtr、Stack.Address 和 Image BaseAddr/EndAddr 合同；新增当前游戏必要的 MIN/MAX、同PID线程时间边界、重复相同 image interval 处理。按实际采样时间及有效模块区间计算 RVA，未匹配为 UNMAPPED；模块加载冲突拒绝。目标线程总数、出现 CPU 样本的线程及全部线程采样量分列，官方 profile Weight、SampledProfile 行数/Count、官方 stack hits 分列，loss 字段缺失保持 UNKNOWN。提取前三个真正随 target sample 的原始栈，缺失不伪造。

将生成 ANALYSIS.actual.json、HOTSPOTS.csv、THREADS.csv、REPORT.zh.md、INDEX.json。源码 CLI help 已实际 exit0，最终源码 AST parse0；当前没有读取 R45 导出或执行分析。等待 ROOT 的 final-exports-ready 信号；实际热点、loss、函数含义与原因均未获信用。synthetic 地址不会写入 actual 结果。
