# R45 实际 ETW 单次离线分析补充

绑定 CK3 PID16528。实际分析 exit0，SampledProfile 439548 行，Count 合计 439548。
线程身份 125 个，出现 CPU 样本 51 个；丢失状态 ZERO。

dumper 原始字节 SHA 在同一完整流式分析中首次生成，未另读或重 hash 大文件。初次 UTF-8 解码失败及 ACP936 严格解码失败原件保留；非 ASCII 信息字节显式转义，数字/IP 字段仍严格解析。

官方 profile 的 Usage% 使用系统分母，不代表 CK3 内部模块占比。样本 Count、官方 Weight、附带栈样本分列。ETL 时长和起止以 trace_stats_raw 原始行及 ROOT 回执为准，不能把等待60秒写成 trace60秒。

模块 Count 热点：

- ck3.exe: 184762
- ntoskrnl.exe: 106155
- D3DCompiler_47.dll: 80542
- ntdll.dll: 31021
- nvwgf2umx.dll: 10022
- ucrtbase.dll: 9741
- Ntfs.sys: 3395
- KernelBase.dll: 3238
- nvlddmkm.sys: 1653
- fmod.dll: 1480

线程 Count 热点：

- TID 14784: 87709；线程角色 UNKNOWN
- TID 13000: 86476；线程角色 UNKNOWN
- TID 9952: 78829；线程角色 UNKNOWN
- TID 17388: 47193；线程角色 UNKNOWN
- TID 2632: 23040；线程角色 UNKNOWN
- TID 11312: 23024；线程角色 UNKNOWN
- TID 11984: 16640；线程角色 UNKNOWN
- TID 16276: 16586；线程角色 UNKNOWN
- TID 6840: 16473；线程角色 UNKNOWN
- TID 15176: 6858；线程角色 UNKNOWN

模块/IP/RVA 可用于后续有限地址映射；函数语义和加载因果仍 UNKNOWN。观测期间存在 shader compiler CPU 样本不能单独证明其造成900秒失败；采样与保存开销可能影响运行。业务仍 NOT_GREEN。
