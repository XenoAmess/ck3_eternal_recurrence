# R45 实际 ETW 离线观察

实际 PID 16528；125 个线程记录身份，51 个线程出现 CPU 样本。
SampledProfile 439548 行，Count 合计 439548；loss 状态 ZERO。

未匹配线程生命周期的目标样本 2 行（Count 2）单列 UNKNOWN，不进入热点。

样本量与官方 profile Weight 分列。模块/IP/RVA 均由实际导出匹配；无匹配区间保持 UNMAPPED。未解析函数语义，热点不单独证明加载原因。原始 Stack 正文未逐行解析，附带栈覆盖率 UNKNOWN；官方 stack.txt 统计独立保留。

模块热点：
- ck3.exe: 184762 samples
- ntoskrnl.exe: 106155 samples
- D3DCompiler_47.dll: 80542 samples
- ntdll.dll: 31021 samples
- nvwgf2umx.dll: 10022 samples
- ucrtbase.dll: 9741 samples
- Ntfs.sys: 3395 samples
- KernelBase.dll: 3238 samples
- nvlddmkm.sys: 1653 samples
- fmod.dll: 1480 samples

线程热点：
- TID 14784: 87709 samples；角色 UNKNOWN
- TID 13000: 86476 samples；角色 UNKNOWN
- TID 9952: 78829 samples；角色 UNKNOWN
- TID 17388: 47193 samples；角色 UNKNOWN
- TID 2632: 23040 samples；角色 UNKNOWN
- TID 11312: 23024 samples；角色 UNKNOWN
- TID 11984: 16640 samples；角色 UNKNOWN
- TID 16276: 16586 samples；角色 UNKNOWN
- TID 6840: 16473 samples；角色 UNKNOWN
- TID 15176: 6858 samples；角色 UNKNOWN
