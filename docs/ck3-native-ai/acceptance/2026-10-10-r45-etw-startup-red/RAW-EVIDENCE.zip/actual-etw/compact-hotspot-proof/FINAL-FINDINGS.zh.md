# R45 实际热点结论与边界

实际 CK3 PID16528 的已完成 CPU 样本分析可用于定位下一有限地址读取。此观察不能单独确定加载原因，也不能证明主线程死锁。

实际 trace89.1057403秒，丢失 buffers/events 均0；目标线程身份125个，51个有匹配 CPU 样本。匹配 SampledProfile 439548 行，另有 2 行（Count 2）因线程生命周期未闭合单列 UNKNOWN，未进入热点。

模块 Count：ck3.exe184762、ntoskrnl.exe106155、D3DCompiler_47.dll80542、ntdll.dll31021。官方 profile Weight 分别180047545、103658432、78494096、30244829，Usage%使用系统分母。Count与Weight不作相同单位解释。

ck3.exe image base0x7ff612670000，最热RVA0x3f91ed9有59290样本、0x3f91f8f有49837样本。二者是本次实际地址；函数语义 UNKNOWN，可供下一步围绕同一有限地址簇静态映射。

前三线程：

- TID14784: 87709匹配样本；角色UNKNOWN。
  - ck3.exe IP0x7ff616601ed9 / RVA0x3f91ed9：29432。
  - ck3.exe IP0x7ff616601f8f / RVA0x3f91f8f：24883。
  - ntoskrnl.exe IP0xfffff8042e62083f / RVA0x22083f：1561。
- TID13000: 86476匹配样本；角色UNKNOWN。
  - ntoskrnl.exe IP0xfffff8042e812565 / RVA0x412565：31494。
  - ntdll.dll IP0x7ffd9666de74 / RVA0x9de74：19526。
  - ntoskrnl.exe IP0xfffff8042e7254f4 / RVA0x3254f4：2378。
- TID9952: 78829匹配样本；角色UNKNOWN。
  - ck3.exe IP0x7ff616601ed9 / RVA0x3f91ed9：18131。
  - ck3.exe IP0x7ff616601f8f / RVA0x3f91f8f：15112。
  - ntoskrnl.exe IP0xfffff8042e62083f / RVA0x22083f：1419。

D3DCompiler 的实际 CPU 样本与同时期 shadercache mtime 只能作为并存活动证据，不能据此断言加载阻塞原因或未来缓存复用必然成功。采样/保存开销可能影响活动。

原始 Stack 正文在004明确未逐行解析，attached-stack覆盖率为NULL/UNKNOWN。官方 stack.txt 已被独立读取/绑定，不能把其表格锚点ID当IP，也不能称取得完整用户栈。初次编码RED及第二次线程生命周期RED全部保留。dumper 10098403170字节/SHA a3ce7977583cdcf0793aa4e2724d83842b91ad1162164b82020d7e2ee9ab58a7 来自004首次完整单pass；本补充不再读取或hash大文件。
