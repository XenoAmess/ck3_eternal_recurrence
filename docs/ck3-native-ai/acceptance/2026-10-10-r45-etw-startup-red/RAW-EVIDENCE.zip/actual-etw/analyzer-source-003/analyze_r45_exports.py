"""File-only analysis of ROOT's final R45 xperf exports; never starts tools/traces."""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import time

PID = 16528
GAME_IDENTITY = {"pid": PID, "create_time": 1791603219.1009781,
                 "filetime": 134360768191009782,
                 "source_head": "fde5fb0a03d24ba00b8a09ce0a52462a50882671",
                 "identity_source": "ROOT actual R45 task binding; creation time is not inferred from ETL"}
EXPORT_ROOT = Path("C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0045/etw-cpu-001")
PID_RE = re.compile(r"^(.*?)\s*\(\s*(\d+)\)$")

def pin_bytes(path, body):
    return {"path": str(path), "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}

def read_small(path):
    b = path.read_bytes()
    return b.decode("utf-8-sig", errors="strict"), pin_bytes(path, b)

def process_id(text):
    m = PID_RE.fullmatch(text.strip())
    return (m.group(1).strip(), int(m.group(2))) if m else (None, None)

def bound(text):
    return None if text in ("MIN", "MAX") else int(text)

def inside_time(ts, row):
    return (row["start_us"] is None or row["start_us"] <= ts) and (row["end_us"] is None or ts <= row["end_us"])

def csv_row(line):
    return [s.strip() for s in next(csv.reader([line], skipinitialspace=True))]

def command_receipts(value):
    if isinstance(value, dict):
        if isinstance(value.get("argv"), list) and "returncode" in value:
            yield value
        for child in value.values():
            yield from command_receipts(child)
    elif isinstance(value, list):
        for child in value:
            yield from command_receipts(child)

class Tables(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows, self.row, self.cell = [], None, None
    def handle_starttag(self, tag, attrs):
        if tag == "tr": self.row = []
        elif tag == "td" and self.row is not None: self.cell = []
    def handle_data(self, data):
        if self.cell is not None: self.cell.append(data)
    def handle_endtag(self, tag):
        if tag == "td" and self.cell is not None:
            self.row.append(" ".join("".join(self.cell).split())); self.cell = None
        elif tag == "tr" and self.row is not None:
            self.rows.append(self.row); self.row = None

def parse_process(text):
    processes, threads, images = [], {}, []
    for n, line in enumerate(text.splitlines(), 1):
        row = csv_row(line)
        if len(row) < 6 or row[0] == "Start Time": continue
        name, pid = process_id(row[4])
        if pid not in (PID, 0, 4): continue
        rec = {"start_us": bound(row[0]), "end_us": bound(row[1]), "start_raw": row[0], "end_raw": row[1],
               "source_line_number": n, "raw_line": line}
        if pid == PID and name.lower() != "ck3.exe": raise ValueError("R45 PID is not ck3.exe in process export")
        if row[2] == "Process" and pid == PID:
            rec.update(parent_pid=int(row[5]), unique_key=row[7] if len(row) > 7 else None); processes.append(rec)
        elif row[2] == "Thread" and pid == PID:
            rec.update(tid=int(row[5]), start_address=row[11] if len(row) > 11 else None)
            threads.setdefault(rec["tid"], []).append(rec)
        elif row[2] == "Image" and (pid == PID or int(row[5], 16) >= (1 << 63)):
            rec.update(pid=pid, module=row[10], base=int(row[5],16), end=int(row[6],16),
                       checksum=row[7], timedatestamp=row[8], version=row[11] if len(row) > 11 else None)
            if rec["base"] >= rec["end"]: raise ValueError("Invalid image interval")
            images.append(rec)
    if not processes or not threads or not any(i["pid"] == PID and i["module"].lower() == "ck3.exe" for i in images):
        raise ValueError("Missing strict R45 ck3.exe process/thread/image rows")
    if len({p["unique_key"] for p in processes}) != 1:
        raise ValueError("Reused or ambiguous PID in process export")
    pages = defaultdict(list)
    for image in images:
        for page in range(image["base"] >> 16, ((image["end"] - 1) >> 16) + 1): pages[page].append(image)
    def resolve(ip, ts):
        found = [i for i in pages.get(ip >> 16, ()) if i["base"] <= ip < i["end"] and inside_time(ts, i)]
        identities = {(i["module"], i["base"], i["end"], i["checksum"], i["timedatestamp"]) for i in found}
        if len(identities) > 1: raise ValueError(f"Ambiguous image interval for IP {ip:#x}, timestamp {ts}")
        return found[0] if found else None
    return processes, threads, images, resolve

def analyze(args):
    tick = time.monotonic()
    paths = {k: Path(getattr(args,k)).resolve(strict=True) for k in ("profile", "process", "stack", "dumper", "tracestats")}
    root = EXPORT_ROOT.resolve(strict=True)
    for path in paths.values():
        if not path.is_relative_to(root): raise ValueError(f"Input is outside exact R45 export root: {path}")
    small, pins, receipts, commands = {}, {}, [], []
    for key in ("profile", "process", "stack", "tracestats"):
        small[key], pins[key] = read_small(paths[key])
    for item in args.receipt:
        path = Path(item).resolve(strict=True); text, pin = read_small(path)
        receipts.append(pin); commands.extend(command_receipts(json.loads(text)))
    # Actual ROOT command receipts pin stdout/stderr, not the output CSV. Authenticate
    # the successful exact producer argv, then hash the CSV during its only read pass.
    dumper_commands = []
    for command in commands:
        argv = command["argv"]
        if command["returncode"] != 0 or not all(isinstance(a,str) for a in argv): continue
        if not argv or Path(argv[0]).name.lower() != "xperf.exe": continue
        try:
            output = Path(argv[argv.index("-o")+1]).resolve()
            trace = Path(argv[argv.index("-i")+1]).resolve()
            action = argv[argv.index("-a")+1]
        except (ValueError,IndexError): continue
        if output == paths["dumper"] and action == "dumper" and trace.is_relative_to(root):
            dumper_commands.append(command)
    if not dumper_commands: raise ValueError("Missing successful ROOT xperf dumper command with exact output path")
    dumper_stat_before = paths["dumper"].stat()
    dumper_hasher = hashlib.sha256(); dumper_bytes = 0
    processes, threads, images, resolve = parse_process(small["process"])
    sample_events = 0; sample_count = 0; headers = {}; raw_examples = []
    by_module, by_ip, by_thread, by_thread_count = Counter(), Counter(), Counter(), Counter()
    per_thread_ips = defaultdict(Counter); time_range = {}; frame_modules = Counter(); raw_stacks = []
    sample_stack_keys = set(); pending = None; current_example = None
    def locate(ip, ts):
        image = resolve(ip, ts)
        if image is None: return ("UNMAPPED", None, None, None)
        return image["module"], image["base"], ip - image["base"], image["timedatestamp"]
    with paths["dumper"].open("rb") as f:
        for n, raw_line in enumerate(f,1):
            dumper_hasher.update(raw_line); dumper_bytes += len(raw_line)
            # xperf contains opaque non-UTF8 metadata bytes. Required event/numeric
            # tokens are ASCII; render other bytes as explicit \xNN escapes in excerpts.
            # This does not replace bytes in the original hash or guess a text codec.
            line = raw_line.decode("ascii", errors="backslashreplace")
            stripped = line.lstrip()
            if stripped.startswith("SampledProfile,"):
                row = csv_row(line)
                if row[1] == "TimeStamp":
                    if row[4] != "PrgrmCtr" or row[3] != "ThreadID" or row[8] != "Count": raise ValueError("Unknown SampledProfile schema")
                    headers["SampledProfile"] = {"line_number":n,"raw_line":line.rstrip()}; continue
                pending = None; current_example = None
                name, pid = process_id(row[2])
                if pid != PID: continue
                if name.lower() != "ck3.exe": raise ValueError("SampledProfile PID name mismatch")
                ts, tid, ip, count = int(row[1]), int(row[3]), int(row[4],16), int(row[8])
                if tid not in threads or not any(inside_time(ts,t) for t in threads[tid]): raise ValueError("Sample outside declared target thread lifetime")
                if count < 1: raise ValueError("Invalid SampledProfile Count")
                module, base, rva, stamp = locate(ip,ts); key = (module,base,ip,rva,stamp)
                sample_events += 1; sample_count += count; by_module[module] += count; by_ip[key] += count
                by_thread[tid] += 1; by_thread_count[tid] += count; per_thread_ips[tid][key] += count
                if tid not in time_range: time_range[tid] = [ts,ts]
                else: time_range[tid] = [min(time_range[tid][0],ts), max(time_range[tid][1],ts)]
                pending = (ts,tid)
                if len(raw_examples) < 8:
                    raw_examples.append({"line_number":n,"timestamp_us":ts,"tid":tid,"ip":hex(ip),"module":module,
                                         "module_base":hex(base) if base is not None else None,"rva":hex(rva) if rva is not None else None,
                                         "raw_line":line.rstrip()})
            elif stripped.startswith("Stack,"):
                row = csv_row(line)
                if row[1] == "TimeStamp":
                    if row[4] != "Address": raise ValueError("Unknown Stack schema")
                    headers["Stack"] = {"line_number":n,"raw_line":line.rstrip()}; continue
                ts, tid = int(row[1]),int(row[2])
                if tid not in threads or not any(inside_time(ts,t) for t in threads[tid]): continue
                address = int(row[4],16); module,base,rva,stamp = locate(address,ts); frame_modules[module] += 1
                if pending == (ts,tid):
                    sample_stack_keys.add(pending)
                    if current_example is None and len(raw_stacks) < 3:
                        current_example = {"timestamp_us":ts,"tid":tid,"frames":[]}; raw_stacks.append(current_example)
                    if current_example is not None and len(current_example["frames"]) < 64:
                        current_example["frames"].append({"line_number":n,"address":hex(address),"module":module,
                            "module_base":hex(base) if base is not None else None,"rva":hex(rva) if rva is not None else None,"raw_line":line.rstrip()})
            elif stripped and not stripped.startswith("#"):
                pending = None; current_example = None
    dumper_stat_after = paths["dumper"].stat()
    if dumper_bytes != dumper_stat_before.st_size or (dumper_stat_before.st_size,dumper_stat_before.st_mtime_ns) != (dumper_stat_after.st_size,dumper_stat_after.st_mtime_ns):
        raise ValueError("Dumper export changed or was truncated during the single analysis pass")
    pins["dumper"] = {"path":str(paths["dumper"]),"bytes":dumper_bytes,"sha256":dumper_hasher.hexdigest(),
        "hash_origin":"first honest output pin, computed during the same one-pass binary analysis"}
    if not sample_events or "SampledProfile" not in headers: raise ValueError("No actual target CPU samples or header")
    def hotspot(key,count):
        module,base,ip,rva,stamp = key
        return {"module":module,"module_base":hex(base) if base is not None else None,"ip":hex(ip),
                "rva":hex(rva) if rva is not None else None,"timedatestamp":stamp,"sample_count":count}
    top_threads = [{"tid":tid,"sample_events":by_thread[tid],"sample_count":count,
        "first_sample_us":time_range[tid][0],"last_sample_us":time_range[tid][1],"role":"UNKNOWN",
        "top_ips":[hotspot(k,c) for k,c in per_thread_ips[tid].most_common(8)]} for tid,count in by_thread_count.most_common()]
    official_profile = []
    for n,line in enumerate(small["profile"].splitlines(),1):
        row = csv_row(line)
        if len(row) == 4 and process_id(row[0])[1] == PID:
            official_profile.append({"line_number":n,"module":row[3],"weight":int(row[1]),"usage_percent":float(row[2]),"raw_line":line})
    if not official_profile: raise ValueError("Official profile export lacks PID16528")
    losses = {}
    for name, pattern in (("lost_buffers", r"^Total\s+#\s+Lost Buffers\s*:\s*(\d+)"), ("lost_events", r"^Total\s+#\s+Lost Events\s*:\s*(\d+)")):
        m = re.search(pattern,small["tracestats"],re.M); losses[name] = int(m.group(1)) if m else None
    losses["status"] = "UNKNOWN" if None in losses.values() else ("ZERO" if not any(losses.values()) else "NONZERO")
    pp = Tables(); pp.feed(small["stack"])
    stack_process_rows = [r for r in pp.rows if len(r) == 4 and Path(r[0]).name.lower() == "ck3.exe" and r[1] == str(PID)]
    if not stack_process_rows: raise ValueError("Stack report is not bound to PID16528")
    me = re.search(r"<a id=['\"]TblME['\"]>(.*?)<a id=['\"]TblMI['\"]>",small["stack"],re.S)
    module_stack_rows = []
    if me:
        table = Tables(); table.feed(me.group(1)); module_stack_rows = table.rows
    result = {"schema":"lyd.r45.actual-etw-offline-analysis.v1","analyzed_at_utc":datetime.now(timezone.utc).isoformat(),
        "root_reported_game_identity":GAME_IDENTITY,"input_files":pins,"root_receipts":receipts,
        "analysis_elapsed_seconds":time.monotonic()-tick,"raw_headers":headers,"target_process_rows":processes,
        "target_thread_count":len(threads),"target_thread_record_count":sum(map(len,threads.values())),
        "threads_with_cpu_samples":len(by_thread),"threads_without_cpu_samples":sorted(set(threads)-set(by_thread)),
        "sample_event_count":sample_events,"sum_sample_count_field":sample_count,"top_modules_by_sample_count":by_module.most_common(),
        "top_instruction_pointers":[hotspot(k,c) for k,c in by_ip.most_common(40)],"threads_by_sample_count":top_threads,
        "sample_events_with_attached_stack_observed":len(sample_stack_keys),"target_thread_stack_frame_modules":frame_modules,
        "raw_sample_examples":raw_examples,"raw_sample_stack_examples":raw_stacks,
        "official_profile_rows":sorted(official_profile,key=lambda r:r["weight"],reverse=True),"profile_weight_unit":"not inferred",
        "official_stack_process_rows":stack_process_rows,"official_stack_exclusive_module_rows":module_stack_rows,
        "loss_statistics":losses,"trace_stats_raw":small["tracestats"],"target_image_intervals":images,
        "new_trace_wpr_exports":False,"etl_opened_or_rehashed":False,"dumper_rehashed":False,
        "dumper_hash_computed_during_single_pass":True,"dumper_hash_passes":1,"actual_dumper_command_provenance":dumper_commands,
        "dumper_text_policy":"Required event/PID/TID/timestamp/IP/count tokens are ASCII; informational non-ASCII bytes are shown as explicit byte escapes. Original hash uses unchanged bytes.",
        "function_semantics":"UNKNOWN pending exact address mapping","engine_cause":"UNKNOWN; hotspots alone do not prove cause",
        "synthetic_addresses_in_actual_result":False}
    out = Path(args.output).resolve(); out.mkdir(parents=False, exist_ok=False)
    def write_json(name,value):
        with (out/name).open("x",encoding="utf-8",newline="\n") as f: json.dump(value,f,ensure_ascii=False,indent=2); f.write("\n")
    write_json("ANALYSIS.actual.json",result)
    for name, rows, fields in (("HOTSPOTS.csv",result["top_instruction_pointers"],["module","module_base","ip","rva","timedatestamp","sample_count"]),
                              ("THREADS.csv",top_threads,["tid","sample_events","sample_count","first_sample_us","last_sample_us","role"])):
        with (out/name).open("x",encoding="utf-8",newline="") as f:
            writer=csv.DictWriter(f,fieldnames=fields,extrasaction="ignore"); writer.writeheader(); writer.writerows(rows)
    lines=["# R45 实际 ETW 离线观察", "",f"实际 PID {PID}；{len(threads)} 个线程记录身份，{len(by_thread)} 个线程出现 CPU 样本。",
           f"SampledProfile {sample_events} 行，Count 合计 {sample_count}；loss 状态 {losses['status']}。", "",
           "样本量、官方 profile Weight 与 stack hits 分列。模块/IP/RVA 均由实际导出匹配；无匹配区间保持 UNMAPPED。未解析函数语义，热点不单独证明加载原因。", "",
           "模块热点："]
    lines += [f"- {m}: {c} samples" for m,c in by_module.most_common(10)]
    lines += ["", "线程热点："] + [f"- TID {r['tid']}: {r['sample_count']} samples；角色 UNKNOWN" for r in top_threads[:10]]
    (out/"REPORT.zh.md").write_text("\n".join(lines)+"\n",encoding="utf-8",newline="\n")
    artifacts=[]
    for p in sorted(out.iterdir()): artifacts.append(pin_bytes(p,p.read_bytes()))
    source=Path(__file__).resolve()
    write_json("INDEX.json",{"schema":"lyd.r45.actual-etw-offline-analysis-index.v1","source":pin_bytes(source,source.read_bytes()),
        "root_reported_game_identity":GAME_IDENTITY,"files":artifacts,"root_receipts":receipts,"large_dumper_first_pin_from_single_analysis_pass":pins["dumper"]})
    print(json.dumps({"output":str(out),"index":pin_bytes(out/"INDEX.json",(out/"INDEX.json").read_bytes()),
                      "sample_events":sample_events,"sample_count":sample_count,"thread_count":len(threads),"losses":losses},ensure_ascii=False))

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for key in ("profile","process","stack","dumper","tracestats"): ap.add_argument("--"+key,required=True)
    ap.add_argument("--receipt",action="append",required=True,help="ROOT actual export command receipt(s): returncode0 and exact xperf dumper argv")
    ap.add_argument("--output",required=True,help="Fresh external output directory, parent must exist")
    analyze(ap.parse_args())

if __name__ == "__main__": main()
