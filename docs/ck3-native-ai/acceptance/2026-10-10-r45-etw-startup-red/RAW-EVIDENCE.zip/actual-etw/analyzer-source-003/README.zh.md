# R45 actual analyzer 003：字节呈现修正

002 首次 actual 执行 return1，在 CSV 开头非UTF8字节0xae处终止，没有完成CSV读取或生成SHA。失败 RESULT/stdout/stderr 保留在 original-exec001。后续限定1MiB的编码读取也证实不能直接假定 Windows ACP/mbcs；首次诊断的原失败脚本保留，当前原始证据在 ENCODING-BOUNDARY.actual.json，不给全文件编码命名。

003 只把 CSV 的文本呈现改为 ASCII + 明确反斜杠字节转义。被解析的 event/PID/TID/time/IP/count 合同均为原ASCII；数字转换仍严格，非ASCII数字不会通过。其余非ASCII元数据不参与资格，excerpt按\xNN显示，不猜UTF8或ANSI、不替换底层bytes。SHA仍同步更新原始raw_line；没有第二个大文件hash pass，ETL不打开。

最终 AST parse0；不重复help/tests。001/002与失败原件均保留。首次完整CSV pass随后执行；本包本身尚无实际模块热点资格。
