# R45 离线分析器 002：适配实际 command receipt

001 原件保留。ROOT 已明确实际 helper 只在 command RESULT 中记录 argv/returncode/stdout/stderr；没有预存 dumper output SHA。002 仅修这一输入合同：--receipt 消费实际 009-dumper/RESULT.actual.json，核 returncode0、xperf -i 位于本轮 ETW root、-o 精确等于传入 CSV、-a dumper。

同一次 rb 逐行分析同步 SHA256.update(raw_line) 与 byte count，真实生成第一份 dumper output pin；不声称存在旧 pin，不第二次读/哈希 CSV，也不打开 ETL。小导出在其初次读取时生成实际 pin。读取前后 size/mtime 和流式 bytes 不一致则拒绝混用未完成输出。

PID16528/create1791603219.1009781/FILETIME134360768191009782/fde5fb0a 固定；MIN/MAX、同采样时刻 image interval、modules/IP/RVA/threads/loss 以及计数分列逻辑保持。AST parse0；按 ROOT 指令不重复 help/tests。不曾消费 actual exports，等待 ROOT final-ready。
