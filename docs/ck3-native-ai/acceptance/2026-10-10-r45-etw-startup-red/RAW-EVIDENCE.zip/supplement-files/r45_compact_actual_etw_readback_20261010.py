import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

BASE = Path("C:/workspace/ck3_lyd_runtime_20261004")
OUT = BASE / "r45-actual-etw-offline-analysis-20261010-001"
EXEC = BASE / "r45-actual-etw-offline-analysis-original-exec-20261010-003"

def read_pin(path):
    data = path.read_bytes()
    return data, {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

raw, analysis_pin = read_pin(OUT / "ANALYSIS.actual.json")
actual = json.loads(raw)
raw, exec_pin = read_pin(EXEC / "RESULT.actual.json")
execution = json.loads(raw)
assert execution["returncode"] == 0, "Actual analyzer did not complete successfully"
assert actual["root_reported_game_identity"]["pid"] == 16528
assert actual["dumper_hash_computed_during_single_pass"] is True
assert actual["dumper_hash_passes"] == 1
pins = [analysis_pin, exec_pin]
for path in [OUT / "INDEX.json", OUT / "REPORT.zh.md", OUT / "HOTSPOTS.csv", OUT / "THREADS.csv", EXEC / "REQUEST.actual.json", EXEC / "stdout.bin", EXEC / "stderr.bin", BASE / "r45-actual-etw-offline-analysis-original-exec-20261010-001/RESULT.actual.json", BASE / "r45-actual-etw-offline-analysis-original-exec-20261010-001/stderr.bin", BASE / "r45-actual-etw-offline-analysis-original-exec-20261010-002/RESULT.actual.json", BASE / "r45-actual-etw-offline-analysis-original-exec-20261010-002/stderr.bin", BASE / "r45-actual-etw-offline-analyzer-sourceonly-20261010-004/SOURCE-INDEX.json"]:
    _, pin = read_pin(path)
    pins.append(pin)

compact = {
    "schema": "lyd.r45.actual-etw-compact-readback.v1",
    "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "root_reported_game_identity": actual["root_reported_game_identity"],
    "analyzed_at_utc": actual["analyzed_at_utc"],
    "analysis_elapsed_seconds": actual["analysis_elapsed_seconds"],
    "actual_analysis_result": exec_pin,
    "input_files": actual["input_files"],
    "root_receipts": actual["root_receipts"],
    "sample_event_count": actual["sample_event_count"],
    "sum_sample_count_field": actual["sum_sample_count_field"],
    "target_thread_count": actual["target_thread_count"],
    "target_thread_record_count": actual["target_thread_record_count"],
    "threads_with_cpu_samples": actual["threads_with_cpu_samples"],
    "threads_without_cpu_samples": actual["threads_without_cpu_samples"],
    "top_modules_by_sample_count": actual["top_modules_by_sample_count"],
    "top_instruction_pointers": actual["top_instruction_pointers"],
    "top_threads": actual["threads_by_sample_count"][:12],
    "sample_events_with_attached_stack_observed": actual["sample_events_with_attached_stack_observed"],
    "target_thread_stack_frame_modules": actual["target_thread_stack_frame_modules"],
    "raw_sample_stack_examples": actual["raw_sample_stack_examples"],
    "raw_stack_analysis_skipped": actual["raw_stack_analysis_skipped"],
    "raw_stack_boundary": actual["raw_stack_boundary"],
    "quarantined_target_sample_events": actual["quarantined_target_sample_events"],
    "quarantined_target_sample_count": actual["quarantined_target_sample_count"],
    "quarantined_target_sample_examples": actual["quarantined_target_sample_examples"],
    "official_profile_rows": actual["official_profile_rows"],
    "official_profile_usage_percent_denominator": "system denominator; not CK3 within-process module percentage",
    "official_profile_weight_unit": actual["profile_weight_unit"],
    "loss_statistics": actual["loss_statistics"],
    "trace_stats_raw": actual["trace_stats_raw"],
    "dumper_text_policy": actual["dumper_text_policy"],
    "large_output_hash_origin": "Copied from the first completed single-pass analysis; no second dumper or ETL read/hash",
    "preserved_failures": [pin for pin in pins if "original-exec-20261010-001" in pin["path"] or "original-exec-20261010-002" in pin["path"]],
    "function_semantics": "UNKNOWN pending exact address mapping",
    "engine_cause": "UNKNOWN; CPU hotspots and shader activity do not establish a loading cause or deadlock",
    "business_credit": "NOT_GREEN",
    "source_main_game_sdk_wpr_exports_mutated": False,
}
with (OUT / "COMPACT.actual.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(compact, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
lines = ["# R45 实际 ETW 单次离线分析补充", "", f"绑定 CK3 PID16528。实际分析 exit0，SampledProfile {compact['sample_event_count']} 行，Count 合计 {compact['sum_sample_count_field']}。", f"线程身份 {compact['target_thread_count']} 个，出现 CPU 样本 {compact['threads_with_cpu_samples']} 个；丢失状态 {compact['loss_statistics']['status']}。", "", "dumper 原始字节 SHA 在同一完整流式分析中首次生成，未另读或重 hash 大文件。初次 UTF-8 解码失败及 ACP936 严格解码失败原件保留；非 ASCII 信息字节显式转义，数字/IP 字段仍严格解析。", "", "官方 profile 的 Usage% 使用系统分母，不代表 CK3 内部模块占比。样本 Count、官方 Weight、附带栈样本分列。ETL 时长和起止以 trace_stats_raw 原始行及 ROOT 回执为准，不能把等待60秒写成 trace60秒。", "", "模块 Count 热点：", ""]
lines.extend(f"- {name}: {count}" for name, count in compact["top_modules_by_sample_count"][:10])
lines += ["", "线程 Count 热点：", ""]
lines.extend(f"- TID {row['tid']}: {row['sample_count']}；线程角色 UNKNOWN" for row in compact["top_threads"][:10])
lines += ["", "模块/IP/RVA 可用于后续有限地址映射；函数语义和加载因果仍 UNKNOWN。观测期间存在 shader compiler CPU 样本不能单独证明其造成900秒失败；采样与保存开销可能影响运行。业务仍 NOT_GREEN。", ""]
(OUT / "COMPACT-REPORT.zh.md").write_text("\n".join(lines), encoding="utf-8", newline="\n")
for path in [OUT / "COMPACT.actual.json", OUT / "COMPACT-REPORT.zh.md", Path(__file__).resolve()]:
    _, pin = read_pin(path)
    pins.append(pin)
index = {"schema": "lyd.r45.actual-etw-final-compact-index.v1", "files": pins, "large_dumper_pin_reused_from_single_pass": actual["input_files"]["dumper"], "root_receipts": actual["root_receipts"], "game_pid": 16528, "business_credit": "NOT_GREEN"}
with (OUT / "FINAL-INDEX.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(index, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
_, final_pin = read_pin(OUT / "FINAL-INDEX.json")
print(json.dumps({"index": final_pin, "files": pins, "dumper_pin": actual["input_files"]["dumper"], "modules": compact["top_modules_by_sample_count"][:12], "top_ips": compact["top_instruction_pointers"][:12], "threads": [{k: v for k, v in row.items() if k != "top_ips"} for row in compact["top_threads"]], "sample_events": compact["sample_event_count"], "sample_count": compact["sum_sample_count_field"], "thread_count": compact["target_thread_count"], "active_threads": compact["threads_with_cpu_samples"], "attached_stack_sample_count": compact["sample_events_with_attached_stack_observed"], "loss": compact["loss_statistics"], "trace_stats_raw": compact["trace_stats_raw"], "profile": compact["official_profile_rows"][:8]}, ensure_ascii=False))
