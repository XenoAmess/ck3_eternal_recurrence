"""Bind completed R45 small evidence; retain large artifacts by existing pins only."""
from pathlib import Path
import hashlib
import json

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
HERE = Path(__file__).resolve().parent
PRIOR = BASE/'r45-etw-startup-red-archive-candidate-20261010-002'
ETW = BASE/'r45-actual-etw-offline-analysis-20261010-001'
R38 = BASE/'r45-r38-shadercache-presence-and-cleanup-history-readonly-20261010-001'
PRODUCER = BASE/'r45-runtime-archive-sourceonly-20261010-001/package_evidence.py'
OUTPUT = BASE/'r45-etw-startup-red-permanent-archive-20261010-001'
PY = 'C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'

def pin(path):
    raw = path.read_bytes()
    assert len(raw) < 16*1024*1024
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def load(path):
    return json.loads(path.read_bytes())

def write(name, value):
    with (HERE/name).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

def text(name, value):
    with (HERE/name).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(value)

inputs = load(PRIOR/'CLOSED-INPUTS.actual-etw-cache-draft.json')
final_index = load(ETW/'FINAL-INDEX.json')
compact = load(ETW/'COMPACT.actual.json')
assert pin(ETW/'FINAL-INDEX.json')['sha256'] == 'b2292dfbb73485d2af3224cd61c17c104508535072b50b3a269e23675296b365'
assert pin(ETW/'COMPACT.actual.json')['sha256'] == 'd9a81a943657dfe300a1eb71eae049e083e4b64700c5e51a9d204e96ed0353b4'
assert pin(ETW/'FINAL-FINDINGS.zh.md')['sha256'] == '3cfbddd551e1ce88c3e29b728d2145f808c093e8acd444b154b44c7a62c408f0'
assert pin(R38/'REPORT.actual.json')['sha256'] == 'fc389e1ffa20700796e6ebd146803ab4fd126def08b1e01f8708b15c1f6c83f4'
assert compact['sample_event_count'] == 439548
assert compact['quarantined_target_sample_events'] == 2
assert compact['raw_stack_analysis_skipped'] is True
assert compact['sample_events_with_attached_stack_observed'] is None
assert compact['target_thread_count'] == 125 and compact['threads_with_cpu_samples'] == 51

inputs['supplements'][1] = {
    'role': 'actual-etw/compact-hotspot-proof', 'status': 'AVAILABLE', 'root': str(ETW),
    'final_index_ref': pin(ETW/'FINAL-INDEX.json'),
    'compact_ref': pin(ETW/'COMPACT.actual.json'),
    'findings_ref': pin(ETW/'FINAL-FINDINGS.zh.md'),
    'hotspot_boundary_ref': pin(ETW/'HOTSPOT-BOUNDARY.actual.json'),
}
for suffix in ['001', '002', '003']:
    root = BASE/f'r45-actual-etw-offline-analysis-original-exec-20261010-{suffix}'
    inputs['supplements'].append({'role': f'actual-etw/analyzer-original-exec-{suffix}',
                                 'status': 'AVAILABLE', 'root': str(root)})
for suffix in ['001', '002', '003', '004']:
    root = BASE/f'r45-actual-etw-offline-analyzer-sourceonly-20261010-{suffix}'
    inputs['supplements'].append({'role': f'actual-etw/analyzer-source-{suffix}',
                                 'status': 'AVAILABLE', 'root': str(root)})
inputs['supplements'].append({
    'role': 'actual-etw/thread-boundary-diagnostic', 'status': 'AVAILABLE',
    'root': str(BASE/'r45-actual-etw-offline-analyzer-thread-boundary-diagnostic-20261010-001')})
inputs['supplements'].append({
    'role': 'diagnostic/R38-cache-presence-and-cleanup-history', 'status': 'AVAILABLE',
    'root': str(R38), 'report_ref': pin(R38/'REPORT.actual.json'), 'index_ref': pin(R38/'INDEX.json')})
large = dict(final_index['large_dumper_pin_reused_from_single_pass'])
assert Path(large['path']).stat().st_size == large['bytes']
large.update(role='actual-CK3-xperf-dumper', body_read=False, hash_recomputed=False,
             pin_source='actual FINAL-INDEX; first completed single-pass analysis')
inputs['external_reference_only'].append(large)
for row in final_index['files']:
    if Path(row['path']).suffix.lower() == '.csv':
        assert Path(row['path']).stat().st_size == row['bytes']
        inputs['external_reference_only'].append({**row, 'role': 'compact CSV derivative; JSON equivalent archived',
                                                 'body_read': False, 'hash_recomputed': False,
                                                 'pin_source': 'actual FINAL-INDEX'})
inputs['small_file_refs'].extend([
    pin(BASE/'r45_compact_actual_etw_readback_20261010.py'), pin(Path(__file__).resolve())])
inputs['actual_hotspot_boundary'] = {
    'matched_sample_count': 439548, 'quarantined_sample_count': 2,
    'quarantined_qualification': 'UNKNOWN', 'thread_identity_count': 125,
    'threads_with_samples': 51, 'raw_stack_body_census': 'SKIPPED',
    'attached_stack_coverage': None, 'thread_roles': 'UNKNOWN', 'engine_cause': 'UNKNOWN',
    'dumper_hash_origin': 'first completed single-pass analysis; archive does not rehash',
}
write('CLOSED-INPUTS.actual.json', inputs)

report = (PRIOR/'REPORT.coherent-pending-hotspot.md').read_text(encoding='utf-8')
report = report.replace(
    '以下为外置候选正文；实际热点摘要尚待 c3 完成，永久 ZIP、主仓导入和提交尚未执行。',
    '本报告记录本轮原始失败、独立观测与其后的实际清场；原host汇总缺项和旧分析失败均保留。')
report = report.replace(
    '实际热点证明待补；加载原因目前UNKNOWN。分析器首次文本解码失败的原回执保留，修正后的首次完整单pass结果将作为独立来源加入。CPU样本、栈聚合或导出成功本身不证明加载死锁、前台原因或某项业务成功。',
    '004分析器于04:19:56.543007Z完成首次完整单pass，匹配439548条SampledProfile，125个目标线程身份中51个有匹配样本。另2条TID17252样本分别超出记录的线程end 5179/8049微秒，隔离为UNKNOWN，不进入热点资格。原始Stack正文统计明确SKIPPED，attached-stack覆盖率NULL；官方stack.txt独立保留，未取得完整用户栈。模块样本Count：ck3.exe184762、ntoskrnl.exe106155、D3DCompiler_47.dll80542、ntdll.dll31021、nvwgf2umx10022、ucrt9741。CK3最热RVA0x3f91ed9为59290样本、0x3f91f8f为49837；线程角色和函数语义均UNKNOWN。官方profile Weight与样本Count单位不等同，Usage%使用系统分母。\n\n002首次分析在432793字节附近遇到非UTF8信息字段而失败，GetACP936/mbcs严格解码亦失败，不能声称全局ANSI。003采用ASCII关键字段加非ASCII byte escapes后，仍因线程生命周期不匹配于04:12:05Z、446.66秒后失败，没有完整dumper SHA或资格结果。004保留严格生命周期关联，只将两条不匹配样本隔离，原始每行参与SHA；首次完整流式生成的dumper pin为10098403170B / `a3ce7977583cdcf0793aa4e2724d83842b91ad1162164b82020d7e2ee9ab58a7`。两旧RED、四版源码及原执行回执纳入小证据链。归档不再读或hash该大正文。CPU热点、D3D活动、缓存mtime与导出成功只证明并存活动，不证明加载死锁、前台原因或业务成功；根因仍UNKNOWN。')
report = report.replace(
    '新小原件纳入候选，旧R38正文证明不重复打包。',
    '新小原件纳入归档，旧R38正文证明不重复打包。新鲜R38 stat清点仍为3740文件/146942067B，名称、大小和mtime均与原元数据相同；窄查42源码、68实际argv和7份prepare记录未找到清理这些cache的证据，但全局“从未删除”、历史delete-and-recreate及正文一致性仍UNKNOWN。新建profile未复制旧cache与删除已有cache是不同事实。')
report = report.replace(
    '永久交付计划为本报告及同名acceptance目录的FACTS、INDEX、RAW-EVIDENCE.zip、VALIDATION、README与producer源码，共7文件。91MB seed、ETL、dumper、二进制、缓存正文和旧source ZIP继续只保留外置引用。最终导入等待ROOT明确通知。',
    '永久证据见[acceptance索引](acceptance/2026-10-10-r45-etw-startup-red/README.md)、[实际事实](acceptance/2026-10-10-r45-etw-startup-red/FACTS.actual.json)与[原件清单](acceptance/2026-10-10-r45-etw-startup-red/INDEX.json)。同目录保留RAW-EVIDENCE.zip、VALIDATION及producer源码。91MB seed、ETL、dumper、二进制、缓存正文和旧source ZIP继续只保留外置引用。归档CRC/member/bytes与小原件SHA检查见实际VALIDATION；没有新增启动、SDK、屏幕操作或业务资格。')
text('REPORT.final.md', report)
text('README.md', '''# R0045 紧凑原证据

对应[永久报告](../../2026-10-10-r45-etw-startup-red.md)。本包保存冻结fde5fb0a0的900秒startup RED、实际清场CAS4358→4359、ETW小回执/004首次完整分析及两旧RED、缓存元数据、精确CI和Git identity勘正。

- [FACTS.actual.json](FACTS.actual.json)：原native RED/cleanupfalse/reportnull和实际当前清场分列；业务未执行。
- [INDEX.json](INDEX.json)：ZIP成员原路径/bytes/SHA、外置引用与排除列表。
- [RAW-EVIDENCE.zip](RAW-EVIDENCE.zip)：本轮小原件、源码、图片和记录命令；synthetic证据有独立路径。
- [VALIDATION.actual.json](VALIDATION.actual.json)：一次归档CRC、member、bytes及小原件SHA验收。
- [package_evidence.py](package_evidence.py)：实际producer原字节；输入原件保存在ZIP内producer/CLOSED-INPUTS.actual.json。

ETL/dumper/process/profile/stack正文、91MB seed、缓存内容和二进制不入包。大dumper SHA只复用004首次完整单pass结果；归档不重新读取或hash。439548匹配样本及2条UNKNOWN quarantine分列，原始Stack正文统计SKIPPED、attached coverage NULL，线程角色/函数语义/加载根因UNKNOWN。正常退出与CreateProcess原句柄/Job最终计数没有补造；独立观察CK3exit1、host1及当前empty/keeper0/CAS实际释放不改写原cleanupfalse。
''')
argv = [PY, '-B', '-X', 'utf8', str(PRODUCER), '--closed-inputs', str(HERE/'CLOSED-INPUTS.actual.json'),
        '--closed-inputs-sha256', pin(HERE/'CLOSED-INPUTS.actual.json')['sha256'], '--output', str(OUTPUT)]
write('CREATE-ARGV.actual.json', {'schema': 'lyd.file-only-archive-argv.v1', 'argv': argv,
                                'output': str(OUTPUT), 'source_only_author': True})
write('INDEX.json', {'schema': 'lyd.r45.final-archive-candidate.v1',
                     'files': [pin(HERE/n) for n in ['CLOSED-INPUTS.actual.json', 'REPORT.final.md', 'README.md',
                                                    'CREATE-ARGV.actual.json', 'author_final_archive.py']],
                     'producer': pin(PRODUCER), 'producer_executed': False,
                     'large_body_reads': 0, 'main_writes': 0})
print(json.dumps({'index': pin(HERE/'INDEX.json'), 'create_argv': pin(HERE/'CREATE-ARGV.actual.json')}, ensure_ascii=False))
