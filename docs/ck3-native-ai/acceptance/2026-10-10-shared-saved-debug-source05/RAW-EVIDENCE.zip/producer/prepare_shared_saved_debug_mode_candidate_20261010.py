from __future__ import annotations

import ast
import difflib
import hashlib
import json
import shutil
from pathlib import Path

REPO = Path('C:/workspace/ck3_eternal_recurrence')
BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'shared-saved-campaign-debug-mode-sourceonly-20261010-001'
SOURCE = OUT / 'source'
TARGETS = [
    'ck3_autonomous_player/src/xar_autoplayer/runtime.py',
    'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py',
    'tools/ck3_mod_acceptance.py',
    'ck3_autonomous_player/tests/unit/test_saved_campaign_delayed_injection.py',
    'tools/test_ck3_mod_acceptance.py',
]


def reference(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def write(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)


OUT.mkdir(exist_ok=False)
before = {}
for relative in TARGETS:
    raw = (REPO / relative).read_bytes()
    before[relative] = raw
    write(OUT / 'before' / relative, raw)

# These are unmodified import dependencies, excluded from the five-file patch.
shutil.copytree(REPO / 'ck3_autonomous_player/src/xar_autoplayer',
                SOURCE / 'ck3_autonomous_player/src/xar_autoplayer',
                ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
common = 'tools/ck3_mod_acceptance_common.py'
write(SOURCE / common, (REPO / common).read_bytes())
dependencies = [reference(path) for path in sorted((SOURCE / 'ck3_autonomous_player/src/xar_autoplayer').rglob('*'))
                if path.is_file() and path.relative_to(SOURCE).as_posix() not in TARGETS]
dependencies.append(reference(SOURCE / common))


def replace(text, old, new):
    if '\r\n' in text:
        old = old.replace('\n', '\r\n')
        new = new.replace('\n', '\r\n')
    if text.count(old) != 1:
        raise ValueError('Expected exactly one source seam: ' + old[:100])
    return text.replace(old, new, 1)


runtime = before[TARGETS[0]].decode('utf-8')
runtime = replace(runtime, '"""Tracked non-debug CK3 launch and visible main-menu attestation."""',
                  '"""Tracked CK3 launch with explicit debug opt-in and main-menu attestation."""')
runtime = replace(runtime,
    '    load_save_name: str | None = None,\n) -> list[str]:\n    if continue_last_save',
    '    load_save_name: str | None = None,\n    debug_mode: bool = False,\n) -> list[str]:\n    if type(debug_mode) is not bool:\n        raise AgentError("debug_mode requires an explicit boolean")\n    if continue_last_save')
runtime = replace(runtime,
    '    if continue_last_save:\n        command.append("-continuelastsave")',
    '    if debug_mode:\n        command.insert(1, "-debug_mode")\n    if continue_last_save:\n        command.append("-continuelastsave")')
runtime = replace(runtime,
    '    load_save_name: str | None = None,\n    verify_prepared_profile: bool = True,',
    '    load_save_name: str | None = None,\n    debug_mode: bool = False,\n    verify_prepared_profile: bool = True,')
runtime = replace(runtime,
    ') -> SessionHandle:\n    native_bridge = (',
    ') -> SessionHandle:\n    if type(debug_mode) is not bool:\n        raise AgentError("debug_mode requires an explicit boolean")\n    native_bridge = (')
runtime = replace(runtime,
    '        continue_last_save=continue_last_save,\n        load_save_name=load_save_name,\n    )',
    '        continue_last_save=continue_last_save,\n        load_save_name=load_save_name,\n        debug_mode=debug_mode,\n    )')

host = before[TARGETS[1]].decode('utf-8')
host = replace(host,
    '    if args.saved_campaign_save is not None:\n        if (any(item is None for item in inputs)',
    '    debug_mode = getattr(args, "saved_campaign_debug_mode", False)\n    if type(debug_mode) is not bool:\n        raise SystemExit("--saved-campaign-debug-mode requires an explicit boolean")\n    if debug_mode and (args.saved_campaign_save is None or args.server):\n        raise SystemExit("--saved-campaign-debug-mode requires an explicit saved campaign, without server mode")\n    if args.saved_campaign_save is not None:\n        if (any(item is None for item in inputs)')
host = replace(host,
    '        launch_kwargs["load_save_name"] = "restored_campaign"\n        launch_kwargs["verify_prepared_profile"] = False',
    '        launch_kwargs["load_save_name"] = "restored_campaign"\n        launch_kwargs["debug_mode"] = getattr(args, "saved_campaign_debug_mode", False)\n        launch_kwargs["verify_prepared_profile"] = False')
host = replace(host,
    '            and argv.count("-loadsave=restored_campaign") == 1 and "-continuelastsave" not in argv\n            and type(pid) is int and pid > 0)',
    '            and argv.count("-loadsave=restored_campaign") == 1 and "-continuelastsave" not in argv\n            and argv.count("-debug_mode") == int(launch_kwargs["debug_mode"])\n            and type(pid) is int and pid > 0)')
host = replace(host,
    '            continue_last_save=False, load_save_name="restored_campaign", captured_at=now())',
    '            continue_last_save=False, load_save_name="restored_campaign",\n            debug_mode=launch_kwargs["debug_mode"], captured_at=now())')
host = replace(host,
    '    result.add_argument("--saved-campaign-server", action="store_true", help=argparse.SUPPRESS)',
    '    result.add_argument("--saved-campaign-debug-mode", action="store_true",\n                        help="Shared saved-campaign diagnostic opt-in: append one actual -debug_mode flag to the same managed launch; default off")\n    result.add_argument("--saved-campaign-server", action="store_true", help=argparse.SUPPRESS)')

entry = before[TARGETS[2]].decode('utf-8')
entry = replace(entry,
    '{"succession_title_readonly", "saved_campaign_inject_after_load"}',
    '{"succession_title_readonly", "saved_campaign_inject_after_load", "saved_campaign_debug_mode"}')
entry = replace(entry,
    '            argv += ["--saved-campaign-inject-after-load"]\n        budgets = self.case["budgets"]',
    '            argv += ["--saved-campaign-inject-after-load"]\n        if features.get("saved_campaign_debug_mode") and startup["mode"] == "saved_campaign":\n            argv += ["--saved-campaign-debug-mode"]\n        budgets = self.case["budgets"]')

unit = before[TARGETS[3]].decode('utf-8')
unit = replace(unit,
    '            self.assertEqual(args[2][runtime.NATIVE_BRIDGE_PIPE_ENV], self.config.pipe_name)\n            return self.process',
    '            self.assertEqual(args[2][runtime.NATIVE_BRIDGE_PIPE_ENV], self.config.pipe_name)\n            self.assertEqual(args[0].count("-debug_mode"), 1)\n            self.assertEqual(args[0].count("-loadsave=restored_campaign"), 1)\n            return self.process')
unit = replace(unit,
    "                runtime.launch(spec, native_bridge=self.config, load_save_name='restored_campaign',\n                    verify_prepared_profile=False, native_bridge_after_saved_load=True,",
    "                runtime.launch(spec, native_bridge=self.config, load_save_name='restored_campaign',\n                    debug_mode=True, verify_prepared_profile=False, native_bridge_after_saved_load=True,")
unit_addition = '''class SavedCampaignDebugModeTests(unittest.TestCase):
    def test_default_command_is_byte_for_byte_unchanged(self):
        spec = SimpleNamespace(game_exe=Path('game/ck3.exe'), profile_dir=Path('profile'))
        expected = [str(spec.game_exe), '-gdpr-compliant', '-userdir=' + str(spec.profile_dir),
                    '-loadsave=restored_campaign']
        self.assertEqual(runtime._ck3_launch_command(spec, load_save_name='restored_campaign'), expected)
        self.assertEqual(runtime._ck3_launch_command(spec, load_save_name='restored_campaign', debug_mode=False), expected)

    def test_explicit_true_adds_only_one_flag_to_the_original_saved_command(self):
        spec = SimpleNamespace(game_exe=Path('game/ck3.exe'), profile_dir=Path('profile'))
        normal = runtime._ck3_launch_command(spec, load_save_name='restored_campaign')
        debug = runtime._ck3_launch_command(spec, load_save_name='restored_campaign', debug_mode=True)
        self.assertEqual(debug, [normal[0], '-debug_mode', *normal[1:]])
        self.assertEqual(debug.count('-loadsave=restored_campaign'), 1)
        self.assertNotIn('-continuelastsave', debug)

    def test_mixed_boolean_types_are_rejected_before_any_process_check(self):
        for value in (0, 1, None, 'true', [], {}):
            with self.subTest(value=value), mock.patch.object(runtime, 'ck3_processes') as processes, \\
                    mock.patch.object(runtime, 'native_bridge_launch_config_from_environment') as config:
                with self.assertRaisesRegex(AgentError, 'explicit boolean'):
                    runtime._ck3_launch_command(object(), debug_mode=value)
                with self.assertRaisesRegex(AgentError, 'explicit boolean'):
                    runtime.launch(object(), debug_mode=value)
                processes.assert_not_called()
                config.assert_not_called()

    def test_host_default_off_and_saved_only_policy(self):
        self.assertFalse(HOST.parser().parse_args([]).saved_campaign_debug_mode)
        for extra in ([], ['--saved-campaign-save', 'fake.ck3', '--server']):
            args = HOST.parser().parse_args(['--saved-campaign-debug-mode', *extra])
            with self.assertRaisesRegex(SystemExit, 'requires an explicit saved campaign'):
                HOST.validate_saved_campaign_options(args)
        for value in (0, 1, None, 'true', [], {}):
            args = HOST.parser().parse_args([])
            args.saved_campaign_debug_mode = value
            with self.subTest(value=value), self.assertRaisesRegex(SystemExit, 'explicit boolean'):
                HOST.validate_saved_campaign_options(args)

    def test_host_accepts_explicit_saved_diagnostic_without_reading_save_body(self):
        with tempfile.TemporaryDirectory() as directory:
            plan = Path(directory) / 'plan.json'
            plan.write_text('[]', encoding='utf-8')
            args = HOST.parser().parse_args(['--saved-campaign-debug-mode', '--fixture-profile',
                '--plan', str(plan), '--saved-campaign-save', str(Path(directory) / 'not-read.ck3'),
                '--saved-campaign-save-bytes', '1', '--saved-campaign-save-sha256', 'a' * 64,
                '--saved-campaign-player-id', '31254', '--saved-campaign-date-raw', '53144712',
                '--saved-campaign-product-inventory', str(Path(directory) / 'not-read.json')])
            HOST.validate_saved_campaign_options(args)
            self.assertTrue(args.saved_campaign_debug_mode)

    def test_wrapper_propagates_bool_and_requires_actual_debug_flag_agreement(self):
        for requested, actual in ((False, False), (True, True), (True, False), (False, True)):
            with self.subTest(requested=requested, actual=actual):
                module = ModuleType('fake_managed_session')
                exec('def native_session(spec, **kwargs):\\n launch(spec, native_bridge=kwargs["native_bridge"])\\n return {}\\n'
                     'def _native_session_locked(*args, **kwargs):\\n return {}\\n', module.__dict__)
                command = ['ck3.exe', '-loadsave=restored_campaign']
                if actual:
                    command.insert(1, '-debug_mode')
                module.launch = mock.Mock(return_value=SimpleNamespace(command=command, process=SimpleNamespace(pid=71)))
                stop = SimpleNamespace(is_set=lambda: False)
                args = SimpleNamespace(timeout=2100, hold_seconds=900, saved_campaign_debug_mode=requested,
                    saved_campaign_inject_after_load=True, _saved_campaign_readiness_deadline=1234.0)
                record = {}
                with mock.patch('importlib.import_module', return_value=module):
                    HOST.saved_campaign_session(object(), object(), args, stop, output_stream=None, launch_record=record)
                kwargs = module.launch.call_args.kwargs
                self.assertIs(kwargs['debug_mode'], requested)
                self.assertEqual(kwargs['load_save_name'], 'restored_campaign')
                self.assertEqual(kwargs['native_bridge_injection_deadline'], 1234.0)
                self.assertIs(kwargs['native_bridge_stop_requested'], stop.is_set)
                self.assertEqual(record['argv_admitted'], requested == actual)
                self.assertIs(record['debug_mode'], requested)


'''
unit = replace(unit, 'class SharedReadinessDeadlineTests(unittest.IsolatedAsyncioTestCase):',
               unit_addition + 'class SharedReadinessDeadlineTests(unittest.IsolatedAsyncioTestCase):')

entry_test = before[TARGETS[4]].decode('utf-8')
entry_test = replace(entry_test,
    "                  *entry.SAVED_FLAGS.values(), '--fixture-profile', '--saved-campaign-inject-after-load']",
    "                  *entry.SAVED_FLAGS.values(), '--fixture-profile', '--saved-campaign-inject-after-load',\n                  '--saved-campaign-debug-mode']")
entry_addition = '''    def test_saved_debug_mode_global_default_off_and_single_flag(self):
        self.assertNotIn('--saved-campaign-debug-mode', self.select().argv)
        for enabled in (False, True):
            with self.subTest(enabled=enabled):
                self.manifest['host_features'] = {'saved_campaign_debug_mode': enabled}
                self.write(self.manifest_path, self.manifest)
                self.runtime['manifest'] = entry.pin(self.manifest_path)
                self.write(self.runtime_path, self.runtime)
                selected = self.select()
                self.assertEqual(selected.argv.count('--saved-campaign-debug-mode'), int(enabled))
                self.assertEqual(selected.preflight()['blockers'], [])

    def test_saved_debug_mode_is_not_routed_to_other_startup_modes(self):
        self.manifest['host_features'] = {'saved_campaign_debug_mode': True}
        self.write(self.manifest_path, self.manifest)
        self.runtime['manifest'] = entry.pin(self.manifest_path)
        self.write(self.runtime_path, self.runtime)
        case = self.products['products']['xqol']['cases'][0]
        for mode in ('workshop_cache', 'fixture'):
            with self.subTest(mode=mode):
                case['startup'] = {'mode': mode, 'state_dir': '{run_dir}/state',
                                   'fixture_start_policy': str(self.files['initial'])}
                self.write(self.products_path, self.products)
                self.assertNotIn('--saved-campaign-debug-mode', self.select().argv)

    def test_saved_debug_mode_rejects_non_boolean_and_unknown_global_features(self):
        for features in ([{'saved_campaign_debug_mode': value} for value in (0, 1, None, 'true', [], {})]
                         + [{'unreviewed_debug_override': True}]):
            with self.subTest(features=features):
                self.manifest['host_features'] = features
                self.write(self.manifest_path, self.manifest)
                self.runtime['manifest'] = entry.pin(self.manifest_path)
                self.write(self.runtime_path, self.runtime)
                with self.assertRaisesRegex(ValueError, 'host feature'):
                    self.select()

    def test_product_or_case_cannot_choose_saved_debug_mode(self):
        original = copy.deepcopy(self.products)
        for location in ('product', 'case'):
            with self.subTest(location=location):
                self.products = copy.deepcopy(original)
                target = self.products['products']['xqol']
                if location == 'case':
                    target = target['cases'][0]
                target['host_features'] = {'saved_campaign_debug_mode': True}
                self.write(self.products_path, self.products)
                with self.assertRaisesRegex(ValueError, 'cannot select shared runtime'):
                    self.select()

'''
entry_test = replace(entry_test, '    def test_all_canonical_products_and_cases_select_the_same_runtime(self):',
                     entry_addition + '    def test_all_canonical_products_and_cases_select_the_same_runtime(self):')

after = dict(zip(TARGETS, [runtime, host, entry, unit, entry_test]))
patches = []
rows = []
for relative in TARGETS:
    text = after[relative]
    ast.parse(text, filename=relative)
    raw = text.encode('utf-8')
    target = SOURCE / relative
    if target.exists():
        target.write_bytes(raw)
    else:
        write(target, raw)
    patches.extend(difflib.unified_diff(before[relative].decode('utf-8').splitlines(keepends=True),
        text.splitlines(keepends=True), fromfile='a/' + relative, tofile='b/' + relative))
    rows.append({'target': relative, 'before': reference(OUT / 'before' / relative),
                 'after': reference(target), 'current_main_input': reference(REPO / relative)})
patch = ''.join(patches).replace('\r\n', '\n').encode('utf-8')
write(OUT / 'saved-campaign-debug-mode.incremental.patch', patch)
manifest = {'schema': 'lyd.shared.saved-campaign-debug-mode-integration.v1',
    'status': 'SOURCE_ONLY_NOT_APPLIED_NOT_LIVE', 'target_count': 5, 'targets': rows,
    'patch': reference(OUT / 'saved-campaign-debug-mode.incremental.patch'),
    'author': reference(__file__), 'unmodified_import_dependencies': dependencies,
    'contract': {'debug_mode_default': False, 'strict_bool': True,
        'host_flag': '--saved-campaign-debug-mode', 'host_saved_only': True,
        'global_feature': 'host_features.saved_campaign_debug_mode',
        'product_case_override': 'forbidden', 'C++': 'unchanged', 'native_session': 'unchanged',
        'fixture_files': 'unchanged', 'new_launches_per_run': 1, 'deadline': 'original unchanged'},
    'future': {'source05': None, 'source_head': None, 'export': None, 'build': None,
        'game_pid': None, 'live_execution': None, 'startup_result': None}}
write(OUT / 'INTEGRATION-MANIFEST.source-only.json',
      (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print(json.dumps({'package': OUT.as_posix(), 'manifest': reference(OUT / 'INTEGRATION-MANIFEST.source-only.json'),
                  'patch': reference(OUT / 'saved-campaign-debug-mode.incremental.patch'),
                  'owned_targets': TARGETS}, ensure_ascii=False, indent=2))
