import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

repo = Path('C:/workspace/ck3_eternal_recurrence')
out = Path('C:/workspace/ck3_lyd_runtime_20261004/shared-saved-debug-main-integration-20261010-001') / 'delayed14-fresh-fixture-002'
out.mkdir(exist_ok=False)
relative = 'ck3_autonomous_player/tests/unit/test_saved_campaign_delayed_injection.py'
raw = (repo / relative).read_bytes()
(out / 'test_saved_campaign_delayed_injection.py').write_bytes(raw)
argv = [sys.executable, '-B', '-X', 'utf8', relative, '-v']
result = subprocess.run(argv, cwd=repo, shell=False, capture_output=True,
    env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1', PYTHONPATH=str(repo / 'ck3_autonomous_player/src')))
(out / 'stdout.txt').write_bytes(result.stdout)
(out / 'stderr.txt').write_bytes(result.stderr)
def ref(path):
    body = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
match = re.search(rb'Ran ([0-9]+) tests?', result.stderr)
receipt = {'schema': 'lyd.shared.saved-debug-mode.delayed14-corrected-fixture.v1',
    'argv': argv, 'returncode': result.returncode, 'actual_tests': int(match.group(1)) if match else None,
    'source': ref(out / 'test_saved_campaign_delayed_injection.py'),
    'stdout': ref(out / 'stdout.txt'), 'stderr': ref(out / 'stderr.txt'),
    'original93_receipt_preserved': str(out.parent / 'FULL-AFFECTED-TESTS.actual.json'),
    'production_change_since_first_tests': False, 'CK3': False}
(out / 'RESULT.actual.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'RESULT': ref(out / 'RESULT.actual.json'), 'returncode': result.returncode, 'tests': receipt['actual_tests']}, indent=2))
raise SystemExit(result.returncode)
