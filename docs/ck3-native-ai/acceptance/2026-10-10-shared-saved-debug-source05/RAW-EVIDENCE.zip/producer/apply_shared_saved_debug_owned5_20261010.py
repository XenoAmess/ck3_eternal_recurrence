from __future__ import annotations

import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

REPO = Path('C:/workspace/ck3_eternal_recurrence')
BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'shared-saved-debug-main-integration-20261010-001'
CANDIDATE = BASE / 'shared-saved-campaign-debug-mode-sourceonly-20261010-002'
EXPECTED_HEAD = '0c0e36e21164d55cd9f47d2d8ab9ae7a5cbf3f63'
PATCH = CANDIDATE / 'saved-campaign-debug-mode.incremental.patch'
TARGETS = [
    'ck3_autonomous_player/src/xar_autoplayer/runtime.py',
    'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py',
    'tools/ck3_mod_acceptance.py',
    'ck3_autonomous_player/tests/unit/test_saved_campaign_delayed_injection.py',
    'tools/test_ck3_mod_acceptance.py',
]


def ref(path):
    raw = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def create(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)


def command(name, argv):
    result = subprocess.run(argv, cwd=REPO, capture_output=True, shell=False)
    stdout = OUT / (name + '.stdout.txt')
    stderr = OUT / (name + '.stderr.txt')
    create(stdout, result.stdout)
    create(stderr, result.stderr)
    row = {'argv': argv, 'returncode': result.returncode, 'stdout': ref(stdout), 'stderr': ref(stderr)}
    create(OUT / (name + '.actual.json'), (json.dumps(row, indent=2) + '\n').encode('utf-8'))
    if result.returncode:
        raise SystemExit(result.returncode)
    return result.stdout


def run_ast(raw):
    node = next(node for node in ast.parse(raw).body if isinstance(node, ast.AsyncFunctionDef) and node.name == 'run')
    return ast.dump(node, include_attributes=False)


OUT.mkdir(exist_ok=False)
head = command('before-head', ['git', 'rev-parse', 'HEAD']).decode().strip()
status = command('before-status', ['git', 'status', '--porcelain=v1'])
assert head == EXPECTED_HEAD and not status, 'Unexpected HEAD or dirty main; stop without apply'
assert ref(PATCH)['sha256'] == '9e09ee1152d7dc23c07dbb9d5096492a2a878dd3e29b1027ae0b2e12e1fccd2c'
rows = []
before = {}
for relative in TARGETS:
    raw = (REPO / relative).read_bytes()
    before[relative] = raw
    saved = OUT / 'before' / relative
    create(saved, raw)
    rows.append({'target': relative, 'before': ref(saved)})
command('db947-initial-plan-fix', ['git', 'show', 'db947a0f89502d1bc16de3793ece805b8dcbc9ba', '--', TARGETS[1]])
command('apply-check', ['git', 'apply', '--check', str(PATCH)])
command('apply', ['git', 'apply', str(PATCH)])
patch = []
for row in rows:
    relative = row['target']
    raw = (REPO / relative).read_bytes()
    after = OUT / 'after' / relative
    create(after, raw)
    row['after'] = ref(after)
    patch.extend(difflib.unified_diff(before[relative].decode('utf-8').splitlines(keepends=True),
        raw.decode('utf-8').splitlines(keepends=True), fromfile='a/' + relative, tofile='b/' + relative))
assert run_ast(before[TARGETS[1]]) == run_ast((REPO / TARGETS[1]).read_bytes())
assert b'initial_plan_failure_hold' in (REPO / TARGETS[1]).read_bytes()
changed = command('after-changed-paths', ['git', 'diff', '--name-only']).decode().splitlines()
assert set(changed) == set(TARGETS), 'Unexpected changed path; do not stage or commit'
create(OUT / 'applied-debug-only.incremental.patch', ''.join(patch).replace('\r\n', '\n').encode('utf-8'))
manifest = {'schema': 'lyd.shared.saved-debug-owned5-main-apply.v1', 'parent_HEAD': head,
    'targets': rows, 'target_count': 5, 'patch_input': ref(PATCH),
    'applied_incremental_patch': ref(OUT / 'applied-debug-only.incremental.patch'),
    'initial_plan_run_AST_preserved': True,
    'source05_freeze_contract': 'Only future author parent-to-author owned5 delta. Never 919bae-to-current-master diff.',
    'author': ref(Path(__file__)), 'tests': None, 'owned_commit': None, 'push': None,
    'game_or_SDK': False, 'C++_changes': False}
create(OUT / 'APPLIED.actual.json', (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print(json.dumps({'applied': ref(OUT / 'APPLIED.actual.json'),
    'patch': ref(OUT / 'applied-debug-only.incremental.patch'),
    'initial_plan_run_AST_preserved': True, 'targets': changed}, indent=2))
