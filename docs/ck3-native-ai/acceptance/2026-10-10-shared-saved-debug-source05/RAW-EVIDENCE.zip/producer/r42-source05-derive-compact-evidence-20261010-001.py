from pathlib import Path
import hashlib
import json

base = Path('C:/workspace/ck3_lyd_runtime_20261004')
relative = Path('payload/docs/ck3-native-ai/acceptance/2026-10-10-shared-saved-debug-source05/package_evidence.py')
old = base / 'r42-source05-evidence-candidate-20261010-001' / relative
new = base / 'r42-source05-evidence-candidate-20261010-002' / relative
raw = old.read_bytes()
needle = b"    for path in paths:\n        assert path.stat().st_size < 8 * 1024 * 1024 and path.suffix.lower() not in ['.ck3', '.zip']\n        selected[prefix + '/' + path.relative_to(root).as_posix()] = path\n"
replacement = b"""    archived_paths = paths
    if root == CANDIDATE:
        owned = set(load(ACTUAL_REVIEW / 'REVIEW.actual.json')['changed_paths_exact'])
        archived_paths = [path for path in paths if path.relative_to(root).parts[0] != 'source'
                          or path.relative_to(root / 'source').as_posix() in owned]
        counts[prefix]['selection'] = 'All candidate receipts, before bytes and five owned source files; copied unchanged package dependencies stay external with original manifest pins.'
    counts[prefix]['archived_files'] = len(archived_paths)
    for path in archived_paths:
        assert path.stat().st_size < 8 * 1024 * 1024 and path.suffix.lower() not in ['.ck3', '.zip']
        selected[prefix + '/' + path.relative_to(root).as_posix()] = path
"""
assert raw.count(needle) == 1
derived = raw.replace(needle, replacement)
old_names = b"    'root-record-command-20261010-001.py',\n"
new_names = old_names + b"    'r42-source05-derive-compact-evidence-20261010-001.py',\n    'r42-source05-compact-producer-derivation-20261010-001.json',\n"
assert derived.count(old_names) == 1
derived = derived.replace(old_names, new_names)
new.parent.mkdir(parents=True, exist_ok=False)
new.write_bytes(derived)
pin = lambda path: {'path': str(path), 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
receipt = {'original': pin(old), 'derived': pin(new), 'derivation_author': pin(Path(__file__)),
    'reason': 'First archive selected unchanged copied xar_autoplayer dependencies. Keep all receipts and owned five files; preserve the oversized external archive without repeating it in the permanent compact package.',
    'excluded_candidate_dependency_files': 1176, 'source05_actual_review_repeated': False,
    'changes': ['Filter only candidate source/ to exact five owned paths', 'Add this producer derivation to archive']}
path = base / 'r42-source05-compact-producer-derivation-20261010-001.json'
with path.open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(receipt, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({'derived': pin(new), 'receipt': pin(path)}, indent=2))
