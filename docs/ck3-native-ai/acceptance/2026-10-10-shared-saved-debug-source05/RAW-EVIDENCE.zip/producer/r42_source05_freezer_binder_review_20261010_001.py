"""Read-only pre-freeze audit. Never execute freezer/binder or tests."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import subprocess

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
REPO = Path('C:/workspace/ck3_eternal_recurrence')
OLD = Path('C:/workspace/ck3-common-runtime/20261010-003')
OUT = BASE / 'r42-source05-freezer-binder-review-20261010-001'
SOURCE05 = Path('C:/csr5')
RUNTIME05 = Path('C:/workspace/ck3-common-runtime/20261010-004')
FIXED_BASE = '919bae0f42def04e6398eb2de4b4afe20dcfc106'
EXPECTED = {
    'ck3_autonomous_player/src/xar_autoplayer/runtime.py',
    'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py',
    'tools/ck3_mod_acceptance.py',
    'tools/test_ck3_mod_acceptance.py',
    'ck3_autonomous_player/tests/unit/test_saved_campaign_delayed_injection.py',
}

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def pin(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def load(path):
    return json.loads(path.read_bytes())

def assert_pin(row):
    path = Path(row['path'])
    assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], path

def git(*args):
    return subprocess.run(['git', *args], cwd=REPO, capture_output=True, check=True).stdout.decode().strip()

def put(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

scripts = {
    'freezer002': BASE / 'r42-root-freeze-source05-20261010-002.py',
    'binder001': BASE / 'r42-root-bind-runtime-20261010-001.py',
}
trees = {key: ast.parse(path.read_text(encoding='utf-8'), filename=str(path)) for key, path in scripts.items()}
for key, tree in trees.items():
    compile(tree, str(scripts[key]), 'exec')  # Syntax only. No script execution.

assignments = {target.id: node.value for node in trees['freezer002'].body if isinstance(node, ast.Assign)
               for target in node.targets if isinstance(target, ast.Name)}
assert ast.literal_eval(assignments['BASE']) == FIXED_BASE
assert set(ast.literal_eval(assignments['PATHS'])) == EXPECTED
assert Path(ast.literal_eval(assignments['OUT'].args[0])) == RUNTIME05
assert Path(ast.literal_eval(assignments['SOURCE'].args[0])) == SOURCE05
for key, value in [('OLD', str(OLD)), ('OUT', str(RUNTIME05)), ('SOURCE', str(SOURCE05))]:
    node = next(node for node in trees['binder001'].body if isinstance(node, ast.Assign)
                and any(isinstance(target, ast.Name) and target.id == key for target in node.targets))
    assert Path(ast.literal_eval(node.value.args[0])) == Path(value)

calls = [node for node in ast.walk(trees['freezer002']) if isinstance(node, ast.Call)
         and isinstance(node.func, ast.Name) and node.func.id == 'git']
commit_calls = [node for node in calls if node.args and isinstance(node.args[0], ast.Constant) and node.args[0].value == 'commit-tree']
assert len(commit_calls) == 1
commit_args = commit_calls[0].args
assert len(commit_args) == 4 and ast.literal_eval(commit_args[2]) == '-p'
assert isinstance(commit_args[3], ast.Name) and commit_args[3].id == 'BASE'
freezer_text = scripts['freezer002'].read_text(encoding='utf-8')
required_freezer_guards = [
    "if OUT.exists() or SOURCE.exists():",
    "patch = git('diff', '--binary', parent, author, '--', *PATHS)",
    "git('read-tree', BASE, env=environment)",
    "git('apply', '--cached', '--whitespace=error'",
    "if sorted(changes) != sorted(PATHS):",
    "if native_changes != [expected_host]:",
    "'artifact_build_result': json.loads((OLD / 'SOURCE04-NATIVE-REUSE.actual.json').read_bytes())['artifact_build_result']",
    "'live_qualification': 'NOT_RUN'",
]
assert all(fragment in freezer_text for fragment in required_freezer_guards)
assert "pin(OLD / 'BUILD-RESULT.actual.json')" not in freezer_text
binder_text = scripts['binder001'].read_text(encoding='utf-8')
required_binder_guards = [
    "if reuse['native_compiled_inputs_unchanged'] is not True:",
    "for key in ('dll', 'injector'):",
    "if any(actual[field] != manifest['native'][key][field] for field in ('bytes', 'sha256')):",
    "source_root=str(SOURCE)",
    "source_index=str(OUT / 'source05-index.json')",
    "native_source_index=str(OUT / 'native-source05-index.json')",
    "manifest['host_features']['saved_campaign_inject_after_load'] = True",
    "manifest['host_features']['saved_campaign_debug_mode'] = True",
    "manifest['qualification'] = 'PYTHON_FIX_NATIVE_INPUTS_EQUAL_NOT_LIVE_NOT_PRODUCT_PASS'",
    "runtime['manifest'] = pin(OUT / 'manifest.json')",
    "runtime['reviewed_launcher'] = pin(SOURCE / 'tools/ck3_mod_acceptance_launcher.py')",
    "runtime['control_queue'] = pin(SOURCE / 'tools/ck3_mod_acceptance_queue.py')",
    "runtime['allocation']['screen_keeper'] = pin(SOURCE / 'tools/ck3_mod_acceptance_keeper.py')",
]
assert all(fragment in binder_text for fragment in required_binder_guards)

derivation = BASE / 'r42-root-source05-tools-derivation-20261010-001.json'
derivation002 = BASE / 'r42-root-freezer002-derivation-20261010-001.json'
derivation_count = 0
for row in load(derivation)['changes']:
    assert_pin(row['original'])
    assert_pin(row['derived'])
    raw = Path(row['original']['path']).read_bytes()
    for old, new in row['replacements']:
        raw = raw.replace(old.encode(), new.encode())
    assert raw == Path(row['derived']['path']).read_bytes()
    derivation_count += 1
row = load(derivation002)
assert_pin(row['original'])
assert_pin(row['derived'])
raw = Path(row['original']['path']).read_bytes()
raw = raw.replace(row['replacement'][0].encode(), row['replacement'][1].encode())
assert raw == Path(row['derived']['path']).read_bytes()
derivation_count += 1

index = load(OLD / 'source04-index.json')
native_index = load(OLD / 'native-source04-index.json')
reuse = load(OLD / 'SOURCE04-NATIVE-REUSE.actual.json')
manifest = load(OLD / 'manifest.json')
runtime = load(OLD / 'runtime.local.json')
assert index['source_commit'] == native_index['source_commit'] == reuse['source04_commit'] == FIXED_BASE
parents = git('rev-list', '--parents', '-n', '1', FIXED_BASE).split()
assert len(parents) == 2
source04 = Path(runtime['paths']['source_root'])
actual_files = {path.relative_to(source04).as_posix() for path in source04.rglob('*') if path.is_file()}
assert actual_files == set(index['files'])
for relative, expected in index['files'].items():
    path = source04 / relative
    assert path.stat().st_size == expected['bytes'] and sha(path) == expected['sha256'], relative
assert native_index['files'] == {key: row for key, row in index['files'].items() if key.startswith('ck3_autonomous_player/native_bridge/')}
assert_pin(reuse['artifact_build_result'])
assert reuse['artifact_build_result'] == manifest['provenance']['build_result']
assert_pin(manifest['provenance']['build_inputs'])
native = {}
for key in ['dll', 'injector']:
    native[key] = pin(Path(runtime['paths'][key]))
    assert native[key]['bytes'] == manifest['native'][key]['bytes'] and native[key]['sha256'] == manifest['native'][key]['sha256']

OUT.mkdir(exist_ok=False)
report = {
    'schema': 'ck3-source05-freezer-binder-readonly-pre-freeze-review-v1',
    'at_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'STATIC_REVIEW_PASS_ACTUAL_SOURCE05_NOT_ASSESSED',
    'checkout_head_observed': git('rev-parse', 'HEAD'),
    'scripts': {key: pin(path) for key, path in scripts.items()},
    'derivation_files': [pin(derivation), pin(derivation002)],
    'exact_script_derivations_rechecked': derivation_count,
    'source04_commit_and_parent': parents,
    'source04_indexed_files_actually_sha256_rechecked': len(index['files']),
    'source04_native_directory_index_files': len(native_index['files']),
    'source04_index': pin(OLD / 'source04-index.json'),
    'source04_native_index': pin(OLD / 'native-source04-index.json'),
    'source04_reuse_receipt': pin(OLD / 'SOURCE04-NATIVE-REUSE.actual.json'),
    'inherited_actual_build_result': reuse['artifact_build_result'],
    'inherited_actual_build_inputs': manifest['provenance']['build_inputs'],
    'cbr2_actual_native': native,
    'intended_changed_paths_exact': sorted(EXPECTED),
    'intended_single_frozen_parent': FIXED_BASE,
    'native_directory_intended_change_only': 'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py',
    'intended_runtime_metadata_root': str(RUNTIME05),
    'intended_source_root': str(SOURCE05),
    'both_global_manifest_flags_assigned_true': True,
    'build_result_not_fabricated_from_missing_source04_build': True,
    'native_rebuild_claimed': False,
    'source05_exists_at_receipt': SOURCE05.exists(),
    'runtime05_exists_at_receipt': RUNTIME05.exists(),
    'actual_source05_frozen_bytes_reviewed': False,
    'actual_author_commit_reviewed': False,
    'actual_runtime05_manifest_reviewed': False,
    'findings_requiring_change': [],
    'boundary': 'Pre-freeze script and predecessor byte audit only. Await root notice, then independently check actual author/frozen single parents, exact five indexed deltas, native bytes and bound manifests once.',
    'production_or_repo_writes': 0,
    'freezer_binder_executions': 0,
    'tests_executed': 0,
    'live_actions': 0,
    'live_qualification': False,
    'business_pass': False,
}
put(OUT / 'REVIEW.actual.json', report)
put(OUT / 'INDEX.json', {'schema': 'ck3-readonly-review-index-v1', 'author': pin(Path(__file__)),
    'report': pin(OUT / 'REVIEW.actual.json')})
print(json.dumps({'status': report['status'], 'source04_files': len(index['files']),
    'native_index_files': len(native_index['files']), 'derivations': derivation_count,
    'report': pin(OUT / 'REVIEW.actual.json'), 'source05_actual_pending': True}, indent=2))
