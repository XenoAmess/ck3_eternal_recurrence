from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
REPO = Path('C:/workspace/ck3_eternal_recurrence')
OUT = BASE / 'shared-saved-campaign-debug-mode-sourceonly-20261010-002'
SOURCE = OUT / 'source'


def ref(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def create(name, value):
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    path = OUT / name
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
    return ref(path)


def functions(raw):
    result = {}
    def visit(node, prefix=''):
        for child in getattr(node, 'body', []):
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                name = prefix + child.name
                if not isinstance(child, ast.ClassDef):
                    result[name] = ast.dump(child, include_attributes=False)
                visit(child, name + '.')
    visit(ast.parse(raw))
    return result


original = json.loads((OUT / 'INTEGRATION-MANIFEST.source-only.json').read_text(encoding='utf-8'))
focused = json.loads((OUT / 'FOCUSED.actual.json').read_text(encoding='utf-8'))
assert focused['all_returncodes_zero'] and focused['actual_tests'] == 11
rows = []
review = []
for row in original['targets']:
    relative = row['target']
    before = OUT / 'before' / relative
    after = SOURCE / relative
    current = ref(REPO / relative)
    assert current['sha256'] == row['before']['sha256'], 'Main changed; stop instead of overwriting: ' + relative
    rows.append({'target': relative, 'before_sha256': row['before']['sha256'],
        'before_bytes': row['before']['bytes'], 'before_source': ref(before), 'candidate': ref(after)})
    if relative in [item['target'] for item in original['targets'][:3]]:
        old = functions(before.read_bytes())
        new = functions(after.read_bytes())
        changed = sorted(name for name in old.keys() | new.keys() if old.get(name) != new.get(name))
        review.append({'target': relative, 'changed_function_ASTs': changed})
assert review[0]['changed_function_ASTs'] == ['_ck3_launch_command', 'launch']
assert review[1]['changed_function_ASTs'] == ['parser', 'saved_campaign_session',
    'saved_campaign_session.launch_saved_once', 'validate_saved_campaign_options']
assert len(review[2]['changed_function_ASTs']) == 1 and review[2]['changed_function_ASTs'][0].startswith('Selection.')
native_session = 'ck3_autonomous_player/src/xar_autoplayer/native_session.py'
assert ref(SOURCE / native_session)['sha256'] == ref(REPO / native_session)['sha256']
create('SEMANTIC-SCOPE.actual.json', {'schema': 'lyd.shared.saved-debug-mode.source-scope.v1',
    'production_AST_changes': review, 'native_session_exact_unchanged': ref(SOURCE / native_session),
    'main_before_hashes_still_match': True, 'target_count': 5,
    'native_or_fixture_targets_in_patch': [], 'new_test_methods': 10, 'changed_existing_test_methods': 1})

report = '''# Shared saved-campaign debug 单变量候选

仅五个跟踪路径：generic runtime、既有host、global entry、两个既有测试文件。未应用主仓、未提交；未来source05、HEAD、export、构建、PID及启动结果均为NULL。

`runtime._ck3_launch_command` 与 `runtime.launch` 新增 `debug_mode: bool = False`。只接受真正bool，默认命令逐项保持；明确True时在EXE之后添加一个 `-debug_mode`，仍只有原 `-loadsave`。invalid bool在进程检查和配置读取之前拒绝。

host 新增 `--saved-campaign-debug-mode`，默认False，只有显式saved campaign且非server模式允许。原saved wrapper把bool传给原launch；返回后必须实际argv内debug标志数量与请求相符，才能保留argv_admitted=True。原same PID、Job、prepared-profile policy、唯一loadsave、延迟注入及original deadline均沿用。

global manifest可声明 `host_features.saved_campaign_debug_mode`，沿现有严格bool whitelist；仅saved startup映射host flag。fixture和workshop_cache不映射，product/case的host_features覆盖继续拒绝。此次没有更改任何全局manifest实际值、C++、native_session、产品fixture或挂载52个额外文件。

隔离源码实际执行11项focused（10项新增seam + 1项加入debug参数的既有same-Job/deadline测试），全部通过；host --help与git apply --check均0。原stdout/stderr和精确argv见FOCUSED.actual.json及checks目录。没有运行未变更历史测试、CK3、SDK或native build。首次001作者在复制一个误假定的common依赖时失败，尚未改源码；该失败和before文件保留，002为本次候选。

ROOT在当前证据包发布后可审阅 `REVIEWABLE-INTEGRATION-MANIFEST.json` 的五个before SHA，再执行：

```text
git apply --check C:/workspace/ck3_lyd_runtime_20261004/shared-saved-campaign-debug-mode-sourceonly-20261010-002/saved-campaign-debug-mode.incremental.patch
git apply C:/workspace/ck3_lyd_runtime_20261004/shared-saved-campaign-debug-mode-sourceonly-20261010-002/saved-campaign-debug-mode.incremental.patch
```

上述apply为未来ROOT步骤，本代理未执行。ROOT还需在新的共享manifest中明确选择true，并按现有source-only发布流程冻结新shared source，才有下一轮实际入口；本包不给未来启动结果或根因信用。
'''
create('REPORT.zh.md', report)
manifest = {'schema': original['schema'], 'status': 'REVIEWABLE_SOURCE_ONLY_ROOT_APPLY_PENDING',
    'targets': rows, 'patch': original['patch'], 'contract': original['contract'],
    'actual_focused': ref(OUT / 'FOCUSED.actual.json'), 'semantic_scope': ref(OUT / 'SEMANTIC-SCOPE.actual.json'),
    'full_original_source_manifest': ref(OUT / 'INTEGRATION-MANIFEST.source-only.json'),
    'apply_order': ['Verify all five before SHA-256 pins', 'git apply --check', 'ROOT git apply only after current completed-package publication'],
    'future': original['future'], 'main_apply': None}
create('REVIEWABLE-INTEGRATION-MANIFEST.json', manifest)
index = {'schema': 'lyd.shared.saved-debug-mode.sourceonly-index.v1',
    'artifacts': [ref(OUT / name) for name in ['REPORT.zh.md', 'REVIEWABLE-INTEGRATION-MANIFEST.json',
        'saved-campaign-debug-mode.incremental.patch', 'FOCUSED.actual.json', 'SEMANTIC-SCOPE.actual.json',
        'INTEGRATION-MANIFEST.source-only.json']],
    'authors': [ref(BASE / name) for name in ['prepare_shared_saved_debug_mode_candidate002_20261010.py',
        'check_shared_saved_debug_candidate002_20261010.py', 'seal_shared_saved_debug_candidate002_20261010.py']],
    'prior_author_failure': ref(BASE / 'shared-saved-campaign-debug-mode-sourceonly-20261010-001/FAILURE.authoring.json'),
    'current_main_target_before_hashes_verified': True, 'SDK': 0, 'CK3': 0,
    'native_build': 0, 'main_apply': None, 'source05': None, 'live_result': None}
create('INDEX.json', index)
print(json.dumps({'INDEX': ref(OUT / 'INDEX.json'), 'manifest': ref(OUT / 'REVIEWABLE-INTEGRATION-MANIFEST.json'),
    'report': ref(OUT / 'REPORT.zh.md'), 'production_AST_changes': review}, ensure_ascii=False, indent=2))
