"""One read-only actual Source05 review; no tests, builds, Git mutations or live actions."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r42-source05-actual-review-20261010-001'
REPO = Path('C:/workspace/ck3_eternal_recurrence')
OLD = Path('C:/workspace/ck3-common-runtime/20261010-003')
NEW = Path('C:/workspace/ck3-common-runtime/20261010-004')
SOURCE = Path('C:/csr5')
FIXED_BASE = '919bae0f42def04e6398eb2de4b4afe20dcfc106'
EXPECTED_COMMIT = '27644fdc18e693990e43794af62ebf13db523aef'
EXPECTED_AUTHOR = '3704561725e583d9c9fc10f4c47c1523bb1d9643'
EXPECTED_PARENT = '0c0e36e21164d55cd9f47d2d8ab9ae7a5cbf3f63'
EXPECTED = {
    'ck3_autonomous_player/src/xar_autoplayer/runtime.py',
    'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py',
    'tools/ck3_mod_acceptance.py',
    'tools/test_ck3_mod_acceptance.py',
    'ck3_autonomous_player/tests/unit/test_saved_campaign_delayed_injection.py',
}

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def pin(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def load(path):
    return json.loads(path.read_bytes())

def verify(row):
    actual = pin(Path(row['path']))
    assert all(actual[key] == row[key] for key in ['bytes', 'sha256']), row

def git(*args):
    return subprocess.run(['git', *args], cwd=REPO, capture_output=True, check=True).stdout

def put(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

reuse = load(NEW / 'SOURCE05-NATIVE-REUSE.actual.json')
old_reuse = load(OLD / 'SOURCE04-NATIVE-REUSE.actual.json')
manifest = load(NEW / 'manifest.json')
old_manifest = load(OLD / 'manifest.json')
runtime = load(NEW / 'runtime.local.json')
old_index = load(OLD / 'source04-index.json')
index = load(NEW / 'source05-index.json')
native_index = load(NEW / 'native-source05-index.json')
assert reuse['source05_commit'] == EXPECTED_COMMIT
assert reuse['source04_commit'] == FIXED_BASE
assert reuse['author_commit'] == EXPECTED_AUTHOR and reuse['author_parent'] == EXPECTED_PARENT
frozen_parents = git('rev-list', '--parents', '-n', '1', EXPECTED_COMMIT).decode().split()
author_parents = git('rev-list', '--parents', '-n', '1', EXPECTED_AUTHOR).decode().split()
assert frozen_parents == [EXPECTED_COMMIT, FIXED_BASE]
assert author_parents == [EXPECTED_AUTHOR, EXPECTED_PARENT]
assert git('rev-parse', reuse['archive_tag'] + '^{commit}').decode().strip() == EXPECTED_COMMIT
author_paths = set(git('diff-tree', '--no-commit-id', '--name-only', '-r', EXPECTED_AUTHOR).decode().splitlines())
frozen_paths = set(git('diff-tree', '--no-commit-id', '--name-only', '-r', EXPECTED_COMMIT).decode().splitlines())
assert author_paths == frozen_paths == EXPECTED
assert git('diff', '--binary', EXPECTED_PARENT, EXPECTED_AUTHOR, '--', *sorted(EXPECTED)) == (NEW / 'shared-saved-debug-author.patch').read_bytes()
assert index['source_commit'] == native_index['source_commit'] == EXPECTED_COMMIT
changes = sorted(path for path in set(old_index['files']) | set(index['files'])
                 if old_index['files'].get(path) != index['files'].get(path))
assert changes == sorted(EXPECTED) == reuse['all_changed_paths']
actual_paths = {path.relative_to(SOURCE).as_posix() for path in SOURCE.rglob('*') if path.is_file()}
assert actual_paths == set(index['files'])
for relative, row in index['files'].items():
    path = SOURCE / relative
    assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], relative
native_files = {key: row for key, row in index['files'].items() if key.startswith('ck3_autonomous_player/native_bridge/')}
assert native_index['files'] == native_files
native_changes = [path for path in changes if path.startswith('ck3_autonomous_player/native_bridge/')]
assert native_changes == ['ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py']
assert reuse['native_compiled_inputs_unchanged'] is True
assert reuse['artifact_build_result'] == old_reuse['artifact_build_result'] == manifest['provenance']['build_result'] == old_manifest['provenance']['build_result']
assert manifest['provenance']['build_inputs'] == old_manifest['provenance']['build_inputs']
verify(reuse['artifact_build_result'])
verify(manifest['provenance']['build_inputs'])
assert not (OLD / 'BUILD-RESULT.actual.json').exists() and not (NEW / 'BUILD-RESULT.actual.json').exists()
verify(reuse['source05_archive'])
verify(reuse['minimal_authored_patch'])
verify(reuse['source04_index'])
verify(reuse['source05_index'])
verify(reuse['source05_host'])
verify(runtime['manifest'])
assert Path(runtime['paths']['source_root']) == SOURCE
assert Path(runtime['paths']['host']) == SOURCE / native_changes[0]
for key, filename in [('source_index', 'source05-index.json'), ('native_source_index', 'native-source05-index.json')]:
    assert Path(runtime['paths'][key]) == NEW / filename
for key in ['host', 'source_index', 'native_source_index']:
    actual = pin(Path(runtime['paths'][key]))
    assert manifest[key]['path_key'] == key
    assert all(actual[field] == manifest[key][field] for field in ['bytes', 'sha256'])
native = {}
for key in ['dll', 'injector']:
    native[key] = pin(Path(runtime['paths'][key]))
    assert manifest['native'][key] == old_manifest['native'][key]
    assert all(native[key][field] == manifest['native'][key][field] for field in ['bytes', 'sha256'])
for row in [runtime['reviewed_launcher'], runtime['control_queue'], runtime['allocation']['screen_keeper'],
            manifest['provenance']['mcp_source']]:
    assert Path(row['path']).is_relative_to(SOURCE)
    verify(row)
verify(manifest['provenance']['python_successor_native_equality'])
assert manifest['host_features']['saved_campaign_inject_after_load'] is True
assert manifest['host_features']['saved_campaign_debug_mode'] is True
assert all(row['actual_live_qualified'] is False for row in manifest['capabilities'].values())
assert manifest['qualification'] == 'PYTHON_FIX_NATIVE_INPUTS_EQUAL_NOT_LIVE_NOT_PRODUCT_PASS'
assert runtime['qualification'] == 'BOUND_NOT_ALLOCATED_NOT_RUN'
tests = load(NEW / 'frozen-python-checks-001/RESULT.actual.json')
assert tests['source_commit'] == EXPECTED_COMMIT
assert [row['name'] for row in tests['commands']] == ['saved-lifecycle', 'global-routing', 'host-help']
for row in tests['commands']:
    assert row['exit_code'] == 0 and Path(row['cwd']) == SOURCE
    verify(row['stdout'])
    verify(row['stderr'])

OUT.mkdir(exist_ok=False)
report = {'schema': 'ck3-source05-actual-independent-review-v1', 'at_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'FROZEN_SOURCE_AND_BINDING_PASS_NOT_LIVE', 'source_commit': EXPECTED_COMMIT,
    'frozen_commit_and_single_parent': frozen_parents, 'author_commit_and_single_parent': author_parents,
    'archive_tag': reuse['archive_tag'], 'author_patch_matches_exact_parent_to_author_owned5': True,
    'changed_paths_exact': changes, 'source05_indexed_files_actual_sha256_rechecked': len(index['files']),
    'source05_native_index_files': len(native_files), 'native_directory_changes_exact': native_changes,
    'every_other_source04_indexed_entry_equal': True, 'source05_root_file_set_exact': True,
    'source05_root': str(SOURCE), 'runtime_metadata_root': str(NEW),
    'actual_build_result_inherited': reuse['artifact_build_result'],
    'actual_build_inputs_unchanged': manifest['provenance']['build_inputs'], 'actual_native': native,
    'source05_archive_pinned_only': reuse['source05_archive'], 'manifest': pin(NEW / 'manifest.json'),
    'runtime': pin(NEW / 'runtime.local.json'), 'source05_index': pin(NEW / 'source05-index.json'),
    'source05_native_index': pin(NEW / 'native-source05-index.json'),
    'both_global_manifest_flags_actual_true': True, 'runtime_support_paths_all_csr5': True,
    'frozen_existing_check_receipts': pin(NEW / 'frozen-python-checks-001/RESULT.actual.json'),
    'frozen_existing_check_exit_codes': {row['name']: row['exit_code'] for row in tests['commands']},
    'tests_executed_by_this_review': 0, 'builds_executed_by_this_review': 0,
    'git_mutations_by_this_review': 0, 'live_actions': 0, 'actual_live_qualified': False, 'business_pass': False,
    'findings_requiring_change': [],
    'boundary': 'The new debug opt-in and deferred-injection policy are globally bound. No R42 startup/native/business/normal-exit conclusion is drawn from this source-only receipt.'}
put(OUT / 'REVIEW.actual.json', report)
put(OUT / 'INDEX.json', {'schema': 'ck3-readonly-review-index-v1', 'author': pin(Path(__file__)),
    'report': pin(OUT / 'REVIEW.actual.json')})
print(json.dumps({'status': report['status'], 'files_checked': len(index['files']),
    'changed_paths': changes, 'report': pin(OUT / 'REVIEW.actual.json')}, indent=2))
