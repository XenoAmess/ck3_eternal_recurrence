from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import subprocess

REPO = Path('C:/workspace/ck3_eternal_recurrence')
BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'shared-saved-debug-main-integration-20261010-001'
BEFORE_HEAD = '0c0e36e21164d55cd9f47d2d8ab9ae7a5cbf3f63'
TARGETS = [
    'ck3_autonomous_player/src/xar_autoplayer/runtime.py',
    'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py',
    'tools/ck3_mod_acceptance.py',
    'ck3_autonomous_player/tests/unit/test_saved_campaign_delayed_injection.py',
    'tools/test_ck3_mod_acceptance.py',
]


def ref(path):
    raw = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def create(name, raw):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)
    return ref(path)


def command(name, argv):
    done = subprocess.run(argv, cwd=REPO, shell=False, capture_output=True)
    receipt = {'argv': argv, 'returncode': done.returncode,
        'stdout': create(name + '.stdout.txt', done.stdout),
        'stderr': create(name + '.stderr.txt', done.stderr)}
    create(name + '.actual.json', (json.dumps(receipt, indent=2) + '\n').encode('utf-8'))
    if done.returncode:
        raise SystemExit(done.returncode)
    return done.stdout


first = json.loads((OUT / 'FULL-AFFECTED-TESTS.actual.json').read_text(encoding='utf-8'))
corrected = json.loads((OUT / 'delayed14-fresh-fixture-002/RESULT.actual.json').read_text(encoding='utf-8'))
assert all(row['returncode'] == 0 for row in first['checks'] if row['name'] != 'saved-delayed-injection')
assert corrected['returncode'] == 0 and corrected['actual_tests'] == 14
assert ref(REPO / TARGETS[3])['sha256'] == corrected['source']['sha256']
for relative in (TARGETS[0], TARGETS[1], TARGETS[2], TARGETS[4]):
    assert ref(REPO / relative)['sha256'] == ref(OUT / 'after' / relative)['sha256']
host_before = ast.parse((OUT / 'before' / TARGETS[1]).read_bytes())
host_after = ast.parse((REPO / TARGETS[1]).read_bytes())
get_run = lambda tree: ast.dump(next(node for node in tree.body if isinstance(node, ast.AsyncFunctionDef) and node.name == 'run'), include_attributes=False)
assert get_run(host_before) == get_run(host_after)
assert command('precommit-head', ['git', 'rev-parse', 'HEAD']).decode().strip() == BEFORE_HEAD
changed = command('precommit-changed-paths', ['git', 'diff', '--name-only']).decode().splitlines()
assert set(changed) == set(TARGETS)
command('precommit-diff-check', ['git', 'diff', '--check'])
message = ('Add explicit shared saved-campaign debug mode\n\n'
    'Keep launch defaults unchanged. Route one strict debug boolean from the shared manifest through the saved-only host wrapper to the original managed launch, and verify the returned argv.\n\n'
    'Preserve the existing initial-plan exception hold. The full lifecycle/admission/entry suites cover 93 tests; the original lease-fixture timestamp failure is preserved and its fresh-mtime fixture now passes all 14 delayed-injection tests. No CK3, C++ or native-session change.\n')
create('COMMIT-MESSAGE.txt', message.encode('utf-8'))
command('stage-owned5', ['git', 'add', '--', *TARGETS])
staged = command('staged-paths', ['git', 'diff', '--cached', '--name-only']).decode().splitlines()
assert set(staged) == set(TARGETS), 'Unexpected staged path: stop without commit'
command('owned-commit', ['git', 'commit', '--only', '-F', str(OUT / 'COMMIT-MESSAGE.txt'), '--', *TARGETS])
head = command('owned-head', ['git', 'rev-parse', 'HEAD']).decode().strip()
parent = command('owned-parent', ['git', 'rev-parse', 'HEAD^']).decode().strip()
assert parent == BEFORE_HEAD
committed = command('owned-commit-paths', ['git', 'diff', '--name-only', parent, head]).decode().splitlines()
assert set(committed) == set(TARGETS)
patch = command('owned5-parent-delta', ['git', 'diff', '--binary', parent, head, '--', *TARGETS])
assert b'initial_plan_failure_hold' not in patch
create('source05-author-parent-owned5.patch', patch)
status = command('postcommit-status', ['git', 'status', '--porcelain=v1'])
receipt = {'schema': 'lyd.shared.saved-debug-owned5-commit.v1',
    'author_commit': head, 'author_parent': parent, 'owned_paths': committed,
    'parent_owned5_patch': ref(OUT / 'source05-author-parent-owned5.patch'),
    'source05_base': '919bae0f42def04e6398eb2de4b4afe20dcfc106',
    'source05_freeze_route': 'Independent GIT_INDEX_FILE read-tree 919bae, then apply ONLY author-parent owned5 delta. Do not diff 919bae against current master.',
    'initial_plan_run_AST_preserved': True, 'main_clean_after_commit': not status,
    'full_first_attempt': ref(OUT / 'FULL-AFFECTED-TESTS.actual.json'),
    'corrected_delayed14': ref(OUT / 'delayed14-fresh-fixture-002/RESULT.actual.json'),
    'currently_applicable_test_coverage': {'native_bridge_lifecycle': 48, 'saved_startup_admission': 11,
        'shared_entry': 20, 'saved_delayed_injection_corrected': 14, 'total': 93},
    'focus11_reused_not_rerun': ref(BASE / 'shared-saved-campaign-debug-mode-sourceonly-20261010-002/FOCUSED.actual.json'),
    'future': {'Source05_export': None, 'native_build': None, 'game_pid': None, 'live_result': None},
    'push': None, 'fetch': None, 'rebase': None, 'C++_changed': False,
    'author': ref(Path(__file__))}
create('COMMIT.actual.json', (json.dumps(receipt, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print(json.dumps({'COMMIT': ref(OUT / 'COMMIT.actual.json'), 'head': head, 'parent': parent,
    'patch': ref(OUT / 'source05-author-parent-owned5.patch'), 'main_clean': not status}, indent=2))
