from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

REPO = Path('C:/workspace/ck3_eternal_recurrence')
OUT = Path('C:/workspace/ck3_lyd_runtime_20261004/shared-saved-debug-main-integration-20261010-001')
TESTS = OUT / 'full-affected-tests'
TESTS.mkdir(exist_ok=False)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1',
    PYTHONPATH=str(REPO / 'ck3_autonomous_player/src'))
COMMANDS = [
    ('native-bridge-lifecycle', [sys.executable, '-B', '-X', 'utf8', '-m', 'unittest', 'discover', '-s',
        'ck3_autonomous_player/tests/unit', '-p', 'test_native_bridge_runtime.py', '-v']),
    ('saved-delayed-injection', [sys.executable, '-B', '-X', 'utf8',
        'ck3_autonomous_player/tests/unit/test_saved_campaign_delayed_injection.py', '-v']),
    ('saved-startup-admission', [sys.executable, '-B', '-X', 'utf8', '-m', 'unittest', 'discover', '-s',
        'ck3_autonomous_player/tests/unit', '-p', 'test_saved_campaign_startup_admission.py', '-v']),
    ('shared-entry', [sys.executable, '-B', '-X', 'utf8', 'tools/test_ck3_mod_acceptance.py', '-v']),
]


def ref(path):
    raw = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def execute(item):
    name, argv = item
    result = subprocess.run(argv, cwd=REPO, env=env, shell=False, capture_output=True, timeout=300)
    stdout = TESTS / (name + '.stdout.txt')
    stderr = TESTS / (name + '.stderr.txt')
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    count = re.search(rb'Ran ([0-9]+) tests?', result.stderr)
    row = {'name': name, 'argv': argv, 'returncode': result.returncode,
        'actual_test_count': int(count.group(1)) if count else None,
        'stdout': ref(stdout), 'stderr': ref(stderr)}
    (TESTS / (name + '.actual.json')).write_text(json.dumps(row, indent=2) + '\n', encoding='utf-8')
    return row


with ThreadPoolExecutor(max_workers=4) as pool:
    rows = list(pool.map(execute, COMMANDS))
result = {'schema': 'lyd.shared.saved-debug-mode.full-affected-tests.v1',
    'checks': rows, 'all_returncodes_zero': all(row['returncode'] == 0 for row in rows),
    'actual_tests': sum(row['actual_test_count'] or 0 for row in rows),
    'author': ref(Path(__file__)), 'CK3_launch': False, 'native_build': False}
path = OUT / 'FULL-AFFECTED-TESTS.actual.json'
path.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'RESULT': ref(path), 'tests': result['actual_tests'],
    'checks': [{key: row[key] for key in ('name', 'returncode', 'actual_test_count')} for row in rows]}, indent=2))
raise SystemExit(0 if result['all_returncodes_zero'] else 1)
