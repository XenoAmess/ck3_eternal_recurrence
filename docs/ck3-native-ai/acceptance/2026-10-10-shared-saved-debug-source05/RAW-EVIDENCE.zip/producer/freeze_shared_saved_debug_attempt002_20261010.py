import json
from pathlib import Path
import subprocess
import sys

base = Path('C:/workspace/ck3_lyd_runtime_20261004')
original = base / 'prepare_shared_saved_debug_mode_candidate_20261010.py'
text = original.read_text(encoding='utf-8')
text = text.replace("shared-saved-campaign-debug-mode-sourceonly-20261010-001", "shared-saved-campaign-debug-mode-sourceonly-20261010-002")
text = text.replace("common = 'tools/ck3_mod_acceptance_common.py'\nwrite(SOURCE / common, (REPO / common).read_bytes())\n", '')
text = text.replace('dependencies.append(reference(SOURCE / common))\n', '')
author = base / 'prepare_shared_saved_debug_mode_candidate002_20261010.py'
with author.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(text)
failure = base / 'shared-saved-campaign-debug-mode-sourceonly-20261010-001/FAILURE.authoring.json'
with failure.open('x', encoding='utf-8', newline='\n') as stream:
    json.dump({'status': 'AUTHORING_FAILED_BEFORE_SOURCE_MUTATION',
        'error': 'FileNotFoundError: nonexistent tools/ck3_mod_acceptance_common.py',
        'cause': 'The entry is self-contained; an import dependency was assumed without evidence.',
        'before_snapshots_preserved': True, 'main_modified': False,
        'successor': 'shared-saved-campaign-debug-mode-sourceonly-20261010-002'}, stream, indent=2)
raise SystemExit(subprocess.run([sys.executable, '-B', '-X', 'utf8', str(author)], shell=False).returncode)
