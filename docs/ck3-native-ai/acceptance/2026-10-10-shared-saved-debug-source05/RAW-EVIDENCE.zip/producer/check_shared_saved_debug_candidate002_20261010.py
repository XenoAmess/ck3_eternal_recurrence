from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'shared-saved-campaign-debug-mode-sourceonly-20261010-002'
SOURCE = OUT / 'source'
CHECKS = OUT / 'checks'
CHECKS.mkdir(exist_ok=False)
PYTHON = sys.executable
COMMANDS = [
    ('runtime-host-new-seam', [PYTHON, '-B', '-X', 'utf8', str(SOURCE / 'ck3_autonomous_player/tests/unit/test_saved_campaign_delayed_injection.py'),
        'SavedCampaignDebugModeTests', 'DelayedInjectionTests.test_launch_timeout_uses_existing_original_job_watchdog_cleanup']),
    ('global-routing-new-seam', [PYTHON, '-B', '-X', 'utf8', str(SOURCE / 'tools/test_ck3_mod_acceptance.py'),
        'SharedEntryTests.test_saved_debug_mode_global_default_off_and_single_flag',
        'SharedEntryTests.test_saved_debug_mode_is_not_routed_to_other_startup_modes',
        'SharedEntryTests.test_saved_debug_mode_rejects_non_boolean_and_unknown_global_features',
        'SharedEntryTests.test_product_or_case_cannot_choose_saved_debug_mode']),
    ('host-help', [PYTHON, '-B', '-X', 'utf8', str(SOURCE / 'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py'), '--help']),
    ('patch-check', ['git', 'apply', '--check', str(OUT / 'saved-campaign-debug-mode.incremental.patch')]),
]


def ref(path):
    raw = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def execute(item):
    name, argv = item
    result = subprocess.run(argv, cwd='C:/workspace/ck3_eternal_recurrence' if name == 'patch-check' else SOURCE,
        shell=False, capture_output=True)
    stdout = CHECKS / (name + '.stdout.txt')
    stderr = CHECKS / (name + '.stderr.txt')
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    match = re.search(rb'Ran ([0-9]+) tests?', result.stderr)
    row = {'name': name, 'argv': argv, 'returncode': result.returncode,
        'stdout': ref(stdout), 'stderr': ref(stderr),
        'actual_test_count': int(match.group(1)) if match else None,
        'CK3_or_SDK_called': False}
    (CHECKS / (name + '.actual.json')).write_text(json.dumps(row, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return row


with ThreadPoolExecutor(max_workers=4) as pool:
    rows = list(pool.map(execute, COMMANDS))
summary = {'schema': 'lyd.shared.saved-debug-mode.focused-actual.v1',
    'source': 'isolated five-file candidate plus unmodified Python import dependencies',
    'checks': rows, 'actual_tests': sum(row['actual_test_count'] or 0 for row in rows),
    'all_returncodes_zero': all(row['returncode'] == 0 for row in rows),
    'author': ref(Path(__file__)), 'live_execution': None, 'main_apply': None}
(OUT / 'FOCUSED.actual.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'summary': ref(OUT / 'FOCUSED.actual.json'),
    'results': [{key: row[key] for key in ('name', 'returncode', 'actual_test_count')} for row in rows],
    'actual_tests': summary['actual_tests']}, indent=2))
raise SystemExit(0 if summary['all_returncodes_zero'] else 1)
