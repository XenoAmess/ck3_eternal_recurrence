# Shared debug 五路径实际集成

实际作者提交 `3704561725e583d9c9fc10f4c47c1523bb1d9643`，父提交 `0c0e36e21164d55cd9f47d2d8ab9ae7a5cbf3f63`；提交后工作树实际干净。仅runtime、既有host、global entry和两个既有测试文件，无C++或native_session变化。未fetch、rebase或push。

原外置002补丁对当前main直接 `git apply --check` 通过，随后按增量应用。五个实际before SHA及原字节保全在APPLIED.actual.json/before目录；没有复制旧host全文。main中的db947 initial-plan失败hold修正保持原样，host `run()` 前后AST完全一致。shared debug默认OFF、只接受真正bool；global true只映射saved启动的host flag，原wrapper传给同一managed launch。实际返回argv须含恰好一个debug标志并保持唯一loadsave。Job、原绝对deadline、延迟注入与strict native准入不变。

历史source-only 001作者误假定common依赖存在，复制依赖时失败、尚未修改源码；FAILURE.authoring.json和before保留。002删除该错误假定后形成五路径候选，11项focused、host help与apply-check全部通过，本次没有重跑该focus。

主仓完整受影响测试首轮实际93项：native bridge lifecycle48、saved admission11、shared entry20全部PASS；delayed14中一项旧lease-gate fixture失败（gate只调用1次，原期望2次）。原失败stderr/RESULT全部保留，没有改GREEN。该fixture未保证MARKER的mtime达到其time_ns epoch，时间分辨率原因是源分支推断，失败当时mtime未记录。仅把该fixture时间显式设为epoch+1秒，生产freshness/deadline谓词不变；随后完整delayed14实际PASS。最终当前适用覆盖93项=原79 PASS+修正后14 PASS，未重复其余已PASS套件。参见FULL-AFFECTED-TESTS.actual.json和delayed14-fresh-fixture-002/RESULT.actual.json。

Source05只使用 `source05-author-parent-owned5.patch`：**作者父提交→作者提交**，明确限制五路径。ROOT在独立GIT_INDEX_FILE中read-tree `919bae0f42def04e6398eb2de4b4afe20dcfc106` 后应用此差异；不能使用919bae→当前master diff，也不复制main host全文。补丁不携带db947的run()新增逻辑、远端host或C++改动。ROOT的freeze尚不在本代理实际执行范围。

Source05实际导出、构建、PID、启动、native attach和业务结果均为NULL。当前官方CI失败由ROOT另行处理，本包不冒充CI通过或实机修复。精确提交、补丁、测试及原件引用见COMMIT.actual.json；不以debug参数ACK授产品或根因信用。
