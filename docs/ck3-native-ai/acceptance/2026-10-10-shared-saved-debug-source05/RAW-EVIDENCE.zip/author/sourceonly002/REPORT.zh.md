# Shared saved-campaign debug 单变量候选

仅五个跟踪路径：generic runtime、既有host、global entry、两个既有测试文件。未应用主仓、未提交；未来source05、HEAD、export、构建、PID及启动结果均为NULL。

`runtime._ck3_launch_command` 与 `runtime.launch` 新增 `debug_mode: bool = False`。只接受真正bool，默认命令逐项保持；明确True时在EXE之后添加一个 `-debug_mode`，仍只有原 `-loadsave`。invalid bool在进程检查和配置读取之前拒绝。

host 新增 `--saved-campaign-debug-mode`，默认False，只有显式saved campaign且非server模式允许。原saved wrapper把bool传给原launch；返回后必须实际argv内debug标志数量与请求相符，才能保留argv_admitted=True。原same PID、Job、prepared-profile policy、唯一loadsave、延迟注入及original deadline均沿用。

global manifest可声明 `host_features.saved_campaign_debug_mode`，沿现有严格bool whitelist；仅saved startup映射host flag。fixture和workshop_cache不映射，product/case的host_features覆盖继续拒绝。此次没有更改任何全局manifest实际值、C++、native_session、产品fixture或挂载52个额外文件。

隔离源码实际执行11项focused（10项新增seam + 1项加入debug参数的既有same-Job/deadline测试），全部通过；host --help与git apply --check均0。原stdout/stderr和精确argv见FOCUSED.actual.json及checks目录。没有运行未变更历史测试、CK3、SDK或native build。首次001作者在复制一个误假定的common依赖时失败，尚未改源码；该失败和before文件保留，002为本次候选。

ROOT在当前证据包发布后可审阅 `REVIEWABLE-INTEGRATION-MANIFEST.json` 的五个before SHA，再执行：

```text
git apply --check C:/workspace/ck3_lyd_runtime_20261004/shared-saved-campaign-debug-mode-sourceonly-20261010-002/saved-campaign-debug-mode.incremental.patch
git apply C:/workspace/ck3_lyd_runtime_20261004/shared-saved-campaign-debug-mode-sourceonly-20261010-002/saved-campaign-debug-mode.incremental.patch
```

上述apply为未来ROOT步骤，本代理未执行。ROOT还需在新的共享manifest中明确选择true，并按现有source-only发布流程冻结新shared source，才有下一轮实际入口；本包不给未来启动结果或根因信用。
