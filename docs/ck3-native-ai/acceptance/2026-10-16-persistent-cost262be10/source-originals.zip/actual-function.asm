0262BE10  48 89 5c 24 10                               mov qword ptr [rsp + 0x10], rbx
0262BE15  48 89 6c 24 18                               mov qword ptr [rsp + 0x18], rbp
0262BE1A  56                                           push rsi
0262BE1B  57                                           push rdi
0262BE1C  41 56                                        push r14
0262BE1E  48 81 ec 20 01 00 00                         sub rsp, 0x120
0262BE25  45 0f b6 f1                                  movzx r14d, r9b
0262BE29  41 0f b6 e8                                  movzx ebp, r8b
0262BE2D  48 8b da                                     mov rbx, rdx
0262BE30  48 8b f9                                     mov rdi, rcx
0262BE33  83 b9 38 01 00 00 00                         cmp dword ptr [rcx + 0x138], 0
0262BE3A  74 1b                                        je 0x262be57
0262BE3C  0f 57 c0                                     xorps xmm0, xmm0
0262BE3F  0f 11 02                                     movups xmmword ptr [rdx], xmm0
0262BE42  0f 11 42 10                                  movups xmmword ptr [rdx + 0x10], xmm0
0262BE46  0f 11 42 20                                  movups xmmword ptr [rdx + 0x20], xmm0
0262BE4A  0f 11 42 30                                  movups xmmword ptr [rdx + 0x30], xmm0
0262BE4E  0f 11 42 40                                  movups xmmword ptr [rdx + 0x40], xmm0
0262BE52  e9 32 02 00 00                               jmp 0x262c089
0262BE57  48 8b 81 18 01 00 00                         mov rax, qword ptr [rcx + 0x118]
0262BE5E  81 78 38 4f 62 44 47                         cmp dword ptr [rax + 0x38], 0x4744624f
0262BE65  74 1b                                        je 0x262be82
0262BE67  0f 57 c0                                     xorps xmm0, xmm0
0262BE6A  0f 11 02                                     movups xmmword ptr [rdx], xmm0
0262BE6D  0f 11 42 10                                  movups xmmword ptr [rdx + 0x10], xmm0
0262BE71  0f 11 42 20                                  movups xmmword ptr [rdx + 0x20], xmm0
0262BE75  0f 11 42 30                                  movups xmmword ptr [rdx + 0x30], xmm0
0262BE79  0f 11 42 40                                  movups xmmword ptr [rdx + 0x40], xmm0
0262BE7D  e9 07 02 00 00                               jmp 0x262c089
0262BE82  8b 91 30 01 00 00                            mov edx, dword ptr [rcx + 0x130]
0262BE88  83 fa ff                                     cmp edx, -1
0262BE8B  74 47                                        je 0x262bed4
0262BE8D  83 b9 2c 01 00 00 ff                         cmp dword ptr [rcx + 0x12c], -1
0262BE94  75 49                                        jne 0x262bedf
0262BE96  48 8b 05 5b 1c 6f 03                         mov rax, qword ptr [rip + 0x36f1c5b]
0262BE9D  48 85 c0                                     test rax, rax
0262BEA0  74 23                                        je 0x262bec5
0262BEA2  8b ca                                        mov ecx, edx
0262BEA4  81 e1 ff ff ff 00                            and ecx, 0xffffff
0262BEAA  3b 48 2c                                     cmp ecx, dword ptr [rax + 0x2c]
0262BEAD  73 16                                        jae 0x262bec5
0262BEAF  48 03 c9                                     add rcx, rcx
0262BEB2  48 8b 40 20                                  mov rax, qword ptr [rax + 0x20]
0262BEB6  48 8b 44 c8 08                               mov rax, qword ptr [rax + rcx*8 + 8]
0262BEBB  48 85 c0                                     test rax, rax
0262BEBE  74 05                                        je 0x262bec5
0262BEC0  39 50 10                                     cmp dword ptr [rax + 0x10], edx
0262BEC3  74 07                                        je 0x262becc
0262BEC5  48 8b 05 14 1c 6f 03                         mov rax, qword ptr [rip + 0x36f1c14]
0262BECC  8b 90 28 01 00 00                            mov edx, dword ptr [rax + 0x128]
0262BED2  eb 10                                        jmp 0x262bee4
0262BED4  8b 91 2c 01 00 00                            mov edx, dword ptr [rcx + 0x12c]
0262BEDA  83 fa ff                                     cmp edx, -1
0262BEDD  75 05                                        jne 0x262bee4
0262BEDF  ba ff ff ff ff                               mov edx, 0xffffffff
0262BEE4  48 8b 05 7d b6 63 03                         mov rax, qword ptr [rip + 0x363b67d]
0262BEEB  48 85 c0                                     test rax, rax
0262BEEE  74 23                                        je 0x262bf13
0262BEF0  8b ca                                        mov ecx, edx
0262BEF2  81 e1 ff ff ff 00                            and ecx, 0xffffff
0262BEF8  3b 48 2c                                     cmp ecx, dword ptr [rax + 0x2c]
0262BEFB  73 16                                        jae 0x262bf13
0262BEFD  48 03 c9                                     add rcx, rcx
0262BF00  48 8b 40 20                                  mov rax, qword ptr [rax + 0x20]
0262BF04  48 8b 74 c8 08                               mov rsi, qword ptr [rax + rcx*8 + 8]
0262BF09  48 85 f6                                     test rsi, rsi
0262BF0C  74 05                                        je 0x262bf13
0262BF0E  39 56 18                                     cmp dword ptr [rsi + 0x18], edx
0262BF11  74 07                                        je 0x262bf1a
0262BF13  48 8b 35 56 b6 63 03                         mov rsi, qword ptr [rip + 0x363b656]
0262BF1A  48 8b ce                                     mov rcx, rsi
0262BF1D  e8 ce 6e 29 00                               call 0x28c2df0
0262BF22  8b 48 40                                     mov ecx, dword ptr [rax + 0x40]
0262BF25  48 c1 e9 1a                                  shr rcx, 0x1a
0262BF29  f6 c1 01                                     test cl, 1
0262BF2C  75 1b                                        jne 0x262bf49
0262BF2E  0f 57 c0                                     xorps xmm0, xmm0
0262BF31  0f 11 03                                     movups xmmword ptr [rbx], xmm0
0262BF34  0f 11 43 10                                  movups xmmword ptr [rbx + 0x10], xmm0
0262BF38  0f 11 43 20                                  movups xmmword ptr [rbx + 0x20], xmm0
0262BF3C  0f 11 43 30                                  movups xmmword ptr [rbx + 0x30], xmm0
0262BF40  0f 11 43 40                                  movups xmmword ptr [rbx + 0x40], xmm0
0262BF44  e9 40 01 00 00                               jmp 0x262c089
0262BF49  40 84 ed                                     test bpl, bpl
0262BF4C  75 65                                        jne 0x262bfb3
0262BF4E  83 7f 28 ff                                  cmp dword ptr [rdi + 0x28], -1
0262BF52  75 48                                        jne 0x262bf9c
0262BF54  48 8b cf                                     mov rcx, rdi
0262BF57  e8 c4 0f 00 00                               call 0x262cf20
0262BF5C  84 c0                                        test al, al
0262BF5E  75 25                                        jne 0x262bf85
0262BF60  48 8b 86 c0 01 00 00                         mov rax, qword ptr [rsi + 0x1c0]
0262BF67  48 85 c0                                     test rax, rax
0262BF6A  74 19                                        je 0x262bf85
0262BF6C  40 38 a8 a9 04 00 00                         cmp byte ptr [rax + 0x4a9], bpl
0262BF73  74 10                                        je 0x262bf85
0262BF75  48 8d 57 18                                  lea rdx, [rdi + 0x18]
0262BF79  48 8b cf                                     mov rcx, rdi
0262BF7C  e8 5f 07 00 00                               call 0x262c6e0
0262BF81  84 c0                                        test al, al
0262BF83  75 17                                        jne 0x262bf9c
0262BF85  41 b0 02                                     mov r8b, 2
0262BF88  45 0f b6 ce                                  movzx r9d, r14b
0262BF8C  48 8b d3                                     mov rdx, rbx
0262BF8F  48 8b cf                                     mov rcx, rdi
0262BF92  e8 79 fe ff ff                               call 0x262be10
0262BF97  e9 ed 00 00 00                               jmp 0x262c089
0262BF9C  41 b0 01                                     mov r8b, 1
0262BF9F  45 0f b6 ce                                  movzx r9d, r14b
0262BFA3  48 8b d3                                     mov rdx, rbx
0262BFA6  48 8b cf                                     mov rcx, rdi
0262BFA9  e8 62 fe ff ff                               call 0x262be10
0262BFAE  e9 d6 00 00 00                               jmp 0x262c089
0262BFB3  83 bf 30 01 00 00 ff                         cmp dword ptr [rdi + 0x130], -1
0262BFBA  74 0d                                        je 0x262bfc9
0262BFBC  83 bf 2c 01 00 00 ff                         cmp dword ptr [rdi + 0x12c], -1
0262BFC3  75 04                                        jne 0x262bfc9
0262BFC5  b1 01                                        mov cl, 1
0262BFC7  eb 02                                        jmp 0x262bfcb
0262BFC9  32 c9                                        xor cl, cl
0262BFCB  4c 8b 97 18 01 00 00                         mov r10, qword ptr [rdi + 0x118]
0262BFD2  48 63 87 28 01 00 00                         movsxd rax, dword ptr [rdi + 0x128]
0262BFD9  4c 69 c8 a0 86 01 00                         imul r9, rax, 0x186a0
0262BFE0  88 4c 24 20                                  mov byte ptr [rsp + 0x20], cl
0262BFE4  4c 8b c6                                     mov r8, rsi
0262BFE7  49 8b ca                                     mov rcx, r10
0262BFEA  40 80 fd 01                                  cmp bpl, 1
0262BFEE  75 0f                                        jne 0x262bfff
0262BFF0  48 8d 94 24 80 00 00 00                      lea rdx, [rsp + 0x80]
0262BFF8  e8 13 15 a9 00                               call 0x30bd510
0262BFFD  eb 0d                                        jmp 0x262c00c
0262BFFF  48 8d 94 24 d0 00 00 00                      lea rdx, [rsp + 0xd0]
0262C007  e8 b4 13 a9 00                               call 0x30bd3c0
0262C00C  0f 10 00                                     movups xmm0, xmmword ptr [rax]
0262C00F  0f 29 44 24 30                               movaps xmmword ptr [rsp + 0x30], xmm0
0262C014  0f 10 48 10                                  movups xmm1, xmmword ptr [rax + 0x10]
0262C018  0f 29 4c 24 40                               movaps xmmword ptr [rsp + 0x40], xmm1
0262C01D  0f 10 50 20                                  movups xmm2, xmmword ptr [rax + 0x20]
0262C021  0f 29 54 24 50                               movaps xmmword ptr [rsp + 0x50], xmm2
0262C026  0f 10 58 30                                  movups xmm3, xmmword ptr [rax + 0x30]
0262C02A  0f 29 5c 24 60                               movaps xmmword ptr [rsp + 0x60], xmm3
0262C02F  0f 10 60 40                                  movups xmm4, xmmword ptr [rax + 0x40]
0262C033  0f 29 64 24 70                               movaps xmmword ptr [rsp + 0x70], xmm4
0262C038  45 84 f6                                     test r14b, r14b
0262C03B  75 39                                        jne 0x262c076
0262C03D  45 33 c0                                     xor r8d, r8d
0262C040  48 8b d6                                     mov rdx, rsi
0262C043  48 8d 8c 24 40 01 00 00                      lea rcx, [rsp + 0x140]
0262C04B  e8 c0 54 a9 00                               call 0x30c1510
0262C050  48 8b 10                                     mov rdx, qword ptr [rax]
0262C053  48 8d 4c 24 30                               lea rcx, [rsp + 0x30]
0262C058  e8 33 95 28 ff                               call 0x18b5590
0262C05D  0f 28 64 24 70                               movaps xmm4, xmmword ptr [rsp + 0x70]
0262C062  0f 28 5c 24 60                               movaps xmm3, xmmword ptr [rsp + 0x60]
0262C067  0f 28 54 24 50                               movaps xmm2, xmmword ptr [rsp + 0x50]
0262C06C  0f 28 4c 24 40                               movaps xmm1, xmmword ptr [rsp + 0x40]
0262C071  0f 28 44 24 30                               movaps xmm0, xmmword ptr [rsp + 0x30]
0262C076  0f 11 03                                     movups xmmword ptr [rbx], xmm0
0262C079  0f 11 4b 10                                  movups xmmword ptr [rbx + 0x10], xmm1
0262C07D  0f 11 53 20                                  movups xmmword ptr [rbx + 0x20], xmm2
0262C081  0f 11 5b 30                                  movups xmmword ptr [rbx + 0x30], xmm3
0262C085  0f 11 63 40                                  movups xmmword ptr [rbx + 0x40], xmm4
0262C089  48 8b c3                                     mov rax, rbx
0262C08C  4c 8d 9c 24 20 01 00 00                      lea r11, [rsp + 0x120]
0262C094  49 8b 5b 28                                  mov rbx, qword ptr [r11 + 0x28]
0262C098  49 8b 6b 30                                  mov rbp, qword ptr [r11 + 0x30]
0262C09C  49 8b e3                                     mov rsp, r11
0262C09F  41 5e                                        pop r14
0262C0A1  5f                                           pop rdi
0262C0A2  5e                                           pop rsi
0262C0A3  c3                                           ret 
