"""One source-proved262BE10 uniqueunchainedextent; no callee or neighbor code."""
from pathlib import Path
import capstone
from capstone.x86 import X86_OP_IMM
import datetime as dt,hashlib,json,struct,sys,time,gzip
R=Path(__file__).resolve().parent
TARGET=0x262BE10
def need(ok,message):
 if not ok:raise ValueError(message)
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def stat(p):
 s=p.stat();return dict(bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,device=s.st_dev,inode=s.st_ino)
def new(name,j):
 data=(j if isinstance(j,str) else json.dumps(j,separators=(',',':'))+'\n').encode('utf-8')
 if name in ['actual-function.asm','BRANCHES.actual.json']:
  with (R/(name+'.gz')).open('xb') as f:f.write(gzip.compress(data,mtime=0))
 else:
  with (R/name).open('xb') as f:f.write(data)
def main():
 check=load(R/'PLAN-CHECK.actual.json');need(check['result']=='plan-consistent','Pre-readplanmustpass')
 plan=load(R/'plan-a01.json');need(check['plan_sha256']==pin(R/'plan-a01.json')['sha256'],'Planchecknotbound')
 layout=load(plan['layout_receipt']);identity=load(plan['identity_receipt'])
 source=Path(identity['frozen_path']);before=stat(source);frozen=layout['frozen_metadata']
 need(identity['sha256']==plan['build']['exe_sha256'],'Exact4cachedSHAdiffers')
 need((before['bytes'],before['mtime_ns'],before['inode'])==(frozen['bytes'],frozen['mtime_ns'],frozen['inode']),'Frozenqualifiedinputchanged')
 reads=[];metadata=0;code=0;started=time.monotonic()
 try:
  with source.open('rb') as f:
   def read(rva,count,kind,why):
    nonlocal metadata,code
    need(time.monotonic()-started<30 and len(reads)<48,'Read/wallbound')
    if kind=='code':need(code+count<=8192,'Codebound');code+=count
    else:need(metadata+count<=512,'Metadatabound');metadata+=count
    s=next(s for s in layout['sections'] if s['va']<=rva<rva+count<=s['va']+s['rawsize'])
    off=s['raw']+rva-s['va'];f.seek(off);b=f.read(count);need(len(b)==count,'Shortboundedread')
    reads.append(dict(rva=rva,file_offset=off,bytes=count,kind=kind,why=why,hex=b.hex() if kind=='metadata' else None,sha256=hashlib.sha256(b).hexdigest()))
    return b
   ex=layout['exception_directory'];entries={}
   def entry(i):
    need(0<=i<ex['entries'],'Exceptionindexbound')
    if i not in entries:entries[i]=struct.unpack('<III',read(ex['rva']+i*12,12,'metadata','Exact262BE10.pdata binarysearch/uniquenessonly'))
    return entries[i]
   lo,hi=0,ex['entries']
   while lo<hi:
    mid=(lo+hi)//2
    if entry(mid)[0]<=TARGET:lo=mid+1
    else:hi=mid
   index=lo-1;begin,end,unwind=entry(index)
   need(begin==TARGET and begin<end,'Entrynotexactuniquetarget')
   if index>0:need(entry(index-1)[0]<begin and entry(index-1)[1]<=begin,'Previous.pdata overlaps/duplicates')
   if index+1<ex['entries']:need(entry(index+1)[0]>=end,'Next.pdata overlaps')
   header=read(unwind,4,'metadata','Onlyactualtargetunwindversion/flags/count')
   version=header[0]&7;flags=header[0]>>3
   need(version==1,'Unrecognizedunwindversion;stopbeforebody')
   need(not flags&4,'CHAININFO;uniquefullfunctionnotclosed;stopbeforebody')
   need(0<end-begin<=8192,'Uniqueextentexceeds8192;stopbeforebody')
   body=read(begin,end-begin,'code','Entiresoledeclared262BE10.pdataextent;nocaller/callee/neighborcode')
  after=stat(source);need(before==after,'Frozeninputchangedduringread')
  with (R/'actual-function.bin').open('xb') as f:f.write(body)
  dis=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64);dis.detail=True
  ins=list(dis.disasm(body,begin));need(sum(i.size for i in ins)==len(body),'Fullcontinuousdecodefailed;retaincapturedbody')
  new('actual-function.asm','\n'.join(f'{i.address:08X}  {i.bytes.hex(" "):<44} {i.mnemonic} {i.op_str}' for i in ins)+'\n')
  boundaries={i.address for i in ins};branches=[];calls=[]
  for i in ins:
   if i.mnemonic=='call':
    calls.append(dict(at_rva=i.address,bytes=i.bytes.hex(),target_rva=i.operands[0].imm if i.operands and i.operands[0].type==X86_OP_IMM else None,operands=i.op_str,expanded=False))
   if i.group(capstone.CS_GRP_JUMP):
    t=i.operands[0].imm if i.operands and i.operands[0].type==X86_OP_IMM else None
    internal=t is not None and begin<=t<end
    need(not internal or t in boundaries,'Internalbranchtargetnotinstructionboundary')
    branches.append(dict(at_rva=i.address,bytes=i.bytes.hex(),mnemonic=i.mnemonic,operands=i.op_str,target_rva=t,internal=internal,target_on_instruction_boundary=t in boundaries if internal else None,external_target_expanded=False))
  new('BRANCHES.actual.json',dict(machine_id=plan['machine_id'],at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),function_begin_rva=begin,function_end_exclusive=end,branch_count=len(branches),branches=branches,external_calls=calls,scope='Allbranchinstructionsincompleteuniqueextent;semanticbranchcontracttobewrittenfromtheseoriginals',callee_reads=0))
  new('READ-RECEIPT.actual.json',dict(status='FULL_SOLE_UNCHAINED_FUNCTION_CAPTURED',machine_id=plan['machine_id'],at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),plan=pin(R/'plan-a01.json'),plan_check=pin(R/'PLAN-CHECK.actual.json'),identity=pin(plan['identity_receipt']),layout=pin(plan['layout_receipt']),upstream_caller=plan['evidence'][2],qualified_EXE_SHA_reused_not_rehashed=identity['sha256'],source=str(source),stat_before=before,stat_after=after,tool_argv=sys.argv,python=sys.executable,capstone_version=capstone.__version__,function=dict(begin_rva=begin,end_exclusive=end,bytes=len(body),pdata_index=index,unwind_rva=unwind,unwind_header_hex=header.hex(),unwind_version=version,flags=flags,chained_runtime_function=None,sha256=hashlib.sha256(body).hexdigest(),instruction_count=len(ins)),read_ledger=reads,new_EXE_code_bytes=code,new_EXE_metadata_bytes=metadata,new_EXE_read_calls=len(reads),whole_EXE_hashes=0,global_scans=0,callee_reads=0,SDK_game_desktop_main_build_actions=0,maintenance_attribution='unclosed'))
  print(json.dumps(dict(status='FULL',begin=hex(begin),end=hex(end),code_bytes=code,metadata_bytes=metadata,reads=len(reads),instruction_count=len(ins),branches=len(branches),calls=calls)))
  return 0
 except Exception as e:
  new('STOPPED.actual.json',dict(machine_id=plan['machine_id'],error=repr(e),at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),read_ledger=reads,code_bytes=code,metadata_bytes=metadata,read_calls=len(reads),further_reads_stopped=True,scope_not_expanded=True,maintenance_attribution='unclosed'))
  raise
if __name__=='__main__':raise SystemExit(main())
