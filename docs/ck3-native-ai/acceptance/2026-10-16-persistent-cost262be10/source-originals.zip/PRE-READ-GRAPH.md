# Research plan: R08-exact4-Regi-tenresource-cost262BE10

GENERATED from the supplied research plan; no native semantics are inferred.

Question: What sources/branches buildpersistentRegi tenresourcecost; which actualR8b/R9b branches apply; whether nativecount/4A9switch orsettlementc/dedgeappears?

```mermaid
flowchart TD
    n0["SixactualheldRegicostcalls"]
    n1["Unknown262BE10completebody"]
    n2["Settlementfourraw/paidrelationunknown"]
    n0 -->|"call [static-confirmed] ActualCALL/argumentbranches"| n1
    n1 -. "relation [unknown] Count/switch/feeproducerboundary" .-> n2
```

| Edge | Declared status | Evidence IDs | Open question |
|---|---|---|---|
| call | static-confirmed | caller, callcontract |  |
| relation | unknown | upstreamcontract | Does anytypedsourcecreatecost orsettlementrawedge? No paidclaimfromfieldnames. |

| Observation design | Value |
|---|---|
| mode | offline-only |
| actor_kind | engine |
| owner_scope | Static262BE10function andexistingRegi/out80 callABI only; no liveprocessmemory |
| identity_kind | definition-key |
| identity_lifetime | Immutable source exact4 only; no runtime eligibility |
| producer_trigger | not-applicable |
| producer | Unknowncostvectorfunction262BE10 |
| caller | Sixhelda07/a08directcalls withRCX=Regi,RDX=out80,R8b/R9b=(0,1)or(1,0) |
| consumer | Calleradds tenresources andmayseparatelyfactor slot0; no source-to-paid orsettlementc/d inference |
| cache_lifetime | Current staticcostcalculation only; realcashcadence/paidperiod/cacheepoch unknown |
| expected_signal | Onlyuniqueunchainedfull262BE10function; argumentregister/branch/count/vectorlineage; externalcalleesunexpanded |
| zero_sample_meaning | Staticfunctioncapture hasno livepaymentsample; noabsenceorpaidclaim |
| stop_condition | Onlytarget262BE10.pdata binarysearch; metadata&lt;=512B/read&lt;=48; exactbegin/uniqueunchainedextent&lt;=8192B beforebody. No automaticcallee/xref/newpointer/wholehash/EXEexecution/SDK/game/desktop/build/main. |
| runtime_window_ref | None |

| Evidence ID | Declared layer | File | SHA-256 | Supports |
|---|---|---|---|---|
| identity | exact-build | C:\ck3-e04-resume-20261015-a01\frozen-game-12004\IDENTITY.actual.json | 15ad8093ca23930d7d440752518d3ce89097dec1b00fe234a5115011782b62b9 | Rootfrozen actual4inputSHA; no rehash |
| layout | exact-build | C:\ck3-e04-resume-20261015-a01\maintenance-parent-r0174-a01\parent28F7939-source-a01\inputs\pe-layout-reused.json | 9f0f3da5fcaf809b8fad13c4310d6abdf3c5a06d98aad113e907ee64c15e7bb4 | Existingsectionmapping andexceptiondirectoryonly |
| caller | source-contract | C:\ck3-e04-resume-20261015-a01\r08-vector-context2C14D70-source-a08\actual-function.asm.gz | 900c91b348fe0bd32674ba215af4bd67365a9af064014f17782083cc28277d31 | Compressedheld613Bcallerfullasm; threeactual262BE10calls |
| callcontract | source-contract | C:\ck3-e04-resume-20261015-a01\r08-regi-cost262BE10-source-a09\UPSTREAM-CALLS.actual.json | a45186e3ce9e81954b3f9ba3d359d2b9e345a977db661a4b98edd14678f244fd | SixactualcallinstructionsandprecedingABIargumentwrites |
| upstreamcontract | source-contract | C:\ck3-e04-resume-20261015-a01\r08-vector-context2C14D70-source-a08\SOURCE-CONTRACT.actual.json | 1e8470164a208a3b169af4a33ed4eee061d702f71d6df7838b032620ea6e0da0 | Callerclosure/currentpermission/offsetreceiverboundaries |

Check result (file integrity and declarations only):

```json
{
  "schema": "xar.native-research-plan-check.v1",
  "result": "plan-consistent",
  "proof_layer": "record-structure-and-file-integrity",
  "semantic_correctness_verified": false,
  "live_execution_performed": false,
  "observation_plan_issues": [
    "offline-only plan does not define a live observation window",
    "the real producer trigger must be located before live sampling"
  ],
  "declared_edges_by_status": {
    "counter-policy": 0,
    "inference": 0,
    "live-confirmed": 0,
    "static-confirmed": 1,
    "unknown": 1
  },
  "enumerated_native_edges": 2,
  "declared_cases_by_status": {
    "pending": 1,
    "observed": 0,
    "not-applicable": 0
  },
  "checked_evidence_files": 5,
  "limitations": [
    "Evidence layers and conclusions are author declarations; hashes bind bytes, not their truth.",
    "Counts cover this enumerated graph only, not all CK3 branches.",
    "A consistent observation plan is not authorization to run or manipulate CK3."
  ],
  "plan_sha256": "c69337a05f1a2df7d548595f72897c2ab57d069fd5bff30275a1005670abb2d2"
}
```
