from pathlib import Path
import hashlib
import json
import shutil
import subprocess

REPO=Path('C:/workspace/ck3_eternal_recurrence')
OUT=Path('C:/workspace/ck3_lyd_runtime_20261004/r41-reviewer-fixture-integration-20261010-001')
SHA='70908433bc4c3d284cfe5dcd0cc96007b96b3cd1'
FILES=['tools/test_ck3_mod_acceptance_normal_close.py','tools/test_ck3_mod_acceptance_operator_quit.py',
       'tools/test_ck3_mod_acceptance_poll_reporting.py','tools/ck3_mod_acceptance_client.py',
       'tools/ck3_mod_acceptance.py']
head=subprocess.run(['git','rev-parse','HEAD'],cwd=REPO,capture_output=True,check=True).stdout.decode('ascii').strip()
if head!=SHA:raise RuntimeError('unexpected integration HEAD')
OUT.mkdir(exist_ok=False)
rows=[]
for relative in FILES:
    path=REPO/relative
    data=path.read_bytes()
    blob=subprocess.run(['git','show',SHA+':'+relative],cwd=REPO,capture_output=True,check=True).stdout
    if data!=blob:raise RuntimeError('before file differs from exact integration blob')
    target=OUT/'before-sources'/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(path,target)
    rows.append({'path':relative,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(OUT/'BEFORE.actual.json').write_text(json.dumps({'source_head':head,'files':rows},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'output':str(OUT),'source_head':head,'files':len(rows)}))
