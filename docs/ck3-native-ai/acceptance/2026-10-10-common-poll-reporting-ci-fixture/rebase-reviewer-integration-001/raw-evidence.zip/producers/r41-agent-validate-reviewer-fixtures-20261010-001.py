from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

REPO=Path('C:/workspace/ck3_eternal_recurrence')
OUT=Path('C:/workspace/ck3_lyd_runtime_20261004/r41-reviewer-fixture-integration-20261010-001')
BEFORE=json.loads((OUT/'BEFORE.actual.json').read_text(encoding='utf-8'))


def pin(path):
    data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


def execute(item):
    label,pattern,count=item
    target=OUT/label
    target.mkdir(exist_ok=False)
    command=[sys.executable,'-B','-X','utf8','-m','unittest','discover','-s','tools','-p',pattern]
    env=dict(os.environ)
    env['PYTHONDONTWRITEBYTECODE']='1'
    started=datetime.now(timezone.utc).isoformat()
    result=subprocess.run(command,cwd=REPO,env=env,capture_output=True,timeout=120)
    finished=datetime.now(timezone.utc).isoformat()
    (target/'stdout.log').write_bytes(result.stdout)
    (target/'stderr.log').write_bytes(result.stderr)
    actual={'schema':'ck3-recorded-actual-command-v1','argv':command,'cwd':str(REPO),
        'source_head_before_commit':BEFORE['source_head'],'started_at_utc':started,'finished_at_utc':finished,
        'exit_code':result.returncode,'tests':count,'stdout':pin(target/'stdout.log'),'stderr':pin(target/'stderr.log')}
    (target/'RESULT.actual.json').write_text(json.dumps(actual,indent=2)+'\n',encoding='utf-8',newline='\n')
    text=result.stderr.decode('utf-8').replace('\r\n','\n')
    if result.returncode or f'Ran {count} tests' not in text or '\nOK\n' not in text:
        raise RuntimeError(label+' failed; inspect preserved receipt')
    return label,actual


with ThreadPoolExecutor(max_workers=2) as executor:
    results=dict(executor.map(execute,[('normal-close-after','test_ck3_mod_acceptance_normal_close.py',4),
                                      ('operator-quit-after','test_ck3_mod_acceptance_operator_quit.py',16)]))
after=[]
for row in BEFORE['files']:
    relative=row['path']
    source=REPO/relative
    current=pin(source)
    if relative in ('tools/ck3_mod_acceptance_client.py','tools/ck3_mod_acceptance.py','tools/test_ck3_mod_acceptance_poll_reporting.py'):
        if current['sha256']!=row['sha256']:raise RuntimeError('unowned source changed: '+relative)
    target=OUT/'after-sources'/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    after.append({'path':relative,'bytes':current['bytes'],'sha256':current['sha256']})
actual={'schema':'ck3.rebased-reviewer-fixture-validation.v1','source_head_before_commit':BEFORE['source_head'],
    'results':results,'source_pins':after,'production_client_and_entry_unchanged':True,
    'poll_reporting_fixture_unchanged':True,'actual_reviewer_resolver_and_pin_checks_executed':True,
    'ck3_or_steam_started':False,'screen_or_bus_acquired':False,'total_passed_tests':20}
(OUT/'RESULT.actual.json').write_text(json.dumps(actual,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'status':'PASS','source_head_before_commit':BEFORE['source_head'],'tests':20,'output':str(OUT)}))
