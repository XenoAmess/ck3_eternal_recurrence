from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import zipfile

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
REPO=Path('C:/workspace/ck3_eternal_recurrence')
SOURCE=BASE/'r41-reviewer-fixture-integration-20261010-001'
KEY='2026-10-10-common-poll-reporting-ci-fixture'
OUT=REPO/'docs/ck3-native-ai/acceptance'/KEY/'rebase-reviewer-integration-001'
SHA='70908433bc4c3d284cfe5dcd0cc96007b96b3cd1'


def digest(data):return hashlib.sha256(data).hexdigest()
def load(path):return json.loads(path.read_text(encoding='utf-8'))
def pin(path):
    data=path.read_bytes()
    return {'bytes':len(data),'sha256':digest(data)}
def write_json(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2)
        stream.write('\n')


before=load(SOURCE/'BEFORE.actual.json')
after=load(SOURCE/'RESULT.actual.json')
if before['source_head']!=SHA or after['source_head_before_commit']!=SHA or after['total_passed_tests']!=20:
    raise RuntimeError('integration source/test binding differs')
root_dirs={
    'root-rebase':'r41-root-publication-rebase-20261010-001',
    'root-rebase-continue':'r41-root-publication-rebase-continue-20261010-001',
    'root-poll-reporting-pass':'r41-root-poll-reporting-rebased-20261010-001',
    'normal-close-before':'r41-root-remote-closure-check-20261010-003',
    'operator-quit-before':'r41-root-remote-closure-check-20261010-004',
}
receipts={}
for label,name in root_dirs.items():
    directory=BASE/name
    actual=load(directory/'RESULT.actual.json')
    for stream in ('stdout','stderr'):
        path=directory/(stream+'.log')
        if pin(path)!={key:actual[stream][key] for key in ('bytes','sha256')}:
            raise RuntimeError('root receipt raw bytes mismatch: '+label)
    receipts[label]=actual
if receipts['normal-close-before']['exit_code']!=1 or receipts['operator-quit-before']['exit_code']!=1:
    raise RuntimeError('original integration failure differs')
if receipts['root-poll-reporting-pass']['exit_code']!=0:
    raise RuntimeError('existing rebased poll test receipt not PASS')
failure_counts={}
for label in ('normal-close-before','operator-quit-before'):
    stderr=(BASE/root_dirs[label]/'stderr.log').read_text(encoding='utf-8')
    if "AttributeError: 'types.SimpleNamespace' object has no attribute 'context'" not in stderr:
        raise RuntimeError('actual original error differs')
    failure_counts[label]={'tests':int(re.search(r'Ran (\d+) tests',stderr).group(1)),
                           'errors':int(re.search(r'FAILED \(errors=(\d+)\)',stderr).group(1))}
for relative in ('tools/ck3_mod_acceptance_client.py','tools/ck3_mod_acceptance.py','tools/test_ck3_mod_acceptance_poll_reporting.py'):
    original=SOURCE/'before-sources'/relative
    if original.read_bytes()!=(REPO/relative).read_bytes():
        raise RuntimeError('unowned production or poll source changed')

inputs=[]
for path in sorted(SOURCE.rglob('*')):
    if path.is_file():inputs.append(('fixture-integration/'+path.relative_to(SOURCE).as_posix(),path))
for label,name in root_dirs.items():
    for filename in ('RESULT.actual.json','stdout.log','stderr.log'):
        inputs.append((label+'/'+filename,BASE/name/filename))
for filename in ('r41-agent-snapshot-reviewer-fixtures-20261010-001.py',
                 'r41-agent-validate-reviewer-fixtures-20261010-001.py',Path(__file__).name):
    inputs.append(('producers/'+filename,BASE/filename))
if len(inputs)!=len({name for name,_ in inputs}):raise RuntimeError('archive name duplicate')
OUT.mkdir(exist_ok=False)
archive_path=OUT/'raw-evidence.zip'
entries=[]
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,path in sorted(inputs):
        data=path.read_bytes()
        info=zipfile.ZipInfo(name,date_time=(2026,10,10,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o100644<<16
        archive.writestr(info,data)
        entries.append({'path':name,'source_path':str(path),'bytes':len(data),'sha256':digest(data)})
archive_pin={'path':'raw-evidence.zip',**pin(archive_path)}
with zipfile.ZipFile(archive_path) as archive:
    if archive.testzip() is not None:raise RuntimeError('ZIP CRC failed')
    if set(archive.namelist())!={row['path'] for row in entries}:raise RuntimeError('ZIP inventory differs')
    for row in entries:
        data=archive.read(row['path'])
        if len(data)!=row['bytes'] or digest(data)!=row['sha256'] or data!=Path(row['source_path']).read_bytes():
            raise RuntimeError('ZIP bytes differ')
write_json(OUT/'INDEX.json',{'schema':'ck3.rebased-reviewer-fixture-archive.v1',
    'archived_at_utc':datetime.now(timezone.utc).isoformat(),'source_head_before_commit':SHA,
    'archive':archive_pin,'entries':entries})
write_json(OUT/'ARCHIVE-VALIDATION.actual.json',{'schema':'ck3.raw-evidence-archive-validation.v1',
    'status':'PASS','archive':archive_pin,'checked_entries':len(entries),'crc':'PASS',
    'all_source_and_archived_bytes_match':True,'all_source_and_archived_sha256_match':True,
    'original_ci_archive_repackaged':False})
write_json(OUT/'RESULT.actual.json',{'schema':'ck3.rebased-reviewer-fixture-fix.v1',
    'source_head_before_commit':SHA,'root_rebased_original_commit':'c5bb3800b9db9cd955e9916bbee4e22ad2f72cf1',
    'remote_supervisor_thread_fixture_retained':True,'existing_rebased_poll_tests':6,
    'existing_rebased_poll_exit_code':0,'poll_test_not_rerun_by_this_work_package':True,
    'root_existing_receipts_have_no_embedded_source_pins':True,
    'original_error':"AttributeError: 'types.SimpleNamespace' object has no attribute 'context'",
    'original_test_results':failure_counts,
    'normal_close_after':{'tests':4,'exit_code':0},'operator_quit_after':{'tests':16,'exit_code':0},
    'total_new_passed_tests':20,'source_pins':after['source_pins'],
    'selection_context_is_client_context_asserted':True,'actual_reviewer_resolver_and_check_pin_executed':True,
    'existing_wrong_reviewer_run_screen_delegation_scope_assertions_preserved':True,
    'production_client_and_entry_unchanged':True,'no_reviewer_resolver_mock_or_fallback_added':True,
    'real_game_or_screen_process_started':False,'new_official_ci_success_claimed':False,
    'original_ci_archive_repackaged':False,'raw_evidence':archive_pin})
report_path=REPO/'docs/ck3-native-ai'/(KEY+'.md')
addition=f'''
## Rebase 后 reviewer 测试夹具补充（2026-10-10）

Root 将原 `c5bb3800b` 线性 rebase 至远端更新后，实际集成 HEAD 为 `{SHA}`。
同一 namespace 的冲突保留远端 `supervisor=threading.Thread()`；Root 已有的 6 项
poll-reporting 测试实际通过回执随本补充封存，本工作包没有重跑该组。
原精确 `6a3` CI 失败和之前 `supervisor=None` 候选回执保持历史原样。

远端 reviewer resolver 开始校验持久化 allocated context、exact frozen argv pin、
run/argv/environment 及委托来源。集成检查发现 normal-close 与 operator-quit 旧夹具
仅有 `client.context`，缺少 `selection.context`，均触发同一 `AttributeError`。
原回执为 normal-close {failure_counts['normal-close-before']['tests']} 项测试 / {failure_counts['normal-close-before']['errors']} 个 ERROR
（含 subtest）、operator-quit {failure_counts['operator-quit-before']['tests']} 项测试 / {failure_counts['operator-quit-before']['errors']} 个 ERROR。

本次只补齐两份测试夹具：共享 normal-close fixture 提供同一 context 对象、持久化 context、
真实可核 frozen pin、run_dir、argv 及 environment；operator fixture 在冻结前传入其
screen/environment。测试实际执行生产 resolver 和 pin 检查，没有 mock resolver 或添加 fallback。
保留错误 reviewer 与跨 run/screen/authority/scope 拒绝断言，并检查 context 对象身份与真实解析的 reviewer。
生产 client、entry 与最终 poll fixture 的 SHA-256 均与集成基线一致。

修复后仅运行这两组原测试，各一次：`normal_close` **4/4**、`operator_quit` **16/16**，均 exit 0。
原 RED、新 PASS、Root rebase/continue 和已有 poll PASS 回执及源码 pins 见
[补充结果](acceptance/{KEY}/rebase-reviewer-integration-001/RESULT.actual.json) 与
[补充索引](acceptance/{KEY}/rebase-reviewer-integration-001/INDEX.json)。
新增 ZIP 为 {archive_pin['bytes']} bytes，SHA-256 `{archive_pin['sha256']}`，
全部 {len(entries)} 项 byte-exact / CRC PASS；未重复打包旧 CI 或 Source04。
这些静态测试结果不追认原 CI 成功，也不授公共 runtime 或产品实机 GREEN。
'''
with report_path.open('a',encoding='utf-8',newline='\n') as stream:stream.write(addition)
print(json.dumps({'archive':archive_pin,'entries':len(entries),'new_tests':20,
    'original_failure_counts':failure_counts,'report':str(report_path)},ensure_ascii=False))
