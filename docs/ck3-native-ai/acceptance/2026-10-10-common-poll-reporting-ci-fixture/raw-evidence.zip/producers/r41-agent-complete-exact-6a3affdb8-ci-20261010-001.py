"""Retain complete terminal logs and verify the exact-head observation bytes."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,io,json,subprocess,time,zipfile

OUT=Path('C:/workspace/ck3_lyd_runtime_20261004/r41-exact-6a3affdb8-ci-20261010-001')
SHA='6a3affdb87f03f01bdc9f4dc43aeff15960200db'
REPO='XenoAmess/ck3_eternal_recurrence'
final=json.loads((OUT/'FINAL.actual.json').read_text(encoding='utf-8'))
if final['head_sha']!=SHA or not final['triggered_workflows_terminal']:
    raise RuntimeError('Exact requested HEAD has not reached a proven terminal state')


def write(name,value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')


def api(endpoint,label,suffix):
    for attempt in range(1,4):
        name=label+'-retry-'+str(attempt).zfill(3)
        argv=['gh','api','repos/'+REPO+'/'+endpoint]
        started=datetime.now(timezone.utc).isoformat()
        try:
            r=subprocess.run(argv,cwd=OUT,capture_output=True,timeout=45)
            raw,err,code,error=r.stdout,r.stderr,r.returncode,None
        except subprocess.TimeoutExpired as exc:
            raw,err,code,error=exc.stdout or b'',exc.stderr or b'',None,'timeout_45_seconds'
        (OUT/(name+'.stdout.'+suffix)).write_bytes(raw)
        (OUT/(name+'.stderr.log')).write_bytes(err)
        write(name+'.actual.json',{'argv':argv,'started_at_utc':started,
            'finished_at_utc':datetime.now(timezone.utc).isoformat(),'exit_code':code,'error':error,
            'stdout_bytes':len(raw),'stdout_sha256':hashlib.sha256(raw).hexdigest(),
            'stderr_bytes':len(err),'stderr_sha256':hashlib.sha256(err).hexdigest()})
        if code==0:return name,raw
        print(json.dumps({'retry_label':name,'code':code,'stderr':err.decode(errors='replace')[:200]}),flush=True)
        if attempt<3:time.sleep(10)
    return None,None


workflows={}
for name,row in final['workflow_status'].items():
    if row['status']=='NOT_TRIGGERED':
        workflows[name]={'status':'NOT_TRIGGERED','not_counted_as_success':True}
        continue
    run=str(row['id']);label='terminal-'+run
    terminal_jobs=[]
    for path in sorted(OUT.glob('poll-*-jobs-'+run+'.stdout.json'),reverse=True):
        meta=json.loads(path.with_name(path.name.replace('.stdout.json','.actual.json')).read_text())
        if meta['exit_code']==0:
            packet=json.loads(path.read_bytes())
            if packet['total_count']==len(packet['jobs']) and all(job['status']=='completed' for job in packet['jobs']):
                terminal_jobs=packet['jobs'];break
    if not terminal_jobs:
        _,raw=api('actions/runs/'+run+'/jobs?per_page=100',label+'-jobs','json')
        if raw is not None:terminal_jobs=json.loads(raw)['jobs']
    archive_label,raw=api('actions/runs/'+run+'/logs',label+'-full-api-logs','zip')
    archive=None
    if raw is not None:
        with zipfile.ZipFile(io.BytesIO(raw)) as zipped:
            if zipped.testzip() is not None:raise RuntimeError('GitHub logs ZIP CRC mismatch')
            archive={'file':archive_label+'.stdout.zip','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
                     'entries':[{'path':item.filename,'bytes':item.file_size,
                                 'sha256':hashlib.sha256(zipped.read(item)).hexdigest()} for item in zipped.infolist()]}
        write(label+'-full-api-logs-index.actual.json',archive)
    workflows[name]={'id':row['id'],'status':row['status'],'conclusion':row['conclusion'],
        'html_url':row['html_url'],'head_sha':row['head_sha'],'full_log_archive':archive,
        'terminal_jobs':[{'id':job['id'],'name':job['name'],'status':job['status'],'conclusion':job['conclusion'],
                          'failed_steps':[step['name'] for step in job.get('steps',[]) if step.get('conclusion')=='failure'],
                          'shared_acceptance_steps':[{'name':step['name'],'status':step['status'],'conclusion':step['conclusion']}
                                                     for step in job.get('steps',[]) if 'shared CK3 acceptance' in step['name']]}
                         for job in terminal_jobs]}
    print(json.dumps({'terminal_evidence':name,'logs_retained':archive is not None,
                      'jobs':workflows[name]['terminal_jobs']}),flush=True)

verified=[]
for path in sorted(OUT.glob('*.actual.json')):
    value=json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(value,dict) or 'argv' not in value or 'stdout_sha256' not in value:continue
    prefix=path.name[:-len('.actual.json')]
    rawpaths=list(OUT.glob(prefix+'.stdout.*'))
    if len(rawpaths)!=1:raise RuntimeError('Raw stdout ambiguous: '+prefix)
    if hashlib.sha256(rawpaths[0].read_bytes()).hexdigest()!=value['stdout_sha256']:
        raise RuntimeError('Raw stdout changed: '+prefix)
    if hashlib.sha256((OUT/(prefix+'.stderr.log')).read_bytes()).hexdigest()!=value['stderr_sha256']:
        raise RuntimeError('Raw stderr changed: '+prefix)
    verified.append(prefix)
report={'schema':'ck3.exact-github-ci-terminal-evidence.v1','head_sha':SHA,
        'observed_at_utc':datetime.now(timezone.utc).isoformat(),'workflow_status':workflows,
        'original_query_pairs_byte_hash_verified':len(verified),'verified_query_labels':verified,
        'repository_mutation_performed':False,'workflow_dispatch_performed':False,
        'not_triggered_is_success':False,'product_live_pass_claimed':False}
write('TERMINAL-EVIDENCE.actual.json',report)
print(json.dumps({'complete':True,'output':str(OUT),'verified_query_pairs':len(verified)}),flush=True)
