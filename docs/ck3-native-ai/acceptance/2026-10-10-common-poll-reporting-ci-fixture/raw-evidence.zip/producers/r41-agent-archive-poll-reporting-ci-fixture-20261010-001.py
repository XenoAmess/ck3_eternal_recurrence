from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
REPO = Path('C:/workspace/ck3_eternal_recurrence')
CI = BASE / 'r41-exact-6a3affdb8-ci-20261010-001'
CANDIDATE = BASE / 'r41-poll-reporting-fixture-candidate-20261010-001'
APPLIED = BASE / 'r41-poll-reporting-fixture-repo-validation-20261010-001'
REL = 'tools/test_ck3_mod_acceptance_poll_reporting.py'
KEY = '2026-10-10-common-poll-reporting-ci-fixture'
OUT = REPO / 'docs/ck3-native-ai/acceptance' / KEY
SHA = '6a3affdb87f03f01bdc9f4dc43aeff15960200db'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write_json(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': digest(data)}


terminal = load(CI / 'TERMINAL-EVIDENCE.actual.json')
final = load(CI / 'FINAL.actual.json')
candidate = load(CANDIDATE / 'RESULT.actual.json')
applied = load(APPLIED / 'RESULT.actual.json')
if terminal['head_sha'] != SHA or final['head_sha'] != SHA or candidate['exact_source_head'] != SHA:
    raise RuntimeError('exact head binding differs')
workflows = terminal['workflow_status']
if workflows['Official Runner CI']['conclusion'] != 'failure' or workflows['Linear history']['conclusion'] != 'success':
    raise RuntimeError('actual terminal conclusions differ')
if workflows['Li Yu Dao static checks']['status'] != 'NOT_TRIGGERED':
    raise RuntimeError('unexpected Li Yu Dao workflow status')
if candidate['probe']['original']['returncode'] != 1 or candidate['probe']['candidate']['returncode'] or applied['returncode']:
    raise RuntimeError('before/candidate/applied test result differs')
if applied['test_file']['sha256'] != pin(REPO / REL)['sha256']:
    raise RuntimeError('applied test changed since actual validation')

query_pairs = []
for path in sorted(CI.glob('*.actual.json')):
    actual = load(path)
    if 'argv' not in actual or 'stdout_sha256' not in actual:
        continue
    stem = path.name.removesuffix('.actual.json')
    stdout = list(CI.glob(stem + '.stdout.*'))
    stderr = CI / (stem + '.stderr.log')
    if len(stdout) != 1 or not stderr.is_file():
        raise RuntimeError('raw query output pair missing: ' + stem)
    for item, label in ((stdout[0], 'stdout'), (stderr, 'stderr')):
        data = item.read_bytes()
        if len(data) != actual[label + '_bytes'] or digest(data) != actual[label + '_sha256']:
            raise RuntimeError('query bytes/hash mismatch: ' + str(item))
    if actual['exit_code']:
        raise RuntimeError('unexpected unsuccessful recorded query')
    query_pairs.append(path.name)
if len(query_pairs) != 31:
    raise RuntimeError('expected all 31 original query groups')

nested_zips = []
for path in sorted(CI.glob('*.zip')):
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('original workflow logs ZIP CRC failure')
        nested_zips.append({'file': path.name, **pin(path), 'entries': len(archive.infolist()), 'crc': 'PASS'})

inputs = []
for label, directory in (('exact-ci', CI), ('external-fixture-candidate', CANDIDATE), ('applied-repo-test', APPLIED)):
    inputs.extend((label + '/' + path.relative_to(directory).as_posix(), path)
        for path in sorted(directory.rglob('*')) if path.is_file())
for name in (
    'r41-agent-start-exact-6a3affdb8-ci-20261010-001.py',
    'r41-agent-watch-exact-6a3affdb8-ci-20261010-001.py',
    'r41-agent-complete-exact-6a3affdb8-ci-20261010-001.py',
    'r41-agent-produce-poll-reporting-fixture-candidate-20261010-001.py',
    'r41-agent-validate-poll-reporting-applied-20261010-001.py',
    Path(__file__).name,
):
    inputs.append(('producers/' + name, BASE / name))
if len({name for name, _ in inputs}) != len(inputs):
    raise RuntimeError('archive names collide')

OUT.mkdir(exist_ok=False)
zip_path = OUT / 'raw-evidence.zip'
entries = []
with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, source in sorted(inputs):
        data = source.read_bytes()
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 10, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, data)
        entries.append({'path': name, 'source_path': str(source), 'bytes': len(data), 'sha256': digest(data)})
archive_pin = {'path': 'raw-evidence.zip', **pin(zip_path)}
with zipfile.ZipFile(zip_path) as archive:
    if archive.testzip() is not None:
        raise RuntimeError('new archive CRC failure')
    if set(archive.namelist()) != {row['path'] for row in entries}:
        raise RuntimeError('new archive inventory mismatch')
    for row in entries:
        actual = archive.read(row['path'])
        if len(actual) != row['bytes'] or digest(actual) != row['sha256']:
            raise RuntimeError('new archive bytes mismatch')
        if actual != Path(row['source_path']).read_bytes():
            raise RuntimeError('new archive source differs')

write_json(OUT / 'INDEX.json', {'schema': 'ck3.common-poll-reporting-ci-fixture-archive.v1',
    'archived_at_utc': datetime.now(timezone.utc).isoformat(), 'source_ci_head': SHA,
    'archive': archive_pin, 'entries': entries})
write_json(OUT / 'ARCHIVE-VALIDATION.actual.json', {
    'schema': 'ck3.raw-evidence-archive-validation.v1', 'status': 'PASS',
    'archive': archive_pin, 'checked_entries': len(entries), 'crc': 'PASS',
    'all_source_and_archived_bytes_match': True, 'all_source_and_archived_sha256_match': True,
    'verified_actual_query_pairs': len(query_pairs), 'query_receipts': query_pairs,
    'original_complete_logs_zip_validation': nested_zips})
result = {'schema': 'ck3.common-poll-reporting-ci-fixture-fix.v1',
    'original_ci_head': SHA, 'original_official_run_id': 37995375811,
    'original_official_conclusion': 'failure', 'original_linear_run_id': 37995375808,
    'original_linear_history': 'success', 'original_li_yu_dao_static_checks': 'NOT_TRIGGERED',
    'original_failed_step': 'Test shared CK3 acceptance without installed CK3',
    'original_exception': "NameError: name 'supervisor' is not defined",
    'original_failed_test_count': 6, 'external_original_exit_code': 1,
    'external_candidate_tests': 6, 'external_candidate_exit_code': 0,
    'actual_repo_tests': 6, 'actual_repo_exit_code': 0,
    'actual_repo_command': applied['argv'], 'actual_repo_receipt': 'applied-repo-test/RESULT.actual.json',
    'fixed_test_source': pin(REPO / REL), 'unchanged_production_host': applied['host_file'],
    'fix': 'Supply supervisor=None in the AST-isolated test namespace, matching the real host initial closure value.',
    'actual_write_function_and_all_original_six_test_assertions_preserved': True,
    'real_game_or_screen_process_started': False, 'workflow_dispatch_performed': False,
    'new_official_ci_success_claimed': False, 'shared_runtime_or_product_green_claimed': False,
    'source04_runtime_repackaged': False,
    'open_kaishek_prevalidation': {'status': 'not-applicable',
        'reason': 'Python AST-isolated reporting fixture; no CK3 script, parser or gameplay semantics changed.'},
    'verified_actual_ci_query_pairs': len(query_pairs), 'raw_evidence': archive_pin}
write_json(OUT / 'RESULT.actual.json', result)
report_path = REPO / 'docs/ck3-native-ai' / (KEY + '.md')
report = f'''# 公共轮询报告的 CI 测试夹具修复（2026-10-10）

精确提交 `{SHA}` 的
[Official Runner CI 37995375811](https://github.com/XenoAmess/ck3_eternal_recurrence/actions/runs/37995375811)
在 `Test shared CK3 acceptance without installed CK3` 失败。
`tools/test_ck3_mod_acceptance_poll_reporting.py` 的 6 个测试均报
`NameError: name 'supervisor' is not defined`：测试经 AST 提取生产 host 的 `write()`，
但测试 namespace 没有提供该函数新增使用的闭包变量。
同一提交的 [Linear history 37995375808](https://github.com/XenoAmess/ck3_eternal_recurrence/actions/runs/37995375808)
成功；Li Yu Dao static checks 为 **NOT_TRIGGERED**，不计作成功。

生产 host 已在声明 `write()` 前初始化 `supervisor: threading.Thread | None = None`。
本次只给隔离测试 namespace 补入 `supervisor=None`，与该初始状态一致。
实际 `write()`、6 个原测试及断言继续执行；生产 host、清理及退出行为未改。

| 实际命令（Python 3.13，`-B -X utf8`） | 运行位置 | 结果 |
| --- | --- | --- |
| `tools/test_ck3_mod_acceptance_poll_reporting.py` | 精确 6a3 原文件外置副本 | 6 ERROR，exit 1，同 CI 异常 |
| 同上 | 单行修复外置候选 | 6 / 6 通过，exit 0 |
| 同上 | 应用修复后的本仓库路径 | 6 / 6 通过，exit 0 |

外置复现前，两个测试输入文件（test 与 host）都与精确 `6a3` 的 Git blob 字节核对一致；
本仓库确认时，测试文件与已验证候选逐字节一致，host 与原副本逐字节一致。
命令、时间、stdout/stderr、源码 pins 与真实返回码见
[实际结果](acceptance/{KEY}/RESULT.actual.json) 和
[证据索引](acceptance/{KEY}/INDEX.json)。

全部 {len(query_pairs)} 组原始 GitHub API/命令回执、终态 jobs、失败日志、两个 workflow 的完整日志 ZIP、
原版与候选测试输入及修复前后回执封存于 `raw-evidence.zip`（{archive_pin['bytes']} bytes，SHA-256
`{archive_pin['sha256']}`）。
[读回复验](acceptance/{KEY}/ARCHIVE-VALIDATION.actual.json)
确认全部 {len(entries)} 项 byte-exact、ZIP CRC 正常；原始日志经 ZIP 保留，避免 Git 文本换行归一化改变证据。
此包不重复封装 Source04 runtime。

本次未启动 CK3、Steam、keeper，未领取屏幕或写真实 run ID/admission。
这是 Python AST 测试夹具修复，`open_kaishek` 预验为 not-applicable。
本地通过不追认精确 `6a3` 的官方 CI 成功，也不授予公共 runtime 或产品实机 GREEN；
后续以新精确 master 的官方 CI 终态为准。历史失败与旧报告保留。
'''
with report_path.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(report)
print(json.dumps({'report': str(report_path), 'archive': archive_pin, 'entries': len(entries),
    'query_pairs': len(query_pairs), 'actual_repo_tests': 6, 'actual_repo_exit_code': 0}, ensure_ascii=False))
