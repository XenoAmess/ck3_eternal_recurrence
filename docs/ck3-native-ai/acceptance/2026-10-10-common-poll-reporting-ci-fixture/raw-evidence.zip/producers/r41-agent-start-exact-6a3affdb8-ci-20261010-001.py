"""Retarget preserved read-only observers to one new exact master head."""
from pathlib import Path
import subprocess
import sys

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
SHA='6a3affdb87f03f01bdc9f4dc43aeff15960200db'
OUTPUT='r41-exact-6a3affdb8-ci-20261010-001'
templates=[
    ('r40-agent-watch-exact-598d4855b-ci-20261010-001.py',
     'r41-agent-watch-exact-6a3affdb8-ci-20261010-001.py'),
    ('r40-agent-complete-exact-598d4855b-ci-20261010-001.py',
     'r41-agent-complete-exact-6a3affdb8-ci-20261010-001.py'),
]
for original,target in templates:
    source=(BASE/original).read_text(encoding='utf-8')
    if source.count('598d4855b1a5e7678fa2253e5664acb991c0c825')!=1 or source.count('r40-exact-598d4855b-ci-20261010-001')!=1:
        raise RuntimeError('Observer source no longer permits an exact unambiguous retarget')
    source=source.replace('598d4855b1a5e7678fa2253e5664acb991c0c825',SHA).replace('r40-exact-598d4855b-ci-20261010-001',OUTPUT)
    with (BASE/target).open('x',encoding='utf-8',newline='\n') as stream:stream.write(source)
raise SystemExit(subprocess.run([sys.executable,'-B','-X','utf8',str(BASE/templates[0][1])],cwd=BASE).returncode)
