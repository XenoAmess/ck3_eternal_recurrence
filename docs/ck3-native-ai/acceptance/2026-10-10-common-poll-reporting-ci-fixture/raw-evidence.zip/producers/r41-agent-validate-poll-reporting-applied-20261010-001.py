from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r41-poll-reporting-fixture-repo-validation-20261010-001'
REPO = Path('C:/workspace/ck3_eternal_recurrence')
REL = 'tools/test_ck3_mod_acceptance_poll_reporting.py'
HOST = 'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py'
CANDIDATE = BASE / 'r41-poll-reporting-fixture-candidate-20261010-001'
SHA = '6a3affdb87f03f01bdc9f4dc43aeff15960200db'


def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


OUT.mkdir(exist_ok=False)
head_result = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=REPO, capture_output=True, check=True)
head = head_result.stdout.decode('ascii').strip()
if head != SHA:
    raise RuntimeError('unexpected current HEAD')
if (REPO / REL).read_bytes() != (CANDIDATE / 'candidate' / REL).read_bytes():
    raise RuntimeError('applied file differs from verified candidate')
if (REPO / HOST).read_bytes() != (CANDIDATE / 'original' / HOST).read_bytes():
    raise RuntimeError('host differs from exact original source')
cmd = [sys.executable, '-B', '-X', 'utf8', REL]
env = dict(os.environ)
env['PYTHONDONTWRITEBYTECODE'] = '1'
started = datetime.now(timezone.utc).isoformat()
result = subprocess.run(cmd, cwd=REPO, capture_output=True, timeout=120, env=env)
finished = datetime.now(timezone.utc).isoformat()
(OUT / 'stdout.log').write_bytes(result.stdout)
(OUT / 'stderr.log').write_bytes(result.stderr)
actual = {'schema': 'ck3.focused-repo-test.actual.v1', 'source_head_before_commit': head,
    'argv': cmd, 'cwd': str(REPO), 'started_at_utc': started, 'finished_at_utc': finished,
    'returncode': result.returncode, 'test_file': pin(REPO / REL), 'host_file': pin(REPO / HOST),
    'stdout': pin(OUT / 'stdout.log'), 'stderr': pin(OUT / 'stderr.log'),
    'candidate_bytes_match': True, 'host_original_exact_bytes_match': True,
    'ck3_or_steam_started': False, 'screen_or_bus_acquired': False}
(OUT / 'RESULT.actual.json').write_text(json.dumps(actual, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(actual, ensure_ascii=False))
if result.returncode or b'Ran 6 tests' not in result.stderr or b'\nOK\n' not in result.stderr.replace(b'\r\n', b'\n'):
    raise RuntimeError('focused test failed')
