from __future__ import annotations

from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r41-poll-reporting-fixture-candidate-20261010-001'
REPO = Path('C:/workspace/ck3_eternal_recurrence')
SHA = '6a3affdb87f03f01bdc9f4dc43aeff15960200db'
TEST = 'tools/test_ck3_mod_acceptance_poll_reporting.py'
HOST = 'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py'
CI = BASE / 'r41-exact-6a3affdb8-ci-20261010-001'


def now():
    return datetime.now(timezone.utc).isoformat()


def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write_json(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def run_git(args):
    result = subprocess.run(['git', *args], cwd=REPO, capture_output=True, timeout=45)
    if result.returncode:
        raise RuntimeError(result.stderr.decode('utf-8', 'replace'))
    return result.stdout


OUT.mkdir(exist_ok=False)
head = run_git(['rev-parse', 'HEAD']).decode('ascii').strip()
if head != SHA:
    raise RuntimeError(f'frozen HEAD changed: {head}')
source_pins = {}
for relative in (TEST, HOST):
    current = REPO / relative
    if current.read_bytes() != run_git(['show', SHA + ':' + relative]):
        raise RuntimeError(f'worktree bytes differ from exact SHA: {relative}')
    source_pins[relative] = pin(current)
    for mode in ('original', 'candidate'):
        target = OUT / mode / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(current, target)

candidate = OUT / 'candidate' / TEST
before = candidate.read_bytes()
needle = b'namespace.update(write_atomic_report=counted, report=value.report, done=value.done, args=SimpleNamespace(output=path))'
replacement = b'namespace.update(write_atomic_report=counted, report=value.report, done=value.done, supervisor=None, args=SimpleNamespace(output=path))'
if before.count(needle) != 1:
    raise RuntimeError('exact namespace fixture anchor missing or repeated')
candidate.write_bytes(before.replace(needle, replacement))
patch = '\n'.join(difflib.unified_diff(before.decode('utf-8').splitlines(),
    candidate.read_bytes().decode('utf-8').splitlines(),
    fromfile='a/' + TEST, tofile='b/' + TEST, lineterm='')) + '\n'
patch_path = OUT / 'poll-reporting-fixture.patch'
patch_path.write_text(patch, encoding='utf-8', newline='\n')

env = dict(os.environ)
env['PYTHONDONTWRITEBYTECODE'] = '1'
results = {}
for mode in ('original', 'candidate'):
    cwd = OUT / mode
    command = [sys.executable, '-B', '-X', 'utf8', TEST]
    started = now()
    result = subprocess.run(command, cwd=cwd, env=env, capture_output=True, timeout=120)
    finished = now()
    stdout = OUT / (mode + '.stdout.log')
    stderr = OUT / (mode + '.stderr.log')
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    results[mode] = {'argv': command, 'cwd': str(cwd), 'started_at_utc': started,
        'finished_at_utc': finished, 'returncode': result.returncode,
        'stdout': pin(stdout), 'stderr': pin(stderr),
        'test_file': pin(cwd / TEST), 'host_file': pin(cwd / HOST)}
    write_json(OUT / (mode + '.actual.json'), results[mode])

if results['original']['returncode'] == 0:
    raise RuntimeError('original did not reproduce failure')
original_log = (OUT / 'original.stderr.log').read_text(encoding='utf-8')
if original_log.count("NameError: name 'supervisor' is not defined") != 6 or 'FAILED (errors=6)' not in original_log:
    raise RuntimeError('original failure differs from six real CI NameErrors')
if results['candidate']['returncode'] != 0:
    raise RuntimeError('candidate still failed')
candidate_log = (OUT / 'candidate.stderr.log').read_text(encoding='utf-8')
if 'Ran 6 tests' not in candidate_log or '\nOK\n' not in candidate_log:
    raise RuntimeError('candidate did not run the six actual tests')

for relative, before_pin in source_pins.items():
    if pin(REPO / relative) != before_pin:
        raise RuntimeError(f'frozen repo file changed: {relative}')
if run_git(['rev-parse', 'HEAD']).decode('ascii').strip() != SHA:
    raise RuntimeError('frozen HEAD changed during probe')

terminal = json.loads((CI / 'TERMINAL-EVIDENCE.actual.json').read_text(encoding='utf-8'))
ci_log = CI / 'failure-37995375811-attempt-1-log-failed.stdout.log'
ci_lines = ci_log.read_text(encoding='utf-8-sig').splitlines()
failures = [line for line in ci_lines if 'ERROR: test_' in line or "NameError: name 'supervisor' is not defined" in line]
result = {'schema': 'ck3.exact-ci-fixture-candidate.v1', 'status': 'EXTERNAL_CANDIDATE_PASS_NOT_APPLIED',
    'observed_at_utc': now(), 'exact_source_head': SHA,
    'source_file_pins': source_pins, 'ci_terminal_evidence': pin(CI / 'TERMINAL-EVIDENCE.actual.json'),
    'actual_ci_failed_log': pin(ci_log), 'actual_ci_failure_lines': failures,
    'ci_workflows': {name: {key: value.get(key) for key in ('id', 'status', 'conclusion')}
        for name, value in terminal['workflow_status'].items()},
    'probe': results, 'candidate_patch': pin(patch_path),
    'scope': 'One test namespace value only; all six original tests and actual extracted write() preserved.',
    'not_applicable_open_kaishek': 'Python AST-isolated reporting fixture; no Paradox/game semantics.',
    'repo_tracked_files_modified': False, 'production_source_modified': False,
    'ck3_or_steam_started': False, 'screen_or_bus_acquired': False,
    'ci_failure_not_reclassified': True, 'new_ci_run_required_after_root_applies': True}
write_json(OUT / 'RESULT.actual.json', result)
report = f'''# Exact 6a3affdb8 CI poll-reporting fixture candidate

The Official Runner CI run 37995375811 failed at `Test shared CK3 acceptance without installed CK3`. Six `PollReportingTests` failed with `NameError: name 'supervisor' is not defined` in the AST-extracted host `write()` (line 3306). Linear history succeeded; Li Yu Dao static checks were NOT_TRIGGERED and are not counted as success.

The actual host initializes `supervisor: threading.Thread | None = None` before declaring `write()`. This isolated test copied that function but omitted the closure value from its namespace. The candidate supplies `supervisor=None`, matching the real initial host state. It changes one test-fixture line; production code, actual reporting function, test assertions, original errors, deadline and shutdown behavior are unchanged.

Local evidence uses only external copies of the exact frozen commit's test and host files, checked against `git show {SHA}:<path>`. The original six tests reproduced all six identical NameErrors (exit 1); the candidate ran the same six tests successfully (exit 0). Commands, stdout/stderr, times, before/after SHA-256 pins and unchanged repository file checks are in `RESULT.actual.json`. No CK3/Steam, screen, bus, IDs, tracked writes or production fallback were used. `open_kaishek` is not applicable to this Python AST fixture.

Root may apply `poll-reporting-fixture.patch` after releasing R41, then run this focused test and publish through the normal rebase workflow. This external result does not change the actual 6a3 CI failure or establish a new CI success, common runtime qualification or product acceptance.

The original exact CI APIs, jobs and complete workflow logs remain at `{CI.as_posix()}`.
'''
(OUT / 'REPORT.md').write_text(report, encoding='utf-8', newline='\n')
index = {'schema': 'ck3.external-candidate-index.v1', 'files': [pin(path) for path in sorted(OUT.rglob('*')) if path.is_file()]}
write_json(OUT / 'INDEX.actual.json', index)
print(json.dumps({'status': result['status'], 'output': str(OUT), 'original_exit': results['original']['returncode'],
    'candidate_exit': results['candidate']['returncode'], 'patch': pin(patch_path),
    'result': pin(OUT / 'RESULT.actual.json'), 'index': pin(OUT / 'INDEX.actual.json')}, ensure_ascii=False))
