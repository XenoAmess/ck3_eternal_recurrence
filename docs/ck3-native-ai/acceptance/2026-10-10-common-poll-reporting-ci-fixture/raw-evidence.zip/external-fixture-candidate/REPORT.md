# Exact 6a3affdb8 CI poll-reporting fixture candidate

The Official Runner CI run 37995375811 failed at `Test shared CK3 acceptance without installed CK3`. Six `PollReportingTests` failed with `NameError: name 'supervisor' is not defined` in the AST-extracted host `write()` (line 3306). Linear history succeeded; Li Yu Dao static checks were NOT_TRIGGERED and are not counted as success.

The actual host initializes `supervisor: threading.Thread | None = None` before declaring `write()`. This isolated test copied that function but omitted the closure value from its namespace. The candidate supplies `supervisor=None`, matching the real initial host state. It changes one test-fixture line; production code, actual reporting function, test assertions, original errors, deadline and shutdown behavior are unchanged.

Local evidence uses only external copies of the exact frozen commit's test and host files, checked against `git show 6a3affdb87f03f01bdc9f4dc43aeff15960200db:<path>`. The original six tests reproduced all six identical NameErrors (exit 1); the candidate ran the same six tests successfully (exit 0). Commands, stdout/stderr, times, before/after SHA-256 pins and unchanged repository file checks are in `RESULT.actual.json`. No CK3/Steam, screen, bus, IDs, tracked writes or production fallback were used. `open_kaishek` is not applicable to this Python AST fixture.

Root may apply `poll-reporting-fixture.patch` after releasing R41, then run this focused test and publish through the normal rebase workflow. This external result does not change the actual 6a3 CI failure or establish a new CI success, common runtime qualification or product acceptance.

The original exact CI APIs, jobs and complete workflow logs remain at `C:/workspace/ck3_lyd_runtime_20261004/r41-exact-6a3affdb8-ci-20261010-001`.
