"""Read only the Root-authorized 59B union around two actual data-trap post-PCs."""
from pathlib import Path
import capstone
from capstone.x86 import X86_OP_MEM, X86_OP_REG
import datetime as dt
import hashlib
import json
import sys

R=Path(__file__).resolve().parent
def need(ok,message):
    if not ok: raise ValueError(message)
def load(path): return json.loads(Path(path).read_bytes())
def pin(path):
    p=Path(path);b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(name,value):
    with (R/name).open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,indent=2);f.write('\n')
def main():
    need(load(R/'PLAN-CHECK.actual.json')['returncode']==0,'Plan must pass before read')
    plan=load(R/'plan-a01.json')
    layout=load(plan['layout_receipt'])
    identity=load(plan['identity_receipt'])
    observed=load(plan['actual_projection'])
    source=Path(identity['frozen_path'])
    before=source.stat()
    need(identity['sha256']==plan['build']['exe_sha256'] and before.st_size==identity['bytes'],'Qualified frozen identity differs')
    old=layout['frozen_metadata']
    need((before.st_size,before.st_mtime_ns,before.st_ino)==(old['bytes'],old['mtime_ns'],old['inode']),'Frozen cached metadata differs')
    start,end=0x28A643B,0x28A6476
    section=next(s for s in layout['sections'] if s['va']<=start<end<=s['va']+s['rawsize'])
    off=section['raw']+start-section['va']
    with source.open('rb') as f:
        f.seek(off);raw=f.read(end-start)
    need(len(raw)==59,'Short bounded source read')
    with (R/'actual-window.bin').open('xb') as f:f.write(raw)
    after=source.stat()
    need((before.st_size,before.st_mtime_ns,before.st_ino)==(after.st_size,after.st_mtime_ns,after.st_ino),'Frozen source changed')
    dis=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64);dis.detail=True
    results=[]
    for event in observed['qualified_writers']:
        post=event['RIP_after_rva'];regs=event['registers'];candidates=[]
        for at in range(max(start,post-15),post):
            seq=list(dis.disasm(raw[at-start:post-start],at))
            if len(seq)!=1:continue
            ins=seq[0]
            if ins.address+ins.size!=post or ins.mnemonic!='mov' or len(ins.operands)!=2:continue
            dest,src=ins.operands
            if dest.type!=X86_OP_MEM or dest.size!=8 or src.type!=X86_OP_REG:continue
            mem=dest.mem
            if mem.base==0 or mem.index!=0:continue
            base=ins.reg_name(mem.base);srcreg=ins.reg_name(src.reg)
            if base not in regs or srcreg not in regs:continue
            if regs[base]+mem.disp!=event['address']:continue
            if regs[srcreg] & ((1<<64)-1) != event['after_raw'] & ((1<<64)-1):continue
            candidates.append(dict(instruction_rva=ins.address,end_rva=post,bytes_hex=ins.bytes.hex(),mnemonic=ins.mnemonic,operands=ins.op_str,destination_base=base,destination_disp=mem.disp,store_size=dest.size,source_register=srcreg,effective_address=regs[base]+mem.disp))
        need(len(candidates)==1,'Actual end/address/registers do not identify one bounded store')
        results.append(dict(raw_line=event['raw_line'],actual_post_rva=post,field_offset=event['offset'],store=candidates[0],same_value_write=event['same_value_write']))
    continuation=[dict(rva=i.address,bytes_hex=i.bytes.hex(),mnemonic=i.mnemonic,operands=i.op_str) for i in dis.disasm(raw[0x28A645B-start:],0x28A645B)]
    write('READ-AND-DECODE.actual.json',dict(machine_id=observed['evidence_machine_id'],at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),source=str(source),qualified_exe_sha256_reused=identity['sha256'],identity=pin(plan['identity_receipt']),layout=pin(plan['layout_receipt']),actual_projection=pin(plan['actual_projection']),plan=pin(R/'plan-a01.json'),tool_argv=sys.argv,tool_python=sys.executable,capstone_version=capstone.__version__,read=dict(rva=start,end_exclusive=end,file_offset=off,bytes=len(raw),hex=raw.hex(),sha256=hashlib.sha256(raw).hexdigest()),new_EXE_code_bytes=59,new_EXE_metadata_bytes=0,new_EXE_read_calls=1,whole_EXE_hashes=0,global_scans=0,results=results,continuation_from_actual_post_boundary=continuation,function_extent_unknown=True,caller_unknown=True,maintenance_attribution='unclosed',method='Unique complete MOV ending at actual trap post-PC, matching 8B effective address and actual source register. No RIP_after-1 shortcut; no function-start claim.'))
    print(json.dumps(dict(stores=results,new_EXE_bytes=59,maintenance_attribution='unclosed')))
    return 0
if __name__=='__main__':raise SystemExit(main())
