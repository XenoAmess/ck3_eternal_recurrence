028A63E0  48 89 5c 24 10                               mov qword ptr [rsp + 0x10], rbx
028A63E5  48 89 74 24 18                               mov qword ptr [rsp + 0x18], rsi
028A63EA  48 89 7c 24 20                               mov qword ptr [rsp + 0x20], rdi
028A63EF  55                                           push rbp
028A63F0  41 54                                        push r12
028A63F2  41 55                                        push r13
028A63F4  41 56                                        push r14
028A63F6  41 57                                        push r15
028A63F8  48 8d 6c 24 b0                               lea rbp, [rsp - 0x50]
028A63FD  48 81 ec 50 01 00 00                         sub rsp, 0x150
028A6404  4d 8b e0                                     mov r12, r8
028A6407  4c 8b fa                                     mov r15, rdx
028A640A  48 8b f1                                     mov rsi, rcx
028A640D  4c 8b 89 c0 01 00 00                         mov r9, qword ptr [rcx + 0x1c0]
028A6414  41 8b 81 88 00 00 00                         mov eax, dword ptr [r9 + 0x88]
028A641B  83 f8 ff                                     cmp eax, -1
028A641E  74 12                                        je 0x28a6432
028A6420  41 89 81 d8 03 00 00                         mov dword ptr [r9 + 0x3d8], eax
028A6427  41 c7 81 88 00 00 00 ff ff ff ff             mov dword ptr [r9 + 0x88], 0xffffffff
028A6432  41 8b 81 8c 00 00 00                         mov eax, dword ptr [r9 + 0x8c]
028A6439  83 f8 ff                                     cmp eax, -1
028A643C  74 12                                        je 0x28a6450
028A643E  41 89 81 dc 03 00 00                         mov dword ptr [r9 + 0x3dc], eax
028A6445  41 c7 81 8c 00 00 00 ff ff ff ff             mov dword ptr [r9 + 0x8c], 0xffffffff
028A6450  49 8b 41 18                                  mov rax, qword ptr [r9 + 0x18]
028A6454  49 89 81 c0 02 00 00                         mov qword ptr [r9 + 0x2c0], rax
028A645B  49 8b 41 20                                  mov rax, qword ptr [r9 + 0x20]
028A645F  49 89 81 c8 02 00 00                         mov qword ptr [r9 + 0x2c8], rax
028A6466  49 8b 41 40                                  mov rax, qword ptr [r9 + 0x40]
028A646A  49 89 81 d0 02 00 00                         mov qword ptr [r9 + 0x2d0], rax
028A6471  49 8b 49 48                                  mov rcx, qword ptr [r9 + 0x48]
028A6475  49 89 89 e0 02 00 00                         mov qword ptr [r9 + 0x2e0], rcx
028A647C  49 2b 41 50                                  sub rax, qword ptr [r9 + 0x50]
028A6480  49 89 81 d8 02 00 00                         mov qword ptr [r9 + 0x2d8], rax
028A6487  49 8b 41 58                                  mov rax, qword ptr [r9 + 0x58]
028A648B  49 89 81 e8 02 00 00                         mov qword ptr [r9 + 0x2e8], rax
028A6492  41 8b 41 60                                  mov eax, dword ptr [r9 + 0x60]
028A6496  41 89 81 f0 02 00 00                         mov dword ptr [r9 + 0x2f0], eax
028A649D  41 8b 41 64                                  mov eax, dword ptr [r9 + 0x64]
028A64A1  41 89 81 f4 02 00 00                         mov dword ptr [r9 + 0x2f4], eax
028A64A8  41 8b 41 68                                  mov eax, dword ptr [r9 + 0x68]
028A64AC  41 89 81 fc 02 00 00                         mov dword ptr [r9 + 0x2fc], eax
028A64B3  41 8b 41 6c                                  mov eax, dword ptr [r9 + 0x6c]
028A64B7  41 89 81 00 03 00 00                         mov dword ptr [r9 + 0x300], eax
028A64BE  41 8b 41 70                                  mov eax, dword ptr [r9 + 0x70]
028A64C2  41 89 81 f8 02 00 00                         mov dword ptr [r9 + 0x2f8], eax
028A64C9  49 8b 41 78                                  mov rax, qword ptr [r9 + 0x78]
028A64CD  49 89 81 08 03 00 00                         mov qword ptr [r9 + 0x308], rax
028A64D4  49 8b 81 80 00 00 00                         mov rax, qword ptr [r9 + 0x80]
028A64DB  49 89 81 10 03 00 00                         mov qword ptr [r9 + 0x310], rax
028A64E2  49 8b 81 90 00 00 00                         mov rax, qword ptr [r9 + 0x90]
028A64E9  45 33 ed                                     xor r13d, r13d
028A64EC  48 85 c0                                     test rax, rax
028A64EF  7e 0e                                        jle 0x28a64ff
028A64F1  49 89 81 50 03 00 00                         mov qword ptr [r9 + 0x350], rax
028A64F8  4d 89 a9 90 00 00 00                         mov qword ptr [r9 + 0x90], r13
028A64FF  49 8b 81 98 00 00 00                         mov rax, qword ptr [r9 + 0x98]
028A6506  48 85 c0                                     test rax, rax
028A6509  7e 0e                                        jle 0x28a6519
028A650B  49 89 81 58 03 00 00                         mov qword ptr [r9 + 0x358], rax
028A6512  4d 89 a9 98 00 00 00                         mov qword ptr [r9 + 0x98], r13
028A6519  48 8b 8e c0 01 00 00                         mov rcx, qword ptr [rsi + 0x1c0]
028A6520  48 81 c1 68 03 00 00                         add rcx, 0x368
028A6527  48 89 b5 80 00 00 00                         mov qword ptr [rbp + 0x80], rsi
028A652E  48 8d 95 80 00 00 00                         lea rdx, [rbp + 0x80]
028A6535  e8 36 fc 02 00                               call 0x28d6170
028A653A  48 8b 9e c0 01 00 00                         mov rbx, qword ptr [rsi + 0x1c0]
028A6541  44 38 ab d8 01 00 00                         cmp byte ptr [rbx + 0x1d8], r13b
028A6548  0f 84 e5 00 00 00                            je 0x28a6633
028A654E  44 88 ab d8 01 00 00                         mov byte ptr [rbx + 0x1d8], r13b
028A6555  4c 89 6c 24 20                               mov qword ptr [rsp + 0x20], r13
028A655A  4c 89 6c 24 28                               mov qword ptr [rsp + 0x28], r13
028A655F  48 8d 44 24 38                               lea rax, [rsp + 0x38]
028A6564  48 89 44 24 30                               mov qword ptr [rsp + 0x30], rax
028A6569  48 8d 05 38 22 ec 01                         lea rax, [rip + 0x1ec2238]
028A6570  48 89 44 24 38                               mov qword ptr [rsp + 0x38], rax
028A6575  48 8d 05 74 12 c4 02                         lea rax, [rip + 0x2c41274]
028A657C  48 89 45 40                                  mov qword ptr [rbp + 0x40], rax
028A6580  48 8b 05 31 22 ec 01                         mov rax, qword ptr [rip + 0x1ec2231]
028A6587  33 d2                                        xor edx, edx
028A6589  44 8d 42 08                                  lea r8d, [rdx + 8]
028A658D  48 8d 4c 24 38                               lea rcx, [rsp + 0x38]
028A6592  ff d0                                        call rax
028A6594  4c 89 6c 24 20                               mov qword ptr [rsp + 0x20], r13
028A6599  4c 89 6c 24 28                               mov qword ptr [rsp + 0x28], r13
028A659E  48 8b 44 24 38                               mov rax, qword ptr [rsp + 0x38]
028A65A3  4c 8d 44 24 28                               lea r8, [rsp + 0x28]
028A65A8  48 8d 54 24 20                               lea rdx, [rsp + 0x20]
028A65AD  48 8d 4c 24 38                               lea rcx, [rsp + 0x38]
028A65B2  ff 50 20                                     call qword ptr [rax + 0x20]
028A65B5  90                                           nop 
028A65B6  48 8d 54 24 20                               lea rdx, [rsp + 0x20]
028A65BB  48 8b cb                                     mov rcx, rbx
028A65BE  e8 1d 2c 0b 00                               call 0x29591e0
028A65C3  48 63 44 24 2c                               movsxd rax, dword ptr [rsp + 0x2c]
028A65C8  48 8b 7c 24 20                               mov rdi, qword ptr [rsp + 0x20]
028A65CD  4c 8d 34 c7                                  lea r14, [rdi + rax*8]
028A65D1  49 3b fe                                     cmp rdi, r14
028A65D4  74 3f                                        je 0x28a6615
028A65D6  66 66 0f 1f 84 00 00 00 00 00                nop word ptr [rax + rax]
028A65E0  48 8b 1f                                     mov rbx, qword ptr [rdi]
028A65E3  48 8d 95 80 00 00 00                         lea rdx, [rbp + 0x80]
028A65EA  48 8b cb                                     mov rcx, rbx
028A65ED  e8 ce 24 bc ff                               call 0x2468ac0
028A65F2  48 8b 00                                     mov rax, qword ptr [rax]
028A65F5  48 8b 8b f0 00 00 00                         mov rcx, qword ptr [rbx + 0xf0]
028A65FC  48 63 51 10                                  movsxd rdx, dword ptr [rcx + 0x10]
028A6600  49 8b 0f                                     mov rcx, qword ptr [r15]
028A6603  48 89 04 d1                                  mov qword ptr [rcx + rdx*8], rax
028A6607  48 83 c7 08                                  add rdi, 8
028A660B  49 3b fe                                     cmp rdi, r14
028A660E  75 d0                                        jne 0x28a65e0
028A6610  48 8b 7c 24 20                               mov rdi, qword ptr [rsp + 0x20]
028A6615  48 85 ff                                     test rdi, rdi
028A6618  74 19                                        je 0x28a6633
028A661A  44 89 6c 24 2c                               mov dword ptr [rsp + 0x2c], r13d
028A661F  48 8b 4c 24 30                               mov rcx, qword ptr [rsp + 0x30]
028A6624  48 8b 01                                     mov rax, qword ptr [rcx]
028A6627  41 b8 08 00 00 00                            mov r8d, 8
028A662D  48 8b d7                                     mov rdx, rdi
028A6630  ff 50 10                                     call qword ptr [rax + 0x10]
028A6633  48 8b 8e c0 01 00 00                         mov rcx, qword ptr [rsi + 0x1c0]
028A663A  48 85 c9                                     test rcx, rcx
028A663D  74 37                                        je 0x28a6676
028A663F  48 8b 89 58 04 00 00                         mov rcx, qword ptr [rcx + 0x458]
028A6646  48 85 c9                                     test rcx, rcx
028A6649  74 2b                                        je 0x28a6676
028A664B  48 8b 05 a6 21 41 03                         mov rax, qword ptr [rip + 0x34121a6]
028A6652  f6 80 b0 02 00 00 20                         test byte ptr [rax + 0x2b0], 0x20
028A6659  74 1b                                        je 0x28a6676
028A665B  80 b9 c8 00 00 00 00                         cmp byte ptr [rcx + 0xc8], 0
028A6662  74 12                                        je 0x28a6676
028A6664  48 81 c1 d0 00 00 00                         add rcx, 0xd0
028A666B  4d 8b c4                                     mov r8, r12
028A666E  48 8b d6                                     mov rdx, rsi
028A6671  e8 5a 4b d5 ff                               call 0x25fb1d0
028A6676  4c 8d 9c 24 50 01 00 00                      lea r11, [rsp + 0x150]
028A667E  49 8b 5b 38                                  mov rbx, qword ptr [r11 + 0x38]
028A6682  49 8b 73 40                                  mov rsi, qword ptr [r11 + 0x40]
028A6686  49 8b 7b 48                                  mov rdi, qword ptr [r11 + 0x48]
028A668A  49 8b e3                                     mov rsp, r11
028A668D  41 5f                                        pop r15
028A668F  41 5e                                        pop r14
028A6691  41 5d                                        pop r13
028A6693  41 5c                                        pop r12
028A6695  5d                                           pop rbp
028A6696  c3                                           ret 
