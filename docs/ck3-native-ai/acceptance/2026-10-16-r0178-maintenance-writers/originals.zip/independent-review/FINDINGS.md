# R0178 首次真实四字段 writer 窗口

本次已观察到两个真实物理写入：同一 native 线程 17340 对 actor31254 当前 secondary context 的 `+2C0` 和 `+2C8` 作同值写入。它们分别为 `384653→384653`、`0→0`；同值仍是写入，暂停态净差为零不能代替 writer 证据。`+28/+30` 本窗口未保留 trap，不能解释为没有 writer 或没有费用。

原始 post-PC 是 RVA `28A645B`、`28A6466`。另行授权读取的精确 59B 窗口确认 store 起点为 `28A6454`、`28A645F`，分别是 `MOV qword ptr[R9+2C0],RAX`、`MOV qword ptr[R9+2C8],RAX`，R9 与实际 context/有效地址一致。识别依据是完整指令恰结束于真实 post-PC，并符合原始寄存器与写地址，没有用 post-PC 减一充当指令起点。

实际第一 post-PC `28A645B` 同时是下一条指令的边界：`MOV RAX,[R9+20]` 后接第二条 store。这闭合了同对象 `+20→+2C8` 的直接复制指令关系。第一条 store 之前的 59B 源窗口还保留 `MOV RAX,[R9+18]` 字节，但未取得完整函数与控制流入口；该相邻 load 不授予调用来源或军事语义。R08 已有 settlement 在 `28A6D10..28A6F4E` 读取四字段，本次补上其中两个字段的真实 store，仍未闭合 `+18/+20` 上游生产者、另外两字段、缓存失效、真实 caller 或 applied military component。

窗口以 timeout 正常达到 30 秒边界，native 返回 1；actual reader 返回 0。原始 raw 的 110 个成功 arm 对应 109 个原调试寄存器精确 readback restore 与一个已退出线程；终态 restored/detached/cleanup_complete 为 true，pending_event 为 false。该结果不能外推全窗口覆盖所有写入。

Root 原始逐日 runner 的本次窗口从暂停帧 `53146896` 到暂停帧 `53146920`；独立 post query 的四个 raw 值仍为 `[384653,0,273262,0]`。trap 没有实际游戏日期/phase 字段，不能单凭窗口跨月把 store 定名为月结维护费刷新。当前 `maintenance_attribution=unclosed`。

下一最小来源请求为只查 `28A6454` 的包含函数 `.pdata`，要求同时覆盖第二个 post-PC `28A6466`；metadata≤512B、≤48次读取，仅在完整 extent≤8192B 时读 body。目标是查明已观察复制的真实入参和 `+18/+20` 来源，不扫 xref、邻居或无关 callee。本报告不执行这一新 scope。

`OBSERVATION.actual.json` 保存原始输入 pins 与独立核对结果；`review_actual_window.py` 只读本次有限小原件。精确指令字节和原 source 读回在相邻 `maintenance-writer-r0178-source-a01/READ-AND-DECODE.actual.json`，其 16,255B 小包保留 plan、实际工具 argv、59B 原始窗口及 capstone 输出。运行机器、PID、指针和观察资格不能迁移到另一机器；源码与原始事实可以复用。
