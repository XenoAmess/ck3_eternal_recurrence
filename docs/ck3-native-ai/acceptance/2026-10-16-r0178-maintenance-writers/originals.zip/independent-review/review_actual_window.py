"""Independent finite-file review of Root's one completed R0178 writer window."""
from pathlib import Path
from collections import Counter
import datetime as dt
import hashlib
import json
import sys

R=Path(__file__).resolve().parent
L=Path('C:/ck3-e04-resume-20261015-a01/maintenance-writer-a08-root-adapter-a01/actual-r0178-day3-commands-a01/watch-ledger')
S=Path('C:/ck3-e04-resume-20261015-a01/maintenance-writer-r0178-source-a01')
def need(ok,message):
    if not ok:raise ValueError(message)
def raw(path,limit):
    b=Path(path).read_bytes();need(len(b)<=limit,'Bounded metadata input cap');return b
def load(path,limit=16384):return json.loads(raw(path,limit))
def pin(path):
    p=Path(path);b=raw(p,65536)
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(name,value):
    with (R/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def main():
    b=raw(L/'admission/writer.raw.ndjson',65536)
    need(hashlib.sha256(b).hexdigest()=='ff7b8efff9c8c8ccff337e581e4637bf7514d870677c9eff67b92a9c75921ce9','Use exact terminal original raw')
    rows=[json.loads(line) for line in b.splitlines() if line]
    counts=dict(Counter(x['kind'] for x in rows))
    need(counts==dict(start=1,arm=110,thread_exited=1,raw_field_write_trap=2,restore=109,terminal=1),'Actual raw shape changed')
    start,terminal=rows[0],rows[-1]
    need(start['synthetic'] is False and start['CK3_observed'] is True,'Not an actual CK3 window')
    expected=dict(pid=24740,created=134365733009843924,full_id=31254,character=2300870195776,context=2296003269728,admission_window_id=1,admission_payment_epoch=1,admission_generation=1,admission_date_raw=53146896,admission_episode='native-31254-0665741d68fc')
    need(all(start[k]==v for k,v in expected.items()),'Root actual tuple differs')
    arms={x['thread_id']:x for x in rows if x['kind']=='arm'}
    restores={x['thread_id']:x for x in rows if x['kind']=='restore'}
    exited={x['thread_id'] for x in rows if x['kind']=='thread_exited'}
    need(len(arms)==110 and len(restores)==109 and set(restores)|exited==set(arms) and not set(restores)&exited,'Lifecycle restore/exit set does not cover retained armed threads')
    need(all(x['success'] is True for x in arms.values()),'Unsuccessful observed arm')
    need(all(x['readback'] is True and x['debug']==arms[tid]['saved_debug'] for tid,x in restores.items()),'Actual original debug restore readback differs')
    need(terminal['reason']=='timeout' and terminal['restored'] is True and terminal['detached'] is True and terminal['cleanup_complete'] is True and terminal['pending_event'] is False,'Terminal cleanup not closed')
    projection=load(L/'WRITERS.actual.json')
    need(projection['cleanup_proved'] is True and len(projection['qualified_writers'])==2 and projection['unknown_traps']==[],'Existing actual reader differs')
    events=[x for x in rows if x['kind']=='raw_field_write_trap']
    stores=[]
    for line,event,pc,offset in zip([113,114],events,[0x28A645B,0x28A6466],[0x2C0,0x2C8]):
        need(rows[line-1] is event and event['RIP_after_rva']==pc and event['offset']==offset,'Actual original trap differs')
        need(event['RIP_after']-start['module_base']==pc and 0<=pc<start['module_size'],'Actual PC outside qualified module')
        need(event['context']==start['context'] and event['full_id']==31254 and event['address']==start['context']+offset,'Actual physical address mismatch')
        need(event['context_identity_stable'] is True and event['after_read_complete'] is True and event['same_value_write'] is True,'Actual stable same-value write facts differ')
        need(event['writer_instruction_start'] is None,'Raw post-PC cannot self-declare instruction start')
        stores.append(dict(raw_line=line,thread=event['thread_id'],offset_hex=hex(offset),post_rva_hex=hex(pc),address=event['address'],before_raw=event['before_raw'],after_raw=event['after_raw'],same_value_write=True,actual_writer_game_date=None))
    readexit=load(L/'READER-EXIT.actual.json');exit=load(L/'WATCH-EXIT.actual.json')
    need(readexit['returncode']==0 and exit['native_returncode']==1 and exit['ready_seen'] is True,'Actual terminal exit contract differs')
    pair=load(L/'BEFORE-AFTER.actual.json')
    need(pair['before_date_raw']==53146896 and pair['after_date_raw']==53146920 and pair['elapsed_raw']==24,'Independent paused date pair differs')
    need(all(x['delta']==0 for x in pair['raw_field_comparison']),'Beforeafter raw cache changed')
    source=load(S/'READ-AND-DECODE.actual.json')
    write('OBSERVATION.actual.json',dict(machine_id=start['machine_id'],reviewed_utc=dt.datetime.now(dt.timezone.utc).isoformat(),result='TWO_REAL_PHYSICAL_CACHE_WRITES_RESTORED_DETACHED_SOURCE_PARTIAL',root_identity=expected,raw_counts=counts,actual_events=stores,source_store_instructions=source['results'],actual_reader_returncode=0,native_returncode=1,native_reason='timeout',original_debug_restores_exact=109,retired_threads=sorted(exited),cleanup_proved=True,beforeafter_date_pair=[53146896,53146920],beforeafter_raw_cache=[384653,0,273262,0],all_four_paused_deltas_zero=True,window_all_writes_covered=False,unobserved_slots=['0x28','0x30'],actual_trap_calendar_date=None,actual_trigger_phase='unknown',known_business_producer=False,maintenance_attribution='unclosed',input_pins=[pin(L/name) for name in ['admission/writer.raw.ndjson','WRITERS.actual.json','WATCH-EXIT.actual.json','READER-EXIT.actual.json','BEFORE-AFTER.actual.json','DAY3-HOOK-CLEANUP.actual.json']]+[pin(S/'READ-AND-DECODE.actual.json')],next_bounded_source_request=dict(lookup_pc_rva='0x28A6454',also_cover_post_rva='0x28A6466',metadata_max=512,code_max_if_full_extent_fits=8192,read_calls_max=48,goal='Containing-function source and real input provenance of context+18/+20, then relation to known2C0/2C8 copies; no military inference from names or values',not_authorized_by_this_report=True),no_SDK_watch_retry_EXE_game_or_main_action_performed=True))
    print(json.dumps(dict(result='ACTUAL_REVIEW_PASS_SOURCE_PARTIAL',observation=pin(R/'OBSERVATION.actual.json'))))
    return 0
if __name__=='__main__':raise SystemExit(main())
