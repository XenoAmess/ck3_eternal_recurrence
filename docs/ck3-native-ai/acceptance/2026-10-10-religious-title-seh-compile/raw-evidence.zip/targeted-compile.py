from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('C:/workspace/ck3_eternal_recurrence')
sys.path.insert(0, str(ROOT / 'tools'))
from run_native_msvc import child_environment, initialize_msvc, visual_studio_installation

B = Path('C:/lci39rtseh1')
B.mkdir(exist_ok=False)
environment = child_environment(B)
installation = visual_studio_installation(None, environment)
environment, tools = initialize_msvc(installation, B, environment)
environment.pop('CL', None)
environment.pop('_CL_', None)
source = ROOT / 'ck3_autonomous_player/native_bridge'
inputs = [source / 'src/ck3_12003_religious_title_readback.cpp',
          source / 'tests/ck3_12003_religious_title_readback_fixture.cpp']
report = {'schema': 'xar.religious-title-seh-compile.v1',
          'started_utc': datetime.now(timezone.utc).isoformat(),
          'source_inputs': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},
          'local_ck3_contacted': False, 'executable_produced': False,
          'fixture_runtime_execution': 'not_run_runtime_library_not_built', 'steps': []}
for i, path in enumerate(inputs):
    argv = [tools['cl'], '/nologo', '/c', '/std:c++20', '/O2', '/MD', '/W4', '/WX',
            '/permissive-', '/EHsc', '/UNDEBUG', '/utf-8', '/DNOMINMAX',
            '/DWIN32_LEAN_AND_MEAN', '/DUNICODE', '/D_UNICODE',
            f'/I{source / "include"}', str(path), f'/Fo{B / (path.stem + ".obj")}']
    result = subprocess.run(argv, cwd=B, env=environment, capture_output=True, timeout=120)
    label = f'{i:02d}-{path.stem}'
    (B / (label + '.stdout.bin')).write_bytes(result.stdout)
    (B / (label + '.stderr.bin')).write_bytes(result.stderr)
    report['steps'].append({'argv': argv, 'exit_code': result.returncode,
                            'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                            'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()})
    print(json.dumps(report['steps'][-1]), flush=True)
    if result.returncode:
        print(result.stdout.decode('utf-8', errors='replace'), flush=True)
        print(result.stderr.decode('utf-8', errors='replace'), flush=True)
        break
report['finished_utc'] = datetime.now(timezone.utc).isoformat()
report['status'] = 'compile_passed' if len(report['steps']) == 2 and all(
    item['exit_code'] == 0 for item in report['steps']) else 'failed'
(B / 'RESULT.actual.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'status': report['status'], 'build_dir': str(B)}), flush=True)
raise SystemExit(0 if report['status'] == 'compile_passed' else 1)
