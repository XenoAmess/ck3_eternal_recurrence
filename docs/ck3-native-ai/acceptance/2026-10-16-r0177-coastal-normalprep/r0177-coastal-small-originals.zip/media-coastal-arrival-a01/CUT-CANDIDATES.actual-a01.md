R0177：250人军队正常到达沿海省份，候选镜头（Root连续复看待办）

45.000秒 / 1350帧 / 2560×1440@30 / H264 yuv420p / 无音频。一次probe和一次严格全解码通过；指定六帧同支抽取并已实际看图。无原片重hash、重编码、额外seek或重复完整解码。

|时码|剪辑候选与可授事实|
|---|---|
|00:00–00:04|250人、100/100、移动剩余1天，Dec28暂停。|
|00:04–00:10|自然到达转换：面板改待命、地图250旗换位、日期到Dec29；转换仅被括在(4,10]秒。|
|00:10–00:15|到达后待命短对照，250人、100/100、Dec29暂停。|
|00:15–00:43.5|到达后暂停留屏长备选，按叙事裁短；尚未连续复看。|

原生独立读回：Army93，date53146824/current2619/route[2624]/moving；自然一天后date53146848/current2624/route complete_empty/regular/paused/in_combat=false。此阶段是normal preparation，R07_treatment_started=false、R07_PASS=false，不能讲成补给恢复实验通过。null且unobservable的move_target不能证明target字段已清空。

recorder.started=20:23:25.077252Z；Root交接给出的phase done=20:23:37.477144Z（+12.399892秒）只作业务完成时刻，不能套成首次像素PTS。encoded PTS与wall clock未校准，实际画面以(4,10]秒样本括界为准。

全部六帧有暂停横幅；样本之间不能据此断言持续暂停。未见旧海岸tooltip、系统弹窗或右侧通知；鼠标停Army header。地图北侧500对3094战斗条可见但不遮250旗或Army面板；这不是Army93交战。1195船模也不是Army93。左下军队面板为内容，遮挡部分地图。本包不生成approval、GREEN capture report、连续clean或human 1× credit。
