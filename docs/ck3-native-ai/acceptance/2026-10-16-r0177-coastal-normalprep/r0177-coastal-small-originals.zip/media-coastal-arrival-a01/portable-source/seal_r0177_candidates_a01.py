"""Seal bounded actual R0177 frame observations and reusable text/code index.

No source video read, media decode, seek, SDK, game, desktop, recorder, main-tree
write, Git or network operation. Images were already opened by the reviewing AI.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

PREP=Path(__file__).resolve().parent
BASE=Path('C:/ck3-e04-resume-20261015-a01/live12004-logistics-source-a01')
OUT=BASE/'media-coastal-arrival-a01'
RESP=BASE/'desktop-3fevhd2-1c74096080--vanilla--R0177/responses'
LIMIT=3145728
DEADLINE=datetime.fromisoformat('2026-10-16T07:45:01.597+00:00')

def require(ok,message):
    if not ok: raise RuntimeError(message)

def load(path):
    require(path.is_file() and not path.is_symlink() and path.suffix=='.json' and path.stat().st_size<=500000,'bounded actual JSON required')
    return json.loads(path.read_text(encoding='utf-8-sig'))

def pin(path):
    require(path.suffix in ('.json','.py','.md','.log') and path.is_file() and not path.is_symlink() and path.stat().st_size<=500000,'bounded text/code only; raw hash forbidden')
    data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def write(path,body):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(body,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')

def size():
    return sum(p.stat().st_size for root in (PREP,OUT) for p in root.rglob('*') if p.is_file())

def now(): return datetime.now(timezone.utc).isoformat()

require(datetime.now(timezone.utc)<DEADLINE,'fixed original deadline reached')
report=load(OUT/'report.json')
require(report['state']=='PASS_RAW_METADATA_AND_STRICT_DECODE_ONLY' and report['decoded_frames']==1350,'actual one-pass media audit required')
require((report['metadata_probe_count'],report['strict_whole_decode_count'],report['extra_seek_count'],report['raw_SHA_reads'],report['raw_reencodes'])==(1,1,0,0,0),'unexpected media operations')
require([s['source_frame_ordinal'] for s in report['samples']]==[0,120,300,450,900,1305],'wrong actual sample set')
closure=load(BASE/'raw-coastal-arrival-a01/result.json')
start=datetime.fromisoformat(closure['started_at_utc'])
identity=load(BASE/'runtime-actor-identity.actual-a01.json')
require(identity['source_head']==report['actual_source_head']=='d9322bcfb3e17a3fe78607cea777bbfaf7be0a11' and identity['pid']==7240 and identity['process_creation_filetime_100ns']==134365679117288462 and identity['connection_generation']==1,'scene process/source binding differs')
daypath=BASE/'normalprepare93-stages/day-53146824.actual.json'
daypin=pin(daypath)
require(daypin['sha256']=='c097d6b9b1b73d1221e240907d4dc0d67c9ca5b96ec4fd26ef677ed54f108b98','actual day9 receipt differs from producer closure')
day=load(daypath)
events=[]
names=[('paused_before_day9','prep-r07s0-day09-film-a01-day-before.json'),('fresh_before_clock_arm','prep-r07s0-day09-film-a01-fresh-before-arm.json'),('normal_resume_once','prep-r07s0-day09-film-a01-resume.json'),('first_stopped_snapshot_record','prep-r07s0-day09-film-a01-pause-poll-003.json'),('independent_post_status_fresh_snapshot','prep-r07s0-day09-film-a01-post-status-fresh.json')]
for label,name in names:
    path=RESP/name;d=load(path);b=d['body']
    require(d['is_error'] is False,'actual native response contains an error')
    army=[a for a in b.get('player_armies',[]) if a.get('army_id')==93]
    if 'player_armies' in b:require(len(army)==1,'Army93 snapshot missing or duplicated')
    events.append({'label':label,'response':pin(path),'receipt_at_utc':d['at'],'receipt_at_minus_recorder_started_seconds':(datetime.fromisoformat(d['at'])-start).total_seconds(),'receipt_at_semantics':'saved MCP wrapper field; not assumed action completion, first pixel time, or calibrated source PTS','date_raw':b.get('date_raw'),'paused':b.get('paused'),'speed':b.get('speed'),'request_tool':d['request']['tool'],'accepted':b.get('accepted'),'army93':army[0] if army else None})
for e in events[:2]:
    require(e['date_raw']==53146824 and e['paused'] is True and e['army93']['current_province_id']==2619 and e['army93']['route_province_ids']==[2624] and e['army93']['army_state']=='moving','actual prearrival snapshot differs')
require(events[2]['accepted'] is True,'actual normal resume was not accepted')
for e in events[3:]:
    require(e['date_raw']==53146848 and e['paused'] is True and e['army93']['current_province_id']==2624 and e['army93']['route_read_status']=='complete_empty' and e['army93']['army_state']=='regular' and e['army93']['in_combat'] is False,'actual independent arrival snapshot differs')
require(day['normal_preparation_only'] is True and day['R07_treatment_started'] is False and day['R07_PASS'] is False and day['actual_arrived_stationary'] is True,'normal preparation qualification changed')
native={'schema':'xar.e04.R0177-coastal-arrival-native-excerpts.actual.v1','at_utc':now(),'actual_run_id':report['actual_run_id'],'source_head':report['actual_source_head'],'runtime_identity':pin(BASE/'runtime-actor-identity.actual-a01.json'),'exact_runtime_binding':{'pid':7240,'create_filetime_100ns':134365679117288462,'generation':1,'episode':identity['episode_run_id'],'actor':31254,'army_id':93},'raw_identity_reused':report['raw_identity_reused'],'recorder_started_at_utc':closure['started_at_utc'],'native_events':events,'actual_day9_receipt':daypin,'day9_clock':day['clock'],'arrival_first_observed_day_interval':day['arrival_first_observed_day_interval'],'wholeDATA_current_not_queried':day['wholeDATA_current_not_queried'],'Root_handoff_times_only':{'recorder_ACK_utc':'2026-10-15T20:23:28.099163+00:00','phase_done_utc':'2026-10-15T20:23:37.477144+00:00','provenance':'Root task handoff; these two completion times are not fabricated from wrapper .at','phase_done_minus_started_seconds':12.399892},'wall_time_to_encoded_PTS_calibrated':False,'exact_arrival_encoded_PTS':None,'new_Move_during_recording_pipeline':0,'normal_preparation_only':True,'R07_treatment_started':False,'R07_PASS':False,'null_move_target_is_not_proven_cleared':True,'supply_recovery_or_attrition_treatment_proven':False,'human_approval':False}
write(OUT/'native-arrival-excerpts.actual-a01.json',native)

observations=[
 {'date_text':'公元1066年12月28日','panel_state_text':'移动：剩余1天','description':'左下选中250人军队，补给读数100/100；地图北侧另有500人集团旗，250旗尚未单独出现在到达后的新位置。'},
 {'date_text':'公元1066年12月28日','panel_state_text':'移动：剩余1天','description':'与0秒同一行军剩余1天状态，250人、100/100；顶部暂停可见。'},
 {'date_text':'公元1066年12月29日','panel_state_text':'待命','description':'左下面板改成营地背景和待命；250军旗单独出现在阿普利亚内陆新位置，原剩余1天显示消失。北侧另有500对3094战斗条，不能当成Army93交战证据。'},
 {'date_text':'公元1066年12月29日','panel_state_text':'待命','description':'到达后同一250军旗位置及待命面板，250人、100/100。'},
 {'date_text':'公元1066年12月29日','panel_state_text':'待命','description':'到达后待命与250军旗保持；日期仍Dec29、250人、100/100。'},
 {'date_text':'公元1066年12月29日','panel_state_text':'待命','description':'到达后待命与250军旗保持；日期仍Dec29、250人、100/100。'}
]
samples=[]
for sample,obs in zip(report['samples'],observations):
    samples.append({**sample,'AI_visual_observation':obs,'AI_sample_viewed':True,'observation_basis':'actual existing original-size JPEG opened with view_image; native facts come from independent saved response bodies','pause_banner_visible_at_sample':True,'coastal_hover_tooltip_visible':False,'system_modal_or_right_notification_visible':False,'mouse_pointer':'Army panel header','Root_visual_review':None,'human_approval':False})
cuts=[
 {'id':'R0177-prearrival-moving-one-day','in_seconds':0,'out_seconds':4,'sample_support_seconds':[0,4],'purpose':'250人、补给100/100、剩余1天、Dec28的到达前基线。'},
 {'id':'R0177-natural-arrival-transition','in_seconds':4,'out_seconds':10,'sample_support_seconds':[4,10],'purpose':'250人从剩余1天转为待命，地图250旗换位，Dec28转Dec29。实际首次转换只限定在(4,10]秒。'},
 {'id':'R0177-arrived-stationary-short','in_seconds':10,'out_seconds':15,'sample_support_seconds':[10,15],'purpose':'到达后250人/100/100/待命、Dec29暂停的短对照。'},
 {'id':'R0177-arrived-paused-long-hold','in_seconds':15,'out_seconds':43.5,'sample_support_seconds':[15,30,43.5],'purpose':'到达后暂停留屏的长备选；最终应按叙事裁短，样本之间的连续clean尚待复看。'}
]
for cut in cuts:
    cut.update({'state':'CANDIDATE_PENDING_ROOT_CONTINUOUS_REVIEW','clean_spans_certified':False,'Root_review':None,'human_1x_review':False,'human_signoff':False})
candidate={'schema':'xar.e04.R0177-coastal-arrival-cut-candidates.actual.v1','state':'ACTUAL_AI_SAMPLES_VIEWED_PENDING_ROOT_CONTINUOUS_REVIEW','at_utc':now(),'raw_identity_reused':report['raw_identity_reused'],'actual_machine_report':pin(OUT/'report.json'),'actual_native_excerpts':pin(OUT/'native-arrival-excerpts.actual-a01.json'),'samples':samples,'cut_candidates':cuts,'visible_arrival_state_transition_bracket_seconds':{'lower_exclusive':4,'upper_inclusive':10},'exact_first_state_change_PTS':None,'phase_completion_used_as_first_pixel_time':False,'all_six_samples_paused_banner':True,'continuous_paused_interval_proven_from_samples':False,'narration_limits':['Army93为正常陆上到达，其他1195船模属于别的军队，不把它说成Army93登船。','地图北侧500对3094战斗条属于背景，Army93原生读回in_combat=false。','250人/100/100是可见基线与到达后读数，不能充当R07补给恢复或损耗实验通过。','所有候选尚缺Root连续复看，不能由六帧自动授予连续clean、1×或signoff。'],'new_partial_decode_needed':False,'partial_decode_omission_reason':'六个指定样本已提供明确(4,10]秒转换范围；剪辑候选可审，不为精确帧定位另加样本/解码。','raw_SHA_reads':0,'raw_reencodes':0,'metadata_probe_count':1,'strict_whole_decode_count':1,'additional_seek_count':0,'new_SDK_game_desktop_recorder_main_tree_actions':0,'clean_capture_complete':False,'clean_spans_certified':False,'continuous_clean_review':False,'Root_visual_approval':None,'human_1x_review':False,'human_signoff':False,'adapter_GREEN_capture_report_created':False,'sealing_source':pin(Path(__file__))}
write(OUT/'cut-candidates.actual-a01.json',candidate)
md='''R0177：250人军队正常到达沿海省份，候选镜头（Root连续复看待办）

45.000秒 / 1350帧 / 2560×1440@30 / H264 yuv420p / 无音频。一次probe和一次严格全解码通过；指定六帧同支抽取并已实际看图。无原片重hash、重编码、额外seek或重复完整解码。

|时码|剪辑候选与可授事实|
|---|---|
|00:00–00:04|250人、100/100、移动剩余1天，Dec28暂停。|
|00:04–00:10|自然到达转换：面板改待命、地图250旗换位、日期到Dec29；转换仅被括在(4,10]秒。|
|00:10–00:15|到达后待命短对照，250人、100/100、Dec29暂停。|
|00:15–00:43.5|到达后暂停留屏长备选，按叙事裁短；尚未连续复看。|

原生独立读回：Army93，date53146824/current2619/route[2624]/moving；自然一天后date53146848/current2624/route complete_empty/regular/paused/in_combat=false。此阶段是normal preparation，R07_treatment_started=false、R07_PASS=false，不能讲成补给恢复实验通过。null且unobservable的move_target不能证明target字段已清空。

recorder.started=20:23:25.077252Z；Root交接给出的phase done=20:23:37.477144Z（+12.399892秒）只作业务完成时刻，不能套成首次像素PTS。encoded PTS与wall clock未校准，实际画面以(4,10]秒样本括界为准。

全部六帧有暂停横幅；样本之间不能据此断言持续暂停。未见旧海岸tooltip、系统弹窗或右侧通知；鼠标停Army header。地图北侧500对3094战斗条可见但不遮250旗或Army面板；这不是Army93交战。1195船模也不是Army93。左下军队面板为内容，遮挡部分地图。本包不生成approval、GREEN capture report、连续clean或human 1× credit。
'''
with (OUT/'CUT-CANDIDATES.actual-a01.md').open('x',encoding='utf-8',newline='\n') as f:f.write(md)

portable=OUT/'portable-source'
portable.mkdir(exist_ok=False)
portable_files=[]
for name in ('audit_r0177_finished_raw_a01.py','actual-finished-binding-a01.json','seal_r0177_candidates_a01.py'):
    original=PREP/name
    require(original.suffix in ('.py','.json') and original.stat().st_size<100000,'bounded existing source required')
    with (portable/name).open('xb') as f:f.write(original.read_bytes())
    pp=pin(portable/name);portable_files.append({'relative_path':str((portable/name).relative_to(OUT)).replace('\\','/'),'bytes':pp['bytes'],'sha256':pp['sha256']})
index={'schema':'xar.e04.R0177-portable-code-evidence-index.actual.v1','at_utc':now(),'raw_original_not_copied':report['raw_identity_reused'],'raw_sha_basis':'actual closed recorder identity reused; audit reads source for probe and strict decode but does not hash it','source_head':report['actual_source_head'],'runtime_scope':native['exact_runtime_binding'],'files':portable_files,'machine_report':{'relative_path':'report.json',**{k:v for k,v in pin(OUT/'report.json').items() if k!='path'}},'native_excerpts':{'relative_path':'native-arrival-excerpts.actual-a01.json',**{k:v for k,v in pin(OUT/'native-arrival-excerpts.actual-a01.json').items() if k!='path'}},'cut_candidates':{'relative_path':'cut-candidates.actual-a01.json',**{k:v for k,v in pin(OUT/'cut-candidates.actual-a01.json').items() if k!='path'}},'samples':[{'relative_path':'samples/'+Path(s['image']['path']).name,'bytes':s['image']['bytes'],'sha256':s['image']['sha256'],'source_frame_ordinal':s['source_frame_ordinal'],'original_pts_ticks':s['original_pts_ticks'],'time_base':s['time_base']} for s in samples],'reuse_contract':['knowledge and code reusable on another machine; raw video must be supplied separately if needed','scene-specific verifier declares exact original absolute paths, verified Python and existing FFmpeg locations; adapt these explicitly in a new source/run, never reinterpret old evidence','source SHA/runtime/scene/raw identity and fixed original deadline are this actual attempt only; no future runtime or game version acceptance inferred','portable-source files are copies of exact code/input for inspection and reuse, not permission to rerun this completed scan','no SDK/desktop/game/recorder/network required for bounded JSON evidence consumption'],'human_approval':False,'cloud_transfer_performed':False}
write(OUT/'PORTABLE-CODE-INDEX.actual-a01.json',index)
delivery={'schema':'xar.e04.R0177-root-cut-delivery.actual.v1','at_utc':now(),'state':'RAW_MACHINE_PASS_AND_ACTUAL_SIX_SAMPLE_CUT_CANDIDATES_PENDING_ROOT_REVIEW','raw_identity_reused':report['raw_identity_reused'],'machine_report':pin(OUT/'report.json'),'native_excerpts':pin(OUT/'native-arrival-excerpts.actual-a01.json'),'cut_candidates':pin(OUT/'cut-candidates.actual-a01.json'),'cut_table':pin(OUT/'CUT-CANDIDATES.actual-a01.md'),'portable_code_index':pin(OUT/'PORTABLE-CODE-INDEX.actual-a01.json'),'samples':[s['image'] for s in samples],'media_summary':'45.000 s / 1350 frames / 2560x1440@30 / h264 yuv420p / silent; one probe plus one strict full decode, 6 same-branch actual samples viewed','arrival_state_change_bracket_seconds':'(4,10]','exact_first_state_change_PTS':None,'phase_done_equals_first_pixel_claimed':False,'new_Move_in_pipeline':0,'R07_treatment_started':False,'R07_PASS':False,'continuous_clean_review':False,'human_1x_review':False,'human_signoff':False,'raw_SHA_reads':0,'raw_reencodes':0,'extra_seek_count':0,'budget_pool':'original active32MiB allocation','all_derived_bytes_before_receipt':size(),'all_derived_limit_bytes':LIMIT,'fixed_deadline_utc':DEADLINE.isoformat(),'SDK_game_desktop_recorder_main_tree_Git_OneDrive_actions':0}
write(OUT/'ROOT-CUT-DELIVERY.actual-a01.json',delivery)
require(size()<=LIMIT,'all derived evidence including portable code exceeds 3 MiB')
print(json.dumps({'delivery':pin(OUT/'ROOT-CUT-DELIVERY.actual-a01.json'),'candidates':pin(OUT/'cut-candidates.actual-a01.json'),'portable_code_index':pin(OUT/'PORTABLE-CODE-INDEX.actual-a01.json'),'native_excerpts':pin(OUT/'native-arrival-excerpts.actual-a01.json'),'all_derived_bytes':size(),'limit_bytes':LIMIT},ensure_ascii=False,indent=2))
