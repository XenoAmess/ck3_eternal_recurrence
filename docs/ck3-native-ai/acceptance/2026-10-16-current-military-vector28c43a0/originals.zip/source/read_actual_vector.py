"""One source-proved28C43A0 extent; no transitive callee reads."""
from pathlib import Path
import capstone
from capstone.x86 import X86_OP_IMM
import datetime as dt
import hashlib
import json
import struct
import sys
import time

R=Path(__file__).resolve().parent
def need(ok,message):
    if not ok:raise ValueError(message)
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def new(name,j):
    with (R/name).open('x',encoding='utf-8',newline='\n') as f:
        if isinstance(j,str):f.write(j)
        else:json.dump(j,f,indent=2);f.write('\n')
def main():
    need(load(R/'PLAN-CHECK.actual.json')['returncode']==0,'Plan must pass first')
    plan=load(R/'plan-a01.json');layout=load(plan['layout_receipt']);identity=load(plan['identity_receipt'])
    source=Path(identity['frozen_path']);before=source.stat();frozen=layout['frozen_metadata']
    need(identity['sha256']==plan['build']['exe_sha256'],'Exact4 cached SHA differs')
    need((before.st_size,before.st_mtime_ns,before.st_ino)==(frozen['bytes'],frozen['mtime_ns'],frozen['inode']),'Frozen qualified input changed')
    reads=[];metadata=0;code=0;started=time.monotonic()
    try:
        with source.open('rb') as f:
            def read(rva,count,kind,why):
                nonlocal metadata,code
                need(time.monotonic()-started<30 and len(reads)<48,'Read/wall bound')
                if kind=='code':need(code+count<=8192,'Code bound');code+=count
                else:need(metadata+count<=512,'Metadata bound');metadata+=count
                s=next(s for s in layout['sections'] if s['va']<=rva<rva+count<=s['va']+s['rawsize'])
                off=s['raw']+rva-s['va'];f.seek(off);b=f.read(count);need(len(b)==count,'Short bounded read')
                reads.append(dict(rva=rva,file_offset=off,bytes=count,kind=kind,why=why,hex=b.hex() if kind=='metadata' else None,sha256=hashlib.sha256(b).hexdigest()))
                return b
            ex=layout['exception_directory'];entries={}
            def entry(i):
                need(0<=i<ex['entries'],'Exception index bound')
                if i not in entries:entries[i]=struct.unpack('<III',read(ex['rva']+i*12,12,'metadata','Binary search uniquely source-proved callee28C43A0'))
                return entries[i]
            lo,hi=0,ex['entries']
            while lo<hi:
                mid=(lo+hi)//2
                if entry(mid)[0]<=0x28C43A0:lo=mid+1
                else:hi=mid
            index=lo-1;begin,end,unwind=entry(index)
            need(begin==0x28C43A0 and begin<end,'Exact callee is not one unique entry extent')
            header=read(unwind,4,'metadata','Only actual containing extent unwind flags/count')
            flags=header[0]>>3;chain=None
            if flags&4:
                at=unwind+4+((header[2]+1)//2)*4
                chain=struct.unpack('<III',read(at,12,'metadata','Only explicit CHAININFO root tuple'))
            need(chain is None,'CHAININFO makes unique complete function extent unresolved; stop before body')
            need(0<end-begin<=8192,'Declared function extent exceeds8192; stop before body')
            body=read(begin,end-begin,'code','Entire sole declared.pdata function at exact source-proved callee28C43A0')
        after=source.stat()
        need((before.st_size,before.st_mtime_ns,before.st_ino)==(after.st_size,after.st_mtime_ns,after.st_ino),'Frozen input changed during read')
        with (R/'actual-function.bin').open('xb') as f:f.write(body)
        dis=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64);dis.detail=True
        ins=list(dis.disasm(body,begin))
        need(sum(i.size for i in ins)==len(body),'Complete function decode failed; retain partial source')
        asm='\n'.join(f'{i.address:08X}  {i.bytes.hex(" "):<44} {i.mnemonic} {i.op_str}' for i in ins)+'\n'
        new('actual-function.asm',asm)
        calls=[dict(at_rva=i.address,target_rva=i.operands[0].imm,kind=i.mnemonic) for i in ins if i.mnemonic in ('call','jmp') and i.operands and i.operands[0].type==X86_OP_IMM]
        new('READ-RECEIPT.actual.json',dict(status='FULL_SOLE_FUNCTION_CAPTURED',machine_id=plan['machine_id'],at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),plan=pin(R/'plan-a01.json'),identity=pin(plan['identity_receipt']),layout=pin(plan['layout_receipt']),qualified_EXE_SHA_reused_not_rehashed=identity['sha256'],source=str(source),tool_argv=sys.argv,python=sys.executable,capstone_version=capstone.__version__,function=dict(begin_rva=begin,end_exclusive=end,bytes=len(body),pdata_index=index,unwind_rva=unwind,flags=flags,chained_runtime_function=chain,hex=body.hex(),sha256=hashlib.sha256(body).hexdigest(),instruction_count=len(ins),direct_calls_and_jumps=calls),read_ledger=reads,new_EXE_code_bytes=code,new_EXE_metadata_bytes=metadata,new_EXE_read_calls=len(reads),whole_EXE_hashes=0,global_scans=0,callee_reads=0,SDK_game_desktop_main_build_actions=0,maintenance_attribution='unclosed'))
        print(json.dumps(dict(begin=hex(begin),end=hex(end),code_bytes=code,metadata_bytes=metadata,reads=len(reads),calls=calls)))
        return 0
    except Exception as e:
        new('STOPPED.actual.json',dict(error=repr(e),at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),read_ledger=reads,code_bytes=code,metadata_bytes=metadata,read_calls=len(reads),further_reads_stopped=True,scope_not_expanded=True,maintenance_attribution='unclosed'))
        raise
if __name__=='__main__':raise SystemExit(main())
