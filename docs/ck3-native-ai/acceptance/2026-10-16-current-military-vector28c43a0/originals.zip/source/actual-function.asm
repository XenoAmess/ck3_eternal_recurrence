028C43A0  48 89 5c 24 08                               mov qword ptr [rsp + 8], rbx
028C43A5  48 89 74 24 10                               mov qword ptr [rsp + 0x10], rsi
028C43AA  57                                           push rdi
028C43AB  48 83 ec 20                                  sub rsp, 0x20
028C43AF  48 8b da                                     mov rbx, rdx
028C43B2  48 8b f1                                     mov rsi, rcx
028C43B5  0f 57 c0                                     xorps xmm0, xmm0
028C43B8  0f 11 02                                     movups xmmword ptr [rdx], xmm0
028C43BB  0f 11 42 10                                  movups xmmword ptr [rdx + 0x10], xmm0
028C43BF  0f 11 42 20                                  movups xmmword ptr [rdx + 0x20], xmm0
028C43C3  0f 11 42 30                                  movups xmmword ptr [rdx + 0x30], xmm0
028C43C7  0f 11 42 40                                  movups xmmword ptr [rdx + 0x40], xmm0
028C43CB  48 8b 89 c0 01 00 00                         mov rcx, qword ptr [rcx + 0x1c0]
028C43D2  48 85 c9                                     test rcx, rcx
028C43D5  74 09                                        je 0x28c43e0
028C43D7  48 81 c1 78 02 00 00                         add rcx, 0x278
028C43DE  eb 07                                        jmp 0x28c43e7
028C43E0  48 8d 0d 31 65 b9 02                         lea rcx, [rip + 0x2b96531]
028C43E7  48 8b 01                                     mov rax, qword ptr [rcx]
028C43EA  48 63 49 0c                                  movsxd rcx, dword ptr [rcx + 0xc]
028C43EE  48 8d 0c 88                                  lea rcx, [rax + rcx*4]
028C43F2  48 3b c1                                     cmp rax, rcx
028C43F5  0f 84 16 01 00 00                            je 0x28c4511
028C43FB  4c 8b 1d 7e 9f 45 03                         mov r11, qword ptr [rip + 0x3459f7e]
028C4402  4c 8b 15 3f 9a 45 03                         mov r10, qword ptr [rip + 0x3459a3f]
028C4409  48 8b 3d 68 9f 45 03                         mov rdi, qword ptr [rip + 0x3459f68]
028C4410  4d 85 db                                     test r11, r11
028C4413  74 2c                                        je 0x28c4441
028C4415  44 8b 08                                     mov r9d, dword ptr [rax]
028C4418  41 8b d1                                     mov edx, r9d
028C441B  81 e2 ff ff ff 00                            and edx, 0xffffff
028C4421  41 3b 53 2c                                  cmp edx, dword ptr [r11 + 0x2c]
028C4425  73 1a                                        jae 0x28c4441
028C4427  44 8b c2                                     mov r8d, edx
028C442A  4d 03 c0                                     add r8, r8
028C442D  49 8b 53 20                                  mov rdx, qword ptr [r11 + 0x20]
028C4431  4a 8b 54 c2 08                               mov rdx, qword ptr [rdx + r8*8 + 8]
028C4436  48 85 d2                                     test rdx, rdx
028C4439  74 06                                        je 0x28c4441
028C443B  44 39 4a 10                                  cmp dword ptr [rdx + 0x10], r9d
028C443F  74 03                                        je 0x28c4444
028C4441  48 8b d7                                     mov rdx, rdi
028C4444  83 7a 18 00                                  cmp dword ptr [rdx + 0x18], 0
028C4448  0f 85 b6 00 00 00                            jne 0x28c4504
028C444E  4d 85 d2                                     test r10, r10
028C4451  74 30                                        je 0x28c4483
028C4453  44 8b 8a 78 01 00 00                         mov r9d, dword ptr [rdx + 0x178]
028C445A  41 8b d1                                     mov edx, r9d
028C445D  81 e2 ff ff ff 00                            and edx, 0xffffff
028C4463  41 3b 52 2c                                  cmp edx, dword ptr [r10 + 0x2c]
028C4467  73 1a                                        jae 0x28c4483
028C4469  44 8b c2                                     mov r8d, edx
028C446C  4d 03 c0                                     add r8, r8
028C446F  49 8b 52 20                                  mov rdx, qword ptr [r10 + 0x20]
028C4473  4a 8b 54 c2 08                               mov rdx, qword ptr [rdx + r8*8 + 8]
028C4478  48 85 d2                                     test rdx, rdx
028C447B  74 06                                        je 0x28c4483
028C447D  44 39 4a 10                                  cmp dword ptr [rdx + 0x10], r9d
028C4481  74 0d                                        je 0x28c4490
028C4483  48 8b 15 c6 99 45 03                         mov rdx, qword ptr [rip + 0x34599c6]
028C448A  66 0f 1f 44 00 00                            nop word ptr [rax + rax]
028C4490  4c 8b 82 30 01 00 00                         mov r8, qword ptr [rdx + 0x130]
028C4497  4c 01 03                                     add qword ptr [rbx], r8
028C449A  4c 8b 82 38 01 00 00                         mov r8, qword ptr [rdx + 0x138]
028C44A1  4c 01 43 08                                  add qword ptr [rbx + 8], r8
028C44A5  4c 8b 82 40 01 00 00                         mov r8, qword ptr [rdx + 0x140]
028C44AC  4c 01 43 10                                  add qword ptr [rbx + 0x10], r8
028C44B0  4c 8b 82 48 01 00 00                         mov r8, qword ptr [rdx + 0x148]
028C44B7  4c 01 43 18                                  add qword ptr [rbx + 0x18], r8
028C44BB  4c 8b 82 50 01 00 00                         mov r8, qword ptr [rdx + 0x150]
028C44C2  4c 01 43 20                                  add qword ptr [rbx + 0x20], r8
028C44C6  4c 8b 82 58 01 00 00                         mov r8, qword ptr [rdx + 0x158]
028C44CD  4c 01 43 28                                  add qword ptr [rbx + 0x28], r8
028C44D1  4c 8b 82 60 01 00 00                         mov r8, qword ptr [rdx + 0x160]
028C44D8  4c 01 43 30                                  add qword ptr [rbx + 0x30], r8
028C44DC  4c 8b 82 68 01 00 00                         mov r8, qword ptr [rdx + 0x168]
028C44E3  4c 01 43 38                                  add qword ptr [rbx + 0x38], r8
028C44E7  4c 8b 82 70 01 00 00                         mov r8, qword ptr [rdx + 0x170]
028C44EE  4c 01 43 40                                  add qword ptr [rbx + 0x40], r8
028C44F2  4c 8b 82 78 01 00 00                         mov r8, qword ptr [rdx + 0x178]
028C44F9  4c 01 43 48                                  add qword ptr [rbx + 0x48], r8
028C44FD  48 8b 3d 74 9e 45 03                         mov rdi, qword ptr [rip + 0x3459e74]
028C4504  48 83 c0 04                                  add rax, 4
028C4508  48 3b c1                                     cmp rax, rcx
028C450B  0f 85 ff fe ff ff                            jne 0x28c4410
028C4511  45 33 c0                                     xor r8d, r8d
028C4514  48 8b d6                                     mov rdx, rsi
028C4517  48 8b cb                                     mov rcx, rbx
028C451A  e8 61 d9 c1 ff                               call 0x24e1e80
028C451F  48 8b c3                                     mov rax, rbx
028C4522  48 8b 5c 24 30                               mov rbx, qword ptr [rsp + 0x30]
028C4527  48 8b 74 24 38                               mov rsi, qword ptr [rsp + 0x38]
028C452C  48 83 c4 20                                  add rsp, 0x20
028C4530  5f                                           pop rdi
028C4531  c3                                           ret 
