from pathlib import Path
import datetime as dt
import hashlib
import json
import zipfile

R=Path(__file__).resolve().parent
BASE=R.parent
C=R/'canonical-candidate-a01'
NEW=C/'newfiles'
A=NEW/'docs/ck3-native-ai/acceptance/2026-10-16-current-military-vector28c43a0'
def pin(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def new(p,j):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(j,f,ensure_ascii=False,indent=2);f.write('\n')
def main():
    receipt=json.loads((R/'READ-RECEIPT.actual.json').read_bytes())
    new(R/'SOURCE-CONTRACT.actual.json',dict(machine_id='desktop-3fevhd2-1c74096080',at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),exact_game_SHA=receipt['qualified_EXE_SHA_reused_not_rehashed'],function=dict(begin='0x28C43A0',end_exclusive='0x28C4532',bytes=402,instructions=95,sha256=receipt['function']['sha256'],unchained=True),source_caller=dict(at='0x2C141D7',target='0x28C43A0',entryRCX='Character',entryRDX='80B output',route='Existing currentmaintenance getter public thirdargument null'),source_steps=[dict(at='0x28C43B5..28C43C7',action='Zero80B output'),dict(at='0x28C43CB..28C43E7',action='Load *(Character+1C0); context+278 is inline ID descriptor, null uses static fallback'),dict(at='0x28C43E7..28C43EE',action='Descriptor [0] pointer and signed32[+0C] count identify4B IDs'),dict(at='0x28C4410..28C4441',action='RegistryA:24bit index capacity/entry/FullID+10 check, fallbackA'),dict(at='0x28C4444',action='Only objectA dword+18==0 contributes'),dict(at='0x28C444E..28C4483',action='Read objectA+178 FullID and resolve via registryB, otherwise fallbackB'),dict(at='0x28C4490..28C44F9',action='Ten qwords objectB+130..178 added slotwise to output80B'),dict(at='0x28C451A',action='Direct CALL24E1E80(output,originalCharacter,0); not read'),dict(at='0x28C451F..28C4531',action='Return original output pointer')],registryA_class_name=None,registryB_class_name=None,context278_descriptor_role='Source-defined ID list, not wallet extension278 tracker',arithmetic='Native64bit ADD, no source clamp claim',direct_secondary_context28_30_read_or_store=False,rawterm_alias_proved=False,unexpanded_tail=dict(call='0x28C451A',callee='0x24E1E80',arguments=['output80B','originalCharacter',0],source_read=False),other_vector_owner='/root/e04_event_1070_followup owns2C142B0; this lane did not read it',actual_new_live_sample=False,actual_paid_wallet_chain=False,maintenance_attribution='unclosed',read_receipt=pin(R/'READ-RECEIPT.actual.json')))
    new(R/'EXECUTION-DONE.actual.json',dict(argv=['D:/workspace/ck3_eternal_recurrence/tools/.venv/Scripts/python.exe','-B','-O',str(R/'read_actual_vector.py')],returncode=0,at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),scope=dict(code_bytes=402,metadata_bytes=220,read_calls=20,callee_reads=0,whole_EXE_hashes=0),source_receipt=pin(R/'READ-RECEIPT.actual.json')))
    originals={'source/'+p.name:p for p in R.iterdir() if p.is_file() and p.name!='prepare_delivery.py'}
    originals['failed-a01/FAILED-PREPARE.actual.json']=BASE/'maintenance-current-vector28C43A0-source-a01/FAILED-PREPARE.actual.json'
    prior=BASE/'payment-settlement-branch-b-a01/source-read-a02'
    for name in ['current_military.bin','current_military.asm']:originals['caller/'+name]=prior/name
    originals['identity/frozen.actual.json']=BASE/'frozen-game-12004/IDENTITY.actual.json'
    originals['identity/pe-layout-reused.json']=BASE/'maintenance-parent-r0174-a01/parent28F7939-source-a01/inputs/pe-layout-reused.json'
    archive=A/'originals.zip';members=[]
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for member,path in sorted(originals.items()):
            b=path.read_bytes()
            if len(b)>131072:raise ValueError('Unexpected large original')
            info=zipfile.ZipInfo(member,(2026,10,16,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
            members.append(dict(member=member,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
    apin=pin(archive);apin['path']='originals.zip'
    new(A/'ARCHIVE-INDEX.json',dict(archive=apin,members=members,historical_C_drive_executors_not_portable_commands=True,new_live_credit=False))
    with (A/'SOURCE-CONTRACT.actual.json').open('xb') as f:f.write((R/'SOURCE-CONTRACT.actual.json').read_bytes())
    files=[dict(path=p.relative_to(NEW).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(NEW.rglob('*')) if p.is_file()]
    new(A/'FILE-MANIFEST.json',dict(schema='xar.current-vector-source-files.v1',files=files))
    copies=[dict(source=str(p),relative_target=p.relative_to(NEW).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(NEW.rglob('*')) if p.is_file()]
    new(C/'REPO-COPY.actual.json',dict(status='NEW_DOC_AND_SOURCE_EVIDENCE_ONLY',base='b42afbbd85df3802b1fa6222f7aac403c2adf735',files=copies,overwrite_existing_targets=False,link_dependencies=['PreviousR0178 writer canonicaldoc','Previous NET allocator canonicaldoc'],no_runtime_native_or_existing_file_changes=True))
    print(json.dumps(dict(archive=pin(archive),members=len(members),current_lane_bytes=sum(p.stat().st_size for p in R.rglob('*') if p.is_file()))))
    return 0
if __name__=='__main__':raise SystemExit(main())
