02C13F60  48 89 5c 24 08                   mov qword ptr [rsp + 8], rbx
02C13F65  48 89 74 24 10                   mov qword ptr [rsp + 0x10], rsi
02C13F6A  48 89 7c 24 18                   mov qword ptr [rsp + 0x18], rdi
02C13F6F  55                               push rbp
02C13F70  41 56                            push r14
02C13F72  41 57                            push r15
02C13F74  48 8d ac 24 90 fe ff ff          lea rbp, [rsp - 0x170]
02C13F7C  48 81 ec 70 02 00 00             sub rsp, 0x270
02C13F83  49 8b f8                         mov rdi, r8
02C13F86  4c 8b f2                         mov r14, rdx
02C13F89  48 8b d9                         mov rbx, rcx
02C13F8C  0f 57 c0                         xorps xmm0, xmm0
02C13F8F  0f 11 01                         movups xmmword ptr [rcx], xmm0
02C13F92  0f 11 41 10                      movups xmmword ptr [rcx + 0x10], xmm0
02C13F96  0f 11 41 20                      movups xmmword ptr [rcx + 0x20], xmm0
02C13F9A  0f 11 41 30                      movups xmmword ptr [rcx + 0x30], xmm0
02C13F9E  0f 11 41 40                      movups xmmword ptr [rcx + 0x40], xmm0
02C13FA2  4d 85 c0                         test r8, r8
02C13FA5  0f 84 24 02 00 00                je 0x142c141cf
02C13FAB  49 8b 30                         mov rsi, qword ptr [r8]
02C13FAE  45 33 ff                         xor r15d, r15d
02C13FB1  48 8d 05 70 64 bf 01             lea rax, [rip + 0x1bf6470]
02C13FB8  48 89 44 24 30                   mov qword ptr [rsp + 0x30], rax
02C13FBD  c7 44 24 38 1a 00 00 00          mov dword ptr [rsp + 0x38], 0x1a
02C13FC5  44 88 7c 24 3c                   mov byte ptr [rsp + 0x3c], r15b
02C13FCA  33 d2                            xor edx, edx
02C13FCC  41 b8 a8 01 00 00                mov r8d, 0x1a8
02C13FD2  48 8d 4d c0                      lea rcx, [rbp - 0x40]
02C13FD6  e8 35 2f 61 01                   call 0x144226f10
02C13FDB  48 8d 4d c0                      lea rcx, [rbp - 0x40]
02C13FDF  e8 fc 59 c7 fd                   call 0x1408899e0
02C13FE4  90                               nop 
02C13FE5  4c 89 7c 24 28                   mov qword ptr [rsp + 0x28], r15
02C13FEA  48 8d 45 c0                      lea rax, [rbp - 0x40]
02C13FEE  48 89 44 24 20                   mov qword ptr [rsp + 0x20], rax
02C13FF3  45 33 c9                         xor r9d, r9d
02C13FF6  45 33 c0                         xor r8d, r8d
02C13FF9  48 8d 54 24 30                   lea rdx, [rsp + 0x30]
02C13FFE  48 8d 4c 24 50                   lea rcx, [rsp + 0x50]
02C14003  e8 18 26 20 01                   call 0x143e16620
02C14008  90                               nop 
02C14009  4c 39 7d c0                      cmp qword ptr [rbp - 0x40], r15
02C1400D  74 23                            je 0x142c14032
02C1400F  48 8d 4d c0                      lea rcx, [rbp - 0x40]
02C14013  e8 b8 5a c7 fd                   call 0x140889ad0
02C14018  48 8b 4d d0                      mov rcx, qword ptr [rbp - 0x30]
02C1401C  48 8b 01                         mov rax, qword ptr [rcx]
02C1401F  45 8d 47 08                      lea r8d, [r15 + 8]
02C14023  48 8b 55 c0                      mov rdx, qword ptr [rbp - 0x40]
02C14027  ff 50 10                         call qword ptr [rax + 0x10]
02C1402A  4c 89 7d c0                      mov qword ptr [rbp - 0x40], r15
02C1402E  44 89 7d c8                      mov dword ptr [rbp - 0x38], r15d
02C14032  4d 8b c7                         mov r8, r15
02C14035  48 8d 54 24 50                   lea rdx, [rsp + 0x50]
02C1403A  48 8b ce                         mov rcx, rsi
02C1403D  e8 de 7f 81 ff                   call 0x14242c020
02C14042  48 8b f0                         mov rsi, rax
02C14045  48 8d 4c 24 50                   lea rcx, [rsp + 0x50]
02C1404A  e8 01 20 c4 fd                   call 0x140856050
02C1404F  8b 4f 08                         mov ecx, dword ptr [rdi + 8]
02C14052  48 89 74 24 40                   mov qword ptr [rsp + 0x40], rsi
02C14057  89 4c 24 48                      mov dword ptr [rsp + 0x48], ecx
02C1405B  c6 44 24 4c 00                   mov byte ptr [rsp + 0x4c], 0
02C14060  89 4c 24 20                      mov dword ptr [rsp + 0x20], ecx
02C14064  4c 8d 4c 24 40                   lea r9, [rsp + 0x40]
02C14069  45 33 c0                         xor r8d, r8d
02C1406C  48 8d 54 24 70                   lea rdx, [rsp + 0x70]
02C14071  49 8b ce                         mov rcx, r14
02C14074  e8 c7 04 cb ff                   call 0x1428c4540
02C14079  48 63 47 08                      movsxd rax, dword ptr [rdi + 8]
02C1407D  4c 8b 4c c4 70                   mov r9, qword ptr [rsp + rax*8 + 0x70]
02C14082  49 8b c1                         mov rax, r9
02C14085  48 f7 d8                         neg rax
02C14088  48 89 46 78                      mov qword ptr [rsi + 0x78], rax
02C1408C  b2 05                            mov dl, 5
02C1408E  48 8b ce                         mov rcx, rsi
02C14091  e8 ea 71 81 ff                   call 0x14242b280
02C14096  41 8b cf                         mov ecx, r15d
02C14099  b8 02 00 00 00                   mov eax, 2
02C1409E  4d 85 c9                         test r9, r9
02C140A1  0f 44 c8                         cmove ecx, eax
02C140A4  0f b6 86 8e 00 00 00             movzx eax, byte ptr [rsi + 0x8e]
02C140AB  24 fd                            and al, 0xfd
02C140AD  0a c8                            or cl, al
02C140AF  88 8e 8e 00 00 00                mov byte ptr [rsi + 0x8e], cl
02C140B5  80 7c 24 4c 00                   cmp byte ptr [rsp + 0x4c], 0
02C140BA  0f 84 c0 00 00 00                je 0x142c14180
02C140C0  c6 47 0c 01                      mov byte ptr [rdi + 0xc], 1
02C140C4  48 8d 05 7d 63 bf 01             lea rax, [rip + 0x1bf637d]
02C140CB  48 89 44 24 30                   mov qword ptr [rsp + 0x30], rax
02C140D0  c7 44 24 38 23 00 00 00          mov dword ptr [rsp + 0x38], 0x23
02C140D8  c6 44 24 3c 00                   mov byte ptr [rsp + 0x3c], 0
02C140DD  33 d2                            xor edx, edx
02C140DF  41 b8 a8 01 00 00                mov r8d, 0x1a8
02C140E5  48 8d 4d c0                      lea rcx, [rbp - 0x40]
02C140E9  e8 22 2e 61 01                   call 0x144226f10
02C140EE  48 8d 4d c0                      lea rcx, [rbp - 0x40]
02C140F2  e8 e9 58 c7 fd                   call 0x1408899e0
02C140F7  90                               nop 
02C140F8  4c 89 7c 24 28                   mov qword ptr [rsp + 0x28], r15
02C140FD  48 8d 45 c0                      lea rax, [rbp - 0x40]
02C14101  48 89 44 24 20                   mov qword ptr [rsp + 0x20], rax
02C14106  45 33 c9                         xor r9d, r9d
02C14109  45 33 c0                         xor r8d, r8d
02C1410C  48 8d 54 24 30                   lea rdx, [rsp + 0x30]
02C14111  48 8d 4c 24 50                   lea rcx, [rsp + 0x50]
02C14116  e8 05 25 20 01                   call 0x143e16620
02C1411B  90                               nop 
02C1411C  48 83 7d c0 00                   cmp qword ptr [rbp - 0x40], 0
02C14121  74 25                            je 0x142c14148
02C14123  48 8d 4d c0                      lea rcx, [rbp - 0x40]
02C14127  e8 a4 59 c7 fd                   call 0x140889ad0
02C1412C  48 8b 4d d0                      mov rcx, qword ptr [rbp - 0x30]
02C14130  48 8b 01                         mov rax, qword ptr [rcx]
02C14133  41 b8 08 00 00 00                mov r8d, 8
02C14139  48 8b 55 c0                      mov rdx, qword ptr [rbp - 0x40]
02C1413D  ff 50 10                         call qword ptr [rax + 0x10]
02C14140  4c 89 7d c0                      mov qword ptr [rbp - 0x40], r15
02C14144  44 89 7d c8                      mov dword ptr [rbp - 0x38], r15d
02C14148  48 8d 4e 18                      lea rcx, [rsi + 0x18]
02C1414C  48 8d 44 24 50                   lea rax, [rsp + 0x50]
02C14151  48 3b c8                         cmp rcx, rax
02C14154  74 1c                            je 0x142c14172
02C14156  48 8d 54 24 50                   lea rdx, [rsp + 0x50]
02C1415B  48 83 7c 24 68 10                cmp qword ptr [rsp + 0x68], 0x10
02C14161  48 0f 43 54 24 50                cmovae rdx, qword ptr [rsp + 0x50]
02C14167  4c 8b 44 24 60                   mov r8, qword ptr [rsp + 0x60]
02C1416C  e8 3f 1c c4 fd                   call 0x140855db0
02C14171  90                               nop 
02C14172  48 8d 4c 24 50                   lea rcx, [rsp + 0x50]
02C14177  e8 d4 1e c4 fd                   call 0x140856050
02C1417C  0f 1f 40 00                      nop dword ptr [rax]
02C14180  48 8b 44 24 70                   mov rax, qword ptr [rsp + 0x70]
02C14185  48 01 03                         add qword ptr [rbx], rax
02C14188  48 8b 44 24 78                   mov rax, qword ptr [rsp + 0x78]
02C1418D  48 01 43 08                      add qword ptr [rbx + 8], rax
02C14191  48 8b 45 80                      mov rax, qword ptr [rbp - 0x80]
02C14195  48 01 43 10                      add qword ptr [rbx + 0x10], rax
02C14199  48 8b 45 88                      mov rax, qword ptr [rbp - 0x78]
02C1419D  48 01 43 18                      add qword ptr [rbx + 0x18], rax
02C141A1  48 8b 45 90                      mov rax, qword ptr [rbp - 0x70]
02C141A5  48 01 43 20                      add qword ptr [rbx + 0x20], rax
02C141A9  48 8b 45 98                      mov rax, qword ptr [rbp - 0x68]
02C141AD  48 01 43 28                      add qword ptr [rbx + 0x28], rax
02C141B1  48 8b 45 a0                      mov rax, qword ptr [rbp - 0x60]
02C141B5  48 01 43 30                      add qword ptr [rbx + 0x30], rax
02C141B9  48 8b 45 a8                      mov rax, qword ptr [rbp - 0x58]
02C141BD  48 01 43 38                      add qword ptr [rbx + 0x38], rax
02C141C1  48 8b 45 b0                      mov rax, qword ptr [rbp - 0x50]
02C141C5  48 01 43 40                      add qword ptr [rbx + 0x40], rax
02C141C9  48 8b 45 b8                      mov rax, qword ptr [rbp - 0x48]
02C141CD  eb 5a                            jmp 0x142c14229
02C141CF  48 8d 54 24 70                   lea rdx, [rsp + 0x70]
02C141D4  49 8b ce                         mov rcx, r14
02C141D7  e8 c4 01 cb ff                   call 0x1428c43a0
02C141DC  48 8b d0                         mov rdx, rax
02C141DF  48 8b 08                         mov rcx, qword ptr [rax]
02C141E2  48 01 0b                         add qword ptr [rbx], rcx
02C141E5  48 8b 48 08                      mov rcx, qword ptr [rax + 8]
02C141E9  48 01 4b 08                      add qword ptr [rbx + 8], rcx
02C141ED  48 8b 48 10                      mov rcx, qword ptr [rax + 0x10]
02C141F1  48 01 4b 10                      add qword ptr [rbx + 0x10], rcx
02C141F5  48 8b 48 18                      mov rcx, qword ptr [rax + 0x18]
02C141F9  48 01 4b 18                      add qword ptr [rbx + 0x18], rcx
02C141FD  48 8b 40 20                      mov rax, qword ptr [rax + 0x20]
02C14201  48 01 43 20                      add qword ptr [rbx + 0x20], rax
02C14205  48 8b 42 28                      mov rax, qword ptr [rdx + 0x28]
02C14209  48 01 43 28                      add qword ptr [rbx + 0x28], rax
02C1420D  48 8b 42 30                      mov rax, qword ptr [rdx + 0x30]
02C14211  48 01 43 30                      add qword ptr [rbx + 0x30], rax
02C14215  48 8b 42 38                      mov rax, qword ptr [rdx + 0x38]
02C14219  48 01 43 38                      add qword ptr [rbx + 0x38], rax
02C1421D  48 8b 42 40                      mov rax, qword ptr [rdx + 0x40]
02C14221  48 01 43 40                      add qword ptr [rbx + 0x40], rax
02C14225  48 8b 42 48                      mov rax, qword ptr [rdx + 0x48]
02C14229  48 01 43 48                      add qword ptr [rbx + 0x48], rax
02C1422D  4c 8b c7                         mov r8, rdi
02C14230  49 8b d6                         mov rdx, r14
02C14233  48 8d 4c 24 70                   lea rcx, [rsp + 0x70]
02C14238  e8 73 00 00 00                   call 0x142c142b0
02C1423D  48 8b d0                         mov rdx, rax
02C14240  48 8b 08                         mov rcx, qword ptr [rax]
02C14243  48 01 0b                         add qword ptr [rbx], rcx
02C14246  48 8b 48 08                      mov rcx, qword ptr [rax + 8]
02C1424A  48 01 4b 08                      add qword ptr [rbx + 8], rcx
02C1424E  48 8b 48 10                      mov rcx, qword ptr [rax + 0x10]
02C14252  48 01 4b 10                      add qword ptr [rbx + 0x10], rcx
02C14256  48 8b 48 18                      mov rcx, qword ptr [rax + 0x18]
02C1425A  48 01 4b 18                      add qword ptr [rbx + 0x18], rcx
02C1425E  48 8b 48 20                      mov rcx, qword ptr [rax + 0x20]
02C14262  48 01 4b 20                      add qword ptr [rbx + 0x20], rcx
02C14266  48 8b 40 28                      mov rax, qword ptr [rax + 0x28]
02C1426A  48 01 43 28                      add qword ptr [rbx + 0x28], rax
02C1426E  48 8b 42 30                      mov rax, qword ptr [rdx + 0x30]
02C14272  48 01 43 30                      add qword ptr [rbx + 0x30], rax
02C14276  48 8b 42 38                      mov rax, qword ptr [rdx + 0x38]
02C1427A  48 01 43 38                      add qword ptr [rbx + 0x38], rax
02C1427E  48 8b 42 40                      mov rax, qword ptr [rdx + 0x40]
02C14282  48 01 43 40                      add qword ptr [rbx + 0x40], rax
02C14286  48 8b 42 48                      mov rax, qword ptr [rdx + 0x48]
02C1428A  48 01 43 48                      add qword ptr [rbx + 0x48], rax
02C1428E  48 8b c3                         mov rax, rbx
02C14291  4c 8d 9c 24 70 02 00 00          lea r11, [rsp + 0x270]
02C14299  49 8b 5b 20                      mov rbx, qword ptr [r11 + 0x20]
02C1429D  49 8b 73 28                      mov rsi, qword ptr [r11 + 0x28]
02C142A1  49 8b 7b 30                      mov rdi, qword ptr [r11 + 0x30]
02C142A5  49 8b e3                         mov rsp, r11
02C142A8  41 5f                            pop r15
02C142AA  41 5e                            pop r14
02C142AC  5d                               pop rbp
02C142AD  c3                               ret 
