import hashlib
import json
from pathlib import Path
import subprocess
import sys

repo=Path('C:/workspace/ck3_eternal_recurrence')
out=Path('C:/workspace/ck3_lyd_runtime_20261004/r39-common-injector-defender-20261010-001')
sys.path.insert(0,str(repo/'tools'))
import register_project_exe_exclusions as helper

ninja='C:/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
argv=[ninja,'-C','C:/cbr2','-d','explain','-n','xar_ck3_bridge_injector']
result=subprocess.run(argv,cwd=repo,capture_output=True,timeout=30)
(out/'injector-dry-run-explain.stdout.bin').write_bytes(result.stdout)
(out/'injector-dry-run-explain.stderr.bin').write_bytes(result.stderr)
manifest=helper.collect_manifest(repo,Path('C:/csr2/ck3_autonomous_player/native_bridge'),Path('C:/cbr2'),'Release',['xar_ck3_bridge_injector'],'common-runtime-20261010-source-af2045521')
assert len(manifest['files'])==1
assert Path(manifest['files'][0]['path']).resolve()==Path('C:/cbr2/xar_ck3_bridge_injector.exe').resolve()
assert manifest['files'][0]['sha256']=='2e22a985ba3166ce50ca1732901f0bac0629e8ff0f068de73330fdd5d09c86a8'
(out/'registration-manifest.readonly.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
provenance=out/'cmake-provenance'
provenance.mkdir(exist_ok=False)
for row in [manifest['cmake_index'],manifest['cmake_codemodel'],*manifest['target_provenance']]:
    path=Path(row['path'])
    (provenance/path.name).write_bytes(path.read_bytes())
report={'schema':'ck3-common-injector-readonly-provenance-v1','argv':argv,'exit_code':result.returncode,
        'stdout':result.stdout.decode(errors='replace'),'stderr':result.stderr.decode(errors='replace'),
        'registration_attempted':False,'cmake_manifest_single_exact_injector':True,
        'dry_run_interpretation':'CMake regeneration pending; no cl/link commands are shown. This does not establish whether binary recompilation is required after regeneration.',
        'fixed_injector_sha256':hashlib.sha256(Path('C:/cbr2/xar_ck3_bridge_injector.exe').read_bytes()).hexdigest(),
        'fixed_dll_sha256':hashlib.sha256(Path('C:/cbr2/xar_ck3_bridge.dll').read_bytes()).hexdigest()}
(out/'READONLY-DETAIL.actual.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report,indent=2))
