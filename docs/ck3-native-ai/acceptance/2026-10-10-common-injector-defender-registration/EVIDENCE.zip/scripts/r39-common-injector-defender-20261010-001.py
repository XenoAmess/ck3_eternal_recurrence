from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

ROOT=Path('C:/workspace/ck3_eternal_recurrence')
sys.path.insert(0,str(ROOT/'tools'))
import register_project_exe_exclusions as helper
from run_native_msvc import child_environment, initialize_msvc, visual_studio_installation, configure_command

B=Path('C:/workspace/ck3_lyd_runtime_20261004/r39-common-injector-defender-20261010-001')
B.mkdir(exist_ok=False)
S=Path('C:/csr2/ck3_autonomous_player/native_bridge')
D=Path('C:/cbr2')
M=Path('C:/workspace/ck3-common-runtime/20261010-002')
candidate='common-runtime-20261010-source-af2045521'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def pin(path):
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path)}

preserved={}
original=B/'original'
original.mkdir()
for label,path in {
    'msvc-configure.log':D/'msvc-configure.log', 'msvc-build.log':D/'msvc-build.log',
    'native-msvc-result.json':D/'native-msvc-result.json', 'CMakeCache.txt':D/'CMakeCache.txt',
    'build.ninja':D/'build.ninja', 'source02-build.stdout.log':M/'build.stdout.log',
    'source02-build.stderr.log':M/'build.stderr.log','BUILD-INPUTS.actual.json':M/'BUILD-INPUTS.actual.json',
    'BUILD-RESULT.actual.json':M/'BUILD-RESULT.actual.json','runtime-manifest.json':M/'manifest.json',
}.items():
    raw=path.read_bytes()
    (original/label).write_bytes(raw)
    preserved[label]=pin(path)
report={'schema':'ck3-common-injector-exact-defender-registration-v1',
        'started_utc':datetime.now(timezone.utc).isoformat(),'preserved_originals':preserved,
        'repo':str(ROOT),'source':str(S),'build':str(D),'external_candidate':candidate,
        'requested_targets':['xar_ck3_bridge_injector'],'build_invoked':False,
        'ck3_contacted':False,'steam_contacted':False,'steps':[],'status':'running'}
fixed=json.loads((M/'BUILD-RESULT.actual.json').read_bytes())
binaries=[Path(fixed[k]['path']) for k in ['dll','injector']]
report['binary_before']=[pin(p) for p in binaries]
for key,path in zip(['dll','injector'],binaries):
    if sha(path)!=fixed[key]['sha256'] or path.stat().st_size!=fixed[key]['bytes']:
        raise SystemExit('Fixed '+key+' differs before registration')

def logged(argv,label,env):
    result=subprocess.run(argv,cwd=ROOT,env=env,capture_output=True,timeout=60)
    (B/(label+'.stdout.bin')).write_bytes(result.stdout)
    (B/(label+'.stderr.bin')).write_bytes(result.stderr)
    report['steps'].append({'argv':argv,'exit_code':result.returncode,
        'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),
        'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})
    if result.returncode:
        raise RuntimeError(label+' failed: '+result.stderr.decode(errors='replace'))
    return result

try:
    report['local_opt_in']=helper.opted_in(ROOT)
    if not report['local_opt_in']:
        raise RuntimeError('Main checkout actual local opt-in is not enabled')
    helper.validate_source(ROOT,S,candidate)
    inputs=json.loads((M/'BUILD-INPUTS.actual.json').read_bytes())
    original_argv=inputs['argv']
    defines=[original_argv[i+1] for i,part in enumerate(original_argv) if part=='--cmake-define']
    if len(defines)!=15 or defines[:13]!=inputs['definitions']:
        raise RuntimeError('Source02 original definitions differ')
    report['cmake_definitions']=defines
    environment=child_environment(B)
    environment,tools=initialize_msvc(visual_studio_installation(None,environment),B,environment)
    helper.request_codemodel(D)
    args=SimpleNamespace(source_dir=S,build_dir=D,configuration='Release',cmake_define=defines)
    logged(configure_command(args,tools),'codemodel-configure',environment)
    dry=logged([tools['ninja'],'-C',str(D),'-n','xar_ck3_bridge_injector'],'injector-dry-run',environment)
    report['binary_after_configure']=[pin(p) for p in binaries]
    if report['binary_after_configure']!=report['binary_before']:
        raise RuntimeError('A fixed native binary changed during configure; registration not attempted')
    if b'ninja: no work to do.' not in dry.stdout:
        raise RuntimeError('Injector dry-run would rebuild; registration not attempted')
    manifest=helper.collect_manifest(ROOT,S,D,'Release',['xar_ck3_bridge_injector'],candidate)
    if len(manifest['files'])!=1 or Path(manifest['files'][0]['path']).resolve()!=binaries[1].resolve():
        raise RuntimeError('Registration target is not the one declared injector EXE')
    manifest_path=B/'registration-manifest.json'
    manifest_path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
    provenance=B/'cmake-provenance'
    provenance.mkdir()
    for value in [manifest['cmake_index'],manifest['cmake_codemodel'],*manifest['target_provenance']]:
        path=Path(value['path'])
        (provenance/path.name).write_bytes(path.read_bytes())
    receipt=helper.register_manifest(manifest,B/'registration-receipt.json',manifest_bytes=manifest_path.read_bytes())
    report['registration_status']=receipt['status']
    report['registration_receipt']=pin(B/'registration-receipt.json')
    report['registration_manifest']=pin(manifest_path)
    report['status']='verified' if receipt['status']=='verified' else 'registration_incomplete'
    report['registration_error']=receipt.get('error')
except Exception as error:
    report.update(status='stopped',error=str(error),error_type=type(error).__name__)
finally:
    report['binary_after']=[pin(p) for p in binaries]
    report['fixed_binary_bytes_unchanged']=report['binary_after']==report['binary_before']
    report['original_logs_unchanged']=all(sha(Path(v['path']))==v['sha256'] for label,v in preserved.items()
                                        if label in ['msvc-configure.log','msvc-build.log','native-msvc-result.json'])
    report['finished_utc']=datetime.now(timezone.utc).isoformat()
    (B/'RESULT.actual.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(report,indent=2))
