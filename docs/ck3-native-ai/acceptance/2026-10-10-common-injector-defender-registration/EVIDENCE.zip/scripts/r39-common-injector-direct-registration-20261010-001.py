from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

repo=Path('C:/workspace/ck3_eternal_recurrence')
out=Path('C:/workspace/ck3_lyd_runtime_20261004/r39-common-injector-defender-20261010-001')
sys.path.insert(0,str(repo/'tools'))
import register_project_exe_exclusions as helper

manifest_path=out/'registration-manifest.readonly.json'
raw=manifest_path.read_bytes()
manifest=json.loads(raw)
fresh=helper.collect_manifest(repo,Path('C:/csr2/ck3_autonomous_player/native_bridge'),Path('C:/cbr2'),'Release',['xar_ck3_bridge_injector'],'common-runtime-20261010-source-af2045521')
assert fresh==manifest
assert len(manifest['files'])==1
assert manifest['files'][0]['sha256']=='2e22a985ba3166ce50ca1732901f0bac0629e8ff0f068de73330fdd5d09c86a8'
assert helper.opted_in(repo) is True
binary_paths=[Path('C:/cbr2/xar_ck3_bridge.dll'),Path('C:/cbr2/xar_ck3_bridge_injector.exe')]
before=[hashlib.sha256(path.read_bytes()).hexdigest() for path in binary_paths]
report={'schema':'ck3-common-injector-existing-artifact-registration-v1','started_utc':datetime.now(timezone.utc).isoformat(),
        'prior_stopped_attempt_preserved':True,'prior_stopped_reason_correction':'The Ninja dry-run only showed glob verification/CMake regeneration. It did not establish whether a binary compile would be needed. No further build or configure was invoked for this registration.',
        'build_invoked':False,'configure_invoked':False,'exe_executed':False,'ck3_contacted':False,'steam_contacted':False,
        'manifest_sha256':hashlib.sha256(raw).hexdigest(),'status':'running'}
receipt_path=out/'registration-receipt.actual.json'
try:
    receipt=helper.register_manifest(manifest,receipt_path,manifest_bytes=raw)
    report['status']=receipt['status']
    report['registration_receipt_sha256']=hashlib.sha256(receipt_path.read_bytes()).hexdigest()
    report['registration_error']=receipt.get('error')
    report['registration_error_stage']=receipt.get('error_stage')
    report['admin_token']=receipt.get('admin_token')
    report['verification_source']=receipt.get('verification_source')
    report['requested_files']=receipt['files']
    report['verified_requested_paths']=receipt.get('verified_requested_paths')
    report['missing_requested_paths']=receipt.get('missing_requested_paths')
except Exception as error:
    report.update(status='registration_exception',error=str(error),error_type=type(error).__name__)
finally:
    report['fixed_binary_bytes_unchanged']=before==[hashlib.sha256(path.read_bytes()).hexdigest() for path in binary_paths]
    report['binary_sha256']=dict(zip([str(path) for path in binary_paths],before))
    report['finished_utc']=datetime.now(timezone.utc).isoformat()
    (out/'REGISTRATION-RESULT.actual.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(report,indent=2))
