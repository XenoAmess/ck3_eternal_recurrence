# R18 decision admission / Select claim repair

Detached source tree: `C:/lci18reject1`, exact base HEAD
`dbaf5f8db2067419838b814e278d962f428dc33c`.
`INTEGRATION-MANIFEST.json` freezes all five source files, three original
preimages, two new files, patch and actual check receipts.

The original admission predicates and their short-circuit order remain.
The rejection ERROR now carries
`decision_action_pre_dispatch_rejection_v1`: fixed schema and branch identity,
actual request ID/step/key, `dispatch_stage=before_main_thread_submit`,
`submitted=false`, `dispatch_invoked=false`, the first evaluated failed
predicate, expected/actual native revision/PID/generation/actor,
snapshot-read/equality observations, both held snapshot serializations and
all differing top-level Snapshot members. It neither reads the game again nor
publishes a new snapshot. A condition not evaluated is not reported as failed.

The real primitive retains exact copies of its sent parsed request and received
parsed ERROR. Select saves these in create-only `.claim.error.json`; the
existing `.claim.json` is unchanged. Only the fixed typed pre-submit branch
produces create-only `.claim.rejected-before-dispatch.json`, hash bound to the
claim and the ERROR file. It does not produce `.verified.json`, does not mark
an action successful and does not retry automatically.

Before a later explicit Select, the resolver rechecks these raw frames and
hashes and requires strictly higher public **and** native revisions, with the
same PID/actor/date/generation/episode. The fresh decision model/frame guards
still run. The same revision, Confirm, timeout, missing or foreign ERROR,
after-submit failure, reconnect and damaged evidence remain locked.

The real R18 SDK80 ERROR bytes were never retained by the old producer. This
package does not reconstruct them, create a retrospective rejection sidecar,
or make the currently running server read new code. R18 retains its original
unknown claim; ROOT must close that run, integrate the patch, commit/export and
perform a new qualified native build before a fresh cold run.

Actual validation: `focused-attempt-002/RESULT.json` records 35 focused Python
tests passing (production Select + primitive + production encoder with only
the low-level transport replaced by memory). It includes recovery constraints,
unknown/after-submit/malformed/tamper cases and existing Select/Confirm/outcome
regressions. No CK3/SDK callbacks were invoked. Attempt001's Windows long-path
failure and raw stdio remain preserved. `git diff --check`, a forward
`git apply --check` against the five exact preimages, and a reverse check against
the detached source all exited 0. C++ compilation and runtime validation have
not been performed by this package.

After genuine R18 closure, ROOT can review and apply:

```text
git -C C:/workspace/ck3_eternal_recurrence apply --check C:/workspace/ck3_lyd_runtime_20261004/r18-decision-predispatch-fix-20261007-001/PATCH.diff
git -C C:/workspace/ck3_eternal_recurrence apply C:/workspace/ck3_lyd_runtime_20261004/r18-decision-predispatch-fix-20261007-001/PATCH.diff
```

These are ROOT mutation instructions for the later closed boundary, not actions
executed here. No compile, business, formal or product GREEN is granted.
