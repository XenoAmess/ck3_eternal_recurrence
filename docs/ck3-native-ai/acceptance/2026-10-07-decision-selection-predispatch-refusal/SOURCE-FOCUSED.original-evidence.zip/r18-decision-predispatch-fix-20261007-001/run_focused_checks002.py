from pathlib import Path
import contextlib
import hashlib
import json
import os
import subprocess
import sys
import unittest

ROOT=Path('C:/lci18reject1')
OUT=Path(__file__).resolve().parent/'focused-attempt-002'
OUT.mkdir(exist_ok=False)
sys.dont_write_bytecode=True
sys.path[:0]=[str(ROOT/'ck3_autonomous_player/src'),str(ROOT/'ck3_autonomous_player/tests/unit'),str(ROOT/'tools')]
short=Path('C:/r18rejt1');short.mkdir(exist_ok=False)
os.environ['XAR_WHITE_DECISION_ACTION_TEST_ARTIFACTS']=str(short/'select')
os.environ['XAR_DECISION_OUTCOME_TEST_ARTIFACTS']=str(short/'outcome')
names=['test_ingame_decision_predispatch_rejection','test_ingame_decision_item_actions','test_ingame_decision_outcomes.OutcomeTests']
with (OUT/'stdout.txt').open('x',encoding='utf-8',newline='\n') as out, (OUT/'stderr.txt').open('x',encoding='utf-8',newline='\n') as err:
 with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
  suite=unittest.defaultTestLoader.loadTestsFromNames(names)
  result=unittest.TextTestRunner(stream=err,verbosity=2).run(suite)
report={'schema':'lyd.r18.decision-predispatch-focused-checks.v1','worktree':str(ROOT),
        'base_head':'dbaf5f8db2067419838b814e278d962f428dc33c','test_names':names,
        'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passed':result.wasSuccessful(),
        'native_compilation_performed':False,'sdk_calls':0,'game_callbacks':0,'main_writes':0}
for name in ['stdout.txt','stderr.txt']:
 p=OUT/name;b=p.read_bytes();report[name]={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(OUT/'RESULT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report))
sys.exit(0 if result.wasSuccessful() else 1)
