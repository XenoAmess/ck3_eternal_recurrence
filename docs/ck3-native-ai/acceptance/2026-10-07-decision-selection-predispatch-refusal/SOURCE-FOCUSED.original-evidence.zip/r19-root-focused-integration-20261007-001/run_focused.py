from pathlib import Path
import argparse, contextlib, hashlib, json, os, subprocess, sys, unittest
from datetime import datetime, timezone

p = argparse.ArgumentParser()
p.add_argument('--repo', required=True, type=Path)
p.add_argument('--output', required=True, type=Path)
a = p.parse_args()
repo = a.repo.resolve(strict=True)
out = a.output.resolve()
if out.exists():
    raise ValueError('Fresh output required')
out.mkdir(parents=True)
os.environ['XAR_WHITE_DECISION_ACTION_TEST_ARTIFACTS'] = 'C:/lt19py1'
sys.path[:0] = [str(repo/'ck3_autonomous_player/src'), str(repo/'ck3_autonomous_player/tests/unit')]
names = ['test_ingame_decision_predispatch_rejection', 'test_ingame_decision_item_actions',
         'test_ingame_decision_outcomes.OutcomeTests', 'test_native_bridge_dispatch_topology']
suite = unittest.defaultTestLoader.loadTestsFromNames(names)
with (out/'stdout.txt').open('x', encoding='utf-8') as stdout, (out/'stderr.txt').open('x', encoding='utf-8') as stderr:
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        result = unittest.TextTestRunner(stream=stderr, verbosity=2).run(suite)
def ref(path):
    raw = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
paths = ['ck3_autonomous_player/native_bridge/src/bridge.cpp',
         'ck3_autonomous_player/src/xar_autoplayer/bridge/native_driver.py',
         'ck3_autonomous_player/src/xar_autoplayer/bridge/ingame_decision_outcome_contract.py',
         'ck3_autonomous_player/src/xar_autoplayer/bridge/ingame_decision_predispatch_contract.py',
         'ck3_autonomous_player/tests/unit/test_ingame_decision_predispatch_rejection.py']
facts = {'schema':'lyd.root.merged-decision-refusal-focused.v1', 'argv':sys.argv,
         'interpreter':sys.executable, 'repo':repo.as_posix(),
         'base_head':subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip(),
         'source_files':[ref(repo/path) for path in paths], 'test_names':names,
         'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
         'passed':result.wasSuccessful(), 'stdout':ref(out/'stdout.txt'),'stderr':ref(out/'stderr.txt'),
         'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
         'SDK_calls':0,'game_calls':0,'native_compile':False,'save_body_reads':0}
with (out/'RESULT.actual.json').open('x',encoding='utf-8',newline='\n') as stream:
    json.dump(facts,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(json.dumps({'result':ref(out/'RESULT.actual.json'),'tests_run':result.testsRun,'passed':result.wasSuccessful()}))
raise SystemExit(0 if result.wasSuccessful() else 1)
