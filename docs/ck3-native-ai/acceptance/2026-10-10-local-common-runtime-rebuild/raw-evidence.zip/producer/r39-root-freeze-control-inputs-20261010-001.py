from pathlib import Path
import json,hashlib
B=Path('C:/workspace/ck3_lyd_runtime_20261004')
O=Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-001')
O.mkdir(parents=True,exist_ok=False)
def pin(p):
 raw=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def put(p,v):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
report=B/'r31-root-clean-export-20261008-001/REPORT.json'
assert pin(report)['sha256']=='ba6a5fd88967c41909043f68d377e2e22d8c03fa21b3332e383d9a992ccdfc14'
r=json.loads(report.read_bytes());P=B/'live-attempt-038/content/production'
rows=r['build']['files'];assert len(rows)==71
actual={p.relative_to(P).as_posix():pin(p) for p in P.rglob('*') if p.is_file()}
assert set(actual)=={row['path'] for row in rows}
for row in rows:
 assert all(actual[row['path']][key]==row[key] for key in ('bytes','sha256')),row['path']
product_manifest=O/'product-inventory.json'
put(product_manifest,{'source_head':r['source']['head'],'files':rows,
 'provenance':{'original_formal_export':pin(report),'original_formal_manifest':r['build']['manifest'],
               'actual_profile_copy':pin(B/'live-attempt-038/COLD-MATERIALIZED.json')},
 'business_acceptance':'NOT_ASSESSED'})
configs={rel:pin(B/'live-attempt-038/userdir'/rel) for rel in ('pdx_settings.txt','tutorial.txt')}
for rel in ('presets.txt','player/game_rules/presets.txt'):
 p=O/'plain-configuration'/rel;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b'')
 configs[rel]=pin(p)
seed=B/'live-attempt-034/checkpoints/D2a/checkpoint.ck3'
assert pin(seed)['sha256']=='a6db85e38ba0648eca4b7e835c79d867b96ca26099698f4d4ee5269b818d822c'
put(O/'plain-configuration-provenance.json',{
 'schema':'ck3-mod-acceptance-plain-configuration-provenance-v1',
 'copied_from_original_R38':['pdx_settings.txt','tutorial.txt'],
 'new_explicit_empty_development_inputs':['presets.txt','player/game_rules/presets.txt'],
 'reason':'Original R38 profile lacks both custom preset files; current Windows Documents CK3 profile is absent. New zero-byte inputs explicitly declare no custom presets; they are not claimed as copies of historical settings. Saved campaign bytes and stored game rules are unchanged.',
 'files':configs,'save':pin(seed)})
put(O/'prepare-inputs.json',{'state_dir':str(O/'state'),
 'case_inputs':{'product_dir':str(P),'product_inventory':pin(product_manifest),
                'overlay_dir':str(B/'r39-transaction-control-overlay-sourceonly-20261009-002'),
                'plain_configuration':configs},
 'saved_campaign':{'save':str(seed),'bytes':pin(seed)['bytes'],'sha256':pin(seed)['sha256'],
                    'player_id':31254,'date_raw':53144712}})
print(json.dumps({'input':pin(O/'prepare-inputs.json'),'formal_files':len(rows),'new_empty_presets':2}))
