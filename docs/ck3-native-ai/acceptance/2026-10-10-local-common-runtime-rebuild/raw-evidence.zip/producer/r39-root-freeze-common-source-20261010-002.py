from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
R=Path('C:/workspace/ck3_eternal_recurrence');O=Path('C:/workspace/ck3-common-runtime/20261010-002');S=Path('C:/csr2');D=Path('C:/cbr2')
def put(path,obj):
 with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n')
def pin(path):
 raw=path.read_bytes();return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
assert not subprocess.run(['git','status','--porcelain'],cwd=R,capture_output=True,check=True).stdout,'clean source required'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head=='af20455212ed75000ba6136b3be308a9288cb06e',head
O.mkdir(parents=True,exist_ok=False);S.mkdir(exist_ok=False)
archive=O/'shared-source.zip'
subprocess.run(['git','archive','--format=zip','--output',str(archive),head,'tools','ck3_autonomous_player','ck3_workshop_mcp','promo/ck3_native_war_ai/integration'],cwd=R,check=True)
with zipfile.ZipFile(archive) as z:
 assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
 z.extractall(S)
rows={p.relative_to(S).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(S.rglob('*')) if p.is_file()}
put(O/'source-index.json',{'schema':'ck3-common-source-index-v1','source_commit':head,'files':rows})
native={k:v for k,v in rows.items() if k.startswith('ck3_autonomous_player/native_bridge/')}
put(O/'native-source-index.json',{'schema':'ck3-common-native-source-index-v1','source_commit':head,'files':native})
cache=Path('C:/lr31b1/CMakeCache.txt').read_text(encoding='utf-8')
defines=[line.split(':',1)[0]+'=ON' for line in cache.splitlines() if line.startswith('XAR_CK3_ENABLE_') and line.endswith(':BOOL=ON')]
# The common host declares frontend rules for every source fixture. Add its
# already implemented native feature to the known local readonly/UI baseline.
defines=sorted(set(defines+['XAR_CK3_ENABLE_FRONTEND_GAME_RULES_PRIVATE_V1=ON']))
argv=[sys.executable,'-B','-X','utf8',str(S/'tools/run_native_msvc.py'),'--source-dir',str(S/'ck3_autonomous_player/native_bridge'),'--build-dir',str(D),'--configure','--build','--jobs','32','--defender-external-candidate','common-runtime-20261010-source-af2045521']
for value in defines+['BUILD_TESTING=ON','XAR_CK3_EXECUTABLE_PATH=C:/Program Files (x86)/Steam/steamapps/common/Crusader Kings III/binaries/ck3.exe']:argv+=['--cmake-define',value]
put(O/'BUILD-INPUTS.actual.json',{'schema':'ck3-common-runtime-build-inputs-v1','source_commit':head,'source_root':str(S),'source_archive':pin(archive),'source_index':pin(O/'source-index.json'),'native_source_index':pin(O/'native-source-index.json'),'definition_provenance':'Existing actual local baseline options; current shared source; frontend rules included for all fixture cases. No product-specific host/source/native override.','definitions':defines,'argv':argv,'business_acceptance':'NOT_ASSESSED','live_qualification':'NOT_RUN'})
with (O/'build.stdout.log').open('xb') as stdout,(O/'build.stderr.log').open('xb') as stderr:
 result=subprocess.run(argv,cwd=R,stdout=stdout,stderr=stderr)
put(O/'BUILD-RESULT.actual.json',{'exit_code':result.returncode,'source_commit':head,'dll':pin(D/'xar_ck3_bridge.dll') if (D/'xar_ck3_bridge.dll').is_file() else None,'injector':pin(D/'xar_ck3_bridge_injector.exe') if (D/'xar_ck3_bridge_injector.exe').is_file() else None,'live_qualification':'NOT_RUN','business_acceptance':'NOT_ASSESSED'})
print('common build',result.returncode,flush=True)
raise SystemExit(result.returncode)
