from pathlib import Path
import json,hashlib,subprocess,zipfile
R=Path('C:/workspace/ck3_eternal_recurrence');O=Path('C:/workspace/ck3-common-runtime/20261010-002')
S=Path('C:/csr3');previous=Path('C:/csr2');head='13d063c81ff706d8bc3f9a8bf81f60c283338042'
assert not S.exists();S.mkdir()
def pin(p):
 raw=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def put(p,v):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
archive=O/'shared-source03.zip'
subprocess.run(['git','archive','--format=zip','--output',str(archive),head,'tools','ck3_autonomous_player','ck3_workshop_mcp','promo/ck3_native_war_ai/integration'],cwd=R,check=True)
with zipfile.ZipFile(archive) as z:
 assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
 z.extractall(S)
def inventory(root):
 return {p.relative_to(root).as_posix():{k:v for k,v in pin(p).items() if k!='path'} for p in sorted(root.rglob('*')) if p.is_file()}
a=inventory(previous);b=inventory(S)
changed=[key for key in sorted(set(a)|set(b)) if a.get(key)!=b.get(key)]
native_changed=[key for key in changed if key.startswith('ck3_autonomous_player/native_bridge/')]
assert native_changed==['ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py'],native_changed
assert all(a[key]==b[key] for key in a if key.startswith('ck3_autonomous_player/native_bridge/') and key not in native_changed)
put(O/'source03-index.json',{'schema':'ck3-common-source-index-v1','source_commit':head,'files':b})
put(O/'native-source03-index.json',{'schema':'ck3-common-native-source-index-v1','source_commit':head,'files':{k:v for k,v in b.items() if k.startswith('ck3_autonomous_player/native_bridge/')}})
put(O/'SOURCE03-NATIVE-REUSE.actual.json',{'schema':'ck3-common-runtime-python-successor-v1',
 'source02_commit':'af20455212ed75000ba6136b3be308a9288cb06e','source03_commit':head,
 'source02_root':str(previous),'source03_root':str(S),'source03_archive':pin(archive),
 'source02_index':pin(O/'source-index.json'),'source03_index':pin(O/'source03-index.json'),
 'all_changed_paths':changed,'changed_native_directory_paths':native_changed,
 'every_other_native_directory_file_byte_equal':True,
 'native_compiled_inputs_unchanged':True,'artifact_build_result':pin(O/'BUILD-RESULT.actual.json'),
 'source03_host':pin(S/native_changed[0]),'live_qualification':'NOT_RUN','product_qualification':'NOT_ASSESSED',
 'scope':'One machine-global common runtime for every product, not a product-selected source. Its explicitly frozen shared source does not automatically change when master advances.'})
print(json.dumps({'source03':head,'changed_paths':len(changed),'native_changes':native_changed,'host':pin(S/native_changed[0])}))
