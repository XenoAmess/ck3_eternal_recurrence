from pathlib import Path
import json,hashlib,ast
R=Path('C:/workspace/ck3_eternal_recurrence');O=Path('C:/workspace/ck3-common-runtime/20261010-002');S=Path('C:/csr3')
def pin(p):
 raw=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def put(p,v):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
build=json.loads((O/'BUILD-RESULT.actual.json').read_bytes());assert build['exit_code']==0
delta=json.loads((O/'SOURCE03-NATIVE-REUSE.actual.json').read_bytes());assert delta['native_compiled_inputs_unchanged'] is True
paths={'source_root':S,'host':S/'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py',
 'source_index':O/'source03-index.json','native_source_index':O/'native-source03-index.json',
 'dll':Path(build['dll']['path']),'injector':Path(build['injector']['path'])}
for key in ('dll','injector'):assert pin(paths[key])==build[key]
def row(key):return {'path_key':key,**{k:v for k,v in pin(paths[key]).items() if k!='path'}}
mcp=S/'ck3_autonomous_player/src/xar_autoplayer/bridge/mcp_server.py'
names={node.name for node in ast.walk(ast.parse(mcp.read_text(encoding='utf-8'))) if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))}
tools=['ck3_take_snapshot','ck3_advance_days','ck3_query_actor_cached_succession_v1','ck3_query_confucian_religious_title_v1',
 'ck3_query_current_event_window_context_v1','ck3_select_event_option','ck3_save_checkpoint',
 'ck3_query_normal_exit_context_v1','ck3_request_normal_exit_v1','ck3_observe_normal_exit_v1']
assert set(tools)<=names,set(tools)-names
manifest={'schema':'ck3-mod-acceptance-shared-runtime-v1',
 'runtime_id':'machine-common-12004-source13d063c81-nativeaf2045521-20261010-002',
 'source_root':{'path_key':'source_root'},'host':row('host'),'source_index':row('source_index'),
 'native_source_index':row('native_source_index'),'native':{'dll':row('dll'),'injector':row('injector')},
 'game':{'version':'1.20.0.4','exe_sha256':'98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518'},
 'host_features':{'succession_title_readonly':True},
 'entry_environment':{'PYTHONPATH_parts':[{'root_key':'source_root','relative_path':p} for p in ('ck3_autonomous_player/src','ck3_workshop_mcp/src','tools')]},
 'capabilities':{name:{'source_build_ready':True,'actual_live_qualified':False,
   'evidence':'Actual common DLL/injector build0; exact registered shared MCP source; no actual live qualification inferred'} for name in tools},
 'provenance':{'source_commit':delta['source03_commit'],'native_build_commit':build['source_commit'],
 'build_inputs':pin(O/'BUILD-INPUTS.actual.json'),'build_result':pin(O/'BUILD-RESULT.actual.json'),
 'python_successor_native_equality':pin(O/'SOURCE03-NATIVE-REUSE.actual.json'),'mcp_source':pin(mcp)},
 'selection_policy':'One globally selected common runtime for all products. No product-selected host/source/native copy.',
 'qualification':'BUILD_ONLY_NOT_LIVE_NOT_PRODUCT_PASS'}
put(O/'manifest.json',manifest)
for p in ('C:/workspace/ck3-common-runtime/userdir-root','C:/workspace/ck3-common-runtime/runs'):Path(p).mkdir(parents=True,exist_ok=True)
bus=Path('C:/workspace/.codex-task-bus/bin/codex_task_bus.py')
assert pin(bus)['sha256']=='b3c44b42f7bdf401b593d863e3210106a46412dcd7d89f8596c74f4c27392dee'
runtime={'schema':'ck3-mod-acceptance-runtime-v1','manifest':pin(O/'manifest.json'),
 'python':'C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe','repo_root':str(R),
 'game_dir':'C:/Program Files (x86)/Steam/steamapps/common/Crusader Kings III',
 'userdir_root':'C:/workspace/ck3-common-runtime/userdir-root','artifacts_root':'C:/workspace/ck3-common-runtime/runs',
 'paths':{key:str(p) for key,p in paths.items()},
 'reviewed_launcher':pin(S/'tools/ck3_mod_acceptance_launcher.py'),
 'control_queue':pin(S/'tools/ck3_mod_acceptance_queue.py'),
 'allocation':{'lease_repo':str(R),'screen_keeper':pin(S/'tools/ck3_mod_acceptance_keeper.py'),
 'task_bus':pin(bus),'task_prefix':'common-acceptance-12004-20261010-'},
 'qualification':'BOUND_NOT_ALLOCATED_NOT_RUN'}
put(O/'runtime.local.json',runtime)
print(json.dumps({'manifest':pin(O/'manifest.json'),'runtime':pin(O/'runtime.local.json'),'common_source':delta['source03_commit'],'actual_live_qualified':False}))
