from pathlib import Path
import sys,json,hashlib
R=Path('C:/workspace/ck3_eternal_recurrence');O=Path('C:/workspace/ck3-common-runtime/20261010-002')
B=Path('C:/workspace/ck3_lyd_runtime_20261004');L=B/'live-attempt-038'
sys.path.insert(0,str(R/'tools'))
import ck3_live_run_id as ids
from ck3_mod_acceptance_allocate import actual_machine_binding
def pin(p):
 raw=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
bundle={'schema':'ck3-mod-acceptance-first-machine-bootstrap-v1','machine':actual_machine_binding(ids),
 'runtime_config':pin(O/'runtime.local.json'),'runtime_manifest':pin(O/'manifest.json'),'repo_root':str(R),
 'legacy_archive_index':pin(R/'docs/li-yu-dao/acceptance/2026-10-09-r0038-transaction-control-guard-red/INDEX.json'),
 'legacy_profile_mcp_closure':{key:pin(path) for key,path in {
 'identity':L/'live-run-id.json','launch':L/'launch.json','profile':L/'native-profile-with-exit-inventory.json',
 'typed_normal_exit':L/'diagnostic-mcp-client-001/0017-r38-exit-observe-002.sdk-result.json',
 'original_handle_exit':L/'game-original-handle-final.json',
 'keeper_final':B/'r38-root-screen-keeper-20261009-001/FINAL.json',
 'client_final':L/'diagnostic-mcp-client-001/final.json','closeout_task':L/'R38-CLOSEOUT-TASK.actual.json'}.items()}}
p=O/'first-machine-bootstrap.json'
with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(bundle,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'bundle':pin(p),'ledger_created':False,'live_id_allocated':False}))
