from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT=Path('C:/workspace/ck3_eternal_recurrence')
B=Path('C:/workspace/ck3_lyd_runtime_20261004/r39-saved-startup-focused-check-20261010-001')
B.mkdir(exist_ok=False)
host=ROOT/'ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py'
test=ROOT/'ck3_autonomous_player/tests/unit/test_saved_campaign_startup_admission.py'
report={'schema':'ck3-saved-startup-focused-portable-check-v1',
        'started_utc':datetime.now(timezone.utc).isoformat(),
        'source_inputs':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [host,test]},
        'ck3_started':False,'steam_contacted':False,'native_qualification_claimed':False,
        'test_layer':'real host and bridge service methods, synthetic transport/native frames', 'steps':[]}
for label,argv in [
    ('portable-tests',[sys.executable,'-X','utf8','-m','unittest','ck3_autonomous_player.tests.unit.test_saved_campaign_startup_admission']),
    ('host-help',[sys.executable,'-X','utf8',str(host),'--help'])]:
    result=subprocess.run(argv,cwd=ROOT,capture_output=True,timeout=60)
    (B/(label+'.stdout.bin')).write_bytes(result.stdout)
    (B/(label+'.stderr.bin')).write_bytes(result.stderr)
    report['steps'].append({'argv':argv,'exit_code':result.returncode,
        'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})
    if result.returncode:
        print(result.stdout.decode('utf-8',errors='replace'))
        print(result.stderr.decode('utf-8',errors='replace'))
        break
report['finished_utc']=datetime.now(timezone.utc).isoformat()
report['status']='passed' if len(report['steps'])==2 and all(s['exit_code']==0 for s in report['steps']) else 'failed'
(B/'RESULT.actual.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
if report['status']!='passed':
    raise SystemExit(1)
O=ROOT/'docs/ck3-native-ai/acceptance/2026-10-10-saved-startup-event-admission'
O.mkdir(parents=True,exist_ok=False)
files={p.name:p for p in B.iterdir() if p.is_file()}
files['focused-check.py']=Path(__file__)
index={'schema':'ck3-saved-startup-portable-evidence-v1','status':'passed_portable_only',
       'files':{name:{'source':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in sorted(files.items())}}
index_path=O/'INDEX.actual.json'
index_path.write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8',newline='\n')
archive=O/'raw-evidence.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in sorted(files.items()):
        z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
    for name,p in files.items():
        if z.read(name)!=p.read_bytes():
            raise SystemExit('Archive bytes mismatch: '+name)
validation={'status':'passed','entries':len(files),'index_sha256':hashlib.sha256(index_path.read_bytes()).hexdigest(),
            'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(O/'ARCHIVE-VALIDATION.actual.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report,indent=2))
print(json.dumps(validation,indent=2))
