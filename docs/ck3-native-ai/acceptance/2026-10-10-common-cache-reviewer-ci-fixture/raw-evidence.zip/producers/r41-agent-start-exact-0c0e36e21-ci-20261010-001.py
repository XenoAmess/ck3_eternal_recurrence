from pathlib import Path
import subprocess
import sys

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
SHA='0c0e36e21164d55cd9f47d2d8ab9ae7a5cbf3f63'
OUTPUT='r41-exact-0c0e36e21-ci-20261010-001'
OLD_SHA='6a3affdb87f03f01bdc9f4dc43aeff15960200db'
OLD_OUTPUT='r41-exact-6a3affdb8-ci-20261010-001'
templates=[('r41-agent-watch-exact-6a3affdb8-ci-20261010-001.py','r41-agent-watch-exact-0c0e36e21-ci-20261010-001.py'),
           ('r41-agent-complete-exact-6a3affdb8-ci-20261010-001.py','r41-agent-complete-exact-0c0e36e21-ci-20261010-001.py')]
preflight="""commit_code, commit_raw, _ = api('commits/' + SHA, 'remote-exact-commit')
if commit_code != 0:
    raise RuntimeError('Exact remote commit API did not succeed; original response retained')
commit = json.loads(commit_raw)
if commit.get('sha') != SHA:
    raise RuntimeError('Remote exact commit resolved a different SHA')
branch_code, branch_raw, _ = api('branches/master', 'remote-master-branch')
branch = json.loads(branch_raw) if branch_code == 0 else {}
save_json('REMOTE-PIN.actual.json', {
    'schema': 'ck3.exact-remote-master-pin.v1', 'requested_head': SHA,
    'exact_commit_api_sha': commit['sha'],
    'observed_master_sha': branch.get('commit', {}).get('sha'),
    'master_matches_requested_head': branch.get('commit', {}).get('sha') == SHA,
    'master_query_exit_code': branch_code,
    'basis': 'Actual read-only GitHub commit and branch API responses; exact-head CI remains bound to requested SHA',
})
print(json.dumps({'remote_pin': True, 'requested_head': SHA,
    'master_sha': branch.get('commit', {}).get('sha'),
    'matches': branch.get('commit', {}).get('sha') == SHA}), flush=True)

"""
for index,(original,target) in enumerate(templates):
    source=(BASE/original).read_text(encoding='utf-8')
    if source.count(OLD_SHA)!=1 or source.count(OLD_OUTPUT)!=1:
        raise RuntimeError('Observer source no longer permits unambiguous retarget')
    source=source.replace(OLD_SHA,SHA).replace(OLD_OUTPUT,OUTPUT)
    if index==0:
        anchor='poll = 0\nlast_state = None\n'
        if source.count(anchor)!=1:raise RuntimeError('Observer preflight anchor differs')
        source=source.replace(anchor,preflight+anchor)
    with (BASE/target).open('x',encoding='utf-8',newline='\n') as stream:stream.write(source)
raise SystemExit(subprocess.run([sys.executable,'-B','-X','utf8',str(BASE/templates[0][1])],cwd=BASE).returncode)
