from pathlib import Path
import hashlib
import json
import shutil
import subprocess

REPO=Path('C:/workspace/ck3_eternal_recurrence')
OUT=Path('C:/workspace/ck3_lyd_runtime_20261004/r41-cache-reviewer-ci-fixture-20261010-001')
CI=Path('C:/workspace/ck3_lyd_runtime_20261004/r41-exact-0c0e36e21-ci-20261010-001')
SHA='3704561725e583d9c9fc10f4c47c1523bb1d9643'
CI_SHA='0c0e36e21164d55cd9f47d2d8ab9ae7a5cbf3f63'
FILES=['tools/test_ck3_mod_acceptance_workshop_cache.py','tools/ck3_mod_acceptance_client.py','tools/ck3_mod_acceptance.py']
head=subprocess.run(['git','rev-parse','HEAD'],cwd=REPO,capture_output=True,check=True).stdout.decode('ascii').strip()
if head!=SHA:raise RuntimeError('unexpected source HEAD')
OUT.mkdir(exist_ok=False)
rows=[]
for relative in FILES:
    source=REPO/relative
    data=source.read_bytes()
    blob=subprocess.run(['git','show',SHA+':'+relative],cwd=REPO,capture_output=True,check=True).stdout
    if data!=blob:raise RuntimeError('current source differs from source HEAD')
    target=OUT/'before-sources'/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    original=subprocess.run(['git','show',CI_SHA+':'+relative],cwd=REPO,capture_output=True,check=True).stdout
    target=OUT/'exact-ci-source'/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(original)
    rows.append({'path':relative,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
        'exact_ci_bytes':len(original),'exact_ci_sha256':hashlib.sha256(original).hexdigest(),
        'same_bytes_as_original_ci':data==original})
actual={'source_head_before_commit':head,'original_ci_head':CI_SHA,'files':rows}
(OUT/'BEFORE.actual.json').write_text(json.dumps(actual,indent=2)+'\n',encoding='utf-8',newline='\n')
log=CI/'failure-38006953109-attempt-1-log-failed.stdout.log'
lines=log.read_text(encoding='utf-8-sig').splitlines()
failure=[line for line in lines if 'ERROR:' in line or 'AttributeError:' in line or 'Ran 9 tests' in line or 'FAILED (errors=1)' in line]
terminal=json.loads((CI/'TERMINAL-EVIDENCE.actual.json').read_text(encoding='utf-8'))
diagnostic={'schema':'ck3.exact-cache-reviewer-ci-diagnostic.v1','head_sha':CI_SHA,
    'official_run_id':38006953109,'official_conclusion':'failure','linear_run_id':38006953137,
    'linear_conclusion':'success','li_yu_dao_static_checks':'NOT_TRIGGERED',
    'failed_step':'Test shared CK3 acceptance without installed CK3',
    'failed_test':'WorkshopCacheTests.test_original_normal_close_remains_mandatory_and_no_business_pass',
    'source_file':'tools/test_ck3_mod_acceptance_workshop_cache.py','source_line':243,
    'exception':"AttributeError: 'Selection' object has no attribute 'context_path'",
    'suite_tests':9,'suite_errors':1,'raw_failure_log':{'path':log.name,'bytes':log.stat().st_size,
        'sha256':hashlib.sha256(log.read_bytes()).hexdigest()},'actual_failure_lines':failure,
    'production_failure_demonstrated':False,'diagnosis':'Old test Selection fixture omits allocated reviewer/context/frozen identity required by actual verifier.',
    'terminal_evidence_file':'TERMINAL-EVIDENCE.actual.json'}
with (CI/'DIAGNOSTIC.actual.json').open('x',encoding='utf-8',newline='\n') as stream:
    json.dump(diagnostic,stream,indent=2);stream.write('\n')
print(json.dumps({'output':str(OUT),'source_head':head,'files':rows}))
