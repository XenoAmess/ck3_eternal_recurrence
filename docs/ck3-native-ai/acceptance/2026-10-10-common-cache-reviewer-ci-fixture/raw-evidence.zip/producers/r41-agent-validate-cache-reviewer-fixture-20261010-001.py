from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

REPO=Path('C:/workspace/ck3_eternal_recurrence')
OUT=Path('C:/workspace/ck3_lyd_runtime_20261004/r41-cache-reviewer-ci-fixture-20261010-001')
BEFORE=json.loads((OUT/'BEFORE.actual.json').read_text(encoding='utf-8'))
REL='tools/test_ck3_mod_acceptance_workshop_cache.py'


def pin(path):
    data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


target=OUT/'after-test'
target.mkdir(exist_ok=False)
command=[sys.executable,'-B','-X','utf8',REL]
env=dict(os.environ)
env['PYTHONDONTWRITEBYTECODE']='1'
started=datetime.now(timezone.utc).isoformat()
result=subprocess.run(command,cwd=REPO,env=env,capture_output=True,timeout=120)
finished=datetime.now(timezone.utc).isoformat()
(target/'stdout.log').write_bytes(result.stdout)
(target/'stderr.log').write_bytes(result.stderr)
pins=[]
for row in BEFORE['files']:
    relative=row['path']
    path=REPO/relative
    current=pin(path)
    if relative!=REL and current['sha256']!=row['sha256']:
        raise RuntimeError('production source changed during fixture test')
    destination=OUT/'after-sources'/relative
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(path,destination)
    pins.append(current)
actual={'schema':'ck3-recorded-actual-command-v1','source_head_before_commit':BEFORE['source_head_before_commit'],
    'argv':command,'cwd':str(REPO),'started_at_utc':started,'finished_at_utc':finished,'exit_code':result.returncode,
    'tests':9,'stdout':pin(target/'stdout.log'),'stderr':pin(target/'stderr.log'),'source_pins':pins,
    'production_client_and_entry_unchanged_by_this_work_package':True,
    'actual_reviewer_resolver_and_check_pin_executed':True,'reviewer_origin_assertion_executed':True,
    'no_reviewer_resolver_mock_added':True,'ck3_or_steam_started':False,'screen_or_bus_acquired':False}
(target/'RESULT.actual.json').write_text(json.dumps(actual,indent=2)+'\n',encoding='utf-8',newline='\n')
text=result.stderr.decode('utf-8').replace('\r\n','\n')
if result.returncode or 'Ran 9 tests' not in text or '\nOK\n' not in text:
    raise RuntimeError('cache suite failed; original result retained')
print(json.dumps({'status':'PASS','tests':9,'exit_code':result.returncode,'output':str(target)}))
