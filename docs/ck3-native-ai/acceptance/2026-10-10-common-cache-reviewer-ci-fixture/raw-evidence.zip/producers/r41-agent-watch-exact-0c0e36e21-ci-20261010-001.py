"""Observe one exact remote head; writes evidence outside the shared checkout only."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import time
import zipfile
import io

OUT = Path('C:/workspace/ck3_lyd_runtime_20261004/r41-exact-0c0e36e21-ci-20261010-001')
OUT.mkdir(exist_ok=False)
SHA = '0c0e36e21164d55cd9f47d2d8ab9ae7a5cbf3f63'
REPO = 'XenoAmess/ck3_eternal_recurrence'
NAMES = ('Official Runner CI', 'Linear history', 'Li Yu Dao static checks')
started = datetime.now(timezone.utc).isoformat()


def save_json(name, value):
    with (OUT / name).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def query(argv, label, suffix='json'):
    begin = datetime.now(timezone.utc).isoformat()
    error = None
    try:
        completed = subprocess.run(argv, cwd=OUT, capture_output=True, timeout=45)
        raw, err, code = completed.stdout, completed.stderr, completed.returncode
    except subprocess.TimeoutExpired as exc:
        raw, err, code = exc.stdout or b'', exc.stderr or b'', None
        error = 'subprocess_timeout_45_seconds'
    (OUT / (label + '.stdout.' + suffix)).write_bytes(raw)
    (OUT / (label + '.stderr.log')).write_bytes(err)
    save_json(label + '.actual.json', {
        'argv': argv, 'started_at_utc': begin,
        'finished_at_utc': datetime.now(timezone.utc).isoformat(),
        'exit_code': code, 'error': error,
        'stdout_bytes': len(raw), 'stdout_sha256': hashlib.sha256(raw).hexdigest(),
        'stderr_bytes': len(err), 'stderr_sha256': hashlib.sha256(err).hexdigest(),
    })
    return code, raw, err


def api(endpoint, label, suffix='json'):
    return query(['gh', 'api', 'repos/' + REPO + '/' + endpoint], label, suffix)


save_json('WATCH-INPUT.actual.json', {
    'schema': 'ck3.exact-github-ci-watch.v1', 'head_sha': SHA, 'repository': REPO,
    'started_at_utc': started, 'poll_interval_seconds': 30, 'read_only_remote': True,
    'writes_only_under': str(OUT), 'workflow_dispatch_performed': False,
    'repository_mutation_performed': False,
})
commit_code, commit_raw, _ = api('commits/' + SHA, 'remote-exact-commit')
if commit_code != 0:
    raise RuntimeError('Exact remote commit API did not succeed; original response retained')
commit = json.loads(commit_raw)
if commit.get('sha') != SHA:
    raise RuntimeError('Remote exact commit resolved a different SHA')
branch_code, branch_raw, _ = api('branches/master', 'remote-master-branch')
branch = json.loads(branch_raw) if branch_code == 0 else {}
save_json('REMOTE-PIN.actual.json', {
    'schema': 'ck3.exact-remote-master-pin.v1', 'requested_head': SHA,
    'exact_commit_api_sha': commit['sha'],
    'observed_master_sha': branch.get('commit', {}).get('sha'),
    'master_matches_requested_head': branch.get('commit', {}).get('sha') == SHA,
    'master_query_exit_code': branch_code,
    'basis': 'Actual read-only GitHub commit and branch API responses; exact-head CI remains bound to requested SHA',
})
print(json.dumps({'remote_pin': True, 'requested_head': SHA,
    'master_sha': branch.get('commit', {}).get('sha'),
    'matches': branch.get('commit', {}).get('sha') == SHA}), flush=True)

poll = 0
last_state = None
while True:
    poll += 1
    prefix = 'poll-' + str(poll).zfill(3)
    code, raw, err = api('actions/runs?head_sha=' + SHA + '&per_page=100', prefix + '-runs')
    if code != 0:
        print(json.dumps({'poll': poll, 'status': 'API_RETRY', 'exit_code': code,
                          'stderr_excerpt': err.decode(errors='replace')[:250]}), flush=True)
        time.sleep(15)
        continue
    packet = json.loads(raw)
    runs = packet['workflow_runs']
    if any(row['head_sha'] != SHA for row in runs):
        raise RuntimeError('GitHub returned a run for a different exact HEAD')
    if packet['total_count'] > len(runs):
        raise RuntimeError('Exact-head API is paginated; refuse incomplete NOT_TRIGGERED observation')
    names = list(NAMES) + sorted({row['name'] for row in runs} - set(NAMES))
    observed = {}
    failures = []
    for name in names:
        found = sorted([row for row in runs if row['name'] == name], key=lambda row: row['id'], reverse=True)
        if not found:
            observed[name] = {'status': 'NOT_TRIGGERED', 'not_counted_as_success': True,
                              'basis': 'No matching workflow run in actual exact-head API response'}
            continue
        run = found[0]
        row = {key: run.get(key) for key in ('id', 'status', 'conclusion', 'event', 'html_url',
                                            'head_sha', 'run_attempt', 'created_at', 'updated_at')}
        row['all_run_ids'] = [entry['id'] for entry in found]
        observed[name] = row
        job_code, job_raw, job_err = api('actions/runs/' + str(run['id']) + '/jobs?per_page=100',
                                       prefix + '-jobs-' + str(run['id']))
        if job_code == 0:
            jobs = json.loads(job_raw)
            row['jobs'] = [{'id': job['id'], 'name': job['name'], 'status': job['status'],
                            'conclusion': job['conclusion'],
                            'active_steps': [step['name'] for step in job.get('steps', [])
                                             if step['status'] == 'in_progress'],
                            'failed_steps': [step['name'] for step in job.get('steps', [])
                                             if step.get('conclusion') == 'failure']}
                           for job in jobs['jobs']]
        else:
            row['jobs_query_exit_code'] = job_code
        if run['status'] == 'completed' and run['conclusion'] != 'success':
            failures.append(run)
    summary = {
        'schema': 'ck3.exact-github-ci-observation.v1', 'head_sha': SHA,
        'started_at_utc': started, 'observed_at_utc': datetime.now(timezone.utc).isoformat(),
        'api_total_count': packet['total_count'], 'returned_count': len(runs),
        'workflow_status': observed, 'observation_only': True,
        'workflow_dispatch_performed': False, 'repository_mutation_performed': False,
        'triggered_workflows_terminal': bool(runs) and all(row['status'] == 'completed' for row in runs),
        'triggered_workflows_success': bool(runs) and all(row['status'] == 'completed' and
                                                        row['conclusion'] == 'success' for row in runs),
        'not_triggered_workflows': [name for name, row in observed.items() if row['status'] == 'NOT_TRIGGERED'],
        'all_required_workflows_success': all(observed[name].get('conclusion') == 'success' for name in NAMES),
    }
    save_json(prefix + '-summary.actual.json', summary)
    print(json.dumps({'poll': poll, 'observed_at_utc': summary['observed_at_utc'],
                      'workflows': observed, 'terminal': summary['triggered_workflows_terminal']}), flush=True)
    if summary['triggered_workflows_terminal']:
        for run in failures:
            label = 'failure-' + str(run['id']) + '-attempt-' + str(run['run_attempt'])
            query(['gh', 'run', 'view', str(run['id']), '--repo', REPO, '--attempt',
                   str(run['run_attempt']), '--log-failed'], label + '-log-failed', 'log')
            log_code, archive, _ = api('actions/runs/' + str(run['id']) + '/logs', label + '-api-logs', 'zip')
            if log_code == 0:
                try:
                    with zipfile.ZipFile(io.BytesIO(archive)) as zipped:
                        save_json(label + '-archive-index.actual.json', {
                            'archive_sha256': hashlib.sha256(archive).hexdigest(),
                            'entries': [{'name': item.filename, 'bytes': item.file_size,
                                         'sha256': hashlib.sha256(zipped.read(item)).hexdigest()}
                                        for item in zipped.infolist()],
                            'zip_test_failed_entry': zipped.testzip(),
                        })
                except zipfile.BadZipFile:
                    save_json(label + '-archive-error.actual.json', {'error': 'API response is not a valid ZIP'})
        save_json('FINAL.actual.json', summary)
        print(json.dumps({'final': True, 'head_sha': SHA, 'output': str(OUT),
                          'triggered_workflows_success': summary['triggered_workflows_success'],
                          'not_triggered_workflows': summary['not_triggered_workflows']}), flush=True)
        break
    time.sleep(30)
