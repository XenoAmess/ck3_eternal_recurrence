from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
REPO=Path('C:/workspace/ck3_eternal_recurrence')
CI=BASE/'r41-exact-0c0e36e21-ci-20261010-001'
LOCAL=BASE/'r41-cache-reviewer-ci-fixture-20261010-001'
KEY='2026-10-10-common-cache-reviewer-ci-fixture'
OUT=REPO/'docs/ck3-native-ai/acceptance'/KEY
SHA='0c0e36e21164d55cd9f47d2d8ab9ae7a5cbf3f63'


def digest(data):return hashlib.sha256(data).hexdigest()
def load(path):return json.loads(path.read_text(encoding='utf-8'))
def pin(path):
    data=path.read_bytes()
    return {'bytes':len(data),'sha256':digest(data)}
def write_json(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')


terminal=load(CI/'TERMINAL-EVIDENCE.actual.json')
diagnostic=load(CI/'DIAGNOSTIC.actual.json')
before=load(LOCAL/'BEFORE.actual.json')
after=load(LOCAL/'after-test/RESULT.actual.json')
if terminal['head_sha']!=SHA or diagnostic['head_sha']!=SHA or after['exit_code'] or after['tests']!=9:
    raise RuntimeError('actual head or test result differs')
query_pairs=[]
for path in sorted(CI.glob('*.actual.json')):
    actual=load(path)
    if 'argv' not in actual or 'stdout_sha256' not in actual:continue
    stem=path.name.removesuffix('.actual.json')
    stdout=list(CI.glob(stem+'.stdout.*'))
    stderr=CI/(stem+'.stderr.log')
    if len(stdout)!=1 or not stderr.is_file():raise RuntimeError('query raw pair missing')
    for item,label in ((stdout[0],'stdout'),(stderr,'stderr')):
        data=item.read_bytes()
        if len(data)!=actual[label+'_bytes'] or digest(data)!=actual[label+'_sha256']:
            raise RuntimeError('query actual bytes/hash mismatch')
    if actual['exit_code']!=0:raise RuntimeError('unexpected unsuccessful query')
    query_pairs.append(path.name)
if len(query_pairs)!=33:raise RuntimeError('expected complete 33 raw query groups')
for path in CI.glob('*.zip'):
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:raise RuntimeError('original CI log CRC failure')
for row in before['files']:
    path=REPO/row['path']
    if row['path']!='tools/test_ck3_mod_acceptance_workshop_cache.py' and pin(path)['sha256']!=row['sha256']:
        raise RuntimeError('production source differs from this work package baseline')
inputs=[]
for label,directory in (('exact-ci',CI),('fixture-fix',LOCAL)):
    inputs.extend((label+'/'+path.relative_to(directory).as_posix(),path)
        for path in sorted(directory.rglob('*')) if path.is_file())
for filename in ('r41-agent-start-exact-0c0e36e21-ci-20261010-001.py',
    'r41-agent-watch-exact-0c0e36e21-ci-20261010-001.py','r41-agent-complete-exact-0c0e36e21-ci-20261010-001.py',
    'r41-agent-snapshot-cache-reviewer-fixture-20261010-001.py','r41-agent-validate-cache-reviewer-fixture-20261010-001.py',
    Path(__file__).name):inputs.append(('producers/'+filename,BASE/filename))
OUT.mkdir(exist_ok=False)
entries=[]
archive_path=OUT/'raw-evidence.zip'
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,path in sorted(inputs):
        data=path.read_bytes()
        info=zipfile.ZipInfo(name,date_time=(2026,10,10,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o100644<<16
        archive.writestr(info,data)
        entries.append({'path':name,'source_path':str(path),'bytes':len(data),'sha256':digest(data)})
archive_pin={'path':'raw-evidence.zip',**pin(archive_path)}
with zipfile.ZipFile(archive_path) as archive:
    if archive.testzip() is not None or set(archive.namelist())!={row['path'] for row in entries}:
        raise RuntimeError('archive CRC or inventory differs')
    for row in entries:
        data=archive.read(row['path'])
        if len(data)!=row['bytes'] or digest(data)!=row['sha256'] or data!=Path(row['source_path']).read_bytes():
            raise RuntimeError('archive bytes differ')
write_json(OUT/'INDEX.json',{'schema':'ck3.cache-reviewer-ci-fixture-archive.v1',
    'archived_at_utc':datetime.now(timezone.utc).isoformat(),'source_ci_head':SHA,'archive':archive_pin,'entries':entries})
write_json(OUT/'ARCHIVE-VALIDATION.actual.json',{'schema':'ck3.raw-evidence-archive-validation.v1',
    'status':'PASS','archive':archive_pin,'checked_entries':len(entries),'crc':'PASS',
    'all_source_and_archived_bytes_match':True,'all_source_and_archived_sha256_match':True,
    'verified_actual_query_pairs':len(query_pairs),'query_receipts':query_pairs})
write_json(OUT/'RESULT.actual.json',{'schema':'ck3.cache-reviewer-ci-fixture-fix.v1',
    'original_ci_head':SHA,'original_official_run_id':38006953109,'original_official_conclusion':'failure',
    'original_linear_run_id':38006953137,'original_linear_conclusion':'success','li_yu_dao_static_checks':'NOT_TRIGGERED',
    'failed_step':diagnostic['failed_step'],'failed_test':diagnostic['failed_test'],
    'original_exception':diagnostic['exception'],'original_cache_suite_tests':9,'original_cache_suite_errors':1,
    'source_head_before_fix_commit':before['source_head_before_commit'],'local_after_tests':9,'local_after_exit_code':0,
    'local_after_argv':after['argv'],'source_baseline_pins':before['files'],'fixed_source_pins':after['source_pins'],
    'production_client_and_entry_unchanged_by_this_work_package':True,
    'actual_reviewer_resolver_and_pin_checks_executed':True,'reviewer_origin_asserted':True,
    'original_normal_close_required_and_no_business_product_pass_assertions_preserved':True,
    'new_official_ci_success_claimed':False,'new_actual_runtime_or_product_acceptance_claimed':False,
    'real_game_or_screen_process_started':False,'workflow_dispatch_performed':False,
    'source04_or_source05_runtime_repackaged':False,'old_6a3_evidence_modified':False,
    'open_kaishek_prevalidation':{'status':'not-applicable','reason':'Pure Python synthetic Selection fixture; no CK3 script or gameplay semantics changed.'},
    'raw_evidence':archive_pin})
report=f'''# 缓存验收 reviewer 的 CI 夹具勘误（2026-10-10）

精确提交 `{SHA}` 的
[Official CI 38006953109](https://github.com/XenoAmess/ck3_eternal_recurrence/actions/runs/38006953109)
在共享 acceptance 步骤失败：缓存套件 9 项中仅
`test_original_normal_close_remains_mandatory_and_no_business_pass` 报
`AttributeError: 'Selection' object has no attribute 'context_path'`。
同一提交 [Linear history 38006953137](https://github.com/XenoAmess/ck3_eternal_recurrence/actions/runs/38006953137)
通过；Li Yu Dao static checks **NOT_TRIGGERED**，不计成功。远端 master 的实际 API 已核对为该 SHA。

该测试绕过 `Selection.__init__` 构造旧夹具，未提供 verifier 新调用的真实 reviewer resolver 所需绑定。
本次只补此测试的 `context_path`、`run_dir`、argv/environment、持久化 reviewer/context 与真实 frozen-argv pin。
`Selection.verify()` 继续执行实际 resolver 和 `check_pin`，并断言派生的 reviewer 来自该 context。
原有 normal-close 必需、未闭场/不合格闭场拒绝、合格闭场后仍无 business/product PASS 的断言保留。

在 debug 提交 `3704561725e583d9c9fc10f4c47c1523bb1d9643` 上应用此单项夹具修复后，实际运行一次
`python -B -X utf8 tools/test_ck3_mod_acceptance_workshop_cache.py`：**9/9 通过，exit 0**。
生产 client 与原 CI 字节相同；entry 使用已提交 debug 基线，本工作包未改任何生产代码或添加 resolver fallback。

原 CI API/终态 jobs/双 workflow 完整日志及唯一 traceback、原/新源码 pins 和本地命令回执见
[结果](acceptance/{KEY}/RESULT.actual.json) 与 [索引](acceptance/{KEY}/INDEX.json)。
原始证据 ZIP 共 {len(entries)} 项、{archive_pin['bytes']} bytes，SHA-256 `{archive_pin['sha256']}`；
[读回复验](acceptance/{KEY}/ARCHIVE-VALIDATION.actual.json)确认 byte-exact / CRC PASS，全部 33 组原查询回执校验通过。

本次无 CK3/Steam/屏幕或 run ID 操作，`open_kaishek` 预验 not-applicable。
旧 `6a3` 日志与报告保持原样；本地 9 PASS 不追认 `0c0e` 官方 CI 成功，不授实机 GREEN。
后续以新精确 master 的官方 CI 终态为准。
'''
report_path=REPO/'docs/ck3-native-ai'/(KEY+'.md')
with report_path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(report)
print(json.dumps({'report':str(report_path),'archive':archive_pin,'entries':len(entries),'query_pairs':33,'tests':9}))
