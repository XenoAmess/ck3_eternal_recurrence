# R49：2955DE0 实际处理另一 Land 集合

当前 `.pdata/CHAININFO` 确认 `2955DE0–2955FC3` 为单一483字节逻辑范围，下一行是独立root。调用条件仍是前包 `R10+14 magic=0x4163436C`、有效contextID、解析ID等于原actorID；该类名与实际actor31254是否经过分支保持UNKNOWN。

实际输入保留为原Land→RSI、候选fullID→EBX、flag1→R15D、flag0→R14D、原R10 context→RBP。这个本体读取的是原Land的 `+230` 数据和 `+23C` 数量，元素地址按 `data+count×4` 计算；没有直接 `+3A0/+3A8/+3AC` 访问或对原Land直接写入。相同步长4不能把+230集合认作已资格化的+3A0缓存。可见对象+68置1/复0和栈写另行分类，不授缓存写信用。

不能擅选一个“唯一writer”：这里有两条串联原Land调用。`2955F75→2956EA0` 接收RCX=原Land、EDX=context+10完整ID；返回值不为-1，且在本次flag0条件下context+40必须等于候选ID，才进入 `2955FA2→2956530`。后者参数为RCX=原Land、RDX=context、R8D=前一返回值、R9D=0、第五字节参数0。两者本体都未读取，未给继承算法名称。

本步新增元数据336字节、代码539字节（含56字节必要条件重复），共读EXE875字节；全链累计代码19,424/65,536字节。只保存65/117条选定指令与必要条件窗，未复制全指令表。到此停止，不递归。writer、五政治头衔刷新、lazy getter和因果仍UNKNOWN，不能据此修改生产或降低原保护规则。

新派生摘要48小时、新compact事实7日复核，旧包期限不续。无MAIN、游戏/SDK、构建、存档正文、全.text扫描或EXE复制/全哈希操作。准确读段、来源、条件、参数与限制见 [FACTS.actual.json](FACTS.actual.json)。
