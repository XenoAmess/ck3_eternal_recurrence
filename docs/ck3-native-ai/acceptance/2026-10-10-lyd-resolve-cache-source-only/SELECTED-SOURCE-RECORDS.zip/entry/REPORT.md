# R49：当前 1.20.0.4 resolve 入口

已在本机 .4 文件重新定位 RTTI：`CResolveTitleAndVassalChangeEffect` 的 TypeDescriptor `5A7BCC8`、COL `4ECF198`、vtable `4860A38`，`+B0` 真实指向 `2D1CC00`。`.pdata` 给出范围 `2D1CC00..2D1CD98`。同一局部 .rdata 真实含脚本名 `resolve_title_and_vassal_change` (`4859268`) 与说明；独立注册表行尚未映射。

入口 `2D1CC20` 比较返回对象 `+260` 与 `17`。type17 路径在 `2D1CCB7` 调用 `2AA5AA0`；普通路径后段在 `2D1CD77` 调用 `2AA58E0`。两处 receiver 均为当前 game-state `+A0+D310`，参数 RDX 为解析后保存在 RBX 的对象。新 callees 的事务语义与缓存写入尚未证明；不得照搬旧 .19 的 `+268` 或旧 RVA。

本步实际 EXE 读取合计 **7,347,162 B**（含一次重复 1MiB metadata 窗口），只保存小窗口/指令/refs。执行函数只保存256B前缀与57B尾部，中间95B未读；没有全 .text 扫描、全函数 dump、全文件重hash或 EXE 副本。保留原 full SHA 身份记录，当前另核 size、版本字符串及原213B .4 pin。

所有窗口的 RVA、文件偏移、长度、SHA、实际 Python argv 见 [FACTS.actual.json](FACTS.actual.json)。未执行 native/SDK/游戏、进程读取、构建、测试或 MAIN/Git 写入。Source09/O8 不变，旧4GiB reservation未使用。缓存 writer、七政治头衔刷新链、lazy refresh及业务 PASS 全部仍 UNKNOWN。
