# R49：resolve 两个直接 callee

当前 .4 入口 `2D1CC00` 的 type17 分支直接到 `2AA5AA0`，普通分支到 `2AA58E0`。实际 `.pdata` 将它们拆成多个范围；本包用 **UNW_FLAG_CHAININFO 的父记录**闭合归属，没有凭地址相邻把其它函数拼进来。两个逻辑体分别295B、438B；实际代码读取 **824B**（含入口重复91B），元数据及代码读取合计 **1620B**。

`2AA5AA0` 检查传入 change 的 `+270` magic `54265643`，操作 receiver `+30` 指针数组，并把原 change 指针写入 receiver `+48` 的8字节指针数组（计数`+54`、容量`+50`）。当前 resolve 的 receiver 是 game-state `+A0+D310`。这是 change 指针集合移交；两逻辑体没有直接 actor`+1C0`／LandState`+3A0` 访问。

普通 wrapper `2AA58E0` 另检查 change`+260`、`+258` 和 context`+60`。可选预处理在 `2AA59FF → 2773150`，RCX为原 change，调用前后对同一计数增减；随后 `2AA5A81 → 2AA5AA0`，与 type17 路径进入同一个指针移交函数。因而 **可选预处理与最终指针移交已静态区分**；尚不能称其中某个 helper 是继承刷新或缓存 writer。

`2773150` 是新的精确有限导航点，其函数体本包未读。七政治头衔刷新链、actor缓存写入点、R49实际change type/flag/counter和 getter lazy refresh仍 UNKNOWN。没有递归追踪 callees、全 .text 扫描、构建、实机、SDK、进程、存档、日志或 MAIN/Git 操作；Source09/O8未变，旧4GiB reservation未用。精确字节、RVA、范围、SHA、argv见 [FACTS.actual.json](FACTS.actual.json)。
