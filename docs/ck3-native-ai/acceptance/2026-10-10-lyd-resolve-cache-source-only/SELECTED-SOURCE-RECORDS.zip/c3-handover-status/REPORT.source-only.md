# 交接155：完整 graph 和显式24工具已实现

2026-10-06 交接第34/133/155行描述的是当时未评审的旧草稿，不能作为今天重新施工的依据。**当前源码已完成交接155要求的 native 完整 challenger/sponsor 集合和显式24工具封装；这两项没有尚未实现的 provider/codec/原profile工具缺口。** 不建议重写、重编译或重跑已有测试。旧草稿、失败和后继 receipts 都继续保留。

| 已完成范围 | 当前真实位置/约束 |
| --- | --- |
| 完整注册集合 | `ck3_12003_challenger_graph_readback.cpp:109–132,282–338`；Faith +C0/count+CC/stride8，拒绝坏count/重复/部分读；+C8未读。known empty保留0与空数组；未知返回null，不截断冒充complete。 |
| 两类 sponsor | 同文件:308–333；registered pair与challenger-holder当前Faith的完整查找分列，保self-sponsor/重复sponsor，分别报告scope是否与原pair相同。旧saved ownerFaith不替代当前Faith。 |
| exact .4 | 同文件:362–369,415–425及`ck3_12004_confucian_title_profile.hpp`；独立.4 storage/vtable/qualification，旧.3仍按原SHA保留。 |
| Python严格DTO | `bridge/confucian_challenger_graph_v1.py:39–65,90–161`；完整Title/holder/currentFaith/四属性/完整laws，saved markers与ownerFaith保持null。request绑定actor/date/PID/generation/public+native revision。 |
| 显式第24工具 | `tools/ck3_native_profile_mcp.py:1096–1110,1219–1237,1288–1291`；`--confucian-challenger-tools` → `ck3_query_profile_confucian_challenger_graph_v1(expected_revision, faith_full_ids)`。独立strict bool、默认OFF；default21/readonly23均保留。selector1–8唯一uint32 full IDs，0合法、UINT32_MAX拒绝。 |

现有测试依据无需复验：`test_confucian_challenger_graph_v1.py:70–224` 覆盖selectors、knownempty/UNKNOWN、self-sponsor、重复/部分/错叶拒绝、holder迁移后的currentFaith、生产wire、权限恢复以及真实SDK21/23/24元数据守恒。native `ck3_12003_challenger_graph_fixture.cpp:153–226` 执行真实reader/serializer并覆盖旧owner集合与当前scope不一致；.4 `ck3_12004_confucian_title_binding_first.cpp:169–192` 已有knownempty、nonempty pair与旧Title/Faith/Law vtable拒绝。既有focused原执行回执在INDEX中引用；本包不复跑，不把历史.3检查授予新的.4实机。

当前 common Cbr2 原构建输入明确 graph/assembly/ordinary/grant ON，原BUILD0、Source09 native-inputs-unchanged和DLL pins已在上一小包核对。**Source09公共host尚未投影G4不等于第24profile封装没实现。** 当前MAIN/Source09的通用 `register_succession_title_readonly_tools` 没有G4注册，现common清单也未声明G4；不能把旧profile的24工具数量套到common9能力清单。

因此没有必要为交接155再开底层实现包。若下一C3明确走当前公共common host，唯一不同的小源码工作包应是“复用既有G4 service的显式公共路由投影”：在现通用注册器按已有default-false challenger permission注册严格只读 G4，并通过全局host feature显式传该permission、在全局manifest声明真实capability；只新增其默认OFF/拒未知selector/同帧service调用的必要注册测试。复用上述provider、normalizer、mailbox、native flag；不改旧profile21/23/24，不造第二provider，不给产品自选runtime。该路由尚未实施，不能仅改产品adapter就称固定Source09已支持；本包也未创建runtime/case或改MAIN。具体新Source冻结由ROOT按公共路由统一安排。

剩余业务证据仍等待合法正式新T/B4/B5：同Faith NPC真实在任、非empty complete graph与saved ownerFaith逐项独立join、正式挑战/拒绝/撤回/死亡清理/冷重载。旧R14/R27/R49的18373、空集合、诊断run0或Send ACK均不能替代。已备single-read discovery/strict saved adapter只是源候选，非empty保存字段映射须用实际保全projection审阅，UNKNOWN不填PASS。independent native effective doctrine仍UNKNOWN；原87/88保护不降。

本次仅只读当前源码、专题和旧小型receipt；没有运行SDK、游戏、存档正文、编译或测试。输出包仅本报告、INDEX与小型historical-result摘录，源文件/旧草稿只存pins，不复制正文。
