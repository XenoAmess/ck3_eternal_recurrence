# R49：已保存缓存 consumer 与事务移交复核

本包只消费已保存的当前 `.4` 记录和有限源码，**新 EXE／代码读取为 0**。分析代码累计仍为 20,574/65,536B；含010重验身份pin的实际代码I/O为20,787B。没有修改MAIN、运行游戏、SDK、构建或读取存档。

`2C0B4B0–2C0B7D2` 的完整227条既存指令显示，`2C0B66F` 读取 actor`+1C0` 之前只有三处调用同一目标 `2494B40`。RCX为原第三参数R8/R13，EDX来自角色`+1B0→+288`关联对象的首DWORD，AL用于输出分类。这里没有显式传入原actor或`+3A0`成员；未读callee本体，因此既不能命名成更新器，也不能排除全局/间接副作用。缓存读取之后的间接call `2C0B71A` 由本体LEA精确指向 `2494B30`，参数是第三输入对象集合的单项指针及关联ID；这同样不是writer证明。

`2AA5AA0` 把原change指针从manager`+30/+3C`集合移到`+48/+50/+54/+58`集合，元素宽8B。普通wrapper可在移交前同步调用`2773150`，并对context`+60`执行inc/call/dec。**移交已证，异步执行、deferred signal、队列drain入口均未证**。现存1.19 prequeue研究也没有队列消费证明，不能迁移其地址作当前入口。分配器虚调用和辅助函数本体未读，不把它们的全部副作用宣称为已排除。

R29旧refresh包只确认`recalculate_succession_election_vote`的教皇选举票用途，没有一般actor继承缓存刷新语义，不能作为本问题修复。另一个现存getter复核确认Title`+150`与actor缓存是不同容器，当前`every_title_heir`入口仍UNKNOWN。

唯一提出但**尚未执行**的新PE步骤为当前三处直接调用的`2494B40`：先.pdata/CHAININFO定界，metadata≤1024B，仅逻辑体≤2048B才读；大于上限即停，不递归callee、不扫.text。这个步骤可判定具体前置门的角色，不能先把它称缓存writer。精确来源、参数小窗和限制见[FACTS.actual.json](FACTS.actual.json)。原87/88保护及所有业务失败不变。
