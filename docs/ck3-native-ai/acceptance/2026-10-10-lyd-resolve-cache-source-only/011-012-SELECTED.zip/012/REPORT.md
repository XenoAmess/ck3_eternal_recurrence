# R49：缓存读取前唯一直接门（已停止）

实际命令exit0。当前`.4`的`2494B40–2494BC2`由.pdata/UNWIND确认完整130B，flags0，无CHAININFO拼接；代码SHA为`d3f63a0875e33bdffc3f058809e0c4e4c24224e378813e78ea3cbc72b55acaff`。本次metadata864B、身份pin213B、分析代码130B，共读1207B；分析累计20704/65536B，包含010/012两次身份pin的代码I/O为21130B。实际size/version/PE sections/pin均匹配，没有重hash EXE。

函数从RCX对象的`+8`读指针、`+14`读count，按8B元素遍历，经`2494B7C call R14`谓词判断并返回是否命中。caller的RCX是原第三输入R8/R13，未显式传原actor或缓存成员；这是指针集合查询形状，与actor缓存DWORD stride4不同。保留的小窗没有给出缓存写入证据。间接谓词未展开，不能据此证明整条调用无副作用或lazy刷新不存在；没有把旧`.3`callee身份移作当前资格。

此步已按授权停止，不追谓词、队列消费者或其它callee。队列drain、actor缓存writer、每Title getter lazy更新、五政治Title变化因果和生产修复仍UNKNOWN，原保护RED不变。精确实际read ledger与字段在[READ.actual.json](READ.actual.json)，紧凑结论在[FACTS.actual.json](FACTS.actual.json)。源码、运行core与Source09/O8均未改变。
