# R49：已有每Title继承观察路径与actor缓存的关系

结论：**已有合格current .4的primary-Title resolver与Title数组复制路径，但没有找到合格current `every_title_heir` iterator/getter注册入口。lazy refresh仍UNKNOWN；当前证据不能给出新生产修复或新实机变量。** 本包只读取既有源码与小ABI记录，不重读PE、consumer2C0B66F正文或存档，不构建/测试/查询。

| 观察面 | 直接证据 | 不可外推 |
| --- | --- | --- |
| actor cached succession | 已入库actor_cached_succession12004_v1.hpp:18–27、64–69：Char+1C0→Land receiver+3A0，data+0/count+C/stride4；reader不调用包围classifier，不refresh | 名字相近不证明和任意Title列表相等；该Land receiver的独立RTTI仍由另一研究lane负责 |
| primary Title resolver | 原FINITE-READERS actual .4 `289DA10..289DA85`，Char+1C0→Land+1E0/+1EC的首Title ID，完整ID解析；另有Char+1D0分支。已存指令为loads/branches/identity comparison/ret，无call | 它返回Title，不返回继承人；不能把它称为every_title_heir，也不读Land+3A0。原记录无pdata边界，只取已解码first-ret leaf，不把256B窗口的邻居当函数 |
| primary Title有序数组 | ck3_12004_campaign.cpp:1574–1576、1774–1817：CLandedTitle+150 data/+158 capacity/+15C count，按4B ID完整复制与身份/重复校验；ReadBytes:1614–1619只经memory accessor或guarded memcpy | 这个读取本体没有engine继承getter/刷新调用；不能证明script iterator也只读同一字段 |
| 每个held Title | 同文件1883–1899 resolve完整Title ID/holder，1910–1932读同数组header，但DTO只取count和first heir | 不能把held_title_partition现有DTO称为七Title完整名单；只有primary_title_succession字段完整复制 |
| stock脚本观察 | build_factory_diagnostic.py:47–61：每个political-title scope直接调用every_title_heir，并记录scope；306–314保留order/fullID未资格与getter可能lazy的标注 | `getter_may_trigger_lazy_recalculation=True`是作者保留的不确定性，不是已证明发生lazy refresh的ABI或运行时证据 |

Class/type依据：current .4 CLandedTitle primary-vtable `4712A28` 由ck3_12004_confucian_title_profile.hpp:10–27的独立RTTI/COL地图绑定；map SHA `5f5a1005711ef523bcd228c1b2ff2822a9767e13c1b9a934f9a3a87f37287e3d`。campaign reader按完整Title identity从typed storage解析，不能因此额外声称每次都做了vtable检查。其继承候选值是DWORD完整Character ID；这些类事实不自动闭合脚本iterator入口。

R49的四段scope日志首次差异在AFTER_RESOLVE，和actor原生45→40仍是不同观察面；39527未出现在Title20列表中。当前材料不能把Title数组与script iterator或actor vector做等价替换。旧R34无本日志仍final40、R47空事务resolve45的事实不被本包改写，不重复去getter、去flag或无变化B4。

最窄后继是**先映射同一个stock `every_title_heir` 注册名到当前.4 typed iterator/getter**，精确源码入口是build_factory_diagnostic.py:56；所需直接ABI证据应是其注册row/typed receiver→实际getter，再判定getter是只复制Title+150数组，还是存在dirty/predicate/refresh调用。当前已有小记录没有该row或RVA，故本包不给虚构地址/读取预算，也不将`289DA10`或另一lane的`2C0B66F`冒充它。获得真实注册锚点后再提出单入口有限读取计划；不展开generic evaluator树。

只从当前闭合范围看，原生actor observer和primary Title数组reader都不能被称为lazy-refresh触发器；脚本iterator是否触发仍UNKNOWN。因此尚无被证明的新law/holder/事务类型改动可推荐为修复。87/88原保护和正式B4/B5/C3信用保持不变。
