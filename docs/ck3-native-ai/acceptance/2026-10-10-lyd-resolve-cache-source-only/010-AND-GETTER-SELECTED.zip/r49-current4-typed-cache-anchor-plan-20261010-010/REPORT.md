# R49：实际缓存读取锚与有限 RTTI 搜索

先核已资格化读取锚：原 current4 consumer `2C0B66F–2C0B687` 直接载入actor+1C0、取成员+3A0、读取count+C，中间没有call。项目缓存provider的ReadHeader/CopyIds也是读取既有内存，没有调用引擎缓存getter或刷新方法。ID解析另经ResolveCoreCharacter回调，本包没有把该独立实现冒充已全面证明纯函数。现有证据不支持observer本身引发lazy refresh；stock every_title_heir的引擎路径仍UNKNOWN。

CampaignRoot读取Title+150/+15C，和actor成员+3A0不是同一个缓存。既有同帧native/save equality仍有效，不能由此推出getter或writer身份。

ROOT授权后，实际Python命令exit0。先重新核当前EXE size、4096B PE/section map、32B版本和原213B代码pin，全部match；随后只在.data RVA5A00000–5B00000的1MiB内查询两种精确CCharacterLandState RTTI名称，均未命中，已停止。没有搜索别名、COL、vtable或新函数，没有保存完整1MiB窗口。名称可能只是描述性布局名或非虚类型；窗口内未命中不能证明全image不存在此类型，更不推翻原member身份。

新EXE读取1,052,917B，其中metadata1,052,704B、身份复核代码pin213B；没有新函数分析代码。原分析链20,574B不变，若计本次身份pin的实际代码I/O则为20,787/65,536B。完整命令、exit0、区段与SHA见原回执及 [FACTS.actual.json](FACTS.actual.json)。

本包不授修复或业务信用；writer、每Title getter/lazy及政治继承因果仍UNKNOWN。下一步仅复用已保存consumer完整范围/typed profile事实提出直接目标，不自动追加PE读取。无MAIN、SDK/游戏、进程、构建、存档正文、EXE全hash/copy或新runtime/cache/profile。新派生48小时、compact7日复核，旧期限不续。
