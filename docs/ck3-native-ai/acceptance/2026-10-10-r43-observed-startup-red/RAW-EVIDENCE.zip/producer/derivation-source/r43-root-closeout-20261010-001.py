from pathlib import Path
from datetime import datetime, timezone
import json
import hashlib
import os
import sys
import psutil
import win32api
import win32con
import pyautogui

run = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0043')
keeper = Path('C:/workspace/ck3-common-runtime/keepers/20261010-a05')
state = Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-005/state')
sys.path.insert(0, 'C:/csr5/ck3_autonomous_player/src')
from xar_autoplayer.runtime import ck3_process_inventory

def put(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

report = json.loads((run / 'native-report.json').read_bytes())
host_exit = json.loads((run / 'host-original-process-exit.json').read_bytes())
observer_exit = json.loads((run / 'startup-observer-001/EXIT.actual.json').read_bytes())
if not (observer_exit['pid'] == 10656 and observer_exit['actual_exit_code'] == 1 and observer_exit['original_createprocess_handle'] is False):
    raise SystemExit('Actual R43 independent exit receipt mismatch')
if report.get('status') != 'RED' or report.get('managed_session_thread_finished') is not True or host_exit.get('returncode') != 1:
    raise SystemExit('Expected actual completed failed-launch report and original host exit')
inventory = ck3_process_inventory()
if inventory.get('processes') != []:
    raise SystemExit('CK3 process remains: ' + repr(inventory))
control = state / 'control'
paths = [control / 'ck3.json', control / 'unsafe-cleanup.json', control / 'ck3.watchdog_error',
    *control.glob('watchdog-*.ready.json')]
controls = [{'path': str(path), 'exists': path.exists()} for path in paths]
if any(row['exists'] for row in controls):
    raise SystemExit('Uncleared control file remains')
matches = []
expected_allocation_supervision = []
errors = []
for process in psutil.process_iter(['pid', 'name', 'cmdline', 'create_time']):
    try:
        row = process.info
        argv = row.get('cmdline') or []
        args = ' '.join(argv).lower()
        if 'allocate' in argv and 'tools/ck3_mod_acceptance.py' in argv:
            expected_allocation_supervision.append(row)
            continue
        if row['pid'] != os.getpid() and (row.get('name', '').lower() == 'ck3.exe' or
            ('python' in row.get('name', '').lower() and 'lyd-transaction-control-20261010-005' in args)):
            matches.append(row)
    except (psutil.NoSuchProcess, psutil.AccessDenied) as error:
        errors.append(str(error))
if matches:
    raise SystemExit('A case process still remains: ' + repr(matches))
put(run / 'ACTUAL-CURRENT-CLOSEOUT.json', {'at_utc': datetime.now(timezone.utc).isoformat(),
    'ck3_inventory': inventory, 'case_processes': matches, 'expected_allocation_supervision': expected_allocation_supervision, 'process_read_errors': errors,
    'control_files': controls, 'host_original_exit': host_exit,
    'independent_observer_handle_exit': observer_exit, 'historical_host_cleanup_ok': report.get('cleanup_ok'), 'historical_ck3_exit_code': None,
    'historical_job_final_active_count': None, 'normal_exit_zero_claimed': False,
    'note': 'Independent observer handle proves actual CK3 exit1; fresh census permits release. Original CreateProcess-handle and Job shutdown records are still missing; cleanup_ok=false and no typed normal0 remain unchanged.'})
image = run / 'steam-final-recovery-001/probe-1/steam-moved.png'
raw = image.read_bytes()
put(run / 'steam-final-recovery-001/OFFLINE-REVIEW.actual.json', {
    'at_utc': datetime.now(timezone.utc).isoformat(), 'path': str(image), 'bytes': len(raw),
    'sha256': hashlib.sha256(raw).hexdigest(), 'direct_original_image_review': True,
    'visible_offline_text': '离线模式', 'steam_offline_confirmed': True,
    'visible_desktop_clock': '10:31 2026/10/10', 'actual_window_move_observed': True})
original = json.loads((run / 'display-fit-001.json').read_bytes())['before']
def describe(mode):
    return {'width': mode.PelsWidth, 'height': mode.PelsHeight, 'bits': mode.BitsPerPel, 'frequency': mode.DisplayFrequency}
before = describe(win32api.EnumDisplaySettings(None, win32con.ENUM_CURRENT_SETTINGS))
chosen = None
for index in range(1000):
    try:
        mode = win32api.EnumDisplaySettings(None, index)
    except Exception:
        break
    if describe(mode) == original:
        chosen = mode
        break
if chosen is None or win32api.ChangeDisplaySettingsEx(None, chosen, win32con.CDS_TEST) != 0:
    raise SystemExit('Original display mode unavailable')
code = win32api.ChangeDisplaySettingsEx(None, chosen, 0)
after = describe(win32api.EnumDisplaySettings(None, win32con.ENUM_CURRENT_SETTINGS))
put(run / 'display-restore-001.json', {'at_utc': datetime.now(timezone.utc).isoformat(), 'before': before,
    'original': original, 'after': after, 'change_result': code, 'pyautogui_size': list(pyautogui.size()),
    'registry_persistence_requested': False})
if code != 0 or after != original:
    raise SystemExit('Display restoration did not match original')
put(keeper / 'STOP', {'at_utc': datetime.now(timezone.utc).isoformat(),
    'reason': 'R43 observed pre-injection startup timeout; original host exit1; current CK3/case census and control files empty; final Steam offline reviewed; display restored',
    'normal_exit_zero_claimed': False, 'historical_host_cleanup_ok': False})
print(json.dumps({'current_process_census_empty': True, 'display_restored': after, 'keeper_stop_requested': True}))
