from pathlib import Path
import hashlib
import json
import psutil

b = Path('C:/workspace/ck3_lyd_runtime_20261004')
rows = []
for kind in ('desktop', 'steam-window'):
    old = b / f'r42-root-fit-{kind}-20261010-001.py'
    new = b / f'r43-root-fit-{kind}-20261010-001.py'
    text = old.read_text(encoding='utf-8')
    if text.count('--R0042') != 1:
        raise RuntimeError('Unexpected original display helper')
    changed = text.replace('--R0042', '--R0043')
    compile(changed, str(new), 'exec')
    with new.open('x', encoding='utf-8', newline='\n') as f:
        f.write(changed)
    rows.append({'original': str(old), 'original_sha256': hashlib.sha256(old.read_bytes()).hexdigest(),
                 'derived': str(new), 'derived_sha256': hashlib.sha256(new.read_bytes()).hexdigest(),
                 'only_change': 'R0042 run path to R0043; actual Steam HWND/PID checks unchanged'})
observer = b / 'r43-root-startup-observer-20261010-001.py'
compile(observer.read_text(encoding='utf-8'), str(observer), 'exec')
out = b / 'r43-root-launch-tools-derivation-20261010-001.json'
with out.open('x', encoding='utf-8', newline='\n') as f:
    json.dump({'derivations': rows, 'observer_compilation': 'PASS',
               'observer_sha256': hashlib.sha256(observer.read_bytes()).hexdigest(),
               'system_memory': psutil.virtual_memory()._asdict(),
               'swap': psutil.swap_memory()._asdict(),
               'current_ck3': [{'pid': p.pid, 'name': p.info['name']} for p in psutil.process_iter(['name']) if (p.info['name'] or '').lower() == 'ck3.exe'],
               'game_launched': False, 'display_actions_executed': False}, f, indent=2)
    f.write('\n')
print(out.read_text(encoding='utf-8'))
