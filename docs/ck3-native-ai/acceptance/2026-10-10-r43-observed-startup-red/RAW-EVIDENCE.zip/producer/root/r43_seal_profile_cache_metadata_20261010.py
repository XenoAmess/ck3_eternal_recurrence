from pathlib import Path
import hashlib
import json

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT=BASE/'r43-profile-cache-metadata-readonly-20261010-001'

def ref(path,body=None):
    body=path.read_bytes() if body is None else body
    return {'path':str(path),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}

def json_new(name,value):
    path=OUT/name
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2)
        stream.write('\n')
    return ref(path)

materializer=BASE/'r38-root-materialize-transaction-only-cold-20261009-001.py'
launch_source=BASE/'r38-root-launch-diagnostic-20261009-001.py'
receipt_path=BASE/'live-attempt-038/COLD-MATERIALIZED.json'
launch_path=BASE/'live-attempt-038/launch.json'
receipt=json.loads(receipt_path.read_text(encoding='utf-8-sig'))
launch=json.loads(launch_path.read_text(encoding='utf-8-sig'))
sources=[]
for path,ranges in ((materializer,[(1,32),(54,89)]),(launch_source,[(45,74)])):
    body=path.read_bytes()
    lines=body.decode('utf-8-sig').splitlines()
    sources.append({'source':ref(path,body),'cuts':[{'first_line':lo,'last_line':hi,'lines':[{'line':n,'text':lines[n-1]} for n in range(lo,min(hi,len(lines))+1)]} for lo,hi in ranges]})
public=[]
for case in ('004','005'):
    root=Path('C:/workspace/ck3-common-runtime/cases')/('lyd-transaction-control-20261010-'+case)/'prepared'
    preparation_path=root/'profile-preparation.json'
    prepared_path=root/'prepared-case.json'
    prep=json.loads(preparation_path.read_text(encoding='utf-8-sig'))
    prepared=json.loads(prepared_path.read_text(encoding='utf-8-sig'))
    files=prep['files']
    cache_inputs=[name for name in files if name.split('/',1)[0].casefold() in ('shadercache','shader_cache','cache','gfx','gfxcache')]
    def select_plain(obj):
        if isinstance(obj,dict):
            for key,value in obj.items():
                if key=='plain_configuration':return value
                found=select_plain(value)
                if found is not None:return found
        elif isinstance(obj,list):
            for value in obj:
                found=select_plain(value)
                if found is not None:return found
        return None
    public.append({'case':case,'preparation':ref(preparation_path),'prepared_case':ref(prepared_path),'profile_dir':prep['profile_dir'],'prepared_top_level_file_prefixes':sorted(set(name.split('/',1)[0] for name in files)),'prepared_cache_input_names':cache_inputs,'plain_configuration_source_pins':select_plain(prepared)})
provenance={'schema':'lyd.r43.profile-cache-copy-provenance.source-only.v1','R38_materializer_source':sources,'R38_materialized_receipt':ref(receipt_path),'R38_configuration_sources':receipt['settings'],'R38_receipt_status':receipt['status'],'R38_launch':{'source':ref(launch_path),'launched_at_utc':launch['launched_at_utc'],'argv':launch['argv']},'public_preparations':public,'public_source_cuts':ref(OUT/'PUBLIC-PREPARE-SOURCE-CUTS.actual.json'),'findings':{'R38_preexisting_run_allowed_by_materializer':False,'R38_profile_shadercache_copy_present_in_materializer':False,'public_profile_shadercache_copy_present_in_case_preparation':False,'public_preparation_cache_files_declared':sum(len(item['prepared_cache_input_names']) for item in public)},'limits':'Materializer/source and receipts describe these exact profile preparations. Other engine/OS/driver caches, later external cache modification and actual cache hit/compile semantics are not observed.'}
provenance_ref=json_new('CACHE-COPY-PROVENANCE.actual.json',provenance)
metadata=json.loads((OUT/'CACHE-DIRECTORY-METADATA.actual.json').read_text(encoding='utf-8'))
profiles=[]
for profile in metadata['profiles']:
    profiles.append({'role':profile['role'],'profile':profile['profile'],'cache_subtrees':[{key:value for key,value in node.items() if key not in ('files','directories','skipped_nonregular')} for node in profile['cache_subtrees']]})
summary={'schema':'lyd.r43.profile-cache-metadata-diagnostic.v1','observed_start':metadata['started_at_utc'],'observed_end':metadata['finished_at_utc'],'profiles':profiles,'metadata_only':True,'cache_body_reads':0,'cache_body_hashes':0,'save_body_reads':0,'runtime_actions':0,'provenance':provenance_ref,'conclusion':'No evidence that R38 was seeded with a hot profile shadercache while public profiles were not. Both materializers construct fresh profile roots without copying shadercache; retained R38 shadercache creation and file mtimes are after actual launch.','unknown':['Actual shadercache hit/compile behavior','Global OS/GPU/driver cache warmth','Loading timeout cause'],'C5_snapshot_limit':'Taken while ROOT owns live R43; single non-atomic metadata traversal, not a pre-launch or final inventory.'}
summary_ref=json_new('SUMMARY.actual.json',summary)
report='''# R43：R38 / C4 / C5 profile 缓存元数据

仅对三个确切 userdir/profile 的 shader/cache/gfx 命名子树作一次目录与 stat 遍历；没有读取或 hash 缓存内容，没有读 seed、查询 SDK、操作进程/游戏或修改主仓。记录为 UTC。C5 正在运行，遍历非原子，计数只代表本次采样，不是启动前或最终状态。

| Profile | shadercache 文件数 | 总字节 | 文件 mtime 范围（UTC） |
| --- | ---: | ---: | --- |
| R38 | 3,740 | 146,942,067 | 2026-10-09 13:22:36.414433 → 13:30:47.037419 |
| 失败 C4 | 3,691 | 143,593,997 | 2026-10-10 00:11:29.281404 → 00:21:26.294211 |
| 运行中 C5 | 1,900 | 42,659,717 | 2026-10-10 02:20:33.999200 → 02:25:56.829131 |

三者 `shadercache` 存在，`cache`、`gfx`、`gfxcache`、`shader_cache` 均不存在。逐文件名称、大小、mtime/creation 元数据保存在 CACHE-DIRECTORY-METADATA.actual.json，没有内容 hash。

R38 原 launch.json 的实际启动为 2026-10-09 13:22:33.852741Z；shadercache 目录 creation/mtime 为13:22:36.414433Z，全部 retained 文件 mtime 都在启动后。原 `r38-root-materialize-transaction-only-cold-20261009-001.py` 要求新 RUN，67–86行仅新建 userdir、复制四项配置、外层 mod registrations 与 seed；54–65行复制的是声明的 mod 源目录到 mounted 内容，不是旧 userdir shadercache。原 COLD-MATERIALIZED.json 的 settings 四项来源 pin 完整保留，没有 shadercache 复制声明。这些事实不支持 R38 启动前复用了既有热 profile 缓存。

公共 C4/C5 的 pinned 产品 prepare_case（69–123行）要求新 state/profile，复制四项 plain_configuration、正式 product 和 overlay 的逐项声明文件、生成 mod/dlc_load 与 preparation。两份实际 profile-preparation.json 的顶层准备输入均无 shadercache/cache/gfx。配置可来自 R38 的普通配置文件，这不等于复制其 shadercache。原 helper 的 checked_copy 只复制显式文件；generic restore_prepared_profile 虽能恢复既有 before-launch inventory，但此 case 的 prepare_case 没有走该分支。

可区分的结论是：两条已读准备路径均没有继承 profile shadercache；R38 的现存缓存是在其启动后生成。不能由目录数量证明实际 shader 编译成功、命中率或具体加载等待点；未检查 engine 安装目录、Windows、GPU 驱动或其他全局缓存。因此“R38 热、公共必冷”的 profile 差异没有证据，R43 加载原因仍 UNKNOWN。本包不复制缓存、不增 flag、不安排启动，也不建议延长预算。
'''
report_path=OUT/'REPORT.zh.md'
with report_path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(report)
index={'schema':'lyd.r43.profile-cache-metadata-diagnostic.index.v1','summary':summary_ref,'report':ref(report_path),'artifacts':[ref(path) for path in sorted(OUT.iterdir()) if path.is_file()],'authors':[ref(BASE/name) for name in ('r43_identify_profile_cache_sources_20261010.py','r43_capture_profile_cache_metadata_20261010.py','r43_read_cache_provenance_sources_20261010.py','r43_seal_profile_cache_metadata_20261010.py')],'cache_body_reads':0,'cache_body_hashes':0,'startup_cause':'UNKNOWN'}
index_ref=json_new('INDEX.json',index)
print(json.dumps({'index':index_ref,'summary':summary_ref,'report':ref(report_path)},ensure_ascii=False,indent=2))
