from pathlib import Path
import json
import subprocess

root = Path('C:/workspace/ck3_eternal_recurrence')
for rel in subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=U'], cwd=root, text=True).splitlines():
    for stage in (1, 2, 3):
        text = subprocess.check_output(['git', 'show', f':{stage}:{rel}'], cwd=root).decode('utf-8')
        lines = [line for line in text.splitlines() if '22976' in line]
        print(json.dumps({'path': rel, 'stage': stage, 'matching_lines': lines}, ensure_ascii=False))
