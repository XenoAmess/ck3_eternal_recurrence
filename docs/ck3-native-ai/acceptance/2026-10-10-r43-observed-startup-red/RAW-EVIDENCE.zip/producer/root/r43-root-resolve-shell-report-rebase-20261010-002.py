from pathlib import Path
import hashlib
import json
import subprocess

root = Path('C:/workspace/ck3_eternal_recurrence')
paths = subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=U'], cwd=root, text=True).splitlines()
expected = ['docs/autonomous-agent-progress/daily/2026-10-10.md', 'docs/autonomous-agent-progress/weekly/2026-W41.md', 'docs/testing-workflow.md']
if sorted(paths) != sorted(expected):
    raise RuntimeError('Unexpected conflict scope: ' + str(paths))

def correction(raw):
    text = raw.decode('utf-8')
    a = 'a stale Codex PowerShell PID22976'
    c = 'Targeted command classification showed Get-Content and no listed'
    if text.count(a) != 1 or text.count(c) != 1:
        raise RuntimeError('Unexpected historical line')
    return text.replace(a, 'a stale Codex process from a prohibited historical read shell, PID22976').replace(c, 'Targeted command classification showed read-only file content inspection and no listed').encode('utf-8')

rows = []
for rel in paths:
    base, remote, local = [subprocess.check_output(['git', 'show', f':{stage}:{rel}'], cwd=root) for stage in (1, 2, 3)]
    if correction(base) != local:
        raise RuntimeError('Local edit is not solely the approved correction: ' + rel)
    if remote.count(b'a stale Codex read-shell process PID22976') != 1:
        raise RuntimeError('Unexpected concurrent historical wording')
    normalized = remote.replace(b'a stale Codex read-shell process PID22976', b'a stale Codex PowerShell PID22976')
    resolved = correction(normalized)
    (root / rel).write_bytes(resolved)
    rows.append({'path': rel, 'remote_sha256': hashlib.sha256(remote).hexdigest(), 'resolved_sha256': hashlib.sha256(resolved).hexdigest(),
                 'all_remote_append_content_retained': True, 'local_change_exactly_replayed': True})
subprocess.run(['git', 'add', '--', *paths], cwd=root, check=True)
with Path(__file__).with_suffix('.actual.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump({'files': rows, 'merge_commit_created': False}, f, indent=2)
    f.write('\n')
print(json.dumps({'resolved': len(rows)}))
