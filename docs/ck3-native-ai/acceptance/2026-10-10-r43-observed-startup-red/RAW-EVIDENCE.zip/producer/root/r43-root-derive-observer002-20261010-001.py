from pathlib import Path
import hashlib
import json

b = Path('C:/workspace/ck3_lyd_runtime_20261004')
old = b / 'r43-root-startup-observer-20261010-001.py'
new = b / 'r43-root-startup-observer-20261010-002.py'
text = old.read_text(encoding='utf-8')
before = "            sample['windows'] = windows(original.pid)\n        except Exception as exc:\n            sample['errors'].append({'type': type(exc).__name__, 'message': str(exc)})\n"
after = "        except Exception as exc:\n            sample['errors'].append({'type': type(exc).__name__, 'message': str(exc)})\n        try:\n            sample['windows'] = windows(original.pid)\n        except Exception as exc:\n            sample['errors'].append({'window_error': type(exc).__name__ + ': ' + str(exc)})\n"
if text.count(before) != 1:
    raise RuntimeError('Unexpected window block')
text = text.replace(before, after)
before = "        debug = profile / 'logs/debug.log'\n        if debug.is_file():\n            with debug.open('rb') as f:\n                f.seek(max(0, debug.stat().st_size - 2500))\n                tail = f.read(2500)\n            sample['debug_log_size'] = debug.stat().st_size\n            sample['debug_log_tail'] = tail.decode('utf-8', errors='replace')\n"
after = "        try:\n            debug = profile / 'logs/debug.log'\n            if debug.is_file():\n                with debug.open('rb') as f:\n                    f.seek(max(0, debug.stat().st_size - 2500))\n                    tail = f.read(2500)\n                sample['debug_log_size'] = debug.stat().st_size\n                sample['debug_log_tail'] = tail.decode('utf-8', errors='replace')\n        except Exception as exc:\n            sample['errors'].append({'debug_log_error': type(exc).__name__ + ': ' + str(exc)})\n"
if text.count(before) != 1:
    raise RuntimeError('Unexpected debug block')
text = text.replace(before, after)
compile(text, str(new), 'exec')
with new.open('x', encoding='utf-8', newline='\n') as f:
    f.write(text)
out = b / 'r43-root-observer002-derivation-20261010-001.json'
with out.open('x', encoding='utf-8', newline='\n') as f:
    json.dump({'original_sha256': hashlib.sha256(old.read_bytes()).hexdigest(),
               'derived_sha256': hashlib.sha256(new.read_bytes()).hexdigest(),
               'changes': ['Independent window sampling exception boundary', 'Log read errors recorded without losing later process exit observation'],
               'compile': 'PASS', 'observer_executed': False}, f, indent=2)
    f.write('\n')
print(str(new))
