from pathlib import Path
import hashlib
import json

b = Path('C:/workspace/ck3_lyd_runtime_20261004')
old = b / 'r42-root-closeout-20261010-001.py'
new = b / 'r43-root-closeout-20261010-001.py'
text = old.read_text(encoding='utf-8')
changes = [('--R0042', '--R0043'), ('20261010-a04', '20261010-a05'),
    ('lyd-transaction-control-20261010-004', 'lyd-transaction-control-20261010-005'),
    ('observer-retained-handle-exit.json', 'startup-observer-001/EXIT.actual.json'),
    ("assert observer_exit['pid'] == 9988 and observer_exit['actual_exit_code'] == 1 and observer_exit['original_createprocess_handle'] is False",
     "if not (observer_exit['pid'] == 10656 and observer_exit['actual_exit_code'] == 1 and observer_exit['original_createprocess_handle'] is False):\n    raise SystemExit('Actual R43 independent exit receipt mismatch')"),
    ('8:37 2026/10/10', '10:31 2026/10/10'),
    ('R42 debug-only pre-injection startup timeout', 'R43 observed pre-injection startup timeout')]
for before, after in changes:
    if before not in text:
        raise RuntimeError('Missing original closeout fragment: ' + before)
    text = text.replace(before, after)
compile(text, str(new), 'exec')
with new.open('x', encoding='utf-8', newline='\n') as f:
    f.write(text)
with Path(__file__).with_suffix('.actual.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump({'original_sha256': hashlib.sha256(old.read_bytes()).hexdigest(),
               'derived_sha256': hashlib.sha256(new.read_bytes()).hexdigest(), 'changes': changes,
               'actual_failure_and_exit_receipts_reviewed': True, 'original_final_steam_image_directly_reviewed': True,
               'cleanup_executed': False}, f, indent=2)
    f.write('\n')
print(str(new))
