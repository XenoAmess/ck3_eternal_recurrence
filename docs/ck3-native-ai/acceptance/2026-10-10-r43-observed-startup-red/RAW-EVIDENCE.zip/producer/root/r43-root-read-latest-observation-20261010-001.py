from pathlib import Path
from datetime import datetime, timezone
import json

out = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0043/startup-observer-001')
paths = sorted(out.glob('sample-*.actual.json'))
rows = []
for path in paths[-2:]:
    s = json.loads(path.read_bytes())
    rows.append({k: s.get(k) for k in ['index', 'at_utc', 'elapsed_seconds', 'cpu_one_core_percent_over_interval', 'num_threads', 'errors']})
    rows[-1].update(rss=s.get('memory_info', {}).get('rss'), available_memory=s.get('system_memory', {}).get('available'),
        io_deltas=s.get('io_deltas'), windows=s.get('windows'), last_debug_lines=s.get('debug_log_tail', '').splitlines()[-2:],
        top_threads=s.get('thread_cpu_deltas', [])[:3])
print(json.dumps({'at_utc': datetime.now(timezone.utc).isoformat(), 'count': len(paths), 'latest': rows,
    'exit': json.loads((out / 'EXIT.actual.json').read_bytes()) if (out / 'EXIT.actual.json').exists() else None}, ensure_ascii=False, indent=2))
