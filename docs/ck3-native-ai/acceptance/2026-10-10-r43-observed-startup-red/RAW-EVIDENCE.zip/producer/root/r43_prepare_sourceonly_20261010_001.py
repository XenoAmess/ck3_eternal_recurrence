"""Produce file-only R43 inputs and argv; never invoke the public entry."""
import copy
import hashlib
import json
from pathlib import Path

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r43-transaction-control-prepare-sourceonly-20261010-001'
OLD = BASE / 'r42-transaction-control-prepare-sourceonly-20261010-001/prepare-inputs.candidate.json'
CASE4 = 'C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-004'
CASE5 = 'C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-005'


def ref(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def put(name, value):
    path = OUT / name
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    return ref(path)


def main():
    original = json.loads(OLD.read_bytes())
    assert original['state_dir'].replace('\\', '/') == CASE4 + '/state'
    candidate = copy.deepcopy(original)
    candidate['state_dir'] = CASE5 + '/state'
    unchanged = {key: value for key, value in candidate.items() if key != 'state_dir'}
    assert unchanged == {key: value for key, value in original.items() if key != 'state_dir'}
    OUT.mkdir(exist_ok=False)
    files = [put('prepare-inputs.candidate.json', candidate)]
    sources = [ref(OLD)]
    for mode in ['prepare', 'preflight']:
        source = BASE / ('r42-root-case-' + mode + '-20261010-001/RESULT.actual.json')
        actual = json.loads(source.read_bytes())
        assert actual['exit_code'] == 0
        argv = actual['argv']
        changed = []
        for arg in argv:
            new = arg.replace(CASE4, CASE5)
            if arg == 'C:/workspace/ck3_lyd_runtime_20261004/r42-transaction-control-prepare-sourceonly-20261010-001/prepare-inputs.candidate.json':
                new = (OUT / 'prepare-inputs.candidate.json').as_posix()
            changed.append(new)
        assert changed[changed.index('--runtime') + 1] == 'C:/workspace/ck3-common-runtime/20261010-004/runtime.local.json'
        files.append(put(mode.upper() + '-ARGV.actual.json', {'cwd': 'C:/workspace/ck3_eternal_recurrence', 'argv': changed, 'executed': False}))
        sources.append(ref(source))
    files.append(put('DERIVATION.actual.json', {'source': sources[0], 'changed_input_keys': ['state_dir'],
        'old_state_dir': original['state_dir'], 'new_state_dir': candidate['state_dir'],
        'other_input_values_exactly_equal': True, 'runtime_unchanged': 'C:/workspace/ck3-common-runtime/20261010-004/runtime.local.json',
        'seed_pin_unchanged': candidate['saved_campaign'], 'seed_body_reads': 0,
        'actual_case005_exists_at_authoring': Path(CASE5).exists(), 'public_entry_invocations': 0,
        'id_allocations': 0, 'launches': 0, 'repository_edits': 0, 'business_pass': False}))
    index = put('INDEX.json', {'schema': 'lyd.r43.prepare-sourceonly.v1', 'producer': ref(Path(__file__)), 'inherited_actual_sources': sources, 'files': files})
    print(json.dumps({'index': index, 'inputs': files[0], 'prepare_argv': files[1], 'preflight_argv': files[2], 'only_state_dir_changed': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()
