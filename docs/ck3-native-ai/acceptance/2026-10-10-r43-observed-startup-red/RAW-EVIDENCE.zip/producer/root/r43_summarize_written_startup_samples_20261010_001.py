"""Read existing observer receipts only; no process/window/screen API calls."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
SOURCE = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0043/startup-observer-001')
OUT = BASE / 'r43-written-startup-samples-readonly-20261010-001'

def pin(path, raw=None):
    if raw is None:
        raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def read(path):
    raw = path.read_bytes()
    return json.loads(raw), pin(path, raw)

rows = []
pending = []
for path in sorted(SOURCE.glob('sample-*.actual.json')):
    try:
        data, ref = read(path)
    except json.JSONDecodeError:
        pending.append(str(path))
        continue
    memory = data.get('memory_info', {})
    row = {key: data.get(key) for key in ['index', 'at_utc', 'elapsed_seconds', 'pid', 'cpu_times',
        'cpu_one_core_percent_over_interval', 'io_counters', 'io_deltas', 'num_threads', 'status',
        'system_memory', 'swap', 'windows', 'errors']}
    row.update({'source': ref, 'rss_bytes': memory.get('rss'), 'vms_bytes': memory.get('vms'),
        'threads_returned': len(data.get('threads', [])),
        'top_same_thread_cpu_deltas': data.get('thread_cpu_deltas', [])[:5],
        'debug_log_size': data.get('debug_log_size'), 'desktop_image': data.get('desktop_image')})
    rows.append(row)
receipts = {}
for name in ['ARMED.actual.json', 'HANDLE-READY.actual.json', 'EXIT.actual.json',
             'OBSERVATION-LIMIT.actual.json', 'DISCOVERY-MISS.actual.json']:
    path = SOURCE / name
    if path.is_file():
        try:
            value, ref = read(path)
            receipts[name] = {'source': ref, 'value': value}
        except json.JSONDecodeError:
            pending.append(str(path))

valid_cpu = [row['cpu_one_core_percent_over_interval'] for row in rows
    if isinstance(row.get('cpu_one_core_percent_over_interval'), (int, float))]
cpu_totals = [sum(row['cpu_times'].get(k, 0) for k in ['user', 'system'])
    for row in rows if isinstance(row.get('cpu_times'), dict)]
rss = [row['rss_bytes'] for row in rows if isinstance(row.get('rss_bytes'), int)]
threads = [row['num_threads'] for row in rows if isinstance(row.get('num_threads'), int)]
report = {'schema': 'ck3-existing-startup-sample-summary-v1',
    'read_at_utc': datetime.now(timezone.utc).isoformat(), 'producer': pin(Path(__file__)),
    'source_directory': str(SOURCE), 'sample_count': len(rows), 'samples': rows,
    'receipts': receipts, 'pending_partial_json': pending,
    'observation_time_bounds_utc': [rows[0]['at_utc'], rows[-1]['at_utc']] if rows else [],
    'sample_elapsed_bounds_seconds': [rows[0]['elapsed_seconds'], rows[-1]['elapsed_seconds']] if rows else [],
    'cpu_one_core_percent_range': [min(valid_cpu), max(valid_cpu)] if valid_cpu else [],
    'observed_cpu_cumulative_delta_seconds': cpu_totals[-1] - cpu_totals[0] if len(cpu_totals) > 1 else None,
    'rss_bytes_range': [min(rss), max(rss)] if rss else [],
    'num_threads_range': [min(threads), max(threads)] if threads else [],
    'error_count': sum(len(row.get('errors') or []) for row in rows),
    'new_sampling': False, 'process_window_screen_api_calls': 0, 'process_signals': 0,
    'repo_writes': 0, 'save_body_reads': 0, 'cause_or_deadlock_inferred': False, 'business_pass': False}
OUT.mkdir(exist_ok=True)
path = OUT / ('snapshot-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ') + '.actual.json')
with path.open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({'output': pin(path), 'sample_count': len(rows),
    'utc_bounds': report['observation_time_bounds_utc'], 'elapsed_bounds': report['sample_elapsed_bounds_seconds'],
    'cpu_one_core_percent_range': report['cpu_one_core_percent_range'],
    'cpu_total_delta_seconds': report['observed_cpu_cumulative_delta_seconds'],
    'rss_bytes_range': report['rss_bytes_range'], 'num_threads_range': report['num_threads_range'],
    'errors': report['error_count'], 'pending': pending,
    'last_samples': [{**{key: row.get(key) for key in ['index', 'at_utc', 'elapsed_seconds',
        'cpu_one_core_percent_over_interval', 'io_deltas', 'num_threads', 'rss_bytes', 'errors']},
        'system_memory_percent': (row.get('system_memory') or {}).get('percent'),
        'system_memory_available_bytes': (row.get('system_memory') or {}).get('available'),
        'foreground_hwnd': (row.get('windows') or {}).get('foreground_hwnd'),
        'foreground_pid': (row.get('windows') or {}).get('foreground_pid'),
        'game_windows': [w for w in (row.get('windows') or {}).get('game_windows', []) if w.get('class') == 'SDL_app'],
        'top_same_thread_cpu_deltas': row.get('top_same_thread_cpu_deltas', [])[:2]} for row in rows[-3:]],
    'terminal_receipts': {key: value for key, value in receipts.items() if key not in ['ARMED.actual.json', 'HANDLE-READY.actual.json']},
    'identity_pid': receipts.get('HANDLE-READY.actual.json', {}).get('value', {}).get('process', {}).get('pid')}, ensure_ascii=False, indent=2))
