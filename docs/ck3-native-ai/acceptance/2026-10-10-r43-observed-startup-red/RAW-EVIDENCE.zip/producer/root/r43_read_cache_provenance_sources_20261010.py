from pathlib import Path
import hashlib
import json

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT=BASE/'r43-profile-cache-metadata-readonly-20261010-001'
meta=OUT/'CACHE-DIRECTORY-METADATA.actual.json'
print(json.dumps({'metadata_capture_completed':meta.is_file(),'R38_named_authors':[str(p) for p in BASE.iterdir() if p.is_file() and 'r38' in p.name.casefold() and p.suffix=='.py'],'R38_immediate_json':[p.name for p in (BASE/'live-attempt-038').iterdir() if p.is_file() and p.suffix=='.json']},ensure_ascii=False))
if meta.is_file():
    value=json.loads(meta.read_text(encoding='utf-8'))
    for profile in value['profiles']:
        print(json.dumps({'role':profile['role'],'directories':profile['immediate_directory_names'],'cache_stats':[{key:value for key,value in node.items() if key not in ('files','directories','skipped_nonregular')} for node in profile['cache_subtrees']]},ensure_ascii=False))
sources=[(Path('C:/workspace/ck3_eternal_recurrence/tools/ck3_mod_acceptance_cases/lyd_transaction_control_adapter.py'),[(69,132)]),(Path('C:/workspace/ck3_eternal_recurrence/tools/ck3_mod_acceptance_prepare.py'),[(10,55),(105,140),(150,184)])]
rows=[]
for path,ranges in sources:
    body=path.read_bytes()
    lines=body.decode('utf-8-sig').splitlines()
    row={'source':{'path':str(path),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()},'cuts':[{'first_line':lo,'last_line':hi,'lines':[{'line':n,'text':lines[n-1]} for n in range(lo,min(hi,len(lines))+1)]} for lo,hi in ranges]}
    rows.append(row)
    print(json.dumps(row,ensure_ascii=False))
with (OUT/'PUBLIC-PREPARE-SOURCE-CUTS.actual.json').open('x',encoding='utf-8',newline='\n') as stream:
    json.dump(rows,stream,ensure_ascii=False,indent=2)
    stream.write('\n')
