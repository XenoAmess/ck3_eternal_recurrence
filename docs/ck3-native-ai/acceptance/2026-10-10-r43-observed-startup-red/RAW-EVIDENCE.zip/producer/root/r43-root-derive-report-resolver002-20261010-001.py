from pathlib import Path
import hashlib
import json

b = Path('C:/workspace/ck3_lyd_runtime_20261004')
old = b / 'r43-root-resolve-shell-report-rebase-20261010-001.py'
new = b / 'r43-root-resolve-shell-report-rebase-20261010-002.py'
text = old.read_text(encoding='utf-8')
before = '    resolved = correction(remote)'
after = "    if remote.count(b'a stale Codex read-shell process PID22976') != 1:\n        raise RuntimeError('Unexpected concurrent historical wording')\n    normalized = remote.replace(b'a stale Codex read-shell process PID22976', b'a stale Codex PowerShell PID22976')\n    resolved = correction(normalized)"
if text.count(before) != 1:
    raise RuntimeError('Unexpected resolver source')
text = text.replace(before, after)
compile(text, str(new), 'exec')
with new.open('x', encoding='utf-8', newline='\n') as f:
    f.write(text)
with Path(__file__).with_suffix('.actual.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump({'original_sha256': hashlib.sha256(old.read_bytes()).hexdigest(),
               'derived_sha256': hashlib.sha256(new.read_bytes()).hexdigest(),
               'reason': 'Remote independently replaced the same historical shell label; preserve every remote append and replay the complete checked local wording correction.',
               'first_attempt_wrote_files': False}, f, indent=2)
    f.write('\n')
print(str(new))
