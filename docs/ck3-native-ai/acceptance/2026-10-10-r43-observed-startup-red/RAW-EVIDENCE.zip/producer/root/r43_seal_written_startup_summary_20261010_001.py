"""Seal a compact derivation of existing, finished observer samples only."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r43-written-startup-samples-readonly-20261010-001'

def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def check(ref):
    actual = pin(Path(ref['path']))
    assert actual == ref, (actual, ref)

def put(name, value):
    path = OUT / name
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    return pin(path)

snapshot_path = sorted(OUT.glob('snapshot-*.actual.json'))[-1]
snapshot = json.loads(snapshot_path.read_bytes())
assert snapshot['sample_count'] == 20
assert 'EXIT.actual.json' in snapshot['receipts']
for row in snapshot['samples']:
    check(row['source'])
for receipt in snapshot['receipts'].values():
    check(receipt['source'])
check(snapshot['producer'])
rows = snapshot['samples']
windows = []
for row in rows:
    state = row.get('windows') or {}
    for window in state.get('game_windows', []):
        if window.get('class') == 'SDL_app':
            windows.append({'index': row['index'], 'at_utc': row['at_utc'],
                'elapsed_seconds': row['elapsed_seconds'], 'window': window,
                'foreground_hwnd': state.get('foreground_hwnd'),
                'foreground_pid': state.get('foreground_pid'),
                'foreground_is_game': state.get('foreground_pid') == row['pid']})
cpu_rows = [row for row in rows if isinstance(row.get('cpu_one_core_percent_over_interval'), (int, float))]
last = rows[-1]
exit_receipt = snapshot['receipts']['EXIT.actual.json']
report = {'schema': 'ck3-r43-written-startup-final-metrics-v1',
    'sealed_at_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'EXISTING_SAMPLES_SUMMARIZED_INDEPENDENT_EXIT_1',
    'snapshot': pin(snapshot_path), 'sample_count': len(rows), 'sample_time_bounds_utc': snapshot['observation_time_bounds_utc'],
    'sample_elapsed_bounds_seconds': snapshot['sample_elapsed_bounds_seconds'],
    'identity': snapshot['receipts']['HANDLE-READY.actual.json'],
    'cpu_percent_convention': '100 percent equals one logical CPU core; this is not whole-machine utilization.',
    'cpu_interval_count': len(cpu_rows),
    'cpu_one_core_percent_range': snapshot['cpu_one_core_percent_range'],
    'zero_cpu_interval_count': sum(row['cpu_one_core_percent_over_interval'] == 0 for row in cpu_rows),
    'cpu_cumulative_delta_seconds': snapshot['observed_cpu_cumulative_delta_seconds'],
    'io_counter_deltas_first_to_last_sample': {k: last['io_counters'][k] - rows[0]['io_counters'][k] for k in last['io_counters']},
    'rss_bytes_range': snapshot['rss_bytes_range'], 'num_threads_range': snapshot['num_threads_range'],
    'last_sample': {k: last.get(k) for k in ['at_utc', 'elapsed_seconds', 'cpu_one_core_percent_over_interval',
        'io_deltas', 'num_threads', 'rss_bytes', 'system_memory', 'swap']},
    'sdl_game_window_observation_count': len(windows),
    'sdl_game_window_time_bounds_utc': [windows[0]['at_utc'], windows[-1]['at_utc']] if windows else [],
    'sdl_game_window_samples_visible': sum(row['window']['visible'] for row in windows),
    'sdl_game_window_samples_iconic': sum(row['window']['iconic'] for row in windows),
    'sdl_game_window_samples_foreground': sum(row['foreground_is_game'] for row in windows),
    'distinct_foreground_hwnd_pid_pairs': sorted({(row['foreground_hwnd'], row['foreground_pid']) for row in windows}),
    'first_sdl_game_window_observation': windows[0] if windows else None,
    'last_sdl_game_window_observation': windows[-1] if windows else None,
    'sample_error_count': snapshot['error_count'], 'pending_partial_json': snapshot['pending_partial_json'],
    'independent_observer_exit': exit_receipt,
    'last_cpu_sample_to_exit_gap_seconds': exit_receipt['value']['elapsed_seconds'] - last['elapsed_seconds'],
    'boundary': 'CPU/IO/window claims end at the last sampled instant. The later independent handle proves process exit code 1; it does not prove normal exit, business success, cleanup semantics or cause. No foreground/cause or deadlock inference.',
    'process_window_screen_api_calls': 0, 'signals': 0, 'new_sampling': False,
    'save_body_reads': 0, 'repo_writes': 0, 'business_pass': False}
ref = put('REPORT.actual.json', report)
index = put('INDEX.json', {'schema': 'ck3-existing-sample-derivation-index-v1', 'producer': pin(Path(__file__)),
    'files': [ref, pin(snapshot_path), snapshot['producer']],
    'raw_observer_inputs': [row['source'] for row in rows] + [value['source'] for value in snapshot['receipts'].values()],
    'input_pin_reverification': 'PASS',
    'interim_snapshots': 'Unchanged working derivations; final report binds only the latest complete snapshot and its exact producer.'})
print(json.dumps({'report': ref, 'index': index, 'cpu_interval_count': report['cpu_interval_count'],
    'cpu_range': report['cpu_one_core_percent_range'], 'zero_cpu_intervals': report['zero_cpu_interval_count'],
    'io_delta': report['io_counter_deltas_first_to_last_sample'],
    'sdl_window_count': len(windows), 'sdl_time_bounds': report['sdl_game_window_time_bounds_utc'],
    'sdl_visible': report['sdl_game_window_samples_visible'], 'sdl_iconic': report['sdl_game_window_samples_iconic'],
    'sdl_foreground': report['sdl_game_window_samples_foreground'],
    'foreground_pairs': report['distinct_foreground_hwnd_pid_pairs'],
    'last_cpu_to_exit_gap_seconds': report['last_cpu_sample_to_exit_gap_seconds']}, indent=2))
