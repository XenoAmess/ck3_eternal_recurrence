from pathlib import Path
from datetime import datetime, timezone
import json
import subprocess

root = Path('C:/workspace/ck3_eternal_recurrence')
paths = ['docs/autonomous-agent-progress/daily/2026-10-10.md', 'docs/autonomous-agent-progress/weekly/2026-W41.md', 'docs/testing-workflow.md']
paths += [row['path'] for row in json.loads(Path('C:/workspace/ck3_lyd_runtime_20261004/r43-root-apply-ci-candidate-20261010-001.actual.json').read_bytes())['applied']]
check = json.loads(Path('C:/workspace/ck3_lyd_runtime_20261004/r43-root-python-only-correction-check-20261010-001/RESULT.actual.json').read_bytes())
if check['exit_code'] != 0:
    raise RuntimeError('Required correction check has not passed')
staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=root, text=True).splitlines()
if staged:
    raise RuntimeError('Another owner has staged paths: ' + str(staged))
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
before = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
subprocess.run(['git', 'add', '--', *paths], cwd=root, check=True)
staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=root, text=True).splitlines()
if sorted(staged) != sorted(paths):
    raise RuntimeError('Unexpected commit scope: ' + str(staged))
subprocess.run(['git', 'commit', '-m', 'Correct prohibited shell references in concurrent progress reports'], cwd=root, check=True)
after = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
receipt = Path(__file__).with_suffix('.actual.json')
with receipt.open('x', encoding='utf-8', newline='\n') as f:
    json.dump({'at_utc': datetime.now(timezone.utc).isoformat(), 'parent': before, 'commit': after, 'paths': paths,
               'check_exit_code': 0, 'runtime_changed': False}, f, indent=2)
    f.write('\n')
print(json.dumps({'commit': after, 'receipt': str(receipt)}))
