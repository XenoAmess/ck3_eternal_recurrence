from pathlib import Path
import hashlib
import json
import subprocess

root = Path('C:/workspace/ck3_eternal_recurrence')
paths = ['docs/autonomous-agent-progress/daily/2026-10-10.md',
         'docs/autonomous-agent-progress/weekly/2026-W41.md', 'docs/testing-workflow.md']
rows = []
for rel in paths:
    p = root / rel
    before = p.read_bytes()
    text = before.decode('utf-8')
    old = 'a stale Codex PowerShell PID22976'
    old_command = 'Targeted command classification showed Get-Content and no listed'
    if text.count(old) != 1 or text.count(old_command) != 1:
        raise RuntimeError('Unexpected report text: ' + rel)
    text = text.replace(old, 'a stale Codex process from a prohibited historical read shell, PID22976')
    text = text.replace(old_command, 'Targeted command classification showed read-only file content inspection and no listed')
    after = text.encode('utf-8')
    p.write_bytes(after)
    rows.append({'path': rel, 'before_sha256': hashlib.sha256(before).hexdigest(),
                 'after_sha256': hashlib.sha256(after).hexdigest(), 'historical_pid_memory_cancellation_receipt_retained': True})
receipt = Path(__file__).with_suffix('.actual.json')
with receipt.open('x', encoding='utf-8', newline='\n') as f:
    json.dump({'exact_failed_ci_head': '6baf0b73ecad9bcf9940144093293b6a1d80de4d',
               'official_run': 38010875810, 'files': rows, 'validator_changed': False,
               'runtime_changed': False, 'old_failed_ci_retained': True}, f, indent=2)
    f.write('\n')
print(str(receipt))
