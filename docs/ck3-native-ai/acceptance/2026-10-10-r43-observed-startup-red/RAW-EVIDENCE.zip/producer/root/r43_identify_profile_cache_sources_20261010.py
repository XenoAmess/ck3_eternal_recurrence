from pathlib import Path
import hashlib
import json

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r43-profile-cache-metadata-readonly-20261010-001'
OUT.mkdir(exist_ok=False)
paths = [
    Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-004/prepared/profile-preparation.json'),
    Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-004/prepared/prepared-case.json'),
    Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-005/prepared/profile-preparation.json'),
    Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-005/prepared/prepared-case.json'),
    BASE / 'r39-r38-bootstrap-original-shape-readonly-20261010-001/ORIGINAL-EIGHT-PINS.actual.json',
    BASE / 'live-attempt-038/launch.json',
]
def leaves(value,path=()):
    if isinstance(value,dict):
        for key,item in value.items():
            yield from leaves(item,path+(str(key),))
    elif isinstance(value,list):
        for i,item in enumerate(value):
            yield from leaves(item,path+(str(i),))
    else:
        yield path,value
rows=[]
for path in paths:
    if not path.is_file():
        rows.append({'path':str(path),'exists':False})
        continue
    body=path.read_bytes()
    value=json.loads(body.decode('utf-8-sig'))
    selected=[]
    for location,item in leaves(value):
        combined='/'.join(location).lower()+(' '+item.lower() if isinstance(item,str) else '')
        if any(key in combined for key in ('profile','userdir','shader','cache','gfx','source','copy','launch','python','recorded_at','started_at')):
            selected.append({'json_path':'/'.join(location),'value':item})
    row={'source':{'path':str(path),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()},'top_keys':list(value) if isinstance(value,dict) else None,'selected':selected}
    rows.append(row)
    print(json.dumps(row,ensure_ascii=False))
with (OUT / 'PROFILE-PATHS-AND-PROVENANCE-INPUTS.actual.json').open('x',encoding='utf-8',newline='\n') as stream:
    json.dump(rows,stream,ensure_ascii=False,indent=2)
    stream.write('\n')
print(json.dumps({'R38_userdir_immediate_directories':[p.name for p in (BASE/'live-attempt-038/userdir').iterdir() if p.is_dir()]},ensure_ascii=False))
