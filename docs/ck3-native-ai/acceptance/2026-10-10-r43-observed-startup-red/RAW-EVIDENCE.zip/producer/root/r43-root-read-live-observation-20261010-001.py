from pathlib import Path
from datetime import datetime, timezone
import json

run = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0043')
out = run / 'startup-observer-001'
rows = []
for path in sorted(out.glob('sample-*.actual.json')):
    sample = json.loads(path.read_bytes())
    rows.append({k: sample.get(k) for k in ['index', 'at_utc', 'elapsed_seconds', 'cpu_one_core_percent_over_interval', 'memory_info', 'system_memory', 'num_threads', 'io_deltas', 'windows', 'errors']})
    rows[-1]['last_debug_lines'] = sample.get('debug_log_tail', '').splitlines()[-2:]
    rows[-1]['top_thread_cpu_deltas'] = sample.get('thread_cpu_deltas', [])[:3]
print(json.dumps({'at_utc': datetime.now(timezone.utc).isoformat(), 'samples': rows,
                  'exit': json.loads((out / 'EXIT.actual.json').read_bytes()) if (out / 'EXIT.actual.json').exists() else None}, ensure_ascii=False, indent=2))
