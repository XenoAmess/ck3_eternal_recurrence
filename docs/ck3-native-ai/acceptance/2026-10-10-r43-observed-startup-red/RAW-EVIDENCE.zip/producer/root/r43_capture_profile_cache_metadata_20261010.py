from pathlib import Path
from datetime import datetime, timezone
import json
import os
import stat
import time

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r43-profile-cache-metadata-readonly-20261010-001'
roots = {'R38':BASE/'live-attempt-038/userdir', 'C4':Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-004/state/profile'), 'C5':Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-005/state/profile')}

def utc(ns):
    return datetime.fromtimestamp(ns / 1_000_000_000, timezone.utc).isoformat()

def metadata(path):
    record = {'path':str(path)}
    try:
        value=path.stat(follow_symlinks=False)
    except OSError as error:
        record.update(exists=False,error=repr(error))
        return record
    record.update(exists=True,mtime_ns=value.st_mtime_ns,mtime_utc=utc(value.st_mtime_ns),creation_time_ns=getattr(value,'st_birthtime_ns',None))
    return record

start=time.time_ns()
rows=[]
for role,root in roots.items():
    immediate = list(root.iterdir())
    targets={name for name in ('shadercache','shader_cache','cache','gfx','gfxcache')}
    targets.update(path.name for path in immediate if path.is_dir() and any(key in path.name.casefold() for key in ('shader','cache','gfx')))
    record={'role':role,'profile':metadata(root),'immediate_directory_names':[path.name for path in immediate if path.is_dir()],'cache_subtrees':[]}
    for name in sorted(targets):
        target=root/name
        node={'name':name,'root':metadata(target),'files':[],'directories':[],'skipped_nonregular':[],'errors':[]}
        if node['root']['exists']:
            pending=[target]
            while pending:
                directory=pending.pop()
                try:
                    children=list(os.scandir(directory))
                except OSError as error:
                    node['errors'].append({'path':str(directory),'error':repr(error)})
                    continue
                for child in children:
                    path=Path(child.path)
                    try:
                        value=child.stat(follow_symlinks=False)
                        row={'relative_path':str(path.relative_to(target)),'bytes':value.st_size,'mtime_ns':value.st_mtime_ns,'mtime_utc':utc(value.st_mtime_ns),'creation_time_ns':getattr(value,'st_birthtime_ns',None)}
                        if stat.S_ISDIR(value.st_mode) and not child.is_symlink():
                            node['directories'].append(row)
                            pending.append(path)
                        elif stat.S_ISREG(value.st_mode):
                            node['files'].append(row)
                        else:
                            node['skipped_nonregular'].append(row)
                    except OSError as error:
                        node['errors'].append({'path':str(path),'error':repr(error)})
        node['file_count']=len(node['files'])
        node['total_file_bytes']=sum(row['bytes'] for row in node['files'])
        times=[row['mtime_ns'] for row in node['files']]
        node['file_mtime_min_ns']=min(times) if times else None
        node['file_mtime_max_ns']=max(times) if times else None
        node['file_mtime_min_utc']=utc(min(times)) if times else None
        node['file_mtime_max_utc']=utc(max(times)) if times else None
        record['cache_subtrees'].append(node)
    rows.append(record)
end=time.time_ns()
result={'schema':'lyd.r43.profile-cache-directory-metadata.v1','started_at_utc':utc(start),'finished_at_utc':utc(end),'scope':'Only immediate cache/shader/gfx-named subtrees of three exact profile roots; metadata only, no content open/hash. C5 is live so snapshot is not atomic and is not pre-launch inventory.','profiles':rows,'cache_body_reads':0,'cache_body_hashes':0,'save_body_reads':0,'runtime_actions':0}
with (OUT/'CACHE-DIRECTORY-METADATA.actual.json').open('x',encoding='utf-8',newline='\n') as stream:
    json.dump(result,stream,ensure_ascii=False,indent=2)
    stream.write('\n')
for record in rows:
    print(json.dumps({'role':record['role'],'profile':record['profile']['path'],'immediate_directory_names':record['immediate_directory_names'],'caches':[{key:value for key,value in node.items() if key not in ('files','directories','skipped_nonregular')} for node in record['cache_subtrees']]},ensure_ascii=False))
print(json.dumps({'R38_immediate_metadata_filenames':[path.name for path in (BASE/'live-attempt-038').iterdir() if path.is_file() and path.suffix in ('.json','.py')],'R38_named_base_authors':[path.name for path in BASE.iterdir() if path.is_file() and 'r38' in path.name.casefold() and path.suffix=='.py']},ensure_ascii=False))
