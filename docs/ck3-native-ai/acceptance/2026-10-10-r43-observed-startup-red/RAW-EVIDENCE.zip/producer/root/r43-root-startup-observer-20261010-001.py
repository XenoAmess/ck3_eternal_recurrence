"""Bounded external observation only; no signals, focus, input, or injection."""
from pathlib import Path
from datetime import datetime, timezone
import ctypes
from ctypes import wintypes
import hashlib
import json
import time
import psutil
import win32api
import win32con
import win32event
import win32gui
import win32process
import pyautogui

run = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0043')
profile = Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-005/state/profile')
expected_profile = '-userdir=' + str(profile)
out = run / 'startup-observer-001'
out.mkdir(exist_ok=False)

def utc():
    return datetime.now(timezone.utc).isoformat()

def put(name, value):
    with (out / name).open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

def windows(pid):
    rows = []
    def accept(hwnd, extra):
        thread, owner = win32process.GetWindowThreadProcessId(hwnd)
        if owner == pid:
            rows.append({'hwnd': hwnd, 'thread_id': thread, 'title': win32gui.GetWindowText(hwnd),
                         'class': win32gui.GetClassName(hwnd), 'visible': bool(win32gui.IsWindowVisible(hwnd)),
                         'iconic': bool(win32gui.IsIconic(hwnd)), 'rect': list(win32gui.GetWindowRect(hwnd))})
    win32gui.EnumWindows(accept, None)
    foreground = win32gui.GetForegroundWindow()
    return {'game_windows': rows, 'foreground_hwnd': foreground,
            'foreground_pid': win32process.GetWindowThreadProcessId(foreground)[1] if foreground else None}

def game_candidates():
    return [p for p in psutil.process_iter(['name']) if (p.info['name'] or '').lower() == 'ck3.exe']

existing = game_candidates()
if existing:
    raise RuntimeError('Observer refuses pre-existing CK3: ' + str([p.pid for p in existing]))
put('ARMED.actual.json', {'at_utc': utc(), 'expected_profile': expected_profile,
    'discovery_budget_seconds': 120, 'observation_budget_seconds': 900, 'sample_interval_seconds': 30,
    'system_memory': psutil.virtual_memory()._asdict(), 'swap': psutil.swap_memory()._asdict(),
    'signals_sent': False, 'foreground_changes_requested': False, 'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
deadline = time.monotonic() + 120
original = None
while time.monotonic() < deadline:
    candidates = game_candidates()
    for p in candidates:
        try:
            argv = p.cmdline()
        except psutil.NoSuchProcess:
            continue
        if argv.count(expected_profile) == 1:
            if original is not None or len(candidates) != 1:
                raise RuntimeError('Multiple CK3 candidates')
            original = p
    if original is not None:
        break
    time.sleep(0.25)
if original is None:
    put('DISCOVERY-MISS.actual.json', {'at_utc': utc(), 'expected_profile': expected_profile, 'signals_sent': False})
    raise RuntimeError('No matching CK3 within discovery budget')
identity = original.as_dict(attrs=['pid', 'name', 'exe', 'cmdline', 'create_time'])
if identity['cmdline'].count('-debug_mode') != 1 or identity['cmdline'].count('-loadsave=restored_campaign') != 1:
    raise RuntimeError('Unexpected CK3 argv')
handle = win32api.OpenProcess(win32con.SYNCHRONIZE | win32con.PROCESS_QUERY_LIMITED_INFORMATION, False, original.pid)
try:
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(wintypes.FILETIME)] * 4)]
    kernel.GetProcessTimes.restype = wintypes.BOOL
    stamps = [wintypes.FILETIME() for _ in range(4)]
    if not kernel.GetProcessTimes(int(handle), *[ctypes.byref(s) for s in stamps]):
        raise ctypes.WinError(ctypes.get_last_error())
    ticks = (stamps[0].dwHighDateTime << 32) | stamps[0].dwLowDateTime
    delta = ticks - round((identity['create_time'] + 11644473600) * 10000000)
    if abs(delta) > 32 or original.create_time() != identity['create_time']:
        raise RuntimeError('Live handle identity mismatch')
    put('HANDLE-READY.actual.json', {'at_utc': utc(), 'process': identity, 'creation_filetime_100ns': ticks,
        'psutil_to_raw_filetime_delta_100ns': delta, 'independent_observer_handle': True,
        'original_createprocess_handle': False, 'rights': ['SYNCHRONIZE', 'PROCESS_QUERY_LIMITED_INFORMATION']})
    start = time.monotonic()
    next_sample = start
    previous = None
    index = 0
    screenshots = {1, 7, 17}
    while time.monotonic() - start < 900:
        wait = win32event.WaitForSingleObject(handle, 250)
        if wait == win32event.WAIT_OBJECT_0:
            put('EXIT.actual.json', {'at_utc': utc(), 'elapsed_seconds': time.monotonic() - start,
                'pid': identity['pid'], 'process_create_time': identity['create_time'], 'wait_result': wait,
                'actual_exit_code': win32process.GetExitCodeProcess(handle), 'independent_observer_handle': True,
                'original_createprocess_handle': False, 'signals_sent': False, 'business_pass': False})
            print(json.dumps({'observed_exit': True, 'out': str(out)}))
            break
        if wait != win32event.WAIT_TIMEOUT:
            raise RuntimeError('Unexpected process wait: ' + str(wait))
        now = time.monotonic()
        if now < next_sample:
            continue
        index += 1
        sample = {'at_utc': utc(), 'elapsed_seconds': now - start, 'index': index,
                  'pid': identity['pid'], 'errors': [], 'signals_sent': False}
        try:
            if original.create_time() != identity['create_time'] or original.cmdline() != identity['cmdline']:
                raise RuntimeError('Process identity changed')
            sample['cpu_times'] = original.cpu_times()._asdict()
            sample['io_counters'] = original.io_counters()._asdict()
            sample['memory_info'] = original.memory_info()._asdict()
            sample['threads'] = [t._asdict() for t in original.threads()]
            sample['num_threads'] = original.num_threads()
            sample['status'] = original.status()
            sample['system_memory'] = psutil.virtual_memory()._asdict()
            sample['swap'] = psutil.swap_memory()._asdict()
            if previous is not None:
                elapsed = now - previous['monotonic']
                cpu = sample['cpu_times']['user'] + sample['cpu_times']['system']
                old_cpu = previous['cpu_times']['user'] + previous['cpu_times']['system']
                sample['cpu_one_core_percent_over_interval'] = 100 * (cpu - old_cpu) / elapsed
                sample['io_deltas'] = {k: v - previous['io_counters'][k] for k, v in sample['io_counters'].items()}
                old_threads = {t['id']: t for t in previous['threads']}
                sample['thread_cpu_deltas'] = sorted([
                    {'id': t['id'], 'seconds': t['user_time'] + t['system_time'] - old_threads[t['id']]['user_time'] - old_threads[t['id']]['system_time']}
                    for t in sample['threads'] if t['id'] in old_threads], key=lambda t: t['seconds'], reverse=True)
            previous = {**sample, 'monotonic': now}
            sample['windows'] = windows(original.pid)
        except Exception as exc:
            sample['errors'].append({'type': type(exc).__name__, 'message': str(exc)})
        debug = profile / 'logs/debug.log'
        if debug.is_file():
            with debug.open('rb') as f:
                f.seek(max(0, debug.stat().st_size - 2500))
                tail = f.read(2500)
            sample['debug_log_size'] = debug.stat().st_size
            sample['debug_log_tail'] = tail.decode('utf-8', errors='replace')
        if index in screenshots:
            try:
                image_path = out / f'desktop-{index:03d}.png'
                shot = pyautogui.screenshot()
                shot.save(image_path)
                sample['desktop_image'] = {'path': str(image_path), 'size': list(shot.size),
                    'bytes': image_path.stat().st_size, 'sha256': hashlib.sha256(image_path.read_bytes()).hexdigest(),
                    'business_state_inferred': False, 'focus_or_input_requested': False}
            except Exception as exc:
                sample['errors'].append({'screenshot_error': type(exc).__name__ + ': ' + str(exc)})
        put(f'sample-{index:03d}.actual.json', sample)
        next_sample = now + 30
    else:
        put('OBSERVATION-LIMIT.actual.json', {'at_utc': utc(), 'pid': identity['pid'], 'limit_seconds': 900,
            'signals_sent': False, 'process_exit_observed': False})
        raise RuntimeError('Observer bound reached; process untouched')
finally:
    win32api.CloseHandle(handle)
