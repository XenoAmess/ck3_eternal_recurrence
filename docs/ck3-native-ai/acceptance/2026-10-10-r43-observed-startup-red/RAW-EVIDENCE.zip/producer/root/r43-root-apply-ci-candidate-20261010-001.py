from pathlib import Path
import hashlib
import json
import shutil

b = Path('C:/workspace/ck3_lyd_runtime_20261004')
root = Path('C:/workspace/ck3_eternal_recurrence')
candidate = b / 'r43-concurrent-report-python-only-correction-package-20261010-001/candidate'
files = sorted(p for p in candidate.rglob('*') if p.is_file())
if len(files) != 5:
    raise RuntimeError('Expected five accepted candidate files')
if any((root / p.relative_to(candidate)).exists() for p in files):
    raise RuntimeError('Candidate target already exists')
rows = []
for source in files:
    target = root / source.relative_to(candidate)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    raw = source.read_bytes()
    if target.read_bytes() != raw:
        raise RuntimeError('Apply bytes differ')
    rows.append({'path': str(target.relative_to(root)).replace('\\', '/'), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
receipt = Path(__file__).with_suffix('.actual.json')
with receipt.open('x', encoding='utf-8', newline='\n') as f:
    json.dump({'applied': rows, 'candidate_validation_reused': True, 'tests_repeated': False}, f, indent=2)
    f.write('\n')
print(json.dumps({'applied': len(rows), 'receipt': str(receipt)}))
