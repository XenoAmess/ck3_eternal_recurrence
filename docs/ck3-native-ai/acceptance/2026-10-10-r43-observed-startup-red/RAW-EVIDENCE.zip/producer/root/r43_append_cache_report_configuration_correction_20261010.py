from pathlib import Path
import hashlib
import json

BASE=Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT=BASE/'r43-profile-cache-metadata-readonly-20261010-001'
def ref(path):
    body=path.read_bytes()
    return {'path':str(path),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
def write_json(name,value):
    path=OUT/name
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2)
        stream.write('\n')
    return ref(path)
source=BASE/'r38-root-materialize-transaction-only-cold-20261009-001.py'
lines=source.read_text(encoding='utf-8-sig').splitlines()
if lines[32].strip()!='assert not RUN.exists()' or "('pdx_settings.txt', 'dlc_load.json', 'tutorial.txt')" not in lines[70]:
    raise ValueError('Original R38 source configuration/new-root facts differ')
receipt=BASE/'live-attempt-038/COLD-MATERIALIZED.json'
rows=json.loads(receipt.read_text(encoding='utf-8-sig'))['settings']
if len(rows)!=3:raise ValueError('R38 settings receipt count differs')
old=OUT/'REPORT.zh.md'
text=old.read_text(encoding='utf-8')
replacements={
    '67–86行仅新建 userdir、复制四项配置':'33行要求新RUN，67–86行仅新建 userdir、复制三个普通文件（pdx_settings.txt、dlc_load.json、tutorial.txt；来源为live-attempt-031/userdir）',
    '54–65行复制的是声明的 mod 源目录到 mounted 内容':'54–65行复制的是声明的 mod 源目录到 RUN/content/<role>',
    '原 COLD-MATERIALIZED.json 的 settings 四项来源 pin':'原 COLD-MATERIALIZED.json 的 settings 三项来源 pin',
}
for before,after in replacements.items():
    if text.count(before)!=1:raise ValueError('Report correction target differs')
    text=text.replace(before,after)
new=OUT/'REPORT.corrected.zh.md'
with new.open('x',encoding='utf-8',newline='\n') as stream:stream.write(text)
correction=write_json('CONFIGURATION-COUNT-CORRECTION.actual.json',{'schema':'lyd.r43.cache-metadata-report.correction.v1','original_report':ref(old),'corrected_report':ref(new),'source':ref(source),'source_lines':[{'line':n,'text':lines[n-1]} for n in (9,33,59,67,68,69,70,71,72,73,74,75,76)],'materialized_receipt':ref(receipt),'R38_actual_settings_count':3,'R38_settings_sources':rows,'public_plain_configuration_count':4,'reason':'Initial report incorrectly called the three R38 copied ordinary files four configurations and called RUN/content mounted content; original receipt/source show the exact counts/paths. No metadata recapture and no cache/seed read.','cache_conclusion_changed':False})
index=write_json('INDEX.append.json',{'schema':'lyd.r43.cache-metadata-report.append-index.v1','original_index':ref(OUT/'INDEX.json'),'primary_report':ref(new),'correction':correction,'author':ref(Path(__file__)),'originals_preserved':True})
print(json.dumps({'primary_report':ref(new),'correction':correction,'append_index':index},ensure_ascii=False,indent=2))
