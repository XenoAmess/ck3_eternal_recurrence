version="0.1.0"
tags={ "Religion" "Decisions" "1.20 'Crozier'" }
name="礼与道：儒家礼仪与学统 / Rites and the Way"
supported_version="1.20.*"
path="C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-005/state/profile/mod-content/product"
