# R43：R38 / C4 / C5 profile 缓存元数据

仅对三个确切 userdir/profile 的 shader/cache/gfx 命名子树作一次目录与 stat 遍历；没有读取或 hash 缓存内容，没有读 seed、查询 SDK、操作进程/游戏或修改主仓。记录为 UTC。C5 正在运行，遍历非原子，计数只代表本次采样，不是启动前或最终状态。

| Profile | shadercache 文件数 | 总字节 | 文件 mtime 范围（UTC） |
| --- | ---: | ---: | --- |
| R38 | 3,740 | 146,942,067 | 2026-10-09 13:22:36.414433 → 13:30:47.037419 |
| 失败 C4 | 3,691 | 143,593,997 | 2026-10-10 00:11:29.281404 → 00:21:26.294211 |
| 运行中 C5 | 1,900 | 42,659,717 | 2026-10-10 02:20:33.999200 → 02:25:56.829131 |

三者 `shadercache` 存在，`cache`、`gfx`、`gfxcache`、`shader_cache` 均不存在。逐文件名称、大小、mtime/creation 元数据保存在 CACHE-DIRECTORY-METADATA.actual.json，没有内容 hash。

R38 原 launch.json 的实际启动为 2026-10-09 13:22:33.852741Z；shadercache 目录 creation/mtime 为13:22:36.414433Z，全部 retained 文件 mtime 都在启动后。原 `r38-root-materialize-transaction-only-cold-20261009-001.py` 要求新 RUN，67–86行仅新建 userdir、复制四项配置、外层 mod registrations 与 seed；54–65行复制的是声明的 mod 源目录到 mounted 内容，不是旧 userdir shadercache。原 COLD-MATERIALIZED.json 的 settings 四项来源 pin 完整保留，没有 shadercache 复制声明。这些事实不支持 R38 启动前复用了既有热 profile 缓存。

公共 C4/C5 的 pinned 产品 prepare_case（69–123行）要求新 state/profile，复制四项 plain_configuration、正式 product 和 overlay 的逐项声明文件、生成 mod/dlc_load 与 preparation。两份实际 profile-preparation.json 的顶层准备输入均无 shadercache/cache/gfx。配置可来自 R38 的普通配置文件，这不等于复制其 shadercache。原 helper 的 checked_copy 只复制显式文件；generic restore_prepared_profile 虽能恢复既有 before-launch inventory，但此 case 的 prepare_case 没有走该分支。

可区分的结论是：两条已读准备路径均没有继承 profile shadercache；R38 的现存缓存是在其启动后生成。不能由目录数量证明实际 shader 编译成功、命中率或具体加载等待点；未检查 engine 安装目录、Windows、GPU 驱动或其他全局缓存。因此“R38 热、公共必冷”的 profile 差异没有证据，R43 加载原因仍 UNKNOWN。本包不复制缓存、不增 flag、不安排启动，也不建议延长预算。
