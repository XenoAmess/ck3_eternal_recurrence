from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

base = Path('C:/lci39maxlink1')
exe = base / 'xar_ck3_12002_army_test.exe'
sha = hashlib.sha256(exe.read_bytes()).hexdigest()
if sha != 'd85132366874044524eaee6b07431bc6bcfdcf41877fabd711eebd5fe7725243':
    raise SystemExit('Previously compiled fixture EXE changed')
original_path = base / 'army-reader-ci-result.json'
original_raw = original_path.read_bytes()
original = json.loads(original_raw)
if original.get('build_status') != 'build_succeeded':
    raise SystemExit('Original isolated helper did not compile/link successfully')
if original.get('defender_exclusions', {}).get('status') != 'settings_failed':
    raise SystemExit('Unexpected original failure, refusing inferred continuation')
out = base / 'fixture-followup'
out.mkdir(exist_ok=False)
started = datetime.now(timezone.utc).isoformat()
result = subprocess.run([str(exe)], cwd=base, capture_output=True, timeout=60)
(out / 'army-fixtures.stdout.bin').write_bytes(result.stdout)
(out / 'army-fixtures.stderr.bin').write_bytes(result.stderr)
report = {
    'schema': 'xar.native.army-fixture-followup.v1',
    'status': 'passed' if result.returncode == 0 else 'failed',
    'started_at_utc': started,
    'finished_at_utc': datetime.now(timezone.utc).isoformat(),
    'argv': [str(exe)],
    'exit_code': result.returncode,
    'executable_sha256': sha,
    'original_result_sha256': hashlib.sha256(original_raw).hexdigest(),
    'original_result_unchanged': original_path.read_bytes() == original_raw,
    'original_helper_status': original['status'],
    'defender_registration_status': 'settings_failed_unresolved',
    'local_ck3_contacted': False,
    'private_feature_definitions': original['private_feature_definitions'],
}
(out / 'RESULT.actual.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
print(result.stdout.decode('utf-8', errors='replace'))
print(result.stderr.decode('utf-8', errors='replace'))
raise SystemExit(result.returncode)
