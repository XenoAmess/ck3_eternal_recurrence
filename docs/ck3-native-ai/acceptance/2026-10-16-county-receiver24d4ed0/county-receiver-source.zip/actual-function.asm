; machine_id: desktop-3fevhd2-1c74096080
; actual1.20.0.4 98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518
024D4ED0 40 53                            push     rbx
024D4ED2 48 83 ec 20                      sub      rsp, 0x20
024D4ED6 81 b9 e0 03 00 00 61 44 6f 43    cmp      dword ptr [rcx + 0x3e0], 0x436f4461
024D4EE0 48 8b d9                         mov      rbx, rcx
024D4EE3 0f 85 9a 00 00 00                jne      0x24d4f83
024D4EE9 48 8b 41 20                      mov      rax, qword ptr [rcx + 0x20]
024D4EED 81 b8 5c 08 00 00 76 6f 72 50    cmp      dword ptr [rax + 0x85c], 0x50726f76
024D4EF7 0f 85 86 00 00 00                jne      0x24d4f83
024D4EFD e8 1e fe ff ff                   call     0x24d4d20
024D4F02 81 78 1c 72 61 68 43             cmp      dword ptr [rax + 0x1c], 0x43686172
024D4F09 75 06                            jne      0x24d4f11
024D4F0B 83 78 18 ff                      cmp      dword ptr [rax + 0x18], -1
024D4F0F 75 79                            jne      0x24d4f8a
024D4F11 48 8b 05 e0 8b 84 03             mov      rax, qword ptr [rip + 0x3848be0]
024D4F18 48 85 c0                         test     rax, rax
024D4F1B 74 26                            je       0x24d4f43
024D4F1D 8b 53 18                         mov      edx, dword ptr [rbx + 0x18]
024D4F20 8b ca                            mov      ecx, edx
024D4F22 81 e1 ff ff ff 00                and      ecx, 0xffffff
024D4F28 3b 48 2c                         cmp      ecx, dword ptr [rax + 0x2c]
024D4F2B 73 16                            jae      0x24d4f43
024D4F2D 48 8b 40 20                      mov      rax, qword ptr [rax + 0x20]
024D4F31 48 03 c9                         add      rcx, rcx
024D4F34 48 8b 44 c8 08                   mov      rax, qword ptr [rax + rcx*8 + 8]
024D4F39 48 85 c0                         test     rax, rax
024D4F3C 74 05                            je       0x24d4f43
024D4F3E 39 50 10                         cmp      dword ptr [rax + 0x10], edx
024D4F41 74 07                            je       0x24d4f4a
024D4F43 48 8b 05 96 8b 84 03             mov      rax, qword ptr [rip + 0x3848b96]
024D4F4A 48 8b 15 17 26 79 03             mov      rdx, qword ptr [rip + 0x3792617]
024D4F51 48 85 d2                         test     rdx, rdx
024D4F54 74 2d                            je       0x24d4f83
024D4F56 44 8b 80 28 01 00 00             mov      r8d, dword ptr [rax + 0x128]
024D4F5D 41 8b c0                         mov      eax, r8d
024D4F60 25 ff ff ff 00                   and      eax, 0xffffff
024D4F65 3b 42 2c                         cmp      eax, dword ptr [rdx + 0x2c]
024D4F68 73 19                            jae      0x24d4f83
024D4F6A 8b c8                            mov      ecx, eax
024D4F6C 48 8b 42 20                      mov      rax, qword ptr [rdx + 0x20]
024D4F70 48 03 c9                         add      rcx, rcx
024D4F73 48 8b 44 c8 08                   mov      rax, qword ptr [rax + rcx*8 + 8]
024D4F78 48 85 c0                         test     rax, rax
024D4F7B 74 06                            je       0x24d4f83
024D4F7D 44 39 40 18                      cmp      dword ptr [rax + 0x18], r8d
024D4F81 74 07                            je       0x24d4f8a
024D4F83 48 8b 05 e6 25 79 03             mov      rax, qword ptr [rip + 0x37925e6]
024D4F8A 48 83 c4 20                      add      rsp, 0x20
024D4F8E 5b                               pop      rbx
024D4F8F c3                               ret      
