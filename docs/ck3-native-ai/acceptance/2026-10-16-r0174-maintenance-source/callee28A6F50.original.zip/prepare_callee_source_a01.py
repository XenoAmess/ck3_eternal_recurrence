"""Freeze the direct Character callee scope and run the normal offline plan check."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import shutil
import subprocess
import sys

R=Path(__file__).resolve().parent
REPO=Path('D:/workspace/ck3_eternal_recurrence')
BASE=Path('C:/ck3-e04-resume-20261015-a01')
PARENT=BASE/'maintenance-parent-r0174-a01'
SHA='98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518'
def require(ok,message):
    if not ok:raise RuntimeError(message)
def fresh(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def main():
    require(not (R/'plan-a01.json').exists(),'Use a new append-only plan attempt')
    sys.path.insert(0,str(REPO))
    from tools.ck3_live_run_id import current_machine_id
    machine=current_machine_id()
    inputs=R/'inputs';inputs.mkdir(exist_ok=False)
    mapping=[('frozen-identity',BASE/'frozen-game-12004/IDENTITY.actual.json','exact-build'),
             ('pe-layout-reused',PARENT/'parent28F7939-source-a01/inputs/pe-layout-reused.json','exact-build'),
             ('parent-direct-call',PARENT/'parent28F7939-source-a01/source-read-a06/final_extension_branch.asm','source-contract')]
    evidence=[]
    for name,path,layer in mapping:
        raw=path.read_bytes();suffix='.asm' if path.suffix=='.asm' else '.json'
        dest=inputs/(name+suffix)
        with dest.open('xb') as f:f.write(raw)
        evidence.append(dict(id=name,layer=layer,path='inputs/'+dest.name,sha256=hashlib.sha256(raw).hexdigest(),exe_sha256=SHA,
            supports='Frozen exact .4 identity/layout reuse' if layer=='exact-build' else 'Decoded actual parent28F7840 same-function branch:28F7BD7 mov rcx,rbp;28F7BDA direct call28A6F50. RBP is actual Character by parent source; no producer claim.'))
    identity=json.loads((inputs/'frozen-identity.json').read_bytes())
    require(identity['machine_id']==machine and identity['sha256']==SHA and identity['bytes']==101040248,'Exact identity or source machine mismatch')
    parent_asm=(inputs/'parent-direct-call.asm').read_text(encoding='utf-8')
    require('028F7BD7' in parent_asm and 'mov rcx, rbp' in parent_asm and '028F7BDA' in parent_asm and 'call 0x1428a6f50' in parent_asm,'Named exact direct-call source absent')
    old=json.loads((PARENT/'grandparent3978BF8-source-a01/plan-a01.json').read_bytes())
    plan=dict(schema=old['schema'],topic='e04-12004-R0174-direct-Character-callee28A6F50',
        question='Does actual parent direct callee28A6F50, passed RCX=RBP=Character, write the secondary context four raw terms or pass a source-qualified context?',
        purpose='engine-transition',build=dict(version='1.20.0.4 / Steam25734779',exe_sha256=SHA),machine_id=machine,
        created_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        observation=dict(mode='offline-only',actor_kind='engine',
            owner_scope='Only actual direct callee28A6F50 from parent28F7BDA, RCX=actual Character; secondary context is not assumed to be a cache.',
            identity_kind='generation-id',identity_lifetime='Frozen exact .4 source identity; no new runtime or cross-session identity claim.',
            producer_trigger='not-applicable',producer='Unknown; investigate concrete stores/typed context inside one actual reached function only.',
            caller='Complete actual parent28F7840..28F7C9E:28F7BD7 mov rcx,rbp;28F7BDA call28A6F50.',
            consumer='Generic settlement reads *(Character+1C0) terms2C0/2C8/28/30; amount relationship already known, term semantics unclosed.',
            cache_lifetime='Unknown; no cache role, refresh epoch or cadence is presumed from this callee name/direction.',
            expected_signal='Explicit store/operation at secondarycontext+2C0/2C8/28/30, or concrete context argument propagation;3E8/3F0/4A0 are different fields.',
            zero_sample_meaning='No direct term store in the fully bounded body does not exclude unexamined callees or other producers; no live sample or zero maintenance conclusion.',
            stop_condition='Normal offline check first. Only target28A6F50 .pdata metadata<=512B/code<=8192/read<=48 cumulatively. Same-function CHAININFO/root/reached branch/fallthrough may be amended and read within totals; no new getter/random callee/global xref/neighbor scan.',
            runtime_window_ref='No new runtime. Prior R0174 actual source direction only; source read deadline2026-10-16T07:45:01.597Z.'),
        read_budget=dict(target_entry_rva='0x28A6F50',metadata_lookup_PC='0x28A6F50',actual_parent_call_rva='0x28F7BDA',
            new_EXE_code_bytes_max=8192,new_EXE_metadata_bytes_max=512,new_EXE_read_calls_max=48,
            source_body_count_max=1,transitive_callee_reads=False,whole_EXE_hashes_or_global_scans=0,
            report_bytes_max=1048576,new_lane_total_bytes_max=8388608,shared_root_reservation_bytes=536870912,
            deadline_utc='2026-10-16T07:45:01.597Z'),evidence=evidence,
        nodes=[dict(id='parent',label='Actual parent direct caller'),dict(id='callee',label='Character callee28A6F50'),dict(id='terms',label='Four raw secondary-context terms')],
        edges=[dict(id='actual-direct-call',**{'from':'parent','to':'callee'},label='28F7BDA direct call with RCX=Character',status='static-confirmed',evidence=['parent-direct-call']),
            dict(id='term-production',**{'from':'callee','to':'terms'},label='Producer/context edge awaiting same-function source',status='unknown',evidence=['parent-direct-call'],open_question='Explicit secondarycontext provenance and stores only; transitive callee effects not assumed')],
        cases=[dict(id='actual-callee-body',question='What is the exact metadata-selected body and context/field flow?',status='pending',evidence=[]),
               dict(id='four-term-stores',question='Are stores to the four actual raw fields source-proved here?',status='pending',evidence=[])],
        open_kaishek=dict(status='not-applicable',reason='Exact finite native instruction research, no Paradox script or runtime execution.'))
    planpath=R/'plan-a01.json';fresh(planpath,plan)
    disk=shutil.disk_usage(R)
    fresh(R/'STORAGE-START.actual.json',dict(schema='xar.e04.source-sub-lane-storage.v1',machine_id=machine,observed_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        policy='docs/storage-retention-policy.json v1.0.0',checkpoint='task_start',root=str(R),volume_total_bytes=disk.total,available_bytes=disk.free,
        this_lane_peak_bytes=8388608,parent_shared_reservation_bytes=536870912,heavy_write=False,
        parent_capacity_receipt='awaiting parent pointer; no claim of independent atomic reservation',
        protected_reason='Active exact source input/analysis for unresolved four-term producer question',review_by_utc='2026-10-22T07:45:01.597Z'))
    argv=[sys.executable,'-B',str(REPO/'tools/native_research_plan.py'),'check',str(planpath)]
    run=subprocess.run(argv,capture_output=True,check=False)
    for label,raw in [('stdout',run.stdout),('stderr',run.stderr)]:
        with (R/('PLAN-A01-CHECK.'+label+'.bin')).open('xb') as f:f.write(raw)
    fresh(R/'PLAN-A01-CHECK.actual.json',dict(machine_id=machine,observed_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),argv=argv,returncode=run.returncode,
        plan_sha256=hashlib.sha256(planpath.read_bytes()).hexdigest(),offline_normal_check=True,for_observation=False,new_EXE_reads=0))
    require(run.returncode==0,'Normal offline native_research_plan check rejected; no EXE read')
    print(json.dumps(dict(status='PLAN_CHECK_PASS',machine_id=machine,plan=str(planpath),plan_sha256=hashlib.sha256(planpath.read_bytes()).hexdigest(),new_EXE_reads=0)))
if __name__=='__main__':main()
