from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess
import sys
R=Path(__file__).resolve().parent
def require(ok,message):
    if not ok:raise RuntimeError(message)
def fresh(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def main():
    old=R/'plan-a01.json';plan=json.loads(old.read_bytes());receipt=R/'source-read-a01/READ-RECEIPT.actual.json'
    result=json.loads(receipt.read_bytes());function=result['function']
    require(function['begin_rva']==0x28A6F50 and function['end_rva']==0x28A6F65,'Actual entry span changed')
    require(function['direct_control_transfers']==[dict(at_rva=0x28A6F63,at_rva_hex='0x28a6f63',kind='je',target_rva=0x28A6FB8,target_rva_hex='0x28a6fb8')],'Exact reached branch differs')
    plan['created_utc']=dt.datetime.now(dt.timezone.utc).isoformat()
    plan['prior_plan']=dict(path=old.name,sha256=hashlib.sha256(old.read_bytes()).hexdigest())
    plan['amendment_reason']='Actual21B root ends in JE28A6FB8 with fallthrough28A6F65, not return; follow only reached pieces and prove same-function CHAININFO/root before body reads.'
    plan['observation']['stop_condition']='Cumulative whole lane code<=8192B metadata<=512B reads<=48. Read only reached PCs28A6F65/28A6FB8 .pdata and explicit CHAININFO back to actual root28A6F50..28A6F65; then those declared same-function pieces. No transitive callees/getters/global xrefs/neighborhoods.'
    plan['read_budget'].update(target_piece_PCs=['0x28A6F65','0x28A6FB8'],prior_receipts=['source-read-a01/READ-RECEIPT.actual.json'],
        actual_root_runtime_function=[function['begin_rva'],function['end_rva'],function['unwind_rva']])
    plan['evidence'].append(dict(id='actual-root-source',layer='source-contract',path='source-read-a01/READ-RECEIPT.actual.json',
        sha256=hashlib.sha256(receipt.read_bytes()).hexdigest(),exe_sha256=plan['build']['exe_sha256'],
        supports='Actual decoded root reads Character+1B8 then branches JE28A6FB8/fallthrough28A6F65; no term store yet and no whole-function conclusion.'))
    path=R/'plan-a02.json';fresh(path,plan)
    argv=[sys.executable,'-B','D:/workspace/ck3_eternal_recurrence/tools/native_research_plan.py','check',str(path)]
    run=subprocess.run(argv,capture_output=True,check=False)
    for label,raw in [('stdout',run.stdout),('stderr',run.stderr)]:
        with (R/('PLAN-A02-CHECK.'+label+'.bin')).open('xb') as f:f.write(raw)
    fresh(R/'PLAN-A02-CHECK.actual.json',dict(machine_id=plan['machine_id'],observed_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),argv=argv,returncode=run.returncode,
        plan_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),offline_normal_check=True,for_observation=False,new_EXE_reads=0))
    capacity=Path('C:/ck3-e04-resume-20261015-a01/continuation-a05/CAPACITY-ACCEPTED.actual-a01.json')
    fresh(R/'CAPACITY-REFERENCE.actual.json',dict(machine_id=plan['machine_id'],observed_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        parent_receipt=str(capacity),parent_sha256=hashlib.sha256(capacity.read_bytes()).hexdigest(),child_limit_bytes=8388608,shared_pool_bytes=536870912,
        deadline_utc=plan['read_budget']['deadline_utc'],independent_atomic_reservation_claimed=False))
    require(run.returncode==0,'Normal piece plan check rejected')
    print(json.dumps(dict(status='PLAN_A02_CHECK_PASS',sha256=hashlib.sha256(path.read_bytes()).hexdigest(),new_EXE_reads=0)))
if __name__=='__main__':main()
