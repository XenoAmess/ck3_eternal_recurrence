028A6FB8  48 83 c4 20                      add rsp, 0x20
028A6FBC  5f                               pop rdi
028A6FBD  c3                               ret 
