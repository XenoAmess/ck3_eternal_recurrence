"""Seal the stored same-function source; performs no further EXE reads."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
import capstone
from capstone.x86 import X86_OP_IMM,X86_OP_MEM
R=Path(__file__).resolve().parent
REPO=Path('D:/workspace/ck3_eternal_recurrence')
def require(ok,message):
    if not ok:raise ValueError(message)
def fresh(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:f.write(value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def pin(path):
    raw=path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def command(argv,prefix):
    run=subprocess.run(argv,capture_output=True,check=False)
    for label,blob in [('stdout',run.stdout),('stderr',run.stderr)]:
        with (R/(prefix+'.'+label+'.bin')).open('xb') as f:f.write(blob)
    fresh(R/(prefix+'.actual.json'),dict(machine_id='desktop-3fevhd2-1c74096080',observed_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),argv=argv,returncode=run.returncode,new_EXE_reads=0))
    require(run.returncode==0,prefix+' failed')
def main():
    require(not (R/'delivery-a01').exists(),'Use a fresh seal attempt')
    sys.path.insert(0,str(REPO))
    from tools.ck3_live_run_id import current_machine_id
    machine=current_machine_id();p1=json.loads((R/'source-read-a01/READ-RECEIPT.actual.json').read_bytes());p2=json.loads((R/'source-read-a02/READ-RECEIPT.actual.json').read_bytes())
    require(machine==p1['machine_id']==p2['machine_id'],'Actual source machine mismatch')
    intervals=[(p1['function']['begin_rva'],p1['function']['end_rva'],R/'source-read-a01/actual-callee.bin',p1['function']['sha256'])]
    for piece in p2['pieces']:
        require(piece['primary_runtime_function']==[p1['function']['begin_rva'],p1['function']['end_rva'],p1['function']['unwind_rva']],'Explicit same-function root differs')
        intervals.append((piece['begin_rva'],piece['end_rva'],R/('source-read-a02/piece-'+format(piece['begin_rva'],'08X')+'.bin'),piece['sha256']))
    intervals.sort();expected=0x28A6F50;body=b''
    for begin,end,path,sha in intervals:
        blob=path.read_bytes();require(begin==expected and len(blob)==end-begin and hashlib.sha256(blob).hexdigest()==sha,'Stored exact source pieces not contiguous/pinned')
        body+=blob;expected=end
    require(expected==0x28A6FBE and len(body)==110,'Complete callee source extent differs')
    with (R/'complete-function.bin').open('xb') as f:f.write(body)
    dis=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64);dis.detail=True
    lines=[];decoded=0;branches=[];calls=[];memory=[];instructions={}
    for ins in dis.disasm(body,0x140000000+0x28A6F50):
        at=ins.address-0x140000000;decoded+=ins.size;text=ins.mnemonic+' '+ins.op_str;instructions[at]=text
        lines.append(f'{at:08X}  {ins.bytes.hex(" "):<32} {text}')
        if ins.mnemonic.startswith('j') and ins.operands[0].type==X86_OP_IMM:
            target=ins.operands[0].imm-0x140000000;require(0x28A6F50<=target<0x28A6FBE,'Unclosed same-function branch outside captured body')
            branches.append(dict(at_rva=at,target_rva=target,instruction=text))
        if ins.mnemonic=='call':
            require(ins.operands[0].type==X86_OP_IMM,'Unexpected indirect call requires distinct evidence')
            calls.append(dict(at_rva=at,target_rva=ins.operands[0].imm-0x140000000,return_rva=at+ins.size,instruction=text))
        for i,operand in enumerate(ins.operands):
            if operand.type==X86_OP_MEM:memory.append(dict(at_rva=at,instruction=text,operand_index=i,base=ins.reg_name(operand.mem.base),disp=operand.mem.disp,access=operand.access,size=operand.size))
    require(decoded==len(body) and instructions[0x28A6FBD]=='ret ','Complete stored source decode/epilogue mismatch')
    expected_ins={0x28A6F56:'mov rax, qword ptr [rcx + 0x1b8]',0x28A6F5D:'mov rdi, rcx',0x28A6F6A:'mov rbx, qword ptr [rax + 0x50]',
        0x28A6F6E:'mov rax, qword ptr [rax]',0x28A6F71:'add rbx, rax',0x28A6F76:'mov rcx, qword ptr [rcx + 0x1b0]',
        0x28A6F82:'add rcx, 0xf8',0x28A6F89:'mov r8, rdi',0x28A6F8C:'mov rdx, rbx',0x28A6F94:'mov rax, qword ptr [rdi + 0x1b0]',
        0x28A6F9B:'mov rcx, qword ptr [rax + 0x278]',0x28A6FA2:'cmp qword ptr [rcx + 0x20], 0',0x28A6FA9:'mov r8, rbx',0x28A6FAC:'xor edx, edx'}
    require(all(instructions.get(at)==text for at,text in expected_ins.items()),'Reviewed register/dataflow source changed')
    require([(x['at_rva'],x['target_rva'],x['return_rva']) for x in calls]==[(0x28A6F8F,0x285EE40,0x28A6F94),(0x28A6FAE,0x19EAE80,0x28A6FB3)],'Unexpected call set')
    writes=[x for x in memory if x['access']&capstone.CS_AC_WRITE];nonstack=[x for x in writes if x['base']!='rsp']
    require(not nonstack and not [x for x in memory if x['disp']==0x1C0],'Direct secondary-context/store result changed')
    fresh(R/'complete-function.asm','\n'.join(lines)+'\n')
    now=dt.datetime.now(dt.timezone.utc)
    result=dict(schema='xar.e04.callee28A6F50.complete-static-source-contract.v1',machine_id=machine,observed_at_utc=now.isoformat(),
        source_identity=pin(R/'inputs/frozen-identity.json'),EXE_sha256_reused_not_rehashed=p1['EXE_sha256_reused_not_rehashed'],
        parent_source=pin(R/'inputs/parent-direct-call.asm'),parent_call_rva=0x28F7BDA,entry_argument='RCX=RBP=Character if parent path executes; inherited from complete parent source',
        function=dict(begin_rva=0x28A6F50,end_exclusive_rva=0x28A6FBE,complete_bytes=110,sha256=hashlib.sha256(body).hexdigest(),
            pieces=[dict(begin_rva=a,end_rva=b,source=pin(c),sha256=d) for a,b,c,d in intervals],all_conditional_branches_locally_closed=True,branches=branches,calls=calls),
        concrete_flow=dict(first_object_slot='Character+0x1B8',first_object_read_offsets=['0x50','0x0'],sum='wrapping64(first+50 + first+0); zero/nonzero guard only',
            wallet_call=dict(at_rva=0x28A6F8F,target_rva=0x285EE40,return_rva=0x28A6F94,rcx='*(Character+1B0)+F8',rdx='sum bits',r8='Character'),
            uninspected_call=dict(at_rva=0x28A6FAE,target_rva=0x19EAE80,rcx='*(*(Character+1B0)+278)',rdx=0,r8='sum bits',guard='[RCX+20]!=0',semantic_type=None)),
        direct_store_result=dict(explicit_nonstack_store_count=0,explicit_memory_writes=writes,secondary_context_1c0_loaded=False,
            four_terms_direct_store_proved=False,four_term_semantic_names=[None,None,None,None],
            excluded_wrong_base_offsets=[x for x in memory if x['disp'] in (0x2C0,0x2C8,0x28,0x30)],
            limit='No explicit direct term producer in this complete function. Unknown external call effects and possible pointer aliasing are not disproved.'),
        distinct_live_seq12=dict(other_wallet_return_rva=0x28A6D7C,this_wallet_return_rva=0x28A6F94,
            seq12_amount_or_four_inputs_reused_here=False,new_runtime_invocation_observed=False,
            limit='R0174 seq12 four inputs500974,0,218610,0 and282364 belong only to caller28A6D7C; this body has no new runtime inputs or result.'),
        reads=dict(new_EXE_code_bytes=p2['cumulative_EXE_code_bytes'],new_EXE_metadata_bytes=p2['cumulative_EXE_metadata_bytes'],new_EXE_read_calls=p2['cumulative_EXE_read_calls'],
            full_EXE_hashes=0,global_scans=0,new_transitive_callee_reads=0,new_EXE_reads_during_seal=0),
        prior_read_receipts=[pin(R/'source-read-a01/READ-RECEIPT.actual.json'),pin(R/'source-read-a02/READ-RECEIPT.actual.json')],
        maintenance_attribution='unclosed',cache_refresh_proved=False,cache_role_proved=False,military_component_proved=False,date_cadence_proved=False,
        game_SDK_desktop_compile_main_tree_operations=0,status='COMPLETE_LOCAL_FUNCTION_NO_DIRECT_FOUR_TERM_PRODUCER')
    fresh(R/'FINAL-SOURCE-CONTRACT.actual.json',result)
    plan=json.loads((R/'plan-a02.json').read_bytes());plan['created_utc']=now.isoformat();plan['prior_plan']=dict(path='plan-a02.json',sha256=hashlib.sha256((R/'plan-a02.json').read_bytes()).hexdigest())
    plan['amendment_reason']='Closure over stored complete110B source, not further EXE access; retain unknown external effects/term producer and distinct wallet return.'
    plan['evidence'].append(dict(id='complete-callee-contract',layer='source-contract',path='FINAL-SOURCE-CONTRACT.actual.json',sha256=pin(R/'FINAL-SOURCE-CONTRACT.actual.json')['sha256'],exe_sha256=plan['build']['exe_sha256'],supports='Reviewed complete local source; direct1B8-derived ADD return28A6F94, zero nonstack direct stores, no1C0 load, unknown external effects.'))
    plan['nodes'] += [dict(id='sum',label='1B8 object raw0+50 sum'),dict(id='wallet',label='Wallet ADD return28A6F94 distinct from seq12'),dict(id='other-call',label='19EAE80 effects uninspected')]
    plan['edges'] += [dict(id='local-sum',**{'from':'callee','to':'sum'},label='Local wrapping64 source0+50 and zero guard',status='static-confirmed',evidence=['complete-callee-contract']),
        dict(id='local-wallet-call',**{'from':'sum','to':'wallet'},label='Direct285EE40 call with extension+F8/sum/Character',status='static-confirmed',evidence=['complete-callee-contract']),
        dict(id='uninspected-effects',**{'from':'callee','to':'other-call'},label='Direct19EAE80 call arguments known, effects unknown',status='unknown',evidence=['complete-callee-contract'],open_question='No callee body read; no four-term/cache/military meaning inferred')]
    plan['edges'][1]['evidence']=['complete-callee-contract'];plan['edges'][1]['open_question']='Complete local body has no1C0 load or nonstack direct store; external effects and other producers remain unknown.'
    plan['cases']=[dict(id='source-only-coverage',question='Is the complete local110B source captured and reviewed?',status='not-applicable',evidence=['complete-callee-contract'],reason='This is a completed static source result, not a new live-observed case; see source-contract edge/receipt.'),
        dict(id='four-term-producer',question='Are four-term producer/cache/paid semantics closed?',status='pending',evidence=['complete-callee-contract'])]
    fresh(R/'plan-a03.json',plan)
    command([sys.executable,'-B',str(REPO/'tools/native_research_plan.py'),'check',str(R/'plan-a03.json')],'PLAN-A03-CHECK')
    command([sys.executable,'-B',str(REPO/'tools/native_research_plan.py'),'render',str(R/'plan-a03.json'),'--output',str(R/'research-graph-a03.md')],'PLAN-A03-RENDER')
    disk=shutil.disk_usage(R);files=[p for p in R.rglob('*') if p.is_file()];total=sum(p.stat().st_size for p in files)
    require(total*3+65536<8388608,'Worst-case source package peak exceeds suballocation')
    fresh(R/'STORAGE-CLOSE.actual.json',dict(schema='xar.e04.source-lane-storage-close.v1',machine_id=machine,observed_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        policy_version='1.0.0',capacity_reference=pin(R/'CAPACITY-REFERENCE.actual.json'),checkpoint='task_close',current_logical_bytes_before_bundle=total,
        projected_uncompressed_bundle_peak_upper_bound_bytes=total*3+65536,lane_budget_bytes=8388608,shared_pool_bytes=536870912,volume_total_bytes=disk.total,available_bytes=disk.free,
        raw_source_review_by_utc=(now+dt.timedelta(days=30)).isoformat(),derived_review_by_utc=(now+dt.timedelta(hours=48)).isoformat(),record_review_by_utc=(now+dt.timedelta(days=180)).isoformat(),
        key_source_protected_until_utc='2026-10-22T07:45:01.597Z',protection_reason='110B exact source + read ledgers needed for unresolved producer boundary and canonical integration',
        automatic_gc_or_atomic_reservation_claimed=False,cleanup_performed=False))
    delivery=R/'delivery-a01';delivery.mkdir()
    files=sorted([p for p in R.rglob('*') if p.is_file() and delivery not in p.parents],key=lambda p:p.relative_to(R).as_posix())
    manifest=dict(schema='xar.e04.callee28A6F50.source-package-manifest.v1',machine_id=machine,observed_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        relative_path_base='lane root',scope='Complete local source only; no full EXE or new callee source',files=[pin(p) for p in files],source_contract=pin(R/'FINAL-SOURCE-CONTRACT.actual.json'),
        total_uncompressed_member_bytes=sum(p.stat().st_size for p in files),maintenance_attribution='unclosed')
    fresh(delivery/'MANIFEST.actual.json',manifest)
    archive=delivery/'callee28A6F50-source-a01.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in files+[delivery/'MANIFEST.actual.json']:
            name=path.relative_to(R).as_posix();info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16
            z.writestr(info,path.read_bytes())
    final=dict(schema='xar.e04.callee28A6F50.root-delivery.v1',machine_id=machine,observed_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        result=result['status'],contract=pin(R/'FINAL-SOURCE-CONTRACT.actual.json'),document=pin(R/'CALLEE-SOURCE-CONTRACT.md'),
        complete_body=pin(R/'complete-function.bin'),complete_asm=pin(R/'complete-function.asm'),plan=pin(R/'plan-a03.json'),
        manifest=pin(delivery/'MANIFEST.actual.json'),archive=pin(archive),read_counts=result['reads'],field_semantic_names=[None,None,None,None],maintenance_attribution='unclosed',
        distinct_wallet_return_rvas=['0x28A6F94','0x28A6D7C'],total_lane_bytes_before_this_receipt=sum(p.stat().st_size for p in R.rglob('*') if p.is_file()))
    require(final['total_lane_bytes_before_this_receipt']+32768<8388608,'Final sublane size exceeds8MiB')
    fresh(delivery/'ROOT-DELIVERY.actual.json',final)
    print(json.dumps(dict(status=final['result'],delivery=pin(delivery/'ROOT-DELIVERY.actual.json'),contract=final['contract'],body=final['complete_body'],archive=final['archive'],read_counts=final['read_counts'],new_EXE_reads=0),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
