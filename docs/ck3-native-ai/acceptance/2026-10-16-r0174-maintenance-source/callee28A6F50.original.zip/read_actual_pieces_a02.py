"""Follow only the two root-proved callee continuations, reusing prior metadata."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import struct
import time
import capstone
from capstone.x86 import X86_OP_IMM,X86_OP_MEM
R=Path(__file__).resolve().parent
def require(ok,message):
    if not ok:raise ValueError(message)
def fresh(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:f.write(value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def main():
    planpath=R/'plan-a02.json';raw=planpath.read_bytes();plan=json.loads(raw);budget=plan['read_budget']
    check=json.loads((R/'PLAN-A02-CHECK.actual.json').read_bytes())
    require(check['returncode']==0 and check['plan_sha256']==hashlib.sha256(raw).hexdigest() and not check['for_observation'],'Actual frozen normal piece check required')
    require(dt.datetime.now(dt.timezone.utc)<dt.datetime.fromisoformat(budget['deadline_utc'].replace('Z','+00:00')),'Root deadline')
    pcs=[int(value,16) for value in budget['target_piece_PCs']]
    require(pcs==[0x28A6F65,0x28A6FB8],'Only root-proved exact continuations admitted')
    layout=json.loads((R/'inputs/pe-layout-reused.json').read_bytes());identity=json.loads((R/'inputs/frozen-identity.json').read_bytes())
    source=Path(identity['frozen_path']);before=source.stat();require(before.st_size==101040248,'Frozen source size')
    prior=[json.loads((R/name).read_bytes()) for name in budget['prior_receipts']]
    counts={'code':sum(x['new_EXE_code_bytes'] for x in prior),'metadata':sum(x['new_EXE_metadata_bytes'] for x in prior)}
    prior_calls=sum(x['new_EXE_read_calls'] for x in prior);cached={};reused=[];ledger=[];pieces=[]
    for receipt in prior:
        for item in receipt['read_ledger']:
            if item['kind']=='metadata':cached[(item['rva'],item['bytes'])]=bytes.fromhex(item['metadata_hex'])
    primary=tuple(budget['actual_root_runtime_function']);out=R/'source-read-a02';out.mkdir(exist_ok=False);started=time.monotonic()
    def offset(rva,count):
        for s in layout['sections']:
            if s['va']<=rva and rva+count<=s['va']+s['rawsize']:return s['raw']+rva-s['va']
        raise ValueError('Outside reused file-backed PE section')
    try:
        with source.open('rb') as stream:
            def read(rva,count,kind,reason):
                if kind=='metadata' and (rva,count) in cached:
                    reused.append(dict(rva=rva,bytes=count,reason=reason));return cached[(rva,count)]
                require(time.monotonic()-started<30 and prior_calls+len(ledger)<budget['new_EXE_read_calls_max'],'Cumulative finite time/read budget')
                require(counts[kind]+count<=budget['new_EXE_'+kind+'_bytes_max'],'Cumulative '+kind+' bytes')
                off=offset(rva,count);stream.seek(off);blob=stream.read(count);require(len(blob)==count,'Short exact piece read')
                counts[kind]+=count
                ledger.append(dict(rva=rva,rva_hex=hex(rva),file_offset=off,bytes=count,kind=kind,reason=reason,sha256=hashlib.sha256(blob).hexdigest(),metadata_hex=blob.hex() if kind=='metadata' else None))
                if kind=='metadata':cached[(rva,count)]=blob
                return blob
            ex=layout['exception_directory'];entrycache={}
            def entry(i):
                require(0<=i<ex['entries'],'Valid .pdata index')
                if i not in entrycache:entrycache[i]=struct.unpack('<III',read(ex['rva']+i*12,12,'metadata','Only reached callee piece binary-search entry'+str(i)))
                return entrycache[i]
            def find(pc):
                lo,hi=0,ex['entries']
                while lo<hi:
                    mid=(lo+hi)//2
                    if entry(mid)[0]<=pc:lo=mid+1
                    else:hi=mid
                result=entry(lo-1);require(result[0]<=pc<result[1],'Reached continuation absent from .pdata')
                return lo-1,result
            def root_of(function):
                chain=[];current=function
                while True:
                    require(len(chain)<8 and current not in [tuple(x['function']) for x in chain],'Finite acyclic explicit CHAININFO')
                    header=read(current[2],4,'metadata','Reached piece unwind header only');flags=header[0]>>3
                    chain.append(dict(function=list(current),unwind_flags=flags))
                    if not flags&4:return current,chain
                    pos=current[2]+4+((header[2]+1)//2)*4
                    current=struct.unpack('<III',read(pos,12,'metadata','Explicit reached same-function CHAININFO only'))
            done=set()
            for pc in pcs:
                index,function=find(pc);root,chain=root_of(function)
                require(root==primary,'Reached .pdata piece not CHAININFO-bound to actual callee root; no body read')
                if function in done:continue
                done.add(function);begin,end,unwind=function
                blob=read(begin,end-begin,'code','Only reached same-function piece'+hex(pc)+' with root28A6F50 CHAININFO proof')
                stem='piece-'+format(begin,'08X')
                with (out/(stem+'.bin')).open('xb') as f:f.write(blob)
                dis=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64);dis.detail=True
                lines=[];control=[];memory=[];decoded=0;last=None
                for ins in dis.disasm(blob,layout['image_base']+begin):
                    at=ins.address-layout['image_base'];decoded+=ins.size;last=dict(rva=at,size=ins.size,mnemonic=ins.mnemonic)
                    text=ins.mnemonic+' '+ins.op_str;lines.append(f'{at:08X}  {ins.bytes.hex(" "):<32} {text}')
                    if (ins.mnemonic.startswith('j') or ins.mnemonic=='call') and ins.operands and ins.operands[0].type==X86_OP_IMM:
                        control.append(dict(at_rva=at,kind=ins.mnemonic,target_rva=ins.operands[0].imm-layout['image_base'],target_rva_hex=hex(ins.operands[0].imm-layout['image_base'])))
                    for n,op in enumerate(ins.operands):
                        if op.type==X86_OP_MEM:memory.append(dict(at_rva=at,instruction=text,operand_index=n,size=op.size,access=op.access,base=ins.reg_name(op.mem.base),index=ins.reg_name(op.mem.index),scale=op.mem.scale,disp=op.mem.disp))
                fresh(out/(stem+'.asm'),'\n'.join(lines)+'\n');fresh(out/(stem+'-memory.actual.json'),memory)
                pieces.append(dict(lookup_pc=pc,begin_rva=begin,end_rva=end,bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),pdata_index=index,unwind_rva=unwind,
                    primary_runtime_function=list(root),CHAININFO=chain,decoded_bytes=decoded,decode_covers_declared_span=decoded==len(blob),last_instruction=last,direct_control_transfers=control))
        after=source.stat();require((before.st_size,before.st_ino,before.st_mtime_ns)==(after.st_size,after.st_ino,after.st_mtime_ns),'Frozen file changed')
        result=dict(schema='xar.e04.callee28A6F50-reached-pieces.v1',machine_id=plan['machine_id'],observed_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
            plan_sha256=hashlib.sha256(raw).hexdigest(),EXE_sha256_reused_not_rehashed=plan['build']['exe_sha256'],pieces=pieces,read_ledger=ledger,reused_metadata_reads=reused,
            new_EXE_code_bytes=counts['code']-sum(x['new_EXE_code_bytes'] for x in prior),new_EXE_metadata_bytes=counts['metadata']-sum(x['new_EXE_metadata_bytes'] for x in prior),new_EXE_read_calls=len(ledger),
            cumulative_EXE_code_bytes=counts['code'],cumulative_EXE_metadata_bytes=counts['metadata'],cumulative_EXE_read_calls=prior_calls+len(ledger),
            transitive_callee_reads=0,whole_EXE_hashes=0,global_scans=0,maintenance_attribution='unclosed')
        fresh(out/'READ-RECEIPT.actual.json',result)
        print(json.dumps(dict(status='REACHED_PIECES_CAPTURED',pieces=pieces,cumulative_code_bytes=counts['code'],cumulative_metadata_bytes=counts['metadata'],cumulative_read_calls=prior_calls+len(ledger)),ensure_ascii=False,indent=2))
    except Exception as error:
        fresh(out/'FAILED-READ-RECEIPT.actual.json',dict(machine_id=plan['machine_id'],observed_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),error=repr(error),plan_sha256=hashlib.sha256(raw).hexdigest(),read_ledger=ledger,reused_metadata_reads=reused,pieces=pieces,cumulative_code_bytes=counts['code'],cumulative_metadata_bytes=counts['metadata'],cumulative_read_calls=prior_calls+len(ledger),further_reads_stopped=True))
        raise
if __name__=='__main__':main()
