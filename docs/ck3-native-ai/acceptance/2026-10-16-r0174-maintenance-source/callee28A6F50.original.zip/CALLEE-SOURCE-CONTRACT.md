# Exact .4 callee 28A6F50 source contract

Machine `desktop-3fevhd2-1c74096080`; offline source study only. Frozen identity is CK3 `1.20.0.4`, Steam build `25734779`, EXE SHA-256 `98702f88a547cde2eaf29a85f93b85f68ee4cf8148336a4f7afaeb75319dd518`. The existing immutable EXE identity and PE layout were reused; this lane did not hash the whole EXE or scan an image/xref neighborhood.

The complete source-selected function is **RVA `28A6F50..28A6FBE` exclusive, 110 bytes**. Its root `.pdata` span is 21 bytes, followed by 83-byte and 6-byte pieces. Each continuation explicitly chains through `UNW_FLAG_CHAININFO` to the same 21-byte primary runtime-function record. All reached conditional branches and fallthroughs stay inside the captured pieces; the final instruction is `ret`. Cumulative new EXE access was **110 code bytes, 264 metadata bytes, 27 read calls**, within the declared 8192/512/48 limits.

## Entry provenance and reachability

The saved complete parent source contains `28F7BD7 mov rcx,rbp; 28F7BDA call 28A6F50`. The parent source identifies RBP as the actual Character. This proves the direct static call and Character argument **if that parent path executes**. The lane did not acquire a new runtime invocation of this callee, prove that the later parent path executed in R0174 seq12, or inspect new callees.

The pointer slots `Character+1B8`, `Character+1B0` and `Character+1C0` are distinct source locations. This function reads the first two and never loads `Character+1C0`. No runtime non-alias claim between their pointer values is made.

## Complete local flow

| Source RVA | Exact local effect |
| --- | --- |
| `28A6F56` | `RAX = *(Character+1B8)`; the Character is preserved in RDI at `28A6F5D`. Null RAX branches directly to the common epilogue. |
| `28A6F6A..28A6F74` | `RBX = *(RAX+50) + *(RAX+0)` using 64-bit ADD; zero result branches to restore/return. The branch is **zero/nonzero**, not a positive-only test. The two term names, time bases and producer semantics are unknown. |
| `28A6F76..28A6F8F` | If `*(Character+1B0)` is nonnull, pass `RCX=extension+F8`, `RDX=sum`, `R8=Character` to direct target `285EE40`, the existing personal wallet ADD entry. |
| `28A6F94..28A6FAE` | Reload `extension=*(Character+1B0)`; set `RCX=*(extension+278)`. If `*(RCX+20)` is nonzero, call direct target `19EAE80` with `RDX=0`, `R8=sum`. The RCX object's type and this callee's effects remain unknown. |
| `28A6FB3..28A6FBD` | Restore stack/registers and return. |

No signed overflow clamp or separate positive guard appears before the wallet call; the sum is the machine's wrapping 64-bit result passed as the existing wallet argument bits. There is no local zero/reset store to either input term. Effects performed inside `285EE40` or `19EAE80` are outside this lane's new source reads.

## Four-term producer result

There are **zero explicit non-stack memory stores** in the complete local function. The explicit memory write at `28A6F65` is only the RBX save to `[RSP+30]`; its `30` displacement is a stack slot, not secondary-context `+30`. Push/call/return mechanics likewise do not identify object-field producers.

This function therefore supplies no direct store to `*(Character+1C0)+2C0`, `+2C8`, `+28` or `+30`, and no source-proved passing of that secondary context to another function. The later call receives an object loaded through `Character+1B0` and `extension+278`; naming it a typed expense/cache context would exceed the evidence. The offsets `3E8`, `3F0` and `4A0` do not occur as local term stores and must not be substituted for the four raw fields.

The negative result is limited to this fully captured function's direct instructions. Unknown external call effects remain unknown. It neither proves that the four-term fields have no other producer nor proves that this function refreshes a cache. Cache role, refresh trigger, per-term semantic names, military paid component and date cadence all remain unclosed.

## Keep the two wallet calls separate

This function calls `285EE40` at `28A6F8F`, producing wallet **return RVA `28A6F94`**. The R0174 live seq12 generic context belonged to a different wallet return, **`28A6D7C`**, whose four observed inputs were `500974,0,218610,0` and amount `282364`.

Those seq12 inputs and amount cannot be assigned to this call. This lane has no runtime values for `*(Character+1B8)+0/+50`, no per-call wallet result for return `28A6F94`, and no invocation count for this function. Sharing the same wallet entry or containing a later call in the same parent source does not establish identical purpose, amount, context, timing or business attribution. `maintenance_attribution` remains `unclosed`.

## Reproduction and artifacts

Plans `plan-a01.json` and `plan-a02.json` passed the actual normal `native_research_plan.py check` before their respective new EXE reads; neither used `--for-observation`. The append-only closure plan `plan-a03.json` records the completed static edges and preserves the unknown producer/effect edges. Its check and generated graph provide file/declaration validation, not new semantics or live credit.

Raw source pieces, asm, metadata/read ledgers and decoded memory operands are under `source-read-a01/` and `source-read-a02/`. `FINAL-SOURCE-CONTRACT.actual.json` records their exact pins, coverage and direct-call distinction. The delivery manifest uses paths relative to this lane root. The full EXE is excluded from the bundle. No build, SDK, game, desktop operation, repository write or new transitive-callee read occurred.
