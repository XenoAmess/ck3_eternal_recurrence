028F7BC9  48 8b 81 b8 00 00 00             mov rax, qword ptr [rcx + 0xb8]
028F7BD0  48 89 81 30 01 00 00             mov qword ptr [rcx + 0x130], rax
028F7BD7  48 8b cd                         mov rcx, rbp
028F7BDA  e8 71 f3 fa ff                   call 0x1428a6f50
028F7BDF  48 83 bd c0 01 00 00 00          cmp qword ptr [rbp + 0x1c0], 0
028F7BE7  0f 84 a7 00 00 00                je 0x1428f7c94
028F7BED  48 8b cd                         mov rcx, rbp
028F7BF0  e8 fb b1 fc ff                   call 0x1428c2df0
028F7BF5  81 78 38 4f 62 44 47             cmp dword ptr [rax + 0x38], 0x4744624f
028F7BFC  0f 85 92 00 00 00                jne 0x1428f7c94
028F7C02  48 8b 40 40                      mov rax, qword ptr [rax + 0x40]
028F7C06  48 c1 e8 29                      shr rax, 0x29
028F7C0A  a8 01                            test al, 1
028F7C0C  0f 84 82 00 00 00                je 0x1428f7c94
028F7C12  45 33 c9                         xor r9d, r9d
028F7C15  48 8d 8c 24 b0 00 00 00          lea rcx, [rsp + 0xb0]
028F7C1D  48 8b d5                         mov rdx, rbp
028F7C20  e8 fb b6 2d 00                   call 0x142bd3320
028F7C25  45 33 c0                         xor r8d, r8d
028F7C28  48 8d 4c 24 30                   lea rcx, [rsp + 0x30]
028F7C2D  48 8b d5                         mov rdx, rbp
028F7C30  e8 2b c3 31 00                   call 0x142c13f60
028F7C35  48 8b 9c 24 b0 00 00 00          mov rbx, qword ptr [rsp + 0xb0]
028F7C3D  48 8b 40 48                      mov rax, qword ptr [rax + 0x48]
028F7C41  48 2b d8                         sub rbx, rax
028F7C44  48 85 db                         test rbx, rbx
028F7C47  7e 2e                            jle 0x1428f7c77
028F7C49  48 83 bd b0 01 00 00 00          cmp qword ptr [rbp + 0x1b0], 0
028F7C51  74 41                            je 0x1428f7c94
028F7C53  48 8b cd                         mov rcx, rbp
028F7C56  e8 d5 82 2b 00                   call 0x142baff30
028F7C5B  84 c0                            test al, al
028F7C5D  74 35                            je 0x1428f7c94
028F7C5F  48 8b 85 c0 01 00 00             mov rax, qword ptr [rbp + 0x1c0]
028F7C66  48 01 98 a0 04 00 00             add qword ptr [rax + 0x4a0], rbx
028F7C6D  48 81 c4 98 00 00 00             add rsp, 0x98
028F7C74  5d                               pop rbp
028F7C75  5b                               pop rbx
028F7C76  c3                               ret 
028F7C77  48 85 c0                         test rax, rax
028F7C7A  74 18                            je 0x1428f7c94
028F7C7C  41 b9 03 00 00 00                mov r9d, 3
028F7C82  48 f7 db                         neg rbx
028F7C85  4c 8b c3                         mov r8, rbx
028F7C88  48 8b cd                         mov rcx, rbp
028F7C8B  41 8d 51 01                      lea edx, [r9 + 1]
028F7C8F  e8 bc 1c fc ff                   call 0x1428b9950
028F7C94  48 81 c4 98 00 00 00             add rsp, 0x98
028F7C9B  5d                               pop rbp
028F7C9C  5b                               pop rbx
028F7C9D  c3                               ret 
