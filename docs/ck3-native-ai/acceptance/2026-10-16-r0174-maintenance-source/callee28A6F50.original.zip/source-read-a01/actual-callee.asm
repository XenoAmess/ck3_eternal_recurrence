028A6F50  40 57                            push rdi
028A6F52  48 83 ec 20                      sub rsp, 0x20
028A6F56  48 8b 81 b8 01 00 00             mov rax, qword ptr [rcx + 0x1b8]
028A6F5D  48 8b f9                         mov rdi, rcx
028A6F60  48 85 c0                         test rax, rax
028A6F63  74 53                            je 0x1428a6fb8
