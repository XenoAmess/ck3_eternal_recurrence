"""Read only the metadata-selected actual direct callee28A6F50 body."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import struct
import time
import capstone
from capstone.x86 import X86_OP_IMM,X86_OP_MEM,X86_REG_RIP

R=Path(__file__).resolve().parent
def require(ok,message):
    if not ok:raise ValueError(message)
def fresh(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        f.write(value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def main():
    planraw=(R/'plan-a01.json').read_bytes();plan=json.loads(planraw)
    check=json.loads((R/'PLAN-A01-CHECK.actual.json').read_bytes())
    require(check['returncode']==0 and check['plan_sha256']==hashlib.sha256(planraw).hexdigest() and check['offline_normal_check'] and not check['for_observation'],'Frozen normal offline plan check required')
    budget=plan['read_budget'];target=int(budget['target_entry_rva'],16)
    require(target==0x28A6F50 and int(budget['metadata_lookup_PC'],16)==target,'Only actual direct callee28A6F50 admitted')
    require(dt.datetime.now(dt.timezone.utc)<dt.datetime.fromisoformat(budget['deadline_utc'].replace('Z','+00:00')),'Root original deadline expired')
    layout=json.loads((R/'inputs/pe-layout-reused.json').read_bytes())
    identity=json.loads((R/'inputs/frozen-identity.json').read_bytes())
    source=Path(identity['frozen_path']);before=source.stat()
    require(before.st_size==101040248 and identity['sha256']==plan['build']['exe_sha256'],'Frozen exact source identity mismatch')
    out=R/'source-read-a01';out.mkdir(exist_ok=False)
    ledger=[];counts={'code':0,'metadata':0};started=time.monotonic()
    def offset(rva,count):
        for section in layout['sections']:
            if section['va']<=rva and rva+count<=section['va']+section['rawsize']:
                return section['raw']+rva-section['va']
        raise ValueError('Targeted range outside reused file-backed PE mapping')
    try:
        with source.open('rb') as stream:
            def read(rva,count,kind,reason):
                require(time.monotonic()-started<30,'Finite helper wall limit')
                require(len(ledger)<budget['new_EXE_read_calls_max'],'48-read cumulative limit')
                maximum=budget['new_EXE_'+kind+'_bytes_max']
                require(counts[kind]+count<=maximum,'Cumulative '+kind+' byte budget')
                off=offset(rva,count);stream.seek(off);blob=stream.read(count)
                require(len(blob)==count,'Short targeted source read')
                counts[kind]+=count
                ledger.append(dict(rva=rva,rva_hex=hex(rva),file_offset=off,bytes=count,kind=kind,reason=reason,
                    sha256=hashlib.sha256(blob).hexdigest(),metadata_hex=blob.hex() if kind=='metadata' else None))
                return blob
            ex=layout['exception_directory'];cache={}
            def entry(index):
                require(0<=index<ex['entries'],'Valid exception index')
                if index not in cache:
                    cache[index]=struct.unpack('<III',read(ex['rva']+index*12,12,'metadata','Binary-search .pdata for actual direct target28A6F50 only; entry'+str(index)))
                return cache[index]
            low,high=0,ex['entries']
            while low<high:
                mid=(low+high)//2
                if entry(mid)[0]<=target:low=mid+1
                else:high=mid
            index=low-1;begin,end,unwind=entry(index)
            require(begin<=target<end,'No .pdata span contains actual direct target; stop before code')
            header=read(unwind,4,'metadata','Target28A6F50 unwind flags and count only')
            flags=header[0]>>3;chain=None
            if flags&4:
                chain_at=unwind+4+((header[2]+1)//2)*4
                chain=struct.unpack('<III',read(chain_at,12,'metadata','Explicit target same-function CHAININFO runtime-function metadata'))
            require(0<end-begin<=budget['new_EXE_code_bytes_max'],'Declared target body exceeds8192; no code read')
            blob=read(begin,end-begin,'code','Only declared .pdata span containing direct Character callee28A6F50')
            with (out/'actual-callee.bin').open('xb') as f:f.write(blob)
        after=source.stat()
        require((before.st_size,before.st_ino,before.st_mtime_ns)==(after.st_size,after.st_ino,after.st_mtime_ns),'Frozen source metadata changed')
        dis=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64);dis.detail=True
        image_base=layout['image_base'];lines=[];instructions=[];control=[];memory=[];decoded=0
        for ins in dis.disasm(blob,image_base+begin):
            at=ins.address-image_base;decoded+=ins.size
            text=ins.mnemonic+' '+ins.op_str
            lines.append(f'{at:08X}  {ins.bytes.hex(" "):<32} {text}')
            instructions.append(dict(rva=at,size=ins.size,bytes=ins.bytes.hex(),instruction=text))
            if (ins.mnemonic.startswith('j') or ins.mnemonic=='call') and ins.operands and ins.operands[0].type==X86_OP_IMM:
                control.append(dict(at_rva=at,at_rva_hex=hex(at),kind=ins.mnemonic,target_rva=ins.operands[0].imm-image_base,target_rva_hex=hex(ins.operands[0].imm-image_base)))
            for n,operand in enumerate(ins.operands):
                if operand.type==X86_OP_MEM:
                    memory.append(dict(at_rva=at,instruction=text,operand_index=n,size=operand.size,access=operand.access,
                        base=ins.reg_name(operand.mem.base),index=ins.reg_name(operand.mem.index),scale=operand.mem.scale,disp=operand.mem.disp,
                        rip_target_rva=at+ins.size+operand.mem.disp if operand.mem.base==X86_REG_RIP else None))
        fresh(out/'actual-callee.asm','\n'.join(lines)+'\n')
        fresh(out/'decoded-instructions.actual.json',instructions)
        fresh(out/'memory-operands.actual.json',memory)
        receipt=dict(schema='xar.e04.actual-direct-callee28A6F50-source-read.v1',machine_id=plan['machine_id'],observed_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
            plan_sha256=hashlib.sha256(planraw).hexdigest(),source=str(source),EXE_sha256_reused_not_rehashed=plan['build']['exe_sha256'],
            actual_direct_parent_call_rva=0x28F7BDA,target_entry_rva=target,
            function=dict(begin_rva=begin,end_rva=end,bytes=len(blob),pdata_index=index,unwind_rva=unwind,unwind_flags=flags,
                chained_runtime_function=chain,full_declared_pdata_span_captured=True,decoded_bytes=decoded,decode_covers_declared_span=decoded==len(blob),sha256=hashlib.sha256(blob).hexdigest(),direct_control_transfers=control),
            read_ledger=ledger,new_EXE_code_bytes=counts['code'],new_EXE_metadata_bytes=counts['metadata'],new_EXE_read_calls=len(ledger),
            whole_EXE_hashes=0,global_scans=0,transitive_callee_reads=0,game_SDK_desktop_build_main_tree_operations=0,
            maintenance_attribution='unclosed',field_semantic_names=[None,None,None,None])
        fresh(out/'READ-RECEIPT.actual.json',receipt)
        print(json.dumps(dict(status='SOURCE_BODY_CAPTURED',receipt=str(out/'READ-RECEIPT.actual.json'),function=receipt['function'],code_bytes=counts['code'],metadata_bytes=counts['metadata'],read_calls=len(ledger)),ensure_ascii=False,indent=2))
    except Exception as error:
        fresh(out/'FAILED-READ-RECEIPT.actual.json',dict(machine_id=plan['machine_id'],observed_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),error=repr(error),
            plan_sha256=hashlib.sha256(planraw).hexdigest(),read_ledger=ledger,new_EXE_code_bytes=counts['code'],new_EXE_metadata_bytes=counts['metadata'],new_EXE_read_calls=len(ledger),further_reads_stopped=True))
        raise
if __name__=='__main__':main()
