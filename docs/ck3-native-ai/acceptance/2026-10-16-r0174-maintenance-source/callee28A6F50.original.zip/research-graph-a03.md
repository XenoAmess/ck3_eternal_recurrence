# Research plan: e04-12004-R0174-direct-Character-callee28A6F50

GENERATED from the supplied research plan; no native semantics are inferred.

Question: Does actual parent direct callee28A6F50, passed RCX=RBP=Character, write the secondary context four raw terms or pass a source-qualified context?

```mermaid
flowchart TD
    n0["Actual parent direct caller"]
    n1["Character callee28A6F50"]
    n2["Four raw secondary-context terms"]
    n3["1B8 object raw0+50 sum"]
    n4["Wallet ADD return28A6F94 distinct from seq12"]
    n5["19EAE80 effects uninspected"]
    n0 -->|"actual-direct-call [static-confirmed] 28F7BDA direct call with RCX=Character"| n1
    n1 -. "term-production [unknown] Producer/context edge awaiting same-function source" .-> n2
    n1 -->|"local-sum [static-confirmed] Local wrapping64 source0+50 and zero guard"| n3
    n3 -->|"local-wallet-call [static-confirmed] Direct285EE40 call with extension+F8/sum/Character"| n4
    n1 -. "uninspected-effects [unknown] Direct19EAE80 call arguments known, effects unknown" .-> n5
```

| Edge | Declared status | Evidence IDs | Open question |
|---|---|---|---|
| actual-direct-call | static-confirmed | parent-direct-call |  |
| term-production | unknown | complete-callee-contract | Complete local body has no1C0 load or nonstack direct store; external effects and other producers remain unknown. |
| local-sum | static-confirmed | complete-callee-contract |  |
| local-wallet-call | static-confirmed | complete-callee-contract |  |
| uninspected-effects | unknown | complete-callee-contract | No callee body read; no four-term/cache/military meaning inferred |

| Observation design | Value |
|---|---|
| mode | offline-only |
| actor_kind | engine |
| owner_scope | Only actual direct callee28A6F50 from parent28F7BDA, RCX=actual Character; secondary context is not assumed to be a cache. |
| identity_kind | generation-id |
| identity_lifetime | Frozen exact .4 source identity; no new runtime or cross-session identity claim. |
| producer_trigger | not-applicable |
| producer | Unknown; investigate concrete stores/typed context inside one actual reached function only. |
| caller | Complete actual parent28F7840..28F7C9E:28F7BD7 mov rcx,rbp;28F7BDA call28A6F50. |
| consumer | Generic settlement reads *(Character+1C0) terms2C0/2C8/28/30; amount relationship already known, term semantics unclosed. |
| cache_lifetime | Unknown; no cache role, refresh epoch or cadence is presumed from this callee name/direction. |
| expected_signal | Explicit store/operation at secondarycontext+2C0/2C8/28/30, or concrete context argument propagation;3E8/3F0/4A0 are different fields. |
| zero_sample_meaning | No direct term store in the fully bounded body does not exclude unexamined callees or other producers; no live sample or zero maintenance conclusion. |
| stop_condition | Cumulative whole lane code&lt;=8192B metadata&lt;=512B reads&lt;=48. Read only reached PCs28A6F65/28A6FB8 .pdata and explicit CHAININFO back to actual root28A6F50..28A6F65; then those declared same-function pieces. No transitive callees/getters/global xrefs/neighborhoods. |
| runtime_window_ref | No new runtime. Prior R0174 actual source direction only; source read deadline2026-10-16T07:45:01.597Z. |

| Evidence ID | Declared layer | File | SHA-256 | Supports |
|---|---|---|---|---|
| frozen-identity | exact-build | inputs/frozen-identity.json | 15ad8093ca23930d7d440752518d3ce89097dec1b00fe234a5115011782b62b9 | Frozen exact .4 identity/layout reuse |
| pe-layout-reused | exact-build | inputs/pe-layout-reused.json | 9f0f3da5fcaf809b8fad13c4310d6abdf3c5a06d98aad113e907ee64c15e7bb4 | Frozen exact .4 identity/layout reuse |
| parent-direct-call | source-contract | inputs/parent-direct-call.asm | 5e816610cd023f0413e8acac9d65430868bbf499934d66d2e9269b848168c6f6 | Decoded actual parent28F7840 same-function branch:28F7BD7 mov rcx,rbp;28F7BDA direct call28A6F50. RBP is actual Character by parent source; no producer claim. |
| actual-root-source | source-contract | source-read-a01/READ-RECEIPT.actual.json | 57666bbeaf87d86a9e045a7027f176fea695c97606af8f5e716e601d587af2be | Actual decoded root reads Character+1B8 then branches JE28A6FB8/fallthrough28A6F65; no term store yet and no whole-function conclusion. |
| complete-callee-contract | source-contract | FINAL-SOURCE-CONTRACT.actual.json | fa9b57d1b97d78f607b58c44c30726f7d2910c8a52bb7bac469fcbc5b367744a | Reviewed complete local source; direct1B8-derived ADD return28A6F94, zero nonstack direct stores, no1C0 load, unknown external effects. |

Check result (file integrity and declarations only):

```json
{
  "schema": "xar.native-research-plan-check.v1",
  "result": "plan-consistent",
  "proof_layer": "record-structure-and-file-integrity",
  "semantic_correctness_verified": false,
  "live_execution_performed": false,
  "observation_plan_issues": [
    "offline-only plan does not define a live observation window",
    "the real producer trigger must be located before live sampling"
  ],
  "declared_edges_by_status": {
    "counter-policy": 0,
    "inference": 0,
    "live-confirmed": 0,
    "static-confirmed": 3,
    "unknown": 2
  },
  "enumerated_native_edges": 5,
  "declared_cases_by_status": {
    "pending": 1,
    "observed": 0,
    "not-applicable": 1
  },
  "checked_evidence_files": 5,
  "limitations": [
    "Evidence layers and conclusions are author declarations; hashes bind bytes, not their truth.",
    "Counts cover this enumerated graph only, not all CK3 branches.",
    "A consistent observation plan is not authorization to run or manipulate CK3."
  ],
  "plan_sha256": "f5e70de6cee632c60c14fa3cab565ce2b72a40bc3f102815f83dfd4560bb76a2"
}
```
