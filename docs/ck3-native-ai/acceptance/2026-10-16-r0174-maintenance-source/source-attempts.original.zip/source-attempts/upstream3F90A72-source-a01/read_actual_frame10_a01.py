"""Read only the .pdata body containing the recorded real generic caller PC."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import struct
import time
import capstone
from capstone.x86 import X86_OP_IMM, X86_OP_MEM, X86_REG_RIP

R = Path(__file__).resolve().parent
def require(ok, message):
    if not ok:
        raise ValueError(message)
def new(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as f:
        if isinstance(value, str):
            f.write(value)
        else:
            json.dump(value, f, ensure_ascii=False, indent=2)
            f.write("\n")
def main():
    plan_path = R / "plan-a01.json"
    plan_raw = plan_path.read_bytes()
    plan = json.loads(plan_raw)
    require(json.loads((R / "PLAN-A01-CHECK.actual.json").read_bytes())["returncode"] == 0, "Actual check before source read")
    prior = json.loads((R / "inputs/pe-layout-reused.json").read_bytes())
    source = Path("C:/ck3-e04-resume-20261015-a01/frozen-game-12004/ck3.exe")
    budget = plan["read_budget"]
    pc = int(budget["metadata_lookup_PC"], 16)
    expected_return = int(budget["actual_caller_return_rva"], 16)
    require(pc == 0x3F90A71 and expected_return == pc + 1, "Only actual record's source PC is admitted")
    before = source.stat()
    require(before.st_size == 101040248, "Frozen exact input differs")
    out = R / "source-read-a01"
    out.mkdir(exist_ok=False)
    reads = []
    code_count = 0
    meta_count = 0
    started = time.monotonic()
    def offset(rva, count):
        for s in prior["sections"]:
            if s["va"] <= rva and rva + count <= s["va"] + s["rawsize"]:
                return s["raw"] + rva - s["va"]
        raise ValueError("Unmapped exact source range")
    try:
        with source.open("rb") as f:
            def read(rva, count, kind, reason):
                nonlocal code_count, meta_count
                require(time.monotonic() - started < 30, "Source helper finite wall budget")
                require(len(reads) < budget["new_EXE_read_calls_max"], "Finite source reads")
                if kind == "code":
                    require(code_count + count <= budget["new_EXE_code_bytes_max"], "Finite code budget")
                    code_count += count
                else:
                    require(meta_count + count <= budget["new_EXE_metadata_bytes_max"], "Finite metadata budget")
                    meta_count += count
                off = offset(rva, count)
                f.seek(off)
                blob = f.read(count)
                require(len(blob) == count, "Short targeted read")
                reads.append({"rva": rva, "file_offset": off, "bytes": count, "kind": kind, "reason": reason, "sha256": hashlib.sha256(blob).hexdigest(), "metadata_hex": blob.hex() if kind == "metadata" else None})
                return blob
            ex = prior["exception_directory"]
            entries = {}
            def entry(i):
                require(0 <= i < ex["entries"], "Valid exception index")
                if i not in entries:
                    entries[i] = struct.unpack("<III", read(ex["rva"] + i * 12, 12, "metadata", f"Only actual caller-PC binary-search exception entry{i}"))
                return entries[i]
            lo, hi = 0, ex["entries"]
            while lo < hi:
                mid = (lo + hi) // 2
                if entry(mid)[0] <= pc:
                    lo = mid + 1
                else:
                    hi = mid
            index = lo - 1
            begin, end, unwind = entry(index)
            require(begin <= pc < end, "Actual caller PC not contained in unwind span; stop before code")
            unwind_header = read(unwind, 4, "metadata", "Only actual caller unwind flags/count")
            chain = None
            flags = unwind_header[0] >> 3
            if flags & 4:
                chain_at = unwind + 4 + ((unwind_header[2] + 1) // 2) * 4
                chain = struct.unpack("<III", read(chain_at, 12, "metadata", "Actual caller chained-runtime-function metadata only"))
            require(end-begin <= budget["new_EXE_code_bytes_max"], "Actual full grandparent extent exceeds8192; no code read")
            count=end-begin
            require(begin <= pc < begin + count, "Recorded call is beyond one-body budget; retain metadata and stop")
            blob = read(begin, count, "code", "Only .pdata span containing actual natural ADD return0x3978BF8")
            with (out / "actual-caller.bin").open("xb") as f:
                f.write(blob)
            dis = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
            dis.detail = True
            image_base = prior["image_base"]
            lines = []
            direct = []
            rip = []
            actual_call = None
            for ins in dis.disasm(blob, image_base + begin):
                at = ins.address - image_base
                lines.append(f"{at:08X}  {ins.bytes.hex(' '):<32} {ins.mnemonic} {ins.op_str}")
                if ins.mnemonic in {"call", "jmp"} and ins.operands and ins.operands[0].type == X86_OP_IMM:
                    item = {"at_rva": at, "target_rva": ins.operands[0].imm - image_base, "kind": ins.mnemonic}
                    direct.append(item)
                    if ins.mnemonic == "call" and at + ins.size == expected_return:
                        actual_call = item
                if ins.mnemonic == "call" and at + ins.size == expected_return:
                    actual_call = {"at_rva": at, "target_rva": ins.operands[0].imm-image_base if ins.operands and ins.operands[0].type==X86_OP_IMM else None, "kind":"call", "instruction":ins.mnemonic+" "+ins.op_str}
                for operand in ins.operands:
                    if operand.type == X86_OP_MEM and operand.mem.base == X86_REG_RIP:
                        rip.append({"at_rva": at, "target_rva": at + ins.size + operand.mem.disp, "size": operand.size, "instruction": ins.mnemonic + " " + ins.op_str})
            new(out / "actual-caller.asm", "\n".join(lines) + "\n")
        after = source.stat()
        require((before.st_size, before.st_ino, before.st_mtime_ns) == (after.st_size, after.st_ino, after.st_mtime_ns), "Frozen source changed")
        receipt = {"schema": "xar.e04.actual-generic-ADD-caller-finite-source-read.v1", "machine_id": plan["machine_id"], "observed_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "plan": str(plan_path), "plan_sha256": hashlib.sha256(plan_raw).hexdigest(), "EXE_sha256_reused_not_rehashed": plan["build"]["exe_sha256"], "source": str(source), "actual_recorded_return_rva": expected_return, "function": {"begin_rva": begin, "declared_end_rva": end, "captured_end_rva": begin + count, "captured_bytes": count, "full_declared_pdata_span_captured": count == end - begin, "pdata_index": index, "unwind_rva": unwind, "unwind_flags": flags, "chained_runtime_function": chain, "sha256": hashlib.sha256(blob).hexdigest(), "direct_calls_and_jumps": direct, "rip_references": rip, "actual_return_matched_instruction_call": actual_call}, "read_ledger": reads, "new_EXE_code_bytes": code_count, "new_EXE_metadata_bytes": meta_count, "new_EXE_read_calls": len(reads),  "whole_EXE_hashes": 0, "transitive_callee_reads": 0, "xref_or_whole_image_scans": 0, "game_SDK_desktop_build_main_tree_operations": 0}
        new(out / "READ-RECEIPT.actual.json", receipt)
        require(actual_call is not None, "Actual return PC not at a decoded call; retain bytes without static parent claim")
        print(json.dumps({"receipt": str(out / "READ-RECEIPT.actual.json"), "function": receipt["function"], "code_bytes": code_count, "metadata_bytes": meta_count, "reads": len(reads)}, ensure_ascii=False, indent=2))
        return 0
    except Exception as error:
        new(out / "FAILED-READ-RECEIPT.actual.json", {"machine_id": plan["machine_id"], "observed_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "error": repr(error), "plan_sha256": hashlib.sha256(plan_raw).hexdigest(), "read_ledger": reads, "new_EXE_code_bytes": code_count, "new_EXE_metadata_bytes": meta_count, "new_EXE_read_calls": len(reads), "further_reads_stopped": True})
        raise
if __name__ == "__main__":
    raise SystemExit(main())
