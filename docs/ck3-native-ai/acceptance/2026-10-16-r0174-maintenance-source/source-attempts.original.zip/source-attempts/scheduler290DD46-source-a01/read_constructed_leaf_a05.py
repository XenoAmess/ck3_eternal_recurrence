from pathlib import Path
import datetime as dt
import hashlib
import json
import capstone
R=Path(__file__).resolve().parent
def require(ok,message):
    if not ok:raise RuntimeError(message)
require(json.loads((R/'PLAN-A05-CHECK.actual.json').read_bytes())['returncode']==0,'Actual plan required')
planraw=(R/'plan-a05.json').read_bytes();plan=json.loads(planraw)
require(plan['read_budget']['leaf_continuation_begin_rva']=='0x290FD38' and plan['read_budget']['leaf_continuation_end_rva_exclusive']=='0x290FD40','Only admitted continuation')
mapping=json.loads((R/'inputs/pe-layout-reused.json').read_bytes());rva=0x290FD38;count=8
offset=next(s['raw']+rva-s['va'] for s in mapping['sections'] if s['va']<=rva and rva+count<=s['va']+s['rawsize'])
source=Path('C:/ck3-e04-resume-20261015-a01/frozen-game-12004/ck3.exe');before=source.stat();require(before.st_size==101040248,'Exact frozen size differs')
out=R/'source-read-a05';out.mkdir(exist_ok=False)
with source.open('rb') as f:f.seek(offset);raw=f.read(count)
require(len(raw)==count,'Short continuation')
after=source.stat();require((before.st_size,before.st_ino,before.st_mtime_ns)==(after.st_size,after.st_ino,after.st_mtime_ns),'Frozen changed')
(out/'continuation.bin').write_bytes(raw)
combined=(R/'source-read-a03/actual-leaf.bin').read_bytes()+(R/'source-read-a04/continuation.bin').read_bytes()+raw
d=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64);rows=list(d.disasm(combined,mapping['image_base']+0x290FD20))
lines=[f'{i.address-mapping["image_base"]:08X}  {i.bytes.hex(" "):<32} {i.mnemonic} {i.op_str}' for i in rows]
(out/'constructed-closure.asm').write_text('\n'.join(lines)+'\n',encoding='utf-8')
term=next((i for i in rows if i.mnemonic in ('jmp','ret','retf')),None)
result=dict(schema='xar.e04.constructed-closure-continuation.v1',observed_utc=dt.datetime.now(dt.timezone.utc).isoformat(),machine_id=plan['machine_id'],plan_sha256=hashlib.sha256(planraw).hexdigest(),begin_rva=rva,bytes=count,sha256=hashlib.sha256(raw).hexdigest(),raw_hex=raw.hex(),combined_begin_rva=0x290FD20,combined_bytes=len(combined),combined_sha256=hashlib.sha256(combined).hexdigest(),source_instructions=lines,first_terminal_rva=(term.address-mapping['image_base'] if term else None),first_terminal=(term.mnemonic+' '+term.op_str if term else None),new_EXE_code_bytes=8,new_EXE_metadata_bytes=0,new_EXE_read_calls=1,cumulative_scope_EXE_code_bytes=501,cumulative_scope_EXE_metadata_bytes=268,cumulative_scope_EXE_read_calls=27,whole_EXE_hashes=0,game_or_SDK_actions=0)
(out/'READ-RECEIPT.actual.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
