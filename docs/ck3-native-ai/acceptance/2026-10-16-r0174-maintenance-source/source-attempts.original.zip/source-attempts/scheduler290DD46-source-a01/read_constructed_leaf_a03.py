from pathlib import Path
import datetime as dt
import hashlib
import json
import capstone
R=Path(__file__).resolve().parent
def require(ok,message):
    if not ok:raise RuntimeError(message)
require(json.loads((R/'PLAN-A03-CHECK.actual.json').read_bytes())['returncode']==0,'Actual plan before leaf read')
planraw=(R/'plan-a03.json').read_bytes();plan=json.loads(planraw)
require(plan['read_budget']['leaf_gap_begin_rva']=='0x290FD20' and plan['read_budget']['leaf_gap_end_rva_exclusive']=='0x290FD30','Exact admitted leaf only')
mapping=json.loads((R/'inputs/pe-layout-reused.json').read_bytes());rva=0x290FD20;count=16
offset=next(s['raw']+rva-s['va'] for s in mapping['sections'] if s['va']<=rva and rva+count<=s['va']+s['rawsize'])
source=Path('C:/ck3-e04-resume-20261015-a01/frozen-game-12004/ck3.exe');before=source.stat();require(before.st_size==101040248,'Exact frozen size differs')
out=R/'source-read-a03';out.mkdir(exist_ok=False)
with source.open('rb') as f:f.seek(offset);raw=f.read(count)
require(len(raw)==16,'Short exact leaf read')
after=source.stat();require((before.st_size,before.st_ino,before.st_mtime_ns)==(after.st_size,after.st_ino,after.st_mtime_ns),'Frozen input changed')
with (out/'actual-leaf.bin').open('xb') as f:f.write(raw)
d=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64);rows=list(d.disasm(raw,mapping['image_base']+rva))
require(sum(i.size for i in rows)==16,'Leaf gap not fully decoded')
lines=[f'{i.address-mapping["image_base"]:08X}  {i.bytes.hex(" "):<32} {i.mnemonic} {i.op_str}' for i in rows]
(out/'actual-leaf.asm').write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
receipt=dict(schema='xar.e04.exact-actual-target-leaf-gap.v1',observed_utc=dt.datetime.now(dt.timezone.utc).isoformat(),machine_id=plan['machine_id'],
 plan_sha256=hashlib.sha256(planraw).hexdigest(),begin_rva=rva,end_rva_exclusive=rva+16,bytes=16,sha256=hashlib.sha256(raw).hexdigest(),raw_hex=raw.hex(),
 actual_source_instructions=lines,new_EXE_code_bytes=16,new_EXE_metadata_bytes=0,new_EXE_read_calls=1,
 cumulative_scope_EXE_code_bytes=485,cumulative_scope_EXE_metadata_bytes=268,cumulative_scope_EXE_read_calls=25,
 whole_EXE_hashes=0,neighbor_code_reads=0,new_game_or_SDK_actions=0)
(out/'READ-RECEIPT.actual.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
