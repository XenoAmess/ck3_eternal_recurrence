from pathlib import Path
import datetime as dt
import hashlib
import json
import struct
import capstone
R=Path(__file__).resolve().parent
def require(ok,message):
    if not ok:raise RuntimeError(message)
def new(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        if isinstance(value,str):f.write(value)
        else:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
planraw=(R/'plan-a02.json').read_bytes();plan=json.loads(planraw)
require(json.loads((R/'PLAN-A02-CHECK.actual.json').read_bytes())['returncode']==0,'Actual plan before source')
prior=json.loads((R/'source-read-a01/READ-RECEIPT.actual.json').read_bytes())
mapping=json.loads((R/'inputs/pe-layout-reused.json').read_bytes());ex=mapping['exception_directory']
cache={(row['rva'],row['bytes']):bytes.fromhex(row['metadata_hex']) for row in prior['read_ledger'] if row.get('metadata_hex') is not None}
entries={}
for (rva,count),raw in cache.items():
    if count==12 and ex['rva']<=rva<ex['rva']+ex['bytes'] and (rva-ex['rva'])%12==0:entries[(rva-ex['rva'])//12]=struct.unpack('<III',raw)
source=Path('C:/ck3-e04-resume-20261015-a01/frozen-game-12004/ck3.exe');before=source.stat()
require(before.st_size==101040248,'Exact frozen size differs')
out=R/'source-read-a02';out.mkdir(exist_ok=False);reads=[];code=0;meta=0
def offset(rva,count):
    for s in mapping['sections']:
        if s['va']<=rva and rva+count<=s['va']+s['rawsize']:return s['raw']+rva-s['va']
    raise RuntimeError('Unmapped exact thunk range')
report=dict(schema='xar.e04.actual-reached-thunk-source.v1',observed_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
            machine_id=plan['machine_id'],target_entry_rva=0x39798E0,plan_sha256=hashlib.sha256(planraw).hexdigest(),
            exact_identity_reused=plan['build'],whole_EXE_hashes=0,other_callee_or_neighbor_reads=0,game_or_SDK_actions=0)
try:
    with source.open('rb') as handle:
        def read(rva,count,kind,reason):
            global code,meta
            if kind=='metadata' and (rva,count) in cache:return cache[(rva,count)]
            require(len(reads)+20<48,'Cumulative read cap')
            if kind=='code':require(code+count+79<=8192,'Cumulative code cap');code+=count
            else:require(meta+count+220<=512,'Cumulative metadata cap');meta+=count
            handle.seek(offset(rva,count));raw=handle.read(count);require(len(raw)==count,'Short exact thunk read')
            reads.append(dict(rva=rva,file_offset=offset(rva,count),bytes=count,kind=kind,reason=reason,sha256=hashlib.sha256(raw).hexdigest(),metadata_hex=raw.hex() if kind=='metadata' else None))
            if kind=='metadata':cache[(rva,count)]=raw
            return raw
        def entry(i):
            require(0<=i<ex['entries'],'Actual exception index')
            if i not in entries:entries[i]=struct.unpack('<III',read(ex['rva']+i*12,12,'metadata','Only actual reached thunk exception entry'))
            return entries[i]
        lo,hi=0,ex['entries'];pc=0x39798E0
        while lo<hi:
            mid=(lo+hi)//2
            if entry(mid)[0]<=pc:lo=mid+1
            else:hi=mid
        idx=lo-1;begin,end,u=entry(idx)
        report['preceding_or_containing_pdata']=dict(index=idx,begin_rva=begin,end_rva=end,unwind_rva=u)
        if not begin<=pc<end:
            report['state']='NO_PDATA_FOR_EXACT_TARGET_METADATA_ONLY_NO_CODE_READ'
        else:
            h=read(u,4,'metadata','Actual reached thunk unwind header');report['unwind_flags']=h[0]>>3
            require(0<end-begin<=8192-79,'Actual thunk full extent exceeds admitted cap')
            raw=read(begin,end-begin,'code','Only actual reached39798E0 true .pdata body')
            with (out/'actual-thunk.bin').open('xb') as f:f.write(raw)
            d=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64);d.detail=True
            rows=list(d.disasm(raw,mapping['image_base']+begin));require(sum(i.size for i in rows)==len(raw),'Actual thunk bytes incompletely decoded')
            new(out/'actual-thunk.asm','\n'.join(f'{i.address-mapping["image_base"]:08X}  {i.bytes.hex(" "):<32} {i.mnemonic} {i.op_str}' for i in rows)+'\n')
            report.update(state='EXACT_TARGET_PDATA_BODY_CAPTURED',code_begin_rva=begin,code_end_rva=end,code_sha256=hashlib.sha256(raw).hexdigest())
    after=source.stat();require((before.st_size,before.st_ino,before.st_mtime_ns)==(after.st_size,after.st_ino,after.st_mtime_ns),'Frozen input changed')
except Exception as error:
    report.update(state='STOPPED_NO_FURTHER_READS',error=str(error))
finally:
    report.update(read_ledger=reads,new_EXE_code_bytes=code,new_EXE_metadata_bytes=meta,new_EXE_read_calls=len(reads),
                  cumulative_EXE_code_bytes=code+79,cumulative_EXE_metadata_bytes=meta+220,cumulative_EXE_read_calls=len(reads)+20)
    new(out/'READ-RECEIPT.actual.json',report);print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(2 if report['state']=='STOPPED_NO_FURTHER_READS' else 0)
