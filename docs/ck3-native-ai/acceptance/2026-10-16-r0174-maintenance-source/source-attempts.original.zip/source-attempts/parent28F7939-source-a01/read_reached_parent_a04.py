from pathlib import Path
import datetime as dt
import hashlib
import json
import struct
import time
import capstone
from capstone.x86 import X86_OP_IMM
R=Path(__file__).resolve().parent
def require(ok,message):
    if not ok:raise RuntimeError(message)
def new(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        if isinstance(value,str):f.write(value)
        else:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
planraw=(R/'plan-a04.json').read_bytes();plan=json.loads(planraw);b=plan['read_budget']
require(json.loads((R/'PLAN-A04-CHECK.actual.json').read_bytes())['returncode']==0,'Plan actual check before read')
previous=json.loads((R/'source-read-a02/READ-RECEIPT.actual.json').read_bytes())
mapping=json.loads((R/'inputs/pe-layout-reused.json').read_bytes())
source=Path('C:/ck3-e04-resume-20261015-a01/frozen-game-12004/ck3.exe')
before=source.stat();require(before.st_size==101040248,'Exact frozen file size differs')
out=R/'source-read-a04';out.mkdir(exist_ok=False)
cache={(row['rva'],row['bytes']):bytes.fromhex(row['metadata_hex']) for row in previous['read_ledger'] if row.get('metadata_hex') is not None}
for row in json.loads((R/'source-read-a03/FAILED-READ-RECEIPT.actual.json').read_bytes())['read_ledger']:
    if row.get('metadata_hex') is not None:cache[(row['rva'],row['bytes'])]=bytes.fromhex(row['metadata_hex'])
ex=mapping['exception_directory'];entries={}
for (rva,count),raw in cache.items():
    if count==12 and ex['rva']<=rva<ex['rva']+ex['bytes'] and (rva-ex['rva'])%12==0:
        entries[(rva-ex['rva'])//12]=struct.unpack('<III',raw)
reads=[];code=0;metadata=0;pieces=[];captured={};started=time.monotonic()
def offset(rva,count):
    for s in mapping['sections']:
        if s['va']<=rva and rva+count<=s['va']+s['rawsize']:return s['raw']+rva-s['va']
    raise RuntimeError('Unmapped finite source range')
try:
    with source.open('rb') as handle:
        def read(rva,count,kind,reason):
            global code,metadata
            if kind=='metadata' and (rva,count) in cache:return cache[(rva,count)]
            require(time.monotonic()-started<30 and len(reads)+24<48,'Cumulative wall/read cap')
            if kind=='code':
                require(code+count+265<=8192,'Cumulative code cap');code+=count
            else:
                require(metadata+count+248<=512,'Cumulative metadata cap');metadata+=count
            handle.seek(offset(rva,count));raw=handle.read(count);require(len(raw)==count,'Short finite read')
            reads.append(dict(rva=rva,file_offset=offset(rva,count),bytes=count,kind=kind,reason=reason,
                              sha256=hashlib.sha256(raw).hexdigest(),metadata_hex=raw.hex() if kind=='metadata' else None))
            if kind=='metadata':cache[(rva,count)]=raw
            return raw
        def entry(i):
            require(0<=i<ex['entries'],'Actual exception index bounds')
            if i not in entries:entries[i]=struct.unpack('<III',read(ex['rva']+i*12,12,'metadata','Only source-reached .pdata lookup'))
            return entries[i]
        def lookup(pc):
            lo,hi=0,ex['entries']
            while lo<hi:
                mid=(lo+hi)//2
                if entry(mid)[0]<=pc:lo=mid+1
                else:hi=mid
            i=lo-1;begin,end,u=entry(i);require(begin<=pc<end,'Reached PC has no actual .pdata span')
            h=read(u,4,'metadata','Reached piece unwind header')
            require(h[0]>>3&4,'Additional piece lacks declared same-root CHAININFO; stop before code')
            chain=struct.unpack('<III',read(u+4+((h[2]+1)//2)*4,12,'metadata','Reached piece actual chained root'))
            chain_path=[chain];seen=set()
            while chain[0]!=0x28F7840:
                require(chain not in seen and len(chain_path)<=4,'CHAININFO loop/depth; stop before code')
                seen.add(chain)
                header=read(chain[2],4,'metadata','Only explicit transitive CHAININFO header')
                require(header[0]>>3&4,'Transitive chain root differs; stop before code')
                chain=struct.unpack('<III',read(chain[2]+4+((header[2]+1)//2)*4,12,'metadata','Only explicit transitive CHAININFO link'))
                chain_path.append(chain)
            require(chain[1]==0x28F784C,'Actual primary extent differs')
            return begin,end,dict(pdata_index=i,unwind_rva=u,chained_runtime_function=chain_path[0],validated_chain_to_primary=chain_path)
        decoder=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64);decoder.detail=True
        for target in b['reached_pieces']:
            label=target['label']
            if label=='primary':begin,end=int(target['begin_rva'],16),int(target['end_rva_exclusive'],16);meta=dict(known_actual_chain_root=True)
            else:begin,end,meta=lookup(int(target['pc_rva'],16))
            if (begin,end) in captured:
                pieces.append(dict(label=label,same_piece_as=captured[(begin,end)],begin_rva=begin,end_rva=end));continue
            require(0<end-begin<=8192-265-code,'Full same-root piece exceeds cumulative extent cap')
            raw=read(begin,end-begin,'code','Only explicit same-root piece '+label);captured[(begin,end)]=label
            with (out/(label+'.bin')).open('xb') as f:f.write(raw)
            instructions=list(decoder.disasm(raw,mapping['image_base']+begin))
            require(sum(i.size for i in instructions)==len(raw),'Source reached piece not fully decoded')
            lines=[];calls=[];branches=[]
            for i in instructions:
                at=i.address-mapping['image_base'];lines.append(f'{at:08X}  {i.bytes.hex(" "):<32} {i.mnemonic} {i.op_str}')
                if i.operands and i.operands[0].type==X86_OP_IMM:
                    row=dict(at_rva=at,target_rva=i.operands[0].imm-mapping['image_base'],kind=i.mnemonic)
                    if i.mnemonic=='call':calls.append(row)
                    elif i.mnemonic.startswith('j'):branches.append(row)
            new(out/(label+'.asm'),'\n'.join(lines)+'\n')
            pieces.append(dict(label=label,begin_rva=begin,end_rva=end,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),metadata=meta,direct_calls=calls,branches=branches))
    after=source.stat();require((before.st_size,before.st_ino,before.st_mtime_ns)==(after.st_size,after.st_ino,after.st_mtime_ns),'Frozen source changed')
    receipt=dict(schema='xar.e04.R0174.actual-parent-reached-pieces.v1',machine_id=plan['machine_id'],observed_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                 plan_sha256=hashlib.sha256(planraw).hexdigest(),pieces=pieces,read_ledger=reads,
                 new_EXE_code_bytes=code,new_EXE_metadata_bytes=metadata,new_EXE_read_calls=len(reads),
                 cumulative_EXE_code_bytes=code+265,cumulative_EXE_metadata_bytes=metadata+248,cumulative_EXE_read_calls=len(reads)+24,
                 exact_EXE_identity_reused_not_rehashed=plan['build'],whole_image_hashes=0,callee_reads=0,neighbor_or_xref_scans=0,new_runtime_actions=0)
    new(out/'READ-RECEIPT.actual.json',receipt)
    print(json.dumps(receipt,ensure_ascii=False,indent=2))
except Exception as error:
    new(out/'FAILED-READ-RECEIPT.actual.json',dict(error=str(error),pieces=pieces,read_ledger=reads,new_EXE_code_bytes=code,new_EXE_metadata_bytes=metadata,new_EXE_read_calls=len(reads),cumulative_EXE_code_bytes=code+265,cumulative_EXE_metadata_bytes=metadata+248,cumulative_EXE_read_calls=len(reads)+24,further_reads_stopped=True))
    raise
