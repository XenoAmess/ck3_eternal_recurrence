# Research plan: R08-actual4-context108-vector-helper2C14D70

GENERATED from the supplied research plan; no native semantics are inferred.

Question: Doesactual2C14D70 connectcallercohort108/switch4A9 tosettlementcontext28/30,oronlybuildreturnedcostvectors?

```mermaid
flowchart TD
    n0["Held2C14440 +localclosure"]
    n1["Unknown2C14D70 exactbody"]
    n2["Secondarycontext28/30 relationunknown"]
    n0 -->|"call [static-confirmed] ActualrelativeCALL andargumentclosure"| n1
    n1 -. "relation [unknown] Typedfieldproducer/readrelation" .-> n2
```

| Edge | Declared status | Evidence IDs | Open question |
|---|---|---|---|
| call | static-confirmed | caller, upstreamcontract |  |
| relation | unknown | upstreamcontract | IsanytypedCharacter1C0+28/30 edgepresent? No paidlabel from rate/cohort naming. |

| Observation design | Value |
|---|---|
| mode | offline-only |
| actor_kind | engine |
| owner_scope | Static2C14D70 localclosure andresolvedpersistent argument only; no processmemory |
| identity_kind | definition-key |
| identity_lifetime | Immutable source exact4 only; no runtime eligibility |
| producer_trigger | not-applicable |
| producer | 2C14D70helperbodyunknown beforeauthorizedread |
| caller | Actual2C14440CALL2C14D70(RCX=&amp;localclosure,RDX=resolvedpersistent); closure0byte=Char1C0byte4A9,8factor,10ptrA,18ptrB |
| consumer | 2C142B0twoaccumulators thenreturnedcurrentcostvector; settlementc/drelationunknown |
| cache_lifetime | Callerlocalclosure/stackaccumulators validonlythisstaticinvocation; persistent/contextcacheepochsunknown |
| expected_signal | Onlyuniqueunchainedfull2C14D70 function; exactargument/branch/fieldlineage; externalcallee boundariesretained |
| zero_sample_meaning | Staticfunctioncapture hasno livepaymentsample; noabsenceorpaidclaim |
| stop_condition | Onlytarget2C14D70pdata binarysearch;metadata&lt;=512B/read&lt;=48;requirebeginexact2C14D70 uniqueunchainedextent&lt;=8192B beforebody. No automaticcallee/xref/neighbor/wholehash/SDK/game/desktop/build/main scope. |
| runtime_window_ref | None |

| Evidence ID | Declared layer | File | SHA-256 | Supports |
|---|---|---|---|---|
| identity | exact-build | C:\ck3-e04-resume-20261015-a01\frozen-game-12004\IDENTITY.actual.json | 15ad8093ca23930d7d440752518d3ce89097dec1b00fe234a5115011782b62b9 | Rootfrozen actual4inputSHA; no rehash |
| layout | exact-build | C:\ck3-e04-resume-20261015-a01\maintenance-parent-r0174-a01\parent28F7939-source-a01\inputs\pe-layout-reused.json | 9f0f3da5fcaf809b8fad13c4310d6abdf3c5a06d98aad113e907ee64c15e7bb4 | Existingsectionmapping andexceptiondirectoryonly |
| caller | source-contract | C:\ck3-e04-resume-20261015-a01\r08-second-vector2C142B0-source-a07\actual-function.asm | 2ed74f8a2ee912fdf484c1ce51eb47c343c6efef88d6496e62338fead875dfc6 | Held2751B2C142B0 actual2C14440CALL andlocalclosure stores; notexternalcontrolcontext |
| upstreamcontract | source-contract | C:\ck3-e04-resume-20261015-a01\r08-second-vector2C142B0-source-a07\SOURCE-CONTRACT.actual.json | 4cdbd5142a75dd3d6d06a09fc7919ac9935c63ff94a736af4afa4c370dd0973d | All62upstreambranches/typedpersistent andfourrawmappinglimits |

Check result (file integrity and declarations only):

```json
{
  "schema": "xar.native-research-plan-check.v1",
  "result": "plan-consistent",
  "proof_layer": "record-structure-and-file-integrity",
  "semantic_correctness_verified": false,
  "live_execution_performed": false,
  "observation_plan_issues": [
    "offline-only plan does not define a live observation window",
    "the real producer trigger must be located before live sampling"
  ],
  "declared_edges_by_status": {
    "counter-policy": 0,
    "inference": 0,
    "live-confirmed": 0,
    "static-confirmed": 1,
    "unknown": 1
  },
  "enumerated_native_edges": 2,
  "declared_cases_by_status": {
    "pending": 1,
    "observed": 0,
    "not-applicable": 0
  },
  "checked_evidence_files": 4,
  "limitations": [
    "Evidence layers and conclusions are author declarations; hashes bind bytes, not their truth.",
    "Counts cover this enumerated graph only, not all CK3 branches.",
    "A consistent observation plan is not authorization to run or manipulate CK3."
  ],
  "plan_sha256": "ede94e1ae9f69dc4d73a9d17a98f485c1889f3197d0b8b4c6a5308b33511e0d5"
}
```
