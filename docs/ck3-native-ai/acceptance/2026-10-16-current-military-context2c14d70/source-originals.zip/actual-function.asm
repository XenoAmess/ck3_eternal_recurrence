02C14D70  48 89 5c 24 08                               mov qword ptr [rsp + 8], rbx
02C14D75  48 89 7c 24 10                               mov qword ptr [rsp + 0x10], rdi
02C14D7A  55                                           push rbp
02C14D7B  48 8b ec                                     mov rbp, rsp
02C14D7E  48 83 ec 70                                  sub rsp, 0x70
02C14D82  83 7a 28 ff                                  cmp dword ptr [rdx + 0x28], -1
02C14D86  48 8b da                                     mov rbx, rdx
02C14D89  48 8b f9                                     mov rdi, rcx
02C14D8C  0f 85 18 01 00 00                            jne 0x2c14eaa
02C14D92  80 39 00                                     cmp byte ptr [rcx], 0
02C14D95  0f 84 f0 00 00 00                            je 0x2c14e8b
02C14D9B  48 8b ca                                     mov rcx, rdx
02C14D9E  e8 7d 81 a1 ff                               call 0x262cf20
02C14DA3  84 c0                                        test al, al
02C14DA5  0f 85 e0 00 00 00                            jne 0x2c14e8b
02C14DAB  48 8d 53 18                                  lea rdx, [rbx + 0x18]
02C14DAF  48 8b cb                                     mov rcx, rbx
02C14DB2  e8 29 79 a1 ff                               call 0x262c6e0
02C14DB7  84 c0                                        test al, al
02C14DB9  0f 84 cc 00 00 00                            je 0x2c14e8b
02C14DBF  41 b1 01                                     mov r9b, 1
02C14DC2  48 8d 55 b0                                  lea rdx, [rbp - 0x50]
02C14DC6  45 33 c0                                     xor r8d, r8d
02C14DC9  48 8b cb                                     mov rcx, rbx
02C14DCC  e8 3f 70 a1 ff                               call 0x262be10
02C14DD1  4c 8b 55 b0                                  mov r10, qword ptr [rbp - 0x50]
02C14DD5  b9 33 f3 04 b5                               mov ecx, 0xb504f333
02C14DDA  4c 8b 4f 08                                  mov r9, qword ptr [rdi + 8]
02C14DDE  48 ba 66 e6 09 6a 01 00 00 00                movabs rdx, 0x16a09e666
02C14DE8  49 8d 04 0a                                  lea rax, [r10 + rcx]
02C14DEC  48 3b c2                                     cmp rax, rdx
02C14DEF  77 35                                        ja 0x2c14e26
02C14DF1  49 8d 04 09                                  lea rax, [r9 + rcx]
02C14DF5  48 3b c2                                     cmp rax, rdx
02C14DF8  77 2c                                        ja 0x2c14e26
02C14DFA  48 8b 4f 10                                  mov rcx, qword ptr [rdi + 0x10]
02C14DFE  48 b8 09 e1 d1 c6 11 6b f1 29                movabs rax, 0x29f16b11c6d1e109
02C14E08  4d 0f af ca                                  imul r9, r10
02C14E0C  49 f7 e9                                     imul r9
02C14E0F  48 c1 fa 0e                                  sar rdx, 0xe
02C14E13  48 8b c2                                     mov rax, rdx
02C14E16  48 c1 e8 3f                                  shr rax, 0x3f
02C14E1A  48 03 d0                                     add rdx, rax
02C14E1D  48 89 55 b0                                  mov qword ptr [rbp - 0x50], rdx
02C14E21  e9 52 01 00 00                               jmp 0x2c14f78
02C14E26  4d 3b ca                                     cmp r9, r10
02C14E29  4d 8b c1                                     mov r8, r9
02C14E2C  4d 0f 4c c2                                  cmovl r8, r10
02C14E30  4d 0f 4f ca                                  cmovg r9, r10
02C14E34  49 ba 09 e1 d1 c6 11 6b f1 29                movabs r10, 0x29f16b11c6d1e109
02C14E3E  49 8b c2                                     mov rax, r10
02C14E41  49 f7 e8                                     imul r8
02C14E44  48 8b ca                                     mov rcx, rdx
02C14E47  48 c1 f9 0e                                  sar rcx, 0xe
02C14E4B  48 8b c1                                     mov rax, rcx
02C14E4E  48 c1 e8 3f                                  shr rax, 0x3f
02C14E52  48 03 c8                                     add rcx, rax
02C14E55  48 69 c1 a0 86 01 00                         imul rax, rcx, 0x186a0
02C14E5C  49 0f af c9                                  imul rcx, r9
02C14E60  4c 2b c0                                     sub r8, rax
02C14E63  49 8b c2                                     mov rax, r10
02C14E66  4d 0f af c1                                  imul r8, r9
02C14E6A  49 f7 e8                                     imul r8
02C14E6D  48 c1 fa 0e                                  sar rdx, 0xe
02C14E71  48 8b c2                                     mov rax, rdx
02C14E74  48 c1 e8 3f                                  shr rax, 0x3f
02C14E78  48 03 d0                                     add rdx, rax
02C14E7B  48 03 d1                                     add rdx, rcx
02C14E7E  48 8b 4f 10                                  mov rcx, qword ptr [rdi + 0x10]
02C14E82  48 89 55 b0                                  mov qword ptr [rbp - 0x50], rdx
02C14E86  e9 ed 00 00 00                               jmp 0x2c14f78
02C14E8B  41 b1 01                                     mov r9b, 1
02C14E8E  48 8d 55 b0                                  lea rdx, [rbp - 0x50]
02C14E92  45 33 c0                                     xor r8d, r8d
02C14E95  48 8b cb                                     mov rcx, rbx
02C14E98  e8 73 6f a1 ff                               call 0x262be10
02C14E9D  48 8b 55 b0                                  mov rdx, qword ptr [rbp - 0x50]
02C14EA1  48 8b 4f 10                                  mov rcx, qword ptr [rdi + 0x10]
02C14EA5  e9 ce 00 00 00                               jmp 0x2c14f78
02C14EAA  8b 82 34 01 00 00                            mov eax, dword ptr [rdx + 0x134]
02C14EB0  39 82 30 01 00 00                            cmp dword ptr [rdx + 0x130], eax
02C14EB6  0f 84 07 01 00 00                            je 0x2c14fc3
02C14EBC  45 33 c9                                     xor r9d, r9d
02C14EBF  48 8d 55 b0                                  lea rdx, [rbp - 0x50]
02C14EC3  41 b0 01                                     mov r8b, 1
02C14EC6  48 8b cb                                     mov rcx, rbx
02C14EC9  e8 42 6f a1 ff                               call 0x262be10
02C14ECE  4c 8b 4d b0                                  mov r9, qword ptr [rbp - 0x50]
02C14ED2  b9 33 f3 04 b5                               mov ecx, 0xb504f333
02C14ED7  4c 8b 5f 08                                  mov r11, qword ptr [rdi + 8]
02C14EDB  48 ba 66 e6 09 6a 01 00 00 00                movabs rdx, 0x16a09e666
02C14EE5  49 8d 04 09                                  lea rax, [r9 + rcx]
02C14EE9  48 3b c2                                     cmp rax, rdx
02C14EEC  77 2a                                        ja 0x2c14f18
02C14EEE  49 8d 04 0b                                  lea rax, [r11 + rcx]
02C14EF2  48 3b c2                                     cmp rax, rdx
02C14EF5  77 21                                        ja 0x2c14f18
02C14EF7  4d 0f af cb                                  imul r9, r11
02C14EFB  48 b8 09 e1 d1 c6 11 6b f1 29                movabs rax, 0x29f16b11c6d1e109
02C14F05  49 f7 e9                                     imul r9
02C14F08  48 c1 fa 0e                                  sar rdx, 0xe
02C14F0C  48 8b c2                                     mov rax, rdx
02C14F0F  48 c1 e8 3f                                  shr rax, 0x3f
02C14F13  48 03 d0                                     add rdx, rax
02C14F16  eb 58                                        jmp 0x2c14f70
02C14F18  4d 3b d9                                     cmp r11, r9
02C14F1B  4d 8b c3                                     mov r8, r11
02C14F1E  49 ba 09 e1 d1 c6 11 6b f1 29                movabs r10, 0x29f16b11c6d1e109
02C14F28  4d 0f 4c c1                                  cmovl r8, r9
02C14F2C  4d 0f 4f d9                                  cmovg r11, r9
02C14F30  49 8b c2                                     mov rax, r10
02C14F33  49 f7 e8                                     imul r8
02C14F36  48 8b ca                                     mov rcx, rdx
02C14F39  48 c1 f9 0e                                  sar rcx, 0xe
02C14F3D  48 8b c1                                     mov rax, rcx
02C14F40  48 c1 e8 3f                                  shr rax, 0x3f
02C14F44  48 03 c8                                     add rcx, rax
02C14F47  48 69 c1 a0 86 01 00                         imul rax, rcx, 0x186a0
02C14F4E  49 0f af cb                                  imul rcx, r11
02C14F52  4c 2b c0                                     sub r8, rax
02C14F55  49 8b c2                                     mov rax, r10
02C14F58  4d 0f af c3                                  imul r8, r11
02C14F5C  49 f7 e8                                     imul r8
02C14F5F  48 c1 fa 0e                                  sar rdx, 0xe
02C14F63  48 8b c2                                     mov rax, rdx
02C14F66  48 c1 e8 3f                                  shr rax, 0x3f
02C14F6A  48 03 d0                                     add rdx, rax
02C14F6D  48 03 d1                                     add rdx, rcx
02C14F70  48 8b 4f 18                                  mov rcx, qword ptr [rdi + 0x18]
02C14F74  48 89 55 b0                                  mov qword ptr [rbp - 0x50], rdx
02C14F78  48 01 11                                     add qword ptr [rcx], rdx
02C14F7B  48 8b 45 b8                                  mov rax, qword ptr [rbp - 0x48]
02C14F7F  48 01 41 08                                  add qword ptr [rcx + 8], rax
02C14F83  48 8b 45 c0                                  mov rax, qword ptr [rbp - 0x40]
02C14F87  48 01 41 10                                  add qword ptr [rcx + 0x10], rax
02C14F8B  48 8b 45 c8                                  mov rax, qword ptr [rbp - 0x38]
02C14F8F  48 01 41 18                                  add qword ptr [rcx + 0x18], rax
02C14F93  48 8b 45 d0                                  mov rax, qword ptr [rbp - 0x30]
02C14F97  48 01 41 20                                  add qword ptr [rcx + 0x20], rax
02C14F9B  48 8b 45 d8                                  mov rax, qword ptr [rbp - 0x28]
02C14F9F  48 01 41 28                                  add qword ptr [rcx + 0x28], rax
02C14FA3  48 8b 45 e0                                  mov rax, qword ptr [rbp - 0x20]
02C14FA7  48 01 41 30                                  add qword ptr [rcx + 0x30], rax
02C14FAB  48 8b 45 e8                                  mov rax, qword ptr [rbp - 0x18]
02C14FAF  48 01 41 38                                  add qword ptr [rcx + 0x38], rax
02C14FB3  48 8b 45 f0                                  mov rax, qword ptr [rbp - 0x10]
02C14FB7  48 01 41 40                                  add qword ptr [rcx + 0x40], rax
02C14FBB  48 8b 45 f8                                  mov rax, qword ptr [rbp - 8]
02C14FBF  48 01 41 48                                  add qword ptr [rcx + 0x48], rax
02C14FC3  4c 8d 5c 24 70                               lea r11, [rsp + 0x70]
02C14FC8  49 8b 5b 10                                  mov rbx, qword ptr [r11 + 0x10]
02C14FCC  49 8b 7b 18                                  mov rdi, qword ptr [r11 + 0x18]
02C14FD0  49 8b e3                                     mov rsp, r11
02C14FD3  5d                                           pop rbp
02C14FD4  c3                                           ret 
