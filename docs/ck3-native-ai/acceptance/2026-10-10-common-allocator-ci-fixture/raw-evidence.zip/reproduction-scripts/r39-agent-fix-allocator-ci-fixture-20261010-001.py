"""Retain targeted test results outside the shared checkout."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys

REPO=Path('C:/workspace/ck3_eternal_recurrence')
OUT=Path('C:/workspace/ck3_lyd_runtime_20261004/r39-common-allocator-ci-fixture-fix-20261010-001')
OUT.mkdir(exist_ok=True)
phase=sys.argv[1]
if phase=='before':
    tests=['-m','unittest','discover','-s','tools','-p','test_ck3_mod_acceptance_adapters.py','-k',
           'test_mocked_allocation_register_immediately_starts_original_keeper','-v']
elif phase=='after':
    tests=['-m','unittest','discover','-s','tools','-p','test_ck3_mod_acceptance_adapters.py','-v']
elif phase=='bootstrap':
    tests=['-m','unittest','discover','-s','tools','-p','test_ck3_mod_acceptance_bootstrap.py','-v']
elif phase=='entry':
    tests=['-m','unittest','discover','-s','tools','-p','test_ck3_mod_acceptance.py','-v']
else:
    raise ValueError('Unknown bounded test phase')
argv=[sys.executable,'-B','-X','utf8',*tests]
started=datetime.now(timezone.utc).isoformat()
result=subprocess.run(argv,cwd=REPO,capture_output=True)
for name,raw in (('stdout',result.stdout),('stderr',result.stderr)):
    (OUT/(phase+'.'+name+'.log')).open('xb').write(raw)
pins={}
for relative in ('tools/test_ck3_mod_acceptance_adapters.py','tools/ck3_mod_acceptance_allocate.py','tools/ck3_live_run_id.py'):
    raw=(REPO/relative).read_bytes();pins[relative]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
value={'schema':'ck3.common-allocator-ci-fixture-regression.v1','phase':phase,'argv':argv,
       'started_at_utc':started,'finished_at_utc':datetime.now(timezone.utc).isoformat(),
       'exit_code':result.returncode,'source_pins':pins,'ck3_or_steam_started':False,
       'actual_machine_id_or_admission_state_used':False,'workflow_dispatch_performed':False}
with (OUT/(phase+'.actual.json')).open('x',encoding='utf-8',newline='\n') as stream:
    json.dump(value,stream,indent=2);stream.write('\n')
print(json.dumps(value),flush=True)
print(result.stderr.decode('utf-8',errors='replace'),flush=True)
raise SystemExit(result.returncode)
