"""Complete an observed terminal run's evidence; no checkout mutation."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import time

OUT = Path('C:/workspace/ck3_lyd_runtime_20261004/r39-exact-00b88fc4d-ci-20261010-001')
REPO = 'XenoAmess/ck3_eternal_recurrence'
RUN = '37979055544'


def write(name, value):
    with (OUT / name).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


jobs = None
for attempt in range(1, 4):
    label = 'terminal-official-jobs-retry-' + str(attempt).zfill(3)
    argv = ['gh', 'api', 'repos/' + REPO + '/actions/runs/' + RUN + '/jobs?per_page=100']
    start = datetime.now(timezone.utc).isoformat()
    try:
        result = subprocess.run(argv, cwd=OUT, capture_output=True, timeout=45)
        raw, err, code, error = result.stdout, result.stderr, result.returncode, None
    except subprocess.TimeoutExpired as exc:
        raw, err, code, error = exc.stdout or b'', exc.stderr or b'', None, 'timeout_45_seconds'
    (OUT / (label + '.stdout.json')).write_bytes(raw)
    (OUT / (label + '.stderr.log')).write_bytes(err)
    write(label + '.actual.json', {
        'argv': argv, 'started_at_utc': start, 'finished_at_utc': datetime.now(timezone.utc).isoformat(),
        'exit_code': code, 'error': error, 'stdout_bytes': len(raw),
        'stdout_sha256': hashlib.sha256(raw).hexdigest(), 'stderr_bytes': len(err),
        'stderr_sha256': hashlib.sha256(err).hexdigest(),
    })
    if code == 0:
        jobs = json.loads(raw)
        break
    print(json.dumps({'retry': attempt, 'exit_code': code, 'error': err.decode(errors='replace')[:200]}), flush=True)
    if attempt < 3:
        time.sleep(10)

checked = []
for path in sorted(OUT.glob('*.actual.json')):
    value = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(value, dict) or 'argv' not in value or 'stdout_sha256' not in value:
        continue
    prefix = path.name[:-len('.actual.json')]
    rawpaths = list(OUT.glob(prefix + '.stdout.*'))
    if len(rawpaths) != 1:
        raise RuntimeError('Ambiguous raw stdout for ' + prefix)
    errpath = OUT / (prefix + '.stderr.log')
    if hashlib.sha256(rawpaths[0].read_bytes()).hexdigest() != value['stdout_sha256']:
        raise RuntimeError('Changed stdout: ' + prefix)
    if hashlib.sha256(errpath.read_bytes()).hexdigest() != value['stderr_sha256']:
        raise RuntimeError('Changed stderr: ' + prefix)
    checked.append(prefix)
report = {
    'schema': 'ck3.exact-github-ci-completed-diagnostic.v1',
    'head_sha': '00b88fc4df0b8b4cea8b15ff85de8f244825a329',
    'observed_at_utc': datetime.now(timezone.utc).isoformat(),
    'official': {'run_id': int(RUN), 'conclusion': 'failure',
                 'failed_jobs': [{'id': item['id'], 'name': item['name'],
                                  'conclusion': item['conclusion'],
                                  'failed_steps': [step['name'] for step in item.get('steps', [])
                                                   if step.get('conclusion') == 'failure']}
                                 for item in (jobs or {}).get('jobs', [])
                                 if item.get('conclusion') == 'failure']},
    'linear_history': 'success', 'li_yu_dao_static_checks': 'NOT_TRIGGERED',
    'failure_test': 'Focused.test_mocked_allocation_register_immediately_starts_original_keeper',
    'failure_source': 'tools/test_ck3_mod_acceptance_adapters.py:356 -> tools/ck3_mod_acceptance_allocate.py:58',
    'actual_exception': "AttributeError: 'types.SimpleNamespace' object has no attribute 'MACHINE_ENV'",
    'inference_from_traceback': 'The mocked ids helper does not model the required machine-binding interface.',
    'test_fixture_not_changed': True, 'source_not_changed': True,
    'local_launch_ten_tests': 'OK in actual official failure log',
    'bootstrap_ten_tests': 'OK in actual official failure log',
    'original_api_stdout_and_stderr_hashes_verified_count': len(checked),
    'verified_query_labels': checked,
    'repository_mutation_performed': False, 'workflow_dispatch_performed': False,
}
write('DIAGNOSTIC.actual.json', report)
print(json.dumps(report), flush=True)
