from __future__ import annotations

import collections
import hashlib
import importlib.util
import json
from datetime import datetime, timezone
from pathlib import Path

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r40-startup-readonly-diagnostic-20261010-001'
RUNS = Path('C:/workspace/ck3-common-runtime/runs')
L = RUNS / 'bf-202609141645-5434332d4d--li-yu-dao--R0040'
L39 = RUNS / 'bf-202609141645-5434332d4d--li-yu-dao--R0039'
HELPER = BASE / 'r39_saved_loading_timing_diagnostic_20261010_001.py'
spec = importlib.util.spec_from_file_location('r39_readonly_file_cuts', HELPER)
cuts = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cuts)
ref = cuts.ref


def put(name, value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    p = OUT / name
    with p.open('xb') as f:
        f.write(raw)
    return ref(p, raw)


def compact(row, index):
    s = row['snapshot']
    d = s.get('diagnostics', {})
    h = d.get('last_heartbeat') or {}
    m = h.get('main_thread_query_mailbox_v1') or {}
    o = h.get('snapshot_observer_12002') or {}
    p = s.get('played_character') or {}
    return {'observation_index_zero_based': index,
        'snapshot': {k: s.get(k) for k in ['snapshot_id', 'revision', 'native_revision',
            'date_raw', 'paused', 'map_ready', 'local_player_id', 'active_event', 'episode_projection']},
        'actor_character_id': p.get('character_id'), 'actor_alive': p.get('alive'),
        'frame': row.get('frame'), 'campaign_root': row.get('campaign_root'), 'binding': row.get('binding'),
        'heartbeat': {k: h.get(k) for k in ['sequence', 'monotonic_ms', 'pid']},
        'mailbox': {k: m.get(k) for k in ['pump_epochs', 'owner_verified_pump_epochs', 'owner_tid',
            'current_tid', 'ready', 'stamp_read_success', 'consecutive_verified', 'jomini_state',
            'game_state', 'published_sequence', 'completed_sequence', 'executor_started_requests']},
        'observer': o, 'connected': d.get('connected'),
        'bridge_pid': d.get('bridge_pid'), 'connection_generation': d.get('connection_generation')}


def main():
    p = L / 'native-report.json'
    raw = p.read_bytes()
    report = json.loads(raw)
    restore = report['saved_campaign_restore']
    rows = restore['observations']
    session = report['session']['report']
    created = datetime.strptime(session['shutdown']['ck3_creation_date'], '%Y%m%d%H%M%S.%f+000').replace(tzinfo=timezone.utc)
    first_ready = next((i for i, row in enumerate(rows) if row.get('frame') is not None), None)
    ready_rows = [row for row in rows if row.get('frame') is not None]
    frozen_path = L / 'frozen-argv.json'
    frozen_raw = frozen_path.read_bytes()
    frozen = json.loads(frozen_raw)
    prior_frozen_path = L39 / 'frozen-argv.json'
    prior_frozen_raw = prior_frozen_path.read_bytes()
    prior_frozen = json.loads(prior_frozen_raw)
    pinned_comparison = []
    for path, pin in frozen['files'].items():
        if path.lower().endswith(('xar_ck3_bridge.dll', 'xar_ck3_bridge_injector.exe', 'run_ck3_12002_mcp_live.py')):
            pinned_comparison.append({'path': path, 'R40': pin, 'R39': prior_frozen['files'].get(path),
                                     'equal': pin == prior_frozen['files'].get(path)})
    attach38_path = BASE / 'live-attempt-038/native-evidence/e028ff7e81f5455e8681862850741e72/0001-attach.json'
    attach38_raw = attach38_path.read_bytes()
    attach38 = json.loads(attach38_raw)
    injector38 = attach38['injector']
    injector40 = session['injector_attestation']
    wire_path = L / 'native-report.native-wire.jsonl'
    wire_hash = hashlib.sha256()
    wire_size = 0
    wire_counts = collections.Counter()
    states = []
    last_heartbeat = None
    with wire_path.open('rb') as f:
        for line_no, line in enumerate(f, 1):
            wire_hash.update(line)
            wire_size += len(line)
            entry = json.loads(line)
            m = entry['message']
            wire_counts[m.get('type')] += 1
            if m.get('type') == 'state_snapshot':
                state = m.get('state') or {}
                states.append({'line': line_no, 'at': entry['at'],
                    'snapshot_id': m.get('snapshot_id'), 'revision': m.get('revision'),
                    'state': {k: state.get(k) for k in ['date_raw', 'paused', 'map_ready',
                        'local_player_id', 'played_character', 'active_event']}})
            if m.get('type') == 'heartbeat':
                mailbox = m.get('main_thread_query_mailbox_v1') or {}
                last_heartbeat = {'line': line_no, 'at': entry['at'],
                    'sequence': m.get('sequence'), 'monotonic_ms': m.get('monotonic_ms'),
                    'pump_epochs': mailbox.get('pump_epochs'),
                    'snapshot_observer_12002': m.get('snapshot_observer_12002')}
    release_path = L / 'release-command-001/stdout.log'
    release_raw = release_path.read_bytes()
    release = json.loads(release_raw)
    logroot = Path(report['profile']['prepared_manifest']).parent / 'logs'
    log = cuts.log_cut(logroot / 'debug.log', '2026-10-10', created)
    OUT.mkdir(exist_ok=False)
    log_ref = put('LOG-CUTS.actual.json', {
        'R40': log, 'error_log': ref(logroot / 'error.log'),
        'setup_perf_log_present': (logroot / 'setup_perf.log').exists(),
        'R38_R39_original_comparison': ref(BASE / 'r39-saved-startup-loading-timing-diagnostic-20261010-001/LOG-CUTS.actual.json')})
    source_ref = put('SOURCE-CUTS.actual.json', {
        'retained_handle_and_launch_api': cuts.source_cut(Path('C:/csr3/ck3_autonomous_player/src/xar_autoplayer/runtime.py'),
            [(98, 123), (2536, 2570), (2667, 2705), (2802, 2836), (2966, 3030), (3066, 3082)]),
        'existing_warmup_is_separate_process': cuts.source_cut(Path('C:/csr3/ck3_autonomous_player/src/xar_autoplayer/native_session.py'),
            [(553, 584), (1014, 1044)]),
        'saved_admission_second_pump_gate': cuts.source_cut(Path('C:/csr3/ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py'),
            [(802, 827)]),
    })
    result_ref = put('REPORT.actual.json', {
        'schema': 'lyd.r40.readonly-startup-diagnostic.v1', 'native_report': ref(p, raw),
        'frozen_argv': ref(frozen_path, frozen_raw), 'R39_frozen_argv': ref(prior_frozen_path, prior_frozen_raw),
        'same_runtime_manifest': frozen['runtime_manifest'] == prior_frozen['runtime_manifest'],
        'runtime_manifest': frozen['runtime_manifest'], 'fixed_native_source_pins': pinned_comparison,
        'started_at': report['started_at'], 'finished_at': report['finished_at'],
        'status': report['status'], 'error': report['error'], 'steps': report['steps'],
        'startup_observation_count': len(restore['startup_observations']),
        'startup_first': restore['startup_observations'][0], 'startup_last': restore['startup_observations'][-1],
        'saved_observation_count': len(rows), 'map_false_count': sum(row['snapshot'].get('map_ready') is False for row in rows),
        'candidate_frame_count': len(ready_rows), 'root_query_count': sum(row.get('campaign_root') is not None for row in rows),
        'binding_count': sum(row.get('binding') is not None for row in rows),
        'first': compact(rows[0], 0),
        'first_candidate_frame': compact(rows[first_ready], first_ready) if first_ready is not None else None,
        'last': compact(rows[-1], len(rows) - 1),
        'candidate_pump_epochs': sorted({row['frame']['pump_epoch'] for row in ready_rows}),
        'native_wire': {'path': str(wire_path), 'bytes': wire_size, 'sha256': wire_hash.hexdigest()},
        'native_wire_type_counts': dict(wire_counts), 'native_state_frames': states, 'last_wire_heartbeat': last_heartbeat,
        'R40_launch': report['saved_campaign_launch'], 'R40_creation_utc': created.isoformat(),
        'R40_injector': {k: injector40[k] for k in ['creation_utc', 'argv', 'status', 'returncode', 'complete_process_tree_proven']},
        'R38_attach': ref(attach38_path, attach38_raw),
        'R38_injector': {k: injector38[k] for k in ['creation_utc', 'argv', 'status', 'returncode', 'complete_process_tree_proven']},
        'R38_setup_completion_utc': '2026-10-09T13:29:31+00:00',
        'R38_setup_completion_to_injection_seconds': 2557.464,
        'log_cuts': log_ref, 'source_cuts': source_ref,
        'actual_release_stdout': ref(release_path, release_raw), 'release_parsed': release,
        'shutdown': {k: session['shutdown'][k] for k in ['ck3_pid', 'ck3_creation_date', 'ck3_exit_code', 'tree_gone', 'cleanup_proven']},
        'managed_session_done': report['managed_session_done'], 'cleanup_ok': report['cleanup_ok'],
        'conclusions': {
            'exact_final_gate': 'wait_for_saved_campaign line806 requires a second equal admission frame with strictly advancing pump epoch; all 50 candidate frames stay at 27770, so campaign_root and handler were not reached.',
            'late_native_frame_is_loading_completion_proof': False,
            'R40_loading_log_completion': 'No In Game or Setup completion marker is present before managed cleanup, despite the later valid map/actor/event candidate frame.',
            'early_injection_cause': None,
            'causal_hypothesis': 'Pre-resume bridge installation may interact with loading/main-thread progress. R38 injected after completed loading, R39/40 before primary-thread resume. These runs also differ in DLL and debug-mode CLI, so this is not a controlled causal proof.',
            'existing_same_pid_delayed_injection_public_api': None,
            'existing_frontend_first_mode': 'Stops warmup and starts a new save-loading process; it is not a same-PID delayed-injection API.',
            'minimal_testable_shared_route': [
                'Add a narrow explicit deferred injection policy to launch/native_session; retain the original child environment, PID/process HANDLE, Job, watchdog and unchanged CLI.',
                'Resume the authenticated CK3 process once without calling the injector; wait boundedly for a current cleared-log-epoch load-completion marker while preserving stop/cleanup and lease checks.',
                'Use the existing contained injector and evidence logic once against that retained process, under the existing before_process_create/CAS callback; do not invoke launch or resume again.',
                'Use the original native pipe and require original exact native identity/map/actor/date/pump/root/typed startup handler admission. Log evidence grants only permission to inject.',
                'Test call ordering and retained PID/Job/watchdog identity, and missing-marker/error cleanup with zero injection; any live confirmation requires a separate explicitly authorized new run.'
            ],
            'existing_CLI_for_delayed_route': None, 'budget_changed': False,
            'additional_time_guarantees_success': None, 'business_pass': False, 'normal_exit_zero': False},
        'actions': {'file_reads_only': True, 'new_external_output_only': True, 'SDK': 0, 'game': 0,
            'process_queries': 0, 'screen': 0, 'bus': 0, 'save_body_reads': 0, 'main_edits': 0,
            'source_edits': 0, 'git': 0, 'build': 0}})
    index = put('INDEX.json', {'schema': 'lyd.readonly-diagnostic-index.v1', 'author': ref(Path(__file__)),
        'author_dependency': ref(HELPER), 'files': [log_ref, source_ref, result_ref], 'runtime_actions': 0})
    print(json.dumps({'report': result_ref, 'index': index}, ensure_ascii=True))


if __name__ == '__main__':
    main()
