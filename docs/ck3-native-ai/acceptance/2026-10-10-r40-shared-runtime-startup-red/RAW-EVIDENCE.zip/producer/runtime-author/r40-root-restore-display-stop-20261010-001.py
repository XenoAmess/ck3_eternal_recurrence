from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
import win32api, win32con, pyautogui

run = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0040')
keeper = Path('C:/workspace/ck3-common-runtime/keepers/20261010-a02')
def put(path, obj):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(obj, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
image = run / 'steam-final-recovery-001/probe-1/steam-moved.png'
put(run / 'steam-final-recovery-001/OFFLINE-REVIEW.actual.json', {
    'at_utc': datetime.now(timezone.utc).isoformat(),
    'path': str(image), 'bytes': image.stat().st_size,
    'sha256': hashlib.sha256(image.read_bytes()).hexdigest(),
    'review_method': 'root directly viewed original 1920x1080 screenshot after actual 20 px Steam window movement',
    'visible_offline_text': '离线模式', 'steam_offline_confirmed': True,
    'visible_desktop_clock': '4:56 2026/10/10',
})
original = json.loads((run / 'display-fit-001.json').read_bytes())['before']
def describe(mode):
    return {'width': mode.PelsWidth, 'height': mode.PelsHeight,
            'bits': mode.BitsPerPel, 'frequency': mode.DisplayFrequency}
before = describe(win32api.EnumDisplaySettings(None, win32con.ENUM_CURRENT_SETTINGS))
chosen = None
for index in range(1000):
    try:
        mode = win32api.EnumDisplaySettings(None, index)
    except Exception:
        break
    if describe(mode) == original:
        chosen = mode
        break
if chosen is None:
    raise RuntimeError('Original display mode not enumerated')
if win32api.ChangeDisplaySettingsEx(None, chosen, win32con.CDS_TEST) != 0:
    raise RuntimeError('Original display mode test failed')
rc = win32api.ChangeDisplaySettingsEx(None, chosen, 0)
after = describe(win32api.EnumDisplaySettings(None, win32con.ENUM_CURRENT_SETTINGS))
size = list(pyautogui.size())
put(run / 'display-restore-001.json', {
    'at_utc': datetime.now(timezone.utc).isoformat(), 'before': before,
    'original': original, 'change_result': rc, 'after': after,
    'pyautogui_size': size, 'registry_persistence_requested': False,
})
if rc != 0 or after != original or size != [original['width'], original['height']]:
    raise RuntimeError('Display actual readback mismatch')
put(keeper / 'STOP', {
    'at_utc': datetime.now(timezone.utc).isoformat(),
    'reason': 'R40 startup readiness RED; host managed cleanup proved process tree gone with CK3 exit 1; final Steam offline visually reviewed; original display restored',
    'normal_exit_zero_claimed': False,
})
print(json.dumps({'display_restored': after, 'keeper_stop_requested': True}))
