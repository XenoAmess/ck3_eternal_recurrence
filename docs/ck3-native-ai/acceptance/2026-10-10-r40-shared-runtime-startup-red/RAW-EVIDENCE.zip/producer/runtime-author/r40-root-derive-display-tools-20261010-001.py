from pathlib import Path
import hashlib, json
base = Path('C:/workspace/ck3_lyd_runtime_20261004')
rows = []
for kind in ('desktop', 'steam-window'):
    old = base / ('r39-root-fit-' + kind + '-20261010-001.py')
    new = base / ('r40-root-fit-' + kind + '-20261010-001.py')
    text = old.read_text(encoding='utf-8')
    assert text.count('--R0039') == 1
    text = text.replace('--R0039', '--R0040')
    with new.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
    rows.append({'old': str(old), 'old_sha256': hashlib.sha256(old.read_bytes()).hexdigest(),
                 'new': str(new), 'new_sha256': hashlib.sha256(new.read_bytes()).hexdigest(),
                 'only_change': 'run directory R0039 to R0040'})
with (base / 'r40-root-display-tools-derivation-20261010-001.json').open('x', encoding='utf-8') as stream:
    json.dump(rows, stream, indent=2)
print(json.dumps(rows))
