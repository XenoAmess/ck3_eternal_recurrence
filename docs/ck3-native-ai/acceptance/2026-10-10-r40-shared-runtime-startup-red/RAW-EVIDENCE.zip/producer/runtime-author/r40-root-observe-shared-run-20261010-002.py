from pathlib import Path
from datetime import datetime, timezone
import json
run=Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0040')
state=Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-002/state')
rows={}
for relative in ('host-started.json','host-original-process-exit.json','case-output/entry-run-result.json',
                 'case-output/case-error-preserved.json','case-output/transaction-control-case-result.json',
                 'case-output/normal-close-result.json','native-report.json'):
    path=run/relative
    if not path.exists():
        rows[relative]={'exists':False}
        continue
    raw=path.read_bytes();obj=json.loads(raw)
    if relative=='native-report.json':
        native=(obj.get('session') or {}).get('report') or {}
        rows[relative]={'status':obj.get('status'),'phase':obj.get('phase'),'error':obj.get('error'),
            'finished_at':obj.get('finished_at'),'step_count':len(obj.get('steps',[])),
            'managed_session_done':obj.get('managed_session_done'),
            'managed_session_thread_finished':obj.get('managed_session_thread_finished'),
            'cleanup_ok':obj.get('cleanup_ok'),'shutdown':native.get('shutdown')}
    else:
        rows[relative]=obj if len(raw)<5000 else {'bytes':len(raw),'keys':list(obj)}
path=state/'profile/logs/system.log'
if path.exists():
    with path.open('rb') as stream:
        stream.seek(max(0,path.stat().st_size-12000))
        text=stream.read().decode('utf-8',errors='replace')
    rows['system.log.tail']=text.splitlines()[-8:]
path=run/'public-run-command-001/stderr.log'
rows['entry.stderr']={'exists':path.exists(),'bytes':path.stat().st_size if path.exists() else None}
print(json.dumps({'at_utc':datetime.now(timezone.utc).isoformat(),'observed':rows},ensure_ascii=False,indent=2))
