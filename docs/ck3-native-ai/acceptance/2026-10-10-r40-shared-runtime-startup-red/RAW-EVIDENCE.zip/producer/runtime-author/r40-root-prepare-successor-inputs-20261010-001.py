from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
old = Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-001/prepare-inputs.json')
new = Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-002')
raw = old.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'cdf3fb3f9d6ba24c8cb8892937f5ebde83be4231ae1542866a6c6c53f812695e'
data = json.loads(raw)
new.mkdir(exist_ok=False)
previous_state = data['state_dir']
data['state_dir'] = str(new / 'state')
def put(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
put(new / 'prepare-inputs.json', data)
put(new / 'INPUT-PROVENANCE.actual.json', {
    'at_utc': datetime.now(timezone.utc).isoformat(),
    'original': {'path': str(old), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()},
    'only_input_change': {'field': 'state_dir', 'before': previous_state, 'after': data['state_dir']},
    'same_fixed_saved_campaign': True, 'same_formal_product_and_overlay': True,
    'old_run_and_profile_preserved': True, 'state_dir_existed': Path(data['state_dir']).exists(),
    'shared_manifest': 'C:/workspace/ck3-common-runtime/20261010-002/manifest.json',
    'machine_bootstrap_repeat_allowed': False,
    'business_credit': False, 'game_started': False,
})
print(json.dumps({'case_inputs': str(new / 'prepare-inputs.json'), 'state_dir': data['state_dir']}))
