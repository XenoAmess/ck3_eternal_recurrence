from pathlib import Path
from datetime import datetime, timezone
import json
run=Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0040')
logs=Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-002/state/profile/logs')
out={'at_utc':datetime.now(timezone.utc).isoformat()}
for rel in ('host-original-process-exit.json','case-output/entry-run-result.json',
            'case-output/case-error-preserved.json','case-output/transaction-control-case-result.json',
            'case-output/normal-close-result.json','native-report.json'):
    path=run/rel
    if not path.exists():
        out[rel]=None
        continue
    obj=json.loads(path.read_bytes())
    if rel=='native-report.json':
        native=(obj.get('session') or {}).get('report') or {}
        out[rel]={key:obj.get(key) for key in ('status','phase','error','finished_at',
            'managed_session_done','managed_session_thread_finished','cleanup_ok')}
        out[rel].update(step_count=len(obj.get('steps',[])),shutdown=native.get('shutdown'))
    else:
        out[rel]=obj
for name in ('debug.log','error.log'):
    path=logs/name
    if path.exists():
        with path.open('rb') as stream:
            stream.seek(max(0,path.stat().st_size-12000))
            lines=stream.read().decode('utf-8',errors='replace').splitlines()
        out[name]={'bytes':path.stat().st_size,'tail':lines[-8:]}
print(json.dumps(out,ensure_ascii=False,indent=2))
