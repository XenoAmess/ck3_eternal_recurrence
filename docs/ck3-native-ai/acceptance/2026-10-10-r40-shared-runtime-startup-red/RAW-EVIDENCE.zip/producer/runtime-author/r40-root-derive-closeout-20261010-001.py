from pathlib import Path
import hashlib, json, subprocess, sys
base=Path('C:/workspace/ck3_lyd_runtime_20261004')
old=base/'r39-root-restore-display-stop-20261010-001.py'
new=base/'r40-root-restore-display-stop-20261010-001.py'
raw=old.read_bytes();text=raw.decode('utf-8')
text=text.replace('--R0039','--R0040').replace('20261010-a01','20261010-a02').replace('R39 startup','R40 startup').replace('4:00 2026/10/10','4:56 2026/10/10')
report=json.loads(Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0040/native-report.json').read_bytes())
assert report['status']=='RED' and report['cleanup_ok'] is True and report['managed_session_thread_finished'] is True
assert report['session']['report']['shutdown']['tree_gone'] is True
assert report['session']['report']['shutdown']['ck3_exit_code']==1
with new.open('x',encoding='utf-8',newline='\n') as stream:stream.write(text)
with (base/'r40-root-closeout-derivation-20261010-001.json').open('x',encoding='utf-8') as stream:
    json.dump({'source':str(old),'source_sha256':hashlib.sha256(raw).hexdigest(),
        'destination':str(new),'sha256':hashlib.sha256(new.read_bytes()).hexdigest(),
        'actual_red_and_tree_cleanup_checked':True,'changes':['run id','keeper path','actual reviewed desktop clock','actual failed run reason']},stream,indent=2)
raise SystemExit(subprocess.run([sys.executable,'-B','-X','utf8',str(new)],check=False).returncode)
