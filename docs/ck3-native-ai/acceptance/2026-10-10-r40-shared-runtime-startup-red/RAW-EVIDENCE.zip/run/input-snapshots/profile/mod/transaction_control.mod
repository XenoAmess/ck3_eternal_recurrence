version="0.0.1"
name="LYD Factory Operation Diagnostic - DEVELOPMENT ONLY"
supported_version="1.20.*"
dependencies={ "礼与道：儒家礼仪与学统 / Rites and the Way" }
path="C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-002/state/profile/mod-content/transaction_control"
