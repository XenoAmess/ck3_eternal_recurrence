from pathlib import Path
import hashlib
import json

OUT=Path('C:/workspace/ck3_lyd_runtime_20261004/r39-native-frame-diagnostic-20261010-001')
SRC=Path('C:/csr2/ck3_autonomous_player/native_bridge')
REPORT=Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0039/native-report.json')
def ref(path):
    data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def create(name,value):
    path=OUT/name
    if path.exists(): raise FileExistsError(path)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')

facts=json.loads((OUT/'OBSERVATION-FACTS.actual.json').read_text(encoding='utf-8'))
report=json.loads(REPORT.read_bytes())
tools=report['mcp_tools']['tools']
core_tools=[item for item in tools if 'core_frame' in item.get('name','') or 'core-frame' in item.get('name','')]
create('EXISTING-CORE-TOOL-METADATA.actual.json',{'source':ref(REPORT),'json_pointer':'/mcp_tools/tools','tools':core_tools})
sources=[]
for relative,begin,end,name in [('src/game_adapter.cpp',323,331,'adapter-capability-delegation'),('include/xar_bridge/game_adapter.hpp',250,260,'snapshot-inline-delegation')]:
    path=SRC/relative
    lines=path.read_text(encoding='utf-8-sig').splitlines()
    target=OUT/(name+'.numbered.txt')
    target.write_text('\n'.join(f'{i}: {lines[i-1]}' for i in range(begin,end+1))+'\n',encoding='utf-8',newline='\n')
    sources.append({'source':ref(path),'line_begin':begin,'line_end':end,'excerpt':ref(target)})

findings={'schema':'lyd.r39.native-frame.readonly-diagnostic.v1',
 'report':facts['report'],'actual_dll':facts['dll_on_disk'],'source_root':str(SRC.parent),'host_source_root':'C:/csr3',
 'actual_frame_count':facts['observation_count'],'actual_unique_frame_values':facts['unique_frame_values'],
 'observer_all_available':facts['observer_all_read_available'],'observer_all_cached':facts['observer_all_cached'],
 'observer_completed_timestamp_unique_count':facts['observer_completed_timestamp_unique_count'],
 'snapshot_update_blocked_by_mainthread_owner_or_command_commit':False,
 'observed_bottleneck':'Actual .4 core readiness expression returns false; adapter intentionally returns an available menu/startup prefix and never reaches played-character/events/world snapshot branches.',
 'ready_operand':'GetLocalPlayer(jomini_state) != nullptr && signed32(player+0x70) >= 0',
 'raw_local_player_pointer':None,'raw_player_plus_0x70':None,'underlying_restore_or_binding_cause':None,
 'dedup_explains_native_revision_unchanged':True,
 'ordinary_publication_diagnostic_zero_proves_no_read_failures':False,
 'ordinary_publication_diagnostic_zero_limitation':'Periodic PublishSnapshot passes no diagnostics pointer; do not use zero count alone to prove publication success.',
 'first_observed_read_duration_ms':facts['first']['snapshot_observer']['last_read_ms'],
 'first_read_duration_is_cause':None,
 'queries_executed_values':facts['mainthread_queries_executed_values'],
 'small_next_step':'Join the parallel actual restore/CLI/log review with this readiness predicate. Existing owner core-frame query can distinguish a fresh core prefix from cached publication, but does not expose raw player pointer/+0x70; if loaded-campaign evidence is established and the predicate remains false, the precise missing diagnostic is only those two existing operands, not a new scan or longer deadline. No native patch is justified by the present receipts.',
 'extra_source_refs':sources,'business_credit':None,
 'actions':{'CK3_launch':0,'SDK_calls':0,'game_actions':0,'save_body_reads':0,'MAIN_writes':0,'fixed_runtime_writes':0,'native_changes':0,'builds':0,'tests':0,'EXE_disassembly':0,'screen_resources':[]},
 'task_bus':{'task_id':'ck3-r39-native-frame-diagnostic-20261010','register_sequence':4225,'resources':[]}}
create('FINDINGS.actual.json',findings)
names=[item['name'] for item in core_tools]
text='''# R39 原生帧只读定位

现有证据不支持 snapshot 更新被 application-main owner 或命令 commit 条件挡住。具体停留条件在 `.4` core reader 的 local-player readiness：`GetLocalPlayer(jomini_state) != nullptr && signed32(player+0x70) >= 0` 持续给出 FALSE。adapter 因而成功返回时钟/menu prefix；角色与事件读取分支不执行。不能由此进一步断言 restore、ABI 或 player 选择哪一层有错。

## 实际回执

R39 原 native-report 的 146 条 observations 逐项只读汇总：完整关键帧值唯一，均 native:1/public revision2/native revision1，date53144712，pausedtrue，map_readyfalse，local_player0，played_character/eventNULL。observer 的 completed timestamp 有146个不同值，146次 last_read_available/cache 都TRUE，pump10871→22047；最终 diagnostics 另外到22105。可见 main-thread observer 在反复完成读，并非只持有最初一份永不更新的 cache。首个诊断的 last_read_ms=58110，后续读取继续完成；本回执不能证明这58.110秒的内部原因，也不能推出延长deadline会恢复。

实际 on-disk DLL `C:/cbr2/xar_ck3_bridge.dll` 9459712 B / SHA `390506e486f5b19e298070523360d420de255a7811b5e79a5b279d5f9331dbbe`，与 report identity相同。精确 report SHA、原JSON pointers、first/last事实在 OBSERVATION-FACTS.actual.json。没有读取 CK3 EXE、游戏现场或存档正文。

## 源码链（均 C:/csr2/ck3_autonomous_player/native_bridge）

1. `src/bridge.cpp:28005`：actual .4 + snapshot capability 选择 WorkerAdapter，28012给 mailbox observer实例。11598–11607注册 ObserveAdapterSnapshot12002 callback。
2. `src/main_thread_query_mailbox_v1.cpp:1804`：TLS与owner stamp成立后直接调用 observer，发生在 queued request/paused业务门禁之前（1819起）。不要求业务命令提交或执行。实际 executed_requests始终0只能证明没有typed executor执行，不能把pump成功写成某个查询业务成功。
3. `src/ck3_12002_semantic_adapter.cpp:128`：Observe仅要求正确owner/TLS/adapter；139–143只在250ms采样窗口内复用，随后150重新 native_->read_snapshot。161–164更新 cache/epoch，不要求 map_ready 或 command commit。112–124读取cache的门禁是stamp、epoch和date/pause一致。
4. `src/ck3_12002_adapter.cpp:141`：descriptor .4选择 ReadCk3_12004Snapshot。`src/ck3_12004_adapter.cpp:260` 调实际 read_core_snapshot；272–274在 !prefix.map_ready 时直接成功返回，不走资源、事件或world分支（303起）。因此 NULL played_character/event 是此分支的直接结果，不能另解释为事件查询失效。
5. `src/ck3_12004_abi_profile.cpp:64`：players+1F0输出 local_player_id（本次0）；65–69调用GetLocalPlayer并读取其+70 readiness；70–71在false时成功返回，故尚未读game-data玩家角色manager（72起）。`include/xar_bridge/ck3_12004.hpp:21` 固定GetLocalPlayer RVA383E290。
6. `src/game_adapter.cpp:328` supports_snapshot只检查capability；header257的ReadSnapshot直接转调virtual read_snapshot。`src/bridge.cpp:14165` 每次heartbeat调用PublishSnapshot；11812–11815对相同完整snapshot/checkpoint去重，11817只在值变时递增native revision。该函数没有 map_ready、owner、commit门禁。**普通周期调用未传diagnostics指针，因此report的snapshot_publish_diagnostic_count=0本身不能证明每次发布成功，也不能证明未read_failed。** observer实际完成/可用事实与源码条件才是本次判断依据。

这些文件的实际 bytes/SHA、有限带行号窗口在READS/FOLLOWUP-READS/FINAL-SOURCE-READS和本包INDEX，不以当前MAIN或其他DLL源码代替。

## 最小下一步

先把另一代理实际restore/CLI/日志结论与上述条件合并。当前核心缺口精确只有 GetLocalPlayer 返回的是NULL，还是非NULL但player+70为负；现有report未记录两者，不能补造。现有 owner core-frame 工具可在后续授权host流程直接读取fresh core而不依赖发布cache，但现有DTO仍不含这两个原始操作数。

现有R39metadata里的core工具名：''' + (', '.join(names) if names else '未发现匹配；不猜工具名') + '''。完整schema原样摘录在EXISTING-CORE-TOOL-METADATA.actual.json，本代理没有调用。

若实际游戏日志证明确实已进入loaded campaign，而新鲜core仍false，才需要针对这两个已有操作数的最小诊断；当前没有足够因果证据修改native。若日志只证明load完成而未有local-player activation，也不能把这当map_ready已成立。不要延长deadline、换成强制map_ready、重放业务动作或展开EXE扫描来替代证据。

任务总线独立source任务已注册sequence4225，无screen资源。SDK/游戏/保存/MAIN/fixed-runtime/native变更、构建和测试均0；业务资格NULL。到此停止读取。
'''
(OUT/'REPORT.zh.md').write_text(text,encoding='utf-8',newline='\n')
artifacts=[ref(p) for p in sorted(OUT.iterdir()) if p.is_file()]
create('INDEX.json',{'schema':'lyd.r39.native-frame.readonly-index.v1','artifacts':artifacts,
 'author_sources':[ref(Path(__file__)),ref(OUT.parent/'r39_frame_source_readonly.py'),ref(OUT.parent/'r39_frame_source_followup_readonly.py'),ref(OUT.parent/'r39_frame_final_readonly.py')],
 'next_native_patch':None,'underlying_cause':None,'business_credit':None})
print(json.dumps({'index':ref(OUT/'INDEX.json'),'report':ref(OUT/'REPORT.zh.md'),'findings':ref(OUT/'FINDINGS.actual.json'),'core_tools':names},ensure_ascii=False))
