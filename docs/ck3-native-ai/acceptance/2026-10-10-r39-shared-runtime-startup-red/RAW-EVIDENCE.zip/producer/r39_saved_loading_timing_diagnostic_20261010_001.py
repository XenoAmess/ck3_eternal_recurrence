from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r39-saved-startup-loading-timing-diagnostic-20261010-001'
L = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0039')
R38 = BASE / 'live-attempt-038'
P39 = Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-001/state/profile')


def ref(path: Path, raw: bytes | None = None) -> dict:
    if raw is None:
        raw = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def put(name: str, value: object) -> dict:
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    path = OUT / name
    with path.open('xb') as stream:
        stream.write(raw)
    return ref(path, raw)


def source_cut(path: Path, ranges: list[tuple[int, int]]) -> dict:
    raw = path.read_bytes()
    lines = raw.decode('utf-8-sig').splitlines()
    return {'source': ref(path, raw), 'ranges': [
        {'start': first, 'end': last, 'lines': [
            {'line': n, 'text': lines[n - 1]} for n in range(first, last + 1)]}
        for first, last in ranges]}


def log_cut(path: Path, day: str, launch: datetime) -> dict:
    raw = path.read_bytes()
    lines = raw.decode('utf-8-sig', errors='replace').splitlines()
    markers = {
        'load_save': "Setting idler 'Load Save'",
        'history_end': 'End loading of history',
        'init_post_read': 'CGameState::InitPostRead',
        'recalculate_cached_data': 'Clear and recalculate cached data',
        'checksum_done': 'ChecksumWaitForJobDone',
        'powerful_vassals': 'Setup powerful vassals among a total of',
        'map_mesh_setup': 'Setup map object mesh streaming',
        'in_game': "Setting idler 'In Game'",
        'setup_completion': 'Setup completion (history loaded)',
        'player_holding_banner': 'player holding banner',
    }
    selected = []
    found = {key: [] for key in markers}
    for n, text in enumerate(lines, 1):
        names = [key for key, marker in markers.items() if marker.lower() in text.lower()]
        if not names:
            continue
        match = re.search(r'\[(\d\d:\d\d:\d\d)\]', text)
        row = {'line': n, 'text': text, 'markers': names}
        if match:
            local = datetime.fromisoformat(day + 'T' + match.group(1)).replace(
                tzinfo=timezone(timedelta(hours=8)))
            utc = local.astimezone(timezone.utc)
            row['utc_from_local_log_clock'] = utc.isoformat()
            row['seconds_after_recorded_launch_or_creation'] = round((utc - launch).total_seconds(), 6)
        selected.append(row)
        for key in names:
            found[key].append(row)
    return {'raw_log': ref(path, raw), 'line_count': len(lines),
            'log_time_resolution_seconds': 1, 'log_clock_timezone': 'UTC+08:00',
            'selected_lines': selected, 'marker_counts': {key: len(rows) for key, rows in found.items()},
            'last_line': {'line': len(lines), 'text': lines[-1] if lines else None}}


def main() -> None:
    native_path = L / 'native-report.json'
    native_raw = native_path.read_bytes()
    native = json.loads(native_raw)
    session = native['session']['report']
    launch38_path = R38 / 'launch.json'
    launch38_raw = launch38_path.read_bytes()
    launch38 = json.loads(launch38_raw)
    launched38 = datetime.fromisoformat(launch38['launched_at_utc'])
    created39 = datetime.strptime(session['shutdown']['ck3_creation_date'],
                                  '%Y%m%d%H%M%S.%f+000').replace(tzinfo=timezone.utc)
    compact_path = BASE / 'r39-saved-startup-readiness-diagnostic-20261010-001/REPORT.actual.json'
    compact_raw = compact_path.read_bytes()
    compact = json.loads(compact_raw)
    debug38 = log_cut(R38 / 'userdir/logs/debug.log', '2026-10-09', launched38)
    debug39 = log_cut(P39 / 'logs/debug.log', '2026-10-10', created39)
    frozen_path = L / 'frozen-argv.json'
    frozen_raw = frozen_path.read_bytes()
    frozen = json.loads(frozen_raw)
    budget_flag = frozen['argv'].index('--readiness-timeout')
    actual_budget = frozen['argv'][budget_flag + 1]
    injector = session['injector_attestation']
    inventory = {}
    for label, root in [('R38', R38 / 'userdir/logs'), ('R39', P39 / 'logs')]:
        inventory[label] = {
            'files': [{'name': p.name, 'bytes': p.stat().st_size} for p in sorted(root.iterdir()) if p.is_file()],
            'setup_perf_log_present': (root / 'setup_perf.log').exists(),
        }
    OUT.mkdir(exist_ok=False)
    logs = put('LOG-CUTS.actual.json', {'R38': debug38, 'R39': debug39,
        'log_inventory_metadata_only': inventory,
        'R39_error_log': ref(P39 / 'logs/error.log')})
    source = put('SOURCE-CUTS.actual.json', {
        'resume_and_injection': source_cut(Path('C:/csr3/ck3_autonomous_player/src/xar_autoplayer/runtime.py'), [(2667, 2705)]),
        'observer_sampling': source_cut(Path('C:/csr3/ck3_autonomous_player/native_bridge/src/ck3_12002_semantic_adapter.cpp'), [(128, 165)]),
        'readiness_deadline_and_default': source_cut(Path('C:/csr3/ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py'), [(737, 750), (802, 807), (827, 840), (3590, 3595)]),
        'registry_budget_projection': source_cut(Path('C:/csr3/tools/ck3_mod_acceptance.py'), [(231, 238)]),
        'original_case_registration': source_cut(BASE / 'r39-root-register-control-case-20261010-001.py', [(7, 15)]),
    })
    report = put('REPORT.actual.json', {
        'schema': 'lyd.r39.readonly-saved-loading-timing-diagnostic.v1',
        'native_report': ref(native_path, native_raw), 'previous_readiness_diagnostic': ref(compact_path, compact_raw),
        'log_cuts': logs, 'source_cuts': source,
        'R38': {'launch': ref(launch38_path, launch38_raw),
            'recorded_launch_utc': launch38['launched_at_utc'], 'argv': launch38['argv'],
            'baseline_sha256': launch38['baseline_sha256'],
            'startup_readiness_budget_seconds': None,
            'budget_limit': 'The inspected legacy launch/attach receipts do not record a startup readiness timeout; do not label R38 as a 400-second shared-host attempt.'},
        'R39': {'game_creation_utc': created39.isoformat(), 'launch': native['saved_campaign_launch'],
            'readiness_timeout_seconds_from_frozen_argv': actual_budget,
            'frozen_argv': ref(frozen_path, frozen_raw),
            'report_started_at': native['started_at'], 'report_finished_at': native['finished_at'],
            'seconds_game_creation_to_report_finish': round((datetime.fromisoformat(native['finished_at']) - created39).total_seconds(), 6),
            'first_semantic_state': compact['startup_last'],
            'first_campaign_observation': compact['first'], 'last_campaign_observation': compact['last'],
            'injector': {key: injector[key] for key in ['status', 'argv', 'parent_pid', 'target_ck3_pid', 'pid', 'creation_utc', 'returncode', 'complete_process_tree_proven', 'evidence_dir']},
            'shutdown': {key: session['shutdown'][key] for key in ['ck3_pid', 'ck3_creation_date', 'ck3_exit_code', 'tree_gone', 'cleanup_proven']},
            'steps': native['steps']},
        'findings': {
            'R39_entered_load_save_and_init_post_read': True,
            'R39_in_game_log_marker_present': bool(debug39['marker_counts']['in_game']),
            'R39_setup_completion_log_marker_present': bool(debug39['marker_counts']['setup_completion']),
            'R39_error_log_empty': (P39 / 'logs/error.log').stat().st_size == 0,
            'explicit_loadsave_failure_in_selected_evidence': False,
            'R38_powerful_vassals_to_in_game_seconds': 103,
            'R38_powerful_vassals_to_setup_completion_seconds': 189,
            'R39_loaded_date_with_missing_player_map_event': 'Consistent with the observed incomplete loading phase; raw local-player/map operands and the underlying cause are not recorded here.',
            'DLL_injected_before_primary_thread_resume': 'Established by actual injector attestation and production runtime.py 2688-2700; not established as the cause of slow/incomplete loading.',
            'snapshot_cache_frozen_for_whole_deadline': 'Not supported: Observe samples again after at most its 250ms cadence and saved diagnostics contain newly completed samples.',
            'budget_provenance': 'Explicit new transaction-only-control registry bound copied from existing LiYu shared case; host argparse default is 300, actual frozen argv is 400. It is not an invariant political/protection predicate.',
            'qualified_minimal_shared_bug': None,
            'longer_new_run_would_complete': None,
        },
        'limits': {'source_changes': 0, 'main_changes': 0, 'git_actions': 0, 'process_queries': 0,
            'SDK_calls': 0, 'screen_actions': 0, 'task_bus_actions': 0, 'save_body_reads': 0,
            'budget_changes': 0, 'business_pass': False, 'normal_exit_zero_claim': False,
            'unknown': 'No exact completed-load failure cause or guaranteed additional duration can be concluded from these existing files.'},
    })
    index = put('INDEX.json', {'schema': 'lyd.readonly-diagnostic-index.v1',
        'author': ref(Path(__file__)), 'files': [logs, source, report], 'runtime_actions': 0})
    print(json.dumps({'report': report, 'index': index}, ensure_ascii=True))


if __name__ == '__main__':
    main()
