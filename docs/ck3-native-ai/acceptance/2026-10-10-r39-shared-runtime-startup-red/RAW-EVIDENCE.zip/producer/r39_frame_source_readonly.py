from pathlib import Path
import hashlib
import json
import subprocess

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004/r39-native-frame-diagnostic-20261010-001')
BASE.mkdir(exist_ok=False)
SRC = Path('C:/csr2/ck3_autonomous_player/native_bridge')
REPORT = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0039/native-report.json')

def ref(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def dump(name, value):
    (BASE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

report = json.loads(REPORT.read_bytes())
topology = {key: {'type': type(value).__name__, 'size': len(value) if isinstance(value, (dict, list, str)) else None,
                  'keys': list(value)[:30] if isinstance(value, dict) else None} for key, value in report.items()}
observations = {}
samples = {}
selected = {'snapshot_observer_12002', 'main_thread_query_mailbox_v1', 'snapshot_publish_diagnostic_count',
            'last_snapshot_publish_diagnostic', 'rejected_state_snapshot_count', 'last_rejected_state_snapshot',
            'semantic_state_available', 'transport_fatal_error'}
def walk(value, pointer=''):
    if isinstance(value, dict):
        for key, item in value.items():
            child = pointer + '/' + key.replace('~', '~0').replace('/', '~1')
            if key in selected:
                values = observations.setdefault(key, [])
                values.append({'pointer': child, 'value': item})
            if ('map_ready' in value and ('revision' in value or 'state_revision' in value or 'date_raw' in value)) and pointer not in samples and len(samples) < 3:
                samples[pointer] = {k: v for k, v in value.items() if not isinstance(v, (list, dict))}
            walk(item, child)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            walk(item, pointer + '/' + str(index))
walk(report)
summary = {}
for key, values in observations.items():
    item = {'occurrences': len(values), 'first': values[0], 'last': values[-1]}
    numeric = {}
    for observed in values:
        data = observed['value']
        if isinstance(data, dict):
            for k, v in data.items():
                if isinstance(v, (int, float)) and not isinstance(v, bool): numeric.setdefault(k, []).append(v)
    item['numeric_ranges'] = {k: {'min': min(v), 'max': max(v)} for k, v in numeric.items()}
    item['unique_values'] = len({json.dumps(x['value'], sort_keys=True) for x in values})
    summary[key] = item
dump('REPORT-COMPACT.actual.json', {'report': ref(REPORT), 'topology': topology,
       'status': report.get('status'), 'error': report.get('error'), 'identity': report.get('identity'),
       'diagnostics': summary, 'frame_samples': samples})

queries = [
 ('snapshot-observer-source', ['rg', '-n', 'SnapshotObserver|last_read_ms|snapshot_cached|last_read_available', str(SRC / 'src'), str(SRC / 'include'), '-g', '*snapshot*', '-g', '*adapter*', '-g', '*observer*']),
 ('adapter-snapshot-source', ['rg', '-n', 'ReadSnapshot|read_snapshot|CommitSnapshot|ObserveSnapshot', str(SRC / 'src/game_adapter.cpp'), str(SRC / 'include/xar_bridge/game_adapter.hpp')]),
 ('bridge-observer-source', ['rg', '-n', 'SnapshotObserver|ObserveSnapshot|CommitSnapshot|ReadCachedSnapshot', str(SRC / 'src/bridge.cpp')]),
 ('core-binding-source', ['rg', '-n', 'ReadCoreSnapshot|local_player_id|map_ready|played_character', str(SRC / 'src/ck3_12004_world.cpp'), str(SRC / 'include/xar_bridge/ck3_12004_world.hpp')]),
]
results = []
for name, argv in queries:
    result = subprocess.run(argv, capture_output=True, shell=False, timeout=30)
    (BASE / (name + '.stdout.txt')).write_bytes(result.stdout)
    (BASE / (name + '.stderr.txt')).write_bytes(result.stderr)
    results.append({'argv': argv, 'exit_code': result.returncode, 'stdout': ref(BASE / (name + '.stdout.txt')), 'stderr': ref(BASE / (name + '.stderr.txt'))})

for relative, begin, end, name in [
  ('src/bridge.cpp', 11545, 11630, 'bridge-observer-scope'),
  ('src/bridge.cpp', 11765, 11827, 'bridge-publish'),
  ('src/bridge.cpp', 14060, 14183, 'bridge-periodic-publication'),
  ('src/ck3_12004_adapter.cpp', 175, 327, 'adapter-bindings-reader'),
  ('src/ck3_12004_core_frame_v1.cpp', 1, 121, 'core-frame-provider'),
]:
    path = SRC / relative
    lines = path.read_text(encoding='utf-8-sig').splitlines()
    destination = BASE / (name + '.numbered.txt')
    destination.write_text('\n'.join(f'{n}: {lines[n - 1]}' for n in range(begin, min(end, len(lines)) + 1)) + '\n', encoding='utf-8', newline='\n')
    results.append({'source': ref(path), 'line_begin': begin, 'line_end': min(end, len(lines)), 'excerpt': ref(destination)})
dump('READS.actual.json', {'results': results, 'author': ref(Path(__file__))})
print(json.dumps({'directory': str(BASE), 'report_top_keys': list(report), 'diagnostic_occurrences': {k: v['occurrences'] for k, v in summary.items()}, 'samples': samples}, ensure_ascii=False))
