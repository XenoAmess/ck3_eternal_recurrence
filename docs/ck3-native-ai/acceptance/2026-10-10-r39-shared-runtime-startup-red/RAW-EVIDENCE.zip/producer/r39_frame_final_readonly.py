from pathlib import Path
import hashlib
import json

OUT = Path('C:/workspace/ck3_lyd_runtime_20261004/r39-native-frame-diagnostic-20261010-001')
SRC = Path('C:/csr2/ck3_autonomous_player/native_bridge')
REPORT = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0039/native-report.json')
def ref(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
def dump(name, value):
    target = OUT / name
    if target.exists(): raise FileExistsError(target)
    target.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
reads=[]
for relative, begin, end, name in [
 ('src/ck3_12004_abi_profile.cpp', 32, 95, 'actual4-core-ready-operand'),
 ('include/xar_bridge/ck3_12004.hpp', 8, 49, 'actual4-core-layout'),
 ('src/ck3_12002_adapter.cpp', 99, 161, 'concrete-adapter-selected-reader'),
 ('src/main_thread_query_mailbox_v1.cpp', 1752, 1834, 'mailbox-observer-before-request'),
 ('src/bridge.cpp', 27975, 28052, 'worker-adapter-lifetime'),
]:
    path=SRC/relative
    lines=path.read_text(encoding='utf-8-sig').splitlines()
    target=OUT/(name+'.numbered.txt')
    target.write_text('\n'.join(f'{i}: {lines[i-1]}' for i in range(begin,min(end,len(lines))+1))+'\n',encoding='utf-8',newline='\n')
    reads.append({'source':ref(path),'line_begin':begin,'line_end':min(end,len(lines)),'excerpt':ref(target)})
report=json.loads(REPORT.read_bytes())
observations=report['saved_campaign_restore']['observations']
rows=[]
for index, obs in enumerate(observations):
    s=obs['snapshot']; hb=s['diagnostics']['last_heartbeat']; mailbox=hb['main_thread_query_mailbox_v1']; observer=hb['snapshot_observer_12002']
    rows.append({'report_pointer':f'/saved_campaign_restore/observations/{index}',
        'snapshot':{k:s.get(k) for k in ['snapshot_id','revision','native_revision','date_raw','speed','paused','map_ready','played_character','local_player_id','active_event']},
        'snapshot_observer':observer,
        'mailbox':{k:mailbox[k] for k in ['pump_epochs','owner_verified_pump_epochs','ready','stamp_read_success','owner_tid','current_tid','published_sequence','completed_sequence','executed_requests','failure']}})
stats={'report':ref(REPORT),'observation_count':len(rows),'unique_frame_values':len({json.dumps(row['snapshot'],sort_keys=True) for row in rows}),
       'first':rows[0],'last':rows[-1],
       'observer_all_read_available':all(r['snapshot_observer']['last_read_available'] for r in rows),
       'observer_all_cached':all(r['snapshot_observer']['snapshot_cached'] for r in rows),
       'observer_read_in_progress_rows':sum(r['snapshot_observer']['read_in_progress'] for r in rows),
       'observer_completed_timestamp_unique_count':len({r['snapshot_observer']['completed_ms'] for r in rows}),
       'owner_ready_all':all(r['mailbox']['ready'] for r in rows),
       'mainthread_queries_executed_values':sorted({r['mailbox']['executed_requests'] for r in rows}),
       'dll_on_disk':ref(Path('C:/cbr2/xar_ck3_bridge.dll')),
       'report_identity':report['identity']}
dump('OBSERVATION-FACTS.actual.json',stats)
dump('FINAL-SOURCE-READS.actual.json',{'sources':reads,'author':ref(Path(__file__))})
print(json.dumps({'observations':len(rows),'unique_frames':stats['unique_frame_values'],'observer_all_available':stats['observer_all_read_available'],
 'observer_all_cached':stats['observer_all_cached'],'observer_completed_unique':stats['observer_completed_timestamp_unique_count'],
 'first_pump':rows[0]['mailbox']['pump_epochs'],'last_pump':rows[-1]['mailbox']['pump_epochs'],'dll':stats['dll_on_disk']},ensure_ascii=False))
