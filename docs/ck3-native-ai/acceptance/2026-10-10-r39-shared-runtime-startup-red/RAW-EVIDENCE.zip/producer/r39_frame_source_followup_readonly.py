from pathlib import Path
import hashlib
import json
import subprocess

OUT = Path('C:/workspace/ck3_lyd_runtime_20261004/r39-native-frame-diagnostic-20261010-001')
SRC = Path('C:/csr2/ck3_autonomous_player/native_bridge')
def ref(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
results = []
for relative, begin, end, name in [
 ('src/ck3_12002_semantic_adapter.cpp', 1, 220, 'semantic-observer'),
 ('include/xar_bridge/ck3_12002_semantic_adapter.hpp', 1, 120, 'semantic-observer-header'),
 ('src/ck3_12004_core_frame_v1.cpp', 1, 90, 'core-frame-read-check'),
]:
    path = SRC / relative
    lines = path.read_text(encoding='utf-8-sig').splitlines()
    dst = OUT / (name + '.numbered.txt')
    dst.write_text('\n'.join(f'{i}: {lines[i-1]}' for i in range(begin, min(end,len(lines))+1))+'\n',encoding='utf-8',newline='\n')
    results.append({'source':ref(path),'line_begin':begin,'line_end':min(end,len(lines)),'excerpt':ref(dst)})
for name, argv in [
 ('core-reader-definition', ['rg','-n','bool ReadCoreSnapshot|CoreSnapshotPrefix|player_id|map_ready',str(SRC / 'src/ck3_12004.cpp'),str(SRC / 'include/xar_bridge/ck3_12004.hpp')]),
 ('concrete-adapter-definition', ['rg','-n','CreateCrozierAdapterFromBindings|read_snapshot\(|class .*Adapter|observer_callback|ReadCk3_12004Snapshot',str(SRC / 'src/ck3_12002_adapter.cpp')]),
 ('observer-callback-use', ['rg','-n','snapshot_observer_callback|snapshot_observer_context',str(SRC / 'src/main_thread_query_mailbox_v1.cpp')]),
]:
    completed=subprocess.run(argv,capture_output=True,shell=False,timeout=30)
    stdout=OUT/(name+'.stdout.txt'); stderr=OUT/(name+'.stderr.txt')
    stdout.write_bytes(completed.stdout); stderr.write_bytes(completed.stderr)
    results.append({'argv':argv,'exit_code':completed.returncode,'stdout':ref(stdout),'stderr':ref(stderr)})
(OUT/'FOLLOWUP-READS.actual.json').write_text(json.dumps({'reads':results,'author':ref(Path(__file__))},ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
compact=json.loads((OUT/'REPORT-COMPACT.actual.json').read_text(encoding='utf-8'))
print(json.dumps({k:compact['diagnostics'][k] for k in ['snapshot_observer_12002','main_thread_query_mailbox_v1','snapshot_publish_diagnostic_count','rejected_state_snapshot_count']},ensure_ascii=False))
