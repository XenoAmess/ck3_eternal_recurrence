"""File-only R39 readiness cut; no host import, SDK, process or scene calls."""
import ast
import copy
import hashlib
import json
from pathlib import Path

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
REPORT = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0039/native-report.json')
HOST = Path('C:/csr3/ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py')
OUT = BASE / 'r39-saved-startup-readiness-diagnostic-20261010-001'


def reference(path, raw=None):
    raw = path.read_bytes() if raw is None else raw
    return {'path': str(path.resolve()), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def put(name, value):
    path = OUT / name
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    return reference(path)


def brief_snapshot(snapshot):
    diagnostics = snapshot.get('diagnostics', {})
    hello = diagnostics.get('hello', {})
    heartbeat = diagnostics.get('last_heartbeat', {})
    mailbox = heartbeat.get('main_thread_query_mailbox_v1', {})
    observer = heartbeat.get('snapshot_observer_12002', {})
    return {**{key: snapshot.get(key) for key in ('snapshot_id', 'revision', 'native_revision', 'date_raw',
        'map_ready', 'paused', 'episode_projection', 'local_player_id', 'played_character', 'active_event')},
        'diagnostics': {**{key: diagnostics.get(key) for key in ('connected', 'semantic_state_available',
            'bridge_pid', 'connection_generation', 'rejected_state_snapshot_count', 'last_error')},
            'hello': {key: hello.get(key) for key in ('pid', 'connection_generation', 'game_adapter_id',
                'expected_ck3_version', 'expected_ck3_sha256', 'ck3_build_match')},
            'heartbeat': {'pid': heartbeat.get('pid'), 'sequence': heartbeat.get('sequence'),
                'monotonic_ms': heartbeat.get('monotonic_ms'),
                'mailbox': {key: mailbox.get(key) for key in ('ready', 'stamp_read_success', 'pump_epochs',
                    'owner_verified_pump_epochs', 'owner_tid', 'current_tid', 'published_sequence',
                    'completed_sequence', 'executor_started_requests', 'executed_requests')},
                'snapshot_observer': {key: observer.get(key) for key in ('started_ms', 'completed_ms',
                    'last_read_ms', 'read_in_progress', 'last_read_available', 'snapshot_cached')}}}}


def main():
    raw, source_raw = REPORT.read_bytes(), HOST.read_bytes()
    report = json.loads(raw)
    source = source_raw.decode('utf-8-sig')
    tree = ast.parse(source)
    names = ('saved_campaign_admission_frame', 'saved_campaign_root_binding',
             'saved_campaign_initial_snapshot_state', 'wait_for_saved_campaign')
    nodes = {node.name: node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in names}
    assert set(nodes) == set(names)
    namespace = {'copy': copy}
    # Run only the existing pure frame predicate on saved JSON, not the host.
    exec(compile(ast.Module(body=[nodes['saved_campaign_admission_frame']], type_ignores=[]), str(HOST), 'exec'), namespace)
    state = report['saved_campaign_restore']
    rows, expected, binding = state['observations'], state['expected'], state['observed_process_binding']
    allow = report.get('saved_campaign_startup_case_contract_input', {}).get('contract') is not None
    replayed_frames = [namespace['saved_campaign_admission_frame'](row['snapshot'], expected, binding,
                        allow_active_event=allow) for row in rows]
    assert all(frame == row['frame'] for frame, row in zip(replayed_frames, rows))
    def row_cut(row):
        return {'snapshot': brief_snapshot(row['snapshot']), 'frame': row.get('frame'),
                'campaign_root': row.get('campaign_root'), 'binding': row.get('binding')}
    startup = state['startup_observations']
    final = report['snapshot_final']
    failures = {
        'map_ready_is_true': sum(row['snapshot'].get('map_ready') is not True for row in rows),
        'played_character_is_native_alive_dict': sum(not isinstance(row['snapshot'].get('played_character'), dict)
            or row['snapshot']['played_character'].get('alive') is not True
            or row['snapshot']['played_character'].get('source') != 'native' for row in rows),
        'local_player_id_is_positive_int': sum(type(row['snapshot'].get('local_player_id')) is not int
            or row['snapshot']['local_player_id'] < 1 for row in rows),
        'startup_active_event_has_positive_instance': sum(not isinstance(row['snapshot'].get('active_event'), dict)
            or type(row['snapshot']['active_event'].get('instance_id')) is not int
            or row['snapshot']['active_event']['instance_id'] < 1 for row in rows)}
    OUT.mkdir(exist_ok=False)
    excerpts = []
    source_lines = source.splitlines(keepends=True)
    for name in names:
        node = nodes[name]
        excerpts.append({'function': name, 'first_line': node.lineno, 'last_line': node.end_lineno,
                         'source': ''.join(source_lines[node.lineno - 1:node.end_lineno])})
    source_cut = put('SOURCE-GUARDS.actual.json', {'host': reference(HOST, source_raw), 'functions': excerpts})
    result = {
        'schema': 'lyd.r39.saved-startup-readiness-file-diagnostic.v1',
        'run_id': 'bf-202609141645-5434332d4d--li-yu-dao--R0039',
        'native_report': reference(REPORT, raw), 'host': reference(HOST, source_raw),
        'source_guards': source_cut, 'status': report.get('status'), 'error': report.get('error'),
        'started_at': report.get('started_at'), 'finished_at': report.get('finished_at'),
        'expected': {'actor_character_id': expected['actor_character_id'], 'date_raw': expected['date_raw'],
            'startup_case': report['saved_campaign_startup_case_contract_input']['contract']['expected']},
        'single_launch': {key: report['saved_campaign_launch'].get(key) for key in ('status', 'argv_admitted', 'ck3_pid', 'captured_at', 'load_save_name')},
        'observed_process_binding': binding, 'startup_count': len(startup),
        'startup_first': startup[0], 'startup_last': startup[-1],
        'observation_count': len(rows), 'first': row_cut(rows[0]), 'last': row_cut(rows[-1]),
        'final_snapshot': brief_snapshot(final),
        'gate2': {'function': 'saved_campaign_admission_frame', 'first_failed_guard_line': 635,
            'first_failed_predicate': 'snapshot.map_ready is True', 'actual_map_ready': False,
            'same_failed_source_predicate_counts': failures,
            'actual_predicate_replay_matches_report': True,
            'nonnull_frames': sum(value is not None for value in replayed_frames),
            'root_queries_observed': sum(row.get('campaign_root') is not None for row in rows),
            'root_bindings_observed': sum(row.get('binding') is not None for row in rows),
            'startup_handler_reached': 'startup_event_admission' in state,
            'first_startup_query_admission_reached': 'first_startup_query_admission' in state},
        'final_actor_date_event_root': {'actor': final.get('played_character'), 'date_raw': final.get('date_raw'),
            'active_event': final.get('active_event'), 'local_player_id': final.get('local_player_id'),
            'campaign_root': rows[-1].get('campaign_root')},
        'steps': report['steps'], 'managed_session_done': report.get('managed_session_done'),
        'managed_session_thread_finished': report.get('managed_session_thread_finished'), 'cleanup_ok': report.get('cleanup_ok'),
        'limits': {'normal_exit_zero_proven': False, 'business_pass': False, 'budget_extension': False,
            'readiness_guard_weakened': False, 'host_or_main_modified': False,
            'SDK_calls': 0, 'process_queries': 0, 'screen_actions': 0, 'save_body_reads': 0,
            'root_cause_beyond_missing_current_map_actor_event_frame': 'UNKNOWN'}}
    result_ref = put('REPORT.actual.json', result)
    index_ref = put('INDEX.json', {'schema': 'lyd.file-only-diagnostic-index.v1',
        'source': reference(Path(__file__)), 'report': result_ref, 'source_guards': source_cut,
        'original_native_report': reference(REPORT, raw), 'runtime_actions': 0})
    print(json.dumps({'index': index_ref, 'report': result_ref, 'observation_count': len(rows),
        'first_failed_guard': 'saved_campaign_admission_frame:635 map_ready != True',
        'nonnull_frames': result['gate2']['nonnull_frames'],
        'final': result['final_actor_date_event_root']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
