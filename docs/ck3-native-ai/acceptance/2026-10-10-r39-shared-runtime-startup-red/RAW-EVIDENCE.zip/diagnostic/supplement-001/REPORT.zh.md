# R39 原生帧只读定位

现有证据不支持 snapshot 更新被 application-main owner 或命令 commit 条件挡住。具体停留条件在 `.4` core reader 的 local-player readiness：`GetLocalPlayer(jomini_state) != nullptr && signed32(player+0x70) >= 0` 持续给出 FALSE。adapter 因而成功返回时钟/menu prefix；角色与事件读取分支不执行。不能由此进一步断言 restore、ABI 或 player 选择哪一层有错。

## 实际回执

R39 原 native-report 的 146 条 observations 逐项只读汇总：完整关键帧值唯一，均 native:1/public revision2/native revision1，date53144712，pausedtrue，map_readyfalse，local_player0，played_character/eventNULL。observer 的 completed timestamp 有146个不同值，146次 last_read_available/cache 都TRUE，pump10871→22047；最终 diagnostics 另外到22105。可见 main-thread observer 在反复完成读，并非只持有最初一份永不更新的 cache。首个诊断的 last_read_ms=58110，后续读取继续完成；本回执不能证明这58.110秒的内部原因，也不能推出延长deadline会恢复。

实际 on-disk DLL `C:/cbr2/xar_ck3_bridge.dll` 9459712 B / SHA `390506e486f5b19e298070523360d420de255a7811b5e79a5b279d5f9331dbbe`，与 report identity相同。精确 report SHA、原JSON pointers、first/last事实在 OBSERVATION-FACTS.actual.json。没有读取 CK3 EXE、游戏现场或存档正文。

## 源码链（均 C:/csr2/ck3_autonomous_player/native_bridge）

1. `src/bridge.cpp:28005`：actual .4 + snapshot capability 选择 WorkerAdapter，28012给 mailbox observer实例。11598–11607注册 ObserveAdapterSnapshot12002 callback。
2. `src/main_thread_query_mailbox_v1.cpp:1804`：TLS与owner stamp成立后直接调用 observer，发生在 queued request/paused业务门禁之前（1819起）。不要求业务命令提交或执行。实际 executed_requests始终0只能证明没有typed executor执行，不能把pump成功写成某个查询业务成功。
3. `src/ck3_12002_semantic_adapter.cpp:128`：Observe仅要求正确owner/TLS/adapter；139–143只在250ms采样窗口内复用，随后150重新 native_->read_snapshot。161–164更新 cache/epoch，不要求 map_ready 或 command commit。112–124读取cache的门禁是stamp、epoch和date/pause一致。
4. `src/ck3_12002_adapter.cpp:141`：descriptor .4选择 ReadCk3_12004Snapshot。`src/ck3_12004_adapter.cpp:260` 调实际 read_core_snapshot；272–274在 !prefix.map_ready 时直接成功返回，不走资源、事件或world分支（303起）。因此 NULL played_character/event 是此分支的直接结果，不能另解释为事件查询失效。
5. `src/ck3_12004_abi_profile.cpp:64`：players+1F0输出 local_player_id（本次0）；65–69调用GetLocalPlayer并读取其+70 readiness；70–71在false时成功返回，故尚未读game-data玩家角色manager（72起）。`include/xar_bridge/ck3_12004.hpp:21` 固定GetLocalPlayer RVA383E290。
6. `src/game_adapter.cpp:328` supports_snapshot只检查capability；header257的ReadSnapshot直接转调virtual read_snapshot。`src/bridge.cpp:14165` 每次heartbeat调用PublishSnapshot；11812–11815对相同完整snapshot/checkpoint去重，11817只在值变时递增native revision。该函数没有 map_ready、owner、commit门禁。**普通周期调用未传diagnostics指针，因此report的snapshot_publish_diagnostic_count=0本身不能证明每次发布成功，也不能证明未read_failed。** observer实际完成/可用事实与源码条件才是本次判断依据。

这些文件的实际 bytes/SHA、有限带行号窗口在READS/FOLLOWUP-READS/FINAL-SOURCE-READS和本包INDEX，不以当前MAIN或其他DLL源码代替。

## 最小下一步

先把另一代理实际restore/CLI/日志结论与上述条件合并。当前核心缺口精确只有 GetLocalPlayer 返回的是NULL，还是非NULL但player+70为负；现有report未记录两者，不能补造。现有 owner core-frame 工具可在后续授权host流程直接读取fresh core而不依赖发布cache，但现有DTO仍不含这两个原始操作数。

现有R39metadata里的core工具名：ck3_query_core_frame_v1。完整schema原样摘录在EXISTING-CORE-TOOL-METADATA.actual.json，本代理没有调用。

若实际游戏日志证明确实已进入loaded campaign，而新鲜core仍false，才需要针对这两个已有操作数的最小诊断；当前没有足够因果证据修改native。若日志只证明load完成而未有local-player activation，也不能把这当map_ready已成立。不要延长deadline、换成强制map_ready、重放业务动作或展开EXE扫描来替代证据。

任务总线独立source任务已注册sequence4225，无screen资源。SDK/游戏/保存/MAIN/fixed-runtime/native变更、构建和测试均0；业务资格NULL。到此停止读取。
