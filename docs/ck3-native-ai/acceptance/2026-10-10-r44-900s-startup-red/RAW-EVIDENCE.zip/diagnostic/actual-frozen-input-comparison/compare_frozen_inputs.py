from pathlib import Path
import copy
import hashlib
import json
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
COMMON = Path('C:/workspace/ck3-common-runtime')
sources = []

def read_json(path):
    raw = path.read_bytes()
    sources.append({'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    return json.loads(raw)

def norm(value):
    if isinstance(value, str):
        value = value.replace('\\', '/')
        for number, case, keeper in [(43, 5, 'a05'), (44, 6, 'a06')]:
            value = value.replace(f'bf-202609141645-5434332d4d--li-yu-dao--R00{number}', '<RUN>')
            value = value.replace(f'lyd-transaction-control-20261010-00{case}', '<CASE>')
            value = value.replace(f'common-acceptance-12004-20261010-{keeper}', '<SCREEN_TASK>')
            value = value.replace(f'/keepers/20261010-{keeper}', '/keepers/<KEEPER>')
        return value
    if isinstance(value, dict):
        return {norm(k): norm(v) for k, v in value.items()}
    if isinstance(value, list):
        return [norm(v) for v in value]
    return value

def diffs(a, b, path='$'):
    if type(a) is not type(b):
        return [{'path': path, 'r43': a, 'r44': b}]
    if isinstance(a, dict):
        result = []
        for key in sorted(set(a) | set(b)):
            if key not in a or key not in b:
                result.append({'path': path + '/' + key, 'r43': a.get(key), 'r44': b.get(key)})
            else:
                result += diffs(a[key], b[key], path + '/' + key)
        return result
    if isinstance(a, list):
        if len(a) != len(b):
            return [{'path': path + '/length', 'r43': len(a), 'r44': len(b)}]
        return sum((diffs(x, y, path + '/' + str(i)) for i, (x, y) in enumerate(zip(a, b))), [])
    return [] if a == b else [{'path': path, 'r43': a, 'r44': b}]

def pin(row):
    return {key: row[key] for key in ('bytes', 'sha256')}

records = []
for number, case in [(43, 5), (44, 6)]:
    run = COMMON / 'runs' / f'bf-202609141645-5434332d4d--li-yu-dao--R00{number}'
    prepared = COMMON / 'cases' / f'lyd-transaction-control-20261010-00{case}' / 'prepared'
    data = {'frozen': read_json(run / 'frozen-argv.json')}
    for name in ['prepared-case', 'profile-preparation', 'saved-product-inventory', 'saved-startup-case-contract', 'initial-plan']:
        data[name] = read_json(prepared / (name + '.json'))
    records.append(data)
a, b = records
argv_diff = diffs(norm(a['frozen']['argv']), norm(b['frozen']['argv']))
assert len(argv_diff) == 1 and argv_diff[0]['r43'] == '600' and argv_diff[0]['r44'] == '900'
assert a['frozen']['argv'][int(argv_diff[0]['path'].rsplit('/', 1)[1])-1] == '--readiness-timeout'

profile_a = a['profile-preparation']['files']
profile_b = b['profile-preparation']['files']
assert set(profile_a) == set(profile_b) and len(profile_a) == 84
categories = {
    'production_71': [k for k in profile_a if k.startswith('mod-content/product/')],
    'overlay_6': [k for k in profile_a if k.startswith('mod-content/transaction_control/')],
    'plain_configuration_4': ['pdx_settings.txt', 'tutorial.txt', 'presets.txt', 'player/game_rules/presets.txt'],
}
pin_comparisons = {}
for category, keys in categories.items():
    assert len(keys) == {'production_71': 71, 'overlay_6': 6, 'plain_configuration_4': 4}[category]
    assert all(pin(profile_a[k]) == pin(profile_b[k]) for k in keys)
    pin_comparisons[category] = {'count': len(keys), 'all_existing_size_sha256_pins_equal': True,
                                'pins': {k: pin(profile_a[k]) for k in keys}}

outer = []
for key in ['mod/product.mod', 'mod/transaction_control.mod']:
    contents = []
    for data, rows in [(a, profile_a), (b, profile_b)]:
        path = Path(rows[key]['path'])
        raw = path.read_bytes()
        actual = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        assert actual == pin(rows[key])
        sources.append({'path': str(path), **actual})
        contents.append(norm(raw.decode('utf-8-sig')))
    assert contents[0] == contents[1]
    outer.append({'relative_path': key, 'r43': pin(profile_a[key]), 'r44': pin(profile_b[key]),
                  'normalized_content_equal': True, 'reason': 'fresh C5/C6 profile absolute path only'})
assert pin(profile_a['dlc_load.json']) == pin(profile_b['dlc_load.json'])

contract_a = a['saved-startup-case-contract']
contract_b = b['saved-startup-case-contract']
assert norm(contract_a) == norm(contract_b)
assert a['initial-plan'] == b['initial-plan'] == {'steps': []}
assert norm(a['prepared-case']['case_inputs']) == norm(b['prepared-case']['case_inputs'])
assert norm(a['prepared-case']['startup']) == norm(b['prepared-case']['startup'])
assert norm(a['profile-preparation']['saved_campaign']) == norm(b['profile-preparation']['saved_campaign'])
inventory_a = norm(copy.deepcopy(a['saved-product-inventory']))
inventory_b = norm(copy.deepcopy(b['saved-product-inventory']))
assert len(inventory_a['product_files']) == len(inventory_b['product_files']) == 79
for inv in [inventory_a, inventory_b]:
    for row in inv['product_files']:
        if row['path'].endswith(('/mod/product.mod', '/mod/transaction_control.mod')):
            row['sha256'] = '<AUTHENTICATED_PATH_ONLY_OUTER_DESCRIPTOR>'
assert inventory_a == inventory_b

frozen_a, frozen_b = a['frozen'], b['frozen']
common_pin_differences = []
for key in sorted(set(frozen_a['files']) & set(frozen_b['files'])):
    if frozen_a['files'][key] != frozen_b['files'][key]:
        common_pin_differences.append({'path': key, 'r43': frozen_a['files'][key], 'r44': frozen_b['files'][key]})
top_a, top_b = copy.deepcopy(frozen_a), copy.deepcopy(frozen_b)
for top in [top_a, top_b]:
    top.pop('files')
    top.pop('predecessor_admission')
    top['execution_id'] = '<FRESH_EXECUTION_ID>'
assert diffs(norm(top_a), norm(top_b)) == [{'path': '$/argv/' + argv_diff[0]['path'].split('/')[-1], 'r43': '600', 'r44': '900'}]

config_path = Path(a['prepared-case']['contract']['path'])
config = read_json(config_path)
assert sources[-1] == a['prepared-case']['contract'] == b['prepared-case']['contract']
adapter_path = Path(a['prepared-case']['adapter']['path'])
adapter_raw = adapter_path.read_bytes()
assert {'path': str(adapter_path), 'bytes': len(adapter_raw), 'sha256': hashlib.sha256(adapter_raw).hexdigest()} == a['prepared-case']['adapter'] == b['prepared-case']['adapter']
sources.append(a['prepared-case']['adapter'])
adapter_lines = adapter_raw.decode('utf-8-sig').splitlines()
client_path = next(Path(k) for k in frozen_a['files'] if k.endswith('ck3_mod_acceptance_client.py'))
client_raw = client_path.read_bytes()
assert pin(frozen_a['files'][str(client_path)]) == pin(frozen_b['files'][str(client_path)]) == {'bytes': len(client_raw), 'sha256': hashlib.sha256(client_raw).hexdigest()}
sources.append({'path': str(client_path), **pin(frozen_a['files'][str(client_path)])})
client_lines = client_raw.decode('utf-8-sig').splitlines()

important = {}
for suffix in ['run_ck3_12002_mcp_live.py', 'xar_ck3_bridge.dll', 'xar_ck3_bridge_injector.exe', 'binaries\\ck3.exe', 'runtime.local.json', 'source05-index.json', 'native-source05-index.json']:
    key = next(k for k in frozen_a['files'] if k.endswith(suffix))
    assert frozen_a['files'][key] == frozen_b['files'][key]
    important[key] = frozen_a['files'][key]

report = {
    'schema': 'lyd.r44.actual-frozen-input-comparison.v1',
    'observed_at_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'ACTUAL_CALL_AND_PRODUCT_INPUT_COMPARISON_MATCHES_WITH_RECORDED_PROVENANCE_DELTA',
    'scope': 'Immutable frozen argv/prepared metadata; no live status or business assessment',
    'normalized_argv_differences': argv_diff,
    'budgets': {'command_timeout': 300, 'readiness_timeout': {'r43': 600, 'r44': 900}, 'timeout': 2100, 'hold_seconds': 900, 'poll_interval': 0.5},
    'flags_unchanged': ['--private-succession-title-readonly', '--saved-campaign-inject-after-load', '--saved-campaign-debug-mode', '--fixture-profile'],
    'runtime_bindings_unchanged': important,
    'prepared_pin_comparisons': pin_comparisons,
    'outer_descriptors': outer,
    'mod_inventory': {'count': 79, 'ordered_semantics_equal': True, 'enabled_mods': inventory_a['enabled_mods']},
    'dlc_load_pin_unchanged': pin(profile_a['dlc_load.json']),
    'handler_contract_equal_after_case_path_normalization': True,
    'expected': contract_a['expected'], 'handler': contract_a['handler'],
    'empty_initial_plan_equal': True,
    'saved_campaign': a['prepared-case']['startup']['saved_campaign'],
    'control_contract': {key: config[key] for key in ['production_source_head', 'baseline_cached_succession', 'political_title_ast_sha256', 'terminal_event_definition_key', 'new_title_scope', 'new_title_id', 'completed_variable']},
    'terminal_and_reserve_sources': {'terminal': [{'line': i+1, 'text': v} for i,v in enumerate(adapter_lines) if 'monotonic() + 60' in v or 'client.guard()' in v], 'quit_reserve': [{'line': i+1, 'text': v} for i,v in enumerate(client_lines) if 'def guard(self, reserve=90' in v]},
    'frozen_common_file_provenance_differences': common_pin_differences,
    'provenance_limit': 'Whole frozen files map is not identical: registry and unrelated xqol_religion_adapter.py pins changed. Run/case/execution/lease/predecessor and derived JSON/outer descriptor pins are fresh provenance, not business input changes.',
    'prepared_case_raw_pin_differences': diffs(norm(a['prepared-case']), norm(b['prepared-case'])),
    'business_pass': None, 'runtime_pass': None,
    'actions': {'game_sdk_screen_process_bus_git': 0, 'seed_body_reads': 0, 'seed_body_hashes': 0, 'mod_config_body_rehashes': 0},
    'sources': sources,
}
for name, value in [('COMPARISON.actual.json', report)]:
    with (OUT/name).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2); stream.write('\n')
text = ('R43/R44 实际 frozen argv 在规范化 run/case/task 路径与 fresh execution ID 后，仅 readiness 600→900。\n'
        '正式71、overlay6、四配置的既有准备 size/SHA pins 均相同；79 mod 清单顺序/语义相同。两外层 descriptor 原 SHA 改变仅来自 C5→C6 路径，实际小文件验证后规范化内容相同。\n'
        'Source05、EXE、DLL、injector、原 seed pin、actor/date、handler、空 plan、45 顺序基线/政治7 AST、terminal60/原 Quit reserve90 保持。\n'
        '全量 frozen files provenance 另有 registry 和无关 xqol_religion_adapter.py pin 改变，不能称整个来源清单只有 registry 差异。\n'
        '只比较已冻结准备输入，不判断 R44 实机状态或成功；旧 R43 600 秒 RED 不变。未读/重 hash seed，没有 SDK/屏幕/进程/bus/Git 操作。\n')
(OUT/'REPORT.zh.md').write_text(text, encoding='utf-8')
rows = []
for name in ['compare_frozen_inputs.py', 'COMPARISON.actual.json', 'REPORT.zh.md']:
    path = OUT/name; raw = path.read_bytes()
    rows.append({'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
with (OUT/'INDEX.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump({'schema': 'lyd.r44.actual-frozen-input-comparison-index.v1', 'files': rows}, stream, ensure_ascii=False, indent=2); stream.write('\n')
print(json.dumps({'status': report['status'], 'argv_differences': argv_diff, 'common_provenance_differences': common_pin_differences, 'files': rows}, ensure_ascii=False))
