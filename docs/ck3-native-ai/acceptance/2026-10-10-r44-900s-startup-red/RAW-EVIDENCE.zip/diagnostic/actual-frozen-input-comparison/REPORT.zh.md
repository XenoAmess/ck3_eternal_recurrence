R43/R44 实际 frozen argv 在规范化 run/case/task 路径与 fresh execution ID 后，仅 readiness 600→900。
正式71、overlay6、四配置的既有准备 size/SHA pins 均相同；79 mod 清单顺序/语义相同。两外层 descriptor 原 SHA 改变仅来自 C5→C6 路径，实际小文件验证后规范化内容相同。
Source05、EXE、DLL、injector、原 seed pin、actor/date、handler、空 plan、45 顺序基线/政治7 AST、terminal60/原 Quit reserve90 保持。
全量 frozen files provenance 另有 registry 和无关 xqol_religion_adapter.py pin 改变，不能称整个来源清单只有 registry 差异。
只比较已冻结准备输入，不判断 R44 实机状态或成功；旧 R43 600 秒 RED 不变。未读/重 hash seed，没有 SDK/屏幕/进程/bus/Git 操作。
