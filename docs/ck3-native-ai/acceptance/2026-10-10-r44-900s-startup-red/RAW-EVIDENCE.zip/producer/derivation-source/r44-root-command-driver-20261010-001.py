from pathlib import Path
import json
import subprocess
import sys

b = Path('C:/workspace/ck3_lyd_runtime_20261004')
root = Path('C:/workspace/ck3_eternal_recurrence')
run = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0044')
oldrun = run.with_name(run.name.replace('R0044', 'R0043'))
prep = 'C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-006/prepared/prepared-case.json'
keeper = 'C:/workspace/ck3-common-runtime/keepers/20261010-a06'
py = 'C:/Users/Administrator/AppData/Local/Programs/Python/Python313/python.exe'
recorder = str(b / 'root-record-command-20261010-001.py')

def derive(source, changes):
    argv = json.loads(source.read_bytes())['argv']
    for key, value in changes.items():
        if argv.count(key) != 1:
            raise RuntimeError('Expected unique option: ' + key)
        argv[argv.index(key) + 1] = value
    return argv

mode = sys.argv[1]
if mode in ('prepare', 'preflight'):
    saved = b / 'r44-transaction-control-prepare-sourceonly-20261010-001' / (mode.upper() + '-ARGV.actual.json')
    argv = json.loads(saved.read_bytes())['argv']
    output = b / f'r44-root-case-{mode}-20261010-001'
elif mode == 'allocate':
    argv = derive(b / 'r43-root-case-allocate-20261010-001/RESULT.actual.json', {
        '--prepared-case': prep, '--attempt': 'a06', '--keeper-output': keeper,
        '--previous-live': str(oldrun), '--previous-keeper': keeper.replace('a06', 'a05'),
        '--previous-release': str(oldrun / 'release-command-001/stdout.log')})
    output = b / 'r44-root-case-allocate-20261010-001'
elif mode in ('run', 'verify'):
    argv = derive(oldrun / f'{mode}-command-001/RESULT.actual.json', {
        '--prepared-case': prep, '--run-context': str(run / 'reviewed-context.json')})
    output = run / f'{mode}-command-001'
elif mode in ('display-fit', 'steam-window-fit', 'observer'):
    helper = {'display-fit': 'fit-desktop', 'steam-window-fit': 'fit-steam-window', 'observer': 'startup-observer'}[mode]
    version = '002' if mode == 'observer' else '001'
    argv = [py, '-B', '-X', 'utf8', str(Path('C:/workspace/ck3_lyd_runtime_20261004/r44-transaction-control-prepare-sourceonly-20261010-001/scripts') / f'r44-root-{helper}-20261010-{version}.py')]
    output = run / f'{mode}-command-001'
elif mode in ('recover-initial', 'recover-final'):
    name = 'steam-offline-recovery-001' if mode == 'recover-initial' else 'steam-final-recovery-001'
    argv = [py, '-B', '-X', 'utf8', 'tools/desktop_steam_offline_recovery.py',
        '--task-bus', 'C:/workspace/.codex-task-bus/bin/codex_task_bus.py', 'recover',
        '--task-id', 'common-acceptance-12004-20261010-a06', '--output-dir', str(run / name), '--bring-steam-forward']
    output = run / f'{mode}-command-001'
elif mode == 'challenge':
    frame = run / 'steam-offline-recovery-001/probe-1'
    argv = [py, '-B', '-X', 'utf8', 'C:/csr5/tools/ck3_mod_acceptance_launcher.py',
        '--create-challenge', '--run-root', str(run), '--keeper-root', keeper,
        '--fresh-frame', str(frame / 'steam-frame-freshness.json'), '--image', str(frame / 'steam-moved.png'),
        '--output', str(run / 'direct-review-001')]
    output = run / 'challenge-command-001'
else:
    raise RuntimeError('Unknown driver phase: ' + mode)
print(json.dumps({'mode': mode, 'argv': argv, 'output': str(output)}), flush=True)
raise SystemExit(subprocess.call([py, '-B', '-X', 'utf8', recorder, str(output), *argv], cwd=root))
