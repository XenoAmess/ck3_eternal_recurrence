"""Use an actually enumerated display mode so Steam's minimum window fits."""
from pathlib import Path
from datetime import datetime, timezone
import json
import win32api
import win32con
import pyautogui

B=Path('C:/workspace/ck3_lyd_runtime_20261004')
out=Path('C:\\workspace\\ck3-common-runtime\\runs\\bf-202609141645-5434332d4d--li-yu-dao--R0044\\display-fit-001.json')
assert not out.exists()
old=win32api.EnumDisplaySettings(None,win32con.ENUM_CURRENT_SETTINGS)
before={'width':old.PelsWidth,'height':old.PelsHeight,'bits':old.BitsPerPel,'frequency':old.DisplayFrequency}
supported=[]
index=0
chosen=None
while True:
    try: mode=win32api.EnumDisplaySettings(None,index)
    except Exception: break
    supported.append({'width':mode.PelsWidth,'height':mode.PelsHeight,'bits':mode.BitsPerPel,'frequency':mode.DisplayFrequency})
    if mode.PelsWidth==1920 and mode.PelsHeight==1080 and mode.BitsPerPel==old.BitsPerPel:
        chosen=mode
    index+=1
assert chosen is not None, '1920x1080 is not an enumerated supported mode'
assert win32api.ChangeDisplaySettingsEx(None,chosen,win32con.CDS_TEST)==0
rc=win32api.ChangeDisplaySettingsEx(None,chosen,0)
actual=win32api.EnumDisplaySettings(None,win32con.ENUM_CURRENT_SETTINGS)
after={'width':actual.PelsWidth,'height':actual.PelsHeight,'bits':actual.BitsPerPel,'frequency':actual.DisplayFrequency}
obj={'utc':datetime.now(timezone.utc).isoformat(),'before':before,'supported_modes':supported,'change_result':rc,'after':after,'pyautogui_size':list(pyautogui.size()),'registry_persistence_requested':False,'purpose':'Steam minimum window exceeded 1024x768 desktop; restore original mode at closeout'}
with out.open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,indent=2);f.write('\n')
assert rc==0 and after['width']==1920 and after['height']==1080
print(json.dumps(obj))
