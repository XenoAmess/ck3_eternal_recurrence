from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys

run = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0044')
observed_nonce, observed_clock = sys.argv[1:3]

def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def put(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

path = run / 'direct-review-001/challenge.json'
challenge = json.loads(path.read_bytes())
if observed_nonce != challenge['nonce']:
    raise RuntimeError('Visually observed nonce does not match')
out = run / 'direct-review-001/operator-review.json'
put(out, {'schema': 'ck3-mod-acceptance-direct-review-v1', 'reviewed_at_utc': datetime.now(timezone.utc).isoformat(),
    'reviewer': '/root', 'direct_image_review': True, 'steam_offline_confirmed': True,
    'observed_nonce': observed_nonce, 'run_id': challenge['run_id'], 'screen_task': challenge['screen_task'],
    'challenge': pin(path), **{key: challenge[key] for key in ('frozen_argv', 'image', 'review_image')},
    'observed_text': 'Root directly reviewed the original moved Steam image and challenge image: 离线模式; taskbar ' + observed_clock + ' 2026/10/10. Original desktop dimensions and current window movement reviewed.',
    'business_pass': False})
context = json.loads((run / 'ready-context.json').read_bytes())
context.update(proof=str(out), challenge=str(path), observed_nonce=observed_nonce, reviewer='/root')
put(run / 'reviewed-context.json', context)
print(json.dumps({'proof': pin(out), 'context': pin(run / 'reviewed-context.json')}))
