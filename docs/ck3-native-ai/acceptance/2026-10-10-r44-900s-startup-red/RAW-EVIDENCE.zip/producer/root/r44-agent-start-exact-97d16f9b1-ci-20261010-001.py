"""Observe the published R44 head using existing read-only CI capture code."""
from pathlib import Path
import subprocess
import sys

base = Path('C:/workspace/ck3_lyd_runtime_20261004')
old_sha = 'a967a41d178d5a7e080415e5f2376b58a70b0f60'
sha = '97d16f9b1f3c91887549c987291c2435087e1025'
old_output = 'r43-exact-a967a41d1-ci-20261010-001'
output = 'r44-exact-97d16f9b1-ci-20261010-001'
targets = []
for operation in ('watch', 'complete'):
    original = base / f'r43-agent-{operation}-exact-a967a41d1-ci-20261010-001.py'
    target = base / f'r44-agent-{operation}-exact-97d16f9b1-ci-20261010-001.py'
    source = original.read_text(encoding='utf-8')
    if source.count(old_sha) != 1 or source.count(old_output) != 1:
        raise RuntimeError('Observer no longer permits an unambiguous exact retarget')
    source = source.replace(old_sha, sha).replace(old_output, output)
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(source)
    targets.append(target)
for target in targets:
    result = subprocess.run([sys.executable, '-B', '-X', 'utf8', str(target)], cwd=base)
    if result.returncode:
        raise SystemExit(result.returncode)
