"""Seal the two existing R44 file cutoffs; never observe processes or game state."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r44-written-startup-samples-readonly-20261010-001'

def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def check(ref):
    assert pin(Path(ref['path'])) == ref, ref

def put(name, value):
    path = OUT / name
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    return pin(path)

reports = sorted(OUT.glob('cutoff-*/REPORT.actual.json'))
assert len(reports) == 2
first, final = [json.loads(path.read_bytes()) for path in reports]
for path in reports:
    index = json.loads(path.with_name('INDEX.json').read_bytes())
    for ref in [index['producer'], index['reader'], index['report'], index['snapshot'],
                *index['captured_artifacts'], *index['raw_observer_sources']]:
        check(ref)
assert final['observer_terminal_receipts']['EXIT.actual.json']['value']['actual_exit_code'] == 1
intervals = final['after600_complete_intervals']
assert len(intervals) == 9
cpu = [row['cpu_one_core_percent_over_interval'] for row in intervals]
io_keys = set.intersection(*(set(row['io_deltas']) for row in intervals))
io_delta = {key: sum(row['io_deltas'][key] for row in intervals) for key in sorted(io_keys)}

def debug_capture(report):
    return next(ref for ref in report['raw_log_captures'] if ref['source_path'].replace('\\', '/').endswith('/logs/debug.log'))

a, b = debug_capture(first), debug_capture(final)
debug_comparison = {'first': a, 'terminal': b,
    'same_observed_source_size': a['source_size_at_open'] == b['source_size_at_open'],
    'same_region_offset': a['offset_bytes'] == b['offset_bytes'],
    'same_region_bytes_sha256': a['captured_region_sha256'] == b['captured_region_sha256'],
    'boundary': 'Equality compares these two captured regions at cutoff times, not every instant between them.'}
snapshot = json.loads(Path(final['snapshot']['path']).read_bytes())
post_sample_debug = []
for row in snapshot['samples']:
    if row['elapsed_seconds'] >= 600:
        raw = json.loads(Path(row['source']['path']).read_bytes())
        tail = raw.get('debug_log_tail', '')
        post_sample_debug.append({'source': row['source'], 'elapsed_seconds': row['elapsed_seconds'],
            'debug_log_size': raw.get('debug_log_size'),
            'recorded_debug_tail_utf8_sha256': hashlib.sha256(tail.encode('utf-8')).hexdigest()})
native = json.loads(Path(final['native_report_capture']['artifact']['path']).read_bytes())
last = final['last_sample']
exit_receipt = final['observer_terminal_receipts']['EXIT.actual.json']
summary = {'schema': 'ck3-r44-two-written-cutoffs-final-summary-v1',
    'sealed_at_utc': datetime.now(timezone.utc).isoformat(), 'cutoffs': [pin(path) for path in reports],
    'cutoff_indexes': [pin(path.with_name('INDEX.json')) for path in reports],
    'status': 'OBSERVED_ORIGINAL_PROCESS_EXIT_1_NO_CAUSE_CREDIT',
    'sample_count': final['sample_count'], 'sample_bounds_utc': final['sample_bounds_utc'],
    'after600_complete_interval_count': len(intervals),
    'after600_complete_interval_bounds_seconds': [intervals[0]['interval_start_elapsed_seconds'], intervals[-1]['interval_end_elapsed_seconds']],
    'after600_cpu_one_core_percent_range': [min(cpu), max(cpu)],
    'after600_zero_cpu_interval_count': sum(value == 0 for value in cpu),
    'after600_io_counter_deltas': io_delta,
    'after600_thread_count_range': [min(row['num_threads'] for row in intervals), max(row['num_threads'] for row in intervals)],
    'after600_rss_bytes_range': [min(row['rss_bytes'] for row in intervals), max(row['rss_bytes'] for row in intervals)],
    'last_sample': {k: last.get(k) for k in ['source', 'at_utc', 'elapsed_seconds', 'cpu_one_core_percent_over_interval',
        'io_deltas', 'num_threads', 'rss_bytes', 'errors']},
    'sample_error_count': final['errors'],
    'sdl_window_count': len(final['sdl_window_observations']),
    'sdl_foreground_count': final['sdl_foreground_count'], 'sdl_visible_count': final['sdl_visible_count'],
    'sdl_iconic_count': final['sdl_iconic_count'],
    'last_sdl_observation': final['sdl_window_observations'][-1],
    'foreground_boundary': final['foreground_boundary'],
    'debug_region_comparison': debug_comparison, 'after600_recorded_debug_samples': post_sample_debug,
    'strict_setup_completion_in_captured_regions': final['setup_completion_recorded_in_captured_regions'],
    'recorded_injection_stage': final['recorded_bridge_injection_stage'],
    'recorded_load_completion_observation': final['recorded_load_completion_observation'],
    'native_phase': final['native_phase'], 'saved_campaign_launch_record': final['saved_campaign_launch_record'],
    'native_cleanup_ok_field': native.get('cleanup_ok'), 'native_session_field': native.get('session'),
    'native_error_field': native.get('error'),
    'native_steps_count': len(native['steps']) if isinstance(native.get('steps'), list) else None,
    'independent_observer_exit': exit_receipt,
    'last_sample_to_exit_gap_seconds': exit_receipt['value']['elapsed_seconds'] - last['elapsed_seconds'],
    'boundary': 'Busy CPU/IO does not disprove deadlock. Only captured records and sampled instants are described. No budget/foreground causal claim, normal-exit claim, native/business qualification or cleanup inference.',
    'new_sampling': False, 'SDK_calls': 0, 'process_signals': 0, 'screen_input_focus_actions': 0,
    'save_body_reads': 0, 'tracked_or_Git_writes': 0, 'business_pass': False}
summary_ref = put('REPORT.actual.json', summary)
producers = [BASE / name for name in ['r44_prepare_written_cutoff_reader_20261010_001.py',
    'r44_summarize_written_startup_samples_20261010_001.py', 'r44_written_startup_cutoff_20261010_001.py',
    'r44_written_terminal_gate_20261010_001.py', 'r44_seal_written_cutoffs_20261010_001.py']]
index_ref = put('INDEX.json', {'schema': 'ck3-r44-written-cutoff-collection-index-v1',
    'producer': pin(Path(__file__)), 'files': [pin(path) for path in sorted(OUT.rglob('*')) if path.is_file()],
    'producers': [pin(path) for path in producers], 'input_reverification': 'PASS',
    'cutoff_count': 2, 'live_calls': 0, 'tracked_or_Git_writes': 0})
print(json.dumps({'report': summary_ref, 'index': index_ref,
    'after600_intervals': len(intervals), 'after600_cpu_range': summary['after600_cpu_one_core_percent_range'],
    'after600_io_delta': io_delta, 'after600_threads_range': summary['after600_thread_count_range'],
    'after600_rss_range': summary['after600_rss_bytes_range'],
    'debug_source_sizes': [a['source_size_at_open'], b['source_size_at_open']],
    'debug_region_sha_equal': debug_comparison['same_region_bytes_sha256'],
    'post600_sample_debug_sizes': sorted({row['debug_log_size'] for row in post_sample_debug}),
    'post600_sample_debug_tail_variants': len({row['recorded_debug_tail_utf8_sha256'] for row in post_sample_debug}),
    'native_cleanup_ok_field': summary['native_cleanup_ok_field'],
    'native_session_field': summary['native_session_field'], 'native_error_field': summary['native_error_field'],
    'native_steps_count': summary['native_steps_count'], 'last_sample_to_exit_gap_seconds': summary['last_sample_to_exit_gap_seconds']},
    ensure_ascii=False, indent=2))
