"""Prepare a file-only R44 reader from the finished R43 reader; do not run it."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
source = BASE / 'r43_summarize_written_startup_samples_20261010_001.py'
target = BASE / 'r44_summarize_written_startup_samples_20261010_001.py'
out = BASE / 'r44-written-startup-samples-readonly-20261010-001'
raw = source.read_bytes()
original = raw.decode('utf-8')
text = original.replace('R0043', 'R0044').replace('r43-written-startup-samples-', 'r44-written-startup-samples-')
assert text.replace('R0044', 'R0043').replace('r44-written-startup-samples-', 'r43-written-startup-samples-') == original
compile(text, str(target), 'exec', dont_inherit=True)
ast.parse(text)
with target.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(text)
out.mkdir(exist_ok=False)
diff_path = out / 'r43-to-r44-reader.diff'
with diff_path.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(''.join(difflib.unified_diff(original.splitlines(True), text.splitlines(True), fromfile=str(source), tofile=str(target))))
def pin(path):
    value = path.read_bytes()
    return {'path': str(path), 'bytes': len(value), 'sha256': hashlib.sha256(value).hexdigest()}
with (out / 'READER-DERIVATION.actual.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump({'producer': pin(Path(__file__)), 'original': pin(source), 'candidate': pin(target),
        'difference': pin(diff_path), 'compile': 'PASS', 'candidate_executed': False,
        'changes': ['run R0043 to R0044', 'external output r43 to r44'],
        'repo_writes': 0, 'new_process_sampling': False}, stream, indent=2)
    stream.write('\n')
print(json.dumps({'candidate': pin(target), 'derivation': pin(out / 'READER-DERIVATION.actual.json')}))
