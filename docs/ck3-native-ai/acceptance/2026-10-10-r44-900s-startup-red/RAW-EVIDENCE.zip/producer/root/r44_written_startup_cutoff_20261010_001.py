"""Interpret existing observer/report/log files only, after 600s or real EXIT."""
from pathlib import Path
from datetime import datetime, timezone
import contextlib
import hashlib
import io
import json
import re
import runpy

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
RUN = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0044')
OBSERVER = RUN / 'startup-observer-001'
OUT = BASE / 'r44-written-startup-samples-readonly-20261010-001'
PROFILE = Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-006/state/profile')
READER = BASE / 'r44_summarize_written_startup_samples_20261010_001.py'

def pin(path, raw=None):
    if raw is None:
        raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

ready = json.loads((OBSERVER / 'HANDLE-READY.actual.json').read_bytes())
elapsed_wall = (datetime.now(timezone.utc) - datetime.fromisoformat(ready['at_utc'])).total_seconds()
terminal_exists = (OBSERVER / 'EXIT.actual.json').is_file()
if elapsed_wall < 601 and not terminal_exists:
    print(json.dumps({'status': 'WAITING_FOR_600S_OR_ACTUAL_EXIT', 'anchor_utc': ready['at_utc'],
        'anchor_elapsed_wall_seconds': elapsed_wall, 'seconds_until_conservative_601s_cutoff': 601 - elapsed_wall,
        'metrics_read': False, 'terminal_receipt_exists': False}))
    raise SystemExit(0)

with contextlib.redirect_stdout(io.StringIO()):
    result = runpy.run_path(str(READER), run_name='__main__')
snapshot = result['report']
snapshot_path = result['path']
rows = snapshot['samples']
stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
CUT = OUT / ('cutoff-' + stamp)
CUT.mkdir(exist_ok=False)

def put(name, value):
    path = CUT / name
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    return pin(path)

captured = []
def capture(path, name, limit=None):
    if not path.is_file():
        return {'source_path': str(path), 'exists': False}, b''
    with path.open('rb') as stream:
        stream.seek(0, 2)
        observed_size = stream.tell()
        offset = max(0, observed_size - limit) if limit is not None else 0
        stream.seek(offset)
        raw = stream.read(observed_size - offset)
    artifact = CUT / name
    with artifact.open('xb') as stream:
        stream.write(raw)
    ref = {'source_path': str(path), 'source_size_at_open': observed_size,
        'offset_bytes': offset, 'captured_bytes': len(raw), 'full_source_captured': offset == 0,
        'captured_region_sha256': hashlib.sha256(raw).hexdigest(), 'artifact': pin(artifact, raw)}
    captured.append(ref)
    return ref, raw

native_ref, native_raw = capture(RUN / 'native-report.json', 'native-report.raw.json')
native = {}
native_parse = 'MISSING'
if native_raw:
    try:
        native = json.loads(native_raw)
        native_parse = 'COMPLETE_JSON'
    except json.JSONDecodeError:
        native_parse = 'PARTIAL_JSON_CAPTURED_UNCHANGED'

log_payloads = []
for source, name in [(RUN / 'host-stdout.log', 'host-stdout.tail.log'),
    (RUN / 'host-stderr.log', 'host-stderr.tail.log'),
    (RUN / 'native-report.session.log', 'native-session.tail.log'),
    (RUN / 'native-report.server-stderr.log', 'native-server-stderr.tail.log'),
    (PROFILE / 'logs/debug.log', 'debug.tail.log')]:
    ref, raw = capture(source, name, 65536)
    log_payloads.append((ref, raw.decode('utf-8', errors='replace')))

patterns = ['Load Save', 'InitPostRead', 'Setup powerful vassals', 'In Game', 'Setup completion',
    'saved startup', 'injector', 'injection', 'native bridge']
milestones = []
seen = set()
for row in rows:
    source_path = Path(row['source']['path'])
    actual = source_path.read_bytes()
    assert pin(source_path, actual) == row['source']
    original = json.loads(actual)
    for line in original.get('debug_log_tail', '').splitlines():
        if any(pattern.casefold() in line.casefold() for pattern in patterns):
            key = ('observer_debug_tail', line)
            if key not in seen:
                seen.add(key)
                milestones.append({'source': row['source'], 'kind': key[0], 'text': line,
                    'first_recorded_sample_utc': row['at_utc'], 'first_recorded_elapsed_seconds': row['elapsed_seconds']})
for ref, text in log_payloads:
    for number, line in enumerate(text.splitlines(), 1):
        if any(pattern.casefold() in line.casefold() for pattern in patterns):
            milestones.append({'source_region': ref, 'region_line': number, 'text': line})

windows = []
for row in rows:
    state = row.get('windows') or {}
    for window in state.get('game_windows', []):
        if window.get('class') == 'SDL_app':
            windows.append({'index': row['index'], 'at_utc': row['at_utc'], 'elapsed_seconds': row['elapsed_seconds'],
                'hwnd': window['hwnd'], 'visible': window['visible'], 'iconic': window['iconic'],
                'foreground_hwnd': state.get('foreground_hwnd'), 'foreground_pid': state.get('foreground_pid'),
                'foreground_is_game': state.get('foreground_pid') == row['pid']})

def interval_rows(after600):
    return [{k: right.get(k) for k in ['index', 'at_utc', 'elapsed_seconds',
        'cpu_one_core_percent_over_interval', 'io_deltas', 'num_threads', 'rss_bytes', 'errors']}
        | {'interval_start_elapsed_seconds': left['elapsed_seconds'], 'interval_end_elapsed_seconds': right['elapsed_seconds']}
        for left, right in zip(rows, rows[1:]) if (left['elapsed_seconds'] >= 600 if after600 else right['elapsed_seconds'] <= 600)]

phase = native.get('phase') if isinstance(native, dict) else None
launch = native.get('saved_campaign_launch') if isinstance(native, dict) else None
session = native.get('session') if isinstance(native, dict) else None
startup = {k: v for k, v in native.items() if 'startup' in k and k != 'saved_campaign_startup_case_contract_input'} if isinstance(native, dict) else {}
startup_compact = {}
for key, value in startup.items():
    if isinstance(value, list):
        startup_compact[key] = {'count': len(value), 'first': value[0] if value else None, 'last': value[-1] if value else None}
    else:
        startup_compact[key] = value
load_observation = launch.get('load_completion_observation') if isinstance(launch, dict) else None
recorded_injection_stage = launch.get('bridge_injection_stage') if isinstance(launch, dict) else None
setup_marker = re.compile(r'^\[\d{2}:\d{2}:\d{2}\]\[D\]\[gameapplication\.cpp:\d+\]: Setup completion \(history loaded\):')
setup_lines = [row for row in milestones if setup_marker.match(row['text'])]
report = {'schema': 'ck3-r44-existing-written-startup-cutoff-v1',
    'captured_at_utc': datetime.now(timezone.utc).isoformat(), 'cutoff_gate_anchor_utc': ready['at_utc'],
    'cutoff_gate_elapsed_wall_seconds': elapsed_wall, 'terminal_receipt_exists_at_gate': terminal_exists,
    'reader_derivation': pin(OUT / 'READER-DERIVATION.actual.json'), 'snapshot': pin(snapshot_path),
    'sample_count': len(rows), 'sample_bounds_utc': snapshot['observation_time_bounds_utc'],
    'sample_elapsed_bounds_seconds': snapshot['sample_elapsed_bounds_seconds'],
    'cpu_convention': '100 percent equals one logical CPU core; activity does not disprove deadlock.',
    'cpu_one_core_percent_range': snapshot['cpu_one_core_percent_range'],
    'cpu_cumulative_delta_seconds': snapshot['observed_cpu_cumulative_delta_seconds'],
    'before600_complete_intervals': interval_rows(False), 'after600_complete_intervals': interval_rows(True),
    'intervals_straddling600': [{'start': left['elapsed_seconds'], 'end': right['elapsed_seconds'], 'sample_index': right['index']}
        for left, right in zip(rows, rows[1:]) if left['elapsed_seconds'] < 600 < right['elapsed_seconds']],
    'last_sample': rows[-1] if rows else None, 'rss_bytes_range': snapshot['rss_bytes_range'],
    'num_threads_range': snapshot['num_threads_range'], 'errors': snapshot['error_count'],
    'sdl_window_observations': windows, 'sdl_foreground_count': sum(row['foreground_is_game'] for row in windows),
    'sdl_visible_count': sum(row['visible'] for row in windows), 'sdl_iconic_count': sum(row['iconic'] for row in windows),
    'foreground_boundary': 'Record actual OS allocation only; foreground was not controlled as a trial variable. Difference from R43 does not prove a budget or foreground cause.',
    'native_report_capture': native_ref, 'native_report_parse': native_parse, 'native_phase': phase,
    'saved_campaign_launch_record': launch, 'native_session_record': session,
    'native_startup_records': startup_compact,
    'setup_completion_recorded_in_captured_regions': bool(setup_lines),
    'setup_completion_regions': setup_lines,
    'recorded_bridge_injection_stage': recorded_injection_stage,
    'recorded_load_completion_observation': load_observation,
    'injection_boundary': 'Presence or absence of report fields describes records at this cutoff, not an independently observed injector action. Missing log marker is bounded to captured regions.',
    'milestones': milestones, 'raw_log_captures': captured,
    'observer_terminal_receipts': {k: v for k, v in snapshot['receipts'].items() if k not in ['ARMED.actual.json', 'HANDLE-READY.actual.json']},
    'source_only': True, 'new_sampling': False, 'SDK_calls': 0, 'process_signals': 0,
    'screen_or_focus_or_input_actions': 0, 'save_body_reads': 0, 'tracked_or_Git_writes': 0,
    'business_pass': False, 'cause_or_deadlock_inferred': False}
report_ref = put('REPORT.actual.json', report)
index = put('INDEX.json', {'schema': 'ck3-r44-file-only-cutoff-index-v1', 'producer': pin(Path(__file__)),
    'reader': pin(READER), 'report': report_ref, 'snapshot': pin(snapshot_path),
    'captured_artifacts': [row['artifact'] for row in captured],
    'raw_observer_sources': [row['source'] for row in rows] + [row['source'] for row in snapshot['receipts'].values()]})
print(json.dumps({'report': report_ref, 'index': index, 'sample_count': len(rows),
    'sample_elapsed_bounds': report['sample_elapsed_bounds_seconds'], 'cpu_range': report['cpu_one_core_percent_range'],
    'after600_interval_count': len(report['after600_complete_intervals']),
    'latest_after600_intervals': report['after600_complete_intervals'][-3:],
    'last_sample': {k: (rows[-1].get(k) if rows else None) for k in ['at_utc', 'elapsed_seconds',
        'cpu_one_core_percent_over_interval', 'io_deltas', 'num_threads', 'rss_bytes', 'errors']},
    'sdl_count': len(windows), 'sdl_foreground_count': report['sdl_foreground_count'],
    'sdl_last': windows[-1] if windows else None,
    'native_phase': phase, 'saved_campaign_launch_record': launch,
    'native_report_parse': native_parse, 'setup_completion_captured': bool(setup_lines),
    'recorded_bridge_injection_stage': recorded_injection_stage,
    'milestone_lines': [row['text'] for row in milestones][-12:],
    'terminal_receipts': report['observer_terminal_receipts']}, ensure_ascii=False, indent=2))
