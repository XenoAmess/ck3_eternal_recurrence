import subprocess
from pathlib import Path
root=Path('C:/workspace/ck3_eternal_recurrence')
paths=['tools/ck3_mod_acceptance_products.json','docs/ck3-native-ai/2026-10-10-local-common-runtime-rebuild.md','docs/li-yu-dao/2026-10-09-progress.md','docs/autonomous-agent-progress/daily/2026-10-10.md','docs/autonomous-agent-progress/weekly/2026-W41.md']
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).splitlines()
if sorted(staged)!=sorted(paths):raise RuntimeError('Unexpected staged paths: '+repr(staged))
subprocess.run(['git','commit','-m','Record R43 observations and adjust the next loading budget'],cwd=root,check=True)
print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True))
