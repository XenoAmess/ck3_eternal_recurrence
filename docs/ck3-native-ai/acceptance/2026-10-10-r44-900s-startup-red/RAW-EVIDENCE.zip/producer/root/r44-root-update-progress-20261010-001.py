from pathlib import Path
import hashlib
import json
import subprocess

root = Path('C:/workspace/ck3_eternal_recurrence')
b = Path('C:/workspace/ck3_lyd_runtime_20261004')
paths = [
    'docs/ck3-native-ai/2026-10-10-local-common-runtime-rebuild.md',
    'docs/li-yu-dao/2026-10-09-progress.md',
    'docs/autonomous-agent-progress/daily/2026-10-10.md',
    'docs/autonomous-agent-progress/weekly/2026-W41.md',
]
text = '''

## 2026-10-10 10:39 CST：R43 活动观察、实际闭场与未来 R44 单预算比较

精确 `a967a41d178d5a7e080415e5f2376b58a70b0f60` 的 Official CI `38016435851`、Linear `38016435827` 均实际 SUCCESS；共享 acceptance 与 Python-only 步骤也有实际 success。Li Yu Dao 工作流 NOT_TRIGGERED，不计通过。原 `6baf0b73e` 的历史报告措辞检查失败继续保留；修后本机完整检查 exit0，生产运行时和校验器未因该文案修正改变。实际 CI 原件位于 `C:/workspace/ck3_lyd_runtime_20261004/r43-exact-a967a41d1-ci-20261010-001`，terminal evidence SHA-256 `65854e54528702656d587fb02af02053ea11bcc28c5f415a23fd35aa62bc9805`。

R43 使用原 Source05、71 正式文件、6 overlay、四项配置和固定 D2a seed，原 readiness600；公共 run/verify 均 exit2，host 原 Popen1、native frames0/steps0。未到 Setup completion，未注入、未进 handler、业务选项/SAVE/day 均0。独立只读观察取得20次采样，19个 CPU 区间均非零；最后一次约573.100秒时 CPU 仍约440.164%（单核100%口径）、RSS约5.87GiB、可用内存约17.86GB，累计 CPU 增量4732.859秒、读取5869441508字节。窗口19次均可见且未最小化，前台均为 Steam；不推断前台状态造成加载延迟。最后日志为 powerful vassals 初始化，不把日志行当作已定位阻塞函数。

独立观察句柄以 raw FILETIME 核对创建身份，在02:30:33.579721Z实际取得 CK3 exit1；它不是原 CreateProcess 句柄，原 cleanup_ok=false/session.report=null、原 Job 最终计数及原游戏退出回执缺失仍保留。最后573秒采样到退出的28.857秒无活动采样，不外推 CPU 状态。当前进程/控制文件清点为空，最终新鲜 Steam 原图10:31亲审离线，桌面恢复1024×768；keeper 原 allocate Popen0/thread joined，FINAL sequence4324，原 CAS 释放回执实际 done/resources=[] sequence4327。[R43 原始观察与闭场归档](../ck3-native-ai/2026-10-10-r43-observed-startup-red.md)独立保全。

缓存元数据只读比较证明 R38 自己的3740个 shadercache 文件也都在本轮启动之后创建/修改；原 materializer 只复制三项普通配置，没有复制 profile cache。原报告把三项误写四项的错误和追加更正均保留。不据此认定公共冷 profile 为根因，也不复制缓存或恢复额外52文件。已保存活动事件是 `.20`，marker 在此阶段缺失符合脚本顺序；没有修改存档或 marker。

下一场 R44 仅将本产品此 case 的未来 readiness600→900秒，保持 Source05、单次 loadsave、同PID/Job、加载后注入、一个绝对 deadline、原 native 守卫及所有业务输入。command300/timeout2100/hold900/poll0.5、终点60秒和退出reserve90保持；这次活动证据支持有界耗时比较，不保证成功，不延长或改写 R43 原600秒失败。外置观察器上限可延至1200秒，以覆盖新预算后的实际退出，仍只读且不改变游戏 deadline。新 profile、ID和常规前驱闭场准入必须重新取得。

并行工作：R43 证据包收尾；root 调整未来预算并更新公共准备；独立线程只读核对 R44 固定输入及观察器派生。没有新增无关能力。正式事务对照、I3b/C3/I4与一期仍 **NOT_GREEN**，75%仅工作量估计，无新增业务PASS。下一时间节点是本轮线性发布后一次最长900秒的启动检查；能否进入业务及一期完成日期仍取决于真实结果。缺失 `C:/workspace/ck3-upgrade-20261008` 不再是依赖。
'''
records=[]
for rel in paths:
    p=root/rel
    before=p.read_bytes()
    if '10:39 CST：R43 活动观察' in before.decode('utf-8-sig'):
        raise RuntimeError('Refuse duplicate append: '+rel)
    adapted=text
    if rel.startswith('docs/ck3-native-ai/'):
        adapted=text.replace('../ck3-native-ai/2026-10-10-r43-', '2026-10-10-r43-')
    elif '/daily/' in rel or '/weekly/' in rel:
        adapted=text.replace('../ck3-native-ai/', '../../ck3-native-ai/')
    after=before+adapted.encode('utf-8')
    p.write_bytes(after)
    records.append({'path':rel,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest()})
out=b/'r44-root-update-progress-20261010-001.actual.json'
if out.exists():
    raise RuntimeError('Receipt already exists')
out.write_text(json.dumps({'records':records,'root_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()},indent=2)+'\n',encoding='utf-8')
print(str(out))
