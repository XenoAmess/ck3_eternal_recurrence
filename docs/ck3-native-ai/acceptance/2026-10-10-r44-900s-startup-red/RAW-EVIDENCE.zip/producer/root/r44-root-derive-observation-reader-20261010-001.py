from pathlib import Path
import hashlib
import json
base=Path('C:/workspace/ck3_lyd_runtime_20261004')
src=base/'r43-root-read-latest-observation-20261010-001.py'
dst=base/'r44-root-read-latest-observation-20261010-001.py'
raw=src.read_bytes()
text=raw.decode().replace('R0043','R0044')
if text.count('R0044')!=1:raise RuntimeError('Unexpected path substitutions')
compile(text,str(dst),'exec')
with dst.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
with (base/'r44-root-derive-observation-reader-20261010-001.actual.json').open('x',encoding='utf-8') as f:
    json.dump({'source':str(src),'source_sha256':hashlib.sha256(raw).hexdigest(),'target':str(dst),'target_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'changes':'Only run path R0043 to R0044; reads already-written sample files'},f,indent=2)
