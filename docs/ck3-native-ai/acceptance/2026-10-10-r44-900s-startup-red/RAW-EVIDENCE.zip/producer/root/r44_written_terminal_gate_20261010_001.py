"""Check only written terminal receipt existence, then append one final file cutoff."""
from pathlib import Path
from datetime import datetime, timezone
import json
import runpy

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r44-written-startup-samples-readonly-20261010-001'
OBSERVER = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0044/startup-observer-001')
done = OUT / 'TERMINAL-CUTOFF-DONE.actual.json'
terminal = [str(OBSERVER / name) for name in ['EXIT.actual.json', 'OBSERVATION-LIMIT.actual.json',
    'DISCOVERY-MISS.actual.json'] if (OBSERVER / name).is_file()]
if done.is_file():
    print(json.dumps({'status': 'FINAL_CUTOFF_ALREADY_WRITTEN', 'receipt': str(done)}))
elif not terminal:
    print(json.dumps({'status': 'WAITING_FOR_WRITTEN_TERMINAL',
        'checked_at_utc': datetime.now(timezone.utc).isoformat(), 'new_metrics_read': False}))
else:
    runpy.run_path(str(BASE / 'r44_written_startup_cutoff_20261010_001.py'), run_name='__main__')
    cutoff = sorted(OUT.glob('cutoff-*/REPORT.actual.json'))[-1]
    with done.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump({'status': 'FINAL_CUTOFF_APPENDED', 'at_utc': datetime.now(timezone.utc).isoformat(),
            'terminal_receipts': terminal, 'report': str(cutoff), 'new_sampling': False,
            'tracked_or_Git_writes': 0}, stream, indent=2)
        stream.write('\n')
