"""Derive external R44 candidates; never execute an entry/driver/observer."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import copy
import difflib
import hashlib
import json
import subprocess

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
ROOT = Path('C:/workspace/ck3_eternal_recurrence')
OLD = BASE / 'r43-transaction-control-prepare-sourceonly-20261010-001'
OUT = BASE / 'r44-transaction-control-prepare-sourceonly-20261010-001'
CASE5 = 'C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-005'
CASE6 = 'C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-006'
L43 = Path('C:/workspace/ck3-common-runtime/runs/bf-202609141645-5434332d4d--li-yu-dao--R0043')
L44 = L43.with_name(L43.name.replace('R0043', 'R0044'))
BASELINE_HEAD = 'a967a41d178d5a7e080415e5f2376b58a70b0f60'
RUNTIME = 'C:/workspace/ck3-common-runtime/20261010-004/runtime.local.json'

def load(path):
    return json.loads(path.read_bytes())

def pin(path):
    assert path.suffix.casefold() != '.ck3', 'Save body reads are prohibited'
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def verify(ref):
    actual = pin(Path(ref['path']))
    assert actual['bytes'] == ref['bytes'] and actual['sha256'] == ref['sha256'], (actual, ref)
    return actual

def put(name, value):
    path = OUT / name
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    return pin(path)

def diff(a, b, path=''):
    if type(a) is not type(b):
        return [{'path': path, 'old': a, 'new': b}]
    if isinstance(a, dict):
        assert set(a) == set(b), (path, set(a) ^ set(b))
        return [d for key in a for d in diff(a[key], b[key], path + '/' + key)]
    if isinstance(a, list):
        assert len(a) == len(b), path
        return [d for i, (x, y) in enumerate(zip(a, b)) for d in diff(x, y, path + '/' + str(i))]
    return [] if a == b else [{'path': path, 'old': a, 'new': b}]

def find_case(data):
    found = []
    def walk(value, path):
        if isinstance(value, dict):
            if value.get('id') == 'transaction-only-control' and 'budgets' in value:
                found.append((path, value))
            for k, child in value.items():
                walk(child, path + '/' + k)
        elif isinstance(value, list):
            for i, child in enumerate(value):
                walk(child, path + '/' + str(i))
    walk(data, '')
    assert len(found) == 1
    return found[0]

def derive_argv(original, changes):
    argv = list(original)
    for key, value in changes.items():
        assert argv.count(key) == 1, key
        argv[argv.index(key) + 1] = value
    assert argv[argv.index('--runtime') + 1] == RUNTIME
    assert argv[argv.index('--product') + 1] == 'li-yu-dao'
    assert argv[argv.index('--case') + 1] == 'transaction-only-control'
    assert '--readiness-timeout' not in argv
    return argv

old_index = load(OLD / 'INDEX.json')
verified_old = [verify(ref) for ref in old_index['files']]
verify(old_index['producer'])
original = load(OLD / 'prepare-inputs.candidate.json')
assert original['state_dir'] == CASE5 + '/state'
candidate = copy.deepcopy(original)
candidate['state_dir'] = CASE6 + '/state'
input_diffs = diff(original, candidate)
assert [row['path'] for row in input_diffs] == ['/state_dir']

prepared_path = Path(CASE5) / 'prepared/prepared-case.json'
prepared = load(prepared_path)
assert prepared['product'] == 'li-yu-dao' and prepared['case'] == 'transaction-only-control'
assert original['case_inputs'] == prepared['case_inputs']
adapter_ref = verify(prepared['adapter'])
config_ref = verify(prepared['contract'])
runtime_manifest_ref = verify(prepared['runtime_manifest'])
config = load(Path(config_ref['path']))
assert config['expected']['actor_character_id'] == config['expected']['root_character_id'] == 31254
assert config['expected']['date_raw'] == original['saved_campaign']['date_raw'] == 53144712
assert config['saved_campaign'] == {k: original['saved_campaign'][k] for k in ['bytes', 'sha256', 'player_id', 'date_raw']}
assert original['saved_campaign']['bytes'] == 91711686
assert original['saved_campaign']['sha256'] == 'a6db85e38ba0648eca4b7e835c79d867b96ca26099698f4d4ee5269b818d822c'
assert Path(original['saved_campaign']['save']).stat().st_size == original['saved_campaign']['bytes']
inventory_ref = verify(original['case_inputs']['product_inventory'])
inventory = load(Path(inventory_ref['path']))
assert len(inventory['files']) == config['production_file_count'] == 71
assert inventory['source_head'] == config['production_source_head']
assert len(config['overlay_files']) == 6
content_checks = []
for directory, files in [(Path(original['case_inputs']['product_dir']), inventory['files']),
                         (Path(original['case_inputs']['overlay_dir']), config['overlay_files'])]:
    for row in files:
        actual = pin(directory / row['path'])
        assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
        content_checks.append(actual)
plain = original['case_inputs']['plain_configuration']
assert set(plain) == {'pdx_settings.txt', 'tutorial.txt', 'presets.txt', 'player/game_rules/presets.txt'}
plain_checks = {name: verify(ref) for name, ref in plain.items()}
adapter_text = Path(adapter_ref['path']).read_text(encoding='utf-8')
adapter_tree = ast.parse(adapter_text)
terminal = next(node for node in adapter_tree.body if isinstance(node, ast.FunctionDef) and node.name == 'observe_terminal')
assert any(isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add) and isinstance(node.right, ast.Constant)
    and node.right.value == 60 for node in ast.walk(terminal))

git_argv = ['git', 'show', BASELINE_HEAD + ':tools/ck3_mod_acceptance_products.json']
git = subprocess.run(git_argv, cwd=ROOT, check=True, capture_output=True)
old_registry = json.loads(git.stdout)
registry_path = ROOT / 'tools/ck3_mod_acceptance_products.json'
registry = load(registry_path)
case_path, current_case = find_case(registry)
old_case_path, old_case = find_case(old_registry)
assert old_case_path == case_path
assert old_case['budgets']['readiness_timeout'] == 600 and current_case['budgets']['readiness_timeout'] == 900
assert current_case['normal_close']['reserve_seconds'] == old_case['normal_close']['reserve_seconds'] == 90
registry_diffs = diff(old_registry, registry)
assert {row['path'] for row in registry_diffs} == {case_path + '/budgets/readiness_timeout', case_path + '/budget_provenance'}
assert {k: v for k, v in old_case['budgets'].items() if k != 'readiness_timeout'} == {k: v for k, v in current_case['budgets'].items() if k != 'readiness_timeout'}

release_path = L43 / 'release-command-001/RESULT.actual.json'
release = load(release_path)
assert release['exit_code'] == 0
release_stdout_ref = verify(release['stdout'])
release_stdout = load(Path(release_stdout_ref['path']))
assert release_stdout['ok'] is True and release_stdout['task']['state'] == 'done'
assert release_stdout['task']['resources'] == []
assert release_stdout['event']['sequence'] == release_stdout['task']['last_sequence'] == 4327
assert release_stdout['task']['task_id'] == 'common-acceptance-12004-20261010-a05'

OUT.mkdir(exist_ok=False)
(OUT / 'scripts').mkdir()
files = [put('prepare-inputs.candidate.json', candidate)]
argv_diffs = {}
source_receipts = []
for mode in ['prepare', 'preflight']:
    source = OLD / (mode.upper() + '-ARGV.actual.json')
    saved = load(source)
    changes = {'--case-inputs': (OUT / 'prepare-inputs.candidate.json').as_posix(), '--prepare-output': CASE6 + '/prepared'} if mode == 'prepare' else {'--prepared-case': CASE6 + '/prepared/prepared-case.json'}
    argv = derive_argv(saved['argv'], changes)
    files.append(put(mode.upper() + '-ARGV.actual.json', {'cwd': str(ROOT), 'argv': argv, 'executed': False}))
    argv_diffs[mode] = diff(saved['argv'], argv)
for mode in ['allocate', 'run', 'verify']:
    source = BASE / 'r43-root-case-allocate-20261010-001/RESULT.actual.json' if mode == 'allocate' else L43 / (mode + '-command-001/RESULT.actual.json')
    actual = load(source)
    if mode == 'allocate':
        assert actual['exit_code'] == 0
        changes = {'--prepared-case': CASE6 + '/prepared/prepared-case.json', '--attempt': 'a06',
            '--keeper-output': 'C:/workspace/ck3-common-runtime/keepers/20261010-a06',
            '--previous-live': str(L43), '--previous-keeper': 'C:/workspace/ck3-common-runtime/keepers/20261010-a05',
            '--previous-release': str(L43 / 'release-command-001/stdout.log')}
    else:
        changes = {'--prepared-case': CASE6 + '/prepared/prepared-case.json', '--run-context': str(L44 / 'reviewed-context.json')}
    argv = derive_argv(actual['argv'], changes)
    files.append(put(mode.upper() + '-ARGV.candidate.json', {'cwd': str(ROOT), 'argv': argv, 'executed': False,
        'inherited_actual': pin(source)}))
    argv_diffs[mode] = diff(actual['argv'], argv)
    source_receipts.append(pin(source))

script_specs = [
    ('r43-root-command-driver-20261010-001.py', 'r44-root-command-driver-20261010-001.py', 'driver'),
    ('r43-root-startup-observer-20261010-002.py', 'r44-root-startup-observer-20261010-002.py', 'observer'),
    ('r43-root-fit-desktop-20261010-001.py', 'r44-root-fit-desktop-20261010-001.py', 'helper'),
    ('r43-root-fit-steam-window-20261010-001.py', 'r44-root-fit-steam-window-20261010-001.py', 'helper'),
    ('r43-root-write-direct-review-20261010-001.py', 'r44-root-write-direct-review-20261010-001.py', 'helper')]
scripts = []
for old_name, new_name, kind in script_specs:
    source = BASE / old_name
    original_text = source.read_text(encoding='utf-8')
    text = original_text.replace('R0043', 'R0044').replace('lyd-transaction-control-20261010-005', 'lyd-transaction-control-20261010-006')
    if kind == 'driver':
        text = text.replace('r43-', 'r44-').replace("'R0042'", "'R0043'")
        text = text.replace('r42-root-case-allocate-', 'r43-root-case-allocate-')
        text = text.replace('20261010-a05', '20261010-a06').replace("'a05'", "'a06'").replace("'a04'", "'a05'")
        before = "str(b / f'r44-root-{helper}-20261010-{version}.py')"
        after = "str(Path('" + (OUT / 'scripts').as_posix() + "') / f'r44-root-{helper}-20261010-{version}.py')"
        assert text.count(before) == 1
        text = text.replace(before, after)
    elif kind == 'observer':
        assert original_text.count('900') == 3
        text = text.replace('900', '1200')
        assert text.replace('1200', '900').replace('R0044', 'R0043').replace('lyd-transaction-control-20261010-006', 'lyd-transaction-control-20261010-005') == original_text
        tree = ast.parse(text)
        assert sum(isinstance(node, (ast.While, ast.For)) for node in ast.walk(tree)) == sum(isinstance(node, (ast.While, ast.For)) for node in ast.walk(ast.parse(original_text)))
        assert 'time.monotonic() + 120' in text and 'while time.monotonic() - start < 1200:' in text
        prohibited = {'kill', 'terminate', 'suspend', 'resume', 'SetFocus', 'ShowWindow', 'SetForegroundWindow', 'SendMessage', 'PostMessage', 'click', 'press', 'hotkey', 'write'}
        calls = {node.func.attr for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)}
        assert not (calls & (prohibited - {'write'}))
    compile(text, str(OUT / 'scripts' / new_name), 'exec', dont_inherit=True)
    ast.parse(text)
    path = OUT / 'scripts' / new_name
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
    patch = ''.join(difflib.unified_diff(original_text.splitlines(True), text.splitlines(True), fromfile=str(source), tofile=str(path)))
    patch_path = OUT / 'scripts' / (new_name + '.diff')
    with patch_path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(patch)
    scripts.append({'kind': kind, 'original': pin(source), 'candidate': pin(path), 'diff': pin(patch_path),
        'compile': 'PASS', 'ast_parse': 'PASS', 'executed': False})
files.append(put('SCRIPT-DERIVATIONS.actual.json', scripts))
files.append(put('REGISTRY-DIFF.actual.json', {'baseline_git_argv': git_argv, 'baseline_git_exit_code': git.returncode,
    'baseline_registry_bytes': len(git.stdout), 'baseline_registry_sha256': hashlib.sha256(git.stdout).hexdigest(),
    'current_registry': pin(registry_path), 'differences': registry_diffs,
    'old_budgets': old_case['budgets'], 'new_budgets': current_case['budgets'], 'normal_close': current_case['normal_close']}))
files.append(put('CONTENT-PIN-CHECKS.actual.json', {'product_inventory': inventory_ref,
    'production_count': 71, 'overlay_count': 6, 'content_checks': content_checks,
    'plain_configuration_count': 4, 'plain_configuration_checks': plain_checks,
    'seed': candidate['saved_campaign'], 'seed_size_stat_only': True, 'seed_body_reads': 0, 'seed_hashes_computed': 0,
    'adapter': adapter_ref, 'config': config_ref, 'runtime_manifest': runtime_manifest_ref}))
files.append(put('DERIVATION.actual.json', {'schema': 'lyd.r44.prepare-sourceonly.v1',
    'at_utc': datetime.now(timezone.utc).isoformat(), 'inputs_source': pin(OLD / 'prepare-inputs.candidate.json'),
    'input_differences': input_diffs, 'argv_differences': argv_diffs,
    'other_case_inputs_exactly_equal': True, 'actor': 31254, 'date_raw': 53144712,
    'terminal_observation_seconds': 60, 'normal_close_reserve_seconds': 90,
    'registry_only_readiness_budget_change': [600, 900], 'observer_only_bound_change': [900, 1200],
    'observer_discovery_seconds': 120, 'observer_sample_interval_seconds': 30,
    'runtime_unchanged': RUNTIME, 'previous_release': {'recorded_command': pin(release_path),
        'actual_stdout': release_stdout_ref, 'actual_release_sequence': 4327},
    'case006_exists_at_authoring': Path(CASE6).exists(), 'runR0044_exists_at_authoring': L44.exists(),
    'new_loop_deadlines': 0, 'seed_body_reads': 0, 'public_entry_invocations': 0,
    'game_launches': 0, 'SDK_calls': 0, 'repo_writes': 0, 'candidate_execution': False, 'business_pass': False}))
index = put('INDEX.json', {'schema': 'lyd.r44.sourceonly-candidates-index.v1', 'producer': pin(Path(__file__)),
    'original_r43_index': pin(OLD / 'INDEX.json'), 'verified_r43_files': verified_old,
    'r43_prepared_case': pin(prepared_path), 'inherited_actual_sources': source_receipts,
    'files': files + [entry[key] for entry in scripts for key in ['candidate', 'diff']],
    'source_pin_checks': 'PASS', 'candidate_compile_checks': '5 PASS; none executed'})
print(json.dumps({'index': index, 'inputs': files[0], 'scripts': [entry['candidate'] for entry in scripts],
    'registry_differences': registry_diffs, 'content_pin_checks': len(content_checks), 'plain_configuration_checks': len(plain_checks),
    'previous_release_sequence': 4327, 'readiness_seconds': 900, 'observer_seconds': 1200,
    'candidate_compile': '5 PASS', 'executed_candidates': 0}, ensure_ascii=False, indent=2))
