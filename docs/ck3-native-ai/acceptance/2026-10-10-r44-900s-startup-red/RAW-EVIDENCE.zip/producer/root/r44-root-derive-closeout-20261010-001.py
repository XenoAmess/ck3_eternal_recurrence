from pathlib import Path
import hashlib
import json
base=Path('C:/workspace/ck3_lyd_runtime_20261004')
src=base/'r43-root-closeout-20261010-001.py'
dst=base/'r44-root-closeout-20261010-001.py'
raw=src.read_bytes()
text=raw.decode('utf-8')
for old,new in [('R0043','R0044'),('R43','R44'),('20261010-a05','20261010-a06'),('20261010-005','20261010-006'),("== 10656","== 14012"),("'visible_desktop_clock': '10:31 2026/10/10'","'visible_desktop_clock': sys.argv[1] + ' 2026/10/10'")]:
    if old not in text:raise RuntimeError('Missing expected replacement: '+old)
    text=text.replace(old,new)
compile(text,str(dst),'exec')
with dst.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
with (base/'r44-root-derive-closeout-20261010-001.actual.json').open('x',encoding='utf-8') as f:
    json.dump({'source':str(src),'source_sha256':hashlib.sha256(raw).hexdigest(),'target':str(dst),'target_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'changes':'R44/a06/case006/actual observed PID14012; final clock must be supplied after direct image review','executed':False,'guards':'Only actual completed RED/host1/independent CK3exit1; no success assumed'},f,indent=2)
print(str(dst))
