028A6B50  48 89 5c 24 08                               mov qword ptr [rsp + 8], rbx
028A6B55  48 89 7c 24 10                               mov qword ptr [rsp + 0x10], rdi
028A6B5A  48 8b d9                                     mov rbx, rcx
028A6B5D  4d 8b d0                                     mov r10, r8
028A6B60  b9 33 f3 04 b5                               mov ecx, 0xb504f333
028A6B65  49 b8 66 e6 09 6a 01 00 00 00                movabs r8, 0x16a09e666
028A6B6F  48 8d 04 0a                                  lea rax, [rdx + rcx]
028A6B73  49 3b c0                                     cmp rax, r8
028A6B76  77 30                                        ja 0x28a6ba8
028A6B78  49 8d 04 0a                                  lea rax, [r10 + rcx]
028A6B7C  49 3b c0                                     cmp rax, r8
028A6B7F  77 27                                        ja 0x28a6ba8
028A6B81  49 0f af d2                                  imul rdx, r10
028A6B85  48 bf 09 e1 d1 c6 11 6b f1 29                movabs rdi, 0x29f16b11c6d1e109
028A6B8F  48 8b c7                                     mov rax, rdi
028A6B92  48 f7 ea                                     imul rdx
028A6B95  4c 8b da                                     mov r11, rdx
028A6B98  49 c1 fb 0e                                  sar r11, 0xe
028A6B9C  49 8b c3                                     mov rax, r11
028A6B9F  48 c1 e8 3f                                  shr rax, 0x3f
028A6BA3  4c 03 d8                                     add r11, rax
028A6BA6  eb 58                                        jmp 0x28a6c00
028A6BA8  4c 3b d2                                     cmp r10, rdx
028A6BAB  4d 8b c2                                     mov r8, r10
028A6BAE  48 bf 09 e1 d1 c6 11 6b f1 29                movabs rdi, 0x29f16b11c6d1e109
028A6BB8  4c 0f 4c c2                                  cmovl r8, rdx
028A6BBC  4c 0f 4f d2                                  cmovg r10, rdx
028A6BC0  48 8b c7                                     mov rax, rdi
028A6BC3  49 f7 e8                                     imul r8
028A6BC6  48 8b ca                                     mov rcx, rdx
028A6BC9  48 c1 f9 0e                                  sar rcx, 0xe
028A6BCD  48 8b c1                                     mov rax, rcx
028A6BD0  48 c1 e8 3f                                  shr rax, 0x3f
028A6BD4  48 03 c8                                     add rcx, rax
028A6BD7  48 69 c1 a0 86 01 00                         imul rax, rcx, 0x186a0
028A6BDE  49 0f af ca                                  imul rcx, r10
028A6BE2  4c 2b c0                                     sub r8, rax
028A6BE5  48 8b c7                                     mov rax, rdi
028A6BE8  4d 0f af c2                                  imul r8, r10
028A6BEC  49 f7 e8                                     imul r8
028A6BEF  48 c1 fa 0e                                  sar rdx, 0xe
028A6BF3  4c 8b da                                     mov r11, rdx
028A6BF6  49 c1 eb 3f                                  shr r11, 0x3f
028A6BFA  4c 03 da                                     add r11, rdx
028A6BFD  4c 03 d9                                     add r11, rcx
028A6C00  4d 85 c9                                     test r9, r9
028A6C03  75 16                                        jne 0x28a6c1b
028A6C05  b8 ff ff ff ff                               mov eax, 0xffffffff
028A6C0A  48 89 03                                     mov qword ptr [rbx], rax
028A6C0D  48 8b c3                                     mov rax, rbx
028A6C10  48 8b 5c 24 08                               mov rbx, qword ptr [rsp + 8]
028A6C15  48 8b 7c 24 10                               mov rdi, qword ptr [rsp + 0x10]
028A6C1A  c3                                           ret 
028A6C1B  48 b8 a3 8d 23 d6 e2 53 00 00                movabs rax, 0x53e2d6238da3
028A6C25  48 b9 46 1b 47 ac c5 a7 00 00                movabs rcx, 0xa7c5ac471b46
028A6C2F  49 03 c3                                     add rax, r11
028A6C32  48 3b c1                                     cmp rax, rcx
028A6C35  77 1d                                        ja 0x28a6c54
028A6C37  49 69 c3 a0 86 01 00                         imul rax, r11, 0x186a0
028A6C3E  48 99                                        cqo 
028A6C40  49 f7 f9                                     idiv r9
028A6C43  48 89 03                                     mov qword ptr [rbx], rax
028A6C46  48 8b c3                                     mov rax, rbx
028A6C49  48 8b 5c 24 08                               mov rbx, qword ptr [rsp + 8]
028A6C4E  48 8b 7c 24 10                               mov rdi, qword ptr [rsp + 0x10]
028A6C53  c3                                           ret 
028A6C54  49 8b c1                                     mov rax, r9
028A6C57  48 b9 00 e4 0b 54 02 00 00 00                movabs rcx, 0x2540be400
028A6C61  48 99                                        cqo 
028A6C63  48 33 c2                                     xor rax, rdx
028A6C66  48 2b c2                                     sub rax, rdx
028A6C69  48 3b c1                                     cmp rax, rcx
028A6C6C  48 8b c7                                     mov rax, rdi
028A6C6F  7c 30                                        jl 0x28a6ca1
028A6C71  49 f7 e9                                     imul r9
028A6C74  49 8b c3                                     mov rax, r11
028A6C77  4c 8b c2                                     mov r8, rdx
028A6C7A  48 99                                        cqo 
028A6C7C  49 c1 f8 0e                                  sar r8, 0xe
028A6C80  49 8b c8                                     mov rcx, r8
028A6C83  48 c1 e9 3f                                  shr rcx, 0x3f
028A6C87  4c 03 c1                                     add r8, rcx
028A6C8A  49 f7 f8                                     idiv r8
028A6C8D  48 8b c8                                     mov rcx, rax
028A6C90  48 89 03                                     mov qword ptr [rbx], rax
028A6C93  48 8b c3                                     mov rax, rbx
028A6C96  48 8b 5c 24 08                               mov rbx, qword ptr [rsp + 8]
028A6C9B  48 8b 7c 24 10                               mov rdi, qword ptr [rsp + 0x10]
028A6CA0  c3                                           ret 
028A6CA1  49 f7 eb                                     imul r11
028A6CA4  48 8b 7c 24 10                               mov rdi, qword ptr [rsp + 0x10]
028A6CA9  48 c1 fa 0e                                  sar rdx, 0xe
028A6CAD  48 8b c2                                     mov rax, rdx
028A6CB0  48 c1 e8 3f                                  shr rax, 0x3f
028A6CB4  48 03 d0                                     add rdx, rax
028A6CB7  48 69 ca a0 86 01 00                         imul rcx, rdx, 0x186a0
028A6CBE  48 8b c1                                     mov rax, rcx
028A6CC1  4c 2b d9                                     sub r11, rcx
028A6CC4  48 99                                        cqo 
028A6CC6  49 f7 f9                                     idiv r9
028A6CC9  4c 8b d0                                     mov r10, rax
028A6CCC  4c 8b c2                                     mov r8, rdx
028A6CCF  49 69 c3 a0 86 01 00                         imul rax, r11, 0x186a0
028A6CD6  48 99                                        cqo 
028A6CD8  49 f7 f9                                     idiv r9
028A6CDB  48 8b c8                                     mov rcx, rax
028A6CDE  49 69 c0 a0 86 01 00                         imul rax, r8, 0x186a0
028A6CE5  48 99                                        cqo 
028A6CE7  49 f7 f9                                     idiv r9
028A6CEA  48 03 c8                                     add rcx, rax
028A6CED  49 69 c2 a0 86 01 00                         imul rax, r10, 0x186a0
028A6CF4  48 03 c8                                     add rcx, rax
028A6CF7  48 8b c3                                     mov rax, rbx
028A6CFA  48 89 0b                                     mov qword ptr [rbx], rcx
028A6CFD  48 8b 5c 24 08                               mov rbx, qword ptr [rsp + 8]
028A6D02  c3                                           ret 
