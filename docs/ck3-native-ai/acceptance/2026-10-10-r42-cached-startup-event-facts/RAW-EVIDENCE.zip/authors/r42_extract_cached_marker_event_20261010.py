from pathlib import Path
import hashlib
import json

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r42-seed-marker-event-cached-readonly-20261010-001'
SOURCES = [BASE / 'r38-offline-cache-candidates-20261009-001' / n for n in ('R34_D2a.json', 'R34_D2b.json', 'R38_after_selection.json')]
SOURCES += [BASE / 'live-attempt-034/diagnostic-mcp-client-001/0014-r34-D2a-stage-window-001.native-01.json', BASE / 'live-attempt-038/diagnostic-mcp-client-001/0004-r38-D2a-window-001.native-01.json', BASE / 'live-attempt-038/NO-EVENT-STATE.actual.json']

def reference(path, body):
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def walk(obj, path=(), parent=None):
    if isinstance(obj, dict):
        for k, value in obj.items():
            yield from walk(value, path + (str(k),), obj)
    elif isinstance(obj, list):
        for i, value in enumerate(obj):
            yield from walk(value, path + (str(i),), obj)
    else:
        yield path, obj, parent

result = []
for source in SOURCES:
    body = source.read_bytes()
    obj = json.loads(body.decode('utf-8-sig'))
    row = {'source': reference(source, body), 'keys': list(obj) if isinstance(obj, dict) else None, 'marker_matches': [], 'event_identity_matches': []}
    if isinstance(obj, dict) and 'save' in obj:
        row['cached_save_reference'] = obj['save']
        chars = obj.get('characters')
        row['characters_shape'] = {'type': type(chars).__name__, 'keys': list(chars)[:5] if isinstance(chars,dict) else None}
        actor = chars.get('31254') if isinstance(chars,dict) else None
        row['actor_shape'] = {'type': type(actor).__name__, 'keys': list(actor) if isinstance(actor, dict) else None}
    for path, value, parent in walk(obj):
        if isinstance(value, str) and 'empty_transaction_completed' in value:
            row['marker_matches'].append({'json_path': '/'.join(path), 'value': value, 'parent': parent})
        if isinstance(value, str) and 'lyd_factory_diag.' in value:
            row['event_identity_matches'].append({'json_path': '/'.join(path), 'value': value, 'parent': parent if len(json.dumps(parent)) < 5000 else 'parent exceeds display bound'})
    if 'characters' not in obj:
        row['native_event_container'] = obj
    result.append(row)
with (OUT / 'CACHED-MARKER-EVENT-EXTRACTION.actual.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
for row in result:
    print(json.dumps({k: v for k, v in row.items() if k != 'native_event_container'}, ensure_ascii=False))
    if 'native_event_container' in row:
        container = row['native_event_container']
        print(json.dumps({'native_event_top_keys': list(container) if isinstance(container,dict) else None}, ensure_ascii=False))
