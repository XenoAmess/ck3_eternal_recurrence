from pathlib import Path
import hashlib
import json
import sys

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r42-seed-marker-event-cached-readonly-20261010-001'

def ref(path):
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def write_new(name, value):
    path = OUT / name
    body = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    with path.open('xb') as stream:
        stream.write(body)
    return ref(path)

if sys.argv[1:] != ['plan']:
    raise SystemExit('Only plan mode defined')
OUT.mkdir(exist_ok=False)
keys = ('r34', 'r38', 'attempt-034', 'attempt-038', 'source03', 'source-03', 'source003', 'source-003')
dirs = [p for p in BASE.iterdir() if p.is_dir() and any(k in p.name.lower() for k in keys)]
plan = {
    'schema': 'lyd.r42.cached-marker-event-inquiry.plan.v1',
    'scope': 'Existing R34 D2a / R38 STATE, checkpoint JSON, indexes and Source03 startup handler source; no seed body read.',
    'questions': ['empty_transaction_completed marker present/absent/unknown in existing projection', 'active event namespace, definition and instance', 'Source03 prepared startup handler .20 relationship to fixture diag.2'],
    'forbidden': ['CK3 or SDK or process inspection', 'save body', 'MAIN edits', 'native image scanning', 'new run or longer deadline'],
    'causal_claim': 'UNKNOWN',
    'next_after_listing': 'Read only identified cached projections/indexes and exact startup handler source; absence from unprojected keys remains UNKNOWN.',
    'candidate_directories': [str(p) for p in sorted(dirs)],
}
write_new('PLAN.json', plan)
listing = {}
for directory in sorted(dirs):
    files = []
    for path in directory.rglob('*.json'):
        name = path.name.lower()
        if any(k in name for k in ('index', 'state', 'checkpoint', 'prepared', 'startup', 'summary', 'binding', 'manifest')):
            files.append({'path': str(path), 'bytes': path.stat().st_size})
    listing[str(directory)] = files
write_new('CACHED-CANDIDATE-PATHS.json', listing)
print(json.dumps({'directories': plan['candidate_directories'], 'counts': {k: len(v) for k, v in listing.items()}}, ensure_ascii=False, indent=2))
