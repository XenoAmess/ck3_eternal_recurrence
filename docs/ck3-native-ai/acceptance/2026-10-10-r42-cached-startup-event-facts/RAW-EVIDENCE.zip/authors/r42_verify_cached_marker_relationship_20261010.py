from pathlib import Path
import hashlib
import json

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r42-seed-marker-event-cached-readonly-20261010-001'
MARKER = 'lyd_factory_diag_empty_transaction_completed'

def ref(path, body=None):
    body = path.read_bytes() if body is None else body
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def write_new(name, value):
    with (OUT / name).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

actors = []
for name in ('R34_D2a.json', 'R34_D2b.json', 'R38_after_selection.json'):
    path = BASE / 'r38-offline-cache-candidates-20261009-001' / name
    body = path.read_bytes()
    data = json.loads(body.decode('utf-8-sig'))
    actor = data['characters']['31254']
    raw_alive = actor['alive_data']
    alive_keys = [r.get('key') for r in raw_alive]
    variable_nodes = [r for r in raw_alive if r.get('key') == 'variables']
    if len(variable_nodes) != 1:
        raise ValueError('Cached actor must preserve one raw alive_data variables node')
    raw_bytes = json.dumps(variable_nodes[0], ensure_ascii=False).encode('utf-8')
    actors.append({
        'source': ref(path, body), 'cached_save': data['save'], 'actor_id': 31254,
        'marker_in_cached_actor_variables': MARKER in actor['variables'],
        'marker_occurrences_in_cached_packet': body.count(MARKER.encode('utf-8')),
        'marker_occurrences_in_raw_actor_variable_AST': raw_bytes.count(MARKER.encode('utf-8')),
        'actor_variable_count': len(actor['variables']), 'raw_alive_keys': alive_keys,
        'raw_variable_node_sha256': hashlib.sha256(raw_bytes).hexdigest(),
        'raw_variable_node': variable_nodes[0],
        'finding': 'ABSENT_IN_CACHED_ACTOR_VARIABLES_AND_RAW_VARIABLE_AST',
        'global_event_queue_from_this_packet': 'UNKNOWN_NOT_PROJECTED',
    })
write_new('CACHED-ACTOR-MARKER-VERIFIED.actual.json', actors)
sources = [
    ('Source03-host-admission', Path('C:/csr3/ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py'), [(785,835),(2496,2555)]),
    ('pinned-product-adapter', Path('C:/workspace/ck3_eternal_recurrence/tools/ck3_mod_acceptance_cases/lyd_transaction_control_adapter.py'), [(145,215),(305,340)]),
    ('reader-variable-map', Path('C:/workspace/ck3_eternal_recurrence/tools/lyd_i3b_checkpoint_readback/reader/i3b_checkpoint_reader.py'), [(1,70),(235,250)]),
    ('prior-event-R38', BASE / 'r42-prior-fixture-startup-hook-sourceonly-20261010-001/source-cuts/R38/diagnostic_stage/events/lyd_factory_operation_diagnostic.txt', [(45,106)]),
    ('current-overlay-event-R41', BASE / 'r42-prior-fixture-startup-hook-sourceonly-20261010-001/source-cuts/R41/diagnostic_stage/events/lyd_factory_operation_diagnostic.txt', [(45,106)]),
]
cuts = []
for role,path,ranges in sources:
    body = path.read_bytes()
    if role == 'pinned-product-adapter' and hashlib.sha256(body).hexdigest() != 'f2fbbfc3c78d7cfe7d45b5c2d0afd0337dd9ebd834f7c81ce46c672dfff49964':
        raise ValueError('Pinned product adapter differs')
    lines = body.decode('utf-8-sig').splitlines()
    cuts.append({'role': role, 'source': ref(path, body), 'cuts': [{'first_line': lo, 'last_line': hi, 'lines': [{'line': n, 'text': lines[n-1]} for n in range(lo, min(hi,len(lines))+1)]} for lo,hi in ranges]})
write_new('SOURCE-RELATIONSHIP-CUTS.actual.json', cuts)
for actor in actors:
    print(json.dumps({k:v for k,v in actor.items() if k != 'raw_variable_node'}, ensure_ascii=False))
for cut in cuts:
    print(json.dumps(cut, ensure_ascii=False))
