from pathlib import Path
import json

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r42-seed-marker-event-cached-readonly-20261010-001'
listing = json.loads((OUT / 'CACHED-CANDIDATE-PATHS.json').read_text(encoding='utf-8'))
for directory, files in listing.items():
    if files and ('live-attempt' in directory or 'no-follow' in directory):
        print(json.dumps({'directory': directory, 'files': files}, ensure_ascii=False))
for name in ('R34_D2a.json', 'R34_D2b.json', 'R38_after_selection.json', 'COMPARISON.json'):
    path = BASE / 'r38-offline-cache-candidates-20261009-001' / name
    obj = json.loads(path.read_text(encoding='utf-8-sig'))
    print(json.dumps({'path': str(path), 'bytes': path.stat().st_size, 'top_keys': list(obj) if isinstance(obj, dict) else None, 'scalars': {k: v for k, v in obj.items() if not isinstance(v, (dict,list))} if isinstance(obj, dict) else None}, ensure_ascii=False))
    if path.stat().st_size < 10000:
        print(json.dumps(obj, ensure_ascii=False))
