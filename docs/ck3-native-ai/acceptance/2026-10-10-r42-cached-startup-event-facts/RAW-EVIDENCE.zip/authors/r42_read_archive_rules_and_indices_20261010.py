from pathlib import Path
import hashlib
import json

MAIN = Path('C:/workspace/ck3_eternal_recurrence')
BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r42-cached-startup-event-permanent-archive-20261010-001'
OUT.mkdir(exist_ok=False)
rules = (MAIN / 'AGENTS.md').read_text(encoding='utf-8-sig').splitlines()
print('\n'.join(f'{i}: {rules[i-1]}' for i in range(440, min(490,len(rules))+1)))
paths = [
    BASE / 'r42-seed-marker-event-cached-readonly-20261010-001/INDEX.json',
    BASE / 'r41-engine-load-callchain-diagnostic-20261010-001/INDEX.json',
    MAIN / 'docs/ck3-native-ai/acceptance/2026-10-10-r42-shared-runtime-startup-red/INDEX.json',
    MAIN / 'docs/ck3-native-ai/acceptance/2026-10-10-saved-startup-event-admission/INDEX.actual.json',
]
def walk(value, path=()):
    if isinstance(value, dict):
        for key, item in value.items():
            yield from walk(item, path + (str(key),))
    elif isinstance(value, list):
        for i, item in enumerate(value):
            yield from walk(item, path + (str(i),))
    elif isinstance(value, str):
        yield path, value
results=[]
needles = ('event_manager', 'event-manager', 'eventqueue', 'event_queue', 'saved-event-queue', 'saved_event_queue')
for path in paths:
    body = path.read_bytes()
    value = json.loads(body.decode('utf-8-sig'))
    matches = [{'json_path':'/'.join(location), 'value':string} for location,string in walk(value) if any(needle in string.casefold() for needle in needles)]
    results.append({'index':{'path':str(path),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()},'specific_event_manager_or_saved_queue_reference_matches':matches})
value={'schema':'lyd.r42.cached-event-queue-index-lookup.v1','scope':'Only four already-known relevant indexes, metadata strings only; no directory traversal or referenced file opening.','indices':results,'conclusion':'No saved event-manager/queue projection is identified by these index metadata records. This is not an exhaustive absence claim for all external files.','save_body_reads':0,'new_runtime_queries':0}
with (OUT / 'EVENT-QUEUE-INDEX-LOOKUP.actual.json').open('x',encoding='utf-8',newline='\n') as stream:
    json.dump(value,stream,ensure_ascii=False,indent=2)
    stream.write('\n')
print(json.dumps({'index_counts':len(results),'matches':sum(len(row['specific_event_manager_or_saved_queue_reference_matches']) for row in results),'conclusion':value['conclusion']},ensure_ascii=False))
