from pathlib import Path
import hashlib
import json

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r42-seed-marker-event-cached-readonly-20261010-001'
PRIOR = BASE / 'r42-prior-fixture-startup-hook-sourceonly-20261010-001/source-cuts'

def ref(path, body=None):
    body = path.read_bytes() if body is None else body
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def write_new(name, obj):
    body = (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    path = OUT / name
    with path.open('xb') as stream:
        stream.write(body)
    return ref(path, body)

actors = json.loads((OUT / 'CACHED-ACTOR-MARKER-VERIFIED.actual.json').read_text(encoding='utf-8'))
extraction = json.loads((OUT / 'CACHED-MARKER-EVENT-EXTRACTION.actual.json').read_text(encoding='utf-8'))
events = []
for row in extraction:
    container = row.get('native_event_container', {})
    event = container.get('result', {}).get('current_event_window_context')
    if isinstance(event, dict):
        root = event['root_scope']['typed_identity']['character_id']
        events.append({'source': row['source'], 'definition': event['event_definition_key'], 'namespace': event['event_definition_key'].rsplit('.',1)[0], 'instance_id': event['current_event_instance_id'], 'root_character_id': root, 'date_raw': event['date_raw'], 'native_snapshot_revision': event['snapshot_revision'], 'calculated_event_id': event['calculated_event_id'], 'runtime_stats_ordinal': event['runtime_stats_ordinal'], 'native_options': [{'native_option_index': item['native_option_index'], 'shown': item['shown'], 'enabled': item['enabled']} for item in event['options']]})

old = PRIOR / 'R38/diagnostic_stage/events/lyd_factory_operation_diagnostic.txt'
new = PRIOR / 'R41/diagnostic_stage/events/lyd_factory_operation_diagnostic.txt'
def d20(path):
    text = path.read_text(encoding='utf-8-sig')
    return text.split('lyd_factory_diag.20 = {',1)[1].split('lyd_factory_diag.2 = {',1)[0].strip()
old_block, new_block = d20(old), d20(new)
if old_block != new_block:
    raise ValueError('Event .20 source block differs')
effect_path = PRIOR / 'R41/diagnostic_stage/common/scripted_effects/lyd_i3b_commit_effects.txt'
effect_lines = effect_path.read_text(encoding='utf-8-sig').splitlines()
if 'lyd_factory_diag_d2_effect = {' not in effect_lines[117] or 'empty_transaction_completed' not in effect_lines[120] or 'trigger_event = lyd_factory_diag.2' not in effect_lines[122]:
    raise ValueError('D2 writer and terminal event sequence differs')

inputs = [
    Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-004/prepared/saved-startup-case-contract.json'),
    Path('C:/workspace/ck3_eternal_recurrence/tools/ck3_mod_acceptance_cases/lyd_transaction_control_adapter.py'),
    Path('C:/workspace/ck3_eternal_recurrence/tools/ck3_mod_acceptance_cases/lyd_transaction_control.json'),
]
frozen = []
input_dir = OUT / 'source-inputs'
input_dir.mkdir(exist_ok=False)
for path in inputs:
    body = path.read_bytes()
    target = input_dir / path.name
    with target.open('xb') as stream:
        stream.write(body)
    frozen.append({'original': ref(path, body), 'preserved': ref(target, body)})
contract = json.loads(inputs[0].read_text(encoding='utf-8'))
case = json.loads(inputs[2].read_text(encoding='utf-8'))
if contract['handler']['sha256'] != frozen[1]['original']['sha256'] or contract['dependencies'][0]['sha256'] != frozen[2]['original']['sha256']:
    raise ValueError('Prepared contract source pin differs')
if contract['expected'] != case['expected']:
    raise ValueError('Prepared and case expected event identity differs')
if case['saved_campaign']['sha256'] != actors[0]['cached_save']['sha256']:
    raise ValueError('Prepared seed differs from R34 D2a cached seed')
summary = {
    'schema': 'lyd.r42.cached-marker-event-diagnostic.source-only.v1',
    'source_inputs': frozen,
    'marker_findings': [{k:v for k,v in row.items() if k not in ('raw_variable_node', 'raw_alive_keys')} for row in actors],
    'actual_native_event_identities': events,
    'prepared_expected': contract['expected'],
    'seed_reference_matches_cached_R34_D2a': True,
    'startup_event_d20_source': {'R38': ref(old), 'current_overlay': ref(new), 'source_lines': [52,77], 'exact_source_block_equal': True, 'block_sha256': hashlib.sha256(new_block.encode('utf-8')).hexdigest(), 'marker_required': False},
    'd20_to_terminal': {'effect_source': ref(effect_path), 'd20_option_calls_D2_effect_line': 73, 'D2_effect_line': 118, 'marker_write_line': 121, 'terminal_d2_trigger_line': 123, 'terminal_marker_guards': [87,94], 'terminal_definition': case['terminal_event_definition_key']},
    'host_source_relationship': {'source': 'C:/csr3/ck3_autonomous_player/native_bridge/research/run_ck3_12002_mcp_live.py', 'call_site_line': 820, 'stable_native_owner_frames_before_handler': [802,819], 'function_line': 2496, 'typed_native_query_lines': [2528,2529], 'startup_case_selections': 0},
    'product_adapter_relationship': {'function_line': 195, 'event_identity_checks': [152,192], 'startup_admission_marker_check': False, 'business_selection_line': 321, 'terminal_event_observation_line': 328},
    'unknown': ['global saved event queue is not projected by these cached packets', 'why CK3 stops after Setup powerful vassals before InGame', 'whether any unrelated restored event or engine initialization contributes to timeout'],
    'conclusion': 'The absent marker belongs to post-selection .2; it does not gate the observed saved startup .20 or the pinned Source03 product startup admission. No evidence supports changing it as a startup repair.',
    'next_minimal_verification': 'Do not vary marker or mount all extras. If a saved-event restoration hypothesis remains a chosen diagnostic direction, first locate an existing event-manager/queue projection; if absent, ROOT may separately authorize a single bounded projection of the same a6db seed event-manager records, preserving instance/definition/saved-scope identity and scheduled-event inventory without business action. This task did not read a save body or create that projection.',
    'execution': {'save_body_reads': 0, 'SDK_or_game_actions': 0, 'native_scans': 0, 'tests': [], 'MAIN_writes': 0, 'future_runtime_result': None},
}
summary_ref = write_new('SUMMARY.actual.json', summary)
report = '''# R34 D2a / R38 已缓存 marker 与事件身份核对

actor31254 的三份既有投影（R34 D2a、D2b、R38 selection 后）均保存完整 `alive_data.variables` AST，103 个变量中没有 `lyd_factory_diag_empty_transaction_completed`；整个缓存包也没有该名称。此为缓存内确定的缺失，不是本轮重新解析存档的结果。三个原 JSON 与相应 save 的精确 hash 见 SUMMARY。

R34 D2a 的原 native 回执和 R38 重载后的原 native 回执均确认 `lyd_factory_diag.20`、instance121、root31254、date53144712、option native0 显示且可用。两轮 calculatedEventId/运行目录序号不同，不能据它们代替 definition/instance 身份。Source03 当前 prepared 合同与相同的 a6db D2a seed 绑定，准确等待 `.20`，不是 `.2`。

旧 R38 与当前 overlay 的 `.20` 源块（事件文件52–77行）逐字相同。`.20` 的 event/option guard 是 stage20 与 unheld-title；不读取 completed marker。选择其 option 才在73行调用 D2 effect；当前 effect 在121行写 marker，123行触发后继 `.2`。当前 `.2` 的87/94行才读取 marker。因此 marker 在这份启动 seed 中缺失与源码阶段顺序一致，现有事实不支持把它改成启动修复。

Source03 host 在802–819行取得稳定 native owner/map frame 及 campaign root 后，才于820行调用 saved-startup admission。2496行函数仅查询 typed current event；产品 handler195–201行核 `.20` 身份并返回 business_pass=false，不选项、不检查 completed marker。业务选择是另一条 run_case 路径的321行。R42 未注入的加载超时没有进入该 typed handler。

三份缓存不含全局 event-manager/queue 投影，所以其他已保存/排队事件保持 UNKNOWN。R38 selection 后的旧诊断终局是 no-event，旧 `.2` 要求 held-title，与当时 unheld Title 不符；这个后继阶段事实不解释更早的启动停滞。

下一步不改 marker、不挂52 extras。若 ROOT 继续选择 saved-event 恢复假设，先定位已有 event-manager/queue 导出；若确实没有，再另行授权对同一 a6db seed 作一次有界 event-manager 记录投影，仅补 instance/definition/saved-scope 与排队事件清单。当前没有读取任何 .ck3 正文、操作 SDK/游戏、扫描 EXE、测试或修改主仓，也没有确定启动根因。
'''
report_path = OUT / 'REPORT.zh.md'
with report_path.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(report)
artifacts = [ref(path) for path in sorted(OUT.rglob('*')) if path.is_file()]
authors = [ref(BASE / name) for name in ('r42_cached_marker_event_inquiry_20261010.py','r42_inspect_cached_paths_20261010.py','r42_extract_cached_marker_event_20261010.py','r42_inspect_cached_actor_and_handler_20261010.py','r42_verify_cached_marker_relationship_20261010.py','r42_seal_cached_marker_event_report_20261010.py')]
index_ref = write_new('INDEX.json', {'schema': 'lyd.r42.cached-marker-event-diagnostic.index.v1', 'summary': summary_ref, 'report': ref(report_path), 'artifacts': artifacts, 'authors': authors, 'save_body_reads': 0, 'root_cause': 'UNKNOWN'})
print(json.dumps({'index': index_ref, 'summary': summary_ref, 'report': ref(report_path)}, ensure_ascii=False, indent=2))
