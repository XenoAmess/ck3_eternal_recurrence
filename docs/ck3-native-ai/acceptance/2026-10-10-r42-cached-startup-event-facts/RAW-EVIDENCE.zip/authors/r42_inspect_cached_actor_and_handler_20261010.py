from pathlib import Path
import hashlib
import json

BASE = Path('C:/workspace/ck3_lyd_runtime_20261004')
OUT = BASE / 'r42-seed-marker-event-cached-readonly-20261010-001'
rows = []
for name in ('R34_D2a.json', 'R34_D2b.json', 'R38_after_selection.json'):
    source = BASE / 'r38-offline-cache-candidates-20261009-001' / name
    obj = json.loads(source.read_text(encoding='utf-8-sig'))
    actor = obj['characters']['31254']
    row = {'name': name, 'actor_variables': actor['variables'], 'entries_type': type(actor['entries']).__name__, 'entries_count': len(actor['entries']), 'entries_sample': actor['entries'][:4] if isinstance(actor['entries'],list) else list(actor['entries'])[:8], 'landed_data_type': type(actor['landed_data']).__name__, 'AST_sha256': actor['AST_sha256']}
    rows.append(row)
    print(json.dumps(row, ensure_ascii=False))
fixed = [
    Path('C:/workspace/ck3-common-runtime/cases/lyd-transaction-control-20261010-004/prepared/saved-startup-case-contract.json'),
    Path('C:/workspace/ck3_eternal_recurrence/tools/ck3_mod_acceptance_cases/lyd_transaction_control_adapter.py'),
    Path('C:/workspace/ck3_eternal_recurrence/tools/ck3_mod_acceptance_cases/lyd_transaction_control.json'),
]
for source in fixed:
    body = source.read_bytes()
    row = {'source': {'path': str(source), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}}
    if source.suffix == '.json':
        row['json'] = json.loads(body.decode('utf-8-sig'))
    else:
        lines = body.decode('utf-8-sig').splitlines()
        row['lines'] = [{'line': n, 'text': line} for n,line in enumerate(lines,1) if any(k in line for k in ('admit_saved_startup_event', 'expected_event', 'lyd_factory_diag', 'instance_id', 'event_definition', 'startup_contract', 'current_event'))]
    rows.append(row)
    print(json.dumps(row, ensure_ascii=False))
with (OUT / 'ACTOR-AND-HANDLER-INSPECTION.actual.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(rows, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
