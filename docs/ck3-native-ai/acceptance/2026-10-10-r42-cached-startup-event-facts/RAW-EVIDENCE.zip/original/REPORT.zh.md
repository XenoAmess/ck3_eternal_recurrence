# R34 D2a / R38 已缓存 marker 与事件身份核对

actor31254 的三份既有投影（R34 D2a、D2b、R38 selection 后）均保存完整 `alive_data.variables` AST，103 个变量中没有 `lyd_factory_diag_empty_transaction_completed`；整个缓存包也没有该名称。此为缓存内确定的缺失，不是本轮重新解析存档的结果。三个原 JSON 与相应 save 的精确 hash 见 SUMMARY。

R34 D2a 的原 native 回执和 R38 重载后的原 native 回执均确认 `lyd_factory_diag.20`、instance121、root31254、date53144712、option native0 显示且可用。两轮 calculatedEventId/运行目录序号不同，不能据它们代替 definition/instance 身份。Source03 当前 prepared 合同与相同的 a6db D2a seed 绑定，准确等待 `.20`，不是 `.2`。

旧 R38 与当前 overlay 的 `.20` 源块（事件文件52–77行）逐字相同。`.20` 的 event/option guard 是 stage20 与 unheld-title；不读取 completed marker。选择其 option 才在73行调用 D2 effect；当前 effect 在121行写 marker，123行触发后继 `.2`。当前 `.2` 的87/94行才读取 marker。因此 marker 在这份启动 seed 中缺失与源码阶段顺序一致，现有事实不支持把它改成启动修复。

Source03 host 在802–819行取得稳定 native owner/map frame 及 campaign root 后，才于820行调用 saved-startup admission。2496行函数仅查询 typed current event；产品 handler195–201行核 `.20` 身份并返回 business_pass=false，不选项、不检查 completed marker。业务选择是另一条 run_case 路径的321行。R42 未注入的加载超时没有进入该 typed handler。

三份缓存不含全局 event-manager/queue 投影，所以其他已保存/排队事件保持 UNKNOWN。R38 selection 后的旧诊断终局是 no-event，旧 `.2` 要求 held-title，与当时 unheld Title 不符；这个后继阶段事实不解释更早的启动停滞。

下一步不改 marker、不挂52 extras。若 ROOT 继续选择 saved-event 恢复假设，先定位已有 event-manager/queue 导出；若确实没有，再另行授权对同一 a6db seed 作一次有界 event-manager 记录投影，仅补 instance/definition/saved-scope 与排队事件清单。当前没有读取任何 .ck3 正文、操作 SDK/游戏、扫描 EXE、测试或修改主仓，也没有确定启动根因。
